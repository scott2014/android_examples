document.write('<script language="JavaScript" src="./js/src/base.js" type="text/javascript" charset="utf-8"></script>');
document.write('<script language="JavaScript" src="./js/src/newscont.js" type="text/javascript" charset="utf-8"></script>');
document.write('<script language="JavaScript" src="./js/src/toggleImage.js" type="text/javascript" charset="utf-8"></script>');