package com.tencent.news.push;

import java.io.Serializable;


public class stBasePushMessage implements Serializable{

	private static final long serialVersionUID = 6020563794598535663L;
	protected short wLength = 83;
	protected short wVersion = 0; // 目前版本号码 2.3.0
	protected short wCommand = 0x101;
	protected byte STX = 0x2;
	protected byte ETX = 0x3;
	
	public stBasePushMessage(){
	}
	
	public void setLength(short wLength){
		this.wLength = wLength;
	}
	
	public short getLength(){
		return this.wLength;
	}
	
	public void setVersion(short wVersion){
		this.wVersion = wVersion;
	}
	
	public short getVersion(){
		return this.wVersion;
	}
	
	public void setCommand(short wCommand){
		this.wCommand = wCommand;
	}
	
	public short getCommand(){
		return this.wCommand;
	}
	
	public void setSTX(byte stx){
		this.STX = stx;
	}
	
	public byte getSTX(){
		return this.STX;
	}
	
	public void setETX(byte etx){
		this.ETX = etx;
	}
	
	public byte getETX(){
		return this.ETX;
	}
	
	public byte[] getByteMessage()
	{
		return null;
	}
	
	@Override
	public String toString() {
		return "STX:" + STX+ " wLength"+wLength+" wVersion"+wVersion+" wCommand"
		+wCommand + " ETX" + ETX;
	}
}
