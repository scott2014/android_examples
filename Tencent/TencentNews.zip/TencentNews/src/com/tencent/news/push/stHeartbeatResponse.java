package com.tencent.news.push;

public class stHeartbeatResponse  extends stBasePushMessage {
	private static final long serialVersionUID = 1624609498321932503L;

}
