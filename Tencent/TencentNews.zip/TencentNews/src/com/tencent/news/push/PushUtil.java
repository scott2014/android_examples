
package com.tencent.news.push;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.content.Intent;

import com.tencent.news.api.JSON;
import com.tencent.news.model.pojo.Msg;
import com.tencent.news.utils.SLog;

public class PushUtil {
    public static final String keyFrom = "From";

    public static final String valueBoot = "Boot";
    public static final String valueAlarm = "Alarm";
    public static final String valueRestart = "restart";
    public static final String valueUser = "user";
    public static final String valueSettingOn = "valueSettingOn";
    public static final String valueSettingOff = "valueSettingOff";
    public static final String valueUnlockHomeScreen = "unlockHomeScreen";
    public static final String valueNetworkChanged = "networkChanged";

    private static final short MSG_COMMAND_REG = 0x101; // 注册消息
    private static final short MSG_COMMAND_HEART = 0x102; // 心跳消息
    private static final short MSG_COMMAND_PUSH = 0x203; // push消息

    public static void startPushService(Context context, String from) {
        Intent intent = new Intent(context, PushService.class);
        intent.putExtra(keyFrom, from);
        context.startService(intent);
    }

    private static boolean checkUpPackage(byte[] input, List<stBasePushMessage> lstMsgCommand, int nSize) {
        ByteArrayInputStream bs = null;
        DataInputStream in = null;
        try {
            bs = new ByteArrayInputStream(input);
            in = new DataInputStream(bs);
            byte etx;
            short length = 0;
            short tmpSize = 0;

            do {
                byte stx = in.readByte();
                length = in.readShort();
                tmpSize += length;
                short version = in.readShort();
                stBasePushMessage msgCommand = new stBasePushMessage();
                msgCommand.setCommand(in.readShort());
                if (stx == 0x2) {
                    byte[] msg = new byte[length - 8];
                    in.read(msg);
                    etx = in.readByte();
                    if (etx != 0x3) {
                        break;
                    }

                    lstMsgCommand.add(msgCommand);
                }

            } while (tmpSize < nSize);

            return lstMsgCommand.size() > 0 ? true : false;

        } catch (IOException e) {
            return false;
        } finally {
            try {
                bs.close();
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static List<stBasePushMessage> ReadMutiCommand(byte[] input, int nSize) {
        ByteArrayInputStream bs = null;
        DataInputStream in = null;
        List<stBasePushMessage> splitedCommands = new ArrayList<stBasePushMessage>();
        List<stBasePushMessage> receivedMsgs = new ArrayList<stBasePushMessage>();
        try {
            if (PushUtil.checkUpPackage(input, splitedCommands, nSize)) {
                bs = new ByteArrayInputStream(input);
                in = new DataInputStream(bs);

                for (int i = 0; i < splitedCommands.size(); ++i) {
                    switch (splitedCommands.get(i).getCommand()) // 修改使用命令字方式
                    {
                        case MSG_COMMAND_HEART:
                            stHeartbeatResponse heart = new stHeartbeatResponse();
                            heart.setSTX(in.readByte());
                            heart.setLength(in.readShort());
                            heart.setVersion(in.readShort());
                            heart.setCommand(in.readShort());
                            heart.setETX(in.readByte());
                            receivedMsgs.add(heart);
                            SLog.push(heart.toString(), "heart_response");
                            break;

                        case MSG_COMMAND_REG:
                            stRegisteResponse Register = new stRegisteResponse();
                            Register.setSTX(in.readByte());
                            Register.setLength(in.readShort());
                            Register.setVersion(in.readShort());
                            Register.setCommand(in.readShort());
                            Register.setResult(in.readByte());
                            Register.setETX(in.readByte());
                            receivedMsgs.add(Register);
                            SLog.push(Register.toString(), "Register_response");
                            break;

                        case MSG_COMMAND_PUSH:
                            stPushedResponse response = new stPushedResponse();
                            response.setSTX(in.readByte());
                            response.setLength(in.readShort());
                            response.setVersion(in.readShort());
                            response.setCommand(in.readShort());
                            response.setFlag(in.readByte());
                            response.setNewsSeq(in.readInt());
                            short msgLen = in.readShort();
                            response.setMsgLen(msgLen);
                            if (msgLen != 0) {
                                byte acMsg[] = new byte[msgLen];
                                in.read(acMsg);

                                try {
                                    JSONObject jo = new JSONObject(new String(acMsg));
                                    Msg msg = new Msg();
                                    msg.setChlid(JSON.getRawString("s", jo));
                                    msg.setMsg(JSON.getRawString("a", jo));
                                    msg.setNewsId(JSON.getRawString("i", jo));
                                    response.setMsg(msg);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                            response.setETX(in.readByte());
                            receivedMsgs.add(response);
                            SLog.push(response.toString(), "push_response");
                            break;

                    } // of switch
                } // of for

                return receivedMsgs;
            } // of if
            else {
                return null;
            }
        } catch (IOException e) {
            return null;
        } finally {
            try {
                bs.close();
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
