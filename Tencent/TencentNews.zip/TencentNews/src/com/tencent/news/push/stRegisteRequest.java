package com.tencent.news.push;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.StringUtil;

public class stRegisteRequest extends stBasePushMessage {

	private static final long serialVersionUID = 166995568599578903L;
	protected short dwBizType = 10001;
	protected int dwUserId = 0;
	protected byte acDevId[] = new byte[32];
	protected int dwReserved = 0;
	protected byte cAuthStrLen = 1;
	protected byte acAuthStr[];

	public stRegisteRequest(byte AuthStr[]) {
		super();
		cAuthStrLen = (byte) AuthStr.length;
		acAuthStr = new byte[cAuthStrLen];
		// 验证串
		System.arraycopy(AuthStr, 0, this.acAuthStr, 0, AuthStr.length);
		// 手机的imei
		System.arraycopy(MobileUtil.getImei().getBytes(), 0, acDevId, 0, MobileUtil.getImei().getBytes().length);
	}

	public void setReserved(int dwReserved) {
		this.dwReserved = dwReserved;
	}

	public int getReserved() {
		return this.dwReserved;
	}

	public void setAuthStrLen(byte cAuthStrLen) {
		this.cAuthStrLen = cAuthStrLen;
	}

	public byte getAuthStrLen() {
		return this.cAuthStrLen;
	}

	public void setacAuthStr(byte[] AuthStr) {
		acAuthStr = new byte[cAuthStrLen];
		System.arraycopy(AuthStr, 0, this.acAuthStr, 0, AuthStr.length);
	}

	public byte[] getacAuthStr() {
		return this.acAuthStr;
	}

	public void setBizType(short dwBizType) {
		this.dwBizType = dwBizType;
	}

	public short getBizType() {
		return this.dwBizType;
	}

	public void setUserId(int dwUserId) {
		this.dwUserId = dwUserId;
	}

	public int getUserId() {
		return this.dwUserId;
	}

	public void setDevId(byte[] acDevId) {
		System.arraycopy(acDevId, 0, this.acDevId, 0, acDevId.length);
	}

	public byte[] getDevId() {
		return this.acDevId;
	}

	@Override
	public byte[] getByteMessage() {
		ByteArrayOutputStream byteStream = null;
		DataOutputStream out = null;
		try {
			byteStream = new ByteArrayOutputStream();
			out = new DataOutputStream(byteStream);
			short nLength = (short) (51 + getAuthStrLen());

			out.writeByte(0x2);
			out.writeShort(nLength);
			out.writeShort(getVersion());
			out.writeShort(getCommand());
			out.writeShort(getBizType());
			out.writeInt(getUserId());
			out.write(getDevId());
			out.writeInt(getReserved());
			out.writeByte(getAuthStrLen());
			out.write(getacAuthStr());
			out.writeByte(0x3);
			out.flush();

			byte[] data = byteStream.toByteArray();
			SLog.i("questHead", "size:" + out.size() + StringUtil.toHexString(data, ""));
			return data;
		} catch (IOException e) {
			return null;
		} finally {
			try {
				byteStream.close();
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public String toString() {
		return "dwBizType" + dwBizType + " dwUserId" + dwUserId + " acDevId" + new String(acDevId) + " dwReserved" + dwReserved + " cAuthStrLen" + cAuthStrLen + " acAuthStr" + new String(acAuthStr);
	}
}
