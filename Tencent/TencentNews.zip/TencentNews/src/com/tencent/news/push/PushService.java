
package com.tencent.news.push;

import java.net.InetSocketAddress;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.nio.channels.SelectableChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.provider.Settings.SettingNotFoundException;
import android.widget.RemoteViews;

import com.google.gson.JsonSyntaxException;
import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.boss.EventId;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpDataResponse;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.model.pojo.Msg;
import com.tencent.news.model.pojo.PushConn;
import com.tencent.news.system.Application;
import com.tencent.news.system.NetStatusReceiver;
import com.tencent.news.system.PushAlarmReceiver;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.PushNewsDetailActivity;
import com.tencent.news.utils.ApnUtil;
import com.tencent.news.utils.InfoConfigUtil;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.StringUtil;
import com.tencent.news.utils.WakeLockUtil;
import com.tencent.omg.webdev.WebDev;

public class PushService extends Service implements HttpDataResponse {
    private final static int POOL_SIZE = 10;
    private final static int PUSH_SOCKET_MSG = 32;
    private final static int PUSH_CONN_MSG = 64;
    private final static int PUSH_NEEDPOLLING_MSG = 128;
    public final static long ALARM_TIME = 300 * 1000L;
    private final static String THREAD_NAME = "QQNewsHeartThread";
    private HeartThread mHeartThread;
    private List<String> mMsgQueue;
    private AlarmManager mAlarmManager;
    private PendingIntent mPendingIntent;
    private ConnectionChangeReceiver mNetReceiver;
    private int wakeupTime = -1;

    // test server
    // private String mIp = "news.mpush.qq.com";
    // private int mPort = 9501;
    // private String mAuth = "3e0c10fff52338d72bc23450";

    // online2
    private String mIp = "111.161.80.208";
    private int mPort = 7000;
    private String mAuth = "3e0c10fff52338d72bc23450";

    // TGW
    // private String mIp = "news.mpush.qq.com";
    // private int mPort = 9502;
    // private String mAuth = "3e0c10fff52338d72bc23450";

    public enum PushType {
        e_push, e_conn, e_inavailable,
    }

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            SLog.push("received a msg, msg.arg1 = " + msg.arg1, "on Handler");

            try {
                if (msg != null && msg.arg1 == PUSH_CONN_MSG && isAllowPush()) {
                    PushConn data = (PushConn) msg.obj;
                    if (data != null && data.getMsg() != null && checkMsgRerpeat(data.getSeq())) {
                        showNotification(data.getMsg(), data.getFlag(), false);
                        WebDev.trackCustomEvent(PushService.this, EventId.BOSS_PUSH, "get a msg by polling, seq=" + data.getSeq());
                    }

                } else if (msg != null && msg.arg1 == PUSH_SOCKET_MSG && isAllowPush()) {
                    stPushedResponse data = (stPushedResponse) msg.obj;
                    if (data != null && data.getMsg() != null && checkMsgRerpeat(String.valueOf(data.getNewsSeq()))) {
                        showNotification(data.getMsg(), String.valueOf(data.getFlag()), false);
                        WebDev.trackCustomEvent(PushService.this, EventId.BOSS_PUSH, "get a msg by push, seq=" + data.getNewsSeq());
                    }

                } else if (msg != null && msg.arg1 == PUSH_NEEDPOLLING_MSG && isAllowPush()) {
                    startPollingRequest();
                }
            } catch (JsonSyntaxException e1) {
                e1.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        SLog.push("onCreate", "onCreate");
        WebDev.trackCustomEvent(this, EventId.BOSS_PUSH, "PushService onCreate()");

        setWifiSleepMode();
        setForeground(true);
        setStatusByNetReceiver();

        initMsgHistory();

        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        wakeupTime++;

        String from = null;
        if (intent != null) {
            from = intent.getStringExtra(PushUtil.keyFrom);
        }

        if (from == null) {
            // 所有路径都用PushUtil.startPushService来启动，还需要排查
            SLog.push("onStartCommand from = null， start by user", "onStartCommand");
            from = PushUtil.valueRestart;
        }

        if (isStatAllowed()) {
            WebDev.trackCustomEvent(this, EventId.BOSS_PUSH, "onStartCommand() from=" + from);
        }
        SLog.push("onStartCommand from = " + from, "onStartCommand");

        if (PushUtil.valueBoot.equals(from) || PushUtil.valueRestart.equals(from) || PushUtil.valueUser.equals(from) || PushUtil.valueUnlockHomeScreen.equals(from) || PushUtil.valueSettingOn.equals(from)) {
            if (isAllowPush()) {
                startAlarm(getApplicationContext());
                SLog.push("init alarm manager", "onStartCommand");
            }
        } else if (PushUtil.valueNetworkChanged.equals(from)) {
            if (isAllowPush()) {
                startAlarm(getApplicationContext(), 15 * 1000);
                SLog.push("init alarm manager, valueNetworkChanged", "onStartCommand");
            }
        } else if (PushUtil.valueSettingOff.equals(from)) {
            stopPushService();
        } else if (PushUtil.valueAlarm.equals(from)) {
            PushType type = getConnectedType();
            SLog.push("PushType = " + type, "onStartCommand");
            if (isStatAllowed()) {
                WebDev.trackCustomEvent(this, EventId.BOSS_PUSH, "onStartCommand() PushType = " + type.name());
            }

            if (type == PushType.e_push) {
                if (isAllowPush()) {
                    // 心跳
                    if (isHeartThreadAlive() == false) {
                        SLog.push("start heartbeat thread", "onStartCommand");
                        startPushHeartThread(true);
                    } else {
                        SLog.push("wake up heartbeat thread to send a heartbeat package", "onStartCommand()");
                        notifyHeartThread();
                    }
                } else {
                    // 用户关闭push设置
                    stopPushService();
                }
            } else if (type == PushType.e_conn) {
                // 需要缩短timeout
                startPollingRequest();
            } else {
                // 没网络
                if (isStatAllowed()) {
                    WebDev.trackCustomEvent(this, EventId.BOSS_PUSH, "no available network onStartCommand()");
                }
                SLog.push("no available network", "onStartCommand");
            }
        } else {
            // 其它
        }

        Thread.yield();
        WakeLockUtil.releaseServiceWakeLock();
        return super.onStartCommand(intent, START_STICKY, startId);
    }

    @Override
    public void onDestroy() {
        SLog.push("onDestroy", "onDestroy");

        if (mMsgQueue != null) {
            mMsgQueue.clear();
        }

        if (isAllowPush() == false) {
            if (mAlarmManager != null && mPendingIntent != null) {
                mAlarmManager.cancel(mPendingIntent);
                mAlarmManager = null;
                mPendingIntent = null;
            }

            if (mPendingIntent != null) {
                mPendingIntent = null;
            }
        }

        if (mHeartThread != null) {
            stopPushHeartThread();
            try {
                mHeartThread.join(1000); // 等待线程完全退出
                SLog.push("onDestroy", "HeartThread has completely exit.");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        if (mHandler != null) {
            mHandler = null;
        }

        if (isAllowPush()) {
            retryStartService();
        }

        super.onDestroy();
    }

    private boolean isStatAllowed() {
        return (wakeupTime % 20) == 0;
    }

    private void initMsgHistory() {
        mMsgQueue = InfoConfigUtil.ReadPushSeq();
        if (mMsgQueue == null) {
            mMsgQueue = new ArrayList<String>();
        }
    }

    private boolean checkMsgRerpeat(String seq) {
        synchronized (mMsgQueue) {
            if (mMsgQueue != null) {
                if (mMsgQueue.contains(seq)) {
                    mMsgQueue.remove(seq);
                    mMsgQueue.add(seq);
                    InfoConfigUtil.WritePushSeq(mMsgQueue);
                    return false;
                } else {
                    mMsgQueue.add(seq);
                    int nLength = mMsgQueue.size();
                    if (nLength > POOL_SIZE) {
                        mMsgQueue.remove(0);
                    }
                    InfoConfigUtil.WritePushSeq(mMsgQueue);
                    return true;
                }
            }
            return true;
        }
    }

    private String getLatestPushMsg() {
        String msg = "";

        synchronized (mMsgQueue) {
            if (mMsgQueue != null && mMsgQueue.size() > 0) {
                msg = mMsgQueue.get(mMsgQueue.size() - 1);
            }
        }

        return msg;
    }

    private void setWifiSleepMode() {
        try {
            if (android.provider.Settings.System.getInt(getContentResolver(), android.provider.Settings.System.WIFI_SLEEP_POLICY) != android.provider.Settings.System.WIFI_SLEEP_POLICY_NEVER) {
                android.provider.Settings.System.putInt(getContentResolver(), android.provider.Settings.System.WIFI_SLEEP_POLICY, android.provider.Settings.System.WIFI_SLEEP_POLICY_NEVER);
            }
        } catch (SettingNotFoundException e) {
            // android.provider.Settings.System.putInt(getContentResolver(),
            // android.provider.Settings.System.WIFI_SLEEP_POLICY,
            // android.provider.Settings.System.WIFI_SLEEP_POLICY_NEVER);
        }
    }

    private void setStatusByNetReceiver() {
        IntentFilter filterNet = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        mNetReceiver = new ConnectionChangeReceiver();
        mNetReceiver.setLastNetWorkStatus(getConnectedType());
        this.registerReceiver(mNetReceiver, filterNet);
    }

    private boolean isAllowPush() {
        SettingInfo settingInfo = SettingObservable.getInstance().getData();
        return settingInfo.isIfPush();
    }

    public void startAlarm(Context context) {
        startAlarm(context, 1000);
    }

    public void startAlarm(Context context, long delay) {
        if (mAlarmManager == null) {
            mAlarmManager = (AlarmManager) context.getSystemService(ALARM_SERVICE);
        }
        if (mPendingIntent == null) {
            Intent intent = new Intent(context, PushAlarmReceiver.class);
            intent.setAction(Constants.ALARM_ACTION);
            mPendingIntent = PendingIntent.getBroadcast(context, 0, intent, 0);
        }

        if (mAlarmManager != null && mPendingIntent != null) {
            mAlarmManager.cancel(mPendingIntent);
        }

        mAlarmManager.setRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + delay, ALARM_TIME, mPendingIntent);
    }

    private void stopAlarm() {
        if (mAlarmManager != null && mPendingIntent != null) {
            mAlarmManager.cancel(mPendingIntent);
            mAlarmManager = null;
            mPendingIntent = null;
        }
    }

    private void stopPushService() {
        WebDev.trackCustomEvent(this, EventId.BOSS_PUSH, "stopPushService");

        try {
            stopAlarm();

            if (isHeartThreadAlive()) {
                stopPushHeartThread();
            }
            mHeartThread.join(1000); // 等待线程完全退出
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        stopSelf();
        WakeLockUtil.releaseServiceWakeLock();

        boolean isServiceRunningInSeparateProcess = Application.getInstance().isServiceRunningInSeparateProcess;
        if (isServiceRunningInSeparateProcess) {
            System.exit(0);
        }
    }

    private void retryStartService() {
        startAlarm(getApplicationContext());
        PushUtil.startPushService(getApplicationContext(), PushUtil.valueRestart);
    }

    private boolean isHeartThreadAlive() {
        if (isStatAllowed()) {
            WebDev.trackCustomEvent(this, EventId.BOSS_PUSH, "isHeartThreadAlive()=" + ((mHeartThread != null) && mHeartThread.isAlive()));
        }

        return ((mHeartThread != null) && mHeartThread.isAlive());
    }

    private void startPushHeartThread(boolean isPush) {
        if (isStatAllowed()) {
            WebDev.trackCustomEvent(this, EventId.BOSS_PUSH, "startPushHeartThread()");
        }

        // 检查现有Thread
        stopPushHeartThread();

        mHeartThread = new HeartThread(this);
        mHeartThread.setName(THREAD_NAME);
        mHeartThread.start();
    }

    private void stopPushHeartThread() {
        if (isStatAllowed()) {
            WebDev.trackCustomEvent(this, EventId.BOSS_PUSH, "stopPushHeartThread()");
        }

        Thread[] tarray = new Thread[Thread.activeCount()];
        Thread.enumerate(tarray);

        for (Thread thread : tarray) {
            if (thread != null && thread.getName().equals(THREAD_NAME) && thread instanceof HeartThread) {
                ((HeartThread) thread).stopThread();
            }
        }
    }

    private void notifyHeartThread() {
        if (isStatAllowed()) {
            WebDev.trackCustomEvent(this, EventId.BOSS_PUSH, "wake up heartbeat thread notifyHeartThread()");
        }

        mHeartThread.wakeup();
    }

    private void showNotification(Msg data, String bSound, boolean bLight) {
        int id = 0x345;
        NotificationManager notiManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification notification = new Notification(R.drawable.icon, "腾讯新闻", System.currentTimeMillis());
        notification.flags = Notification.FLAG_AUTO_CANCEL;

        if (bSound.equals("0")) {
            notification.defaults |= Notification.DEFAULT_SOUND;
        }
        if (bLight) {
            notification.ledARGB = Color.BLUE;
            notification.ledOffMS = 200;
            notification.ledOnMS = 150;
            notification.defaults |= Notification.DEFAULT_LIGHTS;
        }

        Intent intent = new Intent(this, PushNewsDetailActivity.class);
        intent.putExtra(Constants.NEWS_CHANNEL_CHLID_KEY, data.getChlid());
        intent.putExtra(Constants.NEWS_DETAIL_TITLE_KEY, "腾讯新闻");
        intent.putExtra("pushserviceid", data.getNewsId());
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent contentIntent = PendingIntent.getActivity(this, id, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        notification.contentIntent = contentIntent;
        RemoteViews contentView = new RemoteViews(getPackageName(), R.layout.notification_layout);
        contentView.setImageViewResource(R.id.push_notify_icon, R.drawable.icon);
        String briefContent = data.getMsg();
        String strTitle = data.getTitle()==null? "腾讯新闻": StringUtil.ToDBC(data.getTitle());
        
        if(strTitle.length()>10){
        	strTitle = strTitle.substring(0,8) + "...";
        }

        briefContent = StringUtil.ToDBC(briefContent);
        // 获取当前时间
        SimpleDateFormat formatter = new SimpleDateFormat("HH:mm");
        Date curDate = new Date(System.currentTimeMillis());// 获取当前时间
        String strTime = formatter.format(curDate);

        contentView.setTextViewText(R.id.push_notify_content, briefContent);
        contentView.setTextViewText(R.id.push_notify_time, strTime);
        contentView.setTextViewText(R.id.push_notify_title, strTitle);
        notification.contentView = contentView;
        notiManager.notify(id, notification);
    }

    private PushType getConnectedType() {
        PushType type = PushType.e_inavailable;
        if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_WIFI || (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_MOBILE) && !ApnUtil.isWapApnConnected(this)) {
            type = PushType.e_push;
        } else if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_MOBILE && ApnUtil.isWapApnConnected(this)) {
            type = PushType.e_conn;
        } else {
            type = PushType.e_inavailable;
        }

        SLog.push("type = " + type, "getConnectedType");

        return type;
    }

    private void startPollingRequest() {
        if (isStatAllowed()) {
            WebDev.trackCustomEvent(this, EventId.BOSS_PUSH, "startPollingRequest()");
        }
        SLog.push("start polling request", "getPushConn");

        WakeLockUtil.acquireNetWakeLock(getApplicationContext());

        String latestMsg = getLatestPushMsg();
        HttpDataRequest request = TencentNews.getInstance().getPushConnect(mAuth, latestMsg);
        TaskManager.startHttpDataRequset(request, PushService.this);
    }

    @Override
    public void onHttpRecvOK(HttpTag tag, Object result) {
        if (isStatAllowed()) {
            WebDev.trackCustomEvent(this, EventId.BOSS_PUSH, "startPollingRequest() onHttpRecvOK");
        }

        WakeLockUtil.releaseNetWakeLock();

        if (tag.equals(HttpTag.PUSH_MSG_CONN)) {
            PushConn push = (PushConn) result;
            if (push != null) {
                Message msg = Message.obtain();
                msg.obj = push;
                msg.arg1 = PUSH_CONN_MSG;
                mHandler.sendMessage(msg);
            }
        }
    }

    @Override
    public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {
        if (isStatAllowed()) {
            WebDev.trackCustomEvent(this, EventId.BOSS_PUSH, "startPollingRequest() onHttpRecvError");
        }

        WakeLockUtil.releaseNetWakeLock();

        SLog.push("onHttpRecvError", "onHttpRecvError");
        if (tag.equals(HttpTag.PUSH_MSG_CONN)) {
        }
    }

    @Override
    public void onHttpRecvCancelled(HttpTag tag) {
        if (isStatAllowed()) {
            WebDev.trackCustomEvent(this, EventId.BOSS_PUSH, "startPollingRequest() onHttpRecvCancelled");
        }

        WakeLockUtil.releaseNetWakeLock();

        SLog.push("onHttpRecvCancelled", "onHttpRecvCancelled");
        if (tag.equals(HttpTag.PUSH_MSG_CONN)) {
        }
    }

    private class HeartThread extends Thread {
        private static final int bufferSize = 2048;
        private Context mContext;
        private Selector selector;
        private ByteBuffer byteBuffer = ByteBuffer.allocate(bufferSize);
        private SocketChannel socketChannel;
        private boolean cancelled = true;
        private int nRetryCount = 0;
        private int nHeartbeartCount = 0;
        private int nRecvPartialPackageCount = 0;
        private boolean didRegisteSuccess = false;

        public HeartThread(Context context) {
            this.mContext = context;
        }

        public synchronized void stopThread() {
            cancelled = false;
            if (selector != null) {
                selector.wakeup();
            }
        }

        private void initSocket() throws Exception {
            if (selector != null || socketChannel != null) {
                return;
            }

            SLog.push("init socket start", "init_socket_start");

            if (nRetryCount >= 1) {
                SLog.push("will exit, nRetryCount=" + nRetryCount, "initSocket");

                stopThread();// 退出
            } else {
                SLog.push("create a new socket, nRetryCount=" + nRetryCount, "initSocket");

                java.lang.System.setProperty("java.net.preferIPv4Stack", "true");
                java.lang.System.setProperty("java.net.preferIPv6Addresses", "false");

                nRetryCount++;
                byteBuffer.clear();
                selector = Selector.open();

                socketChannel = SocketChannel.open();
                socketChannel.configureBlocking(false);
                socketChannel.socket().setTcpNoDelay(true);
                socketChannel.connect(new InetSocketAddress(mIp, mPort));
                socketChannel.register(selector, SelectionKey.OP_CONNECT);
            }

            SLog.push("init_socket_end", "init_socket_end");
        }

        private void closeSocket() throws Exception {
            if (selector != null) {
                selector.close();
                selector = null;
            }
            if (socketChannel != null) {
                socketChannel.close();
                socketChannel = null;
            }

            byteBuffer.clear();

            SLog.push("close socket", "close socket");
        }

        private byte[] sendRegisteMsg() throws Exception {
            stRegisteRequest msg = new stRegisteRequest(mAuth.getBytes());
            byte data[] = msg.getByteMessage();
            return data;
        }

        @SuppressWarnings("unused")
        private List<stBasePushMessage> parseResponseData(byte[] input, int nSize) throws Exception {
            List<stBasePushMessage> lstHead = PushUtil.ReadMutiCommand(input, nSize);
            List<stBasePushMessage> retMsgs = new ArrayList<stBasePushMessage>();
            int length = 0;

            for (int i = 0; i < lstHead.size(); i++) {
                stBasePushMessage head = lstHead.get(i);
                length += head.getLength();

                if (head != null) {
                    if (head instanceof stRegisteResponse) {
                        SLog.push("stRegisteResponse", "parseResponseData");

                        byte result = ((stRegisteResponse) head).getResult();

                        WebDev.trackCustomEvent(PushService.this, EventId.BOSS_PUSH, "parseResponseData() stRegisteResponse result=" + result);

                        if (result != 0) {
                            throw new SocketException("Register failed!");
                        } else {
                            didRegisteSuccess = true;
                        }

                    } else if (head instanceof stPushedResponse) {
                        SLog.push("stPushedResponse", "parseResponseData");

                        stPushedResponse data = (stPushedResponse) head;
                        Message msg = Message.obtain();
                        msg.arg1 = PUSH_SOCKET_MSG;
                        msg.obj = data;
                        mHandler.sendMessage(msg);

                        WebDev.trackCustomEvent(PushService.this, EventId.BOSS_PUSH, "parseResponseData() stPushedResponse getNewsSeq()=" + data.getNewsSeq());

                        retMsgs.add(new stPushedRequest(data.getNewsSeq()));

                    } else if (head instanceof stHeartbeatResponse) {
                        SLog.push("stHeartbeatResponse: msg= " + head, "parseResponseData");

                    } else {
                        SLog.push("unknown package", "parseResponseData");
                        throw new SocketException("unknown package!");

                    }
                }
            }

            if (length < nSize) {
                byte[] remain = new byte[nSize - length];
                System.arraycopy(input, length, remain, 0, nSize - length);
                byteBuffer.clear();
                byteBuffer.put(remain);
            } else {
                byteBuffer.clear();
            }

            if (lstHead.size() > 0) {
                if (byteBuffer.position() == 0) {
                    nRecvPartialPackageCount = 0;
                } else {
                    nRecvPartialPackageCount = 1;
                }
            } else {
                if (byteBuffer.position() != 0) {
                    nRecvPartialPackageCount++;
                }
            }

            // test
            if (nRecvPartialPackageCount != 0) {
                SLog.push("nRecvPartialPackageCount = " + nRecvPartialPackageCount, "parseResponseData");
            }

            return retMsgs;
        }

        public void wakeup() {
            if (selector != null) {
                selector.wakeup();
            }
        }

        @Override
        public void run() {

            while (cancelled) {
                try {
                    initSocket();

                    WakeLockUtil.releaseNetWakeLock();
                    int nNum = selector.select(ALARM_TIME * 2);
                    WakeLockUtil.acquireNetWakeLock(mContext);

                    if (nNum == 0 && socketChannel != null && socketChannel.isConnected()) {
                        // 心跳消息
                        if (nHeartbeartCount >= 2) {
                            SLog.push("lost too many heartbeat package!", "before_heartbeat");
                            throw new SocketException("lost too many heartbeat package!");
                        } else {
                            stHeartbeatRequest msg = new stHeartbeatRequest();
                            socketChannel.write(ByteBuffer.wrap(msg.getByteMessage()));
                            socketChannel.register(selector, SelectionKey.OP_READ);
                            nHeartbeartCount++;
                            SLog.push("#####,sent a heartbeat " + msg.toString(), "after_heartbeat");
                        }
                    } else {
                        Iterator<SelectionKey> keyIterator = selector.selectedKeys().iterator();

                        while (keyIterator.hasNext()) {
                            SelectionKey key = keyIterator.next();
                            keyIterator.remove();

                            if (key.isConnectable()) {
                                SocketChannel socketChannel = (SocketChannel) key.channel();
                                boolean isConnectSuccess = socketChannel.isConnectionPending() && socketChannel.finishConnect();

                                if (isStatAllowed()) {
                                    WebDev.trackCustomEvent(PushService.this, EventId.BOSS_PUSH, "HeartThread isConnectSuccess=" + isConnectSuccess);
                                }

                                if (isConnectSuccess) {
                                    // 发送注册消息
                                    SLog.push("finishConnect, will send a regist package", "finishConnect");
                                    if (isStatAllowed()) {
                                        WebDev.trackCustomEvent(mContext, EventId.BOSS_PUSH, "sent regist package in HeartThread");
                                    }

                                    socketChannel.write(ByteBuffer.wrap(sendRegisteMsg()));
                                    socketChannel.register(selector, SelectionKey.OP_READ);
                                    SLog.push("sent regist package, ", "register");

                                } else {
                                    SLog.push("cant not connect to server", "cant not connect to server");
                                    throw new SocketException("need to create a new socket!");
                                }
                            } else if (key.isReadable()) {
                                // 读取消息
                                SelectableChannel channel = key.channel();
                                if (channel == socketChannel) {
                                    int nSize = socketChannel.read(byteBuffer);
                                    byteBuffer.flip();

                                    if (nSize <= 0) {
                                        throw new SocketException("closed by server! " + nSize);
                                    } else {
                                        SLog.push("byteBuffer.size = " + byteBuffer.limit(), "isReadable");

                                        nRetryCount = 0;
                                        nHeartbeartCount = 0;
                                        List<stBasePushMessage> msgList = parseResponseData(byteBuffer.array(), nSize);

                                        if (nRecvPartialPackageCount > 5 || (byteBuffer.position() > (bufferSize / 2))) {
                                            SLog.push("unknown package, too long, reset connection", "isReadable");
                                            throw new SocketException("unknown package, too long, reset connection");
                                        }

                                        // 对成功收到包后的回包,暂时不能打开，会对线上现有push有影响，等待后台升级
                                        // for (stBasePushMessage msg : msgList)
                                        // {
                                        // socketChannel.write(ByteBuffer.wrap(msg.getByteMessage()));
                                        // }
                                    }
                                } else {
                                    SLog.push("unknown package type： " + channel.getClass().getName() + "," + channel.toString(), "isReadable");
                                    throw new SocketException("unknown package type： " + channel.getClass().getName());
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    try {
                        if (isStatAllowed()) {
                            WebDev.trackCustomEvent(PushService.this, EventId.BOSS_PUSH, "HeartThread while loop() catch a exception" + e.toString());
                        }
                        SLog.push(e.toString(), "catch a exception, in while loop");

                        closeSocket();
                        initSocket();
                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }
                }
            }

            try {
                closeSocket();
            } catch (Exception e) {
                e.printStackTrace();
            }

            // 通知主线程轮询
            if (didRegisteSuccess == false && getConnectedType() != PushType.e_inavailable) {
                Message msg = Message.obtain();
                msg.arg1 = PUSH_NEEDPOLLING_MSG;
                mHandler.sendMessage(msg);
            } else {
                WakeLockUtil.releaseNetWakeLock();
            }

            SLog.push("thread exit", "thread exit:" + Thread.currentThread().getId());
            if (isStatAllowed()) {
                WebDev.trackCustomEvent(PushService.this, EventId.BOSS_PUSH, "HeartThread exit");
            }
        }
    }

    public class ConnectionChangeReceiver extends BroadcastReceiver {
        private PushType lastNetWorkStatus;

        public PushType getLastNetWorkStatus() {
            return lastNetWorkStatus;
        }

        public void setLastNetWorkStatus(PushType lastNetWorkStatus) {
            this.lastNetWorkStatus = lastNetWorkStatus;
        }

        @Override
        public void onReceive(Context context, Intent intent) {
            PushType currentNetWorkStatus = getConnectedType();
            SLog.push("lastNetWorkStatus = " + lastNetWorkStatus + ", currentNetWorkStatus = " + currentNetWorkStatus, "ConnectionChangeReceiver");

            if (lastNetWorkStatus == PushType.e_inavailable && currentNetWorkStatus != PushType.e_inavailable) {
                PushUtil.startPushService(getApplicationContext(), PushUtil.valueNetworkChanged);
            }

            lastNetWorkStatus = currentNetWorkStatus;
        }
    }
}
