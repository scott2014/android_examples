package com.tencent.news.push;

public class stRegisteResponse extends stBasePushMessage{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8312753394221304900L;
	private byte cResult;
	
	public void setResult(byte cResult){
		this.cResult = cResult;
	}
	
	public byte getResult(){
		return this.cResult;
	}
	
	@Override
	public String toString() {
		return "STX:" + STX+ " wLength"+wLength+" wVersion"+wVersion+" wCommand"
		+wCommand+" cResult" + cResult;
	}
}
