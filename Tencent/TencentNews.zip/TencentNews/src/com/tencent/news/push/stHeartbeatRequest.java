package com.tencent.news.push;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import com.tencent.news.utils.SLog;
import com.tencent.news.utils.StringUtil;

public class stHeartbeatRequest extends stBasePushMessage {
	private static final long serialVersionUID = 6028882267442517882L;


	@Override
	public byte[] getByteMessage() {
		ByteArrayOutputStream byteStream = null;
		DataOutputStream out = null;
		try{
			byteStream = new ByteArrayOutputStream();
			out = new DataOutputStream(byteStream);
			out.writeByte(0x2);
			out.writeShort(8);
			out.writeShort(getVersion());
			out.writeShort(0x102);
			out.writeByte(0x3);
			out.flush();
			byte[] data = byteStream.toByteArray();
			SLog.i("questHead","size:" + out.size() + StringUtil.toHexString(data,""));
			return data;
		}catch(IOException e){
			return null;
		}finally{
			try {
				byteStream.close();
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
}
