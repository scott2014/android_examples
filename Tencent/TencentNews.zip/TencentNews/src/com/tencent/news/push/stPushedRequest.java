package com.tencent.news.push;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import com.tencent.news.utils.SLog;
import com.tencent.news.utils.StringUtil;

public class stPushedRequest extends stBasePushMessage {

	private static final long serialVersionUID = 1519129109614380169L;
	public int dwNewsSeq;
	
	public stPushedRequest(int dwNewsSeq) {
		super();
		
		setCommand((short)0x204);
		setDwNewsSeq(dwNewsSeq);
	}
	public int getDwNewsSeq() {
		return dwNewsSeq;
	}
	public void setDwNewsSeq(int dwNewsSeq) {
		this.dwNewsSeq = dwNewsSeq;
	}

	@Override
	public byte[] getByteMessage() {
		ByteArrayOutputStream byteStream = null;
		DataOutputStream out = null;
		try{
			byteStream = new ByteArrayOutputStream();
			out = new DataOutputStream(byteStream);
			out.writeByte(0x2);
			out.writeShort(12);
			out.writeShort(getVersion());
			out.writeShort(getCommand());
			out.writeInt(getDwNewsSeq());
			out.writeByte(0x3);
			out.flush();
			byte[] data = byteStream.toByteArray();
			SLog.i("questHead","size:" + out.size() + StringUtil.toHexString(data,""));
			return data;
		}catch(IOException e){
			return null;
		}finally{
			try {
				byteStream.close();
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
}
