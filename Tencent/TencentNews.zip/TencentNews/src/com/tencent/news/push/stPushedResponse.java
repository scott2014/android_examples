
package com.tencent.news.push;

import com.tencent.news.model.pojo.Msg;

public class stPushedResponse extends stBasePushMessage {

    private static final long serialVersionUID = -2175851390006011910L;
    private byte cFlag;
    private int dwNewsSeq;
    private short cMsgLen;
    private Msg msg;

    public stPushedResponse() {

    }

    public void setFlag(byte cFlag) {
        this.cFlag = cFlag;
    }

    public byte getFlag() {
        return this.cFlag;
    }

    public void setNewsSeq(int dwNewsSeq) {
        this.dwNewsSeq = dwNewsSeq;
    }

    public int getNewsSeq() {
        return this.dwNewsSeq;
    }

    public void setMsgLen(short cMsgLen) {
        this.cMsgLen = cMsgLen;
    }

    public short getMsgLen() {
        return this.cMsgLen;
    }

    public Msg getMsg() {
        return this.msg;
    }

    public void setMsg(Msg msg) {
        this.msg = msg;
    }

    @Override
    public String toString() {
        return "STX:" + STX + " length:" + wLength + " wVersion:" + wVersion + " wCommand:" + wCommand + " cFlag" + cFlag + " dwNewsSeq:" + dwNewsSeq
                + " cMsgLen" + cMsgLen + " Msg:" + this.msg.toString() + " ETX:" + ETX;
    }
}
