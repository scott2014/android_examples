package com.tencent.news.utils;

import com.tencent.news.ui.ImageDetailActivity;
import com.tencent.news.ui.ImgTxtLiveActivity;
import com.tencent.news.ui.NewsDetailActivity;
import com.tencent.news.ui.SpecialListActivity;
import com.tencent.news.ui.WebDetailActivity;

public class DispatchClassUtil {

	public static Class<? extends Object> getClassName(String type) {
		if ("1".equals(type)) {
			return ImageDetailActivity.class;
		} else if ("5".equals(type)) {
			return WebDetailActivity.class;
		} else if (("100").equals(type)) {
			return SpecialListActivity.class;
		} else if ("7".equals(type)) {
			return ImgTxtLiveActivity.class;
		}
		return NewsDetailActivity.class;
	}

}
