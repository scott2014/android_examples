package com.tencent.news.system;
//
//import com.tencent.news.R;
//import com.tencent.news.model.pojo.WXUserInfo;
//import com.tencent.news.shareprefrence.SpConfig;
//import com.tencent.news.utils.StringUtil;
//
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.ImageView;
import android.widget.TextView;

import com.tencent.news.ui.MyAccountActivity;
//import android.content.Context;
//import android.content.Intent;
//import android.graphics.Color;
//import android.view.View;
//import android.widget.ImageView;
//import android.widget.LinearLayout;
//import android.widget.TextView;
//
public class WeiXinAuthBroadcastReceiver extends BroadcastReceiver {

	public WeiXinAuthBroadcastReceiver(MyAccountActivity myAccountActivity, TextView login_weixin_state, ImageView icon_weixin_login, TextView login_weixin_text, TextView weixin_username,
			String login_state_color, String logged_state_color) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onReceive(Context context, Intent intent) {
		
	}
//	LinearLayout weixinAccount = null;
//	TextView weixin_username = null;
//	TextView login_weixin_text = null;
//	ImageView icon_weixin_login = null;
//	TextView login_weixin_state = null;
//	Context myContext = null;
//	String logged_state_color="#999999";
//	String login_state_color="#2E65A8";
//	
//	public WeiXinAuthBroadcastReceiver(Context myContext,TextView login_weixin_state,ImageView icon_weixin_login,TextView login_weixin_text,TextView weixin_username,String login_state_color,String logged_state_color){
//		this.myContext = myContext;
//		this.login_weixin_state = login_weixin_state;
//		this.icon_weixin_login = icon_weixin_login;
//		this.login_weixin_text = login_weixin_text;
//		this.weixin_username = weixin_username;
//		this.logged_state_color = logged_state_color;
//		this.login_state_color = login_state_color;
//	}
//
//	@Override
//	public void onReceive(Context context, Intent intent) {
//		// TODO Auto-generated method stub
//		String weixinUser="登录用户";
//		WXUserInfo weixinInfo = SpConfig.loadWXSendAuthResp();
//		if (weixinInfo != null) {
//			weixinUser=weixinInfo.getUserName();
//		//if(weixnlogin==true){
//			icon_weixin_login.setImageResource(R.drawable.set_weixin_login_icon);
//			login_weixin_text.setText(myContext.getResources().getString(R.string.logout_weixin));
//			weixin_username.setText(weixinUser);
//			login_weixin_state.setText(myContext.getResources().getString(R.string.logged));
//			login_weixin_state.setTextColor(Color.parseColor(logged_state_color));
//		}else{
//			icon_weixin_login.setImageResource(R.drawable.icon_setting_weixin);
//			login_weixin_text.setText(myContext.getResources().getString(R.string.login_weixin));
//			weixin_username.setText("");//未登录用户名处显示信息
//			login_weixin_state.setText(myContext.getResources().getString(R.string.not_login));
//			login_weixin_state.setTextColor(Color.parseColor(login_state_color));
//		}
//
//	}
//
}
