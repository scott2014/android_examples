//package com.tencent.news.model.pojo;
//
//import java.io.Serializable;
//import java.util.List;
//
//public class AppList implements Serializable {
//
//	/**
//	 * 
//	 */
//	private static final long serialVersionUID = -5653000824161031829L;
//	private List<App> mAppList;
//	private String version;
//
//	public void setAppList(List<App> list) {
//		this.mAppList = list;
//	}
//
//	public List<App> getAppList() {
//		return this.mAppList;
//	}
//
//	public void setVersion(String version) {
//		this.version = version;
//	}
//
//	public String getVersion() {
//		return this.version;
//	}
//}
