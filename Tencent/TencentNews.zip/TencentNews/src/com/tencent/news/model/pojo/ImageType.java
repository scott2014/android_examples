package com.tencent.news.model.pojo;

public enum ImageType {
	SPLASH_IMAGE,
	PNG_IMAGE,
	SMALL_IMAGE,
	LARGE_IMAGE,
	EXTENDED_IMAGE,
}
