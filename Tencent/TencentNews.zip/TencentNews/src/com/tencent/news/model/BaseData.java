package com.tencent.news.model;


public abstract class BaseData {
	public abstract boolean realEquals(Object o);
}
