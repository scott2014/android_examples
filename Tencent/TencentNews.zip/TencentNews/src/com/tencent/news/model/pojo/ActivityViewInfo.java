package com.tencent.news.model.pojo;

import android.view.View;

public class ActivityViewInfo {
	public String mActivityId;
	public View mView;

	public ActivityViewInfo(String mActivityId, View mView) {
		super();
		this.mActivityId = mActivityId;
		this.mView = mView;

	}

}
