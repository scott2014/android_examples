package com.tencent.news.activity;

import java.io.File;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.RelativeLayout;

import com.tencent.news.R;
import com.tencent.news.boss.EventId;
import com.tencent.news.cache.FavorItemCache;
import com.tencent.news.config.Constants;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.model.pojo.ChannelList;
import com.tencent.news.model.pojo.ListMapData;
import com.tencent.news.model.pojo.Pic;
import com.tencent.news.model.pojo.RemoteConfig;
import com.tencent.news.model.pojo.SplashData;
import com.tencent.news.push.PushUtil;
import com.tencent.news.shareprefrence.SpUpdate;
import com.tencent.news.system.Application;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.GuideActivity;
import com.tencent.news.ui.MainActivity;
import com.tencent.news.utils.ApkUtil;
import com.tencent.news.utils.FileUtil;
import com.tencent.news.utils.ImageCacheNameUtil;
import com.tencent.news.utils.ImageUtil;
import com.tencent.news.utils.InfoConfigUtil;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.NewsRemoteConfigHelper;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.SharedPrefManager;
import com.tencent.news.utils.TempManager;
import com.tencent.omg.webdev.WebDev;

public class SplashActivity extends Activity {
	private final static long SPLASH_TIME = 2 * 1000L;
	private final static int START_MSG = 0x201;
	private static boolean APK_AVAILABLE = true;
	private ImageView mBackGround;
	private ImageView mImage;
	private ImageView mLogo;
	private SplashData mData;
	private Bitmap mDefaultLogo;
	private Bitmap mDefaultBg;
	private Bitmap mDefaultFoot;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// Auto-generated method stub
		super.onCreate(savedInstanceState);
		// Application.getInstance().statistics_app_start =
		// System.currentTimeMillis() / 1000;
		setContentView(R.layout.splash);
		createShortcut();
		InitData();
		InitConfig();
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}

	private void createShortcut() {
		Log.i("shortcut", "fffffffffff");
		// ApkUtil.shortcuts(this);
		ApkUtil.createShortcut(this);
	}

	private void InitData() {
		mData = InfoConfigUtil.ReadSplash();
		mDefaultLogo = ImageUtil.FromResToBitmap(getResources(), R.drawable.splash_logo);
		mDefaultBg = ImageUtil.FromResToBitmap(getResources(), R.drawable.splash_floor);
		mDefaultFoot = ImageUtil.FromResToBitmap(getResources(), R.drawable.splash_logo_foot);
	}

	private void loadDefaultImage() {
		mBackGround.setScaleType(ScaleType.FIT_XY);
		mBackGround.setImageBitmap(mDefaultBg);
		setSplashImage(mDefaultLogo, "1");
		mLogo.setImageBitmap(mDefaultFoot);
	}

	private void InitView() {
		mBackGround = (ImageView) findViewById(R.id.splash_background);
		mImage = (ImageView) findViewById(R.id.splash_image);
		mLogo = (ImageView) findViewById(R.id.splash_foot);

		if (mData != null && mData.getPics() != null) {
			int nLength = mData.getPics().length;
			if (nLength > 0) {
				for (int i = 0; i < nLength; i++) {
					Pic pic = mData.getPics()[i];
					if (pic != null && checkPicTime(pic)) {
						if (pic.getMode().equals("0")) {
							Bitmap bm = getSplashImage(pic.getPic());
							Bitmap logo = getSplashImage(pic.getLogo());
							if (bm != null) {
								mLogo.setVisibility(View.GONE);
								mImage.setVisibility(View.GONE);
								setSplashImage(bm, "0");
								if (logo != null) {
									mLogo.setVisibility(View.VISIBLE);
									mLogo.setImageBitmap(logo);
								}
							} else {
								loadDefaultImage();
							}
						} else {
							Bitmap logo = getSplashImage(pic.getLogo());
							Bitmap bm = getSplashImage(pic.getPic());
							Bitmap bg = getSplashImage(pic.getBackGround());
							if (logo != null && bm != null && bg != null) {
								mLogo.setVisibility(View.VISIBLE);
								mImage.setVisibility(View.VISIBLE);
								mBackGround.setImageBitmap(bg);
								mLogo.setImageBitmap(logo);
								setSplashImage(bm, "1");
							} else {
								loadDefaultImage();
							}
						}
						break;
					} else {
						continue;
					}
				}
			} else {
				loadDefaultImage();
			}
		} else {
			loadDefaultImage();
		}
	}

	private boolean checkPicTime(Pic pic) {
		if (pic != null) {
			long currTime = System.currentTimeMillis() / 1000;
			long start = Long.valueOf(pic.getStart());
			long end = Long.valueOf(pic.getEnd());
			if (currTime >= start && currTime <= end) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	private Bitmap getSplashImage(String url) {
		String filePath = ImageCacheNameUtil.getSplashImageFileName(url);
		Bitmap bm = ImageUtil.FromFileToBitmap(filePath);
		return bm;
	}

	private void setSplashImage(Bitmap bm, String mode) {
		if (mode.equals("0")) {
			mBackGround.setScaleType(ScaleType.CENTER_CROP);
			mBackGround.setImageBitmap(bm);
		} else {
			int nWidth = bm.getWidth();
			int nHeight = bm.getHeight();
			int desImageViewWidth = 0;
			int desImageViewHeight = 0;
			int totalWidth = MobileUtil.getScreenWidthIntPx();
			desImageViewWidth = totalWidth;
			desImageViewHeight = totalWidth * nHeight / nWidth;
			RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) mImage.getLayoutParams();
			lp.width = desImageViewWidth;
			lp.height = desImageViewHeight;
			mImage.setLayoutParams(lp);
			mImage.setScaleType(ScaleType.FIT_XY);
			mImage.setImageBitmap(bm);
		}

	}

	private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if (msg != null && msg.what == START_MSG && APK_AVAILABLE) {
				startMainActivity();
			}
		}
	};

	private void InitConfig() {
		long time1 = System.currentTimeMillis();
		InitView();
		RemoteConfig config = null;
		ListMapData channel = null;
		boolean isInit = true;
		if (SpUpdate.startFromWhat() != SpUpdate.START_FROM_NORMAL) {
			ChannelList channelTemp = null;
			SLog.v("首次安装或更新");
			config = TempManager.getManager().getRemoteConfigInfo(SplashActivity.this);
			channelTemp = TempManager.getManager().getChannelListInfo(SplashActivity.this);
			if (SpUpdate.startFromWhat() == SpUpdate.START_FROM_UPDATE) {
				ListMapData tempListMapData = InfoConfigUtil.ReadSubChannel();
				if (tempListMapData != null && tempListMapData.getMenuDataMap() != null && tempListMapData.getMenuDataMap().size() > 0) {
					isInit = false;
				}
			}
			if (isInit == true && channelTemp != null && channelTemp.getChannelList() != null && channelTemp.getChannelList().size() > 0) {
				channel = InfoConfigUtil.translate(channelTemp, true);// 只初始化时使用true，其它时候用false
				channel.setVersion(channelTemp.getVersion());
			}
			Application.getInstance().setChannelList(channel);
			if (config != null) {
				InfoConfigUtil.WriteRemoteConfig(config);
			}
			if (channel != null) {
				InfoConfigUtil.WriteSubChannel(channel);
			}
		}
		channel = InfoConfigUtil.ReadSubChannel();
		if (SpUpdate.startFromWhat() != SpUpdate.START_FROM_NORMAL) {
			InfoConfigUtil.putChannelIdAndName(channel);
		}
		Application.getInstance().setChannelList(channel);
		NewsRemoteConfigHelper.getInstance().InitRemoteConfig();
		startPushService();
		long time2 = System.currentTimeMillis();
		long time = time2 - time1;
		SLog.v("LoadingActivity", "LoadingActivity总共加载耗时为：" + time + "ms");
		if (time < SPLASH_TIME) {
			int delay = (int) (SPLASH_TIME - time);
			mHandler.sendEmptyMessageDelayed(START_MSG, delay);
		} else {
			mHandler.sendEmptyMessage(START_MSG);
		}
	}

	private void startPushService() {
		try {
			// 启动时候判断是否接收push，如果接收push，启动service;否则不启动service
			SettingInfo settingInfo = SettingObservable.getInstance().getData();
			if (settingInfo.isIfPush()) {
				SLog.push("splash_startPushService", "splash_startPushService");
                PushUtil.startPushService(getApplicationContext(), PushUtil.valueUser);
			} else {
				WebDev.trackCustomEvent(SplashActivity.this, EventId.BOSS_PUSH_UN_START, "SplashActivity not start push service by NO PUSH setting");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private void startMainActivity() {

		switch (SpUpdate.startFromWhat()) {

		case SpUpdate.START_FROM_NEW_INSTALL:
			SLog.v("start", SLog.getTraceInfo() + "全新安装");

			// Statistics.getInstance().saveStatistics(Statistics.REPORTED_DATA_INSTALL_OR_UPDATE,
			// StatisticsUtil.generateCustomField(new String[] { "1", "" +
			// System.currentTimeMillis() / 1000 }));
			// Statistics.getInstance().reportAllInTime();

			WebDev.trackCustomEvent(this, EventId.BOSS_APP_INSTALL);

			start();
			break;
		case SpUpdate.START_FROM_UPDATE:
			SLog.v("start", SLog.getTraceInfo() + "更新");

			// Statistics.getInstance().saveStatistics(Statistics.REPORTED_DATA_INSTALL_OR_UPDATE,
			// StatisticsUtil.generateCustomField(new String[] { "0", "" +
			// System.currentTimeMillis() / 1000 }));
			// Statistics.getInstance().reportAllInTime();
			WebDev.trackCustomEvent(this, EventId.BOSS_APP_UPDATE);

			start();
			break;
		case SpUpdate.START_FROM_NORMAL:
			SLog.v("start", SLog.getTraceInfo() + "正常");
			
			WebDev.trackCustomEvent(this, EventId.BOSS_APP_NORMAL_START);
			
			Intent intent = new Intent();
			intent.setClass(SplashActivity.this, MainActivity.class);
			intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(intent);
			finish();
			overridePendingTransition(R.anim.push_left_in, R.anim.push_left_out);
			break;

		}
	}

	private void start() {
		FavorItemCache.getInstance().clearCache();
		
		TaskManager.startRunnableRequest(new Runnable() {

			@Override
			public void run() {
				SharedPrefManager.updataDeleteAll();
				File log = new File(Constants.LOG_PATH);
				FileUtil.delete(log, true);
				File allCache = new File(Constants.CACHE_DELTE_PATH);
				File delFile = new File(allCache.getPath() + System.currentTimeMillis() + "_del");
				allCache.renameTo(delFile);
				FileUtil.delete(delFile, true);
				System.gc();
			}
		});

		Intent intent = new Intent();
		intent.setClass(SplashActivity.this, GuideActivity.class);
		intent.putExtra("GuidFrom", "SplashActivity");
		startActivity(intent);
		finish();
		overridePendingTransition(R.anim.push_left_in, R.anim.push_left_out);
	}

	protected void quitActivity() {
		finish();
		overridePendingTransition(R.anim.push_right_in, R.anim.push_right_out);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			if (mHandler != null) {
				mHandler.removeMessages(START_MSG);
			}
//			Statistics.getInstance().refreshMap();
			quitActivity();
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	protected void onStop() {
//		Statistics.getInstance().refreshMap();
		super.onStop();
	}

	@Override
	protected void onDestroy() {
		if (mHandler != null) {
			mHandler.removeCallbacksAndMessages(null);
		}
//		Statistics.getInstance().reportAll();

		if (mDefaultLogo != null && !mDefaultLogo.isRecycled()) {
			mDefaultLogo.recycle();
			mDefaultLogo = null;
		}
		if (mDefaultBg != null && !mDefaultBg.isRecycled()) {
			mDefaultBg.recycle();
			mDefaultBg = null;
		}
		if (mDefaultFoot != null && !mDefaultFoot.isRecycled()) {
			mDefaultFoot.recycle();
			mDefaultFoot = null;
		}
		super.onDestroy();
	}

}
