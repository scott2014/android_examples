package com.tencent.news.ui;

import java.util.Properties;

import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;

import com.tencent.news.api.TencentNews;
import com.tencent.news.boss.EventId;
import com.tencent.news.cache.NewsDetailCache;
import com.tencent.news.cache.NewsDetailCache.CacheType;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.pojo.FullNewsDetail;
import com.tencent.news.system.AddCommentBroadcastReceiver;
import com.tencent.news.system.RefreshCommentNumBroadcastReceiver;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.news.utils.SLog;
import com.tencent.omg.webdev.WebDev;

public class MicroNewsDetailActivity extends AbsNewsActivity {
	
	private long viewStart;
	private long viewEnd;
	
	private String mId;
	private String mFrom;
	private String mBackType;

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
		viewStart = System.currentTimeMillis();
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
		viewEnd = System.currentTimeMillis();
		
		Properties p = new Properties(getPts());
		p.setProperty(EventId.KEY_VIEW_START, "" + viewStart);
		p.setProperty(EventId.KEY_VIEW_END, "" + viewEnd);
		WebDev.trackCustomEvent(this, EventId.BOSS_VIEW_DETAIL, p);
	}


	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		getIntentData(intent);
		getFullHtmlContent();
		if (receiver != null) {
			receiver.setComment_bar(mCommentView);
			receiver.setId(mId);
		}
		if (mRefreshCommentReceiver != null) {
			mRefreshCommentReceiver.setmWebView(mWebView);
			mRefreshCommentReceiver.setmItemId(mId);
		}
		SLog.i("PushNewsDetailActivity", "onNewIntent");
	}

	private void getFullHtmlContent() {
		WebDev.trackCustomBeginKVEvent(MicroNewsDetailActivity.this, EventId.ITIL_LOAD_DETAIL_TIME, getPts());
		HttpDataRequest request = TencentNews.getInstance().getQQNewsFullHtmlContent(mId, mFrom,mChild);
		TaskManager.startHttpDataRequset(request, this);
	}

	@Override
	protected void retryData() {
		// Auto-generated method stub
		getFullHtmlContent();
	}

	@Override
	protected void targetActivity() {
		// Auto-generated method stub
		if (mBackType.equals("0")) {
			quitActivity();
		} else {
			Intent intent = new Intent();
			intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			intent.setClass(this, MainActivity.class);
			startActivity(intent);
			quitActivity();
		}
	}

	@Override
	protected void getData() {
		Loading();
		getFullHtmlContent();
	}

	@Override
	protected boolean isInitComments() {
		// Auto-generated method stub
		return false;
	}

	@Override
	protected void registerBroadReceiver() {
		// Auto-generated method stub
		receiver = new AddCommentBroadcastReceiver(mCommentView, mId);
		registerReceiver(receiver, new IntentFilter(Constants.WRITE_SUCCESS_ACTION));

		mRefreshCommentReceiver = new RefreshCommentNumBroadcastReceiver(mId, null, mWebView, mWritingCommentView);
		registerReceiver(mRefreshCommentReceiver, new IntentFilter(Constants.REFRESH_COMMENT_NUMBER_ACTION));
	}

	@Override
	protected void getIntentData(Intent intent) {
		// Auto-generated method stub
		if (intent != null) {
			Uri data = intent.getData();
			mTitleText = "腾讯新闻";
			mId = data.getQueryParameter("nm");
			mChild = data.getQueryParameter("chlid");
			mFrom = data.getQueryParameter("from");
			mBackType = data.getQueryParameter("type");
			String isComment = data.getQueryParameter("iscomment");
			if (isComment != null && isComment.length() > 0) {
				mIsComment = Integer.parseInt(isComment);
				nCurrentPage = 1;
			} else {
				mIsComment = 0;
			}
			//mNewsDetailCache = new NewsDetailCache(mId);
			mNewsDetailCache = new NewsDetailCache(mId,CacheType.NEWS_CACHE);
		}
	}

	@Override
	public void onHttpRecvOK(HttpTag tag, Object result) {
		super.onHttpRecvOK(tag, result);
		if (tag.equals(HttpTag.FULL_HTML_CONTENT)) {
			
			Properties p = getPts();
			WebDev.trackCustomEndKVEvent(MicroNewsDetailActivity.this, EventId.ITIL_LOAD_DETAIL_TIME, p);
			Properties newp = new Properties(p);
			newp.setProperty(EventId.KEY_RESCODE, EventId.VALUE_RESCODE_SUCCESS);
			WebDev.trackCustomEvent(MicroNewsDetailActivity.this, EventId.ITIL_LOAD_DETAIL_TIME_RESULT, newp);
			
			
			FullNewsDetail detail = (FullNewsDetail) result;
			mItem = detail.getmItem();
			mWritingCommentView.setItem(mChild, mItem);
			mWritingCommentView.canWrite(false);
			mCommentView.init(mChild, mItem);
			mCommentView.setWritingCommentView(mWritingCommentView);

			Message msg = new Message();
			msg.obj = detail.getmDetail();
			mHandler.sendMessage(msg);
			mNewsDetailCache.setCacheDetailData(detail.getmDetail());
			mNewsDetailCache.saveNewsDetail();
		}
	}

	@Override
	public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {
		if (tag.equals(HttpTag.FULL_HTML_CONTENT)) {
			
			Properties p = getPts();
			WebDev.trackCustomEndKVEvent(MicroNewsDetailActivity.this, EventId.ITIL_LOAD_DETAIL_TIME, p);
			Properties newp = new Properties(p);
			newp.setProperty(EventId.KEY_RESCODE, EventId.VALUE_RESCODE_ERROR);
			WebDev.trackCustomEvent(MicroNewsDetailActivity.this, EventId.ITIL_LOAD_DETAIL_TIME_RESULT, newp);
			
			TipsToast.getInstance().showTipsError(msg);
			loadError();
		}
	}

	@Override
	protected void setSourceType() {
		// Auto-generated method stub
		mSourceType = WEIXIN_NEWS_DETAIL;
	}

	@Override
	protected String iAmWhich() {
		return mFrom;
	}
	
	@Override
	protected Properties getPts() {
		Properties pts = new Properties();
		pts.setProperty(EventId.KEY_NEWSID, mItem != null ? mItem.getId() : mId);
		pts.setProperty(EventId.KEY_CHANNELID, mChild);
		pts.setProperty(EventId.KEY_DETAILTYPE, iAmWhich());
		return pts;
	}
}
