
package com.tencent.news.ui;

import java.io.File;
import java.lang.ref.WeakReference;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.Display;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.boss.EventId;
import com.tencent.news.cache.UserDBHelper;
import com.tencent.news.config.Constants;
import com.tencent.news.download.DownloadConstants;
import com.tencent.news.download.OffLineDownloadManagerNew;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.push.PushService;
import com.tencent.news.push.PushUtil;
import com.tencent.news.shareprefrence.SpDraft;
import com.tencent.news.shareprefrence.SpForbidenCommentNews;
import com.tencent.news.shareprefrence.SpOffline;
import com.tencent.news.shareprefrence.SpOfflineOneChannelTime;
import com.tencent.news.shareprefrence.SpOfflineProgress;
import com.tencent.news.shareprefrence.SpSetting;
import com.tencent.news.system.Application;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.system.observer.SettingObserver;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.CheckUpdateView;
import com.tencent.news.ui.view.TextSizeDialog;
import com.tencent.news.utils.FileUtil;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.ThemeSettingsHelper;
import com.tencent.omg.webdev.WebDev;

@SuppressLint("ResourceAsColor")
public class SettingActivity extends BaseActivity implements OnClickListener, SettingObserver {

    private final static int SURE_CLEARCACHE = 1024;
    private final static int DIALOG_TEXTSIZE = 1025;
    private final static int DIALOG_CLEAR_CACHE_END = 1026;
    private final static int DIALOG_CLEAR_CACHE_NO_NEED = 1027;

    private RelativeLayout settingTitle = null;
    private RelativeLayout setting_page = null;
    private Button settingTitle_btn_back = null;
    private LinearLayout myAccount = null;
    private LinearLayout push = null;
    private LinearLayout autoLoad = null;
    private LinearLayout textMode = null;

    private View wordSize = null;
    private View clearCache = null;
    private View sendSuggestion = null;
    private CheckUpdateView checkUpdateView = null;
    private View apps = null;
    private View about = null;
    private LinearLayout update_check = null;
    private View tail = null;
    private ScrollView SettingScrollView = null;

    private NewsHandler mHandler = null;
    private SettingObservable settingObv;
    private SettingInfo settingData;
    private File allCache = new File(Constants.CACHE_DELTE_PATH);
    private float downX, downY, upX, upY;
    private int checkUpdateFlag = 0;

    private Context mContext = null;
    protected ThemeSettingsHelper themeSettingsHelper = null;

    private ImageView icon_account = null;
    private ImageView icon_account_unfold = null;

    private ImageView icon_push = null;
    private ImageView pushIcon = null;
    private int pushIconRValue;

    private ImageView icon_text_mode = null;
    private ImageView textModeIcon = null;
    private int textModeIconRValue;

    private ImageView icon_auto_load = null;
    private ImageView autoLoadIcon = null;
    private int autoLoadIconRValue;

    private ImageView icon_word_size = null;
    private ImageView icon_clear_cache = null;

    private ImageView icon_about = null;
    private ImageView icon_about_unfold = null;

    private ImageView icon_suggestion = null;
    private ImageView icon_suggestion_unfold = null;

    private ImageView icon_apps = null;
    private ImageView icon_apps_unfold = null;

    private TextView txtView_bar_title = null;
    private TextView txt_account = null;
    private TextView txtView_account = null;
    private TextView txt_setting = null;
    private TextView txtView_push = null;
    private TextView pushDescrip = null;
    private TextView txtView_text_mode = null;
    private TextView txtView_text_mode_extra = null;
    private TextView textModeDescription = null;
    private TextView txtView_autoload = null;
    private TextView autoLoadDescrip = null;
    private TextView txtView_word_size = null;
    private TextView wordSizeSummary = null;
    private TextView txtView_clear_cache = null;
    private TextView cacheDescrip = null;
    private TextView txt_app_info = null;
    private TextView txtView_about = null;
    private TextView txtView_suggestion = null;
    private TextView txtView_recomm = null;

    private View divider1 = null;
    private View divider2 = null;
    private View divider3 = null;
    private View divider4 = null;
    private View divider5 = null;
    private View divider6 = null;
    private View divider7 = null;
    private View divider8 = null;

    private View mMask;

    private static class NewsHandler extends Handler {
        private WeakReference<SettingActivity> mOuterClass;

        NewsHandler(SettingActivity view) {
            mOuterClass = new WeakReference<SettingActivity>(view);
        }

        @Override
        public void handleMessage(android.os.Message msg) {
            super.handleMessage(msg);
            SettingActivity mTheClass = mOuterClass.get();

            switch (msg.what) {
                case SURE_CLEARCACHE:
                    mTheClass.showDialog(SURE_CLEARCACHE);
                    break;
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting_new);

        settingObv = SettingObservable.getInstance();
        settingObv.registerObserver(this);

        mContext = Application.getInstance().getApplicationContext();
        themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(this);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null && bundle.containsKey(Constants.CHECK_UPDATE)) {
            checkUpdateFlag = bundle.getInt(Constants.CHECK_UPDATE);
            SLog.d("hj", "checkUpdateFlag: " + checkUpdateFlag);
        }

        initViews();
        initListener();
    }

    private void initViews() {
        mHandler = new NewsHandler(this);

        mMask = (View) findViewById(R.id.mask_view);

        setting_page = (RelativeLayout) findViewById(R.id.setting_page);
        settingTitle = (RelativeLayout) findViewById(R.id.settingTitle);
        settingTitle_btn_back = (Button) findViewById(R.id.settingTitle_btn_back);
        SettingScrollView = (ScrollView) findViewById(R.id.SettingScrollView);

        initLayoutViews();
        initIconViews();
        initTextViews();
        initDividerViews();

        if (Constants.IS_BETATESTING_APK) {// 如果是内部测试版apk,push需要关闭。将push设置隐藏，避免用户打开push
            push.setVisibility(View.GONE);
        }

        checkUpdateView = (CheckUpdateView) findViewById(R.id.check_update);

        // initViewsByMode();
        initViewsBySetting();
    }

    private void initTextViews() {
        txtView_bar_title = (TextView) findViewById(R.id.txtView_bar_title);
        txt_account = (TextView) findViewById(R.id.txt_account);
        txtView_account = (TextView) findViewById(R.id.txtView_account);
        txt_setting = (TextView) findViewById(R.id.txt_setting);
        txtView_push = (TextView) findViewById(R.id.txtView_push);
        pushDescrip = (TextView) findViewById(R.id.pushDescrip);
        txtView_text_mode = (TextView) findViewById(R.id.txtView_text_mode);
        txtView_text_mode_extra = (TextView) findViewById(R.id.txtView_text_mode_extra);
        textModeDescription = (TextView) findViewById(R.id.text_mode_desciption);
        txtView_autoload = (TextView) findViewById(R.id.txtView_autoload);
        autoLoadDescrip = (TextView) findViewById(R.id.auto_load_Descrip);
        txtView_word_size = (TextView) findViewById(R.id.txtView_word_size);
        wordSizeSummary = (TextView) findViewById(R.id.wordSizeSummary);
        txtView_clear_cache = (TextView) findViewById(R.id.txtView_clear_cache);
        cacheDescrip = (TextView) findViewById(R.id.cacheDescrip);
        txt_app_info = (TextView) findViewById(R.id.txt_app_info);
        txtView_about = (TextView) findViewById(R.id.txtView_about);
        txtView_suggestion = (TextView) findViewById(R.id.txtView_suggestion);
        txtView_recomm = (TextView) findViewById(R.id.txtView_recomm);
    }

    private void initIconViews() {
        icon_account = (ImageView) findViewById(R.id.icon_account);
        icon_account_unfold = (ImageView) findViewById(R.id.icon_account_unfold);

        icon_push = (ImageView) findViewById(R.id.icon_push);
        pushIcon = (ImageView) findViewById(R.id.pushIcon);
        pushIconRValue = R.drawable.setting_checked_bg;

        icon_text_mode = (ImageView) findViewById(R.id.icon_text_mode);
        textModeIcon = (ImageView) findViewById(R.id.text_mode_icon);
        textModeIconRValue = R.drawable.setting_unchecked_bg;

        icon_auto_load = (ImageView) findViewById(R.id.icon_auto_load);
        autoLoadIcon = (ImageView) findViewById(R.id.auto_load_Icon);
        autoLoadIconRValue = R.drawable.setting_checked_bg;

        icon_word_size = (ImageView) findViewById(R.id.icon_word_size);
        icon_clear_cache = (ImageView) findViewById(R.id.icon_clear_cache);

        icon_about = (ImageView) findViewById(R.id.icon_about);
        icon_about_unfold = (ImageView) findViewById(R.id.icon_about_unfold);

        icon_suggestion = (ImageView) findViewById(R.id.icon_suggestion);
        icon_suggestion_unfold = (ImageView) findViewById(R.id.icon_suggestion_unfold);

        icon_apps = (ImageView) findViewById(R.id.icon_apps);
        icon_apps_unfold = (ImageView) findViewById(R.id.icon_apps_unfold);
    }

    private void initDividerViews() {
        divider1 = (View) findViewById(R.id.divider1);
        divider2 = (View) findViewById(R.id.divider2);
        divider3 = (View) findViewById(R.id.divider3);
        divider4 = (View) findViewById(R.id.divider4);
        divider5 = (View) findViewById(R.id.divider5);
        divider6 = (View) findViewById(R.id.divider6);
        divider7 = (View) findViewById(R.id.divider7);
        divider8 = (View) findViewById(R.id.divider8);
    }

    private void initLayoutViews() {
        myAccount = (LinearLayout) findViewById(R.id.myAccount);
        push = (LinearLayout) findViewById(R.id.push);
        textMode = (LinearLayout) findViewById(R.id.text_mode);
        autoLoad = (LinearLayout) findViewById(R.id.auto_load);
        wordSize = findViewById(R.id.wordSize);
        clearCache = findViewById(R.id.clearCache);
        about = findViewById(R.id.about);
        update_check = (LinearLayout) findViewById(R.id.update_check);
        sendSuggestion = findViewById(R.id.sendSuggestion);
        apps = findViewById(R.id.apps);
        tail = (View) findViewById(R.id.tail);
    }

    private void initViewsByMode() {
        initFontByMode();
        initImageByMode();
        initBackgroundByMode();
        initDividerByMode();
        initSelectorByMode();
    }

    private void initFontByMode() {
        themeSettingsHelper.setTextViewColor(mContext, txtView_bar_title, R.color.menu_setting_title_color);

        if (themeSettingsHelper.isNightTheme()) {
            settingTitle_btn_back.setTextColor(Color.parseColor("#f0f4f8"));
        } else {
            settingTitle_btn_back.setTextColor(Color.parseColor("#ffffff"));
        }

        themeSettingsHelper.setTextViewColor(mContext, txt_account, R.color.list_setting_title_color);
        themeSettingsHelper.setTextViewColor(mContext, txt_setting, R.color.list_setting_title_color);
        themeSettingsHelper.setTextViewColor(mContext, txt_app_info, R.color.list_setting_title_color);

        themeSettingsHelper.setTextViewColor(mContext, txtView_account, R.color.list_title_color);
        themeSettingsHelper.setTextViewColor(mContext, txtView_push, R.color.list_title_color);
        themeSettingsHelper.setTextViewColor(mContext, txtView_text_mode, R.color.list_title_color);
        themeSettingsHelper.setTextViewColor(mContext, txtView_text_mode_extra, R.color.list_title_color);
        themeSettingsHelper.setTextViewColor(mContext, txtView_autoload, R.color.list_title_color);
        themeSettingsHelper.setTextViewColor(mContext, txtView_word_size, R.color.list_title_color);
        themeSettingsHelper.setTextViewColor(mContext, txtView_clear_cache, R.color.list_title_color);
        themeSettingsHelper.setTextViewColor(mContext, txtView_about, R.color.list_title_color);
        themeSettingsHelper.setTextViewColor(mContext, txtView_suggestion, R.color.list_title_color);
        themeSettingsHelper.setTextViewColor(mContext, txtView_recomm, R.color.list_title_color);

        themeSettingsHelper.setTextViewColor(mContext, pushDescrip, R.color.list_comment_color);
        themeSettingsHelper.setTextViewColor(mContext, textModeDescription, R.color.list_comment_color);
        themeSettingsHelper.setTextViewColor(mContext, autoLoadDescrip, R.color.list_comment_color);
        themeSettingsHelper.setTextViewColor(mContext, wordSizeSummary, R.color.list_comment_color);
        themeSettingsHelper.setTextViewColor(mContext, cacheDescrip, R.color.list_comment_color);
    }

    private void initImageByMode() {
        themeSettingsHelper.setImageViewSrc(mContext, icon_account, R.drawable.icon_setting_account);
        themeSettingsHelper.setImageViewSrc(mContext, icon_account_unfold, R.drawable.set_unfold);

        themeSettingsHelper.setImageViewSrc(mContext, icon_push, R.drawable.icon_setting_push);
        themeSettingsHelper.setImageViewSrc(mContext, pushIcon, pushIconRValue);

        themeSettingsHelper.setImageViewSrc(mContext, textModeIcon, textModeIconRValue);

        themeSettingsHelper.setImageViewSrc(mContext, icon_auto_load, R.drawable.icon_setting_auto);
        themeSettingsHelper.setImageViewSrc(mContext, autoLoadIcon, autoLoadIconRValue);

        themeSettingsHelper.setImageViewSrc(mContext, icon_word_size, R.drawable.icon_setting_wordsize);

        themeSettingsHelper.setImageViewSrc(mContext, icon_clear_cache, R.drawable.icon_setting_cache);

        themeSettingsHelper.setImageViewSrc(mContext, icon_about, R.drawable.icon_setting_about);
        themeSettingsHelper.setImageViewSrc(mContext, icon_about_unfold, R.drawable.set_unfold);

        themeSettingsHelper.setImageViewSrc(mContext, icon_suggestion, R.drawable.icon_setting_sugg);
        themeSettingsHelper.setImageViewSrc(mContext, icon_suggestion_unfold, R.drawable.set_unfold);

        themeSettingsHelper.setImageViewSrc(mContext, icon_apps, R.drawable.icon_setting_apps);
        themeSettingsHelper.setImageViewSrc(mContext, icon_apps_unfold, R.drawable.set_unfold);
    }

    private void initSelectorByMode() {
        if (themeSettingsHelper.isNightTheme()) {
            mySetBackground(myAccount, R.drawable.night_setting_selector);
            mySetBackground(push, R.drawable.night_setting_selector);
            mySetBackground(textMode, R.drawable.night_setting_selector);
            mySetBackground(autoLoad, R.drawable.night_setting_selector);
            mySetBackground(wordSize, R.drawable.night_setting_selector);
            mySetBackground(clearCache, R.drawable.night_setting_selector);
            mySetBackground(about, R.drawable.night_setting_selector);
            mySetBackground(checkUpdateView, R.drawable.night_setting_selector);
            mySetBackground(sendSuggestion, R.drawable.night_setting_selector);
            mySetBackground(apps, R.drawable.night_setting_selector);
        } else {
            mySetBackground(myAccount, R.drawable.setting_selector);
            mySetBackground(push, R.drawable.setting_selector);
            mySetBackground(textMode, R.drawable.setting_selector);
            mySetBackground(autoLoad, R.drawable.setting_selector);
            mySetBackground(wordSize, R.drawable.setting_selector);
            mySetBackground(clearCache, R.drawable.setting_selector);
            mySetBackground(about, R.drawable.setting_selector);
            mySetBackground(checkUpdateView, R.drawable.setting_selector);
            mySetBackground(sendSuggestion, R.drawable.setting_selector);
            mySetBackground(apps, R.drawable.setting_selector);
        }
    }

    private void initBackgroundByMode() {
        themeSettingsHelper.setViewBackgroudColor(mContext, setting_page, R.color.page_setting_bg_color);

        themeSettingsHelper.setViewBackgroud(mContext, settingTitle, R.drawable.title_bar_bg);
        themeSettingsHelper.setViewBackgroud(mContext, settingTitle_btn_back, R.drawable.title_back_btn);
        themeSettingsHelper.setViewBackgroud(mContext, tail, R.drawable.list_item_normal);
    }

    private void mySetBackground(View view, int id) {
        int bottom = view.getPaddingBottom();
        int top = view.getPaddingTop();
        int left = view.getPaddingLeft();
        int right = view.getPaddingRight();

        view.setBackgroundDrawable(getResources().getDrawable(id));

        view.setPadding(left, top, right, bottom);
    }

    private void initDividerByMode() {
        if (themeSettingsHelper.isNightTheme()) {
            mySetBackground(txt_account, R.drawable.night_setting_bar_bg);
            mySetBackground(txt_setting, R.drawable.night_setting_bar_bg);
            mySetBackground(txt_app_info, R.drawable.night_setting_bar_bg);
        } else {
            mySetBackground(txt_account, R.drawable.setting_bar_bg);
            mySetBackground(txt_setting, R.drawable.setting_bar_bg);
            mySetBackground(txt_app_info, R.drawable.setting_bar_bg);
        }

        themeSettingsHelper.setViewBackgroud(mContext, divider1, R.drawable.setting_divider_bg);
        themeSettingsHelper.setViewBackgroud(mContext, divider2, R.drawable.setting_divider_bg);
        themeSettingsHelper.setViewBackgroud(mContext, divider3, R.drawable.setting_divider_bg);
        themeSettingsHelper.setViewBackgroud(mContext, divider4, R.drawable.setting_divider_bg);
        themeSettingsHelper.setViewBackgroud(mContext, divider5, R.drawable.setting_divider_bg);
        themeSettingsHelper.setViewBackgroud(mContext, divider6, R.drawable.setting_divider_bg);
        themeSettingsHelper.setViewBackgroud(mContext, divider7, R.drawable.setting_divider_bg);
        themeSettingsHelper.setViewBackgroud(mContext, divider8, R.drawable.setting_divider_bg);
    }

    private void initViewsBySetting() {

        if (checkUpdateFlag == Constants.FROM_UPDATE_NOW) {
            SettingScrollView.post(new Runnable() {
                public void run() {

                    SettingScrollView.fullScroll(ScrollView.FOCUS_DOWN);
                }
            });
            checkUpdateView.start();
        } else if (checkUpdateFlag == Constants.FROM_SETTING) {

            SettingScrollView.post(new Runnable() {
                public void run() {

                    SettingScrollView.fullScroll(ScrollView.FOCUS_DOWN);
                }
            });
        }

        settingData = settingObv.getData();

        if (settingData.isIfPush()) {
            // pushIcon.setImageResource(R.drawable.setting_checked_bg);
            pushIconRValue = R.drawable.setting_checked_bg;
            themeSettingsHelper.setImageViewSrc(mContext, pushIcon, pushIconRValue);
            pushDescrip.setText(this.getResources().getString(R.string.push_open));
        } else {
            // pushIcon.setImageResource(R.drawable.setting_unchecked_bg);
            pushIconRValue = R.drawable.setting_unchecked_bg;
            themeSettingsHelper.setImageViewSrc(mContext, pushIcon, pushIconRValue);
            pushDescrip.setText(this.getResources().getString(R.string.push_close));
        }

        if (settingData.isIfAutoLoadMore()) {
            // autoLoadIcon.setImageResource(R.drawable.setting_checked_bg);
            autoLoadIconRValue = R.drawable.setting_checked_bg;
            themeSettingsHelper.setImageViewSrc(mContext, autoLoadIcon, autoLoadIconRValue);
            autoLoadDescrip.setText(this.getResources().getString(R.string.auto_load));
        } else {
            // autoLoadIcon.setImageResource(R.drawable.setting_unchecked_bg);
            autoLoadIconRValue = R.drawable.setting_unchecked_bg;
            themeSettingsHelper.setImageViewSrc(mContext, autoLoadIcon, autoLoadIconRValue);
            autoLoadDescrip.setText(this.getResources().getString(R.string.click_load));
        }

        if (settingData.isIfTextMode()) {
            // textModeIcon.setImageResource(R.drawable.setting_checked_bg);
            textModeIconRValue = R.drawable.setting_checked_bg;
            themeSettingsHelper.setImageViewSrc(mContext, textModeIcon, textModeIconRValue);
            textModeDescription.setText(this.getResources().getString(R.string.setting_text_mode_desciption_open));
        } else {
            // textModeIcon.setImageResource(R.drawable.setting_unchecked_bg);
            textModeIconRValue = R.drawable.setting_unchecked_bg;
            themeSettingsHelper.setImageViewSrc(mContext, textModeIcon, textModeIconRValue);
            textModeDescription.setText(this.getResources().getString(R.string.setting_text_mode_desciption_close));
        }

        if (settingData.getTextSize() == Constants.SETTING_MIN_TEXT_SIZE) {
            wordSizeSummary.setText(this.getResources().getString(R.string.word_size_s));
        } else if (settingData.getTextSize() == Constants.SETTING_MID_TEXT_SIZE) {
            wordSizeSummary.setText(this.getResources().getString(R.string.word_size_m));
        } else if (settingData.getTextSize() == Constants.SETTING_MAX_TEXT_SIZE) {
            wordSizeSummary.setText(this.getResources().getString(R.string.word_size_b));
        } else if (settingData.getTextSize() == Constants.SETTING_BIG_TEXT_SIZE) {
            wordSizeSummary.setText(this.getResources().getString(R.string.word_size_xb));
        } else {// 默认小号字,避免将来升级出问题
            wordSizeSummary.setText(this.getResources().getString(R.string.word_size_s));
        }
    }

    private void initListener() {
        settingTitle_btn_back.setOnClickListener(this);
        myAccount.setOnClickListener(this);
        push.setOnClickListener(this);
        pushIcon.setOnClickListener(this);
        autoLoad.setOnClickListener(this);
        autoLoadIcon.setOnClickListener(this);
        // text mode
        textMode.setOnClickListener(this);
        textModeIcon.setOnClickListener(this);
        // text mode
        wordSize.setOnClickListener(this);
        clearCache.setOnClickListener(this);
        sendSuggestion.setOnClickListener(this);
        apps.setOnClickListener(this);
        about.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        // SLog.v("SettingActivity",String.valueOf(getResources().getResourceEntryName(v.getId())));
        switch (v.getId()) {
            case R.id.settingTitle_btn_back:

                quitActivity();
                break;
            case R.id.myAccount:

                Intent myAccountIntent = new Intent();
                myAccountIntent.setClass(this, MyAccountActivity.class);
                this.startActivity(myAccountIntent);
                break;
            case R.id.push:
            case R.id.pushIcon:

                if (!settingData.isIfPush()) {
                    // pushIcon.setImageResource(R.drawable.setting_checked_bg);
                    pushIconRValue = R.drawable.setting_checked_bg;
                    themeSettingsHelper.setImageViewSrc(mContext, pushIcon, pushIconRValue);
                    pushDescrip.setText(this.getResources().getString(R.string.push_open));
                } else {
                    // pushIcon.setImageResource(R.drawable.setting_unchecked_bg);
                    pushIconRValue = R.drawable.setting_unchecked_bg;
                    themeSettingsHelper.setImageViewSrc(mContext, pushIcon, pushIconRValue);
                    pushDescrip.setText(this.getResources().getString(R.string.push_close));
                }
                settingData.setIfPush(!settingData.isIfPush());
                SpSetting.saveSetting(settingData);

                WebDev.trackCustomEvent(this, EventId.BOSS_SETTING_PUSH, new String[] {
                    settingObv.getData().isIfPush() ? "1" : "0"
                });

                // 增加处理service
                doPushService();
                break;
            case R.id.auto_load:
            case R.id.auto_load_Icon:

                if (settingData.isIfAutoLoadMore()) {
                    // autoLoadIcon.setImageResource(R.drawable.setting_checked_bg);
                    autoLoadIconRValue = R.drawable.setting_checked_bg;
                    themeSettingsHelper.setImageViewSrc(mContext, autoLoadIcon, autoLoadIconRValue);
                    autoLoadDescrip.setText(this.getResources().getString(R.string.auto_load));
                } else {
                    // autoLoadIcon.setImageResource(R.drawable.setting_unchecked_bg);
                    autoLoadIconRValue = R.drawable.setting_unchecked_bg;
                    themeSettingsHelper.setImageViewSrc(mContext, autoLoadIcon, autoLoadIconRValue);
                    autoLoadDescrip.setText(this.getResources().getString(R.string.click_load));
                }

                settingData.setIfAutoLoadMore(!settingData.isIfAutoLoadMore());
                settingObv.setData(settingData);

                WebDev.trackCustomEvent(this, EventId.BOSS_SETTING_AUTOLOAD, new String[] {
                    settingObv.getData().isIfAutoLoadMore() ? "1" : "0"
                });

                break;
            case R.id.text_mode:
            case R.id.text_mode_icon: {
                if (settingData.isIfTextMode()) {
                    // textModeIcon.setImageResource(R.drawable.setting_checked_bg);
                    textModeIconRValue = R.drawable.setting_checked_bg;
                    themeSettingsHelper.setImageViewSrc(mContext, textModeIcon, textModeIconRValue);
                    textModeDescription.setText(this.getResources().getString(R.string.setting_text_mode_desciption_open));
                } else {
                    // textModeIcon.setImageResource(R.drawable.setting_unchecked_bg);
                    textModeIconRValue = R.drawable.setting_unchecked_bg;
                    themeSettingsHelper.setImageViewSrc(mContext, textModeIcon, textModeIconRValue);
                    textModeDescription.setText(this.getResources().getString(R.string.setting_text_mode_desciption_close));
                }
                settingData.setIfTextMode(!settingData.isIfTextMode());
                settingObv.setData(settingData);

                WebDev.trackCustomEvent(this, EventId.BOSS_SETTING_TEXTMODE, new String[] {
                    settingObv.getData().isIfTextMode() ? "1" : "0"
                });

            }
                break;
            case R.id.wordSize:

                showDialog(DIALOG_TEXTSIZE);

                break;
            case R.id.clearCache:

                mHandler.sendEmptyMessage(SURE_CLEARCACHE);
                break;
            case R.id.sendSuggestion:

                Intent mIntent = new Intent();
                mIntent.setClass(this, SuggestActivity.class);
                this.startActivity(mIntent);
                break;
            case R.id.apps:

                Intent appsIntent = new Intent();
                appsIntent.setClass(this, HotAppListActivity.class);
                this.startActivity(appsIntent);
                break;
            case R.id.about:

                Intent aboutIntent = new Intent();
                aboutIntent.setClass(this, AboutActivity.class);
                this.startActivity(aboutIntent);
                break;
            default:
                break;
        }
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        Dialog dialog = null;
        switch (id) {
            case DIALOG_CLEAR_CACHE_END:
                AlertDialog endDialog = new AlertDialog.Builder(this)//
                        .setTitle(SettingActivity.this.getResources().getString(R.string.dialog_title))//
                        .setMessage(SettingActivity.this.getResources().getString(R.string.dialog_clean_finish))//
                        .setPositiveButton(SettingActivity.this.getResources().getString(R.string.dialog_ok),//
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dismissDialog(DIALOG_CLEAR_CACHE_END);
                                    }
                                }).create();
                dialog = endDialog;
                break;
            case DIALOG_CLEAR_CACHE_NO_NEED:
                AlertDialog noNeedDialog = new AlertDialog.Builder(this)//
                        .setTitle(SettingActivity.this.getResources().getString(R.string.dialog_title))//
                        .setMessage(SettingActivity.this.getResources().getString(R.string.dialog_clean_noneed))//
                        .setPositiveButton(SettingActivity.this.getResources().getString(R.string.dialog_ok),//
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dismissDialog(DIALOG_CLEAR_CACHE_NO_NEED);
                                    }
                                }).create();
                dialog = noNeedDialog;
                break;
            case SURE_CLEARCACHE:

                final AlertDialog iatDialog = new AlertDialog.Builder(this).setTitle(SettingActivity.this.getResources().getString(R.string.dialog_title))//
                        .setMessage(SettingActivity.this.getResources().getString(R.string.dialog_clean_info))//
                        .setPositiveButton(SettingActivity.this.getResources().getString(R.string.dialog_cancel),//
                                new DialogInterface.OnClickListener() {

                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                    }
                                })//
                        .setNegativeButton(SettingActivity.this.getResources().getString(R.string.dialog_clean_start),//
                                new DialogInterface.OnClickListener() {

                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        TaskManager.startRunnableRequest(new Runnable() {
                                            @Override
                                            public void run() {
                                                OffLineDownloadManagerNew.getInstance().getDownloadedData().clear();
                                                OffLineDownloadManagerNew.getInstance().setState(DownloadConstants.T_DOWNLOAD);
                                                OffLineDownloadManagerNew.getInstance().setClearCache(true);
                                                SpForbidenCommentNews.delAll();
                                                SpDraft.delAll();
                                                SpOffline.delAll();
                                                SpOfflineProgress.delAll();
                                                SpOfflineOneChannelTime.delAll();
                                                File delFile = new File(allCache.getPath() + System.currentTimeMillis() + "_del");
                                                allCache.renameTo(delFile);
                                                FileUtil.delete(delFile, true);
                                                Intent i = new Intent();
                                                i.setAction(Constants.CLEAR_CAHCE_ACTION);
                                                sendBroadcast(i);

                                                WebDev.trackCustomEvent(SettingActivity.this, EventId.BOSS_SETTING_CLEARCACHE);
                                            }
                                        });

                                        showDialog(DIALOG_CLEAR_CACHE_END);
                                    }
                                }).create();
                dialog = iatDialog;
                break;
            case DIALOG_TEXTSIZE:

                settingData = settingObv.getData();

                TextSizeDialog textsizeDialog = new TextSizeDialog(this, settingData, settingObv, R.style.alert_dialog);
                textsizeDialog.show();

                Window window = textsizeDialog.getWindow();
                WindowManager.LayoutParams layoutParams = window.getAttributes();
                Display d = getWindowManager().getDefaultDisplay();
                layoutParams.width = (int) (d.getWidth() * 0.83);
                window.setAttributes(layoutParams);

                dialog = textsizeDialog;

                break;
        }
        return dialog;
    }

    @Override
    public void updateSetting(SettingInfo setting) {
        if (UserDBHelper.getInstance().getUserInfo() != null) {
            setting.setUserInfo(UserDBHelper.getInstance().getUserInfo());
        }
        SpSetting.saveSetting(setting);
        // 先存再读取
        initViewsBySetting();
    }

    @Override
    protected void onPause() {

        if (UserDBHelper.getInstance().getUserInfo() != null) {
            settingData.setUserInfo(UserDBHelper.getInstance().getUserInfo());
        }
        SpSetting.saveSetting(settingData);
        super.onPause();
        WebDev.onPause(this);
    }

    @Override
    protected void onDestroy() {

        settingObv.removeObserver(this);

        super.onDestroy();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            quitActivity();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MENU) {
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void doPushService() {
        if (!settingData.isIfPush()) {
            Intent intent = new Intent(this, PushService.class);
            PushUtil.startPushService(getApplicationContext(), PushUtil.valueSettingOff);
        } else {
            PushUtil.startPushService(getApplicationContext(), PushUtil.valueSettingOn);
        }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        final float x = ev.getX();
        final float y = ev.getY();
        if (ev.getAction() == MotionEvent.ACTION_DOWN) {
            downX = x;
            downY = y;
        } else if (ev.getAction() == MotionEvent.ACTION_UP) {
            upX = x;
            upY = y;
            if (upX > downX && Math.abs(upX - downX) > MobileUtil.dpToPx(100) && Math.abs(upY - downY) / Math.abs(upX - downX) < 0.4) {
                quitActivity();
            }
        }
        return super.dispatchTouchEvent(ev);
    }

    @Override
    public void applyTheme() {
        initViewsByMode();
        themeSettingsHelper.setViewBackgroudColor(this, mMask, R.color.mask_page_color);
    }

    @Override
    protected void onResume() {
        super.onResume();
        WebDev.onResume(this);
    }

}
