package com.tencent.news.ui;

import java.net.URLDecoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.boss.EventId;
import com.tencent.news.config.Constants;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.model.pojo.SimpleNewsDetail;
import com.tencent.news.model.pojo.SinaAccountsInfo;
import com.tencent.news.shareprefrence.SpConfig;
import com.tencent.news.system.Application;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.news.ui.view.TitleBar;
import com.tencent.news.utils.SLog;
import com.tencent.omg.webdev.WebDev;

public class SinaOuthActivity extends BaseActivity {
	public static final int SETTING_ACCOUNTS = 0x201;
	public static final int SHARE_LIST = 0x202;
	private TitleBar mTitleBar;
	private WebView mWebView;
	private LinearLayout mLoadingLayout;
	private Item mItem;
	private SimpleNewsDetail mNewsDetail;
	private int mFrom;
	private SinaAccountsInfo mInfo;
	private String TAG = "TAGSinaOuthActivity";
	private Boolean shouldOverrideUrlLoading = false;
	private Pattern pattern = Pattern.compile("(^[sS][mM][sS])[:：](\\d+$)");
	private View mMask;
	private View webviewMask;
	private ImageView mLoadingIcon;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.sina_outh_layout);
		getIntentData(getIntent());
		initView();
		initListener();
	}

	@SuppressLint("SetJavaScriptEnabled")
	private void initView() {
		webviewMask = (View) findViewById(R.id.web_detail_mask_view);
		mMask = (View) findViewById(R.id.mask_view);
		mLoadingIcon = (ImageView) findViewById(R.id.sina_loading_icon);
		mTitleBar = (TitleBar) findViewById(R.id.sina_title_bar);
		mTitleBar.setBackName("返回");
		mWebView = (WebView) findViewById(R.id.sina_outh_webview);
		mLoadingLayout = (LinearLayout) findViewById(R.id.sina_outh_loading);
		mTitleBar.ShowSinaBar(R.string.sina_outh_title);
		mWebView.getSettings().setSavePassword(false);
		mWebView.getSettings().setJavaScriptEnabled(true);
		mWebView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
		mWebView.loadUrl(TencentNews.WRITE_BASE_URL + "sinaLogin");
		loading();
	}

	private void loading() {
		mLoadingLayout.setVisibility(View.VISIBLE);
		mWebView.setVisibility(View.GONE);
	}

	private void loadComplete() {
		mLoadingLayout.setVisibility(View.GONE);
		mWebView.setVisibility(View.VISIBLE);
		themeSettingsHelper.setViewBackgroudColor(this, webviewMask, R.color.mask_webview_color);
	}

	private void getIntentData(Intent intent) {
		if (intent != null) {
			mNewsDetail = (SimpleNewsDetail) intent.getSerializableExtra(Constants.NEWS_SHARE_CONTENT);
			mItem = (Item) intent.getSerializableExtra(Constants.NEWS_SHARE_ITEM);
			mFrom = intent.getIntExtra(Constants.SINA_LOGIN_FROM, SHARE_LIST);
		}
	}

	private void parseAccountsInfo(String url) {
		mInfo = new SinaAccountsInfo();
		if (url != null && url.length() > 0) {
			int n = url.indexOf("?");
			url = url.substring(n + 1, url.length());
			String subDatas[] = url.split("&");
			for (int i = 0; i < subDatas.length; i++) {
				String data = subDatas[i].trim();
				String str[] = data.split("=");
				if (data.startsWith("access_token")) {
					mInfo.setToken(str[1]);
				} else if (data.startsWith("expires_in")) {
					long time = System.currentTimeMillis() / 1000;
					long gap = (str[1] != null && str[1].length() > 0) ? Long.parseLong(str[1]) : 0;
					mInfo.setExpires(gap + time);
				}
			}
		}
		try {
			CookieSyncManager.createInstance(SinaOuthActivity.this);
			CookieManager cookieManager = CookieManager.getInstance();
			String cookie = URLDecoder.decode(cookieManager.getCookie("inews.qq.com"));
			SLog.v("SinaOuthActivity", cookie);
			if (cookie != null && cookie.length() > 0) {
				String subDatas[] = cookie.split(";");
				for (int i = 0; i < subDatas.length; i++) {
					String data = subDatas[i].trim();
					String str[] = data.split("=");
					SLog.v("SinaOuthActivity", "data=" + data + "str=" + str[1]);
					if (data.startsWith("sina_id")) {
						mInfo.setSina_id(str[1]);
					} else if (data.startsWith("sina_screen_name")) {
						mInfo.setSina_screen_name(str[1]);
					} else if (data.startsWith("sina_name")) {
						mInfo.setSina_name(str[1]);
					} else if (data.startsWith("sina_domain")) {
						mInfo.setSina_domain(str[1]);
					} else if (data.startsWith("sina_profile_image_url")) {
						mInfo.setSina_profile_image_url(str[1]);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			SLog.v("SinaOuthActivity", mInfo.toString());
			if (mInfo != null) {
				SpConfig.setSinaAccountInfo(mInfo);
				TipsToast.getInstance().showTipsSuccess("登录成功!");
				Intent mIntent = new Intent("SinaBack");
                //SLog.v("lvxn","sendbroadcast");
				sendBroadcast(mIntent);
			}	
		}
	}

	private void initListener() {
		mTitleBar.setBackClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Application.getInstance().hideSoftInputFromWindow(mWebView.getWindowToken());
				quitActivity();
			}

		});

		mWebView.setWebChromeClient(new WebChromeClient() {
			public void onProgressChanged(WebView view, int progress) {
				if (progress >= 100) {
					loadComplete();
					mWebView.requestFocus();
				}
			}
		});

		mWebView.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView view, String url, Bitmap favicon) {
				SLog.v(TAG, "onPageStarted:" + url);
				super.onPageStarted(view, url, favicon);
				if (url.startsWith("http://inews.qq.com/sinaNews.png")) {
					shouldOverrideUrlLoading(view, url);
					shouldOverrideUrlLoading = true;
				}

			}

			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				// 发送短信注册
				Matcher matcher = pattern.matcher(url);
				if (matcher.find()) {
					int i = matcher.groupCount();
					String toPhone = matcher.group(2);
					Uri uri = Uri.parse("smsto:" + toPhone);
					Intent it = new Intent(Intent.ACTION_SENDTO, uri);
					startActivity(it);
					return true;
				}

				SLog.v(TAG, "shouldOverrideUrlLoading:" + url);
				if (shouldOverrideUrlLoading) {
					shouldOverrideUrlLoading = false;
					return true;
				}
				if (url.startsWith("http://inews.qq.com/sinaNews.png")) {
					parseAccountsInfo(url);
					if (mFrom == SHARE_LIST) {
						Intent intent = new Intent();
						intent.setClass(SinaOuthActivity.this, ShareInterfaceActivity.class);
						intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						intent.putExtra(Constants.NEWS_SHARE_CONTENT, mNewsDetail);
						intent.putExtra(Constants.NEWS_SHARE_ITEM, mItem);
						intent.putExtra(Constants.NEWS_SHARE_TYPE, ShareInterfaceActivity.SINA_WEIBO);
						startActivity(intent);
						SinaOuthActivity.this.finish();
						
						WebDev.trackCustomEvent(SinaOuthActivity.this, EventId.BOSS_SETTING_LOGINFROM_SHARE_SINAWB);
						
					} else {
						Intent intent = new Intent();
						intent.putExtra(Constants.SINA_ACCOUNTS_INFO, mInfo);
						setResult(RESULT_OK, intent);
						SinaOuthActivity.this.finish();
						
						WebDev.trackCustomEvent(SinaOuthActivity.this, EventId.BOSS_SETTING_LOGINFROM_MYACC_SINAWB);
					}

				} else {
					view.loadUrl(url);
				}
				return true;
			}

			@Override
			public void onPageFinished(WebView view, String url) {
				SLog.v(TAG, "onPageFinished:" + url);
				super.onPageFinished(view, url);

			}

			@Override
			public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
				super.onReceivedError(view, errorCode, description, failingUrl);
				if (errorCode != -10) {
					mWebView.loadUrl("file:///android_asset/error.html");
				}
				loadComplete();
			}

		});
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
			quitActivity();
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_MENU) {
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public void applyTheme() {
		// Auto-generated method stub
		mTitleBar.applyTitleBarTheme(this);
		themeSettingsHelper.setViewBackgroudColor(this, mWebView, R.color.page_setting_bg_color);
		themeSettingsHelper.setViewBackgroudColor(this, mMask, R.color.mask_page_color);
		themeSettingsHelper.setViewBackgroudColor(this, this.mLoadingLayout, R.color.sina_outh_loading_color);
		themeSettingsHelper.setImageViewSrc(this, mLoadingIcon, R.drawable.news_loading_icon);
	}

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}
}
