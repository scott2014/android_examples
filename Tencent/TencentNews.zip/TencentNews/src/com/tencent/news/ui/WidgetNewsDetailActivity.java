package com.tencent.news.ui;

import java.util.Properties;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;

import com.tencent.news.boss.EventId;
import com.tencent.news.cache.NewsDetailCache;
import com.tencent.news.config.Constants;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.system.AddCommentBroadcastReceiver;
import com.tencent.news.system.RefreshCommentNumBroadcastReceiver;
import com.tencent.news.utils.SLog;
import com.tencent.omg.webdev.WebDev;

public class WidgetNewsDetailActivity extends AbsNewsActivity {

	private long viewStart;
	private long viewEnd;
	
	
	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
		viewStart = System.currentTimeMillis();
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
		viewEnd = System.currentTimeMillis();
		
		Properties p = new Properties(getPts());
		p.setProperty(EventId.KEY_VIEW_START, "" + viewStart);
		p.setProperty(EventId.KEY_VIEW_END, "" + viewEnd);
		WebDev.trackCustomEvent(this, EventId.BOSS_VIEW_DETAIL, p);
	}

	@Override
	protected void retryData() {
		//  Auto-generated method stub
		getQQnewsContentData();
	}

	@Override
	protected void targetActivity() {
		// TODO Auto-generated method stub
		quitActivity();
	}

	@Override
	protected void getData() {
		// TODO Auto-generated method stub
		getQQnewsContentData();
	}

	@Override
	protected boolean isInitComments() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	protected void registerBroadReceiver() {
		// TODO Auto-generated method stub
		receiver = new AddCommentBroadcastReceiver(mCommentView, mItem.getId());
		registerReceiver(receiver, new IntentFilter(Constants.WRITE_SUCCESS_ACTION));

		mRefreshCommentReceiver = new RefreshCommentNumBroadcastReceiver(mItem.getId(), null, mWebView, mWritingCommentView);
		registerReceiver(mRefreshCommentReceiver, new IntentFilter(Constants.REFRESH_COMMENT_NUMBER_ACTION));
	}

	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		getIntentData(intent);
		getQQnewsContentData();
		SLog.i("PushNewsDetailActivity", "onNewIntent");
	}

	@Override
	protected void getIntentData(Intent intent) {
		//  Auto-generated method stub
		if (intent != null) {
			Bundle bundle = intent.getExtras();
			mItem = (Item) bundle.getSerializable(Constants.NEWS_DETAIL_KEY);
			mChild = bundle.getString(Constants.NEWS_CHANNEL_CHLID_KEY);
			mTitleText = bundle.getString(Constants.NEWS_DETAIL_TITLE_KEY);
			isSpecial = bundle.getBoolean(Constants.IS_SPECIAL_KEY);
			mNewsDetailCache = new NewsDetailCache(mItem);
		}
	}

	@Override
	protected void setSourceType() {
		// TODO Auto-generated method stub
		mSourceType = WIDGET_NEWS_DETAIL;
	}

	@Override
	protected String iAmWhich() {
		//  Auto-generated method stub
		return "widget";
	}

	@Override
	protected Properties getPts() {
		Properties pts = new Properties();
		pts.setProperty(EventId.KEY_NEWSID, mItem != null ? mItem.getId() : "");
		pts.setProperty(EventId.KEY_CHANNELID, mChild);
		pts.setProperty(EventId.KEY_DETAILTYPE, iAmWhich());
		return pts;
	}

}
