package com.tencent.news.ui.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.tencent.news.R;
import com.tencent.news.system.NetStatusReceiver;
import com.tencent.news.ui.view.CommentListView;
import com.tencent.news.ui.view.TipsToast;

public class MyCommentFragment extends BaseFragment{
	private View MyCommentView = null;	
	private CommentListView mCommentListView;
	//private TextView commentViewTips = null;
	//private RelativeLayout mCommentViewRoot = null;
	//private ImageView mClickLoadComment = null;	 
	//private Context appContext;
	
	public static MyCommentFragment newInstance() {
		MyCommentFragment f = new MyCommentFragment();
        return f;
    }
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
	
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
		//appContext = Application.getInstance().getApplicationContext();
		MyCommentView = inflater.inflate(R.layout.view_mycomment, container, false);					
		mCommentListView = (CommentListView) MyCommentView.findViewById(R.id.comment_list);
		//mCommentViewRoot = (RelativeLayout) MyCommentView.findViewById(R.id.comment_layout);
		//commentViewTips = (TextView) MyCommentView.findViewById(R.id.commentViewTips);
		//mClickLoadComment = (ImageView) MyCommentView.findViewById(R.id.offline_download_comment);
		applyTheme();
        return MyCommentView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_INAVAILABLE) {			
			TipsToast.getInstance().showTipsWarning(getResources().getString(R.string.string_http_data_nonet));
		}else{
			mCommentListView.getMyComments("","",1);
		}
    }

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}
    
	public void applyTheme() {
        mCommentListView.applyTheme();
    }
}
