package com.tencent.news.ui.view;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.tencent.news.R;
import com.tencent.news.boss.EventId;
import com.tencent.news.cache.FavorDbItem;
import com.tencent.news.cache.FavorItemCache;
import com.tencent.news.cache.FavorSyncHelper;
import com.tencent.news.cache.NewsDetailCache;
import com.tencent.news.cache.NewsDetailCache.CacheType;
import com.tencent.news.cache.RssChannelSyncHelper;
import com.tencent.news.cache.UserDBHelper;
import com.tencent.news.command.GetImageResponse;
import com.tencent.news.config.Constants;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.model.pojo.RssCatListItem;
import com.tencent.news.model.pojo.Share;
import com.tencent.news.model.pojo.SimpleNewsDetail;
import com.tencent.news.model.pojo.SinaAccountsInfo;
import com.tencent.news.model.pojo.VideoValue;
import com.tencent.news.shareprefrence.SpConfig;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.ui.ChatActivity;
import com.tencent.news.ui.LoginActivity;
import com.tencent.news.ui.MobleQQActivity;
import com.tencent.news.ui.RssMediaActivity;
import com.tencent.news.ui.RssMediaHistoryActivity;
import com.tencent.news.ui.ShareInterfaceActivity;
import com.tencent.news.ui.SinaOuthActivity;
import com.tencent.news.ui.adapter.ShareListAdapter;
import com.tencent.news.utils.ThemeSettingsHelper;
import com.tencent.news.wxapi.WXEntryActivity;
import com.tencent.omg.webdev.WebDev;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

public class ShareDialog implements OnDismissListener, GetImageResponse {

	public static final int SHARE_NORMAL_DETAIL = 0;
	public static final int SHARE_MEDIA_DETAIL = 2;
	public static final int SHARE_NORMAL_DETAIL_NIGHT = 1;
	public static final int SHARE_MEDIA_DETAIL_NIGHT = 4;

	private static final int SHARE_TO_SINA = 0;
	private static final int SHARE_TO_QZONE = 1;
	private static final int SHARE_TO_QQWEIBO = 2;
	private static final int SHARE_TO_WEIXIN = 4;
	private static final int SHARE_TO_FRIENDS = 8;
	private static final int SHARE_TO_MOBLEQQ = 16;
	private static final int SHARE_TO_FAVOR_ADD = 9;
	private static final int SHARE_TO_FAVOR_DEL = 10;
	private static final int SHARE_TO_MEDIA = 32;
	private static final int SHARE_TO_CHAT = 64;

	private static ShareDialog mPopupShare = new ShareDialog();
	private Context ctx;
	private static ArrayList<Share> groupList;
	private RelativeLayout mLinearLayout;
	private GridView shareListView;
	private ImageView share_cut_event;
	private Button share_cancel;
	private ShareListAdapter groupAdapter;
	Dialog dlg;
	private ShareDismissListener mListener;

	private Item newsItem;
	private SimpleNewsDetail newsDetail;
	private String imageUrl;
	private String vid;
	private String openFrom = null;

	private String specialReportIntro;
	private String specialReportTitle;

	private int doWhat;
	private String channelId;
	protected ThemeSettingsHelper themeSettingsHelper = null;
	
	private ShareDialog() {

	}

	public static ShareDialog getInstance() {
		return mPopupShare;
	}

	public String getSpecialReportIntro() {
		return specialReportIntro;
	}

	public String getSpecialReportTitle() {
		return specialReportTitle;
	}

	public String getOpenFrom() {
        return openFrom;
    }

    public void setOpenFrom(String openFrom) {
        this.openFrom = openFrom;
    }

    public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
//		GetImageRequest request = new GetImageRequest();
//		request.setGzip(false);
//		request.setTag(System.currentTimeMillis());
//		request.setUrl(imageUrl);
//		TaskManager.startSmallImageTask(request, this);
	}

	public SimpleNewsDetail getNewsDetail() {
		return newsDetail;
	}

	public void setNewsDetail(SimpleNewsDetail newsDetail) {
		this.newsDetail = newsDetail;
	}

	public Item getNewsItem() {
		return newsItem;
	}

	public void setNewsItem(Item newsItem) {
		this.newsItem = newsItem;
	}

	public void setParams(String imageUrl, String vid, SimpleNewsDetail newsDetail, Item newsItem, String channelId) {
		this.imageUrl = imageUrl;
		this.vid = vid;
		this.newsDetail = newsDetail;
		this.newsItem = newsItem;
		this.setChannelId(channelId);
	}

	public void setSpecialReportParams(String specialReportTitle, String specialReportIntro, Item newsItem, String channelId) {
		this.specialReportTitle = specialReportTitle;
		this.specialReportIntro = specialReportIntro;
		this.newsItem = newsItem;
		this.channelId = channelId;
		if (newsItem.getThumbnails_qqnews() != null && newsItem.getThumbnails_qqnews().length > 0) {
			this.imageUrl = newsItem.getThumbnails_qqnews()[0];
		} else {
			this.imageUrl = "";
		}
	}

	public Dialog showAlert(final Context context, final int popType) {
		if (context instanceof Activity && ((Activity) context).isFinishing()) {
			return null;
		}
		int type = popType;
		groupList = new ArrayList<Share>();
		groupList.clear();

        addFavorBtn();
        addMediaBtn();
		groupList.add(new Share(SHARE_TO_QQWEIBO, R.drawable.share_weibo_icon, "腾讯微博"));
		groupList.add(new Share(SHARE_TO_QZONE, R.drawable.share_qzone_icon, "QQ空间"));
		groupList.add(new Share(SHARE_TO_SINA, R.drawable.share_sina_icon, "新浪微博"));
		groupList.add(new Share(SHARE_TO_FRIENDS, R.drawable.share_friends_icon, "微信朋友"));
		groupList.add(new Share(SHARE_TO_WEIXIN, R.drawable.share_weixin_icon, "微信好友"));
		groupList.add(new Share(SHARE_TO_MOBLEQQ, R.drawable.share_qq_icon, "手机QQ"));
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(context);	
		if(themeSettingsHelper.isNightTheme()){
			type = SHARE_NORMAL_DETAIL_NIGHT;
		}
		if (dlg != null) {
			dismiss();
		}
		if (dlg == null) {
			dlg = new Dialog(context, R.style.MMTheme_DataSheet);
		}
		
		LayoutInflater inflate = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		switch (type) {
		case SHARE_MEDIA_DETAIL:
		case SHARE_NORMAL_DETAIL_NIGHT:
			mLinearLayout = (RelativeLayout) inflate.inflate(R.layout.view_share_list_black, null);
			break;
		case SHARE_NORMAL_DETAIL:
		default:
			mLinearLayout = (RelativeLayout) inflate.inflate(R.layout.view_share_list_normal, null);
			break;
		}
		mLinearLayout.setMinimumWidth(10000);
		dlg.setContentView(mLinearLayout);

		share_cut_event = (ImageView) mLinearLayout.findViewById(R.id.share_cut_event);
		share_cancel = (Button) mLinearLayout.findViewById(R.id.share_cancel);
		shareListView = (GridView) mLinearLayout.findViewById(R.id.share_grid);
		groupAdapter = new ShareListAdapter(context, shareListView);
		groupAdapter.setAppList(groupList);
		shareListView.setAdapter(groupAdapter);
		shareClick();

		Window w = dlg.getWindow();
		WindowManager.LayoutParams lp = w.getAttributes();
		lp.x = 0;
		final int cMakeBottom = -1000;
		lp.y = cMakeBottom;
		lp.width = WindowManager.LayoutParams.FILL_PARENT;
		lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
		lp.gravity = Gravity.BOTTOM;
		dlg.onWindowAttributesChanged(lp);
		dlg.setCancelable(true);
		dlg.setCanceledOnTouchOutside(true);
		dlg.setOnDismissListener(this);

		if (context instanceof Activity && !((Activity) context).isFinishing()) {
			try{
				dlg.show();
			}catch (Exception e){
				e.printStackTrace();
			}
		}

		return dlg;
	}
	
	private void addMediaBtn() {
        if (newsItem.getArticletype().equals("100") || newsItem.getArticletype().equals("7")
                || newsDetail == null) {// 专题列表、图文直播
            return;
        }
	    RssCatListItem card = newsDetail.getCard();
        if (card != null) {
            if (!RssMediaHistoryActivity.SUB_CLASS_NAME.equals(openFrom)) {
                groupList.add(new Share(SHARE_TO_MEDIA, R.drawable.share_media_icon, "查看媒体信息"));
            }

            if (card.getUin() != null
                && card.getUin().length() > 0
                && RssChannelSyncHelper.getInstance().isBookedChannel(card.getChlid())) {
                groupList.add(new Share(SHARE_TO_CHAT, R.drawable.share_chat_icon, "给作者留言"));
            }
        }
	}
	
	private void addFavorBtn() {
        boolean toFavor=true;
        if(newsDetail==null){
        	return;//没有底层页信息
        }
        if(newsItem.getArticletype().equals("100") || newsItem.getArticletype().equals("7")){//专题列表、图文直播 不可收藏
            toFavor=false;
        }else{
            TreeMap<String, Object> attribute = newsDetail.getAttribute();
            Iterator<?> keyIter = attribute.entrySet().iterator();
            while (keyIter.hasNext()) {
                @SuppressWarnings("unchecked")
                Map.Entry<String, Object> entry = (Map.Entry<String,Object>) keyIter.next();
                String key = (String) entry.getKey();
                if (key.indexOf("VIDEO") > -1 && attribute.containsKey(key)) {
                    VideoValue vValue = (VideoValue) attribute.get(key);
                    if("2".equals(vValue.getVideoSourceType())){
                        toFavor=false;//视频直播 不可收藏
                        break;
                    }
                }
            }
        }
        
        //订阅不可收藏判断
        if(toFavor){
            if(FavorSyncHelper.getInstance().isFavor(newsItem.getId(), 0)){
                groupList.add(new Share(SHARE_TO_FAVOR_DEL, R.drawable.set_collect_cancel_icon, "取消收藏"));
            }else{
                groupList.add(new Share(SHARE_TO_FAVOR_ADD, R.drawable.set_collect_icon, "收藏"));
            }
        }
	}

	/**
	 * 显示分享渠道popupwindow
	 * 
	 * @param ctx
	 * @param popType
	 * @param eventComeFrom
	 */
	public void showShareList(Context ctx, int popType, View eventComeFrom) {

		this.ctx = ctx;

		showAlert(ctx, popType);

	}

	public boolean isShowing() {
		if (dlg != null) {
			return dlg.isShowing();
		} else {
			return false;
		}
	}

	public void dismiss() {
		if (dlg != null) {
			dlg.hide();
			dlg.cancel();
			dlg.dismiss();
			dlg = null;
		}
	}

	private void shareClick() {

		share_cancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				dismiss();
			}
		});
		share_cut_event.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				dismiss();
			}
		});

		shareListView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

				switch (groupList.get(position).getId()) {
				case SHARE_TO_SINA:
					long mCurrTime = System.currentTimeMillis() / 1000;
					SinaAccountsInfo info = SpConfig.getSinaAccountInfo();
					if (info != null && mCurrTime <= info.getExpires()) {
						Intent intent = new Intent();
						intent.setClass(ctx, ShareInterfaceActivity.class);
						intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						intent.putExtra(Constants.NEWS_SHARE_TYPE, ShareInterfaceActivity.SINA_WEIBO);
						ctx.startActivity(intent);
					} else {
						Intent intent = new Intent();
						intent.setClass(ctx, SinaOuthActivity.class);
						intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						intent.putExtra(Constants.SINA_LOGIN_FROM, SinaOuthActivity.SHARE_LIST);
						intent.putExtra(Constants.NEWS_SHARE_TYPE, ShareInterfaceActivity.SINA_WEIBO);
						ctx.startActivity(intent);
					}
					break;
				case SHARE_TO_QZONE:
				case SHARE_TO_QQWEIBO:

					startTencentShare(groupList.get(position).getId());

					break;
				case SHARE_TO_WEIXIN:
					doWhat = WXEntryActivity.WEIXIN;
					sendWeiXin(doWhat);
					break;
				case SHARE_TO_FRIENDS:
					// if (SpConfig.loadWXSendAuthResp() != null) {
					// Intent intent = new Intent();
					// intent.setClass(ctx, ShareInterfaceActivity.class);
					// intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					// intent.putExtra(Constants.NEWS_SHARE_TYPE,
					// ShareInterfaceActivity.WECHAT_FRIEND_ZONE);
					// ctx.startActivity(intent);
					// } else {
					doWhat = WXEntryActivity.FRIENDS_ZONE;
					sendWeiXin(doWhat);
					// }
					break;
				case SHARE_TO_MOBLEQQ:
				    sendMobleQQ();
					break;
				case SHARE_TO_FAVOR_ADD:
					favor(true);//收藏
					break;
				case SHARE_TO_FAVOR_DEL:
					favor(false);//取消收藏
					break;
				case SHARE_TO_MEDIA:
				    shareToMedia();
				    break;
				case SHARE_TO_CHAT:
				    shareToChat();
				    break;
				default:
					break;
				}
				dismiss();
			}

		});
	}
	
	private void sendMobleQQ(){
	    Intent intent = new Intent();
	    intent.setClass(ctx, MobleQQActivity.class);
	    ctx.startActivity(intent);
	}

	/**
	 * 
	 * @param isAdd true-收藏 false-取消收藏
	 */
	private void favor(boolean isAdd){
	    
        Intent intent = new Intent();

		if(isAdd){
			
			WebDev.trackCustomEvent(ctx, EventId.BOSS_FAVORITES_CLICK_COLLECT_BTN, ""+newsItem.getId());
			
			FavorDbItem item=FavorSyncHelper.getInstance().addFavor(newsItem.getId(), 0);
			newsItem.setFavorSource("0");
			newsItem.setFavorTimestamp(String.valueOf(item.timestamp));
			String newsid=newsItem.getId();
			newsItem.setId(FavorSyncHelper.getInstance().translateId(newsItem.getId()));
			FavorItemCache.getInstance().writeToCache(newsItem.getId(), newsItem);
			
			NewsDetailCache mNewsDetailCache = new NewsDetailCache(newsItem.getId(),CacheType.FAVOR_CACHE);
			mNewsDetailCache.setCacheDetailData(newsDetail);
			mNewsDetailCache.saveNewsDetail();
			intent.putExtra(Constants.FAVOR_LIST_ITEM, newsItem);
			TipsToast.getInstance().showTipsSuccess("收藏成功");
			newsItem.setId(newsid);
		}else{
			
			WebDev.trackCustomEvent(ctx, EventId.BOSS_FAVORITES_CLICK_UN_COLLECT_BTN, ""+newsItem.getId());
			
			String newsid=FavorSyncHelper.getInstance().translateId(newsItem.getId());
			FavorSyncHelper.getInstance().delFavor(newsid, 0);
			FavorItemCache.getInstance().clearCache(newsid);
			TipsToast.getInstance().showTipsSuccess("收藏已取消");
		}
        intent.setAction(Constants.FAVOR_LIST_REFRESH_ACTION);
        intent.putExtra(Constants.FAVOR_LIST_REFRESH_ID, FavorSyncHelper.getInstance().translateId(newsItem.getId()));
        intent.putExtra(Constants.FAVOR_LIST_OP_TYPE, isAdd);
        ctx.sendBroadcast(intent);
	}
	
	private void shareToMedia() {
        RssCatListItem card = newsDetail.getCard();
        RssCatListItem rssChannelListItem = new RssCatListItem();
        rssChannelListItem.setChlid(card.getChlid());
        rssChannelListItem.setChlname(card.getChlname());
        rssChannelListItem.setUin(card.getUin());
        rssChannelListItem.setEmpty(true);
        Intent intent = new Intent();
        Bundle bundle = new Bundle();
        bundle.putSerializable(RssMediaActivity.RSS_MEDIA_ITEM, rssChannelListItem);
        intent.putExtras(bundle);
        intent.setClass(ctx, RssMediaActivity.class);
        ctx.startActivity(intent);
	}
	
	private void shareToChat() {
        WebDev.trackCustomEvent(ctx, EventId.BOSS_RSS_CLICK_SEND_MSG_TO_WRITOR);
        
        RssCatListItem card = newsDetail.getCard();
        Intent intent = new Intent();
        SettingInfo settingData = SettingObservable.getInstance().getData();
        if (settingData.getUserInfo() != null && settingData.getUserInfo().getUin() != null) {
                intent.putExtra("uin", card.getUin());
                intent.putExtra("nick", card.getChlname());
                intent.putExtra("mediaHeadUrl", card.getIcon());
                intent.setClass(ctx, ChatActivity.class);
                ctx.startActivity(intent);
        } else {
            intent.setClass(ctx, LoginActivity.class);
            intent.putExtra(Constants.LOGIN_FROM, Constants.LOGIN_FROM_RSS_SEND);
            if (ctx instanceof Activity) {
                ((Activity) ctx).startActivityForResult(intent, Constants.REQUEST_CODE_LOGIN);
            }
        }
	}
	
	private void sendWeiXin(int sth) {
		Intent intent = new Intent();
		intent.setClass(ctx, WXEntryActivity.class);
		intent.putExtra(Constants.NEWS_SHARE_WEIXIN_OR_FIRENDS, sth);
		ctx.startActivity(intent);
	}

	private void startTencentShare(int id) {
		int type = 0;
		switch (id) {
		case SHARE_TO_QZONE:
			type = ShareInterfaceActivity.TENCENT_QZONE;
			break;
		case SHARE_TO_QQWEIBO:
			type = ShareInterfaceActivity.TENCENT_WEIBO;
			break;
		default:
			break;
		}

		if (UserDBHelper.getInstance().getUserInfo() != null) {

			if (type == ShareInterfaceActivity.TENCENT_WEIBO && !UserDBHelper.getInstance().getUserInfo().isOpenMBlog()) {
				TipsToast.getInstance().showTipsWarning("未开通腾讯微博\n无法分享");
				return;
			}

			if (type == ShareInterfaceActivity.TENCENT_QZONE && !UserDBHelper.getInstance().getUserInfo().isOpenQZone()) {
				TipsToast.getInstance().showTipsWarning("未开通QQ空间\n无法分享");
				return;
			}

			Intent intent = new Intent();
			intent.setClass(ctx, ShareInterfaceActivity.class);
			intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			intent.putExtra(Constants.NEWS_SHARE_TYPE, type);
			ctx.startActivity(intent);

		} else {
			Intent intent = new Intent();
			intent.setClass(ctx, LoginActivity.class);
			intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			intent.putExtra(Constants.NEWS_SHARE_CONTENT, newsDetail);
			intent.putExtra(Constants.NEWS_SHARE_ITEM, newsItem);
			intent.putExtra(Constants.NEWS_SHARE_TYPE, type);
			intent.putExtra(Constants.LOGIN_FROM, Constants.LOGIN_FROM_SHARE_TENCENT_WEIBO);
			ctx.startActivity(intent);
		}
	}

	// public void afterWXThenSend() {
	// Intent intent = new Intent();
	// intent.setClass(ctx, ShareInterfaceActivity.class);
	// intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
	// intent.putExtra(Constants.NEWS_SHARE_TYPE,
	// ShareInterfaceActivity.WECHAT_FRIEND_ZONE);
	// ctx.startActivity(intent);
	// }

	/**
	 * @return the vid
	 */
	public String getVid() {
		return vid;
	}

	/**
	 * @param vid
	 *            the vid to set
	 */
	public void setVid(String vid) {
		this.vid = vid;
	}

	public Dialog getDlg() {
		return dlg;
	}

	public void setShareDismissListener(ShareDismissListener listener) {
		mListener = listener;
	}

	@Override
	public void onDismiss(DialogInterface dialog) {
		if (mListener != null) {
			mListener.OnDlgdismiss(dialog);
		}
	}

	public int getDoWhat() {
		return doWhat;
	}

	public void setDoWhat(int doWhat) {
		this.doWhat = doWhat;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public interface ShareDismissListener {
		public void OnDlgdismiss(DialogInterface dialog);
	}

	@Override
	public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm, String path) {

	}

	@Override
	public void onImageRecvError(ImageType imageType, Object tag, int retCode) {

	}
}
