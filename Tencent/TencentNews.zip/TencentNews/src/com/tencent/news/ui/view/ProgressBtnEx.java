package com.tencent.news.ui.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.FontMetrics;
import android.graphics.Paint.Style;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewTreeObserver;

import com.tencent.news.R;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.SLog;

/**
* @author jianhu
* @version 创建时间：2013-5-2 下午12:19:48
* 带进度条的按钮
*/
public class ProgressBtnEx extends View {
	private final static String TAG = ProgressBtnEx.class.getSimpleName();
	/* 声明Bitmap对象 */
	private Bitmap mBitmap = null;

	/* 创建画笔 */
	private Paint mPaint = null;

	/* 创建一个缓冲区 */
	private Bitmap mSCBitmap = null;

	/* 创建Canvas对象 */
	private Canvas mCanvas = null;

	private Context mContext;
	private String mText = "";
	private int mProgress;
	private int maxProgress = 100;
	private int mRight;
	private int mTextColor;
	private int mProgressColor;
	private float mTextSize = MobileUtil.dpToPx(14);
	private int width;
	private int height;
	private boolean hasMeasured = false;

	//背景点击态
	private Rect mCachedBounds = new Rect();
	private Drawable mBackground;

	public ProgressBtnEx(Context context, AttributeSet attrs) {
		super(context, attrs);
		init(context);
	}

	public ProgressBtnEx(Context context) {
		super(context);
		init(context);
	}

	public ProgressBtnEx(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init(context);
	}

	public void init(Context context) {
		mContext = context;
		initListener();
		initStateListDrawable();
		
		/* 装载资源 */
	//	mBitmap = ((BitmapDrawable) getResources().getDrawable(R.drawable.button_complete)).getBitmap();
		/* 创建屏幕大小的缓冲区 */
/*		mSCBitmap = Bitmap.createBitmap(250, 100, Config.ARGB_8888);
		 创建Canvas 
		mCanvas = new Canvas();
		 设置将内容绘制在mSCBitmap上 
		mCanvas.setBitmap(mSCBitmap);*/
		
		/* 创建Canvas */
		mCanvas = new Canvas();
		mPaint = new Paint();

	}

	/**
	 * Title:initListener
	 * @Description:设定OnPreDrawListener，获得控件宽高
	 * @param 
	 * @return void
	 * @throws
	 */
	public void initListener() {

		this.getViewTreeObserver().addOnPreDrawListener(
				new ViewTreeObserver.OnPreDrawListener() {
					public boolean onPreDraw() {
						if (hasMeasured == false) {

							height = getMeasuredHeight();
							width = getMeasuredWidth();// 获取到宽度和高度后，可用于计算
							hasMeasured = true;
							SLog.d(TAG, "initListener:" + width + "  " + height);
						}
						mSCBitmap = Bitmap.createBitmap(width, height, Config.ARGB_8888);
						/* 设置将内容绘制在mSCBitmap上 */
						mCanvas.setBitmap(mSCBitmap);
						return true;
					}
				});

	}

	/**
	 * Title:initStateListDrawable
	 * @Description:按钮不同状态背景图设置，类似selector效果的设置
	 * @param 
	 * @return void
	 * @throws
	 */
	private void initStateListDrawable() {
		StateListDrawable statelistDrawable = new StateListDrawable();

		int pressed = android.R.attr.state_pressed;
		int windowfocused = android.R.attr.state_window_focused;
		
		statelistDrawable.addState(new int[] { pressed, windowfocused }, mContext.getResources().getDrawable(R.drawable.appwall_button_press));
		statelistDrawable.addState(new int[] { -pressed, windowfocused },mContext.getResources().getDrawable(R.drawable.appwall_button));
		statelistDrawable.addState(new int []{}, getResources().getDrawable(R.drawable.appwall_button));  
		mBackground = statelistDrawable;
		mBackground.setCallback(this);
		this.setBackgroundDrawable(null);

	}

	/**
	 * Title:drawRect
	 * @Description:画矩形
	 * @param right
	 * @param color
	 * @param isFill
	 * @param isRoundBorder
	 * @return void
	 * @throws
	 */
	public void drawRect(float right, int color, boolean isFill) {

		// 定义圆角矩形对象
		RectF rectF1 = new RectF(0, 0, right, height);
		mPaint.setAntiAlias(true);
		mPaint.setDither(true);
		mPaint.setColor(color);

		if (isFill) {
			mPaint.setStyle(Style.FILL);
		} else {
			mPaint.setStyle(Style.STROKE);
			mPaint.setStrokeWidth(2);
		}

		mCanvas.drawRect(rectF1, mPaint);
	}

	/**
	 * Title:drawBitmap
	 * @Description:画进度条一致的图片
	 * @param right
	 * @return void
	 * @throws
	 */
	public void drawBitmap(int right) {

		Rect src = new Rect();// 图片
		Rect dst = new Rect();//屏幕
		src.left = 0; 
		src.top = 0;
		src.right = mBitmap.getWidth();
		src.bottom = mBitmap.getHeight();
		dst.left = 0; 
		dst.top = 0; 
		dst.right = right;
		SLog.d("hj", "mProgress:" + mProgress + " " + " right:" + dst.right);
		dst.bottom = height; 
		mCanvas.drawBitmap(mBitmap, src, dst, null);
		src = null;
		dst = null;
	}

	/**
	 * Title:drawText
	 * @Description:画进度条文字,垂直水平居中
	 * @return void
	 * @throws
	 */
	public void drawText() {

		mPaint.setColor(mTextColor);
		mPaint.setAntiAlias(true);
		Typeface font = Typeface.create("宋体", Typeface.NORMAL);
		mPaint.setTypeface(font);
		mPaint.setTextSize(mTextSize);
/*	
		float textWidth = mPaint.measureText(mText);
		FontMetrics fm = mPaint.getFontMetrics();
		float fFontHeight = (float) Math.ceil(fm.descent - fm.ascent); // 字高度
		mCanvas.drawText(mText, (width - textWidth) / 2, height / 2 + fFontHeight / 4, mPaint);*/
		
		mPaint.setTextAlign(Paint.Align.CENTER); 

		FontMetrics fontMetrics = mPaint.getFontMetrics(); 
		// 计算文字高度 
		float fontHeight = fontMetrics.bottom - fontMetrics.top; 
		// 计算文字baseline 
		float textBaseY = height - (height - fontHeight) / 2 - fontMetrics.bottom; 
		mCanvas.drawText(mText, width / 2, textBaseY, mPaint);
	}

	public void setProgressColor(int color) {
		mProgressColor = color;
	}

	public void setTextColor(int color) {
		mTextColor = color;
	}

	public void setTextSize(float size) {
		mTextSize = size;

	}

	public void setText(String text) {
		mText = text;
	}

	/**
	 * Title:drawProgress
	 * @Description:画进度
	 * @param progress
	 * @param mmaxProgress
	 * @return void
	 * @throws
	 */
	public void drawProgress(int progress, int mmaxProgress) {

		mProgress = progress;
		maxProgress = mmaxProgress;
		invalidate();
	}

	/**
	 * Title:setProgress
	 * @Description:设置进度
	 * @param progress
	 * @param text
	 * @return void
	 * @throws
	 */
	public void setProgress(int progress, String text) {

		mText = text;
		SLog.d("hj", "setProgress:" + progress + " " + text);
		drawProgress(progress, 100);
	}
	
	@Override
	public void onDraw(Canvas canvas) {

		if (mBackground != null) {
			SLog.d("hj", "mBackground draw");
			mBackground.setBounds(mCachedBounds);
			mBackground.draw(mCanvas); // 绘制当前状态对应的图片
		}
		
		mRight = width * mProgress / maxProgress;
		SLog.d("hj", "mRight: " + mRight);
		drawRect(mRight, mProgressColor, true);// 画进度条
		// drawBitmap(mRight);
		drawText();// 画进度百分百

		// 将mSCBitmap显示到屏幕上 
		Bitmap output = DrawRoundedCornerBitmap(MobileUtil.dpToPx(3));
		canvas.drawBitmap(output, 0, 0, mPaint);
		output.recycle();
		output = null;
		mSCBitmap.recycle();
		mSCBitmap = null;
	}
	
	/**
	 * Title:DrawRoundedCornerBitmap
	 * @Description:画mask，生成圆角图像
	 * @param roundPx
	 * @return Bitmap
	 * @throws
	 */
	public Bitmap DrawRoundedCornerBitmap(float roundPx) {

		try {
			Bitmap output = Bitmap.createBitmap(width, height, Config.ARGB_8888);
			Canvas canvas = new Canvas(output);
			final int color = 0xff424242;
			final Paint paint = new Paint();
			final Rect rect = new Rect(0, 0, width, height);
			final RectF rectF = new RectF(rect);
			paint.setAntiAlias(true);
			//canvas.drawARGB(0, 0, 0, 0);
			paint.setColor(color);
			canvas.drawRoundRect(rectF, roundPx, roundPx, paint);
			paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
			canvas.drawBitmap(mSCBitmap, rect, rect, paint);
			return output;
		} catch (OutOfMemoryError e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	protected void drawableStateChanged() {
		Drawable d = mBackground;
		if (d != null && d.isStateful()) {
			d.setState(getDrawableState());
		}

		super.drawableStateChanged();
	}

	@Override
	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		super.onSizeChanged(w, h, oldw, oldh);

		// Cache the view bounds.
		mCachedBounds.set(0, 0, w, h);
	}

	// 验证图片是否相等 , 在invalidateDrawable()会调用此方法，我们需要重写该方法。
	protected boolean verifyDrawable(Drawable who) {
		return who == mBackground || super.verifyDrawable(who);
	}

	/**
	 * Title:RecycleBitmap
	 * @Description:回收位图内存
	 * @return void
	 * @throws
	 */
	public void RecycleBitmap(){
		if(mSCBitmap != null && !mSCBitmap.isRecycled()){
			mSCBitmap.recycle();
			mSCBitmap = null;
		}
	}
}
