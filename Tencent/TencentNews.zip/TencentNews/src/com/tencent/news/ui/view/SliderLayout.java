package com.tencent.news.ui.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.PointF;
import android.graphics.RectF;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.FloatMath;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.Scroller;

import com.tencent.news.utils.DefaulImageUtil;
import com.tencent.news.utils.SLog;

/**
 * 实现的相册的图片浏览功能，手势放大缩小图片，可以左右滑动
 * @author Haiyandu
 * date: 2012-07-5
 */
public class SliderLayout extends ViewGroup {
	private static final String TAG = "ScrollLayout";
	private Scroller mScroller;
	private VelocityTracker mVelocityTracker;
	private int mCurScreen;
	private int mDefaultScreen = 0;
	private static final int TOUCH_STATE_REST = 0;
	private static final int TOUCH_STATE_SCROLLING = 1;
	private static final int SNAP_VELOCITY = 600;
	private int mTouchState = TOUCH_STATE_REST;
	private int mTouchSlop;
	private float mLastMotionX;
	private float mLastMotionY;
	private OnMoveScreenListener mScreenListener = null;
	
	// 初始状态
	private final static int IMAGE_MODE_NONE = 0x300;

	// 拖动状态(在图片已放大，并且左右边没有到顶)
	private final static int IMAGE_MODE_DRAG = 0x301;

	// 拖动放大状态(大于等于两个手指)
	private final static int IMAGE_MODE_ZOOM = 0x302;

	// 当前图片拖动状态
	private int mImageMode;
	
	// 当前View的MatrixImageView
	private MatrixImageView mCurrentImageView;
	
	// 多点触摸时第一次两指间的距离
	private float mFirstFingerSpace;

	// 多点触摸时第一次两指间的中点
	private PointF mFirstMiddlePoint;
	
	private boolean IsSlide = false;
	
	private RectF rect = new RectF();
	private Handler clickHandler;
	private float downX;
	private float upX;

	public SliderLayout(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
		// TODO Auto-generated constructor stub
	}

	public SliderLayout(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		// TODO Auto-generated constructor stub
		mScroller = new Scroller(context);
		mImageMode = IMAGE_MODE_NONE;
		mCurScreen = mDefaultScreen;
		mTouchSlop = ViewConfiguration.get(getContext()).getScaledTouchSlop();
	}

	@Override
	protected void onLayout(boolean changed, int l, int t, int r, int b) {
		// TODO Auto-generated method stub
		SLog.e(TAG, "onLayout");
		if (changed) {
			int childLeft = 0;
			final int childCount = getChildCount();
			
			for (int i=0; i<childCount; i++) {
				final View childView = getChildAt(i);
				if (childView.getVisibility() != View.GONE) {
					final int childWidth = childView.getMeasuredWidth();
					childView.layout(childLeft, 0, 
							childLeft+childWidth, childView.getMeasuredHeight());
					childLeft += childWidth;
				}
				MatrixImageView	ImageView = getCurrentView(i);
				ImageView.setImageBitmap(ImageView.getCurrentBitmap());
			}
		}
	}


    @Override  
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {   
    	SLog.e(TAG, "onMeasure");
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);   
        final int width = MeasureSpec.getSize(widthMeasureSpec);     
        final int count = getChildCount();   
        for (int i = 0; i < count; i++) {   
            getChildAt(i).measure(widthMeasureSpec, heightMeasureSpec);   
        }     
        scrollTo(mCurScreen * width, 0);  
        mCurrentImageView = getCurrentView(0);
    }  
    
    /**
     * According to the position of current layout
     * scroll to the destination page.
     */  
    public void snapToDestination() {    
        final int screenWidth = getWidth();    
        int destScreen = (getScrollX()+ screenWidth/2)/screenWidth;    
        destScreen = Math.max(0, Math.min(destScreen, getChildCount()-1));
    	if (getScrollX() != (destScreen*getWidth())) {
    		
    		final int delta = destScreen*getWidth()-getScrollX();
    		mScroller.startScroll(getScrollX(), 0, 
    				delta, 0, 300);
    		mCurScreen = destScreen;
//    		if(mScreenListener != null){
//    			mScreenListener.onCurScreen(mCurScreen);
//    		}
    		mCurrentImageView = getCurrentView(mCurScreen);
    		invalidate();		// Redraw the layout
    	}  
 }  
    
    public void snapToScreen(int whichScreen) {
    	// get the valid layout page
    	SLog.e(TAG, "snapscreen"+ mCurScreen);
    	whichScreen = Math.max(0, Math.min(whichScreen, getChildCount()-1));
    	if (getScrollX() != (whichScreen*getWidth())) {
    		
    		final int delta = whichScreen*getWidth()-getScrollX();
    		mScroller.startScroll(getScrollX(), 0, 
    				delta, 0, 300);
    		if (mCurScreen != whichScreen) {
    			mCurrentImageView.restoreImage();
    		}
    		mCurScreen = whichScreen;
    		mCurrentImageView = getCurrentView(mCurScreen);
    		invalidate();		// Redraw the layout
    		if(mScreenListener != null){
    			mScreenListener.onScrollFling(mCurScreen);
    		}
    	}
    }
    
    public void setToScreen(int whichScreen) {
    	whichScreen = Math.max(0, Math.min(whichScreen, getChildCount()-1));
    	mCurScreen = whichScreen;
    	scrollTo(whichScreen*getWidth(), 0);
    }
    
    public int getCurScreen() {
    	return mCurScreen;
    }
    
	@Override
	public void computeScroll() {
		// TODO Auto-generated method stub
		if (mScroller.computeScrollOffset()) {
			scrollTo(mScroller.getCurrX(), mScroller.getCurrY());
			SLog.v("SliderLayout", ""+mScroller.computeScrollOffset() + "mCurScreen:" + mCurScreen);
			postInvalidate();
			if(mScreenListener != null && !mScroller.computeScrollOffset()){
    			mScreenListener.onScrollFinished(mCurScreen);
    		}
			
		}
	}
	
	public Bitmap getCurrentBitmap(){
		return mCurrentImageView.getCurrentBitmap();
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		// TODO Auto-generated method stub
		
		if (mVelocityTracker == null) {
			mVelocityTracker = VelocityTracker.obtain();
		}
		mVelocityTracker.addMovement(event);
		final int action = event.getAction();
		final int pointerCount = event.getPointerCount();
		final float x = event.getX();
		final float y = event.getY();
		if(mCurrentImageView == null) return true;
		if(IsSlide) return false;
		switch (action & MotionEvent.ACTION_MASK) {
		case MotionEvent.ACTION_DOWN:
			SLog.e(TAG, "event down!");
			if (!mScroller.isFinished()){
				mScroller.abortAnimation();
			}
			mLastMotionX = x;
			mLastMotionY = y;
			downX = x;
			if(mCurrentImageView != null){
				mCurrentImageView.recordBasePoint();
			}
			rect.set(x-6, y-6, x+6, y+6);
			break;
			
		case MotionEvent.ACTION_MOVE:
		   int deltaX = (int)(mLastMotionX - x);
		   if(pointerCount == 1 && mCurrentImageView.isZoomIn() && mImageMode != IMAGE_MODE_ZOOM){
			   if (mCurrentImageView.isToLeftSide() && (x - mLastMotionX > 0)) {
					mImageMode = IMAGE_MODE_NONE;
				} else if (mCurrentImageView.isToRightSide() && (x - mLastMotionX < 0)) {
					mImageMode = IMAGE_MODE_NONE;
				} else {
					if(pointerCount == 2){
						mImageMode = IMAGE_MODE_ZOOM ; 
					}else{
						mImageMode = IMAGE_MODE_DRAG;
					}
				}
		   }
		   if(mImageMode == IMAGE_MODE_NONE){
		    	if (IsCanMove(deltaX))
		     	   {
		     		 	if (mVelocityTracker != null)
				        {
				            mVelocityTracker.addMovement(event); 
				        }   
			            mLastMotionX = x;  
			            scrollBy(deltaX, 0);	 
		     	   }
		    }else{
			    // 2、图片缩放、移动
				if (mImageMode == IMAGE_MODE_DRAG) {
					// 2.1图片移动
					float translateX = x - mLastMotionX;
					float translateY = y - mLastMotionY;
					mCurrentImageView.setTranslate(translateX, translateY);
					SLog.d(TAG, "变量记录：进行移动操作");
				} else if (mImageMode == IMAGE_MODE_ZOOM && !mCurrentImageView.getCurrentBitmap().equals(DefaulImageUtil.getDefaultPhotoDetailImage())) {
					// 2.2图片缩放
					float currentSpace = getFingerSpace(event);
					if (currentSpace > 10f) {
						mCurrentImageView.setScale(currentSpace / mFirstFingerSpace);
					}
					SLog.d(TAG, "变量记录：进行缩放操作");
				}
		    }
		   
			break;
		case MotionEvent.ACTION_POINTER_DOWN:
			mFirstFingerSpace = getFingerSpace(event);
			SLog.e(TAG, "首次间距为 mFirstFingerSpace = " + mFirstFingerSpace);
			if (mFirstFingerSpace > 10f) {
				mFirstMiddlePoint = getMiddlePoint(event);
				mImageMode = IMAGE_MODE_ZOOM;
			}
			mCurrentImageView.recordBaseScale();
			break;
		case MotionEvent.ACTION_POINTER_UP:
			mImageMode = IMAGE_MODE_NONE;
			mFirstFingerSpace = 0;
			// 给移动做准备
			mCurrentImageView.recordBasePoint();
			break;
		case MotionEvent.ACTION_UP:
			SLog.e(TAG, "event : up");     
			upX = x;
            float valF = upX - downX;
            int halfScreenWidth = 70;
            if (valF > halfScreenWidth && mCurScreen > 0 && !mCurrentImageView.isZoomIn()) {
                // Fling hard enough to move left
                snapToScreen(mCurScreen - 1);
            } else if (valF < -halfScreenWidth && mCurScreen < getChildCount()-1 && !mCurrentImageView.isZoomIn()) {
                // Fling hard enough to move right
                snapToScreen(mCurScreen + 1);
            } else {
                snapToDestination();
            }
            if(rect.contains(x, y)){
				clickHandler.sendEmptyMessage(1);
			}
            /*mTouchState = TOUCH_STATE_REST; */
            mImageMode = IMAGE_MODE_NONE;
			break;
		case MotionEvent.ACTION_CANCEL:
			/*mTouchState = TOUCH_STATE_REST;*/
			mImageMode = IMAGE_MODE_NONE;
			break;
		}
		
		return true;
	}
	
	@Override
	public boolean onInterceptTouchEvent(MotionEvent ev) {
		// TODO Auto-generated method stub
		SLog.e(TAG, "onInterceptTouchEvent-slop:"+mTouchSlop);
		
		final int action = ev.getAction();
		if ((action == MotionEvent.ACTION_MOVE) && 
				(mTouchState != TOUCH_STATE_REST)) {
			SLog.e("", "ACTION_MOVE --onInterceptTouchEvent  return true");
			return true;
		}
		
		final float x = ev.getX();
		final float y = ev.getY();
		
		switch (action) {
		case MotionEvent.ACTION_MOVE:
			final int xDiff = (int)Math.abs(mLastMotionX-x);
			if (xDiff>mTouchSlop) {
				mTouchState = TOUCH_STATE_SCROLLING;
			}
			SLog.e("onInterceptTouchEvent", "ACTION_MOVE ---onInterceptTouchEvent-mTouchState:"+mTouchState);
			break;
			
		case MotionEvent.ACTION_DOWN:
			mLastMotionX = x;
			mLastMotionY = y;
			downX = x;
			mTouchState = mScroller.isFinished()? TOUCH_STATE_REST : TOUCH_STATE_SCROLLING;
			SLog.e("onInterceptTouchEvent", "ACTION_DOWN ---onInterceptTouchEvent"+ mTouchState + mLastMotionX);
			break;
			
		case MotionEvent.ACTION_CANCEL:
		case MotionEvent.ACTION_UP:
			mTouchState = TOUCH_STATE_REST;
			SLog.e("onInterceptTouchEvent", "ACTION_UP---onInterceptTouchEvent"+ mTouchState);
			break;
		}
		 if (mTouchState != TOUCH_STATE_REST)
         {
			 SLog.e("onInterceptTouchEvent mTouchState != TOUCH_STATE_REST  return true");
       	  
         }
		return mTouchState != TOUCH_STATE_REST;
	}
	
	private MatrixImageView getCurrentView(int nCount){
		 View child = null;
		 MatrixImageView image = null;
		 if(getChildCount()>0){
			  child = getChildAt(nCount);
			  image = (MatrixImageView)((FrameLayout)child).getChildAt(0);
		 }
		 return image;
	}
	
	public void setSlide(boolean isSlide){
		this.IsSlide = isSlide;
	}
	
	private boolean IsCanMove(int deltaX)
	{
		if (getScrollX() <= 0 && deltaX < 0 )
		{
			return false;
		}
		if  (getScrollX() >=  (getChildCount() - 1) * getWidth() && deltaX > 0)
		{
			return false;
		}
		return true;
	}
	
	public void setMoveSreenListener(OnMoveScreenListener mScreenListener){
		this.mScreenListener = mScreenListener;
	}
	
	public void setHandler(Handler handler){
		this.clickHandler = handler;
	}
	
	//定义接口
	 public interface OnMoveScreenListener {
			public void onScrollFling(int whitch);
			public void onScrollFinished(int whitch);
		}
	 
	 /**
	  * 计算两指间的距离
	  * 
	  * @param event
	  * @return
	  */
	private float getFingerSpace(MotionEvent event) {
		float x = event.getX(0) - event.getX(1);
		float y = event.getY(0) - event.getY(1);
		return FloatMath.sqrt(x * x + y * y);
	}

	/**
	 * 计算中间点
	 * 
	 * @param point
	 * @param event
	 */
	private PointF getMiddlePoint(MotionEvent event) {
		PointF point = new PointF();
		float x = event.getX(0) + event.getX(1);
		float y = event.getY(0) + event.getY(1);
		point.set(x / 2, y / 2);
		return point;
	}
}
