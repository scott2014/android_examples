package com.tencent.news.ui;

import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;

import com.tencent.news.R;
import com.tencent.news.command.GetImageResponse;
import com.tencent.news.command.HttpDataResponse;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.utils.ThemeSettingsHelper;
import com.tencent.news.utils.ThemeSettingsHelper.ThemeCallback;

public abstract class BaseActivity extends FragmentActivity implements HttpDataResponse, GetImageResponse, ThemeCallback {

	// private boolean isBackground2Forground = false;
	protected ThemeSettingsHelper themeSettingsHelper = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		overridePendingTransition(R.anim.push_left_in, R.anim.push_left_out);
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(this);
		themeSettingsHelper.registerThemeCallback(this);
	}

	@Override
	protected void onStart() {
		super.onStart();
		themeSettingsHelper.loadDefaultTheme(this);
	}

	@Override
	protected void onRestart() {
		// SLog.i("STATISTICS", SLog.getTraceInfo() + "activity restart..");
		// if (isBackground2Forground) {
		// isBackground2Forground = false;
		// SLog.i("STATISTICS", SLog.getTraceInfo() + "background->forground");
		// Statistics.getInstance().reportAll();
		// Application.getInstance().statistics_app_start =
		// System.currentTimeMillis() / 1000; // 程序从后台切换到前台时
		// }
		super.onRestart();
	}

	@Override
	protected void onResume() {
		super.onResume();
		Resources resources = getResources();
		Configuration c = resources.getConfiguration();
		c.fontScale = 1.0f;
		resources.updateConfiguration(c, resources.getDisplayMetrics());
	}

	@Override
	protected void onPause() {
		super.onPause();
	}

	@Override
	protected void onStop() {
		// SLog.i("STATISTICS", SLog.getTraceInfo() +
		// "activity to another one");
		//
		//
		// if (!MobileUtil.isForgroundRunning()) {
		// isBackground2Forground = true;
		// Application.getInstance().statistics_app_end =
		// System.currentTimeMillis() / 1000;
		//
		// SLog.e("STATISTICS", SLog.getTraceInfo() + "开始时间:" +
		// Application.getInstance().statistics_app_start);
		// SLog.e("STATISTICS", SLog.getTraceInfo() + "结束时间:" +
		// Application.getInstance().statistics_app_end);
		//
		// SLog.f(Constants.LOG_TIME_PATH, "STATISTICS",
		// "HOME-->Application.getInstance().statistics_app_end=" +
		// Application.getInstance().statistics_app_end +
		// ",Application.getInstance().statistics_app_start="
		// + Application.getInstance().statistics_app_start + "--->" +
		// (Application.getInstance().statistics_app_end -
		// Application.getInstance().statistics_app_start));
		//
		// if (Application.getInstance().statistics_app_start > 0 &&
		// Application.getInstance().statistics_app_end > 0
		// && Application.getInstance().statistics_app_end >
		// Application.getInstance().statistics_app_start) {
		//
		// SLog.e("STATISTICS", "use time:" +
		// (Application.getInstance().statistics_app_end -
		// Application.getInstance().statistics_app_start));
		// Statistics.getInstance().saveStatistics(Statistics.REPORTED_DATA_DAILY,
		// StatisticsUtil.generateCustomField(new String[] { "" +
		// Application.getInstance().statistics_app_start, "" +
		// Application.getInstance().statistics_app_end }));
		// Application.getInstance().statistics_app_start = 0;
		// Application.getInstance().statistics_app_end = 0;
		// } else {
		// SLog.f(Constants.LOG_TIME_PATH, "STATISTICS",
		// "HOME-->data error! be filtered");
		// }
		//
		// // TipsToast.getInstance().dismissTips();// 清除所有的tips
		//
		// SLog.i("STATISTICS", SLog.getTraceInfo() +
		// "forground->background: save map");
		// Statistics.getInstance().refreshMap();
		// }
		super.onStop();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (themeSettingsHelper != null) {
			themeSettingsHelper.unRegisterThemeCallback(this);
		}
	}

	protected void quitActivity() {
		finish();
		overridePendingTransition(R.anim.push_right_in, R.anim.push_right_out);

	}

	@Override
	public void onHttpRecvOK(HttpTag tag, Object result) {

	}

	@Override
	public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {

	}

	@Override
	public void onHttpRecvCancelled(HttpTag tag) {

	}

	@Override
	public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm, String path) {

	}

	@Override
	public void onImageRecvError(ImageType imageType, Object tag, int retCode) {

	}

	@Override
	public void applyTheme() {
		// Auto-generated method stub
	}

}
