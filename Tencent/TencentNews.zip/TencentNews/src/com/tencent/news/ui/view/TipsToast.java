package com.tencent.news.ui.view;

import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.tencent.news.R;
import com.tencent.news.system.Application;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.ThemeSettingsHelper;

public class TipsToast {

	private static final int IMG_SUCCESS = R.drawable.tips_success;
	private static final int IMG_WARNING = R.drawable.tips_warning;
	private static final int IMG_SOFT_WARNING = R.drawable.tips_smile;
	private static final int IMG_ERROR = R.drawable.tips_error;
	private static final int TIPS_TIME = Toast.LENGTH_SHORT;
	private ThemeSettingsHelper themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(Application.getInstance().getBaseContext());
	private RelativeLayout mTipsLayout;
	static TipsToast mTipsToast = new TipsToast();

	static Toast mToast;


	private TipsToast() {
	}

	public static TipsToast getInstance() {
		return mTipsToast;
	}

	View v;

	private synchronized View makeTipsView(String msg, int tipsImage) {
		LayoutInflater lf = LayoutInflater.from(Application.getInstance().getApplicationContext());
		if (v == null) {
			v = lf.inflate(R.layout.view_tips, null, true);
		}

		mTipsLayout = (RelativeLayout) v.findViewById(R.id.view_tips_layout);
		if(themeSettingsHelper.isNightTheme()){
			mTipsLayout.setBackgroundResource(R.drawable.night_tips_bg);
		}else{
			mTipsLayout.setBackgroundResource(R.drawable.tips_bg);
		}
		ImageView tips_icon = (ImageView) v.findViewById(R.id.tips_icon);
		TextView tips_msg = (TextView) v.findViewById(R.id.tips_msg);
		tips_icon.setImageResource(tipsImage);
		tips_msg.setText(msg);
		return v;
	}

	private View makeEmptyTipsView() {
		LayoutInflater lf = LayoutInflater.from(Application.getInstance().getApplicationContext());
		View v = lf.inflate(R.layout.view_tips_empty, null, true);
		return v;
	}

	// private View makeLoadingTipsView(String msg) {
	// LayoutInflater lf =
	// LayoutInflater.from(Application.getInstance().getApplicationContext());
	// View v = lf.inflate(R.layout.view_tips_loading, null, true);
	// TextView tips_msg = (TextView) v.findViewById(R.id.tips_loading_msg);
	// tips_msg.setText(msg);
	// return v;
	// }

	private void showTips(View v, int dur) {
		Log.i("TEST", MobileUtil.getSystemSdk() + "");
		if (mToast != null) {
			if (MobileUtil.getSystemSdk() < 14) {
				mToast.cancel();
			}
		} else {
			mToast = new Toast(Application.getInstance().getBaseContext());
		}

		mToast.setView(v);
		mToast.setGravity(Gravity.CENTER, 0, 0);
		mToast.setDuration(TIPS_TIME);

		mToast.show();
	}

	// public void showTipsLoading(String msgStr) {
	// if (MobileUtil.isForgroundRunning()) {
	// setGoonTostLoading(true);
	// Message msg = Message.obtain();
	// msg.what = TIPS_LOADING;
	// msg.obj = msgStr;
	// mHandler.sendMessage(msg);
	// }
	// }

	public void showTipsSuccess(String msg) {
		if (MobileUtil.isForgroundRunning()) {
			showTips(makeTipsView(msg, IMG_SUCCESS), TIPS_TIME);
		}
	}

	public void showTipsError(String msg) {
		if (MobileUtil.isForgroundRunning()) {
			// showTipsLoading(msg);
			// showTips(makeLoadingTipsView(msg), TIPS_LOADING);
			showTips(makeTipsView(msg, IMG_ERROR), TIPS_TIME);
		}
	}

	/**
	 * 强硬警告
	 * 
	 * @param msg
	 */
	public void showTipsWarning(String msg) {
		if (MobileUtil.isForgroundRunning()) {
			showTips(makeTipsView(msg, IMG_WARNING), TIPS_TIME);
		}
	}

	/**
	 * 强硬警告
	 * 
	 * @param msg
	 * @param time
	 */
	public void showTipsWarning(String msg, int time) {
		if (MobileUtil.isForgroundRunning()) {
			showTips(makeTipsView(msg, IMG_WARNING), time);
		}
	}

	/**
	 * 柔和警告
	 * 
	 * @param msg
	 */
	public void showTipsSoftWarning(String msg) {
		if (MobileUtil.isForgroundRunning()) {
			showTips(makeTipsView(msg, IMG_SOFT_WARNING), TIPS_TIME);
		}
	}

	/**
	 * 柔和警告
	 * 
	 * @param msg
	 * @param time
	 */
	public void showTipsSoftWarning(String msg, int time) {
		if (MobileUtil.isForgroundRunning()) {
			showTips(makeTipsView(msg, IMG_SOFT_WARNING), time);
		}
	}

	public void showTipsSuccessIgnoreRunning(String msg) {
		showTips(makeTipsView(msg, IMG_SUCCESS), TIPS_TIME);
	}

	public void showTipsErrorIgnoreRunning(String msg) {
		showTips(makeTipsView(msg, IMG_ERROR), TIPS_TIME);
	}

	public void showTipsWarningIgnoreRunning(String msg) {
		showTips(makeTipsView(msg, IMG_WARNING), TIPS_TIME);
	}

	/**
	 * 柔和警告,忽略正在运行
	 * 
	 * @param msg
	 */
	public void showTipsSoftWarningIgnoreRunning(String msg) {
		showTips(makeTipsView(msg, IMG_SOFT_WARNING), TIPS_TIME);
	}

	public void dismissTips() {
		if (mToast != null) {
			mToast.cancel();
		}
		showTips(makeEmptyTipsView(), TIPS_TIME);
	}

}
