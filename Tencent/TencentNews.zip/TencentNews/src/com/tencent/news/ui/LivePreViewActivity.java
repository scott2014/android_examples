package com.tencent.news.ui;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.config.Constants;
import com.tencent.news.model.pojo.ImgTxtLiveImage;
import com.tencent.news.ui.adapter.ImageDetailViewPagerAdapter;
import com.tencent.news.ui.adapter.ImageDetailViewPagerAdapter.DisplayListener;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.news.ui.view.TouchImageView;
import com.tencent.news.ui.view.ViewPagerEx2;
import com.tencent.news.ui.view.ViewPagerEx2.OverScrollListener;
import com.tencent.news.utils.DefaulImageUtil;
import com.tencent.news.utils.ImageCacheNameUtil;
import com.tencent.news.utils.ImageUtil;
import com.tencent.news.utils.ThemeSettingsHelper;
import com.tencent.omg.webdev.WebDev;

public class LivePreViewActivity extends Activity {
	private ViewPagerEx2 mImagesViewPager;
	private ImageDetailViewPagerAdapter mImageDetailViewPagerAdapter;

	private ImageButton mDownBtn;
	private TextView mImageContent;
	private List<ImgTxtLiveImage> mImageList;
	private List<Bundle> mDataList;

	private int nImageCount;
	private int mImageIndex = 0;
	private int nCurrScreen = 0;
	protected ThemeSettingsHelper themeSettingsHelper = null;
	private View mMask;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		overridePendingTransition(R.anim.popup_enter, R.anim.popup_exit);
		setContentView(R.layout.live_preview_layout);
		getIntentData(getIntent());
		initView();
		initListener();
		initImage();
	}

	private void getIntentData(Intent intent) {
		if (intent != null) {
			mImageList = intent.getParcelableArrayListExtra(Constants.PREVIEW_IMAGE_KEY);
			mImageIndex = intent.getIntExtra(Constants.PREVIEW_IMAGE_INDEX_KEY, 0);
			nCurrScreen = mImageIndex;
		}
	}

	@SuppressLint("HandlerLeak")
	private void initView() {
		mImagesViewPager = (ViewPagerEx2) findViewById(R.id.image_detail_viewpager);
		mImageDetailViewPagerAdapter = new ImageDetailViewPagerAdapter();
		mImagesViewPager.setAdapter(mImageDetailViewPagerAdapter);
		mImageDetailViewPagerAdapter.setDisplayListener(new DisplayListener() {
			@Override
			public void onShowImage(int index, Bundle dataBundle, TouchImageView view) {
				view.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						quitActivity();
					}
				});
			}
		});

		mDownBtn = (ImageButton) findViewById(R.id.live_download_image_btn);
		mImageContent = (TextView) findViewById(R.id.live_image_text);
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(this);
		mMask = (View) findViewById(R.id.livepremask_view);
		if (themeSettingsHelper.isDefaultTheme()) {
			mMask.setBackgroundColor(getResources().getColor(R.color.mask_page_color));
		} else {
			mMask.setBackgroundColor(getResources().getColor(R.color.night_mask_page_color));
		}
	}

	private void initListener() {
		mDownBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				String path = ImageCacheNameUtil.getSaveImageFileName(mImageList.get(nCurrScreen).getImgurl());
				Bitmap showBitmap = mImagesViewPager.getCurrentBitmap();
				if (showBitmap != null && !showBitmap.equals(DefaulImageUtil.getDefaultPhotoDetailImage())) {
					boolean bFlag = ImageUtil.saveBitmap(showBitmap, path, ImageUtil.QUALITY_HIGH);
					if (bFlag) {
						Uri localUri = Uri.fromFile(new File(path));
						Intent localIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, localUri);
						sendBroadcast(localIntent);

						TipsToast.getInstance().showTipsSuccess("已下载到相册");
					} else {
						TipsToast.getInstance().showTipsError("下载失败");
					}
				}
			}

		});

		mImagesViewPager.setOnPageChangeListener(new OnPageChangeListener() {
			@Override
			public void onPageSelected(int arg0) {
				nCurrScreen = arg0;
				if (mImageList == null) {
					return;
				}

				setImageDesc(nCurrScreen);
			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
			}

			@Override
			public void onPageScrollStateChanged(int arg0) {
			}
		});

		mImagesViewPager.setOverScrollListener(new OverScrollListener() {
			@Override
			public void onOverScrollToRight() {
			}

			@Override
			public void onOverScrollToLeft() {
				quitActivity();
			}
		});

	}

	private void setImageDesc(int index) {
		if (mImageList != null && index >= 0 && index < mImageList.size()) {
			ImgTxtLiveImage live = mImageList.get(index);
			String str = "(" + (index + 1) + "/" + nImageCount + ")";
			String content = live != null ? live.getDesc() : "";
			mImageContent.setText(str + content);
		}
	}

	private void initImage() {
		if (mImageList == null) {
			return;
		}
		nImageCount = mImageList.size();
		mDataList = new ArrayList<Bundle>(nImageCount);
		for (int i = 0; i < nImageCount; i++) {
			Bundle bundle = new Bundle();
			bundle.putString("image", mImageList.get(i).getImgurl());
			mDataList.add(bundle);
		}

		mImageDetailViewPagerAdapter.setData(mDataList);
		mImagesViewPager.setCurrentItem(mImageIndex);
		setImageDesc(mImageIndex);
	}

	protected void quitActivity() {
		Intent intent = new Intent();
		intent.putExtra(Constants.IMAGE_TEXT_LIVE_KEY_IMAGE_RESULT_INDEX, nCurrScreen);
		setResult(RESULT_OK, intent);
		finish();
		overridePendingTransition(0, R.anim.popup_exit);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			quitActivity();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}
}
