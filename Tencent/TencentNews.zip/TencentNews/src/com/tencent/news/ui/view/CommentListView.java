package com.tencent.news.ui.view;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import android.content.Context;
import android.content.Intent;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Handler;
import android.text.ClipboardManager;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.boss.EventId;
import com.tencent.news.cache.UserDBHelper;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpDataResponse;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.pojo.Comment;
import com.tencent.news.model.pojo.CommentCount;
import com.tencent.news.model.pojo.CommentCountItem;
import com.tencent.news.model.pojo.CommentList;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.model.pojo.SimpleRet;
import com.tencent.news.model.pojo.UserInfo;
import com.tencent.news.shareprefrence.SpForbidenCommentNews;
import com.tencent.news.shareprefrence.SpUpComment;
import com.tencent.news.system.NetStatusReceiver;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.ChatActivity;
import com.tencent.news.ui.PublishActivity;
import com.tencent.news.ui.PushNewsDetailActivity;
import com.tencent.news.ui.adapter.CommentListAdapter;
import com.tencent.news.ui.view.PullRefreshListView.OnClickFootViewListener;
import com.tencent.news.ui.view.PullRefreshListView.OnRefreshListener;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.ThemeSettingsHelper;
import com.tencent.omg.webdev.WebDev;

/**
 * 评论列表,含撕页特效
 * 
 * @author jackiecheng
 * @since 2012-7-30
 */
public class CommentListView extends RelativeLayout implements HttpDataResponse {

	// long statistics_load_start;
	// long statistics_load_end;
	// long statistics_load_total;
	// long statistics_load_more_start;
	// long statistics_load_more_end;
	// long statistics_load_more_total;

	Context mContext;

	private PullToRefreshFrameLayout mFramelayout;
	private PullRefreshListView mListView;
	private CommentListAdapter mCommentListAdapter;

	private CommentList resultCommentList;

	private Comment[] myComment;

	private List<Comment[]> mDataList;
	private Handler mHandler;
	// private Handler mCloseWinHandler;

	boolean isBusy = false;
	boolean hadAdd = false;
	private Item mItem;
	private String imgUrl;
	private String channelId;
	private String vid;
	private String graphicLiveChlid;

	private int page = 1;

	private int xPos;
	private int yPos;
	private int location;
	private View clickedView;
	private String commentContent;
	private Comment[] clickedComment;
	private int width;
	private int forbidHeightInDp = 30;
	private int operationType = 0;

	private Animation fadeupAnim;
	private LayoutParams lp;
	private TextView animPlus;
	private PopupWindow popCommentWindow = null;
	private UpAndTransBar mUpAndTransBar;

	private TextView mCommentListViewHeaderTitle;
	private TextView mCommentListViewHeaderChannel;
	private TextView mCommentListViewHeaderTime;
	private ImageView mCommentListViewHeaderIcon;
	private ImageView mCommentListViewHeaderCommentIcon;
	private TextView mCommentListViewHeaderCommentNumber;
	private boolean isRelateNews;
	private int haveNum = 0;
	private ThemeSettingsHelper themeSettingsHelper = null;	

	/* kiddyliu 2013-06-21  用来标识是在哪个页面展示点评列表
	 * 0：新闻底层页的点评列表 1：我的点评页面的点评列表 2：提到我的页面点评列表*/
	private int commentListType = Constants.COMMENT_IN_NEWS_DETAIL_PAGE;
	private String lastTime = "", lastReplyID = "";
	private UserInfo user;
	
	public void setmHandler(Handler mHandler) {
		this.mHandler = mHandler;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public void setmItem(Item mItem) {
		this.mItem = mItem;
		if (mItem == null || mItem.getCommentNum() == null) {
			haveNum = 0;
		} else {
			try {
				haveNum = Integer.parseInt(mItem.getCommentNum());
			} catch (NumberFormatException e) {
				haveNum = 0;
			}
		}
	}

	public PullRefreshListView getmListView() {
		return mListView;
	}

	public CommentListView(Context context) {
		this(context, null);
	}

	public CommentListView(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public CommentListView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		//kiddyliu 这部分代码是为 “我的评论”、“提到我的” 而增加
		TypedArray arrayType = context.obtainStyledAttributes(attrs, com.tencent.news.R.styleable.CommentListView);
		commentListType = arrayType.getInteger(R.styleable.CommentListView_commentType, Constants.COMMENT_IN_NEWS_DETAIL_PAGE);
		arrayType.recycle();
		//增加的代码结束
		
		init(context);
	}

	private void init(Context context) {
		mContext = context;
		user = UserDBHelper.getInstance().getUserInfo();
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(mContext);
		if(commentListType==Constants.COMMENT_IN_NEWS_DETAIL_PAGE){ //kiddyliu 2013-06-24 我的评论、提到我的，不需要这段代码
			initView();			
		}else{
			initMyCommentView();
		}
		calcPopCommentWindowSize();
		initPopCommentWindow();
		initListener();
	}

	private void initView() {
		LayoutInflater.from(mContext).inflate(R.layout.view_commentlistview, this, true);
		mFramelayout = (PullToRefreshFrameLayout) findViewById(R.id.comment_list_view);

		lp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		animPlus = (TextView) findViewById(R.id.anim_plus);
		fadeupAnim = AnimationUtils.loadAnimation(mContext, R.anim.plus_up);

		mFramelayout.setTipsText("沙发，很寂寞...");
		mListView = mFramelayout.getPullToRefreshListView();
		mCommentListAdapter = new CommentListAdapter(mContext, mListView);
		View v = LayoutInflater.from(mContext).inflate(R.layout.view_commentlistview_header, null);
		themeSettingsHelper.setViewBackgroudColor(mContext, v, R.color.comment_list_background_color);
		mListView.addHeaderView(v);
		mListView.setAdapter(mCommentListAdapter);
		mFramelayout.showState(Constants.LOADING);

		mCommentListAdapter.setCommentListView(this);
		applyTheme();
	}
	
	//kiddyliu 初始化 “我的评论”/“提到我的” 页面
	private void initMyCommentView() {
		LayoutInflater.from(mContext).inflate(R.layout.view_mycommentlist, this, true);
		mFramelayout = (PullToRefreshFrameLayout) findViewById(R.id.comment_list_view);		
		lp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		animPlus = (TextView)findViewById(R.id.anim_plus);
		fadeupAnim = AnimationUtils.loadAnimation(mContext, R.anim.plus_up);			
		mListView = mFramelayout.getPullToRefreshListView();
		mCommentListAdapter = new CommentListAdapter(mContext, mListView, this.commentListType);			
		mListView.setAdapter(mCommentListAdapter);
		mFramelayout.showState(Constants.LOADING);		
		mCommentListAdapter.setCommentListView(this);		
	}

	private void initPopCommentWindow() {

		mUpAndTransBar = new UpAndTransBar(mContext);		
		mUpAndTransBar.setCommentListView(this);

		popCommentWindow = new PopupWindow(mUpAndTransBar, width, LayoutParams.WRAP_CONTENT);
		// 这个是为了点击“返回Back”也能使其消失，并且并不会影响你的背景
		popCommentWindow.setBackgroundDrawable(new BitmapDrawable());
		// 使其可点击
		popCommentWindow.setTouchable(true);		
		
		// 使其聚集
		popCommentWindow.setFocusable(true);
		// 设置允许在外点击消失
		popCommentWindow.setOutsideTouchable(true);
		popCommentWindow.setAnimationStyle(android.R.style.Animation_Dialog);
		popCommentWindow.update();

		xPos = MobileUtil.getScreenWidthIntPx() / 2 - popCommentWindow.getWidth() / 2;
	}

	private void calcPopCommentWindowSize() {
		if(commentListType==Constants.COMMENT_IN_NEWS_DETAIL_PAGE && !isCurrMediaWorker()){
			width = MobileUtil.getScreenWidthIntPx() * 2 / 3;
		}else{
			width = MobileUtil.getScreenWidthIntPx() * 4 / 5;
		}
	}

	public void initCommentViewHeader() {
		if (null == mItem) {
			return;
		}
		mCommentListViewHeaderTitle = (TextView) findViewById(R.id.comment_list_view_header_title);
		mCommentListViewHeaderChannel = (TextView) findViewById(R.id.comment_list_view_header_source);
		mCommentListViewHeaderTime = (TextView) findViewById(R.id.comment_list_view_header_time);
		mCommentListViewHeaderIcon = (ImageView) findViewById(R.id.comment_list_view_header_icon);
		mCommentListViewHeaderCommentIcon = (ImageView) findViewById(R.id.comment_list_view_header_comment_icon);
		mCommentListViewHeaderCommentNumber = (TextView) findViewById(R.id.comment_list_view_header_comment_number);

		// mCommentListViewHeaderCommentIcon.setImageResource(R.drawable.list_item_comment_icon);
		themeSettingsHelper.setImageViewSrc(mContext, mCommentListViewHeaderCommentIcon, R.drawable.list_item_comment_icon);
		themeSettingsHelper.setTextViewColor(mContext, mCommentListViewHeaderTitle, R.color.comment_list_title_color);
		themeSettingsHelper.setTextViewColor(mContext, mCommentListViewHeaderChannel, R.color.comment_list_channel_color);
		themeSettingsHelper.setTextViewColor(mContext, mCommentListViewHeaderTime, R.color.comment_list_channel_color);
		themeSettingsHelper.setTextViewColor(mContext, mCommentListViewHeaderCommentNumber, R.color.comment_list_channel_color);
		// 发布时间
		String shortPostTime = "";
		try {
			SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date postTime = formater.parse(mItem.getTime());
			formater.applyPattern("MM-dd HH:mm");
			shortPostTime = formater.format(postTime);
		} catch (Exception e) {
			e.printStackTrace();
		}

		mCommentListViewHeaderTitle.setText(mItem.getTitle());
		mCommentListViewHeaderChannel.setText(mItem.getSource());
		mCommentListViewHeaderTime.setText(shortPostTime);

		int resId = 0;
		if (themeSettingsHelper.isNightTheme()) {
			resId = setNightItemFlag();
		} else {
			resId = setItemFlag();
		}
		if (0 != resId) {
			mCommentListViewHeaderIcon.setImageResource(resId);
			mCommentListViewHeaderIcon.setVisibility(View.VISIBLE);
		}
		mCommentListViewHeaderCommentNumber.setText(mItem.getCommentNum());
		return;
	}

	public void refreshHeaderCommentNumber(int num) {
		mCommentListViewHeaderCommentNumber.setText("" + num);
		return;
	}

	public int getCurrentDisplayCommentNum() {
		try {

			return Integer.parseInt("" + mCommentListViewHeaderCommentNumber.getText());
		} catch (Exception e) {
			return 0;
		}
	}

	private void initListener() {

		fadeupAnim.setAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {
			}

			@Override
			public void onAnimationRepeat(Animation animation) {
			}

			@Override
			public void onAnimationEnd(Animation animation) {
				animPlus.setVisibility(View.GONE);
			}
		});
		mListView.setOnRefreshListener(new OnRefreshListener() {
			@Override
			public void onRefresh() {
				//getNewComment();
				if(commentListType==Constants.COMMENT_IN_NEWS_DETAIL_PAGE){
					getNewComment();
				}
				else if(commentListType==Constants.COMMENT_IN_ATME_COMMENT_PAGE){
					page = 1;
					getAtMeComments("","",page);
				}
				else{
					page = 1;
					getMyComments("","",page);
				}
			}

		});

		mListView.setOnClickFootViewListener(new OnClickFootViewListener() {

			@Override
			public void onClickFootView() {
				//getMoreData();
				if(commentListType==Constants.COMMENT_IN_NEWS_DETAIL_PAGE){
					getMoreData();
				}
				else if(commentListType==Constants.COMMENT_IN_ATME_COMMENT_PAGE){
					++page;
					getAtMeComments(lastTime,lastReplyID,page);
				}
				else{
					++page;
					getMyComments(lastTime,lastReplyID,page);
				}
			}

		});

		mListView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

				SLog.d("hj", "onItemClick position-->" + position);
				location = position - 1;
				try {
					clickedComment = mCommentListAdapter.getDataList().get(location);
				} catch (Exception e) {
					return;
				}

				clickedView = view;
				clickedComment = mCommentListAdapter.getDataList().get(location);
				
//				if (!clickedComment[clickedComment.length - 1].getReplyId().equals(Constants.TAG_COMMENT_CANTBEUP)) {
//					commentContent = ((TextView) view.findViewById(R.id.comment_text)).getText().toString();
//					showCommentPopWindow();
//				}
				
				if(clickedComment!=null && clickedComment.length > 0){
					Comment cm = clickedComment[clickedComment.length - 1];
					if( cm!=null && cm.getStatus()!=null && !cm.getStatus().trim().equals("0")){
						//这种情况下是被删除的评论，不允许进行顶、回复等操作
					}else if(cm!=null && !cm.getReplyId().equals(Constants.TAG_COMMENT_CANTBEUP)){
						commentContent = ((TextView) view.findViewById(R.id.comment_text)).getText().toString();
						showCommentPopWindow();
					}
				}
			}
		});

		mFramelayout.setRetryButtonClickedListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				//OnRetryData();
				if(commentListType==Constants.COMMENT_IN_NEWS_DETAIL_PAGE){
					OnRetryData();
				}
				else if(commentListType==Constants.COMMENT_IN_ATME_COMMENT_PAGE){
					page = 1;
					getAtMeComments("","",page);
				}
				else{
					page = 1;
					getMyComments("","", page);
				}
			}

		});

	}

	public void setClickedItemData(int position, Comment[] comment, View v) {

		location = position;
		clickedComment = comment;
		clickedView = v;
	}

	private boolean isCurrMediaWorker(){	
		
		if(mItem==null || user==null || mItem.getChlid()==null){	
			SLog.d("#####","can not get mItem or user! ");
			return false;
		}
		
		String strMediaID = user.getMediaID()==null? "":user.getMediaID().trim();
		String strChlID = mItem.getChlid()==null? "":mItem.getChlid().trim();
		SLog.d("#####","childid:" + strMediaID + " ### mediaid:" + strChlID);
		if(!strMediaID.equals("") && !strChlID.equals("") && strMediaID.equals(strChlID)){
			SLog.d("#####","I am Media Worker");
			return true;
		}
		
		return false;
	}
	
	public void showCommentPopWindow() {

		SLog.d("hj", "showCommentPopWindow:forbidArea:" + MobileUtil.dpToPx(forbidHeightInDp) + " yPos:" + yPos);

		int index = clickedComment.length - 1;
		Comment cm = clickedComment[index];
		
		if (yPos < MobileUtil.dpToPx(forbidHeightInDp) || index < 0 || cm ==null ) {
			return;
		}
				
		//如果是在我的评论页，媒体人有删除评论的权限
		if(commentListType==Constants.COMMENT_IN_MYCOMMENT_PAGE && cm.getMediaID()!=null 
		  && !cm.getMediaID().trim().equals("") && !cm.getMediaID().trim().equals("0")){
			mUpAndTransBar.showDelIcon();
		}else if(commentListType==Constants.COMMENT_IN_NEWS_DETAIL_PAGE){
			if(isCurrMediaWorker()){
				if(cm.isHot()){ //如果已经是置顶的评论，则pop弹窗显示取消置顶项
					mUpAndTransBar.showMediaView(1);
				}else{ //如果不是置顶的评论，则pop弹窗显示置顶项
					mUpAndTransBar.showMediaView(0);
				}
			}else{
				mUpAndTransBar.hideOriginalArticleIcon();
			}
		}else{
			mUpAndTransBar.hideDelIcon();
		}		
		
		mUpAndTransBar.setUpState(cm.isHadUp());
		xPos = MobileUtil.getScreenWidthIntPx() / 2 - popCommentWindow.getWidth() / 2;
		popCommentWindow.showAtLocation(clickedView, Gravity.NO_GRAVITY, xPos, yPos);

		popCommentWindow.setOnDismissListener(new OnDismissListener() {

			@Override
			public void onDismiss() {
				// TODO Auto-generated method stub
				SLog.d("hj", SLog.getTraceInfo() + " onDismiss");
				switch (operationType) {
				case 1:
					operationType = 0;
					upComment();
					break;
				case 2:
					operationType = 0;
					popWritingCommentWindow();
					break;
				case 3:
					operationType = 0;
					copyComment();
					break;
				case 4:
					operationType = 0;
					showOriginalArticle();
					break;
				case 5:
					operationType = 0;
					delComment();
					break;
				case 6:
					operationType = 0;
					setToHotComment();
					break;
				case 7:
					operationType = 0;
					setToNormalcomment();
					break;
				case 8:
					operationType = 0;
					sendMsg();
					break;
				default:
					break;
				}
			}
		});
	}	
	
	private void changeSetHotLocalView(){
		mCommentListAdapter.getDataList().remove(location);
		mCommentListAdapter.getDataList().add(1, clickedComment);	
		mCommentListAdapter.setHotNum(mCommentListAdapter.getHotNum()+1);
		mCommentListAdapter.setNewnum(mCommentListAdapter.getNewnum()-1);
		mCommentListAdapter.notifyDataSetChanged();	
	}
	
	private void changeSetNormalLocalView(){
		mCommentListAdapter.getDataList().remove(location);
		mCommentListAdapter.setHotNum(mCommentListAdapter.getHotNum()-1);
		if(mCommentListAdapter.getHotNum() < 1){
			mCommentListAdapter.getDataList().remove(0);
		}
		mCommentListAdapter.notifyDataSetChanged();	
	}
	
	public void addLittleTitleBar(int localtion, String commTag){
		Comment tag = new Comment();
		tag.setReplyId(Constants.TAG_COMMENT_CANTBEUP);		
		tag.setUin(commTag);		
		Comment[] tagComment = new Comment[] { tag };
		mCommentListAdapter.getDataList().add(localtion, tagComment);
	}
	
	public void sendMsg(){
		if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_INAVAILABLE) {			
			TipsToast.getInstance().showTipsWarning(getResources().getString(R.string.string_http_data_nonet));
		} else if(clickedComment!=null && clickedComment.length > 0){	
			Comment cm = clickedComment[clickedComment.length - 1];
			if(cm.getUin()!=null && cm.getNick()!=null){
				Intent intent = new Intent();
				intent.putExtra("uin", cm.getUin());
	            intent.putExtra("nick", cm.getNick());
	            intent.putExtra("mediaHeadUrl", cm.getHeadUrl());
	            intent.setClass(this.mContext, ChatActivity.class);
	            this.mContext.startActivity(intent);
			}
		}
	}
	
	private void setOneHotToServer(boolean isSetHot){
		if(clickedComment==null || clickedComment.length < 1 ){
			return;
		}		
		Comment cm = clickedComment[clickedComment.length - 1];
		if((cm.getCommentID()==null || cm.getCommentID().trim().equals("") 
		   || cm.getCommentID().trim().equals("0")) && mItem!=null && mItem.getCommentid()!=null 
		   && !mItem.getCommentid().trim().equals("") && !mItem.getCommentid().trim().equals("0") ){				
				cm.setCommentID(mItem.getCommentid());
		}
		if((cm.getArticleID()==null || cm.getArticleID().trim().equals("") 
		   || cm.getArticleID().trim().equals("0")) && mItem!=null && mItem.getId()!=null 
		   && !mItem.getId().trim().equals("") && !mItem.getId().trim().equals("0") ){				
				cm.setArticleID(mItem.getId());
		}
		
		String strChlID = (user==null || user.getMediaID()==null)? "": user.getMediaID();
		
		HttpDataRequest request = TencentNews.getInstance().setOneHotOrNormal(cm.getReplyId(), cm.getCommentID(), cm.getArticleID(), strChlID, cm.getCattr(), isSetHot);
		TaskManager.startHttpDataRequset(request, this);
		SLog.d("###sendHotSetToServer", "replyID:" + cm.getReplyId() + "| commentID:" + cm.getCommentID() + "| articleID:" + cm.getArticleID() + "| cattr:" + cm.getCattr());
	}	
	
	public void setToHotComment(){
		if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_INAVAILABLE) {			
			TipsToast.getInstance().showTipsWarning(getResources().getString(R.string.string_http_data_nonet));
		} else if(clickedComment!=null && clickedComment.length > 0){	
			if(mCommentListAdapter.getHotNum() < 1){ //如果原来没有最热点评，则先应该加一个最热评论的小标题
				addLittleTitleBar(0,Constants.TAG_COMMENT_HOT);				
			}else if(mCommentListAdapter.getHotNum()>=20){ //最多只能置顶20条评论
				TipsToast.getInstance().showTipsWarning(getResources().getString(R.string.set_hot_limit));				
			}			
			setOneHotToServer(true);
		}
	}
	
	public void setToNormalcomment(){
		if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_INAVAILABLE) {			
			TipsToast.getInstance().showTipsWarning(getResources().getString(R.string.string_http_data_nonet));
		} else if(clickedComment!=null && clickedComment.length > 0){			
			setOneHotToServer(false);
		}
	}
	
	public void delComment(){
		if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_INAVAILABLE) {			
			TipsToast.getInstance().showTipsWarning(getResources().getString(R.string.string_http_data_nonet));
		} else if(clickedComment!=null && clickedComment.length > 0){			
			Comment cm = clickedComment[clickedComment.length - 1];
			mCommentListAdapter.getDataList().remove(location);	//本地页面做一个假删除并提示用户删除成功
			if(commentListType==Constants.COMMENT_IN_NEWS_DETAIL_PAGE){ //如果是媒体人在订阅新闻评论底层页删除的评论
				if(cm.isHot()){
					mCommentListAdapter.setHotNum(mCommentListAdapter.getHotNum()-1);
				}else{
					mCommentListAdapter.setNewnum(mCommentListAdapter.getNewnum()-1);
				}
				if(mCommentListAdapter.getHotNum() < 1){
					mCommentListAdapter.getDataList().remove(0);
				}				
			}
			mCommentListAdapter.notifyDataSetChanged();		
			
			if((cm.getCommentID()==null || cm.getCommentID().trim().equals("") 
			   || cm.getCommentID().trim().equals("0")) && mItem.getCommentid()!=null 
			   && !mItem.getCommentid().trim().equals("") && !mItem.getCommentid().trim().equals("0") ){				
					cm.setCommentID(mItem.getCommentid());
			}
			if((cm.getArticleID()==null || cm.getArticleID().trim().equals("") 
			   || cm.getArticleID().trim().equals("0")) && mItem.getId()!=null 
			   && !mItem.getId().trim().equals("") && !mItem.getId().trim().equals("0") ){				
					cm.setArticleID(mItem.getId());
			}
			
			String strChlID = (user==null || user.getMediaID()==null)? "": user.getMediaID();			
					
			HttpDataRequest request = TencentNews.getInstance().delOneComment(cm.getReplyId(), cm.getCommentID(), cm.getArticleID(), strChlID, cm.getCattr());
			TaskManager.startHttpDataRequset(request, this);
			SLog.d("###delComment", "replyID:" + cm.getReplyId() + "| commentID:" + cm.getCommentID() + "| articleID:" + cm.getArticleID() + "| cattr:" + cm.getCattr());
		}
	}

	public void upComment() {

		if (!clickedComment[clickedComment.length - 1].isHadUp()) {
			if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_INAVAILABLE) {				
				TipsToast.getInstance().showTipsWarning(getResources().getString(R.string.string_http_data_nonet));
			} else {				
				if(clickedComment!=null && clickedComment.length > 0){					
					SpUpComment.saveUpCommentId(clickedComment[clickedComment.length - 1].getReplyId());
					TipsToast.getInstance().showTipsSuccess(getResources().getString(R.string.up_ok));
					clickedComment[clickedComment.length - 1].setHadUp(true);
					clickedComment[clickedComment.length - 1].setAgreeCount("" + (Integer.parseInt(clickedComment[clickedComment.length - 1].getAgreeCount()) + 1));
					mCommentListAdapter.getDataList().remove(location);
					mCommentListAdapter.getDataList().add(location, clickedComment);
					mCommentListAdapter.notifyDataSetChanged();	
					lp.setMargins(clickedView.findViewById(R.id.up_icon).getLeft(), clickedView.getTop() + clickedView.findViewById(R.id.up_icon).getTop(), 0, 0);
					animPlus.setLayoutParams(lp);
					animPlus.setVisibility(View.VISIBLE);
					animPlus.startAnimation(fadeupAnim);
					
					String url = "";
					String commentID = "";
					
					if(commentListType==Constants.COMMENT_IN_NEWS_DETAIL_PAGE){
						url = mItem.getSurl();
						commentID = mItem.getCommentid();
					}else{
						commentID = clickedComment[clickedComment.length - 1].getCommentID();
						
					}
					
					String cattr = clickedComment[clickedComment.length - 1].getCattr();
					
					SLog.d("### upComment ###", "url:" + url + "commentID:" + commentID + "getReplyId:" + clickedComment[clickedComment.length - 1].getReplyId());

					//HttpDataRequest request = TencentNews.getInstance().upOneComment(mItem.getSurl(), mItem.getCommentid(), clickedComment[clickedComment.length - 1].getReplyId());
					HttpDataRequest request = TencentNews.getInstance().upOneComment(url, commentID, clickedComment[clickedComment.length - 1].getReplyId(), cattr);
					TaskManager.startHttpDataRequset(request, this);
				}else{
					SLog.d("### upComment ###","clickedComment==null || clickedComment.length < 1 ");
				}				
			}
		}
		// closePopCommentWindow();
	}

	public void copyComment() {

		SLog.d("hj", commentContent);

		ClipboardManager cbm = (ClipboardManager) mContext.getSystemService(Context.CLIPBOARD_SERVICE);
		cbm.setText(commentContent);

		// closePopCommentWindow();
		Toast.makeText(mContext, getResources().getString(R.string.cppy_finished_message), Toast.LENGTH_SHORT).show();

	}

	public void setOperationType(int flag) {

		this.operationType = flag;
		sendToBossStatistics(this.operationType);
		closePopCommentWindow();		
	}

	public void closePopCommentWindow() {

		/*
		 * if(popCommentWindow != null && popCommentWindow.isShowing()){
		 * popCommentWindow.dismiss(); }
		 */
		postDelayed(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				if (popCommentWindow != null && popCommentWindow.isShowing()) {
					popCommentWindow.dismiss();
				}

			}
		}, 20);
	}

	public void popWritingCommentWindow() {

		mListView.setSelection(location + 1);
		Comment cm = null;
		if(clickedComment.length < 1){
			return;
		}else{
			cm = clickedComment[clickedComment.length - 1];
		}
		
		SLog.d("##################");
		Intent intent = new Intent();
		intent.setClass(mContext, PublishActivity.class);

		//在“我的点评”、“提到我的”页面，是没有mItem这个对象的，需要自己构造一个
		if(commentListType!=Constants.COMMENT_IN_NEWS_DETAIL_PAGE && mItem==null && cm!=null){	        
			Item tItem = new Item();
			tItem.setTitle(cm.getArticleTitle());
			tItem.setId(cm.getArticleID());
			tItem.setCommentid(cm.getCommentID());
			tItem.setUrl(cm.getUrl());
			
			intent.putExtra(Constants.WRITE_COMMENT_KEY, tItem);			
			SLog.d("#### itme", tItem.toString());
		}else{
			intent.putExtra(Constants.WRITE_COMMENT_KEY, mItem);
			intent.putExtra(Constants.WRITE_COMMENT_CHANNEL_KEY, channelId);
			intent.putExtra(Constants.WRITE_COMMENT_VID_KEY, vid);
			intent.putExtra(Constants.WRITE_COMMENT_GRAPHICLIVECHLID_KEY, graphicLiveChlid);
			intent.putExtra(Constants.WRITE_COMMENT_IMG_KEY, imgUrl);
			SLog.d("#### itme", mItem.toString());
		}
		
		SLog.d("#### comment", cm.toString());
		//intent.putExtra(Constants.WRITE_TRAN_COMMENT_KEY, clickedComment[clickedComment.length - 1]);
		if(cm!=null){
			intent.putExtra(Constants.WRITE_TRAN_COMMENT_KEY, cm);
		}
		mContext.startActivity(intent);
		// closePopCommentWindow();
	}
	
	//查看原文
	public void showOriginalArticle(){
		if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_INAVAILABLE) {
			//TipsToast.getInstance().showTipsWarning("无网络连接\n请启用数据网络");
			TipsToast.getInstance().showTipsWarning(getResources().getString(R.string.string_http_data_nonet));
		} else if(clickedComment!=null && clickedComment.length > 0){
			
			String articleID = clickedComment[clickedComment.length - 1].getArticleID();
			SLog.d("#### ID:",articleID);
			if(articleID!=null && !articleID.trim().equals("") && articleID.length()>0){
				Intent intent = new Intent();
				intent.setClass(mContext, PushNewsDetailActivity.class);		
		        intent.putExtra(Constants.NEWS_CHANNEL_CHLID_KEY, "");
		        intent.putExtra(Constants.NEWS_DETAIL_TITLE_KEY, "腾讯新闻");
		        intent.putExtra("pushserviceid", articleID);		        
		        if(commentListType==Constants.COMMENT_IN_ATME_COMMENT_PAGE){
		        	intent.putExtra("newFrom", "at");
		        }else if(commentListType==Constants.COMMENT_IN_MYCOMMENT_PAGE){
		        	intent.putExtra("newFrom", "my");
		        }
		        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
		        mContext.startActivity(intent);
			}
			
		}
	}
	
	private Properties getPts(int page) {
		Properties pts = new Properties();
		if(mItem!=null && mItem.getId()!=null){
			pts.setProperty(EventId.KEY_NEWSID, mItem.getId());
		}
		if(channelId!=null){
			pts.setProperty(EventId.KEY_CHANNELID, channelId);
		}
		pts.setProperty(EventId.KEY_PAGE, "" + page);
		return pts;
	}

	private void getNewComment() {

		// statistics_load_start = System.currentTimeMillis();

		isBusy = true;
		mListView.setSelection(0);
		page = 1;// 服务器从1开始,统计从0开始
		WebDev.trackCustomBeginKVEvent(mContext, EventId.ITIL_LOAD_COMMENT_TIME, getPts(0));
		HttpDataRequest request = TencentNews.getInstance().getQQNewsComment(mItem.getCommentid(), channelId, mItem.getUrl(), lastReplyID, lastTime, page);
		TaskManager.startHttpDataRequset(request, this);
	}

	private void getMoreData() {

		// statistics_load_more_start = System.currentTimeMillis();
		page++;
		WebDev.trackCustomBeginKVEvent(mContext, EventId.ITIL_LOAD_COMMENT_TIME, getPts(page));
		HttpDataRequest request = TencentNews.getInstance().getQQNewsComment(mItem.getCommentid(), channelId, mItem.getUrl(), lastReplyID, lastTime, page);
		TaskManager.startHttpDataRequset(request, this);
	}

	public void getMyComments(String replyID, String pubTime, int page){
		String strID = "";
		String strTime = "";
		if(page == 1){
			isBusy = true;
			mListView.setSelection(0);			
		}else{
			strID = replyID;
			strTime = pubTime;
		}
		
		HttpDataRequest request = TencentNews.getInstance().getMyComments(strID, strTime, page);
		TaskManager.startHttpDataRequset(request, this);	
		
		SLog.d("####","getMyComments replyID: " + strID + " Time: " + strTime);
	}
	
	public void getAtMeComments(String replyID, String pubTime, int page){
		String strID = "";
		String strTime = "";
		if(page == 1){
			isBusy = true;
			mListView.setSelection(0);			
		}else{
			strID = replyID;
			strTime = pubTime;
		}
		
		HttpDataRequest request = TencentNews.getInstance().getAtComments(strID, strTime, page);
		TaskManager.startHttpDataRequset(request, this);
		
		SLog.d("####","getAtMeComments replyID: " + strID + " Time: " + strTime);				
	}
	
	private void OnRetryData() {
		getNewComment();
		getNewCommentCount();
		mFramelayout.showState(Constants.LOADING);
	}

	public void refreshComment() {
		getNewComment();
		if (mCommentListAdapter.getCount() <= 1) {
			mFramelayout.showState(Constants.LOADING);
		}
	}

	public void refreshCommentCount(boolean is) {
		isRelateNews = is;
		getNewCommentCount();
	}

	private void getNewCommentCount() {
		if (isRelateNews) {
			HttpDataRequest requestCommentCount = TencentNews.getInstance().getQQNewsCommentCount(mItem.getCommentid());
			TaskManager.startHttpDataRequset(requestCommentCount, this);
		}
	}

	public boolean isBusy() {
		return isBusy;
	}

	/*将每次取回来的评论列表中最后一个item的时间和replyid取出来，获取下一页时
	 *需要回传给服务器*/	
	private void setLastCommentItemTimeAndReplyID(List<Comment[]> commList){		
		int len = commList.size();
		Comment[] commArr = commList.get(len-1);
		len = commArr.length;
		if(commArr!=null && len > 0){
			Comment lastComment = commArr[len-1];
			lastTime = lastComment.getPubTime();
			lastReplyID = lastComment.getReplyId();
			SLog.d("###LastItem###", lastTime + "|" + lastReplyID);
		}
	}
	
	@Override
	public void onHttpRecvOK(HttpTag tag, Object result) {
		isBusy = false;
		if (tag.equals(HttpTag.QQNEWS_COMMENT)) {
			resultCommentList = (CommentList) result;
			String ret = resultCommentList.getRet();

			if (mListView != null) {
				mListView.onRefreshComplete(true);
			}

			if (ret.equals("9999")) {
				endTrack(0, EventId.VALUE_RESCODE_SERVER_ERROR);

				Log.i("CJZ", mCommentListAdapter.getCount() - resultCommentList.getTagNum() + "");
				if (mCommentListAdapter.getCount() - resultCommentList.getTagNum() > 1) {
					mFramelayout.showState(Constants.LIST);
				} else {
					mFramelayout.showState(Constants.ERROR);
				}

			} else if (ret.equals("0")) {

				endTrack(0, EventId.VALUE_RESCODE_SUCCESS);

				// if (myComment != null) {

				mDataList = resultCommentList.addSelfCommentInto2Comments(myComment);
				// } else {
				// mDataList = resultCommentList.convert2CommentIn1();
				// }
				String hasNext = resultCommentList.hasNext();
				if (mDataList != null && mDataList.size() - resultCommentList.getTagNum() > 0) {
					mCommentListAdapter.addDataList(mDataList);
					mCommentListAdapter.notifyDataSetChanged();
					mFramelayout.showState(Constants.LIST);
					//mListView.setFootViewAddMore(true, true, false);
					if(hasNext.trim().equalsIgnoreCase("1")){
						setLastCommentItemTimeAndReplyID(mDataList);
						mListView.setFootViewAddMore(true, true, false);						
					}else{						
						mListView.setFootViewAddMore(true, false, false);
					}
					mHandler.sendEmptyMessage(Constants.REFRESH_COMMENT_NUM);

					// 如果禁止评论的新闻再次打开评论了,则删除本地的禁止评论缓存
					if (mItem != null && SpForbidenCommentNews.getForbidenCommentNews(mItem.getId())) {
						SpForbidenCommentNews.delForbidenCommentNews(mItem.getId());
					}

				} else {
					mFramelayout.showState(Constants.EMPTY);
				}
				sendRefreshCommentNumBroadcast(mCommentListAdapter.getCount() - resultCommentList.getTagNum());

			} else if (ret.equalsIgnoreCase("-1")) {
				endTrack(0, EventId.VALUE_RESCODE_FORBID);
				mHandler.sendEmptyMessage(Constants.FORBID_COMMENT);
			}

		} else if (tag.equals(HttpTag.QQNEWS_COMMENT_GET_MORE)) {

			CommentList resultCommentListGetMore = (CommentList) result;
			String ret = resultCommentListGetMore.getRet();

			if (ret.equalsIgnoreCase("0")) {				
				endTrack(page - 1, EventId.VALUE_RESCODE_SUCCESS);
				resultCommentListGetMore.setHadAddTag(resultCommentList.isHadAddTag());
				List<Comment[]> mMoreDataList = resultCommentListGetMore.convert2CommentIn1();
				resultCommentListGetMore.setTagNum(resultCommentList.getTagNum());
				if (mMoreDataList != null && mMoreDataList.size() > 0) {
					mCommentListAdapter.addMoreDataList(mMoreDataList);
					mCommentListAdapter.notifyDataSetChanged();
					mFramelayout.showState(Constants.LIST);
					//mListView.setFootViewAddMore(true, true, false);
					String hasNext = resultCommentListGetMore.hasNext();
					if(hasNext.trim().equalsIgnoreCase("1")){
						setLastCommentItemTimeAndReplyID(mMoreDataList);
						mListView.setFootViewAddMore(true, true, false);						
					}else{						
						mListView.setFootViewAddMore(true, false, false);
					}
					mHandler.sendEmptyMessage(Constants.REFRESH_COMMENT_NUM);
				} else {
					mHandler.sendEmptyMessage(Constants.TIPS_NO_MORE_COMMENTS);
					mListView.setFootViewAddMore(true, false, false);
				}
				sendRefreshCommentNumBroadcast(mCommentListAdapter.getCount() - resultCommentListGetMore.getTagNum());
			} else if (ret.equals("9999")) {

				endTrack(page - 1, EventId.VALUE_RESCODE_SERVER_ERROR);

				mListView.onRefreshComplete(true);
				Log.i("CJZ", mCommentListAdapter.getCount() - resultCommentListGetMore.getTagNum() + "");
				if (mCommentListAdapter.getCount() - resultCommentListGetMore.getTagNum() > 1) {
					mFramelayout.showState(Constants.LIST);
				} else {
					mFramelayout.showState(Constants.ERROR);
				}
			} else if (ret.equalsIgnoreCase("-1")) {
				endTrack(page - 1, EventId.VALUE_RESCODE_FORBID);
				mHandler.sendEmptyMessage(Constants.FORBID_COMMENT);
			}

		} else if (tag.equals(HttpTag.QQNEWS_COMMENT_COUNT)) {
			String cid = mItem.getCommentid();
			CommentCount resultCommentCount = (CommentCount) result;
			if (resultCommentCount.getRet().equals("0")) {
				HashMap<String, Object> info = resultCommentCount.getInfo();
				if (info != null && info.containsKey(cid)) {
					CommentCountItem commentCountItem = (CommentCountItem) info.get(cid);
					if (commentCountItem.getRet().equals("0")) {
						int num = commentCountItem.getCount();
						broadCastComment(num);
					}
				}
			}
		}
		else if(tag.equals(HttpTag.GET_MYCOMMENTS) || tag.equals(HttpTag.GET_ATCOMMENTS)){ //我的评论、提到我的
			resultCommentList = (CommentList) result;
			String ret = resultCommentList.getRet();
			String hasNext = resultCommentList.hasNext();
			if (ret.trim().equalsIgnoreCase("0")){ //非0的都是错误
//				if (mListView != null) {
//					mListView.onRefreshComplete(true);
//				}
				SLog.d("#####","recvOK tag: GET_MYCOMMENTS or GET_ATCOMMENTS");
				mListView.onRefreshComplete(true);
				mFramelayout.showState(Constants.LIST);
				mDataList = resultCommentList.getNewList();
				if (mDataList != null && mDataList.size()>0){
					mCommentListAdapter.addDataList(mDataList);
					mCommentListAdapter.notifyDataSetChanged();					
					if(hasNext.trim().equalsIgnoreCase("1")){
						setLastCommentItemTimeAndReplyID(mDataList);
						mListView.setFootViewAddMore(true, true, false);						
					}else{						
						mListView.setFootViewAddMore(true, false, false);
					}
				}else{
					mFramelayout.showState(Constants.EMPTY);
				}
			}
		}
		else if(tag.equals(HttpTag.GET_MYCOMMENTS_MORE) || tag.equals(HttpTag.GET_ATCOMMENTS_MORE)){ //获取到了更多我的评论
			CommentList resultCommentListGetMore = (CommentList) result;
			String ret = resultCommentListGetMore.getRet();
			String hasNext = resultCommentList.hasNext();
			if (ret.trim().equalsIgnoreCase("0")){ //非0的都是错误	
				SLog.d("#####","recvOK tag: GET_MYCOMMENTS_MORE or GET_ATCOMMENTS_MORE");
				mListView.onRefreshComplete(true);
				mFramelayout.showState(Constants.LIST);
				List<Comment[]> mMoreDataList = resultCommentListGetMore.getNewList();				
				if (mMoreDataList != null && mMoreDataList.size() > 0) {
					mCommentListAdapter.addMoreDataList(mMoreDataList);
					mCommentListAdapter.notifyDataSetChanged();					
					if(hasNext.trim().equalsIgnoreCase("1")){
						setLastCommentItemTimeAndReplyID(mMoreDataList);
						mListView.setFootViewAddMore(true, true, false);
					}else{
						mListView.setFootViewAddMore(true, false, false);
					}
				}
			}
		}
		else if(tag.equals(HttpTag.DEL_ONE_COMMENT)){//删除一条评论
			//do nothing
			SimpleRet retVal = (SimpleRet) result;
			if(retVal!=null && retVal.getReturnValue()!=null && retVal.getReturnValue().equalsIgnoreCase("0")){
				TipsToast.getInstance().showTipsSuccess(getResources().getString(R.string.del_ok));
			}else{
				TipsToast.getInstance().showTipsSuccess(getResources().getString(R.string.del_failed));
			}
			SLog.d("###ret DEL", result.toString());
		}else if(tag.equals(HttpTag.SET_ONE_TOP)){//置顶一条评论
			SimpleRet retVal = (SimpleRet) result;
			if(retVal!=null && retVal.getReturnValue()!=null && retVal.getReturnValue().equalsIgnoreCase("0")){
				changeSetHotLocalView();
				TipsToast.getInstance().showTipsSuccess(getResources().getString(R.string.set_hot_ok));
			}else{
				TipsToast.getInstance().showTipsSuccess(getResources().getString(R.string.set_hot_failed));
			}
			SLog.d("###ret TOP", result.toString());
		}else if(tag.equals(HttpTag.SET_ONE_NORMAL)){//取消置顶
			SimpleRet retVal = (SimpleRet) result;
			if(retVal!=null && retVal.getReturnValue()!=null && retVal.getReturnValue().equalsIgnoreCase("0")){
				changeSetNormalLocalView();
				TipsToast.getInstance().showTipsSuccess(getResources().getString(R.string.set_normal_ok));
			}else{
				TipsToast.getInstance().showTipsSuccess(getResources().getString(R.string.set_normal_failed));
			}
			SLog.d("###ret NORMAL", result.toString());
		}
	}

	private void endTrack(int page, String resCode) {
		Properties p = getPts(page);
		WebDev.trackCustomEndKVEvent(mContext, EventId.ITIL_LOAD_COMMENT_TIME, p);
		Properties newp = new Properties(p);
		newp.setProperty(EventId.KEY_RESCODE, resCode);
		WebDev.trackCustomEvent(mContext, EventId.ITIL_LOAD_COMMENT_TIME_RESULT, newp);
	}

	/**
	 * 发送刷新评论数的通知
	 * 
	 * @param commentNumber
	 */
	public void sendRefreshCommentNumBroadcast(int commentNumber) {

		broadCastComment(commentNumber);
		mCommentListAdapter.setHotAndAllNum(resultCommentList.getHotList().size(), getCurrentDisplayCommentNum());
	}

	private void broadCastComment(int commentNumber) {
		if (commentNumber > haveNum) {

			refreshHeaderCommentNumber(commentNumber);

			Intent intent = new Intent();
			intent.setAction(Constants.REFRESH_COMMENT_NUMBER_ACTION);
			intent.putExtra(Constants.REFRESH_COMMENT_NUMBER, commentNumber);
			intent.putExtra(Constants.REFRESH_COMMENT_ITEM_ID, mItem.getId());
			mContext.sendBroadcast(intent);
			haveNum = commentNumber;
		}
	}

	@Override
	public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {
		isBusy = false;
		if (tag.equals(HttpTag.QQNEWS_COMMENT)) {
			
			endTrack(0, EventId.VALUE_RESCODE_ERROR);
			
			mListView.onRefreshComplete(true);

			Log.i("CJZ", (mCommentListAdapter.getCount() - (resultCommentList != null ? resultCommentList.getTagNum() : 0)) + "");
			if (mCommentListAdapter.getCount() - (resultCommentList != null ? resultCommentList.getTagNum() : 0) > 1) {
				mFramelayout.showState(Constants.LIST);
			} else {
				mFramelayout.showState(Constants.ERROR);
			}

			TipsToast.getInstance().showTipsError(msg);
		} else if (tag.equals(HttpTag.QQNEWS_COMMENT_GET_MORE) 
		  || tag.equals(HttpTag.GET_MYCOMMENTS_MORE) || tag.equals(HttpTag.GET_ATCOMMENTS_MORE)) {
			
			endTrack(page - 1, EventId.VALUE_RESCODE_ERROR);
			
			mListView.setFootViewAddMore(true, true, true);
			TipsToast.getInstance().showTipsError(msg);
		} else if (tag.equals(HttpTag.GET_MYCOMMENTS) || tag.equals(HttpTag.GET_ATCOMMENTS)){
			endTrack(0, EventId.VALUE_RESCODE_ERROR);
			mListView.onRefreshComplete(true);
			mFramelayout.showState(Constants.ERROR);
			TipsToast.getInstance().showTipsError(msg);
		} else if (tag.equals(HttpTag.UP_ONE_COMMENT) || tag.equals(HttpTag.DEL_ONE_COMMENT)) {
			// DO NOTHING
		}
	}

	@Override
	public void onHttpRecvCancelled(HttpTag tag) {
		isBusy = false;
	}

	public void addComment(Comment[] c) {
		SLog.i("添加自己的评论.......");
		myComment = c;

		if (mDataList != null && resultCommentList != null) {
			mDataList = resultCommentList.addSelfCommentInto2Comments(c);
		} else {
			mDataList = new ArrayList<Comment[]>();
			mDataList.add(c);
		}
		mCommentListAdapter.addDataList(mDataList);
		mCommentListAdapter.notifyDataSetChanged();
		mFramelayout.showState(Constants.LIST);
	}

	public boolean isBarSHowing() {
		return hadAdd;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	public void setVid(String vid) {
		this.vid = vid;
	}

	public void setGraphicLiveChlid(String graphicLiveChlid) {
		this.graphicLiveChlid = graphicLiveChlid;
	}

	private int setItemFlag() {
		String flag = mItem.getFlag();
		int id = 0;
		if (flag != null && !"0".equals(flag)) {
			if ("1".equals(flag)) {
				id = R.drawable.flag_scoop_icon;
			} else if ("2".equals(flag)) {
				id = R.drawable.flag_tote_icon;
			} else if ("3".equals(flag)) {
				id = R.drawable.flag_video_icon;
			} else if ("4".equals(flag)) {
				id = R.drawable.flag_special_icon;
			} else if ("5".equals(flag)) {
				id = R.drawable.flag_flash_icon;
			} else if ("6".equals(flag)) {
				id = R.drawable.flag_live_icon;
			} else if ("7".equals(flag)) {
				id = R.drawable.flag_redian;
			}
		}
		return id;
	}

	private int setNightItemFlag() {
		String flag = mItem.getFlag();
		int id = 0;
		if (flag != null && !"0".equals(flag)) {
			if ("1".equals(flag)) {
				id = R.drawable.night_flag_scoop_icon;
			} else if ("2".equals(flag)) {
				id = R.drawable.night_flag_tote_icon;
			} else if ("3".equals(flag)) {
				id = R.drawable.night_flag_video_icon;
			} else if ("4".equals(flag)) {
				id = R.drawable.night_flag_special_icon;
			} else if ("5".equals(flag)) {
				id = R.drawable.night_flag_flash_icon;
			} else if ("6".equals(flag)) {
				id = R.drawable.night_flag_live_icon;
			} else if ("7".equals(flag)) {
				id = R.drawable.night_flag_redian;
			}
		}
		return id;
	}

	// private void smoothScrollToPosition(int position) throws Exception {
	// Class<ListView> clazz = (Class<ListView>)
	// mListView.getClass().getSuperclass();
	// Class[] clzs = new Class[1];
	// clzs[0] = int.class;
	// Method m = clazz.getMethod("smoothScrollToPosition", clzs);
	// if (!m.isAccessible()) {
	// m.setAccessible(true);
	// }
	// m.invoke(mListView, position);
	// }
	@Override
	public boolean dispatchTouchEvent(MotionEvent event) {

		yPos = (int) event.getY();

		return super.dispatchTouchEvent(event);
	}

	public void applyTheme() {

		if (mFramelayout != null) {
			mFramelayout.applyFrameLayoutTheme();
		}
		if (mListView != null) {
			mListView.applyPullRefreshViewTheme();
		}

		if (themeSettingsHelper.isNightTheme()) {
			mListView.setCacheColorHint(Color.parseColor("#FF000000"));
		} else {
			mListView.setCacheColorHint(Color.parseColor("#00000000"));
		}

		themeSettingsHelper.setViewBackgroudColor(mContext, this.mListView, R.color.timeline_home_bg_color);
		themeSettingsHelper.setListViewSelector(mContext, this.mListView, R.drawable.list_selector);
		themeSettingsHelper.setListViewDivider(mContext, this.mListView, R.drawable.list_divider_line);

		if (mCommentListAdapter != null) {
			mCommentListAdapter.notifyDataSetChanged();
		}
	}
	
	//kiddyliu boss统计代码
	private void bossUp(){
		switch(this.commentListType){
			case Constants.COMMENT_IN_NEWS_DETAIL_PAGE:
				WebDev.trackCustomEvent(this.mContext, EventId.BOSS_COMMENT_LIST_CLICK_UP_ONE_COMMENT_BTN);
				break;
			case Constants.COMMENT_IN_MYCOMMENT_PAGE:
				WebDev.trackCustomEvent(this.mContext, EventId.BOSS_MY_COMMENT_CLICK_UP_ONE_COMMENT_BTN);
				break;
			case Constants.COMMENT_IN_ATME_COMMENT_PAGE:
				WebDev.trackCustomEvent(this.mContext, EventId.BOSS_AT_COMMENT_CLICK_UP_ONE_COMMENT_BTN);
				break;
			default:
				break;
		}
	}
	
	private void bossTran(){
		switch(this.commentListType){
			case Constants.COMMENT_IN_NEWS_DETAIL_PAGE:
				WebDev.trackCustomEvent(this.mContext, EventId.BOSS_COMMENT_LIST_CLICK_TRAN_COMMENT_BTN);
				break;
			case Constants.COMMENT_IN_MYCOMMENT_PAGE:
				WebDev.trackCustomEvent(this.mContext, EventId.BOSS_MY_COMMENT_CLICK_TRAN_COMMENT_BTN);
				break;
			case Constants.COMMENT_IN_ATME_COMMENT_PAGE:
				WebDev.trackCustomEvent(this.mContext, EventId.BOSS_AT_COMMENT_CLICK_TRAN_COMMENT_BTN);
				break;
			default:
				break;
		}
	}
	
	private void bossCopy(){
		switch(this.commentListType){
			case Constants.COMMENT_IN_NEWS_DETAIL_PAGE:
				WebDev.trackCustomEvent(this.mContext, EventId.BOSS_COMMENT_LIST_CLICK_COPY_BTN);
				break;
			case Constants.COMMENT_IN_MYCOMMENT_PAGE:
				WebDev.trackCustomEvent(this.mContext, EventId.BOSS_MY_COMMENT_CLICK_COPY_BTN);
				break;
			case Constants.COMMENT_IN_ATME_COMMENT_PAGE:
				WebDev.trackCustomEvent(this.mContext, EventId.BOSS_AT_COMMENT_CLICK_COPY_BTN);
				break;
			default:
				break;
		}
	}
	
	private void bossShowOrigArticle(){
		switch(this.commentListType){
			case Constants.COMMENT_IN_NEWS_DETAIL_PAGE:
				break;
			case Constants.COMMENT_IN_MYCOMMENT_PAGE:
				WebDev.trackCustomEvent(this.mContext, EventId.BOSS_MY_COMMENT_CLICK_ORIGINAL_ARTICLE_BTN);
				break;
			case Constants.COMMENT_IN_ATME_COMMENT_PAGE:
				WebDev.trackCustomEvent(this.mContext, EventId.BOSS_AT_COMMENT_CLICK_ORIGINAL_ARTICLE_BTN);
				break;
			default:
				break;
		}
	}
	
	private void bossDel(){
		switch(this.commentListType){
			case Constants.COMMENT_IN_NEWS_DETAIL_PAGE:
				WebDev.trackCustomEvent(this.mContext, EventId.BOSS_COMMENT_LIST_CLICK_DEL_BTN);
				break;
			case Constants.COMMENT_IN_MYCOMMENT_PAGE:
				WebDev.trackCustomEvent(this.mContext, EventId.BOSS_MY_COMMENT_CLICK_DEL_BTN);
				break;
			case Constants.COMMENT_IN_ATME_COMMENT_PAGE:
				break;
			default:
				break;
		}
	}
	
	private void bossHot(){
		switch(this.commentListType){
			case Constants.COMMENT_IN_NEWS_DETAIL_PAGE:
				WebDev.trackCustomEvent(this.mContext, EventId.BOSS_COMMENT_LIST_CLICK_SETTOP_BTN);
				break;
			case Constants.COMMENT_IN_MYCOMMENT_PAGE:
				break;
			case Constants.COMMENT_IN_ATME_COMMENT_PAGE:
				break;
			default:
				break;
		}
	}
	
	private void bossNormal(){
		switch(this.commentListType){
			case Constants.COMMENT_IN_NEWS_DETAIL_PAGE:
				WebDev.trackCustomEvent(this.mContext, EventId.BOSS_COMMENT_LIST_CLICK_SETNORMAL_BTN);
				break;
			case Constants.COMMENT_IN_MYCOMMENT_PAGE:
				break;
			case Constants.COMMENT_IN_ATME_COMMENT_PAGE:
				break;
			default:
				break;
		}
	}
	
	private void bossSendMsg(){
		switch(this.commentListType){
			case Constants.COMMENT_IN_NEWS_DETAIL_PAGE:
				WebDev.trackCustomEvent(this.mContext, EventId.BOSS_COMMENT_LIST_CLICK_SENDMSG_BTN);
				break;
			case Constants.COMMENT_IN_MYCOMMENT_PAGE:
				break;
			case Constants.COMMENT_IN_ATME_COMMENT_PAGE:
				break;
			default:
				break;
		}		
	}
	
	private void sendToBossStatistics(int opType){
		SLog.d("BOSS", "CommentListView opreation type:" + String.valueOf(opType) + " in page: " + String.valueOf(this.commentListType));
		switch (opType) {
			case 1:			
				bossUp();
				break;
			case 2:			
				bossTran();
				break;
			case 3:			
				bossCopy();
				break;
			case 4:			
				bossShowOrigArticle();
				break;
			case 5:			
				bossDel();
				break;
			case 6:			
				bossHot();
				break;
			case 7:			
				bossNormal();
				break;
			case 8:			
				bossSendMsg();
				break;
			default:
				break;
		}
	}
	
	
}
