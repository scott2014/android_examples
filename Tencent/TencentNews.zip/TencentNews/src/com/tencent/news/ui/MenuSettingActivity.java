package com.tencent.news.ui;

import java.util.ArrayList;
import java.util.HashMap;

import android.content.Intent;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.Window;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationSet;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.anim.ResizeHeightAnimation;
import com.tencent.news.config.Constants;
import com.tencent.news.model.pojo.ListMapData;
import com.tencent.news.ui.view.ChannelListView;
import com.tencent.news.ui.view.ChannelListView.OnSelectChannel;
import com.tencent.news.ui.view.DragDropGrid;
import com.tencent.news.ui.view.DragDropGrid.OnLayoutEvent;
import com.tencent.news.ui.view.DragDropGrid.OnTranslateAnimation;
import com.tencent.news.ui.view.InterceptScrollView;
import com.tencent.news.ui.view.Switch;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.ThemeSettingsHelper;
import com.tencent.omg.webdev.WebDev;

public class MenuSettingActivity<isLastIndex, isEnd> extends BaseActivity implements OnClickListener, OnTouchListener {

	private static int TRANSLATE_ANIMATION_DURATION = 350;
	private static int TRANSLATE_DRAGBTN_ANIMATION_DURATION = 350;
	private static int LONG_PRESS_TIMEOUT = 200;
	private static int CLICK_TIME = 500;
	private static int DRAGGED_DISABLE = -1;
	private static int DRAGGED_ENABLE = 1;
	private static int TOP_OFFSET = 28;

	private Button menuSettingCompleteBtn = null;
	private ArrayList<HashMap<String, Object>> menuDataMap = new ArrayList<HashMap<String, Object>>();
	private ArrayList<HashMap<String, Object>> listDataMap = new ArrayList<HashMap<String, Object>>();

	private LinearLayout selectedMenuBtnLayout;
	private LinearLayout menuListLayout;
	private LinearLayout moreChannelBar;
	private DragDropGrid dragDropGrid = null;
	private ChannelListView channelListView = null;
	private InterceptScrollView scrollView;
	private ListMapData allChannels;
	private ArrayList<HashMap<String, Object>> allChannelsData;

	private int dragged = DRAGGED_DISABLE;

	private int lastDragIndex = DragDropGrid.NO_INDEX;
	private int dragIndex = DragDropGrid.NO_INDEX;

	private Button origButton = null;
	private Button dragButton = null;
	private boolean isDragBtnMoving = false;
	private boolean isMenuBtnMoving = false;
	private boolean isAtTheSameTime = false;
	private boolean isDragMoving = false;
	private boolean isLastIndex = false;
	private int initialX;
	private int initialY;
	private int currentX;
	private int currentY;
	private int lastTouchX;
	private int lastTouchY;
	private int tempX;
	private int tempY;

	private int viewGroupHeight = -1;
	private int lastViewGroupHeight;

	private long clickBeginTime = 0;
	private long clickEndTime = 0;
	private Switch monitoredSwitch;
	private String currentListType = "channellist";

	Handler handler = new Handler();
	Handler longClickHandler = new Handler();
	Runnable removeDragBtnRunnable;
	Runnable removeMenuRunnable;
	private boolean isTouchMoved;
	private View startDragView;
	private static final int TOUCH_SLOP = 20;

	private View mMask;

	// 夜间模式
	RelativeLayout settingTitle = null;
	// Button menuSettingCompleteBtn = null;
	FrameLayout dragContainer = null;
	TextView toolTips = null;

	//

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(this);
		/*
		 * if(themeSettingsHelper.isDefaultTheme()){
		 * setContentView(R.layout.custom_menu); } else{
		 * setContentView(R.layout.night_custom_menu); }
		 */
		if (themeSettingsHelper.isDefaultTheme()) {
			setTheme(R.style.NoShade);
		} else {
			setTheme(R.style.NoShade2);
		}
		setContentView(R.layout.custom_menu);
		mMask = (View) findViewById(R.id.mask_view);
		initData();
		initViews();
		initListener();
		initRemoveMenuRunnable();
		initRemoveDragBtnRunnable();
	}

	/**
	 * 初始化数据
	 */
	private void initData() {
		Intent intent = getIntent();
		if (intent != null) {
			Bundle bundle = intent.getExtras();
			allChannels = (ListMapData) bundle.getSerializable(Constants.SUB_CHANNEL);
			allChannelsData = allChannels.getMenuDataMap();
			initChannelData(allChannelsData);
		}
	}

	/**
	 * 初始化已选菜单数据
	 */
	private void initChannelData(ArrayList<HashMap<String, Object>> arrayList) {
		int count = arrayList.size();
		ArrayList<HashMap<String, Object>> tempData = new ArrayList<HashMap<String, Object>>();
		for (int i = 0; i < count; i++) {
			HashMap<String, Object> map = arrayList.get(i);
			boolean isSelected = (Boolean) map.get("isSelected");
			String from = (String) map.get("from");
			map.put("isAlpha", false);
			if (isSelected) {
				menuDataMap.add(map);
				tempData.add(map);
			}
			if (from.equals(currentListType)) {
				listDataMap.add(map);
			}
		}
		int c = tempData.size();
		for (int j = 0; j < c; j++) {
			HashMap<String, Object> map = tempData.get(j);
			int order = (Integer) map.get("order");
			try {
				menuDataMap.set(order, map);
			} catch (Exception e) {
			}
		}
	}

	/**
	 * 设置排序后的数据
	 */
	private void setOrderChannelData() {
		int count = menuDataMap.size();
		int allCount = allChannelsData.size();
		for (int j = 0; j < allCount; j++) {
			HashMap<String, Object> allMap = allChannelsData.get(j);
			allMap.put("order", -1);
			allMap.put("isSelected", false);
			String allChildName = String.valueOf(allMap.get("chlid"));
			for (int i = 0; i < count; i++) {
				HashMap<String, Object> map = menuDataMap.get(i);
				String childName = String.valueOf(map.get("chlid"));
				if (allChildName.equals(childName)) {
					allMap.put("order", i);
					allMap.put("isSelected", true);
				}
			}
			allChannelsData.set(j, allMap);
		}
		allChannels.setMenuDataMap(allChannelsData);
	}

	/**
	 * 动态创建已经选中菜单界面
	 */
	private void createDragDropGrid() {
		dragDropGrid = new DragDropGrid(this);
		dragDropGrid.setClipChildren(false);
		dragDropGrid.setCellHeight(MobileUtil.dpToPx(DragDropGrid.BUTTON_HEIGHT_DP));
		dragDropGrid.setCellWidth(MobileUtil.dpToPx(DragDropGrid.BUTTON_WIDTH_DP));
		dragDropGrid.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
		selectedMenuBtnLayout.addView(dragDropGrid);
		dragDropGrid.setAdapter(menuDataMap);
		dragDropGrid.render();
		dragDropGridListener();
		bindDragEvent(dragDropGrid);
	}

	/**
	 * 重绘频道选择区域
	 */
	private void renderListView() {
		int count = allChannelsData.size();
		listDataMap.clear();
		for (int i = 0; i < count; i++) {
			HashMap<String, Object> map = allChannelsData.get(i);
			String from = (String) map.get("from");
			map.put("isAlpha", false);
			if (from.equals(currentListType)) {
				listDataMap.add(map);
			}
		}
		menuListLayout.removeAllViews();
		channelListView.setAdapter(listDataMap);
		channelListView.render();
	}

	/**
	 * 创建ListView, 监听channel选择事件
	 */
	private void createListView() {
		channelListView = new ChannelListView(this);
		channelListView.setAdapter(listDataMap);
		channelListView.setParent(menuListLayout);
		channelListView.render();
		channelListView.setOnSelectChannelListener(new OnSelectChannel() {
			@Override
			public void onSeleced(HashMap<String, Object> hasMap) {
				String from = (String) hasMap.get("from");
				if (from.equals(currentListType)) {
					hasMap.put("isAlpha", true);
					int i = menuDataMap.size();
					menuDataMap.add(i, hasMap);
					dragDropGrid.removeAllViews();
					dragDropGrid.setAdapter(menuDataMap);
					dragDropGrid.render();
					updateToolTip();
				}
			}

		});
	}

	/**
	 * 变更数据顺序
	 * 
	 * @param begin
	 * @param end
	 */
	private void swapDataPositon(int begin, int end) {
		HashMap<String, Object> tempMap = menuDataMap.get(begin);
		menuDataMap.remove(begin);
		menuDataMap.add(end, tempMap);
	}

	/**
	 * 改变数据状态
	 * 
	 * @param tempMap
	 */
	private void setChannelsDataValue(HashMap<String, Object> tempMap, String key, Object value) {
		int count = allChannelsData.size();
		for (int index = 0; index < count; index++) {
			HashMap<String, Object> map = allChannelsData.get(index);
			String childName = (String) map.get("chlid");
			String tmpChildName = (String) tempMap.get("chlid");
			if (childName != null && childName.equals(tmpChildName)) {
				map.put(key, value);
				allChannelsData.set(index, map);
			}
		}
	}

	/**
	 * 删除已选菜单数据
	 */
	private void removeMenuDataIndex(int index) {
		HashMap<String, Object> tempMap = menuDataMap.get(index);
		String from = (String) tempMap.get("from");
		if (from.equals(currentListType)) {
			channelListView.show(tempMap);
		} else {
			setChannelsDataValue(tempMap, "isSelected", false);
		}
		menuDataMap.remove(index);
	}

	/**
	 * 绑定事件
	 */
	private void bindDragEvent(View v) {
		v.setOnTouchListener(this);
		v.setOnClickListener(null);
	}

	/**
	 * 初始化
	 */
	private void initViews() {
		selectedMenuBtnLayout = (LinearLayout) findViewById(R.id.selectedMenuBtnLayout);
		dragButton = (Button) findViewById(R.id.dragButton);
		moreChannelBar = (LinearLayout) findViewById(R.id.MoreChannelBar);
		menuSettingCompleteBtn = (Button) findViewById(R.id.menuSettingCompleteBtn);
		monitoredSwitch = (Switch) findViewById(R.id.monitoredSwitch);
		scrollView = (InterceptScrollView) findViewById(R.id.scrollView);
		menuListLayout = (LinearLayout) findViewById(R.id.menuListLayout);

		settingTitle = (RelativeLayout) findViewById(R.id.settingTitle);
		dragContainer = (FrameLayout) findViewById(R.id.dragContainer);
		// themeSettingsHelper.setViewBackgroudColor(this, this.dragContainer,
		// R.color.dragContainer_color);
		toolTips = (TextView) findViewById(R.id.toolTips);
		createDragDropGrid();
		dragDropGridListener();
		createListView();
	}

	/**
	 * 获取顶部偏移
	 * 
	 * @return
	 */
	private int getParentY() {
		return MobileUtil.dpToPx(45) + MobileUtil.dpToPx(TOP_OFFSET) - scrollView.getScrollY();
	}

	/**
	 * 初始化事件监听
	 */
	private void initListener() {
		menuSettingCompleteBtn.setOnClickListener(this);
		monitoredSwitch.setOnClickListener(this);

		/**
		 * 监听移动动画是否完成
		 */
		dragDropGrid.setOnTranslateAnimationListener(new OnTranslateAnimation() {
			@Override
			public void onAnimationStart(Animation animation) {
			}

			@Override
			public void onAnimationEnd(Animation animation) {
				if (isAtTheSameTime) {
					removeMenuBtnEnd();
				} else {
					new Handler().post(new Runnable() {
						public void run() {
							swapDataPositon(dragIndex, lastDragIndex);
							dragDropGrid.setAdapter(menuDataMap);
							dragIndex = lastDragIndex;
							dragDropGrid.reLayout();
						}
					});
				}
			}
		});

		/**
		 * 监听gridView重绘
		 */
		dragDropGrid.setOnLayoutEventListener(new OnLayoutEvent() {
			@Override
			public void OnLayoutEnd() {
				Log.i("isMenuBtnMoving", "OnLayoutEnd");
				isDragMoving = false;
			}
		});

	}

	/**
	 * 取消频道选择以后，触发
	 */
	private void removeMenuBtnEnd() {
		removeMenuDataIndex(dragIndex);
		dragDropGrid.setAdapter(menuDataMap);
		new Handler().post(new Runnable() {
			public void run() {
				dragDropGrid.reLayout();
				dragDropGrid.removeAllViews();
				dragDropGrid.render();
				isLastIndex = false;
				updateToolTip();
				isAtTheSameTime = false;
			}
		});
	}

	/**
	 * 监听dragDropGrid内容变化
	 */
	private void dragDropGridListener() {
		/**
		 * 监听layout布局完成
		 */
		dragDropGrid.getViewTreeObserver().addOnGlobalLayoutListener(new OnGlobalLayoutListener() {
			@Override
			public void onGlobalLayout() {
				if (viewGroupHeight == -1) {
					viewGroupHeight = dragDropGrid.getLastHeigh();
				}
				lastViewGroupHeight = dragDropGrid.getLastHeigh();
				if (viewGroupHeight != lastViewGroupHeight) {
					dragDropGirdResizeHeight();
					viewGroupHeight = lastViewGroupHeight;
				}
			}
		});
	}

	/**
	 * 动画调整大小
	 */
	private void dragDropGirdResizeHeight() {
		ResizeHeightAnimation resizeAnimation = new ResizeHeightAnimation(dragDropGrid, viewGroupHeight, lastViewGroupHeight);
		resizeAnimation.setDuration(600);
		dragDropGrid.startAnimation(resizeAnimation);
	}

	/**
	 * 判断所有的动画是否结束
	 * 
	 * @return boolean
	 */
	private boolean isAllAniateEnd() {
		return !isMenuBtnMoving && !isDragBtnMoving;
	}

	/**
	 * 全局监听事件点击
	 * 
	 * @param v
	 * @return
	 */
	@Override
	public void onClick(View v) {
		switch (v.getId()) {

		case R.id.menuSettingCompleteBtn:
			if (isAllAniateEnd()) {
				setOrderChannelData();
				Intent i = new Intent();
				Bundle bundle = new Bundle();
				ListMapData selectedChannels = allChannels;
				bundle.putSerializable(Constants.SUB_CHANNEL, selectedChannels);
				i.putExtras(bundle);
				setResult(RESULT_OK, i);
				quitActivity();
			}
			break;
		case R.id.monitoredSwitch:
			Switch switchButton = (Switch) v;
			if (channelListView.onSelectAnimation) {
				switchButton.setChecked(!switchButton.isChecked());
			} else {
				if (switchButton.isChecked()) {
					currentListType = "channellist";
					renderListView();
				} else {
					currentListType = "local_chllist";
					renderListView();
				}
			}
			break;
		default:
		}
	}

	@Override
	public boolean dispatchKeyEvent(KeyEvent event) {
		if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
			if (isAllAniateEnd()) {
				setOrderChannelData();
				Intent i = new Intent();
				Bundle bundle = new Bundle();
				ListMapData selectedChannels = allChannels;
				bundle.putSerializable(Constants.SUB_CHANNEL, selectedChannels);
				i.putExtras(bundle);
				setResult(RESULT_OK, i);
			}
			quitActivity();
		}
		return super.dispatchKeyEvent(event);
	}

	/**
	 * 初始化线程
	 */
	Runnable touchLongPressRunnable = new Runnable() {
		@Override
		public void run() {
			if (dragged == DRAGGED_DISABLE) {
				Log.i("onTouchEventLog", "touchLongPressRunnable");
				scrollView.disable();
				startDrag(startDragView, lastTouchX, lastTouchY);
				dragged = MenuSettingActivity.DRAGGED_ENABLE;
			}
		}
	};

	/**
	 * Remove the longpress detection timer.
	 */
	private void removeLongPressCallback() {
		if (touchLongPressRunnable != null) {
			longClickHandler.removeCallbacks(touchLongPressRunnable);
		}
	}

	/**
	 * 监听触摸事件, 动画播放过程中，禁止监听
	 * 
	 * @param v
	 * @return
	 */
	@Override
	public boolean onTouch(View view, MotionEvent event) {
		if (isMenuBtnMoving || isDragBtnMoving || channelListView.onSelectAnimation) {
			return false;
		}
		if (event.getPointerCount() > 1) {
			return false;
		}
		lastTouchX = (int) event.getRawX();
		lastTouchY = (int) event.getRawY();
		View v = dragDropGrid.canDrag(lastTouchX, lastTouchY);
		Boolean flag = (v != null || dragged == DRAGGED_ENABLE) ? true : false;
		int action = event.getAction();
		switch (action) {
		case MotionEvent.ACTION_MOVE:
			Log.i("onTouchEventLog", "ACTION_MOVE");
			if (flag) {
				if (dragged == DRAGGED_ENABLE) {
					touchMove(event);
				}
				if (isMoved() && !isTouchMoved) {
					isTouchMoved = true;
					longClickHandler.postDelayed(touchLongPressRunnable, LONG_PRESS_TIMEOUT);
				}
			}
			return false;
		case MotionEvent.ACTION_CANCEL:
			Log.i("onTouchEventLog", "ACTION_CANCEL");
		case MotionEvent.ACTION_UP:
			Log.i("onTouchEventLog", "ACTION_UP");
			clickEndTime = System.currentTimeMillis();
			touchUp(event);
			dragged = DRAGGED_DISABLE;
			scrollView.enable();
			removeLongPressCallback();
			return false;
		case MotionEvent.ACTION_DOWN:
			Log.i("onTouchEventLog", "ACTION_DOWN");
			if (flag) {
				isTouchMoved = false;
				dragged = DRAGGED_DISABLE;
				clickBeginTime = System.currentTimeMillis();
				if (!isDragMoving) {
					touchDown(v, event);
					startDragView = v;
					longClickHandler.postDelayed(touchLongPressRunnable, LONG_PRESS_TIMEOUT);
				}
			}
			return true;
		default:
			return false;
		}
	}

	/**
	 * 拖动开始时初始化坐标位置
	 * 
	 * @param event
	 */
	private void touchDown(View v, MotionEvent event) {
		initialX = (int) event.getRawX();
		initialY = (int) event.getRawY();
		if (v != null) {
			currentX = v.getLeft();
			currentY = v.getTop();
		}
		tempX = initialX;
		tempY = initialY;
		dragIndex = dragDropGrid.positionForView(initialX, initialY);
	}

	/**
	 * 开始拖拽, 复制一个按钮进行拖动
	 * 
	 * @param bm
	 * @param x
	 * @param y
	 */
	private void startDrag(View btn, int x, int y) {
		if (dragIndex != DRAGGED_DISABLE && btn != null) {
			origButton = (Button) btn;
			dragButton = (Button) findViewById(R.id.dragButton);
			dragButton.setText(String.valueOf(origButton.getText()));
			FrameLayout.LayoutParams ll = new FrameLayout.LayoutParams(MobileUtil.dpToPx(DragDropGrid.BUTTON_WIDTH_DP), LayoutParams.WRAP_CONTENT);
			ll.gravity = Gravity.TOP;
			int w = MobileUtil.dpToPx(DragDropGrid.BUTTON_WIDTH_DP);
			int h = MobileUtil.dpToPx(DragDropGrid.BUTTON_HEIGHT_DP);
			ll.width = (int) (w * 1.1);
			ll.height = (int) (h * 1.3);
			int left = currentX - (int) (w * 0.1) / 2;
			int top = (int) ((int) (currentY + getParentY()) - Math.ceil((h * 0.3) / 2));
			ll.setMargins(left, top, 0, 0);
			dragButton.setVisibility(View.VISIBLE);
			dragButton.setLayoutParams(ll);
			dragButton.getParent().bringChildToFront(dragButton);
			// themeSettingsHelper =
			// ThemeSettingsHelper.getThemeSettingsHelper(this);
			if (themeSettingsHelper.isDefaultTheme()) {
				origButton.setTextColor(getResources().getColor(R.color.menusetting_start_drag_color));
				origButton.setBackgroundResource(R.drawable.custom_menu_dotted_line_btn);
			} else {
				// //
				dragButton.setBackgroundResource(R.drawable.night_custom_menu_button);
				dragButton.setTextColor(getResources().getColor(R.color.night_custom_menu_button_color));
				// //
				origButton.setTextColor(getResources().getColor(R.color.night_menusetting_start_drag_color));
				origButton.setBackgroundResource(R.drawable.night_custom_menu_dotted_line_btn);
			}

		}
	}

	/**
	 * 拖动过程中事件处理
	 * 
	 * @param event
	 */
	private void touchMove(MotionEvent event) {
		if (dragButton != null) {
			canDrag();
			Log.i("touchMoveValue", "lastTouchY" + lastTouchY);
			Log.i("touchMoveValue", "tempY" + tempY);
			onDrag(tempX, tempY);
		}
		if (!isDragMoving) {
			lastDragIndex = dragDropGrid.positionForView(lastTouchX, lastTouchY);
			if (lastDragIndex > 0 && dragIndex > 0 && lastDragIndex != dragIndex) {
				isDragMoving = true;
				dragDropGrid.stepAnimateByOrder(dragIndex, lastDragIndex, true);
			}
		}
	}

	/**
	 * 是否可以拖拽
	 * 
	 * @return
	 */
	private void canDrag() {
		Rect rect = new Rect();
		Display gd = getWindowManager().getDefaultDisplay();
		rect.top = getParentY();
		rect.left = 0;
		rect.right = gd.getWidth() - dragButton.getMeasuredWidth();
		rect.bottom = gd.getHeight() - dragButton.getMeasuredHeight();
		int x = lastTouchX - initialX + currentX;
		int y = lastTouchY - initialY + currentY + getParentY() + MobileUtil.dpToPx(TOP_OFFSET);
		if (x > rect.left && x < rect.right) {
			tempX = lastTouchX;
		}
		if (y > rect.top && y < rect.bottom) {
			tempY = lastTouchY;
		}
	}

	/**
	 * 开始拖动复制后的图片
	 * 
	 * @param x
	 * @param y
	 */
	private void onDrag(int x, int y) {
		if (dragButton != null && isAllAniateEnd()) {
			dragButton.setVisibility(View.VISIBLE);
			FrameLayout.LayoutParams ll = new FrameLayout.LayoutParams(MobileUtil.dpToPx(DragDropGrid.BUTTON_WIDTH_DP), LayoutParams.WRAP_CONTENT);
			ll.gravity = Gravity.TOP;
			int w = MobileUtil.dpToPx(DragDropGrid.BUTTON_WIDTH_DP);
			int h = MobileUtil.dpToPx(DragDropGrid.BUTTON_HEIGHT_DP);
			ll.width = (int) (w * 1.1);
			ll.height = (int) (h * 1.3);
			int left = x - initialX + currentX - (int) (w * 0.1) / 2;
			int top = (int) ((int) (y - initialY + currentY + getParentY()) - Math.ceil((h * 0.3) / 2));
			ll.setMargins(left, top, 0, 0);
			dragButton.setLayoutParams(ll);
		}
	}

	/**
	 * 拖动结束事件处理
	 * 
	 * @param event
	 */
	private void touchUp(MotionEvent event) {
		if (dragIndex != DRAGGED_DISABLE) {
			onRelease();
		}
	}

	/**
	 * 触屏完毕以后动作进行
	 */
	private void onRelease() {
		if (dragged == DRAGGED_ENABLE) {
			if (!isInDragDropGridView() && enableDelete()) {
				handler.postDelayed(removeMenuRunnable, 10);
			} else {
				handler.postDelayed(removeDragBtnRunnable, 10);
			}
		} else {
			if (isTap() && enableDelete()) {
				startDrag(startDragView, lastTouchX, lastTouchY);
				handler.postDelayed(removeMenuRunnable, 10);
			}
		}
	}

	/**
	 * 更新提示状态
	 */
	private void updateToolTip() {
		if (enableDelete()) {
			showTips(R.string.menu_setting_nav_tips);
		} else {
			showTips(R.string.menu_setting_limit_tips);
		}
	}

	/**
	 * 提示信息
	 * 
	 * @param txt
	 */
	private void showTips(int txt) {
		TextView toolTips = (TextView) findViewById(R.id.toolTips);
		toolTips.setText(txt);
	}

	/**
	 * 判断是否满足条件删除已定制
	 * 
	 * @return
	 */
	private boolean enableDelete() {
		int count = menuDataMap.size();
		return (count > DragDropGrid.DISABLE_DRAG_NUM) ? true : false;
	}

	/**
	 * 是否是轻点, 鼠标坐标点未上移
	 * 
	 * @return
	 */
	private boolean isTap() {
		boolean isTap = Math.abs(clickEndTime - clickBeginTime) < CLICK_TIME ? true : false;
		return isTap && !isMoved();
	}

	/**
	 * 是否移动超过一个距离
	 * 
	 * @return
	 */
	private boolean isMoved() {
		return Math.abs(lastTouchX - initialX) > TOUCH_SLOP || Math.abs(lastTouchY - initialY) > TOUCH_SLOP;
	}

	/**
	 * 动画移除菜单完成过程中，需要等待移位动画完成
	 */
	private void initRemoveDragBtnRunnable() {
		removeDragBtnRunnable = new Runnable() {
			@Override
			public void run() {
				if (dragIndex == DRAGGED_DISABLE) {
					return;
				}
				if (isDragMoving) {
					handler.postDelayed(this, 10);
				} else {
					animateRemoveDragBtn();
					handler.removeCallbacks(removeDragBtnRunnable);
				}
			}
		};
	}

	/**
	 * 动画移除菜单完成过程中，需要等待移位动画完成
	 */
	private void initRemoveMenuRunnable() {
		removeMenuRunnable = new Runnable() {
			@Override
			public void run() {
				if (dragIndex == DRAGGED_DISABLE) {
					return;
				}
				if (isDragMoving) {
					handler.postDelayed(this, 10);
				} else {
					isAtTheSameTime = true;
					isDragMoving = true;
					isMenuBtnMoving = true;
					if (dragIndex == dragDropGrid.getChildCount() - 1) {
						isLastIndex = true;
					} else {
						isLastIndex = false;
					}
					animateRemoveMenuBtn();
					dragDropGrid.stepAnimateByOrder(dragIndex, dragDropGrid.getChildCount() - 1, false);
					handler.removeCallbacks(removeMenuRunnable);
				}
			}
		};
	}

	/**
	 * 判断是否在grid容器中
	 * 
	 * @return
	 */
	private boolean isInDragDropGridView() {
		Rect rect = new Rect();
		dragDropGrid.getGlobalVisibleRect(rect);
		rect.top = rect.top - MobileUtil.dpToPx(TOP_OFFSET) - getParentY();
		rect.bottom = rect.bottom + MobileUtil.dpToPx(26);
		return rect.contains(lastTouchX, lastTouchY);
	}

	/**
	 * 移除正在拖拽的按钮
	 */
	private void removeDragBtn() {
		if (dragButton != null) {
			dragButton.setVisibility(View.INVISIBLE);
			dragButton = null;
		}
	}

	/**
	 * 恢复原按钮样式
	 */
	private void resumeOrigButton() {
		if (origButton != null) {
			themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(this);
			if (themeSettingsHelper.isDefaultTheme()) {
				origButton.setTextColor(getResources().getColor(R.color.menusetting_resumeorigbutton_color));
				origButton.setBackgroundResource(R.drawable.custom_menu_button);
			} else {
				origButton.setTextColor(getResources().getColor(R.color.night_menusetting_resumeorigbutton_color));
				origButton.setBackgroundResource(R.drawable.night_custom_menu_button);
			}

			origButton = null;
		}
	}

	/**
	 * 动画移除菜单按钮
	 * 
	 * @param <isLastIndex>
	 */
	private void animateRemoveMenuBtn() {
		if (dragButton != null) {
			Point oldXY = getViewPosition(dragButton);
			Point pos = getViewPosition(moreChannelBar);
			HashMap<String, Object> tempMap = menuDataMap.get(dragIndex);
			String from = (String) tempMap.get("from");
			if (from.equals("channellist")) {
				pos.x = pos.x - moreChannelBar.getMeasuredWidth() / 6;
			} else {
				pos.x = pos.x + moreChannelBar.getMeasuredWidth() / 6;
			}
			Point newXY = pos;
			Point oldOffset = new Point(0, 0);
			Point newOffset = computeTranslationEndDeltaRelativeToRealViewPosition(oldXY, newXY);
			AnimationListener aListener = new AnimationListener() {
				/**
				 * 动画结束后执行
				 */
				public void onAnimationEnd(Animation animation) {
					if (isLastIndex) {
						removeMenuBtnEnd();
					}
					removeDragBtn();
					isMenuBtnMoving = false;
				}

				public void onAnimationRepeat(Animation animation) {
				}

				public void onAnimationStart(Animation animation) {
				}

			};
			animateMoveToNewPosition(dragButton, oldOffset, newOffset, aListener);
		}
	}

	/**
	 * 动画移除正在拖拽按钮 复原正在拖拽的按钮
	 */
	private void animateRemoveDragBtn() {
		if (dragButton != null) {
			isDragBtnMoving = true;
			Point oldXY = getViewPosition(dragButton);
			Point newXY = getViewPosition(origButton);
			Point oldOffset = new Point(0, 0);
			Point newOffset = computeTranslationEndDeltaRelativeToRealViewPosition(oldXY, newXY);
			AnimationListener aListener = new AnimationListener() {
				/**
				 * 动画结束后执行
				 */
				public void onAnimationEnd(Animation animation) {
					removeDragBtn();
					resumeOrigButton();
					isDragBtnMoving = false;
				}

				public void onAnimationRepeat(Animation animation) {

				}

				public void onAnimationStart(Animation animation) {
					isDragBtnMoving = true;
				}
			};
			animateMoveToNewPosition(dragButton, oldOffset, newOffset, aListener);
		}
	}

	/**
	 * 获取某个view容器中心位置的x和y坐标
	 * 
	 * @param v
	 * @return
	 */
	private Point getViewPosition(View v) {
		Rect rect = new Rect();
		if (v != null) {
			v.getGlobalVisibleRect(rect);
			int x = rect.left + v.getWidth() / 2;
			int y = rect.top + v.getHeight() / 2;
			return new Point(x, y);
		} else {
			return new Point(0, 0);
		}
	}

	/**
	 * 动画view到某个位置
	 * 
	 * @param targetView
	 * @param oldOffset
	 * @param newOffset
	 */
	private void animateMoveToNewPosition(View targetView, Point oldOffset, Point newOffset, AnimationListener aListener) {
		AnimationSet set = new AnimationSet(true);
		if (!isDragBtnMoving) {
			AlphaAnimation animationAlpha = new AlphaAnimation(1.0f, 0.0f);
			animationAlpha.setDuration(TRANSLATE_ANIMATION_DURATION);
			set.addAnimation(animationAlpha);
		}
		Animation translate = createTranslateAnimation(oldOffset, newOffset, aListener);
		set.addAnimation(translate);
		targetView.clearAnimation();
		targetView.startAnimation(set);
	}

	/**
	 * 计算2个点之间的相对位移
	 * 
	 * @param oldXY
	 * @param newXY
	 * @return
	 */
	private Point computeTranslationEndDeltaRelativeToRealViewPosition(Point oldXY, Point newXY) {
		return new Point(newXY.x - oldXY.x, newXY.y - oldXY.y);
	}

	/**
	 * 创建一个移动动画
	 */
	private TranslateAnimation createTranslateAnimation(Point oldOffset, Point newOffset, AnimationListener aListener) {
		TranslateAnimation translate = new TranslateAnimation(oldOffset.x, newOffset.x, oldOffset.y, newOffset.y);
		if (isDragBtnMoving) {
			translate.setDuration(TRANSLATE_DRAGBTN_ANIMATION_DURATION);
		} else {
			translate.setDuration(TRANSLATE_ANIMATION_DURATION);
		}
		translate.setFillEnabled(true);
		translate.setFillAfter(true);
		translate.setInterpolator(new AccelerateDecelerateInterpolator());
		translate.setAnimationListener(aListener);
		return translate;
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		menuDataMap.clear();
		menuDataMap = null;
		listDataMap.clear();
		listDataMap = null;
		allChannelsData.clear();
		allChannelsData = null;
		dragDropGrid = null;
		dragButton = null;
		origButton = null;
		dragIndex = DRAGGED_DISABLE;
	}

	/**
	 * 从其它界面进入时，重绘一下当前页面
	 */
	@Override
	public void onResume() {
		super.onResume();
		WebDev.onResume(this);
		onRelease();
	}

	@Override
	public void applyTheme() {
		// Auto-generated method stub
		themeSettingsHelper.setViewBackgroudColor(this, mMask, R.color.mask_page_color);
		themeSettingsHelper.setViewBackgroud(this, this.settingTitle, R.drawable.title_bar_bg);
		themeSettingsHelper.setViewBackgroud(this, this.menuSettingCompleteBtn, R.drawable.title_complete_btn);
		themeSettingsHelper.setViewBackgroudColor(this, this.dragContainer, R.color.dragContainer_color);
		themeSettingsHelper.setViewBackgroudColor(this, this.scrollView, R.color.scrollView_color);
		themeSettingsHelper.setViewBackgroudColor(this, this.menuListLayout, R.color.menuListLayout_color);
		themeSettingsHelper.setTextViewColor(this, this.toolTips, R.color.menu_setting_nav_tips_color);
		themeSettingsHelper.setViewBackgroud(this, this.moreChannelBar, R.drawable.custom_channel_more_floor);
		// monitoredSwitch
		/*
		 * if(themeSettingsHelper.isDefaultTheme()){ setTheme(R.style.NoShade);
		 * } else{ setTheme(R.style.NoShade2); }
		 */
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}
}