
package com.tencent.news.ui.view;
/** 
 * @author jianhu
 * @version 创建时间2013-5-10 上午10:09:20
 * 带文字和点击态的进度条按钮
 */
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.ProgressBar;

import com.tencent.news.utils.MobileUtil;
 
public class TextProgressBar extends ProgressBar {
	
    private Paint textPaint;
	private String mText = "";
	private int mTextColor;
	private float mTextSize = MobileUtil.dpToPx(14);
 
    public TextProgressBar(Context context) {
        super(context);
        init();
    }
 
    public TextProgressBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }
 
    public TextProgressBar(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }
    
    private void init(){
        textPaint = new Paint();
        textPaint.setColor(Color.BLACK);
    }

	public void setTextSize(float size) {
		mTextSize = size;
	}

	private void drawText(Canvas canvas){
		
        Rect bounds = new Rect();
        textPaint.setColor(mTextColor);
        textPaint.setTextSize(mTextSize);
        textPaint.setAntiAlias(true);
        textPaint.getTextBounds(mText, 0, mText.length(), bounds);
        int x = getWidth() / 2 - bounds.centerX();
        int y = getHeight() / 2 - bounds.centerY();
        canvas.drawText(mText, x, y, textPaint);
        
        Log.v("vincesun", "draw!!!!!");
	}
	
    @Override
    protected synchronized void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        drawText(canvas);
    }
 
    public synchronized void setText(String text) {
    	mText = text;
        //drawableStateChanged();
       invalidate();
    }
 
    public synchronized void setTextColor(int color) {
		mTextColor = color;
        //drawableStateChanged();
        invalidate();
    }
}