package com.tencent.news.ui.view;

import java.util.Random;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.config.Constants;
import com.tencent.news.model.pojo.Comment;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.shareprefrence.SpForbidenCommentNews;
import com.tencent.news.utils.ThemeSettingsHelper;

public class CommentView extends RelativeLayout {

	private Context context;
	private RelativeLayout mCommentViewRoot = null;
	private WritingCommentView mWritingCommentView = null;
	private CommentListView mCommentListView = null;
	private TextView commentViewTips = null;
	private ImageView mClickLoadComment = null;
	private RelativeLayout offline_loading_layout;
	private boolean isRelateNews;
	private String channelId;
	private Item mItem;
	private boolean isOffline = false;
	private ThemeSettingsHelper themeSettingsHelper = null;

	private Handler mHandler = new Handler() {

		@Override
		public void dispatchMessage(Message msg) {
			switch (msg.what) {
			case Constants.FORBID_COMMENT:

				forbid();

				break;
			case Constants.REFRESH_COMMENT_NUM:
				commentViewTips.setVisibility(View.GONE);

				break;
			case Constants.TIPS_NO_MORE_COMMENTS:
				break;
			}
			super.dispatchMessage(msg);
		}

	};

	private void forbid() {

		SpForbidenCommentNews.saveForbidenCommentNews(mItem.getId());

		String tips = null;
		Random r = new Random();
		switch (r.nextInt(7)) {
		case 0:
			tips = "本新闻已调成静音模式";
			break;
		case 1:
			tips = "囧,这事儿不让说三道四了";
			break;
		case 2:
			tips = "此楼遭遇拆迁";
			break;
		case 3:
			tips = "此评论今天限号禁止出行";
			break;
		case 4:
			tips = "不言不语都是好风景";
			break;
		case 5:
			tips = "无声胜有声";
			break;
		default:
			tips = "评论已关闭";
		}
		mCommentListView.setVisibility(View.GONE);
		offline_loading_layout.setVisibility(View.GONE);
		commentViewTips.setVisibility(View.VISIBLE);
		commentViewTips.setText(tips);

		if (mWritingCommentView != null) {
			mWritingCommentView.setCommentNum(-1);
			mWritingCommentView.refreshUI();
		}
	}
	
	public CommentView(Context context) {
		this(context, null);
	}

	public CommentView(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public CommentView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		this.context = context;
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(context);
		initView();
	}

	/**
	 * 从布局文件中取到CommentBar之后,必须调用这个方法初始化:<br/>
	 * 形如<br/>
	 * <code>
	 * mCommentBar = (CommentBar) findViewById(R.id.comment_bar);<br/>
	 * mCommentBar.init(mItem);
	 * </code>
	 * 
	 * @param mItem
	 *            评论列表的属主
	 * @param mWritingCommentView
	 */
	public void init(String channelId, Item mItem) {
		this.channelId = channelId;
		this.mItem = mItem;
		if (mCommentListView != null) {
			mCommentListView.setmItem(mItem);
			mCommentListView.setChannelId(channelId);
		}
	}
	
	public void setOffline(){
		this.isOffline = true;
		mCommentListView.setVisibility(View.GONE);
		offline_loading_layout.setVisibility(View.VISIBLE);
	}

	private void initView() {
		LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		inflater.inflate(R.layout.view_comment, this, true);

		mCommentViewRoot = (RelativeLayout) findViewById(R.id.comment_layout);
		mCommentListView = (CommentListView) findViewById(R.id.comment_list);
		commentViewTips = (TextView) findViewById(R.id.commentViewTips);
		mClickLoadComment = (ImageView) findViewById(R.id.offline_download_comment);
		offline_loading_layout = (RelativeLayout) findViewById(R.id.offline_comment_loading_layout);
		mCommentListView.setmHandler(mHandler);
		
		themeSettingsHelper.setImageViewSrc(context, mClickLoadComment, R.drawable.offline_download_comment);
		themeSettingsHelper.setViewBackgroudColor(context, commentViewTips, R.color.comment_list_background_color);
		themeSettingsHelper.setViewBackgroudColor(context, mCommentViewRoot, R.color.comment_list_background_color);		

		initListener();
	}

	private void initListener() {

		mCommentListView.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				return mCommentListView.getmListView().dispatchTouchEvent(event);
			}
		});
		
		offline_loading_layout.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				offline_loading_layout.setVisibility(View.GONE);
				mCommentListView.setVisibility(View.VISIBLE);
				getComments();
			}
			
		});

	}

	public boolean isBusy() {
		if (mCommentListView != null) {
			return mCommentListView.isBusy();
		}
		return false;
	}

	public void addVirtualComment(Comment[] c) {
		if (mCommentListView != null) {
			mCommentListView.addComment(c);
			try {
				mCommentListView.sendRefreshCommentNumBroadcast(mCommentListView.getCurrentDisplayCommentNum() + 1);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * true禁止评论
	 * 
	 * @return
	 */
	public boolean isForbid() {
		if (mItem != null) {
			return SpForbidenCommentNews.getForbidenCommentNews(mItem.getId()) || Constants.FORBID_COMMENT_ID.equals(mItem.getCommentid());
		} else {
			return false;
		}
	}

	public void enterPageThenGetComments(boolean isRelateNews) {
		
		if (isForbid()) {
			forbid();
		}else{
			this.isRelateNews = isRelateNews;
			if(!isOffline){
				getComments();
			}
		}
	}
	
	private void getComments(){
		//收藏内容需获取评论数
		if(mItem.getFavorTimestamp()!=null && mItem.getFavorTimestamp().length()>0){
			this.isRelateNews = true;
		}
		// 网络能用直接加载
		// if (NetStatusReceiver.netStatus !=
		// NetStatusReceiver.NETSTATUS_INAVAILABLE) {
		// 列表刷新,可及时检测到评论是否已关闭
		if (!mCommentListView.isBusy() && mCommentListView.getmListView().getAdapter().getCount() <= 2) {
			if (mItem != null /*&& !Constants.FORBID_COMMENT_ID.equals(mItem.getCommentid())*/) {//后台统计用, 不论是否禁止评论都去拉取一次评论
				mCommentListView.refreshComment();
				mCommentListView.initCommentViewHeader();
				mCommentListView.refreshCommentCount(isRelateNews);
			}
		}
		// }
	}

	public void setWritingCommentView(WritingCommentView mWritingCommentView) {
		this.mWritingCommentView = mWritingCommentView;
	}

	// public void setOnUpAndTranClickLinstener(OnUpAndTranClickLinstener utc) {
	// mCommentListView.setOnUpAndTranClick(utc);
	// }

	public void upToTop() {
		if (mCommentListView != null && mCommentListView.getmListView() != null) {
			mCommentListView.getmListView().setSelection(0);
		}
	}

	/**
	 * 评一下用的img
	 * 
	 * @param img
	 */
	public void setImg(String img) {
		if (mCommentListView != null) {
			mCommentListView.setImgUrl(img);
		}
	}
	
	public void applyTheme(){
	
		if(mCommentListView != null){
			mCommentListView.applyTheme();
		}
	}
}
