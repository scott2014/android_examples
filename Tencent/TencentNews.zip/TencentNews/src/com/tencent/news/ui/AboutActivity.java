package com.tencent.news.ui;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.omg.webdev.WebDev;

public class AboutActivity extends BaseActivity implements OnClickListener {
	private RelativeLayout about_page = null;
	private RelativeLayout about_title = null;
	private Button about_title_btn_back = null;
	private TextView textView1 = null;
	private TextView txtView_about_title = null;
	private TextView txtView_license = null;
	private ImageView icon_copyright = null;
	private View mMask;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_about);
		mMask = (View) findViewById(R.id.mask_view);
		about_page = (RelativeLayout) findViewById(R.id.about_page);
		about_title = (RelativeLayout) findViewById(R.id.about_title);
		about_title_btn_back = (Button) findViewById(R.id.about_title_btn_back);
		textView1 = (TextView) findViewById(R.id.textView1);
		txtView_about_title = (TextView) findViewById(R.id.txtView_about_title);
		icon_copyright = (ImageView) findViewById(R.id.icon_copyright);
		txtView_license = (TextView) findViewById(R.id.text_license);

		txtView_license.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				Intent intent = new Intent(AboutActivity.this, WebBrowserActivity.class);
				intent.putExtra("url", TencentNews.READ_BASE_URL + TencentNews.TENCENT_NEWS_LICENSE);
				intent.putExtra("title", getResources().getString(R.string.license_agreement_title));
				intent.putExtra("backText", getResources().getString(R.string.about));
				intent.putExtra("disable_gesture_quit", true);

				startActivity(intent);
			}
		});
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.about_title_btn_back:
			quitActivity();
			break;
		case R.id.btn_test:
			Runtime runtime = Runtime.getRuntime();
			try {
				runtime.exec("su");
			} catch (Exception e) {
			}
			break;
		default:
			break;
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
			quitActivity();
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_MENU) {
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public void applyTheme() {
		themeSettingsHelper.setViewBackgroudColor(this, about_page, R.color.page_setting_bg_color);
		themeSettingsHelper.setViewBackgroud(this, about_title, R.drawable.title_bar_bg);
		themeSettingsHelper.setViewBackgroud(this, about_title_btn_back, R.drawable.title_back_btn);

		themeSettingsHelper.setTextViewColor(this, textView1, R.color.list_comment_color);

		themeSettingsHelper.setImageViewSrc(this, icon_copyright, R.drawable.copyright);

		if (themeSettingsHelper.isNightTheme()) {
			about_title_btn_back.setTextColor(Color.parseColor("#f0f4f8"));
			txtView_about_title.setTextColor(Color.parseColor("#f0f4f8"));
		} else {
			about_title_btn_back.setTextColor(Color.parseColor("#ffffff"));
			txtView_about_title.setTextColor(Color.parseColor("#ffffff"));
		}

		themeSettingsHelper.setViewBackgroudColor(this, mMask, R.color.mask_page_color);
		themeSettingsHelper.setTextViewColor(this, txtView_license, R.color.about_license_text_color);
	}

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}
}
