package com.tencent.news.ui.view;

import com.tencent.news.R;
import com.tencent.news.utils.ThemeSettingsHelper;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class ViewPagerIndicators extends LinearLayout {

    private Context mContext;
    private int mPageNum = 0;
    private int mCurrentIndicator = 0;
    ThemeSettingsHelper mThemeSettingsHelper;

    public ViewPagerIndicators(Context context, AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
        mThemeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(mContext);
    }

    public ViewPagerIndicators(Context context) {
        super(context);
        mContext = context;
    }

    public void setIndicatorNum(int pageNum) {
        mPageNum = pageNum;

        for (int i = 0; i < mPageNum; i++) {
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT,
                    LayoutParams.WRAP_CONTENT);
            params.setMargins(20, 0, 0, 0);
            ImageView view = new ImageView(mContext);

            if (mThemeSettingsHelper.isNightTheme()) {
                view.setImageResource(R.drawable.rss_point_selected);

            } else {
                view.setImageResource(R.drawable.rss_point);
            }

            this.addView(view, params);
        }

        setFocusIndicator(0);
    }

    public void setFocusIndicator(int index) {
        if (index > (mPageNum - 1)) {
            return;
        }

        // revert current item
        ImageView imgView = (ImageView) this.getChildAt(mCurrentIndicator);
        if (mThemeSettingsHelper.isNightTheme()) {
            imgView.setImageResource(R.drawable.rss_point_selected);

        } else {
            imgView.setImageResource(R.drawable.rss_point);

        }

        // set new focus item
        imgView = (ImageView) this.getChildAt(index);
        if (mThemeSettingsHelper.isNightTheme()) {
            imgView.setImageResource(R.drawable.rss_point);

        } else {
            imgView.setImageResource(R.drawable.rss_point_selected);
        }

        mCurrentIndicator = index;
    }

    public void applyTheme() {
        int size = this.getChildCount();
        ImageView imgView;
        for (int i = 0; i < size; i++) {
            if (i == mCurrentIndicator) {
                imgView = (ImageView) this.getChildAt(mCurrentIndicator);
                if (mThemeSettingsHelper.isNightTheme()) {
                    imgView.setImageResource(R.drawable.rss_point);

                } else {
                    imgView.setImageResource(R.drawable.rss_point_selected);
                }
            } else {
                imgView = (ImageView) this.getChildAt(i);
                if (mThemeSettingsHelper.isNightTheme()) {
                    imgView.setImageResource(R.drawable.rss_point_selected);

                } else {
                    imgView.setImageResource(R.drawable.rss_point);

                }
            }
        }
    }
}
