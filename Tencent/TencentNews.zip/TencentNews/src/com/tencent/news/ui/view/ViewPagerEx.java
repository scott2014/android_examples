package com.tencent.news.ui.view;

import java.lang.reflect.Field;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.animation.Interpolator;

import com.tencent.news.utils.SLog;

public class ViewPagerEx extends ViewPager {
	private onPagerFinishedListener mListener;
	protected ScrollerCustomDuration mScroller = null;
	
	private Boolean isScrollable = true;

	public ViewPagerEx(Context context, AttributeSet attrs) {
		super(context, attrs);
		postInitViewPager(context);
	}
	
	public ViewPagerEx(Context context) {
		super(context);
		postInitViewPager(context);
	}
	
    /**
     * Override the Scroller instance with our own class so we can change the
     * duration
     */
    private void postInitViewPager(Context context) {
        try {
            Class<?> viewpager = ViewPager.class;
            Field scroller = viewpager.getDeclaredField("mScroller");
            scroller.setAccessible(true);
            Field interpolator = viewpager.getDeclaredField("sInterpolator");
            interpolator.setAccessible(true);

            mScroller = new ScrollerCustomDuration(context, (Interpolator) interpolator.get(null));
            scroller.set(this, mScroller);
        } catch (Exception e) {
        	e.printStackTrace();
        }
    }
	
//	@Override
//	public boolean onInterceptTouchEvent(MotionEvent event) {
//		try {
//			return super.onInterceptTouchEvent(event);
//		} catch (Exception e) {
//		}
//		return false;
//	}
	
	@Override
    public boolean onInterceptTouchEvent(MotionEvent event) {
        if (isScrollable == false) {
            return false;
        } else {
            return super.onInterceptTouchEvent(event);
        }
    }
    
    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        if (isScrollable == false) {
            return false;
        } else {
            return super.onTouchEvent(ev);
        }
    }
    
    public boolean isScrollable() {
        return isScrollable;
    }

    public void setScrollable(boolean isScrollable) {
        this.isScrollable = isScrollable;
    }
	
	public void setViewPagerDuration(int Duration){
		mScroller.setDuration(Duration);
	}
	
	@Override
	public void computeScroll() {
		if(mScroller.computeScrollOffset()){
			if(!mScroller.computeScrollOffset()){
				if(mListener != null){
					mListener.onScrollFinished();
					SLog.v("ViewPagerEx", ""+mScroller.computeScrollOffset());
				}
			}
		}
		super.computeScroll();
	}
	
	public void setPagerFinishedListener(onPagerFinishedListener listener){
		this.mListener = listener;
	}
	
	public interface onPagerFinishedListener{
		public void onScrollFinished();
	}
}
