package com.tencent.news.ui.adapter;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.ui.view.TextSizeDialog;
import com.tencent.news.utils.ThemeSettingsHelper;

public class TextSizeAdapter extends BaseAdapter {
	protected Context mContext;
	protected ListView mListView;
	protected List<TextSizeDialog.Item> mDataList;
	protected ThemeSettingsHelper themeSettingsHelper = null; 
	
	public TextSizeAdapter(Context context, ListView listview, List<TextSizeDialog.Item> listItem) {
		mContext = context;
		mListView = listview;
		mDataList = listItem;
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(mContext);	
	}

	public TextSizeDialog.Item getObjectItem(int position) {
		if (mDataList != null && position < mDataList.size()) {
			return mDataList.get(position);
		}
		return null;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		if (mDataList != null) {
			return mDataList.size();
		} else {
			return 0;
		}
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return mDataList.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}
	
	protected static class ViewHolder {
		TextView title;
		ImageView image;
	}

	public void addDataList(List<TextSizeDialog.Item> list) {
		if (this.mDataList != null) {
			this.mDataList.clear();
		} else {
			mDataList = new ArrayList<TextSizeDialog.Item>();
		}
		this.mDataList.addAll(list);
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent)
	{
		ViewHolder holder = null;
		
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = LayoutInflater.from(mContext).inflate(R.layout.textsize_dialog_items, null);
			holder.title = (TextView) convertView.findViewById(R.id.title);
			holder.image = (ImageView) convertView.findViewById(R.id.image);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		
		TextSizeDialog.Item item = mDataList.get(position);
		if (item != null) {
			holder.title.setText(item.title);
			
			if (themeSettingsHelper.isNightTheme()) {
				holder.title.setTextColor(Color.parseColor("#b0b5b8"));
			} else {
				holder.title.setTextColor(Color.parseColor("#000000"));
			}
			
			if (item.checked == true)
				themeSettingsHelper.setImageViewSrc(this.mContext, holder.image, R.drawable.btn_radio_on);
			else
				themeSettingsHelper.setImageViewSrc(this.mContext, holder.image, R.drawable.btn_radio_off);
		}
		
		return convertView;
	}
}
