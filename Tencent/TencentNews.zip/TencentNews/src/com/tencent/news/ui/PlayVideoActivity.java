package com.tencent.news.ui;

import java.util.Properties;
import android.app.KeyguardManager;
import android.app.KeyguardManager.KeyguardLock;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.VideoView;
import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.boss.EventId;
import com.tencent.news.cache.UserDBHelper;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.download.DownloadConstants;
import com.tencent.news.download.DownloadManager;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.model.pojo.UserInfo;
import com.tencent.news.model.pojo.Video;
import com.tencent.news.shareprefrence.SpConfig;
import com.tencent.news.system.Application;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.news.utils.DownloaderStateCallBack;
import com.tencent.news.utils.SLog;
import com.tencent.omg.webdev.WebDev;

public class PlayVideoActivity extends BaseActivity implements OnCompletionListener, OnErrorListener, OnPreparedListener {
	private final static String LOW_CODE_RATE = "100001";
	private final static String HIGH_CODE_RATE = "2";
	private VideoView mVideoView = null;
	private MediaController mMediaController = null;
	private int mPositionWhenPaused = -1;
	private boolean isplaying;
	private LinearLayout mLoadingLayout;
	private String mVid;
	private int nTime = 1;
	private KeyguardManager mKeyguardManager = null;
	private KeyguardLock mKeyguardLock = null;
	private Item mItem;
	private String mChild;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		setContentView(R.layout.play_video_layout);

		// 控制处理锁屏相关状态
		mKeyguardManager = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
		mKeyguardLock = mKeyguardManager.newKeyguardLock("PlayVideoActivity");
		// 监控Home键，恢复锁屏状态
		final IntentFilter mHomeFilter = new IntentFilter(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
		registerReceiver(mHomePressReceiver, mHomeFilter);
		// 初始化，播放态去掉锁屏
		mKeyguardLock.disableKeyguard();

		Intent intent = getIntent();
		if (intent != null) {
			mVid = intent.getStringExtra(Constants.PLAY_VIDEO_VID_KEY);
			// kiddyliu 获取该视频的item
			mItem = (Item) intent.getSerializableExtra(Constants.NEWS_DETAIL_KEY);
			mChild = intent.getStringExtra(Constants.NEWS_CHANNEL_CHLID_KEY);
		}
		InitViews();
		getVideoData(LOW_CODE_RATE);
	}

	@Override
	protected void onStart() {
		// Auto-generated method stub
		sendStatisticsBeginToBoss();
		super.onStart();
	}

	@Override
	protected void onStop() {
		// Auto-generated method stub
		sendStatisticsEndToBoss();
		super.onStop();
	}

	@Override
	protected void onPause() {
		if (mVideoView != null && mVideoView.getVisibility() == View.VISIBLE) {
			isplaying = mVideoView.isPlaying();
			mPositionWhenPaused = mVideoView.getCurrentPosition();
			mKeyguardLock.disableKeyguard();
			mVideoView.pause();

		}
		super.onPause();
		WebDev.onPause(this);
	}

	private final BroadcastReceiver mHomePressReceiver = new BroadcastReceiver() {

		final String SYSTEM_DIALOG_REASON_KEY = "reason";
		final String SYSTEM_DIALOG_REASON_HOME_KEY = "homekey";

		@Override
		public void onReceive(Context context, Intent intent) {
			String action = intent.getAction();

			if (action.equals(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)) {
				String reason = intent.getStringExtra(SYSTEM_DIALOG_REASON_KEY);
				if (reason != null && reason.equals(SYSTEM_DIALOG_REASON_HOME_KEY)) {
					// 判断home键，回复锁屏状态
					mKeyguardLock.reenableKeyguard();
				}
			}
		}

	};

	@Override
	protected void onDestroy() {

		if (mHomePressReceiver != null) {
			unregisterReceiver(mHomePressReceiver);
		}
		mKeyguardLock.reenableKeyguard();
		super.onDestroy();
	}

	@Override
	protected void onResume() {
		if (mVideoView != null && mVideoView.getVisibility() == View.VISIBLE) {
			if (mPositionWhenPaused >= 0) {
				mKeyguardLock.disableKeyguard();
				mVideoView.seekTo(mPositionWhenPaused);
				if (isplaying) {
					mVideoView.start();
				} else {
					mVideoView.pause();
				}
				mPositionWhenPaused = -1;
			}
		}
		super.onResume();
		WebDev.onResume(this);
	}

	private void InitViews() {
		mVideoView = (VideoView) findViewById(R.id.detail_video_view);
		mLoadingLayout = (LinearLayout) findViewById(R.id.loading_layout);
		mMediaController = new MediaController(this);
		mVideoView.setMediaController(mMediaController);
		mVideoView.setOnCompletionListener(this);
		mVideoView.setOnErrorListener(this);
		mVideoView.setOnPreparedListener(this);
		showLoading();
	}

	@Override
	public void onCompletion(MediaPlayer mp) {
		quitActivity();
	}

	@Override
	public boolean onError(MediaPlayer mp, int what, int extra) {
		hideLoading();
		return false;
	}

	@Override
	public void onPrepared(MediaPlayer mp) {
		hideLoading();
	}

	private void showLoading() {
		mLoadingLayout.setVisibility(View.VISIBLE);
	}

	private void hideLoading() {
		mLoadingLayout.setVisibility(View.GONE);
	}

	private void getVideoData(String format) {
		PauseSilentDownload();
		//添加qq登录信息
		String uin=null;
		UserInfo uf = UserDBHelper.getInstance().getUserInfo();
		if(uf!=null){
		    uin = uf.getAccount();
		}
		if(uin==null||uin.length()<1){
		    uin="0";
		}
		//
		HttpDataRequest request = TencentNews.getInstance().getVideoUrl(format, mVid,uin);
		TaskManager.startHttpDataRequset(request, this);
	}

	@Override
	public void onHttpRecvOK(HttpTag tag, Object result) {
		Video video = (Video) result;
		if (video != null && video.getUrl() != null && video.getUrl().length() > 0) {
			nTime = 1;
			mVideoView.setVideoPath(video.getUrl());
			mVideoView.requestFocus();
			mVideoView.start();
		} else {
			nTime++;
			if (nTime > 2) {
			    Log.v("lxn", "nTime="+nTime);
                Log.v("lxn", "getCode="+video.getCode());
                if (video != null && video.getCode() != null && video.getCode().length() > 0) {
                    if (video.getCode().equals("80")) {
                        TipsToast.getInstance().showTipsWarning("由于版权限制，您所在的地区无法观看本视频");
                    } else if (video.getCode().equals("61")) {
                        TipsToast.getInstance().showTipsWarning("视频源不存在");
                    } else if (video.getCode().equals("62")) {
                        TipsToast.getInstance().showTipsWarning("节目暂时不提供播放");
                    } else {
                        TipsToast.getInstance().showTipsWarning(video.getMsg());
                    }
                }
				//TipsToast.getInstance().showTipsWarning(video.getMsg());
				quitActivity();
				return;
			}
			getVideoData(HIGH_CODE_RATE);
		}
	}

	@Override
	public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {
		// TODO Auto-generated method stub
		nTime = 1;
		TipsToast.getInstance().showTipsError(msg);
		quitActivity();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
			quitActivity();
			return true;
		} else if (event.getKeyCode() == KeyEvent.KEYCODE_MENU && event.getRepeatCount() > 0) {
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	private void PauseSilentDownload() {
		int mState = Application.getInstance().getDownloadState();
		SLog.d("hj", "playVideo Downloadstate:" + Integer.toHexString(mState));
		if (mState == DownloadConstants.T_UPDATE_PROGRESS && SpConfig.getSilentDownloadFlag() == Constants.SILENT_START_DOWNLOAD) {
			DownloadManager.getInstance().doStateAction(Constants.APPID, mState, "", "com.tencent.news", "腾讯新闻", DownloaderStateCallBack.getInstance(), "", false);
		}
	}

	/*
	 * private void startSilentDownload(){ int mState =
	 * Application.getInstance().getDownloadState();
	 * 
	 * if(SpConfig.getSilentDownloadFlag() == Constants.SILENT_START_DOWNLOAD &&
	 * mState != DownloadConstants.T_UPDATE_PROGRESS ){ String versionCode = "";
	 * String updateUrl = ""; NewsVersion mVersion =
	 * Application.getInstance().getVersion(); if (mVersion != null) {
	 * versionCode = mVersion.getVersion(); updateUrl = mVersion.getUrl(); }
	 * DownloadManager.getInstance().doStateAction(Constants.APPID, mState,
	 * updateUrl, "com.tencent.news", "腾讯新闻",
	 * DownloaderStateCallBack.getInstance(), versionCode, false); }
	 * 
	 * }
	 */

	private void sendStatisticsBeginToBoss() {
		String strNewsID;
		if (mItem == null) {
			SLog.d("#####sendStatisticsToBoss#####", "mItem is empty!");
			return;
		}
		if (mItem.getId() == null || mItem.getId() == "") {
			strNewsID = "-";
		} else {
			strNewsID = mItem.getId();
		}

		if (mVid == null || mVid == "") {
			mVid = "-";
		}

		if (mChild == null || mChild == "") {
			mChild = "-";
		}

		Properties pts = new Properties();
		pts.setProperty(EventId.KEY_CHANNELID, mChild);
		pts.setProperty(EventId.KEY_NEWSID, strNewsID);
		pts.setProperty(EventId.KEY_VID, mVid);
		pts.setProperty(EventId.KEY_ISLIVE, EventId.VALUE_NOT_LIVE);
		WebDev.trackCustomBeginKVEvent(this, EventId.ITIL_PLAY_VIDEO_TIME, pts);

	}

	private void sendStatisticsEndToBoss() {
		String strNewsID;
		if (mItem == null) {
			SLog.d("#####sendStatisticsToBoss#####", "mItem is empty!");
			return;
		}
		if (mItem.getId() == null || mItem.getId() == "") {
			strNewsID = "-";
		} else {
			strNewsID = mItem.getId();
		}

		if (mVid == null || mVid == "") {
			mVid = "-";
		}

		if (mChild == null || mChild == "") {
			mChild = "-";
		}
		Properties pts = new Properties();
		pts.setProperty(EventId.KEY_CHANNELID, mChild);
		pts.setProperty(EventId.KEY_NEWSID, strNewsID);
		pts.setProperty(EventId.KEY_VID, mVid);
		pts.setProperty(EventId.KEY_ISLIVE, EventId.VALUE_NOT_LIVE);
		WebDev.trackCustomEndKVEvent(this, EventId.ITIL_PLAY_VIDEO_TIME, pts);

	}

}
