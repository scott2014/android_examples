
package com.tencent.news.ui.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.boss.EventId;
import com.tencent.news.command.GetImageRequest;
import com.tencent.news.command.GetImageResponse;
import com.tencent.news.config.Constants;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.model.pojo.Comment;
import com.tencent.news.model.pojo.ImageResult;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.model.pojo.RssCatListItem;
import com.tencent.news.shareprefrence.SpUpComment;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.RssMediaActivity;
import com.tencent.news.ui.WebBrowserActivity;
import com.tencent.news.ui.view.CommentListView;
import com.tencent.news.ui.view.PullRefreshListView;
import com.tencent.news.ui.view.PullRefreshListView.startListener;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.StringUtil;
import com.tencent.news.utils.TextUtil;
import com.tencent.omg.webdev.WebDev;

public class CommentListAdapter extends AbsListAdapter<Comment[]> implements GetImageResponse, startListener,
        OnClickListener {

    private int itemType;
    private int hotNum;
    private int newNum;
    private int userNameMaxLength;
    private int listType; /* kiddyliu 2013-06-21  用来标识是在哪个页面展示点评列表
     * 0：新闻底层页的点评列表 1：我的点评页面的点评列表 2：提到我的页面点评列表*/

    private CommentListView mCommentListView;

    public CommentListAdapter(Context context, ListView listView) {
		this(context, listView, Constants.COMMENT_IN_NEWS_DETAIL_PAGE);
		//this(context, listView, Constants.COMMENT_IN_MYCOMMENT_PAGE);
	}
	
	public CommentListAdapter(Context context, ListView listView, int type) {
		this.mContext = context;
		this.mListView = listView;
		this.listType = type;
		
		mDataList = new ArrayList<Comment[]>();
		((PullRefreshListView) mListView).setSartListener(this);

		SettingInfo settingInfo = SettingObservable.getInstance().getData();
		if (settingInfo != null && settingInfo.isIfTextMode()) {
			itemType = Constants.TYPE_ITEM_TEXT;
		} else {
			itemType = Constants.TYPE_ITEM_IMAGE;
		}

		userNameMaxLength = MobileUtil.getScreenWidthIntPx() / 2;
	} 

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;

        Comment[] comment = mDataList.get(position);

        int type = getItemViewType(position);

        switch (type) {
            case Constants.TYPE_ITEM_TEXT:
                convertView = setTextMode(position, convertView, comment, holder);
                break;
            case Constants.TYPE_ITEM_IMAGE:
                convertView = setImageMode(position, convertView, comment, holder);
                break;
            case Constants.TYPE_ITEM_SECTION:
                convertView = setGroupSection(convertView, comment, holder);
                break;
            default:
                break;
        }
        return convertView;
    }

    @Override
    public int getItemViewType(int position) {
        Comment[] comment = mDataList.get(position);
        if (Constants.TAG_COMMENT_CANTBEUP.equals(comment[0].getReplyId())
                && (Constants.TAG_COMMENT_HOT.equals(comment[0].getUin()) || Constants.TAG_COMMENT_LATEST
                        .equals(comment[0].getUin()))) {
            styleType = Constants.TYPE_ITEM_SECTION;
        } else {
            styleType = itemType;
        }
        return styleType;
    }

    @Override
    public int getViewTypeCount() {
        return 3;
    }

    private View setImageMode(int position, View convertView, Comment[] comment, ViewHolder holder) {
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = LayoutInflater.from(mContext).inflate(R.layout.comment_list_item, null);
            holder.comment_user_icon = (ImageView) convertView.findViewById(R.id.comment_user_icon);
            holder.comment_user_name = (TextView) convertView.findViewById(R.id.comment_list_item_user_name);
            holder.comment_hot = (ImageView) convertView.findViewById(R.id.comment_hot);
            holder.comment_address = (TextView) convertView.findViewById(R.id.comment_address);
            holder.comment_time = (TextView) convertView.findViewById(R.id.comment_time);
            holder.up_icon = (ImageView) convertView.findViewById(R.id.up_icon);
            holder.comment_text = (TextView) convertView.findViewById(R.id.comment_text);
            holder.comment_up_num = (TextView) convertView.findViewById(R.id.comment_up_num);
            holder.comment_user_weibo_icon = (ImageView) convertView.findViewById(R.id.comment_user_weibo_icon);
            holder.comment_user_weibo_icon_verified = (ImageView) convertView.findViewById(R.id.comment_user_weibo_icon_verified);
            holder.article_title = (TextView) convertView.findViewById(R.id.article_title);
            holder.has_deleted = (TextView) convertView.findViewById(R.id.has_deleted);            
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        themeSettingsHelper.setViewBackgroudColor(mContext, convertView, R.color.comment_list_background_color);
        holder.position = position;
        holder.up_icon.setTag(holder);
        holder.comment_user_name.setTag(holder);
        holder.comment_user_icon.setTag(holder);

        if (comment != null) {
            doDiffirence(position, comment, holder);
        }
        return convertView;
    }

    private View setTextMode(int position, View convertView, Comment[] comment, ViewHolder holder) {
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = LayoutInflater.from(mContext).inflate(R.layout.comment_list_text_item, null);
            holder.comment_user_name = (TextView) convertView.findViewById(R.id.comment_user_name);
            holder.comment_hot = (ImageView) convertView.findViewById(R.id.comment_hot);
            holder.comment_address = (TextView) convertView.findViewById(R.id.comment_address);
            holder.comment_time = (TextView) convertView.findViewById(R.id.comment_time);
            holder.up_icon = (ImageView) convertView.findViewById(R.id.up_icon);
            holder.comment_text = (TextView) convertView.findViewById(R.id.comment_text);
            holder.comment_up_num = (TextView) convertView.findViewById(R.id.comment_up_num);
            holder.comment_user_weibo_icon = (ImageView) convertView.findViewById(R.id.comment_user_weibo_icon);
            holder.comment_user_weibo_icon_verified = (ImageView) convertView
                    .findViewById(R.id.comment_user_weibo_icon_verified);
            holder.article_title = (TextView) convertView.findViewById(R.id.article_title);
            holder.has_deleted = (TextView) convertView.findViewById(R.id.has_deleted);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        themeSettingsHelper.setViewBackgroudColor(mContext, convertView, R.color.comment_list_background_color);
        holder.position = position;
        holder.up_icon.setTag(holder);
        holder.comment_user_name.setTag(holder);

        if (comment != null) {
            setTextData(position, comment, holder);
        }

        return convertView;
    }

    private View setGroupSection(View convertView, Comment[] comment, ViewHolder holder) {
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = LayoutInflater.from(mContext).inflate(R.layout.comment_list_group_section_item, null);
            holder.hot_or_new = (TextView) convertView.findViewById(R.id.hot_or_new);
            holder.hot_or_new_num = (TextView) convertView.findViewById(R.id.hot_or_new_num);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        themeSettingsHelper.setViewBackgroud(mContext, convertView, R.drawable.special_report_section_bg_untran);
        themeSettingsHelper.setTextViewColor(mContext, holder.hot_or_new, R.color.comment_group_section_color);
        themeSettingsHelper.setTextViewColor(mContext, holder.hot_or_new_num, R.color.comment_group_section_color);

        holder.id = Constants.TAG_COMMENT_CANTBEUP;

        if (comment != null) {
            setGroupSectionTextData(comment, holder);
        }

        return convertView;
    }

    private static class ViewHolder {
        int position;

        ImageView comment_user_icon = null;
        TextView comment_user_name = null;
        ImageView comment_hot = null;
        TextView comment_address = null;
        TextView comment_time = null;
        ImageView up_icon = null;
        TextView comment_text = null;
        TextView comment_up_num = null;
        TextView article_title = null;
        TextView has_deleted = null;
        String sex = null;
        String id = null;

        ImageView comment_user_weibo_icon = null;
        ImageView comment_user_weibo_icon_verified = null;        

        TextView hot_or_new = null;
        TextView hot_or_new_num = null;
    }

    private void setUserIconMode(ImageResult result, String sex, ViewHolder holder) {
        if (result != null && result.isResultOK() && result.getRetBitmap() != null) {
            holder.comment_user_icon.setImageBitmap(result.getRetBitmap());

            /*
             * if(themeSettingsHelper.isNightTheme()){
             * holder.comment_user_icon.setImageDrawable
             * (ImageUtil.getBlackBitmap(result.getRetBitmap())); }else{
             * holder.comment_user_icon.setImageBitmap(result.getRetBitmap()); }
             */
        } else {
            if (themeSettingsHelper.isNightTheme()) {
                if ("1".equals(sex)) {
                    holder.comment_user_icon.setImageResource(R.drawable.night_default_comment_user_man_icon);
                } else {
                    holder.comment_user_icon.setImageResource(R.drawable.night_default_comment_user_woman_icon);
                }
            } else {
                if ("1".equals(sex)) {
                    holder.comment_user_icon.setImageResource(R.drawable.default_comment_user_man_icon);
                } else {
                    holder.comment_user_icon.setImageResource(R.drawable.default_comment_user_woman_icon);
                }
            }

            /*
             * if(themeSettingsHelper.isNightTheme()){ if (sex.equals("1")) {
             * holder
             * .comment_user_icon.setImageDrawable(ImageUtil.getBlackBitmap(
             * ImageUtil
             * .FromResToBitmap(Application.getInstance().getResources(),
             * R.drawable.default_comment_user_man_icon))); } else {
             * holder.comment_user_icon
             * .setImageDrawable(ImageUtil.getBlackBitmap(
             * ImageUtil.FromResToBitmap
             * (Application.getInstance().getResources(),
             * R.drawable.default_comment_user_woman_icon))); } }else{ if
             * (sex.equals("1")) {
             * holder.comment_user_icon.setImageResource(R.drawable
             * .default_comment_user_man_icon); } else {
             * holder.comment_user_icon
             * .setImageResource(R.drawable.default_comment_user_woman_icon); }
             * }
             */
        }
    }

    protected void setUserHeadIcon(final Comment comment, ViewHolder holder) {
        if (comment.getHeadUrl() == null || comment.getHeadUrl().length() <= 0) {
            if (holder.comment_user_icon != null) {
                setUserIconMode(null, comment.getSex(), holder);
            }
            return;
        }
        GetImageRequest request = new GetImageRequest();
        request.setGzip(false);
        request.setTag(comment.getReplyId());
        if (comment.isOpenMb()) {
            request.setUrl(comment.getMb_head_url());
        } else {
            request.setUrl(comment.getHeadUrl());
        }
        ImageResult result = TaskManager.startSmallImageTask(request, this);
        if (holder.comment_user_icon != null) {
            setUserIconMode(result, comment.getSex(), holder);
            holder.comment_user_icon.setOnClickListener(this);
        }
    }

    private void setTextData(int position, Comment[] comment, ViewHolder holder) {
        int length = comment.length;
        final Comment last1comment = comment[length - 1];
        Comment last2comment = null;
        if (length >= 2) {
            last2comment = comment[length - 2];
        }

        holder.id = last1comment.getReplyId();

        if (holder.comment_user_icon != null) {
            try {
                if (last1comment.getHeadUrl() == null || last1comment.getHeadUrl().length() <= 0) {
                    setUserIconMode(null, last1comment.getSex(), holder);
                    return;
                }
            } catch (OutOfMemoryError e) {

                System.gc();
                setUserIconMode(null, last1comment.getSex(), holder);
            }
        }
        applyTheme(holder);

        if (holder.comment_user_name != null) {
            holder.comment_user_name.setMaxWidth(userNameMaxLength);
            if (last1comment.isOpenMb()) {
                holder.comment_user_name.setText(last1comment.getMb_nick_name());
            } else {
                holder.comment_user_name.setText(last1comment.getNick());
            }
            holder.comment_user_name.setOnClickListener(this);
        }

        if (holder.comment_hot != null) {
            if (last1comment.isHot()) {
                // holder.comment_hot.setVisibility(View.VISIBLE);
            } else {
                holder.comment_hot.setVisibility(View.GONE);
            }
        }
        
        if(this.listType==Constants.COMMENT_IN_MYCOMMENT_PAGE || this.listType==Constants.COMMENT_IN_ATME_COMMENT_PAGE){ 
      		   if( holder.article_title!=null
	      		  && last1comment.getArticleID()!=null 
	      		  && last1comment.getArticleTitle()!=null 
	      		  && last1comment.getArticleTitle().length()>0) {
      			    String strTitle = last1comment.getArticleTitle();
      			    if(strTitle.length()>16){
      			    	strTitle = strTitle.substring(0,14) + "...";
      			    }
	      			holder.article_title.setText("[原文]" + strTitle);
	      			holder.article_title.setVisibility(View.VISIBLE);
      		   }
      		   if(last1comment.getStatus()!=null &&last1comment.getStatus().equals("1")){
      			   holder.has_deleted.setVisibility(View.VISIBLE);
      		   }
        }
        
        if (holder.comment_address != null) {
            holder.comment_address.setText(last1comment.getProvinceCity());
        }
        if (holder.comment_time != null) {
            //holder.comment_time.setText(StringUtil.getPublishTime(Long.parseLong(last1comment.getPubTime() + "000")));
            holder.comment_time.setText(StringUtil.getPublishTime( (long)(Float.parseFloat(last1comment.getPubTime())*1000) ));
        }
        if (holder.comment_up_num != null) {
            holder.comment_up_num.setText(StringUtil.tenTh2wan(last1comment.getAgreeCount()));
        }
        if (holder.comment_text != null) {
            if (themeSettingsHelper.isNightTheme()) {
                TextUtil.formatText(mContext, holder.comment_text, last1comment, last2comment, true);
            } else {
                TextUtil.formatText(mContext, holder.comment_text, last1comment, last2comment, false);
            }
        }

        if (holder.up_icon != null) {
            if (SpUpComment.getUpComment(last1comment.getReplyId())) {
                holder.up_icon.setImageResource(R.drawable.comment_up_highnight);
            } else {
                holder.up_icon.setImageResource(R.drawable.comment_up);
            }
            holder.up_icon.setOnClickListener(this);
        }

        holder.sex = last1comment.getSex();

        this.setWeiBoIcons(last1comment, holder);
    }

    private void setGroupSectionTextData(Comment[] comment, ViewHolder holder) {
        if (holder.hot_or_new != null && comment[0].getReplyId().equals(Constants.TAG_COMMENT_CANTBEUP)) {
            if (comment[0].getUin().equals(Constants.TAG_COMMENT_HOT)) {
                holder.hot_or_new.setText("最热评论");
                holder.hot_or_new_num.setText("(" + hotNum + "条)");
            } else if (comment[0].getUin().equals(Constants.TAG_COMMENT_LATEST)) {
                holder.hot_or_new.setText("最新评论");
                holder.hot_or_new_num.setText("(" + newNum + "条)");
            }
        }
    }

    protected void doDiffirence(int position, Comment[] comment, ViewHolder holder) {

        int length = comment.length;
        final Comment last1comment = comment[length - 1];
        Comment last2comment = null;
        if (length >= 2) {
            last2comment = comment[length - 2];
        }

        holder.id = last1comment.getReplyId();

        try {
            if (!((PullRefreshListView) mListView).isBusy()) {
                setUserHeadIcon(last1comment, holder);
            } else {
                GetImageRequest request = new GetImageRequest();
                request.setGzip(false);
                request.setTag(last1comment.getReplyId());
                if (last1comment.isOpenMb()) {
                    request.setUrl(last1comment.getMb_head_url());
                } else {
                    request.setUrl(last1comment.getHeadUrl());
                }
                ImageResult result = TaskManager.getLocalIconImage(request, this);
                setUserIconMode(result, last1comment.getSex(), holder);
            }

        } catch (OutOfMemoryError e) {

            System.gc();

            if (holder.comment_user_icon != null) {
                setUserIconMode(null, last1comment.getSex(), holder);
            }
        }
        applyTheme(holder);

        if (holder.comment_user_name != null) {
            holder.comment_user_name.setMaxWidth(userNameMaxLength);
            if (last1comment.getMb_nick_name()!=null && last1comment.getMb_nick_name().trim().length()>0 ) {
                holder.comment_user_name.setText(last1comment.getMb_nick_name());
            } else {
                holder.comment_user_name.setText(last1comment.getNick());
            }
            holder.comment_user_name.setOnClickListener(this);
        }

        if (holder.comment_hot != null) {
            if (last1comment.isHot()) {
                // holder.comment_hot.setVisibility(View.VISIBLE);
            } else {
                holder.comment_hot.setVisibility(View.GONE);
            }
        }
        
        if(this.listType==Constants.COMMENT_IN_MYCOMMENT_PAGE || this.listType==Constants.COMMENT_IN_ATME_COMMENT_PAGE){ 
   		   if( holder.article_title!=null
	      		  && last1comment.getArticleID()!=null 
	      		  && last1comment.getArticleTitle()!=null 
	      		  && last1comment.getArticleTitle().length()>0) {   			   
		   			String strTitle = last1comment.getArticleTitle();
				    if(strTitle.length()>16){
				    	strTitle = strTitle.substring(0,14) + "...";
				    }
		  			holder.article_title.setText("[原文]" + strTitle);
	      			holder.article_title.setVisibility(View.VISIBLE);
   		   }
   		   if(last1comment.getStatus()!=null &&last1comment.getStatus().equals("1")){
   			   holder.has_deleted.setVisibility(View.VISIBLE);
   		   }
        }

        if (holder.comment_address != null) {

            holder.comment_address.setText(last1comment.getProvinceCity());
        }
        if (holder.comment_time != null) {
            holder.comment_time.setText(StringUtil.getPublishTime( (long)(Float.parseFloat(last1comment.getPubTime())*1000) ));
        }
        if (holder.comment_up_num != null) {
            holder.comment_up_num.setText(StringUtil.tenTh2wan(last1comment.getAgreeCount()));
        }

        if (holder.comment_text != null) {
            if (themeSettingsHelper.isNightTheme()) {
                TextUtil.formatText(mContext, holder.comment_text, last1comment, last2comment, true);
            } else {
                TextUtil.formatText(mContext, holder.comment_text, last1comment, last2comment, false);
            }
        }

        if (holder.up_icon != null) {
            if (last1comment.isHadUp()) {
                holder.up_icon.setImageResource(R.drawable.comment_up_highnight);
            } else {
                holder.up_icon.setImageResource(R.drawable.comment_up);
            }
            holder.up_icon.setOnClickListener(this);
        }
        holder.sex = last1comment.getSex();

        this.setWeiBoIcons(last1comment, holder);

    }

    @Override
    public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm, String path) {
        switch (imageType) {
            case SMALL_IMAGE:
                int countImage = mListView.getChildCount();
                for (int i = 0; i < countImage; i++) {
                    ViewHolder viewHolder = (ViewHolder) mListView.getChildAt(i).getTag();
                    if (viewHolder != null) {
                        if (((String) tag).equals(viewHolder.id) && viewHolder.comment_user_icon != null) {

                            viewHolder.comment_user_icon.setImageBitmap(bm);

                            /*
                             * if(themeSettingsHelper.isNightTheme()){
                             * viewHolder
                             * .comment_user_icon.setImageDrawable(ImageUtil
                             * .getBlackBitmap(bm)); }else{
                             * viewHolder.comment_user_icon.setImageBitmap(bm);
                             * }
                             */
                            break;
                        }
                    }
                }
                break;
            default:
                break;
        }
    }

    @Override
    public void onImageRecvError(ImageType imageType, Object tag, int retCode) {
        switch (imageType) {
            case SMALL_IMAGE:
                int countImage = mListView.getChildCount();
                for (int i = 0; i < countImage; i++) {
                    ViewHolder viewHolder = (ViewHolder) mListView.getChildAt(i).getTag();
                    if (viewHolder != null) {
                        if (((String) tag).equals(viewHolder.id) && viewHolder.comment_user_icon != null) {
                            setUserIconMode(null, viewHolder.sex, viewHolder);
                            break;
                        }
                    }
                }
                break;
            default:
                break;
        }
    }

    @Override
    public void changeStyleMode(int style) {

    }

    @Override
    public void serListViewBusy(int currPosition, int tag) {
        if (styleType == Constants.TYPE_ITEM_TEXT) {
            return;
        }
        ViewHolder holder = (ViewHolder) mListView.getChildAt(tag).getTag();
        if (currPosition >= 0 && currPosition < mDataList.size() && holder != null) {
            Comment[] comment = mDataList.get(currPosition);
            Comment last1comment = comment[comment.length - 1];
            setUserHeadIcon(last1comment, holder);
        }
    }

    private void setWeiBoIcons(Comment comment, ViewHolder holder) {
        if (holder.comment_user_weibo_icon != null && holder.comment_user_weibo_icon_verified != null) {
            /*
             * if(themeSettingsHelper.isNightTheme()){ if (comment.isOpenMb()) {
             * holder.comment_user_weibo_icon.setVisibility(View.VISIBLE);
             * holder.comment_user_weibo_icon.setImageDrawable(ImageUtil.
             * getBlackBitmapForExpress(
             * mContext.getResources().getDrawable(R.drawable
             * .comment_user_weibo_icon))); } else {
             * holder.comment_user_weibo_icon.setVisibility(View.GONE); } if
             * (comment.isVip()) {
             * holder.comment_user_weibo_icon_verified.setVisibility
             * (View.VISIBLE);
             * holder.comment_user_weibo_icon.setImageDrawable(ImageUtil
             * .getBlackBitmapForExpress(
             * mContext.getResources().getDrawable(R.drawable
             * .comment_weibo_icon_verified_vip)));
             * setWeiboVipDescription(holder, comment); } else if
             * (comment.isGroupVip()) {
             * holder.comment_user_weibo_icon_verified.setVisibility
             * (View.VISIBLE);
             * holder.comment_user_weibo_icon.setImageDrawable(ImageUtil
             * .getBlackBitmapForExpress(
             * mContext.getResources().getDrawable(R.drawable
             * .comment_weibo_icon_verified_group_vip)));
             * setWeiboVipDescription(holder, comment); } else {
             * holder.comment_user_weibo_icon_verified.setVisibility(View.GONE);
             * } }else{
             */
            if (comment.isOpenMb()) {
                holder.comment_user_weibo_icon.setVisibility(View.VISIBLE);
            } else {
                holder.comment_user_weibo_icon.setVisibility(View.GONE);
            }

            if(comment.getMediaID()!=null && !comment.getMediaID().equals("") && !comment.getMediaID().equals("0")){
            	 holder.comment_user_weibo_icon_verified.setVisibility(View.VISIBLE);
                 holder.comment_user_weibo_icon_verified.setImageResource(R.drawable.msg_user_vip_icon);
                 setWeiboVipDescription(holder, comment);
            }else if (comment.isVip()) {
                holder.comment_user_weibo_icon_verified.setVisibility(View.VISIBLE);
                holder.comment_user_weibo_icon_verified.setImageResource(R.drawable.comment_weibo_icon_verified_vip);
                setWeiboVipDescription(holder, comment);
            } else if (comment.isGroupVip()) {
                holder.comment_user_weibo_icon_verified.setVisibility(View.VISIBLE);
                holder.comment_user_weibo_icon_verified
                        .setImageResource(R.drawable.comment_weibo_icon_verified_group_vip);
                setWeiboVipDescription(holder, comment);
            } else {
                holder.comment_user_weibo_icon_verified.setVisibility(View.GONE);
            }
            // }

        }
    }

    private void setWeiboVipDescription(ViewHolder holder, Comment comment) {
        String address = null;
        if (null != comment.getMb_usr_desc() && !"".equals(comment.getMb_usr_desc())) {
            address = comment.getMb_usr_desc();
        } else if (null != comment.getMb_usr_desc_detail() && !"".equals(comment.getMb_usr_desc_detail())) {
            address = comment.getMb_usr_desc_detail();
        } else {
            address = comment.getProvinceCity();
        }
        if (holder.comment_address != null) {
            holder.comment_address.setText(address);
        }
        setAdressTimeMargins(holder);
    }

    private void setAdressTimeMargins(ViewHolder holder) {

        if (holder.comment_time != null && holder.comment_address != null) {
            Paint paint = new Paint();
            paint.setTextSize(holder.comment_time.getTextSize());
            int width = (int) paint.measureText(holder.comment_time.getText().toString());
            RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) (holder.comment_time.getLayoutParams());
            lp.setMargins(0 - width - MobileUtil.dpToPx(12), lp.topMargin, lp.rightMargin, lp.bottomMargin);
            holder.comment_time.setLayoutParams(lp);
            lp = (RelativeLayout.LayoutParams) (holder.comment_address.getLayoutParams());
            lp.setMargins(lp.leftMargin, lp.topMargin, 0 + (width + MobileUtil.dpToPx(12 * 2)), lp.bottomMargin);
            holder.comment_address.setLayoutParams(lp);
        }
    }

    public void setHotAndAllNum(int hotNum, int allNum) {
        this.hotNum = hotNum;
        newNum = allNum - hotNum;
        if (newNum < 0) {
            newNum = 0;
        }
    }
    
    public int getHotNum(){ //返回最热评论的数目
    	return this.hotNum;
    }
    
    public int getNewnum(){ //返回最新评论的数码
    	return this.newNum;
    }
    
    public void setHotNum(int num){ 
    	this.hotNum = num;
    }
    
    public void setNewnum(int num){ 
    	this.newNum = num;
    }

    public void setCommentListView(CommentListView mCommentListView) {
        this.mCommentListView = mCommentListView;
    }

    @Override
    public void onClick(View v) {

        ViewHolder holder = (ViewHolder) v.getTag();

        Comment[] clickedComment = (Comment[]) getItem(holder.position);
        int length = clickedComment.length;
        Comment last1comment = clickedComment[length - 1];

        int viewId = v.getId();

        switch (viewId) {
            case R.id.up_icon:            	
//            	if (!clickedComment[clickedComment.length - 1].getReplyId().equals(Constants.TAG_COMMENT_CANTBEUP)) {
//                    mCommentListView.setClickedItemData(holder.position, clickedComment, (View) v.getParent());
//                    mCommentListView.upComment();
//                }
            	if(clickedComment!=null && clickedComment.length > 0){
					Comment cm = clickedComment[clickedComment.length - 1];
					if( cm!=null && cm.getStatus()!=null && !cm.getStatus().trim().equals("0")){
						//这种情况下是被删除的评论，不允许进行顶、回复等操作
					}else if(cm!=null && !cm.getReplyId().equals(Constants.TAG_COMMENT_CANTBEUP)){
						bossUp();
						mCommentListView.setClickedItemData(holder.position, clickedComment, (View) v.getParent());
	                    mCommentListView.upComment();
					}
				} 
                break;
            case R.id.comment_user_icon:
            case R.id.comment_user_name:
            case R.id.comment_list_item_user_name:            	
            	if(last1comment.getMediaID()!=null && !last1comment.getMediaID().equals("") && !last1comment.getMediaID().equals("0")){
            		goToMediaCardPage(last1comment);
            	}
            	else if (last1comment.isOpenMb()) {
                    Intent i = new Intent();
                    i.setClass(mContext, WebBrowserActivity.class);
                    i.putExtra("url", "http://m.3g.qq.com/account_guest.html?aid=" + last1comment.getChar_name()
                            + "&fr=5");
                    mContext.startActivity(i);
                } else {
                    TipsToast.getInstance().showTipsWarning("该用户尚未开通微博");
                }

                break;
        }
    }

    private void goToMediaCardPage(Comment cm){
    	SLog.d("###goToMediaCardPage###",cm.getMediaID());
    	RssCatListItem rssChannelListItem = new RssCatListItem();
	    rssChannelListItem.setChlid(cm.getMediaID());
	    if (cm.isOpenMb()) {
	    	rssChannelListItem.setChlname(cm.getMb_nick_name());
        } else {
        	rssChannelListItem.setChlname(cm.getNick());
        }				    
        rssChannelListItem.setUin(cm.getUin());
	    rssChannelListItem.setEmpty(true);
        Intent intent = new Intent();
        Bundle bundle = new Bundle();
        bundle.putSerializable(RssMediaActivity.RSS_MEDIA_ITEM, rssChannelListItem);
        intent.putExtras(bundle);
        intent.setClass(this.mContext, RssMediaActivity.class); 
        this.mContext.startActivity(intent);
    }
    
    private void applyTheme(ViewHolder holder) {

        themeSettingsHelper.setTextViewColor(mContext, holder.comment_user_name, R.color.comment_user_name_color);
        themeSettingsHelper.setTextViewColor(mContext, holder.comment_up_num, R.color.comment_up_num_color);
        themeSettingsHelper.setTextViewColor(mContext, holder.comment_address, R.color.comment_up_num_color);
        themeSettingsHelper.setTextViewColor(mContext, holder.comment_time, R.color.comment_up_num_color);
    }
    
  //kiddyliu boss统计代码
  	private void bossUp(){
  		SLog.d("BOSS", "up one Comment in page:" + String.valueOf(this.listType));
  		switch(this.listType){
  			case Constants.COMMENT_IN_NEWS_DETAIL_PAGE:
  				WebDev.trackCustomEvent(this.mContext, EventId.BOSS_COMMENT_LIST_CLICK_UP_ONE_COMMENT_BTN);
  				break;
  			case Constants.COMMENT_IN_MYCOMMENT_PAGE:
  				WebDev.trackCustomEvent(this.mContext, EventId.BOSS_MY_COMMENT_CLICK_UP_ONE_COMMENT_BTN);
  				break;
  			case Constants.COMMENT_IN_ATME_COMMENT_PAGE:
  				WebDev.trackCustomEvent(this.mContext, EventId.BOSS_AT_COMMENT_CLICK_UP_ONE_COMMENT_BTN);
  				break;
  			default:
  				break;
  		}
  	}
  	
}
