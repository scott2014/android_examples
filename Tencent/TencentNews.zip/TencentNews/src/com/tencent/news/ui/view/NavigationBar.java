package com.tencent.news.ui.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.tencent.news.R;
import com.tencent.news.model.pojo.ExtendedChannels;
import com.tencent.news.model.pojo.RemoteConfig;
import com.tencent.news.utils.ImageCacheNameUtil;
import com.tencent.news.utils.ImageUtil;
import com.tencent.news.utils.InfoConfigUtil;

public class NavigationBar extends LinearLayout implements View.OnClickListener {
	private View viewSelected = null;
	private Context mContext;
	private LinearLayout mLinearLayout;
	private NavigationListener navigateListener;
	private static int mSelected = 0;
	
	public NavigationBar(Context context) {
		super(context);
		init(context);
	}
	
	public NavigationBar(Context context, AttributeSet attrs) {
		super(context, attrs);
		init(context);

	}
	
	private void init(Context context){
		this.mContext = context;
		LayoutInflater.from(mContext).inflate(R.layout.layout_navigation_bar, this, true);
		mLinearLayout = (LinearLayout)findViewById(R.id.navigation_layout);
		ExtendedChannels channel = InfoConfigUtil.ReadExtendedChannels();
		RemoteConfig mRemote = InfoConfigUtil.ReadRemoteConfig();
		if(mRemote != null && mRemote.getAppModeEx() != null && mRemote.getAppModeEx().equals("extended")){
			if(isShowExtendedTab(channel)){
				Button btn = (Button)LayoutInflater.from(mContext).inflate(R.layout.navigation_bar_item, null);
				btn.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT,1));
				btn.setCompoundDrawablesWithIntrinsicBounds(null, newSelector(channel), null, null);
				if(channel != null && channel.getChlname() != null){
					btn.setText(channel.getChlname());
				}
				mLinearLayout.addView(btn);
			}
		}
		for(int i = 0; i < mLinearLayout.getChildCount(); i++){
			View view = mLinearLayout.getChildAt(i);
			view.setTag(i);
			view.setOnClickListener(this);
			if(i == 0){
				viewSelected = view;
				viewSelected.setSelected(true);
			}
		}
	}
	
	public void showRSSRedDot(boolean isShow) {
		findViewById(R.id.red_dot).setVisibility(isShow ? View.VISIBLE : View.GONE);
	}
	public boolean isRSSRedDotShow() {
		return findViewById(R.id.red_dot).getVisibility() == View.VISIBLE ? true : false;
	}
	public boolean isShowExtendedTab(ExtendedChannels channel){
		boolean bFlag = false;
		if(channel != null){
			if(getExtendedIcon(channel.getIcon()) == null || getExtendedIcon(channel.getIcon_hl()) == null){
				bFlag = false;
			}else{
				bFlag = true;
			}
		}
		return bFlag;
	}
	
	private Bitmap getExtendedIcon(String url) {
		String filePath = ImageCacheNameUtil.getExtendedIconFileName(url);
		Bitmap bm = ImageUtil.FromFileToBitmap(filePath);
		return bm;
	}
	
	private StateListDrawable newSelector(ExtendedChannels channel) {  
		StateListDrawable bg = null; 
		if(channel != null){
			bg = new StateListDrawable(); 
			Drawable normal = new BitmapDrawable(mContext.getResources(),getExtendedIcon(channel.getIcon()));
			Drawable pressed = new BitmapDrawable(mContext.getResources(),getExtendedIcon(channel.getIcon_hl()));  
			bg.addState(new int[] { android.R.attr.state_pressed }, pressed);  
			bg.addState(new int[] { android.R.attr.state_focused }, pressed);  
			bg.addState(new int[] { android.R.attr.state_selected }, pressed);  
			bg.addState(new int[] {}, normal);  
	
		}
	    return bg;  
	}  
	
	@Override
	public void onClick(View v) {
		if(v == null) return;
		boolean refresh = viewSelected.equals(v);
		viewSelected.setSelected(false);
		v.setSelected(true);
		viewSelected = v;
		if(navigateListener != null){
			int nIndex = (Integer)viewSelected.getTag();
			mSelected = nIndex;
			navigateListener.onOnNavigationBarClick(nIndex, refresh);
		}
	}
	
	public void setDefault(int nIndex){
		View v = null;
		if(nIndex >= 0 && nIndex < mLinearLayout.getChildCount()){
			v = mLinearLayout.getChildAt(nIndex);
			viewSelected.setSelected(false);
			v.setSelected(true);
			viewSelected = v;
		}
	}
	
	public void setOnNavigationListener(NavigationListener listener){
		this.navigateListener = listener;
	}
	
	public static int getSelected(){
		return mSelected;
	}
	
	public interface NavigationListener{
		public void onOnNavigationBarClick(int nIndex, boolean refresh);
	}
}
