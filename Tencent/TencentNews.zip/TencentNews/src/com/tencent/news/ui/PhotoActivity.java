package com.tencent.news.ui;

import java.util.List;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

import com.tencent.news.R;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.ui.adapter.PhotoListAdapter;
import com.tencent.news.ui.view.NetTipsBar;
import com.tencent.news.ui.view.PullToRefreshFrameLayout;
import com.tencent.news.ui.view.TitleBar;
import com.tencent.omg.webdev.WebDev;

public class PhotoActivity extends AbsChannelActivityNew {
	@Override
	protected void InitContainerView(Bundle savedInstanceState){
		setContentView(R.layout.photo_layout);
		mFramelayout = (PullToRefreshFrameLayout)findViewById(R.id.photo_list_content);
		mListView = mFramelayout.getPullToRefreshListView();
		mTitleBar = (TitleBar)findViewById(R.id.photo_title_bar);
		mNetTipsBar = (NetTipsBar)findViewById(R.id.photo_nettips_bar);
		mTitleBar.ShowElseBar(R.string.title_photo);
		if(mIsViewPager){
			mTitleBar.setVisibility(View.GONE);
		}
		
		mTitleBar.setTopClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				setSelection();
			}
			
		});
	}
	
	@Override
	protected String getListviewTimeTag() {
		// TODO Auto-generated method stub
		return mChannel;
	}
	
	@Override
	protected void addHeadView(){
	
	}
	
	@Override
	protected void InitAdapter(){
		mAdapter = new PhotoListAdapter(this, mListView);
		mListView.setAdapter(mAdapter);
	}

	@Override
	protected synchronized void setHeadData(List<Item> list) {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected Class<? extends Object> getClassName(Item item) {
		// TODO Auto-generated method stub
		return ImageDetailActivity.class;
	}

	@Override
	protected String getChlidTitle() {
		// TODO Auto-generated method stub
		return "精选图片";
	}

	@Override
	protected boolean isRegisterNetTips() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	protected boolean isNeedHeadView() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	protected void createCellView() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void removeCellView() {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}
}
