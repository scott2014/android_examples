package com.tencent.news.ui.view;

import java.util.ArrayList;
import java.util.List;

import android.app.Dialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.boss.EventId;
import com.tencent.news.config.Constants;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.ui.adapter.TextSizeAdapter;
import com.tencent.news.utils.ThemeSettingsHelper;
import com.tencent.omg.webdev.WebDev;

public class TextSizeDialog extends Dialog {
	
	Context context;  
	TextSizeAdapter adapter;
	ListView listView;
	List<Item> listItems;
	Button btn_cancel;
	
	TextView mTitle;
	LinearLayout textsize_dialog;
	
	private SettingInfo settingData;
	private SettingObservable settingObv;
	private ThemeSettingsHelper themeSettingsHelper;
	
	public TextSizeDialog(Context context) 
	{        
		super(context);        
		this.context = context;  
	} 
	
	public TextSizeDialog(Context context, int theme) 
	{        
		super(context, theme);        
		this.context = context;    
	}
	
	public TextSizeDialog(Context context, SettingInfo info, SettingObservable observer, int theme)
	{        
		super(context, theme);        
		this.context = context;  
		this.settingData = info;
		this.settingObv = observer;
	}  
	
	@Override    
	protected void onCreate(Bundle savedInstanceState) 
	{        
		super.onCreate(savedInstanceState);        
		
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(context);	
		
		if (themeSettingsHelper.isNightTheme()) {
			this.setContentView(R.layout.night_textsize_dialog);
		} else {
			this.setContentView(R.layout.textsize_dialog);
		}
		
		initViews();
		
		loadData();
		
		initAdapter();
		
		initListener();
	}
	
	public class Item {
		public String title;
		public boolean checked;
		
		public Item(String title, boolean checked)
		{
			this.title = title;
			this.checked = checked;
		}
	}
	
	private void initViews()
	{
		btn_cancel = (Button) findViewById(R.id.button3);
		listView = (ListView) findViewById(R.id.list_font);
		mTitle = (TextView) findViewById(R.id.title);
		textsize_dialog = (LinearLayout) findViewById(R.id.textsize_dialog);
		
		if (themeSettingsHelper.isNightTheme()) {
			listView.setBackgroundResource(R.color.night_page_setting_bg_color);
			listView.setSelector(context.getResources().getDrawable(R.drawable.night_setting_selector));
			listView.setDivider(context.getResources().getDrawable(R.drawable.night_setting_divider_bg));
			
			ColorStateList night_csl = (ColorStateList) context.getResources().getColorStateList(R.drawable.night_btn_cancel_text_selector);
			if (night_csl != null) {
				btn_cancel.setTextColor(night_csl);
			}
		} else {
			listView.setBackgroundResource(R.color.page_setting_bg_color);
			listView.setSelector(context.getResources().getDrawable(R.drawable.setting_selector));
			listView.setDivider(context.getResources().getDrawable(R.drawable.setting_divider_bg));
		}
	}

	private void initAdapter()
	{
		adapter = new TextSizeAdapter(context, listView, listItems);
		listView.setAdapter(adapter);
	}
	
	private void loadData()
	{
		listItems = new ArrayList<Item>();
		
		int id = settingData.getTextSize();
		
		for (int i = 0; i < Constants.wordSizeStr.length; i++) {
			Item item = new Item(Constants.wordSizeStr[i], i == id);
			if (item != null)
				listItems.add(item);
		}
	}
	
	private void initListener()
	{
		listView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				setChecked(position);
				dismiss();
			}
		});
		
		btn_cancel.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view)
			{
				dismiss();
			}
		});
	}
	
	private void setChecked(int id)
	{
		if (id < 0 || id >= listItems.size())
			return;
		
		for (int i = 0; i < listItems.size(); i++)
		{
			Item item = adapter.getObjectItem(i);
			item.checked = (i == id);
			listItems.set(i,  item);
			
			View view = listView.getChildAt(i);
			ImageView image = (ImageView) view.findViewById(R.id.image);
			
			if (i == id)
				themeSettingsHelper.setImageViewSrc(this.context, image, R.drawable.btn_radio_on);
			else
				themeSettingsHelper.setImageViewSrc(this.context, image, R.drawable.btn_radio_off);
		}
		
		switch (id) {
		case 0:
			settingData.setTextSize(Constants.SETTING_MIN_TEXT_SIZE);
			break;
		case 1:
			settingData.setTextSize(Constants.SETTING_MID_TEXT_SIZE);
			break;
		case 2:
			settingData.setTextSize(Constants.SETTING_MAX_TEXT_SIZE);
			break;
		case 3:
			settingData.setTextSize(Constants.SETTING_BIG_TEXT_SIZE);
			break;
		default:
			break;
		}
		
		settingObv.setData(settingData);
		
		WebDev.trackCustomEvent(context, EventId.BOSS_SETTING_TEXTSIZE, new String[] { "" + settingObv.getData().getTextSize() });
		
		adapter.notifyDataSetChanged();
	}
}

