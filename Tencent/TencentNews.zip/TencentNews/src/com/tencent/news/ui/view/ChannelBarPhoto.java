package com.tencent.news.ui.view;

import android.content.Context;
import android.util.AttributeSet;

import com.tencent.news.model.pojo.ChannelList;
import com.tencent.news.system.Application;
import com.tencent.news.utils.InfoConfigUtil;
import com.tencent.news.utils.TempManager;


public class ChannelBarPhoto extends ChannelBarBase {
	public ChannelBarPhoto(Context context){
		super(context);
	}
	
	public ChannelBarPhoto(Context context, AttributeSet attrs){
		super(context,attrs);
	}
	
	@Override
	public ChannelList getChannelList(){
		ChannelList ChannelList = Application.getInstance().getPhotoChannelList();
		if(ChannelList == null){
			ChannelList = InfoConfigUtil.ReadPhotoSubChannel();
			//ChannelList = InfoConfigUtil.ReadSubChannel();//临时
			if(ChannelList == null){
				ChannelList = TempManager.getManager().getPhotoChannelListInfo(mContext);
			}
			Application.getInstance().setPhotoChannelList(ChannelList);
		}
		return ChannelList;
	}

	@Override
	public void onClickSetUp() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object getChannelData() {
		// TODO Auto-generated method stub
		return null;
	}
}
