package com.tencent.news.ui.view;

import java.io.File;

import android.content.Context;
import android.content.Intent;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.config.Constants;
import com.tencent.news.ui.OfflineActivity;
import com.tencent.news.utils.ThemeSettingsHelper;

public class NetTipsBar extends LinearLayout {
	private Context mContext;
	private LinearLayout mTipsLayout = null;
	private TextView netTipsText = null;
	private ImageView netTipsImgeView = null;
	protected ThemeSettingsHelper themeSettingsHelper = null;
	private boolean canChangeTipText = false;

	public NetTipsBar(Context context) {
		this(context, null);
	}

	public NetTipsBar(Context context, AttributeSet attrs) {
		super(context, attrs);

		TypedArray arrayType = context.obtainStyledAttributes(attrs, com.tencent.news.R.styleable.NetTipsBar);
		canChangeTipText = arrayType.getBoolean(R.styleable.NetTipsBar_can_change, false);
		arrayType.recycle();

		Init(context);
	}

	boolean gotoOffline;

	private void Init(Context context) {
		this.mContext = context;

		LayoutInflater.from(mContext).inflate(R.layout.net_tips_bar_layout, this, true);
		mTipsLayout = (LinearLayout) findViewById(R.id.net_tips_layout);
		netTipsText = (TextView) findViewById(R.id.net_tips_text);

		netTipsImgeView = (ImageView) findViewById(R.id.net_tips_img_arrow);

	}

	@Override
	public void setVisibility(int visibility) {
		refreshUI();
		super.setVisibility(visibility);
	}

	public void applyNetTipsBarTheme(Context context) {
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(context);
		themeSettingsHelper.setViewBackgroudColor(context, this.mTipsLayout, R.color.nettips_bg_color);
		themeSettingsHelper.setTextViewColor(context, this.netTipsText, R.color.nettips_text_color);
		themeSettingsHelper.setImageViewSrc(context, this.netTipsImgeView, R.drawable.net_tips_arrow);
	}

	public void refreshUI() {
		gotoOffline = new File(Constants.CACHE_OFFLINE_LIST_PATH).exists();
		if (gotoOffline && canChangeTipText) {
			netTipsText.setText(mContext.getResources().getString(R.string.string_net_tips_goto_offline_text));
		} else {
			netTipsText.setText(mContext.getResources().getString(R.string.string_net_tips_text));
		}
		mTipsLayout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (gotoOffline && canChangeTipText) {
					Intent intent = new Intent(mContext, OfflineActivity.class);
					mContext.startActivity(intent);
				} else {

					Intent intent = new Intent();
					intent.setAction(android.provider.Settings.ACTION_SETTINGS);
					mContext.startActivity(intent);
				}
			}
		});
	}
}
