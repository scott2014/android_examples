package com.tencent.news.ui.view;

import java.util.ArrayList;
import java.util.HashMap;

import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationSet;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.tencent.news.R;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.ThemeSettingsHelper;

public class DragDropGrid extends FrameLayout {

	private Context context;

	private static int TRANSLATE_ANIMATION_DURATION = 300;
	private static float PADDING_LEFT = 10f;
	private static float PADDING_TOP = 13f;
	public static int BUTTON_WIDTH_DP = 67;
	public static int BUTTON_HEIGHT_DP = 33;
	public static int DISABLE_DRAG_NUM = 2;
	private static int START_OFFSET = 10;

	private OnTranslateAnimation onTranslateAnimation = null;
	private OnLayoutEvent onLayoutEvent = null;

	private int mCellWidth;
	private int mCellHeight;
	private int computedRowCount;
	private int computedColCount;
	private int computedColCountOffset;
	private int stepAnimateCount = 0;
	private int stepAnimateTotal = 0;

	public boolean isMoving = false;

	private int initHeight = -1;
	private int lastHeight;
	public ArrayList<HashMap<String, Object>> adapter;

	public static int NO_INDEX = -1;
	
	protected ThemeSettingsHelper themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(context); //支持夜间模式

	public DragDropGrid(Context ct) {
		super(ct);
		context = ct;
	}

	/**
	 * 定义自定义事件
	 */
	public interface OnTranslateAnimation {
		public abstract void onAnimationStart(Animation animation);

		public abstract void onAnimationEnd(Animation animation);
	}

	/**
	 * 允许用户设置事件监听对象
	 * 
	 * @param onTranslateAnimation2
	 */
	public void setOnTranslateAnimationListener(OnTranslateAnimation onTranslateAnimation2) {
		onTranslateAnimation = onTranslateAnimation2;
	}

	/**
	 * 定义自定义事件
	 */
	public interface OnLayoutEvent {
		public abstract void OnLayoutEnd();
	}

	/**
	 * 允许用户设置事件监听对象
	 * 
	 * @param onTranslateAnimation2
	 */
	public void setOnLayoutEventListener(OnLayoutEvent fun) {
		onLayoutEvent = fun;
	}

	/**
	 * 设置单元格宽度
	 * 
	 * @param px
	 */
	public void setCellWidth(int px) {
		mCellWidth = px;
	}

	/**
	 * 设置适配器
	 * 
	 * @param adapter
	 */
	public void setAdapter(ArrayList<HashMap<String, Object>> adapter) {
		this.adapter = adapter;
	}

	/**
	 * 渲染可以拖拽的grid控件
	 */
	public void render() {
		int count = adapter.size();
		int index;
		for (index = 0; index < count; index++) {
			HashMap<String, Object> map = adapter.get(index);
			String childName = String.valueOf(map.get("chlid"));
			String channelName = String.valueOf(map.get("channelName"));
			Button menuButton;
			if (childName.equals("news_news_top")) {
				menuButton = cloneTopButton(channelName, childName);
			} else {
				menuButton = cloneButton(channelName, childName);
			}
			menuButton.setTag(childName);
			addView(menuButton, index);
			Boolean isAlpha = (Boolean) map.get("isAlpha");
			if (isAlpha) {
				fadeIn(menuButton);
				map.put("isAlpha", false);
			}
			map.put("viewIndex", index);
			adapter.set(index, map);
		}
	}

	/**
	 * 动态创建普通按钮
	 * 
	 * @param txt
	 * @return
	 */
	public Button cloneButton(String channelName, String childName) {
		LayoutInflater inflater = LayoutInflater.from(context);
		
		Button menuButton = null;
		if(themeSettingsHelper.isDefaultTheme()){
			menuButton = (Button) inflater.inflate(R.layout.custom_menu_btn, null, false);
		}
		else{
			menuButton = (Button) inflater.inflate(R.layout.night_custom_menu_btn, null, false);
		}
		LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(MobileUtil.dpToPx(BUTTON_WIDTH_DP), MobileUtil.dpToPx(BUTTON_HEIGHT_DP));
		menuButton.setText(channelName);
		menuButton.setTag(childName);
		menuButton.setLayoutParams(ll);
		menuButton.setFocusable(false);
		menuButton.setFocusableInTouchMode(false);
		menuButton.setClickable(false);
		menuButton.setGravity(Gravity.CENTER | Gravity.CENTER_HORIZONTAL);
		return menuButton;
	}

	/**
	 * 动态创建置顶按钮
	 * 
	 * @param txt
	 * @return
	 */
	public Button cloneTopButton(String channelName, String childName) {
		LayoutInflater inflater = LayoutInflater.from(context);
		Button menuButton = null;
		if(themeSettingsHelper.isDefaultTheme()){
			menuButton = (Button) inflater.inflate(R.layout.custom_menu_btn, null, false);
			LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(MobileUtil.dpToPx(BUTTON_WIDTH_DP), MobileUtil.dpToPx(BUTTON_HEIGHT_DP));
			menuButton.setText(channelName);
			menuButton.setTag(childName);
			menuButton.setTextColor(getResources().getColor(R.color.custom_menu_button_yaowen_color));
			menuButton.setBackgroundResource(R.drawable.custom_menu_button_yaowen);
			menuButton.setLayoutParams(ll);
			menuButton.setFocusable(false);
			menuButton.setFocusableInTouchMode(false);
			menuButton.setClickable(false);
			menuButton.setGravity(Gravity.CENTER | Gravity.CENTER_HORIZONTAL);
		}
		else{
			menuButton = (Button) inflater.inflate(R.layout.night_custom_menu_btn, null, false);
			LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(MobileUtil.dpToPx(BUTTON_WIDTH_DP), MobileUtil.dpToPx(BUTTON_HEIGHT_DP));
			menuButton.setText(channelName);
			menuButton.setTag(childName);
			menuButton.setTextColor(getResources().getColor(R.color.night_custom_menu_button_yaowen_color));
			menuButton.setBackgroundResource(R.drawable.night_custom_menu_button_yaowen);
			menuButton.setLayoutParams(ll);
			menuButton.setFocusable(false);
			menuButton.setFocusableInTouchMode(false);
			menuButton.setClickable(false);
			menuButton.setGravity(Gravity.CENTER | Gravity.CENTER_HORIZONTAL);
		}
		
		
		return menuButton;
	}

	/**
	 * 设置单元格高度
	 * 
	 * @param px
	 */
	public void setCellHeight(int px) {
		mCellHeight = px;
	}

	/**
	 * 根据dp值获取值单位像素
	 * 
	 * @return
	 */
	private int getPx(float dp) {
		int pixels = 0;
		DisplayMetrics metrics = getContext().getResources().getDisplayMetrics();
		pixels = (int) (metrics.density * dp + 0.5f);
		return pixels;
	}

	/**
	 * 按顺序单步移动动画
	 * 
	 * @author zhishouwang
	 * @param flag
	 *            是否移动开始位置
	 */
	public void stepAnimateByOrder(int start, int end, boolean flag) {
		if (start == end) {
			return;
		}
		isMoving = true;
		int i = 0;
		stepAnimateTotal = Math.abs(end - start);
		if (flag) {
			stepAnimateTotal = stepAnimateTotal + 1;
		}
		int startOffset;
		if (flag) {
			View startChild = getChildAt(getViewIndex(start));
			View endChild = getChildAt(getViewIndex(end));
			startOffset = i * START_OFFSET;
			view2View(startChild, endChild, startOffset);
		}
		if (start < end) {
			start++;
			end++;
			for (int index = start; index < end; index++) {
				View startChild = getChildAt(getViewIndex(index));
				View endChild = getChildAt(getViewIndex(index - 1));
				startOffset = i * START_OFFSET;
				view2View(startChild, endChild, startOffset);
				i++;
			}
		} else {
			start--;
			end--;
			for (int index = start; index > end; index--) {
				startOffset = i * START_OFFSET;
				View startChild = getChildAt(getViewIndex(index));
				View endChild = getChildAt(getViewIndex(index + 1));
				view2View(startChild, endChild, startOffset);
				i++;
			}
		}
	}

	/**
	 * 获取位置所在的节点索引
	 * 
	 * @param index
	 * @return
	 */
	private int getViewIndex(int index) {
		HashMap<String, Object> map = adapter.get(index);
		return (Integer) map.get("viewIndex");
	}

	/**
	 * 从一个view坐标移动到另一个view坐标
	 * 
	 * @param startChild
	 * @param endChild
	 */
	private void view2View(View startChild, View endChild, long startOffset) {
		Point oldXY = getViewPosition(startChild);
		Point newXY = getViewPosition(endChild);
		Point oldOffset = new Point(0, 0);
		Point newOffset = computeTranslationEndDeltaRelativeToRealViewPosition(oldXY, newXY);
		animateMoveToNewPosition(startChild, oldOffset, newOffset, startOffset);
	}

	/**
	 * 获取view的位置
	 */
	public int positionForView(int initialX, int initialY) {
		int count = getChildCount();
		int total = adapter.size();
		for (int index = 0; index < count; index++) {
			if(index < total) {
				View child = getChildAt(getViewIndex(index));
				if (isPointInsideView(initialX, initialY, child)) {
					return index;
				}
			}
		}
		return DragDropGrid.NO_INDEX;
	}

	/**
	 * 获取某个view容器中心位置的x和y坐标
	 * 
	 * @param v
	 * @return
	 */
	private Point getViewPosition(View v) {
		Rect rect = new Rect();
		v.getGlobalVisibleRect(rect);
		int x = rect.left + v.getWidth() / 2;
		int y = rect.top + v.getHeight() / 2;
		return new Point(x, y);
	}

	/**
	 * 动画view到某个位置
	 * 
	 * @param targetView
	 * @param oldOffset
	 * @param newOffset
	 */
	private void animateMoveToNewPosition(View targetView, Point oldOffset, Point newOffset, long startOffset) {
		AnimationSet set = new AnimationSet(true);
		Animation translate = createTranslateAnimation(oldOffset, newOffset);
		set.addAnimation(translate);
		set.setStartOffset(startOffset);
		set.setFillAfter(true);
		targetView.clearAnimation();
		targetView.startAnimation(set);
	}

	/**
	 * 计算2个点之间的相对位移
	 * 
	 * @param oldXY
	 * @param newXY
	 * @return
	 */
	private Point computeTranslationEndDeltaRelativeToRealViewPosition(Point oldXY, Point newXY) {
		return new Point(newXY.x - oldXY.x, newXY.y - oldXY.y);
	}

	/**
	 * 创建一个移动动画
	 */
	private TranslateAnimation createTranslateAnimation(Point oldOffset, Point newOffset) {
		final TranslateAnimation translate = new TranslateAnimation(oldOffset.x, newOffset.x, oldOffset.y, newOffset.y);
		translate.setDuration(TRANSLATE_ANIMATION_DURATION);
		translate.setFillEnabled(true);
		translate.setInterpolator(new AccelerateDecelerateInterpolator());
		translate.setAnimationListener(new AnimationListener() {
			/**
			 * 动画结束后执行
			 */
			public void onAnimationEnd(Animation animation) {
				stepAnimateCount++;
				if (stepAnimateTotal == stepAnimateCount) {
					stepAnimateTotal = 0;
					stepAnimateCount = 0;
					isMoving = false;
					onTranslateAnimation.onAnimationEnd(animation);
				}
			}

			public void onAnimationRepeat(Animation animation) {

			}

			public void onAnimationStart(Animation animation) {
				isMoving = true;
				onTranslateAnimation.onAnimationStart(animation);
			}

		});
		return translate;
	}

	/**
	 * 判断是否满足拖拽条件
	 * 
	 * @return
	 */
	public View canDrag(int x, int y) {
		View child = getViewByPos(x, y);
		if (child != null && child.getTag().equals("news_news_top")) {
			return null;
		} else {
			return child;
		}
	}

	/**
	 * 根据坐标获取view
	 */
	public View getViewByPos(int x, int y) {
		View child = null;
		int count = adapter.size();
		for (int index = 0; index < count; index++) {
			View ch = getChildAt(getViewIndex(index));
			if (isPointInsideView(x, y, ch)) {
				return ch;
			}
		}
		return child;
	}

	/**
	 * 判断坐标点是否与目标view重合
	 * 
	 * @param x
	 * @param y
	 * @param view
	 * @return
	 */
	private boolean isPointInsideView(float x, float y, View view) {
		int location[] = new int[2];
		view.getLocationOnScreen(location);
		int viewX = location[0];
		int viewY = location[1];
		if (pointIsInsideViewBounds(x, y, view, viewX, viewY)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 判断坐标在哪个View中
	 * 
	 * @param x
	 * @param y
	 * @param view
	 * @param viewX
	 * @param viewY
	 * @return
	 */
	private boolean pointIsInsideViewBounds(float x, float y, View view, int viewX, int viewY) {
		int paddingLeftPx = getPx(DragDropGrid.PADDING_LEFT);
		int paddingTopPx = getPx(DragDropGrid.PADDING_TOP);
		return (x > viewX - paddingLeftPx && x < (viewX + view.getWidth() + paddingLeftPx))
				&& (y > viewY - paddingTopPx && y < (viewY + view.getHeight() + paddingTopPx));
	}

	/**
	 * 获取最后一次页面布局
	 * 
	 * @return
	 */
	public int getLastHeigh() {
		return lastHeight;
	}

	/**
	 * 找寻最大的view宽和高的尺寸
	 */
	private void searchBiggestChildMeasures() {
		mCellWidth = 0;
		mCellHeight = 0;
		int count = getChildCount();
		for (int index = 0; index < count; index++) {
			View child = getChildAt(index);
			if (mCellHeight < child.getMeasuredHeight()) {
				mCellHeight = child.getMeasuredHeight();
			}
			if (mCellWidth < child.getMeasuredWidth()) {
				mCellWidth = child.getMeasuredWidth();
			}
		}
	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		int widthSize = MeasureSpec.getSize(widthMeasureSpec);
		int widthMode = MeasureSpec.getMode(widthMeasureSpec);
		WindowManager wm = (WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE);
		Display display = wm.getDefaultDisplay();
		if (widthMode == MeasureSpec.UNSPECIFIED) {
			widthSize = display.getWidth();
		}
		int paddingTopPx = getPx(DragDropGrid.PADDING_TOP);
		int cellWidthSpec = MeasureSpec.makeMeasureSpec(mCellWidth, MeasureSpec.EXACTLY);
		int cellHeightSpec = MeasureSpec.makeMeasureSpec(mCellHeight, MeasureSpec.AT_MOST);
		int count = getChildCount();
		for (int index = 0; index < count; index++) {
			final View child = getChildAt(index);
			child.measure(cellWidthSpec, cellHeightSpec);
		}
		searchBiggestChildMeasures();
		computedRowCount = getRowCount(widthMeasureSpec, heightMeasureSpec) + 1;
		computedRowCount = computedRowCount > 0 ? computedRowCount : 1;
		if (initHeight == -1) {
			initHeight = (mCellHeight + paddingTopPx) * computedRowCount + paddingTopPx * 2;
			lastHeight = initHeight;
		} else {
			lastHeight = (mCellHeight + paddingTopPx) * computedRowCount + paddingTopPx * 2;
		}
		setMeasuredDimension(resolveSize(widthSize, widthMeasureSpec), resolveSize(initHeight, heightMeasureSpec));
	}

	/**
	 * 根据宽度获取有多少列
	 * 
	 * @param widthMeasureSpec
	 * @param heightMeasureSpec
	 * @return
	 */
	private int getRowCount(int widthMeasureSpec, int heightMeasureSpec) {
		int paddingLeftPx = getPx(DragDropGrid.PADDING_LEFT);
		int widthMode = MeasureSpec.getMode(widthMeasureSpec);
		int widthSize = MeasureSpec.getSize(widthMeasureSpec);
		WindowManager wm = (WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE);
		Display display = wm.getDefaultDisplay();
		if (widthMode == MeasureSpec.UNSPECIFIED) {
			widthSize = display.getWidth();
		}
		int totalWidth = (widthSize - paddingLeftPx);
		int w = (mCellWidth + paddingLeftPx);
		computedColCount = totalWidth / w;
		computedColCountOffset = totalWidth % w;
		computedColCount = (computedColCount <= 0) ? 1 : computedColCount;
		int count = getChildCount();
		int num = (int) Math.ceil(count / computedColCount);
		int row = ((count % computedColCount) == 0) ? num - 1 : num;
		return row;
	}

	/**
	 * 页面重新布局
	 */
	public void reLayout() {
		int paddingLeftPx = getPx(DragDropGrid.PADDING_LEFT);
		int paddingTopPx = getPx(DragDropGrid.PADDING_TOP);
		int cellWidth = mCellWidth;
		int cellHeight = mCellHeight;
		int x = 0;
		int y = 0;
		int i = 0;
		int offset = computedColCountOffset / computedColCount;
		int count = adapter.size();
		for (int index = 0; index < count; index++) {
			final View child = getChildAt(getViewIndex(index));
			child.clearAnimation();
			int w = child.getMeasuredWidth();
			int h = child.getMeasuredHeight();
			int left = (int) (x + Math.ceil((cellWidth - w) / 2) + paddingLeftPx + Math.ceil(offset / 2));
			int top = y + ((cellHeight - h) / 2) + paddingTopPx;
			child.layout(left, top, left + w, top + h);
			if (i >= (computedColCount - 1)) {
				i = 0;
				x = 0;
				y += cellHeight + paddingTopPx;
			} else {
				i++;
				x += cellWidth + paddingLeftPx + offset;
			}
		}
		onLayoutEvent.OnLayoutEnd();
	}

	@Override
	protected void onLayout(boolean changed, int l, int t, int r, int b) {
		int paddingLeftPx = getPx(DragDropGrid.PADDING_LEFT);
		int paddingTopPx = getPx(DragDropGrid.PADDING_TOP);
		int cellWidth = mCellWidth;
		int cellHeight = mCellHeight;
		int x = 0;
		int y = 0;
		int i = 0;
		int offset = computedColCountOffset / computedColCount;
		int count = getChildCount();
		int total = adapter.size();
		for (int index = 0; index < count; index++) {
			if(index < total) {
				final View child = getChildAt(getViewIndex(index));
				int w = child.getMeasuredWidth();
				int h = child.getMeasuredHeight();
				int left = (int) (x + Math.ceil((cellWidth - w) / 2) + paddingLeftPx + Math.ceil(offset / 2));
				int top = y + ((cellHeight - h) / 2) + paddingTopPx;
				child.layout(left, top, left + w, top + h);
				if (i >= (computedColCount - 1)) {
					i = 0;
					x = 0;
					y += cellHeight + paddingTopPx;
				} else {
					i++;
					x += cellWidth + paddingLeftPx + offset;
				}
			}
		}
	}

	/**
	 * 设置某个view渐现
	 * 
	 * @param targetView
	 */
	public void fadeIn(View targetView) {
		AlphaAnimation animation = new AlphaAnimation(0.0f, 1.0f);
		animation.setFillAfter(true);
		animation.setDuration(350);
		targetView.clearAnimation();
		targetView.startAnimation(animation);
	}

	/**
	 * 设置某个view渐隐
	 */
	public void fadeOut(View targetView) {
		AlphaAnimation animation = new AlphaAnimation(1.0f, 0.0f);
		animation.setFillAfter(true);
		animation.setDuration(200);
		targetView.clearAnimation();
		targetView.startAnimation(animation);
	}
	
	/*public void applyDragDropGridTheme(Context context) {			
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(context);		
		themeSettingsHelper.setViewBackgroud(context, this.mLayout, R.drawable.title_bar_bg);
		themeSettingsHelper.setImageButtonSrc(context, this.btnShare, R.drawable.title_share_btn);	
		themeSettingsHelper.setImageButtonSrc(context, this.btnSetting, R.drawable.title_setting_btn);
		themeSettingsHelper.setViewBackgroud(context, this.mBackBtn, R.drawable.title_back_btn);		

	}*/
}
