package com.tencent.news.ui.adapter;

import java.util.List;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.model.pojo.OfflinePreview;
import com.tencent.news.shareprefrence.SpConfig;
import com.tencent.news.shareprefrence.SpNewsHadRead;
import com.tencent.news.shareprefrence.SpOfflineOneChannelTime;
import com.tencent.news.ui.view.IphoneTreeView;
import com.tencent.news.utils.StringUtil;
import com.tencent.news.utils.ThemeSettingsHelper;

public class OfflineAdapter extends IphoneTreeViewAdapter {

	private static final int ITEM = 0;
	private static final int READMORE = 1;

	private Context ctx;
	private IphoneTreeView listView;
	private List<OfflinePreview> downloadedData;
	private ThemeSettingsHelper themeSettingsHelper = null;

	public OfflineAdapter(Context ctx, IphoneTreeView listView, List<OfflinePreview> downloadedData) {
		this.ctx = ctx;
		this.listView = listView;
		this.downloadedData = downloadedData;
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(ctx);
	}

	@Override
	public Object getChild(int groupPosition, int childPosition) {
		try {
			if (downloadedData != null && downloadedData.size() > 0 && downloadedData.get(groupPosition) != null && downloadedData.get(groupPosition).getDownloadedItems() != null
					&& downloadedData.get(groupPosition).getDownloadedItems().size() > 0) {
				return downloadedData.get(groupPosition).getDownloadedItems().get(childPosition);
			} else {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		return childPosition;
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		try {
			if (downloadedData != null && downloadedData.size() > 0 && downloadedData.get(groupPosition) != null && downloadedData.get(groupPosition).getDownloadedItems() != null
					&& downloadedData.get(groupPosition).getDownloadedItems().size() > 0) {
				return downloadedData.get(groupPosition).getDownloadedItems().size();
			} else {
				return 0;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

	@Override
	public Object getGroup(int groupPosition) {

		try {
			if (downloadedData != null && downloadedData.size() > 0 && downloadedData.get(groupPosition) != null && downloadedData.get(groupPosition).getDownloadedChannel() != null) {
				return downloadedData.get(groupPosition).getDownloadedChannel();
			} else {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public int getGroupCount() {
		try {
			if (downloadedData != null && downloadedData.size() > 0) {
				return downloadedData.size();
			} else {
				return 0;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

	@Override
	public long getGroupId(int groupPosition) {
		return groupPosition;
	}

	@Override
	public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {

		ViewGroupHolder mViewGroupHolder = null;

		if (convertView != null && convertView.getTag() != null && convertView.getTag() instanceof ViewGroupHolder) {
			mViewGroupHolder = (ViewGroupHolder) convertView.getTag();
		} else {

			if (themeSettingsHelper.isDefaultTheme()) {
				convertView = LayoutInflater.from(ctx).inflate(R.layout.view_iphone_tree_offline_view_title, null);
			} else {
				convertView = LayoutInflater.from(ctx).inflate(R.layout.night_view_iphone_tree_offline_view_title, null);
			}

			convertView.setEnabled(false);
			convertView.setClickable(true);
			convertView.setFocusable(false);
			convertView.setFocusableInTouchMode(false);
			mViewGroupHolder = new ViewGroupHolder();
			mViewGroupHolder.textView = (TextView) convertView.findViewById(R.id.view_offline_title);
			mViewGroupHolder.textViewTime = (TextView) convertView.findViewById(R.id.view_offline_title_time);
			convertView.setTag(mViewGroupHolder);
		}

		if (mViewGroupHolder != null && getGroup(groupPosition) != null) {
			String chl = (String) getGroup(groupPosition);
			mViewGroupHolder.textView.setText(SpConfig.getChannelNameById(chl));
			mViewGroupHolder.textViewTime.setText(SpOfflineOneChannelTime.getUpdataChannelTime(chl) + " 更新");
		}

		return convertView;

	}

	private static class ViewGroupHolder {
		TextView textView = null;
		TextView textViewTime = null;
	}

	@Override
	public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {

		int type = getChildType(groupPosition, childPosition);
		switch (type) {
		case ITEM:
			convertView = normalView(groupPosition, childPosition, isLastChild, convertView, parent);
			break;
		case READMORE:
			convertView = readMoreView(groupPosition, childPosition, isLastChild, convertView, parent);
			break;
		default:
			break;
		}

		return convertView;

	}

	private View normalView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
		ViewChildHolder mViewChildHolder = null;
		if (convertView != null && convertView.getTag() != null && convertView.getTag() instanceof ViewChildHolder) {
			mViewChildHolder = (ViewChildHolder) convertView.getTag();
		} else {

			if (themeSettingsHelper.isDefaultTheme()) {
				convertView = LayoutInflater.from(ctx).inflate(R.layout.special_news_list_text_item, null);
			} else {
				convertView = LayoutInflater.from(ctx).inflate(R.layout.night_special_news_list_text_item, null);
			}

			mViewChildHolder = new ViewChildHolder();
			mViewChildHolder.title = (TextView) convertView.findViewById(R.id.list_title_text);
			mViewChildHolder.stract = (TextView) convertView.findViewById(R.id.list_abstract_text);
			mViewChildHolder.comments = (TextView) convertView.findViewById(R.id.list_comments_text);
			mViewChildHolder.flag = (ImageView) convertView.findViewById(R.id.list_item_flag);
			mViewChildHolder.imageIcon = (ImageView) convertView.findViewById(R.id.list_image_count_icon);
			mViewChildHolder.imageCount = (TextView) convertView.findViewById(R.id.list_image_count_text);

			convertView.setTag(mViewChildHolder);
		}
		Item item = (Item) getChild(groupPosition, childPosition);
		mViewChildHolder.articletype = item.getArticletype();
		doDiffirence(item, mViewChildHolder);
		showNewsImageIconForText(item, mViewChildHolder);
		return convertView;
	}

	private View readMoreView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
		ViewChildReadMoreHolder mViewChildHolder = null;
		if (convertView != null && convertView.getTag() != null && convertView.getTag() instanceof ViewChildReadMoreHolder) {
			mViewChildHolder = (ViewChildReadMoreHolder) convertView.getTag();
		} else {

			if (themeSettingsHelper.isDefaultTheme()) {
				convertView = LayoutInflater.from(ctx).inflate(R.layout.read_more_item, null);
			} else {
				convertView = LayoutInflater.from(ctx).inflate(R.layout.night_read_more_item, null);
			}

			mViewChildHolder = new ViewChildReadMoreHolder();
			mViewChildHolder.title = (TextView) convertView.findViewById(R.id.list_readmore_text);
			convertView.setTag(mViewChildHolder);
		}
		String c = (String) getGroup(groupPosition);
		if ("news_news_top".equalsIgnoreCase(c)) {
			mViewChildHolder.title.setText("更多" + SpConfig.getChannelNameById(c) + "(100条)");
		} else {
			mViewChildHolder.title.setText("更多" + SpConfig.getChannelNameById(c) + "新闻(100条)");
		}
		return convertView;
	}

	private void showNewsImageIconForText(Item item, ViewChildHolder holder) {
		if (holder.articletype.equals("1")) {
			try {
				if (Integer.parseInt(item.getImageCount()) > 0) {
					holder.imageIcon.setVisibility(View.VISIBLE);
					holder.imageCount.setVisibility(View.VISIBLE);
				}
			} catch (Exception e) {
				holder.imageIcon.setVisibility(View.GONE);
				holder.imageCount.setVisibility(View.GONE);
			}
		} else {
			holder.imageIcon.setVisibility(View.GONE);
			holder.imageCount.setVisibility(View.GONE);
		}
	}

	private static class ViewChildHolder {
		public TextView title;
		TextView stract;
		TextView comments;
		ImageView flag;
		String articletype;
		ImageView imageIcon;
		TextView imageCount;
	}

	private static class ViewChildReadMoreHolder {
		public TextView title;
	}

	@Override
	public boolean hasStableIds() {
		return false;
	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		return true;
	}

	protected void doDiffirence(Item item, ViewChildHolder holder) {
		if (themeSettingsHelper.isDefaultTheme()) {
			if (SpNewsHadRead.isNewsHadRead(item.getId())) {
				holder.title.setTextColor(Color.parseColor("#999999"));
			} else {
				holder.title.setTextColor(Color.parseColor("#212121"));
			}
		} else {
			if (SpNewsHadRead.isNewsHadRead(item.getId())) {
				holder.title.setTextColor(Color.parseColor("#b0b5b8"));
			} else {
				holder.title.setTextColor(Color.parseColor("#f0f4f8"));
			}
		}
		if (item.getTitle() != null) {
			holder.title.setText(StringUtil.replaceBlank(item.getTitle()));
		}
		String stract = null;
		if (item.getBstract() != null) {
			stract = item.getBstract().trim();
			if (stract.length() > 30) {
				stract = stract.substring(0, 30);
			}
		}
		stract = StringUtil.replaceBlank(stract);
		stract = StringUtil.StringFilter(stract);
		holder.stract.setText(stract);

		holder.comments.setText(StringUtil.tenTh2wan(item.getCommentNum()));

		if (holder.imageCount != null && holder.articletype.equals("1")) {
			holder.imageCount.setText(item.getImageCount());
		}
		setItemFlag(holder, item.getFlag());
	}

	private void setItemFlag(ViewChildHolder holder, String flag) {
		if (flag == null || "0".equals(flag)) {
			holder.flag.setVisibility(View.GONE);
		} else {
			holder.flag.setVisibility(View.VISIBLE);
			if (themeSettingsHelper.isNightTheme()) {
				setNightFlagIcon(holder.flag, flag);
			} else {
				setFlagIcon(holder.flag, flag);
			}
		}
	}

	private void setFlagIcon(ImageView imgView, String flag) {
		if ("1".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_scoop_icon);
		} else if ("2".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_tote_icon);
		} else if ("3".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_video_icon);
		} else if ("4".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_special_icon);
		} else if ("5".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_flash_icon);
		} else if ("6".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_live_icon);
		} else if ("7".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_redian);
		}
	}

	private void setNightFlagIcon(ImageView imgView, String flag) {
		if ("1".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_scoop_icon);
		} else if ("2".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_tote_icon);
		} else if ("3".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_video_icon);
		} else if ("4".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_special_icon);
		} else if ("5".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_flash_icon);
		} else if ("6".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_live_icon);
		} else if ("7".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_redian);
		}
	}

	protected void loadSelfView(View convertView, ViewChildHolder holder) {
		holder.title = (TextView) convertView.findViewById(R.id.list_title_text);
		holder.stract = (TextView) convertView.findViewById(R.id.list_abstract_text);
		holder.comments = (TextView) convertView.findViewById(R.id.list_comments_text);
		holder.flag = (ImageView) convertView.findViewById(R.id.list_item_flag);
		holder.imageIcon = (ImageView) convertView.findViewById(R.id.list_image_count_icon);
		holder.imageCount = (TextView) convertView.findViewById(R.id.list_image_count_text);
	}

	@Override
	public int getChildType(int groupPosition, int childPosition) {
		Item i = (Item) getChild(groupPosition, childPosition);
		if ("READ_MORE_OFF_LINE".equalsIgnoreCase(i.getId())) {
			return READMORE;
		} else {
			return ITEM;
		}
	}

	@Override
	public int getChildTypeCount() {
		return 2;
	}

	public void setDownloadedData(List<OfflinePreview> downloadedData) {
		this.downloadedData = downloadedData;
	}

}
