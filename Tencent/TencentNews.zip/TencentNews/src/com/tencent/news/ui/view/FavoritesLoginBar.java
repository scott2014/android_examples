/**
* @author jianhu
* @version 创建时间：2013-7-1 下午7:43:51
* 类说明
*/
package com.tencent.news.ui.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.LinearLayout;

import com.tencent.news.R;

public class FavoritesLoginBar extends LinearLayout{

    private Context mContext;
    private Button mBtnLogin;
    public FavoritesLoginBar(Context context) {
        super(context);
        mContext = context;
        initView();
    }
    
    public FavoritesLoginBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
        initView();
    }
    
    public void initView(){
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.favorites_login_bar, this, true);
        mBtnLogin = (Button)findViewById(R.id.btn_favorites_login);
    }

    public void setBtnLoginClickListener(OnClickListener l) {
        // TODO Auto-generated method stub
        mBtnLogin.setOnClickListener(l);
    }
    
    public void setLoginBtnEnable(boolean isEnable){
        mBtnLogin.setEnabled(isEnable);
    }
    
}
