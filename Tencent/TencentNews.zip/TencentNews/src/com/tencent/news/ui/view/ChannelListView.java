package com.tencent.news.ui.view;

import java.util.ArrayList;
import java.util.HashMap;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationSet;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.anim.DropDownAnimation;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.ThemeSettingsHelper;

public class ChannelListView implements OnTouchListener {

	private Context context;
	public ArrayList<HashMap<String, Object>> adapter;
	private static int FADEIN_ANIMATION_DURATION = 200;
	private static int FADEOUT_ANIMATION_DURATION = 200;
	private static int DROP_DOWN_TIME = 300;
	private static int NO_DATA_ID = 989898;

	private OnSelectChannel onSelectChannel;
	private LinearLayout parent = null;

	public static int LIST_HEIGHT_DP = 51;
	
	protected ThemeSettingsHelper themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(context); //支持夜间模式

	public boolean onSelectAnimation = false;

	/**
	 * 构造函数
	 * 
	 * @param ct
	 */
	public ChannelListView(Context ct) {
		context = ct;
	}

	/**
	 * 定义自定义事件
	 */
	public interface OnSelectChannel {
		public abstract void onSeleced(HashMap<String, Object> hasMap);
	}

	/**
	 * 允许用户设置事件监听对象
	 * 
	 * @param onTranslateAnimation2
	 */
	public void setOnSelectChannelListener(OnSelectChannel ch) {
		onSelectChannel = ch;
	}

	/**
	 * 设置适配器
	 * 
	 * @param adapter
	 */
	public void setAdapter(ArrayList<HashMap<String, Object>> adapter) {
		this.adapter = adapter;
	}

	/**
	 * 设置父级别容器
	 * 
	 * @param adapter
	 */
	public void setParent(LinearLayout view) {
		this.parent = view;
	}

	/**
	 * 渲染可以拖拽的grid控件
	 */
	public void render() {
		int count = adapter.size();
		int total = 0;
		LayoutInflater inflater = LayoutInflater.from(context);
		if (count > 0) {
			for (int index = 0; index < count; index++) {
				HashMap<String, Object> map = adapter.get(index);
				String channelName = (String) map.get("channelName");
				Boolean isSelected = (Boolean) map.get("isSelected");
				FrameLayout.LayoutParams ll;
				if (isSelected) {
					ll = new FrameLayout.LayoutParams(LayoutParams.FILL_PARENT, 0);
				} else {
					total++;
					ll = new FrameLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
				}
				View v = null;
				if(themeSettingsHelper.isDefaultTheme()){
					v = inflater.inflate(R.layout.custom_menu_list_item, null, false);
					
				}
				else{
					v = inflater.inflate(R.layout.night_custom_menu_list_item, null, false);
					
				}
				TextView tv = (TextView) v.findViewById(R.id.name);
				tv.setText(channelName);
				TextView plusBtn = (TextView) v.findViewById(R.id.plusBtn);
				plusBtn.setOnTouchListener(this);
				v.setLayoutParams(ll);
				v.setTag(index);
				parent.addView(v);
			}
		}
		if (total == 0) {
			renderNoData();
		}
	}

	/**
	 * 更新ListView里面元素的状态
	 */
	public void updateListViewStatus() {
		int count = adapter.size();
		int i = 0;
		for (int index = 0; index < count; index++) {
			HashMap<String, Object> map = adapter.get(index);
			Boolean isSelected = (Boolean) map.get("isSelected");
			if (!isSelected) {
				i++;
			}
		}
		if (i > 0) {
			TextView tv = new TextView(context);
			LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT, 1);
			tv.setLayoutParams(ll);
			parent.addView(tv);
			View v = parent.findViewById(NO_DATA_ID);
			if (v != null) {
				parent.removeView(v);
			}

		} else {
			renderNoData();
		}
	}

	/**
	 * 渲染没数据时的界面
	 */
	private void renderNoData() {
		LayoutInflater inflater = LayoutInflater.from(context);
		View v = null;
		if(themeSettingsHelper.isDefaultTheme()){
			v = inflater.inflate(R.layout.custom_menu_no_item, null, false);
		}
		else{
			v = inflater.inflate(R.layout.night_custom_menu_no_item, null, false);
		}
		v.setId(NO_DATA_ID);
		parent.addView(v);
		//fadeIn(parent, null, FADEIN_ANIMATION_DURATION);
	}

	/**
	 * 显示某个频道项
	 * 
	 * @param tempMap
	 */
	public void show(HashMap<String, Object> tempMap) {
		int count = adapter.size();
		for (int index = 0; index < count; index++) {
			HashMap<String, Object> map = adapter.get(index);
			String childName = (String) map.get("chlid");
			String tmpChildName = (String) tempMap.get("chlid");
			if (childName != null && childName.equals(tmpChildName)) {
				map.put("isSelected", false);
				adapter.set(index, map);
				updateListViewStatus();
				View v = parent.getChildAt(index);
				expandView(v);
			}
		}
	}
	
	/**
	 * 给需要的view新增展开的动画
	 * 
	 * @param v
	 */
	private void expandView(final View v) {
		DropDownAnimation a = new DropDownAnimation(v, MobileUtil.dpToPx(ChannelListView.LIST_HEIGHT_DP), true);
		a.setDuration(DROP_DOWN_TIME);
		a.setAnimationListener(new AnimationListener() {
			@Override
			public void onAnimationStart(Animation animation) {
			}

			@Override
			public void onAnimationRepeat(Animation animation) {
			}

			@Override
			public void onAnimationEnd(Animation animation) {
				final LinearLayout background = (LinearLayout) v.findViewById(R.id.background);
				fadeIn(background, new AnimationListener() {
					@Override
					public void onAnimationStart(Animation animation) {
						if(themeSettingsHelper.isDefaultTheme()){
							background.setBackgroundColor(context.getResources().getColor(R.color.expandview_color));
						}
						else{
							background.setBackgroundColor(context.getResources().getColor(R.color.night_expandview_color));
						}
					}

					@Override
					public void onAnimationRepeat(Animation animation) {
					}

					@Override
					public void onAnimationEnd(Animation animation) {
						if(themeSettingsHelper.isDefaultTheme()){
							background.setBackgroundColor(context.getResources().getColor(R.color.expandview_color));
						}
						else{
							background.setBackgroundColor(context.getResources().getColor(R.color.night_expandview_color));
						}
					}
				}, FADEIN_ANIMATION_DURATION);
			}
		});
		v.startAnimation(a);
	}

	/**
	 * 给需要的view新增折叠的动画
	 * 
	 * @param v
	 */
	private void collapseView(final View v) {
		DropDownAnimation a = new DropDownAnimation(v, MobileUtil.dpToPx(ChannelListView.LIST_HEIGHT_DP), false);
		a.setDuration(DROP_DOWN_TIME);
		a.setAnimationListener(new AnimationListener() {
			@Override
			public void onAnimationStart(Animation animation) {
			}

			@Override
			public void onAnimationRepeat(Animation animation) {
			}

			@Override
			public void onAnimationEnd(Animation animation) {
				int index = (Integer) v.getTag();
				HashMap<String, Object> map = adapter.get(index);
				map.put("isSelected", true);
				adapter.set(index, map);
				updateListViewStatus();
				onSelectChannel.onSeleced(map);
				onSelectAnimation = false;
				final TextView checkedBtn = (TextView) v.findViewById(R.id.checkedBtn);
				final TextView plusBtn = (TextView) v.findViewById(R.id.plusBtn);
				plusBtn.clearAnimation();
				fadeOut(checkedBtn, null, FADEOUT_ANIMATION_DURATION);
			}
		});
		v.startAnimation(a);
	}

	/**
	 * 设置某个view渐现
	 * 
	 * @param targetView
	 */
	public void fadeIn(View targetView, AnimationListener animListener, int fadeInDuration) {
		AnimationSet animationSet = new AnimationSet(true);
		AlphaAnimation alphaAnimation = new AlphaAnimation(0.0f, 1.0f);
		alphaAnimation.setDuration(fadeInDuration);
		animationSet.addAnimation(alphaAnimation);
		animationSet.setFillAfter(true);
		if (animListener != null) {
			animationSet.setAnimationListener(animListener);
		}
		targetView.startAnimation(animationSet);
	}

	/**
	 * 设置某个view渐隐
	 */
	public void fadeOut(View targetView, AnimationListener animListener, int fadeOutDuration) {
		AnimationSet animationSet = new AnimationSet(true);
		AlphaAnimation alphaAnimation = new AlphaAnimation(1.0f, 0.0f);
		alphaAnimation.setDuration(fadeOutDuration);
		animationSet.addAnimation(alphaAnimation);
		animationSet.setFillAfter(true);
		if (animListener != null) {
			animationSet.setAnimationListener(animListener);
		}
		targetView.startAnimation(animationSet);
	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		if (!onSelectAnimation) {
			onSelectAnimation = true;
			final View frameLayout = (View) v.getParent().getParent();
			final TextView checkedBtn = (TextView) frameLayout.findViewById(R.id.checkedBtn);
			final LinearLayout background = (LinearLayout) frameLayout.findViewById(R.id.background);
			AnimationListener animOutListener = new Animation.AnimationListener() {
				@Override
				public void onAnimationStart(Animation animation) {
					if(themeSettingsHelper.isDefaultTheme()){
						background.setBackgroundColor(context.getResources().getColor(R.color.ontouch_color));
					}
					else{
						background.setBackgroundColor(context.getResources().getColor(R.color.night_ontouch_color));
					}
				}

				@Override
				public void onAnimationRepeat(Animation animation) {
				}

				@Override
				public void onAnimationEnd(Animation animation) {
				}
			};
			AnimationListener animInListener = new Animation.AnimationListener() {
				@Override
				public void onAnimationStart(Animation animation) {
					checkedBtn.setVisibility(View.VISIBLE);
				}

				@Override
				public void onAnimationRepeat(Animation animation) {
				}

				@Override
				public void onAnimationEnd(Animation animation) {
					collapseView(frameLayout);
				}
			};
			fadeOut(v, null, FADEOUT_ANIMATION_DURATION);
			fadeOut(background, animOutListener, FADEOUT_ANIMATION_DURATION);
			fadeIn(checkedBtn, animInListener, FADEIN_ANIMATION_DURATION);
		}
		return false;
	}

}
