package com.tencent.news.ui.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.command.GetImageRequest;
import com.tencent.news.command.GetImageResponse;
import com.tencent.news.config.Constants;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.model.pojo.ImageResult;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.model.pojo.SpecialReport;
import com.tencent.news.shareprefrence.SpNewsHadRead;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.IphoneTreeView;
import com.tencent.news.utils.DefaulImageUtil;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.StringUtil;
import com.tencent.news.utils.ThemeSettingsHelper;

/**
 * @author josephzhang
 * 
 */
public class SpecialReportAdapter extends IphoneTreeViewAdapter implements GetImageResponse {
	private Context ctx;
	private IphoneTreeView listView;
	private SpecialReport mSpecialReport;
	private boolean isTextMode;
	
	protected ThemeSettingsHelper themeSettingsHelper = null; //支持夜间模式
	

	public SpecialReportAdapter(Context ctx, IphoneTreeView listView, SpecialReport mSpecialReport, boolean isFromOffline) {
		this.ctx = ctx;
		this.listView = listView;
		this.mSpecialReport = mSpecialReport;
		SettingInfo settingInfo = SettingObservable.getInstance().getData();
		isTextMode = settingInfo.isIfTextMode();
		if(isFromOffline) {
			isTextMode = true;
		}
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(this.ctx);
	}

	public SpecialReport getmSpecialReport() {
		return mSpecialReport;
	}

	public void setSpecialReport(SpecialReport mSpecialReport) {
		this.mSpecialReport = mSpecialReport;
	}

	@Override
	public Object getChild(int groupPosition, int childPosition) {
		try {
			if (mSpecialReport != null && mSpecialReport.getIdlist() != null && mSpecialReport.getIdlist().length > 0 && mSpecialReport.getIdlist()[groupPosition].getNewslist() != null
					&& mSpecialReport.getIdlist()[groupPosition].getNewslist().length > 0) {
				return mSpecialReport.getIdlist()[groupPosition].getNewslist()[childPosition];
			} else {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		return childPosition;
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		try {
			if (mSpecialReport != null && mSpecialReport.getIdlist() != null && mSpecialReport.getIdlist().length > 0 && mSpecialReport.getIdlist()[groupPosition].getNewslist() != null) {
				return mSpecialReport.getIdlist()[groupPosition].getNewslist().length;
			} else {
				return 0;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

	@Override
	public Object getGroup(int groupPosition) {

		try {
			if (mSpecialReport != null && mSpecialReport.getIdlist() != null && mSpecialReport.getIdlist().length > 0 && mSpecialReport.getIdlist()[groupPosition].getSection() != null
					&& mSpecialReport.getIdlist()[groupPosition].getSection().length() > 0) {
				return mSpecialReport.getIdlist()[groupPosition].getSection();
			} else {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public int getGroupCount() {
		try {
			if (mSpecialReport != null && mSpecialReport.getIdlist() != null && mSpecialReport.getIdlist().length > 0) {
				return mSpecialReport.getIdlist().length;
			} else {
				return 0;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

	@Override
	public long getGroupId(int groupPosition) {
		return groupPosition;
	}

	@Override
	public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {

		ViewGroupHolder mViewGroupHolder = null;		

		if (convertView != null && convertView.getTag() != null && convertView.getTag() instanceof ViewGroupHolder) {
			mViewGroupHolder = (ViewGroupHolder) convertView.getTag();
		} else {
			if(themeSettingsHelper.isDefaultTheme()){
				convertView = LayoutInflater.from(ctx).inflate(R.layout.view_iphone_tree_view_title, null);//?
			}
			else{
				convertView = LayoutInflater.from(ctx).inflate(R.layout.night_view_iphone_tree_view_title, null);
			}
			convertView.setEnabled(false);
			convertView.setClickable(true);
			convertView.setFocusable(false);
			convertView.setFocusableInTouchMode(false);
			mViewGroupHolder = new ViewGroupHolder();
			mViewGroupHolder.textView = (TextView) convertView.findViewById(R.id.view_title);
			convertView.setTag(mViewGroupHolder);
		}

		if (mViewGroupHolder != null && getGroup(groupPosition) != null) {
			mViewGroupHolder.textView.setText(getGroup(groupPosition).toString());
		}

		return convertView;

	}

	private static class ViewGroupHolder {
		TextView textView = null;
	}

	@Override
	public int getChildType(int groupPosition, int childPosition){
		if(isTextMode){
			return Constants.TYPE_ITEM_TEXT;
		}
		
		Item item = (Item) getChild(groupPosition, childPosition);
		if(item!=null && item.getArticletype().trim().equals("1")){
			return Constants.TYPE_ITEM_THREE_PHOTO;
		}
		
		return Constants.TYPE_ITEM_IMAGE;
	}
	
	@Override
	public int  getChildTypeCount(){
		return 4;
	}
	
	@Override
	public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
		ViewChildHolder mViewChildHolder = null;
		int type = getChildType(groupPosition, childPosition);
		switch (type) {
			case Constants.TYPE_ITEM_TEXT:
				convertView = setTextMode(convertView, groupPosition, childPosition, mViewChildHolder);
				break;
			case Constants.TYPE_ITEM_IMAGE:
				convertView = setImageMode(convertView, groupPosition, childPosition, mViewChildHolder);
				break;
			case Constants.TYPE_ITEM_THREE_PHOTO:
				convertView = setThreeImageMode(convertView, groupPosition, childPosition, mViewChildHolder);
				break;
			default:
				break;
		}
		
		return convertView;

	}

	private View setThreeImageMode(View convertView, int groupPosition, int childPosition, ViewChildHolder mViewChildHolder){
		if (convertView != null && convertView.getTag() != null && convertView.getTag() instanceof ViewChildHolder) {
			mViewChildHolder = (ViewChildHolder) convertView.getTag();
		} else {
			//夜间模式
			if(themeSettingsHelper.isDefaultTheme()){
				convertView = LayoutInflater.from(ctx).inflate(R.layout.special_news_list_item_photos, null);
			}
			else{
				convertView = LayoutInflater.from(ctx).inflate(R.layout.night_special_news_list_item_photos, null);
			}
			///
			mViewChildHolder = new ViewChildHolder();			
			loadViewForThreeImage(convertView, mViewChildHolder);
			convertView.setTag(mViewChildHolder);
		}
		
		Item item = (Item) getChild(groupPosition, childPosition);
		if(item!=null && mViewChildHolder!=null ){
			mViewChildHolder.id = item.getId();
			mViewChildHolder.articletype = item.getArticletype();
			doDiffirence(item, mViewChildHolder);
			setNewsListThreeImage(item, mViewChildHolder);
		}
		return convertView;
	}
	private View setImageMode(View convertView, int groupPosition, int childPosition, ViewChildHolder mViewChildHolder) {
		if (convertView != null && convertView.getTag() != null && convertView.getTag() instanceof ViewChildHolder) {
			mViewChildHolder = (ViewChildHolder) convertView.getTag();
		} else {			
			if(themeSettingsHelper.isDefaultTheme()){
				convertView = LayoutInflater.from(ctx).inflate(R.layout.special_news_list_item, null);
			}
			else{
				convertView = LayoutInflater.from(ctx).inflate(R.layout.night_special_news_list_item, null);
			}
			mViewChildHolder = new ViewChildHolder();			
			loadViewForSingleImage(convertView, mViewChildHolder);
			convertView.setTag(mViewChildHolder);
		}

		Item item = (Item) getChild(groupPosition, childPosition);
		if(item!=null && mViewChildHolder!=null){
			mViewChildHolder.id = item.getId();
			mViewChildHolder.articletype = item.getArticletype();
			doDiffirence(item, mViewChildHolder);
			setNewsListSingleImage(item, mViewChildHolder);
		}
		return convertView;
	}

	private View setTextMode(View convertView, int groupPosition, int childPosition, ViewChildHolder mViewChildHolder) {
		if (convertView != null && convertView.getTag() != null && convertView.getTag() instanceof ViewChildHolder) {
			mViewChildHolder = (ViewChildHolder) convertView.getTag();
		} else {			
			if(themeSettingsHelper.isDefaultTheme()){
				convertView = LayoutInflater.from(ctx).inflate(R.layout.special_news_list_text_item, null);
			}
			else{
				convertView = LayoutInflater.from(ctx).inflate(R.layout.night_special_news_list_text_item, null);
			}
			mViewChildHolder = new ViewChildHolder();
			mViewChildHolder.title = (TextView) convertView.findViewById(R.id.list_title_text);
			mViewChildHolder.stract = (TextView) convertView.findViewById(R.id.list_abstract_text);
			mViewChildHolder.comments = (TextView) convertView.findViewById(R.id.list_comments_text);
			mViewChildHolder.flag = (ImageView) convertView.findViewById(R.id.list_item_flag);
			mViewChildHolder.imageIcon = (ImageView) convertView.findViewById(R.id.list_image_count_icon);
			mViewChildHolder.imageCount = (TextView) convertView.findViewById(R.id.list_image_count_text);

			convertView.setTag(mViewChildHolder);
		}
		Item item = (Item) getChild(groupPosition, childPosition);
		if(item!=null && mViewChildHolder!=null){			
			mViewChildHolder.id = item.getId();
			mViewChildHolder.articletype = item.getArticletype();
			doDiffirence(item, mViewChildHolder);
			showNewsImageIconForText(item, mViewChildHolder);
		}
		return convertView;
	}

	private void showNewsImageIconForText(Item item, ViewChildHolder holder) {
		if (holder.articletype.equals("1")) {
			try {
				if (Integer.parseInt(item.getImageCount()) > 0) {
					holder.imageIcon.setVisibility(View.VISIBLE);
					holder.imageCount.setVisibility(View.VISIBLE);
				}
			} catch (Exception e) {
				holder.imageIcon.setVisibility(View.GONE);
				holder.imageCount.setVisibility(View.GONE);
			}
		} else {
			holder.imageIcon.setVisibility(View.GONE);
			holder.imageCount.setVisibility(View.GONE);
		}
	}

	private static class ViewChildHolder {
		public TextView title;
		TextView stract;
		TextView comments;
		ImageView image;
		ImageView flag;
		ImageView imageIcon;
		ImageView commentIcon;
		ImageView imageLeft;   //列表页三个小图中最左边的一个
		ImageView imageMid;    //列表页三个小图中中间的一个
		ImageView imageRight;  //列表页三个小图中最右边的一个
		String id;
		String articletype;		
		TextView imageCount;
	}
	
	protected static class Tag{
		String id;		
		int position;  //如果是一张图position=0，如果是三张小图position=1，2，3分别表示左中右
	}

	@Override
	public boolean hasStableIds() {
		return false;
	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		return true;
	}

	protected Bitmap getDefaultBitmap(boolean isThreePhoto){
		Bitmap retBitmap = null;
		if(isThreePhoto){
			if(themeSettingsHelper.isNightTheme()){
				retBitmap = DefaulImageUtil.getNightDefaultPhotoListImage();
			}
			else{
				retBitmap = DefaulImageUtil.getDefaultPhotoListImage();
			}
		}else{	
			if(themeSettingsHelper.isNightTheme()){
				retBitmap = DefaulImageUtil.getNightDefaultTimelineImage();
			}else{
				retBitmap = DefaulImageUtil.getDefaultTimelineImage();
			}				
		}
		return retBitmap;
	}
	
	protected Bitmap getBitMapFromRemot(Item item, Tag tag, String url){		
		Bitmap retBitmap = null;	
		ImageResult result = null;
		GetImageRequest request = new GetImageRequest();		
		
		request.setGzip(false);
		request.setTag(tag);
		request.setUrl(url);
		
		result = TaskManager.startSmallImageTask(request,this);		
		
		if(result.isResultOK() && result.getRetBitmap() != null){
			retBitmap = result.getRetBitmap();				
		}else{
			retBitmap = getDefaultBitmap(true);
		}		
		return retBitmap;
	}
	
	protected void setNewsListThreeImage(Item item, ViewChildHolder holder) {
		if (null == holder || null == item || holder.id==null || null == item.getThumbnails_qqnews() || item.getThumbnails_qqnews().length == 0) {
			return;
		}
		
		String url = "";			
		Bitmap smallBitmapArr[] = new Bitmap[3];		
		int size = item.getThumbnails_qqnews().length>4? 4:item.getThumbnails_qqnews().length;		
		for(int i=1; i<size; i++){
			Tag tag = new Tag();
			tag.id = holder.id;
			tag.position = i;
			url = (item.getThumbnails_qqnews()[i]!=null && item.getThumbnails_qqnews()[i].length()>0)? item.getThumbnails_qqnews()[i]:"";
			smallBitmapArr[i-1]  = getBitMapFromRemot(item, tag, url);
		}	
		
		setNewsListMoreImage(holder.imageLeft,smallBitmapArr[0]);
		setNewsListMoreImage(holder.imageMid,smallBitmapArr[1]);
		setNewsListMoreImage(holder.imageRight,smallBitmapArr[2]);
		
	}
	
	protected void setNewsListSingleImage(Item item, ViewChildHolder holder) {
		if (holder==null || null == holder.image || holder.id==null || null == item || null == item.getThumbnails_qqnews() || item.getThumbnails_qqnews().length == 0) {
			return;
		}
		
		Tag tag = new Tag();
		tag.id = holder.id;
		tag.position = 0;
		
		GetImageRequest request = new GetImageRequest();
		request.setGzip(false);
		request.setTag(tag);
		request.setUrl(item.getThumbnails_qqnews()[0]);
		ImageResult result = TaskManager.startSmallImageTask(request, this);
		if (result.isResultOK() && result.getRetBitmap() != null) {
			holder.image.setImageBitmap(result.getRetBitmap());			
		} else {
			Bitmap mbitMap = getDefaultBitmap(true);
			if(mbitMap!=null){
				holder.image.setImageBitmap(mbitMap);
			}
		}
	}

	private void setNewsListMoreImage(ImageView srcImage, Bitmap bm) {
		if(bm == null || srcImage==null){
			return;
		}
		
		int desImageViewWidth = 0;
		int desImageViewHeight = 0;
		int totalWidth = MobileUtil.getScreenWidthIntPx()-MobileUtil.dpToPx(7*2 + 18 );
			
		desImageViewWidth = totalWidth/3;
		desImageViewHeight = (int)(desImageViewWidth*0.7);
		LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) srcImage.getLayoutParams();
		lp.width = desImageViewWidth;
		lp.height = desImageViewHeight;
		srcImage.setLayoutParams(lp);
		srcImage.setScaleType(ScaleType.FIT_XY);	
		srcImage.setImageBitmap(bm);
		/*if(themeSettingsHelper.isNightTheme()){
			srcImage.setImageDrawable(ImageUtil.getBlackBitmap(bm));
		}else{
			srcImage.setImageBitmap(bm);
		}*/
	}

	protected void doDiffirence(Item item, ViewChildHolder holder) {		
		if(themeSettingsHelper.isDefaultTheme()){
			if (SpNewsHadRead.isNewsHadRead(item.getId())) {
				holder.title.setTextColor(ctx.getResources().getColor(R.color.readed_news_title_color));
			} else {
				holder.title.setTextColor(ctx.getResources().getColor(R.color.list_title_color));
			}
		}
		else{
			if (SpNewsHadRead.isNewsHadRead(item.getId())) {
				holder.title.setTextColor(ctx.getResources().getColor(R.color.night_readed_news_title_color));
			} else {
				holder.title.setTextColor(ctx.getResources().getColor(R.color.night_list_title_color));
			}			
		}
		if (item.getTitle() != null) {
			holder.title.setText(StringUtil.replaceBlank(item.getTitle()));
		}
		String stract = null;
		if (item.getBstract() != null) {
			stract = item.getBstract().trim();
		}
		stract = StringUtil.replaceBlank(stract);
		if (stract != null && stract.length() > 30) {
			stract = stract.substring(0, 30);
		}
		if(holder.stract!=null){
			holder.stract.setText(stract);
		}
		if(holder.comments!=null){
			holder.comments.setText(StringUtil.tenTh2wan(item.getCommentNum()));
		}
		if (holder.imageCount != null && holder.articletype.equals("1")) {
			holder.imageCount.setText(item.getImageCount());
		}
		if(holder.flag!=null){
			setItemFlag(holder, item.getFlag());
		}
	}

	private void setItemFlag(ViewChildHolder holder, String flag) {
		if (flag == null || "0".equals(flag)) {
			holder.flag.setVisibility(View.GONE);
		} else {
			holder.flag.setVisibility(View.VISIBLE);
			if(themeSettingsHelper.isNightTheme()){
				setNightFlagIcon(holder.flag, flag);
			}else{
				setFlagIcon(holder.flag, flag);
			}
		}
	}

	private void setFlagIcon(ImageView imgView,String flag){			
		if ("1".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_scoop_icon);
		} else if ("2".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_tote_icon);
		} else if ("3".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_video_icon);
		} else if ("4".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_special_icon);
		} else if ("5".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_flash_icon);
		} else if ("6".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_live_icon);
		} else if ("7".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_redian);
		}
	}
	
	private void setNightFlagIcon(ImageView imgView,String flag){			
		if ("1".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_scoop_icon);
		} else if ("2".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_tote_icon);
		} else if ("3".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_video_icon);
		} else if ("4".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_special_icon);
		} else if ("5".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_flash_icon);
		} else if ("6".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_live_icon);
		} else if ("7".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_redian);
		}
	}

	
	protected void loadViewForSingleImage(View convertView, ViewChildHolder holder) {
		holder.title = (TextView) convertView.findViewById(R.id.list_title_text);
		holder.stract = (TextView) convertView.findViewById(R.id.list_abstract_text);
		holder.comments = (TextView) convertView.findViewById(R.id.list_comments_text);
		holder.image = (ImageView) convertView.findViewById(R.id.list_item_image);		
		holder.flag = (ImageView) convertView.findViewById(R.id.list_item_flag);		
	}

	protected void loadViewForThreeImage(View convertView, ViewChildHolder holder){		
		holder.title = (TextView)convertView.findViewById(R.id.list_title_text);
		holder.commentIcon = (ImageView)convertView.findViewById(R.id.list_comments_image);
		holder.imageIcon = (ImageView)convertView.findViewById(R.id.list_image_count_icon);		
		holder.comments = (TextView)convertView.findViewById(R.id.list_comments_text);
		holder.imageCount = (TextView)convertView.findViewById(R.id.list_image_count_text);
		holder.imageLeft = (ImageView)convertView.findViewById(R.id.left_image);			
		holder.imageMid = (ImageView)convertView.findViewById(R.id.mid_image);
		holder.imageRight = (ImageView)convertView.findViewById(R.id.right_image);
		if(themeSettingsHelper.isNightTheme()){//设置夜间模式图标和字体颜色				
			if(holder.commentIcon != null){
				holder.commentIcon.setImageDrawable(ctx.getResources().getDrawable(R.drawable.night_list_item_comment_icon));				
			}
			
			if(holder.imageIcon!=null){
				holder.imageIcon.setImageDrawable(ctx.getResources().getDrawable(R.drawable.night_photo_list_image_icon));	
			}
		}
		else{			
			if(holder.commentIcon != null){
				holder.commentIcon.setImageDrawable(ctx.getResources().getDrawable(R.drawable.list_item_comment_icon));				
			}
			
			if(holder.imageIcon!=null){
				holder.imageIcon.setImageDrawable(ctx.getResources().getDrawable(R.drawable.photo_list_image_icon));	
			}
		}
	}
	@Override
	public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm, String path) {
		// TODO Auto-generated method stub
		Tag mTag = (Tag) tag;
		if(mTag==null || bm==null){
			return;
		}
		switch (imageType) {
		case SMALL_IMAGE:
			int countImage = listView.getChildCount();
			for (int i = 0; i < countImage; i++) {
				if (listView.getChildAt(i).getTag() instanceof ViewChildHolder) {
					ViewChildHolder holder = (ViewChildHolder) listView.getChildAt(i).getTag();
					if (holder != null) {
						if(((String)mTag.id).equals(holder.id)){
							switch(mTag.position){
								case 0:	
									if(bm!=null){
										holder.image.setImageBitmap(bm);			
									}
									break;
								case 1:
									setNewsListMoreImage(holder.imageLeft,bm);
									break;
								case 2:
									setNewsListMoreImage(holder.imageMid,bm);
									break;								
								case 3:
									setNewsListMoreImage(holder.imageRight,bm);
									break;
								default:
								    break;
							}	
							break;
						}
					}
				}
			}
			break;
		default:
			break;
		}
	}

	@Override
	public void onImageRecvError(ImageType imageType, Object tag, int retCode) {
		// TODO Auto-generated method stub

	}

}
