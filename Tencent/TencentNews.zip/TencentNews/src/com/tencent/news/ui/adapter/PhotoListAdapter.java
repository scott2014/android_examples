package com.tencent.news.ui.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.command.GetImageRequest;
import com.tencent.news.config.Constants;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.model.pojo.ImageResult;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.shareprefrence.SpNewsHadRead;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.PullRefreshListView;
import com.tencent.news.utils.DefaulImageUtil;
import com.tencent.news.utils.MobileUtil;

public class PhotoListAdapter extends ChannelListAdapter {
	private int itemType;
	private final int FROM_LOCAL = 0;  //从本地缓存取图
	private final int FROM_REMOTE = 1; //从网络取图
	
	public PhotoListAdapter(Context context, ListView listView) {
		super(context, listView);		
		SettingInfo settingInfo = SettingObservable.getInstance().getData();
		if (settingInfo != null && settingInfo.isIfTextMode()) {
			itemType = Constants.TYPE_ITEM_TEXT;
		} else {
			itemType = Constants.TYPE_ITEM_IMAGE;
		}
	}
	
	@Override
	public int getItemViewType(int position) {			
		Item item = mDataList.get(position);		
		//SLog.d("######", item.getShowType() + "|" + item.getId() +"|" + item.getTitle());
	    if(itemType == Constants.TYPE_ITEM_IMAGE && item !=null && 
	        item.getShowType()!=null && item.getShowType().trim().equals("three")){	    	
	    	styleType = Constants.TYPE_ITEM_THREE_PHOTO;
	    	
	    }else{
	    	styleType =itemType;	    	
	    }
	    
	    //SLog.d("######", item.getShowType() + "|" + item.getId() +"|" + styleType);
		return styleType;
	}

	public void changeStyleMode(int style) {
		// TODO Auto-generated method stub
		this.itemType = style;
		notifyDataSetChanged();
	}
	
	@Override
	public int getViewTypeCount() {
		return 3;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		PhotoHolder holder = null;
		int type = getItemViewType(position);
		switch(type){
		case Constants.TYPE_ITEM_TEXT:
			convertView = setTextMode(convertView, position, holder);
			break;
		case Constants.TYPE_ITEM_IMAGE: //图片模式，单图
			convertView = setOneImageMode(convertView, position, holder);
			break;
		case Constants.TYPE_ITEM_THREE_PHOTO:  //图片模式，三种小图
			convertView = setThreeImageMode(convertView, position, holder);			
			break;
		default:
			break;
		}
		return convertView;
	}
	
	//fromWhere 标识是从网络取图还是从本地缓存取图
	private void setOneBigImage(Item item, PhotoHolder holder, int fromWhere){
		if(item==null || holder==null || holder.id == null || holder.image==null){
			return;
		}
		String url = "";		
		Bitmap bigBitmap = null;	
		Tag tag = new Tag();
		tag.id = holder.id;
		tag.position = 0;
		url = (item.getThumbnails_qqnews_photo() != null && item.getThumbnails_qqnews_photo().length>0)?item.getThumbnails_qqnews_photo()[0]:"";
		////SLog.d("####setOneBigImage###",holder.id + "|" + url);
		bigBitmap = getBitMapImage(item, tag, Constants.TYPE_ITEM_IMAGE, url, fromWhere);		
		setPhotoListImage(holder.image,bigBitmap,Constants.TYPE_ITEM_IMAGE);		
	}
	
	private void setThreeSmallImage(Item item, PhotoHolder holder, int fromWhere){
		if(item==null || holder==null || holder.id == null || holder.imageLeft==null
		   || holder.imageMid==null || holder.imageRight==null ){
			return;
		}
		String url = "";			
		Bitmap smallBitmapArr[] = new Bitmap[3];
		int mType = Constants.TYPE_ITEM_THREE_PHOTO;		
		if(holder!=null && holder.id!=null && item!=null && item.getThumbnails_qqnews() != null && item.getThumbnails_qqnews().length>0){			
			int size = item.getThumbnails_qqnews().length>4? 4:item.getThumbnails_qqnews().length;			
			for(int i=1; i<size; i++){		
				Tag tag = new Tag();
				tag.id = holder.id;
				tag.position = i;
				url = (item.getThumbnails_qqnews()[i]!=null && item.getThumbnails_qqnews()[i].length()>0)? item.getThumbnails_qqnews()[i]:"";
				////SLog.d("####setThreeSmallImage###",holder.id + "|" +url);
				smallBitmapArr[i-1]  = getBitMapImage(item, tag, mType, url, fromWhere);
			}
			
			setPhotoListImage(holder.imageLeft,smallBitmapArr[0],mType);		
			setPhotoListImage(holder.imageMid,smallBitmapArr[1],mType);		
			setPhotoListImage(holder.imageRight,smallBitmapArr[2],mType);					
		}		
	}
	
	private View setOneImageMode(View convertView, int position, PhotoHolder holder){			
		//Bitmap bigBitmap = null;				
		
		if (convertView == null) {
			holder = new PhotoHolder();
			convertView = LayoutInflater.from(mContext).inflate(R.layout.photo_list_item, null);			
			holder.title = (TextView)convertView.findViewById(R.id.photo_title_text);			
			holder.comments = (TextView)convertView.findViewById(R.id.photo_comments_text);
			holder.commentIcon = (ImageView) convertView.findViewById(R.id.list_comments_icon);
			holder.imageIcon = (ImageView) convertView.findViewById(R.id.list_image_count_icon);
			holder.imageCount = (TextView) convertView.findViewById(R.id.photo_count_text);
			holder.image = (ImageView)convertView.findViewById(R.id.photo_item_image);				
			convertView.setTag(holder);
		} else {
			holder = (PhotoHolder) convertView.getTag();
		}
		
		applyThemeForListItem(holder);
		
		Item item = mDataList.get(position);
		if(item==null){
			return convertView;
		}
		holder.id = item.getId();			
		setTextData(item, holder);		
		
		if(!((PullRefreshListView)mListView).isBusy()){ 
			setOneBigImage(item, holder, FROM_REMOTE);
		}else{			
			setOneBigImage(item, holder, FROM_LOCAL);
		}	
		
		return convertView;		
	}	
	
	private View setThreeImageMode(View convertView, int position, PhotoHolder holder){							
		//Bitmap mBitmap = null;		
		//int mType = Constants.TYPE_ITEM_THREE_PHOTO;
		
		if (convertView == null) {
			holder = new PhotoHolder();
			convertView = LayoutInflater.from(mContext).inflate(R.layout.photo_list_item_small, null);			
			holder.title = (TextView)convertView.findViewById(R.id.photo_title_text);			
			holder.comments = (TextView)convertView.findViewById(R.id.photo_comments_text);
			holder.commentIcon = (ImageView) convertView.findViewById(R.id.list_comments_icon);
			holder.imageIcon = (ImageView) convertView.findViewById(R.id.list_image_count_icon);
			holder.imageCount = (TextView) convertView.findViewById(R.id.photo_count_text);			
			holder.imageLeft = (ImageView)convertView.findViewById(R.id.left_image);			
			holder.imageMid = (ImageView)convertView.findViewById(R.id.mid_image);
			holder.imageRight = (ImageView)convertView.findViewById(R.id.right_image);
			convertView.setTag(holder);
		} else {
			holder = (PhotoHolder) convertView.getTag();
		}
		
		applyThemeForListItem(holder);
		
		Item item = mDataList.get(position);
		if(item==null){
			return convertView;
		}
		holder.id = item.getId();
		setTextData(item, holder);		
		
		if(!((PullRefreshListView)mListView).isBusy()){
			setThreeSmallImage(item, holder, FROM_REMOTE);
		}else{			 
			setThreeSmallImage(item, holder, FROM_LOCAL);		
		}
		
		return convertView;		
	}
	

	private View setTextMode(View convertView, int position, PhotoHolder holder){
		if (convertView == null) {
			holder = new PhotoHolder();
			convertView = LayoutInflater.from(mContext).inflate(R.layout.photo_list_text_item, null);
			holder.title = (TextView)convertView.findViewById(R.id.photo_title_text);
			//holder.stract = (TextView)convertView.findViewById(R.id.photo_count_text);
			holder.comments = (TextView)convertView.findViewById(R.id.photo_comments_text);
			holder.commentIcon = (ImageView) convertView.findViewById(R.id.list_comments_icon);
			holder.imageIcon = (ImageView) convertView.findViewById(R.id.list_image_count_icon);
			holder.imageCount = (TextView) convertView.findViewById(R.id.photo_count_text);
			convertView.setTag(holder);
		} else {
			holder = (PhotoHolder) convertView.getTag();
		}
		
		applyThemeForListItem(holder);		
		Item item = mDataList.get(position);
		if(item==null){
			return convertView;
		}
		setTextData(item, holder);
		return convertView;
	}
	
	protected static class PhotoHolder{
		String id;
		TextView title;
		TextView stract;
		TextView comments;
		TextView imageCount;
		ImageView commentIcon;			
		ImageView imageIcon;		
		ImageView image;
		ImageView imageLeft;   //列表页三个小图中最左边的一个
		ImageView imageMid;    //列表页三个小图中中间的一个
		ImageView imageRight;  //列表页三个小图中最右边的一个
		String showType;
	}
	
	protected static class Tag{
		String id;		
		int position;  //如果是一张大图position=0，如果是三张小图position=1，2，3分别表示左中右
	}
	
	 //夜间模式的处理
		public void applyThemeForListItem(PhotoHolder holder){
			if(holder==null){
				return;
			}			
			if(themeSettingsHelper.isNightTheme()){//设置夜间模式图标和字体颜色
				//SLog.d("#################","applyThemeForListItem");
				if(holder.title!=null){
					holder.title.setTextColor(mContext.getResources().getColor(R.color.night_list_title_color));
				}
				if(holder.stract!=null){
					 holder.stract.setTextColor(mContext.getResources().getColor(R.color.night_list_abstract_color));
				}			
				if(holder.imageCount!=null){
					holder.imageCount.setTextColor(mContext.getResources().getColor(R.color.night_list_image_count_color));
				}
				if(holder.comments!=null){
					holder.comments.setTextColor(mContext.getResources().getColor(R.color.night_list_comment_color));
				}
				if(holder.commentIcon != null){
					holder.commentIcon.setImageDrawable(mContext.getResources().getDrawable(R.drawable.night_list_item_comment_icon));				
				}
				
				if(holder.imageIcon!=null){
					holder.imageIcon.setImageDrawable(mContext.getResources().getDrawable(R.drawable.night_photo_list_image_icon));	
				}
			}
			else{
				if(holder.title!=null){
					holder.title.setTextColor(mContext.getResources().getColor(R.color.list_title_color));
				}
				if(holder.stract!=null){
					 holder.stract.setTextColor(mContext.getResources().getColor(R.color.list_abstract_color));
				}			
				if(holder.imageCount!=null){
					holder.imageCount.setTextColor(mContext.getResources().getColor(R.color.list_image_count_color));
				}
				if(holder.comments!=null){
					holder.comments.setTextColor(mContext.getResources().getColor(R.color.list_comment_color));
				}
				if(holder.commentIcon != null){
					holder.commentIcon.setImageDrawable(mContext.getResources().getDrawable(R.drawable.list_item_comment_icon));				
				}
				
				if(holder.imageIcon!=null){
					holder.imageIcon.setImageDrawable(mContext.getResources().getDrawable(R.drawable.photo_list_image_icon));	
				}
			}
		}
		
	/*public void setPhotoListImage(ImageView srcImage,Bitmap bm){
		setPhotoListImage(srcImage,bm,"three");
	}*/
	
	/**
	 * 设置显示图片
	 * @param srcImage
	 * @param bm
	 * @param showType big:一张大图格式  three:三张小图格式
	 */
	public void setPhotoListImage(ImageView srcImage,Bitmap bm,int showType){
		if(bm == null || srcImage==null){
			return;
		}
		
		if(showType==Constants.TYPE_ITEM_IMAGE){
			int desImageViewWidth = 0;
			int desImageViewHeight = 0;
			int totalWidth = MobileUtil.getScreenWidthIntPx()-MobileUtil.dpToPx(12*2);
			desImageViewWidth = totalWidth;
			desImageViewHeight = (int)(desImageViewWidth / 1.939393939393939);
			LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) srcImage.getLayoutParams();
			lp.width = desImageViewWidth;
			lp.height = desImageViewHeight;
			srcImage.setLayoutParams(lp);
			
			srcImage.setScaleType(ScaleType.CENTER_CROP);
			srcImage.setImageBitmap(bm);		
			/*if(themeSettingsHelper.isNightTheme()){
				srcImage.setImageDrawable(ImageUtil.getBlackBitmap(bm));
			}else{
				srcImage.setImageBitmap(bm);				
			}*/
		}else{
			int desImageViewWidth = 0;
			int desImageViewHeight = 0;
			//int totalWidth = MobileUtil.getScreenWidthIntPx()-MobileUtil.dpToPx(12*2);
			int totalWidth = MobileUtil.getScreenWidthIntPx()-MobileUtil.dpToPx(12*2 + 7*2 );
			//desImageViewWidth = totalWidth;
			desImageViewWidth = totalWidth/3;
			desImageViewHeight = (int)(desImageViewWidth*0.7);
			LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) srcImage.getLayoutParams();
			lp.width = desImageViewWidth;
			lp.height = desImageViewHeight;
			
			srcImage.setLayoutParams(lp);
			srcImage.setScaleType(ScaleType.FIT_XY);			
			srcImage.setImageBitmap(bm);		
			/*if(themeSettingsHelper.isNightTheme()){
				srcImage.setImageDrawable(ImageUtil.getBlackBitmap(bm));
			}else{
				srcImage.setImageBitmap(bm);				
			}*/
		}
	}
	
	protected void setTextData(Item item, PhotoHolder holder){
		if(item != null && item.getId()!=null){
			if (SpNewsHadRead.isNewsHadRead(item.getId())) {
				if(themeSettingsHelper.isNightTheme()){
					holder.title.setTextColor(mContext.getResources().getColor(R.color.night_readed_news_title_color));
				}else{
					holder.title.setTextColor(mContext.getResources().getColor(R.color.readed_news_title_color));
				}
			} else {
				if(themeSettingsHelper.isNightTheme()){
					holder.title.setTextColor(mContext.getResources().getColor(R.color.night_list_title_color));
				}else{
					holder.title.setTextColor(mContext.getResources().getColor(R.color.list_title_color));
				}				
			}				
			
			holder.title.setText(item.getTitle());
			holder.imageCount.setText(item.getImageCount());
			holder.comments.setText(item.getCommentNum());
			holder.showType=item.getShowType();//图片显示方式
			//if(holder.showType!=null){
			//	holder.title.setText(item.getTitle()+"("+holder.showType+")");
			//}
		}
	}
	
	protected Bitmap getBitMapImage(Item item, Tag tag,  int type, String url, int fromWhere){		
		Bitmap retBitmap = null;	
		ImageResult result = null;
		GetImageRequest request = new GetImageRequest();		
		
		request.setGzip(false);
		request.setTag(tag);
		request.setUrl(url);
		if(fromWhere == FROM_REMOTE){
			result = TaskManager.startSmallImageTask(request,this);
		}else{
			result = TaskManager.getLocalIconImage(request, this);
		}
		
		if(result.isResultOK() && result.getRetBitmap() != null){
			retBitmap = result.getRetBitmap();				
		}else{
			if(type==Constants.TYPE_ITEM_THREE_PHOTO){
				if(themeSettingsHelper.isNightTheme()){
					retBitmap = DefaulImageUtil.getNightDefaultPhotoListImage();
				}
				else{
					retBitmap = DefaulImageUtil.getDefaultPhotoListImage();
				}
			}else{	
				if(themeSettingsHelper.isNightTheme()){
					retBitmap = DefaulImageUtil.getNightDefaultListHeadImage();
				}else{
					retBitmap = DefaulImageUtil.getDefaultListHeadImage();
				}				
			}
		}		
		return retBitmap;
	}
	
	
	@Override
	public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm,String path) {
		// TODO Auto-generated method stub
		Tag photoTag = (Tag) tag;
		////SLog.d("####onImageRecvOK###", photoTag.id);
		switch(imageType){
		case SMALL_IMAGE:
			int countImage = mListView.getChildCount();
			for(int i = 0; i < countImage; i++){
				PhotoHolder holder = (PhotoHolder) mListView.getChildAt(i).getTag();
				if(holder != null){
					if(((String)photoTag.id).equals(holder.id)){
						switch(photoTag.position){
							case 0:
								setPhotoListImage(holder.image,bm,Constants.TYPE_ITEM_IMAGE);
								break;
							case 1:
								setPhotoListImage(holder.imageLeft,bm,Constants.TYPE_ITEM_THREE_PHOTO);
								break;
							case 2:
								setPhotoListImage(holder.imageMid,bm,Constants.TYPE_ITEM_THREE_PHOTO);
								break;								
							case 3:
								setPhotoListImage(holder.imageRight,bm,Constants.TYPE_ITEM_THREE_PHOTO);
								break;
							default:
							    break;
						}	
						
						break;
					}					
				}
			}
			break;
		default:
			break;
		}
	}

	@Override
	public void onImageRecvError(ImageType imageType, Object tag, int retCode) {
		// TODO Auto-generated method stub		
		////SLog.d("####onImageRecvError###", photoTag.id);
	}
	
	@Override
	public void serListViewBusy(int currPosition, int tag) {
		// TODO Auto-generated method stub		
		//SLog.d("####serListViewBusy###",String.valueOf(currPosition));
		if(itemType == Constants.TYPE_ITEM_TEXT){
			return;
		}
		PhotoHolder holder = (PhotoHolder)mListView.getChildAt(tag).getTag();		
		if(currPosition >= 0 && currPosition < mDataList.size() && holder != null){
			Item item = mDataList.get(currPosition);
			if(item !=null && item.getShowType()!=null && item.getShowType().trim().equals("three")){
				setThreeSmallImage(item, holder, FROM_REMOTE);
			}else{
				setOneBigImage(item, holder, FROM_REMOTE);
			}
			//SLog.d("####serListViewBusy###", item.getShowType()+"|"+styleType + "|" + holder.id +"|" +  item.getTitle() + "|" + String.valueOf(currPosition));
		}
		
	}
}
