package com.tencent.news.ui;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;

import com.tencent.news.R;
import com.tencent.news.config.Constants;
import com.tencent.news.model.pojo.ListMapData;
import com.tencent.news.system.Application;
import com.tencent.news.system.ChannelLoadReceiver;
import com.tencent.news.ui.view.ChannelBarNew;
import com.tencent.news.ui.view.NetTipsBar;
import com.tencent.news.ui.view.TitleBar;
import com.tencent.news.ui.view.ViewPagerEx;
import com.tencent.news.utils.InfoConfigUtil;
import com.tencent.news.utils.SLog;
import com.tencent.omg.webdev.WebDev;

public class HomeChannelActivity extends AbsActivityGroup {
	protected ChannelLoadReceiver mChannelLoadReceiver;
	protected mailAndAtCountReceiver mMailAndAtReceiver=null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		registerMailAndATReceiver();
	}
	
	@Override
	protected void setContainerView(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		setContentView(R.layout.home_channel_layout);
		mChannelViewPager = (ViewPagerEx) findViewById(R.id.channel_view_pager);
		mTitleBar = (TitleBar) findViewById(R.id.channel_title_bar);
		mTitleBar.ShowMainBar(R.string.title_news, R.drawable.title_setting_btn);
		mChannelBar = (ChannelBarNew) findViewById(R.id.channel_bar);
		mNetTipsBar = (NetTipsBar) findViewById(R.id.news_nettips_bar);
		mOneChannelHide = false;// 只剩一个频道时不隐藏
	}

	@Override
	protected Class<? extends Object> getChannelClassName(Object channel) {
		// TODO Auto-generated method stub
		return ImportantNewsActivity.class;
	}

	@Override
	protected void getChannelData() {
		// TODO Auto-generated method stub
		IntentFilter filter = new IntentFilter(Constants.NEWS_CHANNEL_NEW_LOAD);
		mChannelLoadReceiver = new ChannelLoadReceiver(mHandler);
		this.registerReceiver(mChannelLoadReceiver, filter);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		SLog.i("ChannelBarBase", " onActivityResult " + String.valueOf(requestCode) + " " + String.valueOf(resultCode));
		if (resultCode == RESULT_OK) {
			if (requestCode == Constants.REQUEST_CODE_SET_CHANNEL) {
				Bundle bundle = data.getExtras();
				ListMapData channels = (ListMapData) bundle.getSerializable(Constants.SUB_CHANNEL);
				if (channels != null && channels.getMenuDataMap() != null && channels.getMenuDataMap().size() > 0) {
					// Application.getInstance().setNewsChannelSelected(channels);
					Application.getInstance().setChannelList(channels);
					InfoConfigUtil.WriteSubChannel(channels);
					mChannelBar.refresh();
				}
			}
		}
	}

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
		int cIndex = getCurrentChannel();
		mChannelBar.setActive(cIndex);
	}

	@Override
	public void onRestoreInstanceState(Bundle savedInstanceState) {
		super.onRestoreInstanceState(savedInstanceState);
		setCurrentChannel(savedInstanceState.getInt(Constants.NEWS_CURRENT_CHANNEL));
	}

	@Override
	public void onSaveInstanceState(Bundle savedInstanceState) {
		super.onSaveInstanceState(savedInstanceState);
		savedInstanceState.putInt(Constants.NEWS_CURRENT_CHANNEL, nCurrChannel);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (mChannelLoadReceiver != null) {
			unregisterReceiver(mChannelLoadReceiver);
			mChannelLoadReceiver = null;
		}
		if(mMailAndAtReceiver!=null){
			unregisterReceiver(mMailAndAtReceiver);
			mMailAndAtReceiver = null;
		}
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}
	
	protected void registerMailAndATReceiver() {
        if (mMailAndAtReceiver == null) {
        	//SLog.d("====","registerMailAndATReceiver");
        	mMailAndAtReceiver = new mailAndAtCountReceiver();
            IntentFilter filter = new IntentFilter(Constants.UPDATE_MAIL_AND_AT_COUNT);
            registerReceiver(mMailAndAtReceiver, filter);
        }
    }
	
	//处理MainActivity.java中mCheckNewSubscribeCallback()从服务器端接收到的私信和“提到我的”评论数后发出的广播
	protected class mailAndAtCountReceiver extends BroadcastReceiver {	    
	    @Override
        public void onReceive(Context context, Intent intent) {
            if (intent!=null && intent.getAction()!=null && 
               intent.getAction().equals(Constants.UPDATE_MAIL_AND_AT_COUNT) && 
               intent.hasExtra("action") && intent.hasExtra("mailCount") && 
               intent.hasExtra("atCount")) {
            	
            	 //SLog.d("====","mailAndAtCountReceiver");
            	 String action = intent.getStringExtra("action");
            	 if(mTitleBar!=null && action!=null && action.equals("update")){
            		 int mailNum = intent.getIntExtra("mailCount", 0);
            		 int atNum =  intent.getIntExtra("atCount", 0);   
            		 //SLog.d("==mailAndAtCountReceiver==","mail:" + String.valueOf(mailNum) + " at:"+String.valueOf(atNum));
            		 if( mailNum + atNum > 0){            			 
            		     mTitleBar.showRemindRedDot();            			 
            		 }else{
            			 mTitleBar.hideRemindRedDot();
            		 }
            	 }
            }
        }
	}
	
	
}
