package com.tencent.news.ui.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.tencent.news.R;

public class ImageDetailView extends FrameLayout{
	private Context mContext;
	private ViewPagerEx2 mImagesViewPager;
	private LinearLayout mLinearLayout;
	private ScrollView mScrollView;
	private TextView mPicContent;
	private View mView;
	
	public ImageDetailView(Context context) {
		super(context);
		init(context);
	}

	public ImageDetailView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init(context);
	}
	
	private void init(Context context){
		this.mContext = context;
		LayoutInflater.from(context).inflate(R.layout.image_detail_view_layout, this, true);
		mImagesViewPager = (ViewPagerEx2) findViewById(R.id.images_viewpager);
		mPicContent = (TextView) findViewById(R.id.picture_content_text);
		mLinearLayout = (LinearLayout) findViewById(R.id.photo_detail_text_layout);
		mScrollView = (ScrollView) findViewById(R.id.photo_scroll_view);
		mView = (View) findViewById(R.id.stance_view);
	}

	public ViewPagerEx2 getImagesViewPager(){
		return this.mImagesViewPager;
	}
	
	public LinearLayout getLinearLayout(){
		return this.mLinearLayout;
	}
	
	public ScrollView getScrollView(){
		return this.mScrollView;
	}
	
	public TextView getTextView(){
		return this.mPicContent;
	}
	
	public View getView(){
		return this.mView;
	}
}
