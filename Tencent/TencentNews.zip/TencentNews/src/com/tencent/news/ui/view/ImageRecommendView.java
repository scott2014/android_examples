/**
 * 图片相关推荐视图
 */
package com.tencent.news.ui.view;

import java.util.List;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.FrameLayout;
import android.widget.GridView;

import com.tencent.news.R;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.ui.adapter.ImageRecommendAdapter;

public class ImageRecommendView extends FrameLayout {
	private Context mContext;
	private GridView mGridView;
	private ImageRecommendAdapter mAdapter;
	private FrameLayout mFrameLayout;
	
	/**
	 * 构造函数
	 * @param context
	 */
	public ImageRecommendView(Context context){
		super(context);
		init(context);
	}
	/**
	 * 构造函数
	 * @param context
	 * @param attrs
	 */
	public ImageRecommendView(Context context, AttributeSet attrs){
		super(context, attrs);
		init(context);
	}
	/**
	 * 初始化函数
	 * @param context
	 */
	public void init(Context context){
		this.mContext = context;
		LayoutInflater.from(context).inflate(R.layout.image_recommend_view_layout, this, true);
		mFrameLayout = (FrameLayout) findViewById(R.id.photo_recommend_framelayout);
		mGridView = (GridView) findViewById(R.id.image_recommend_view);
		mAdapter = new ImageRecommendAdapter(context,mGridView);
	}
	
	public void setdata(List<Item> picDataList){
		mAdapter.setPicDataList(picDataList);
		mGridView.setAdapter(mAdapter);
	}
	
	public GridView getGridView(){
		return mGridView;
	}
	
	public FrameLayout getFrameLayout(){
		return mFrameLayout;
	}
}
