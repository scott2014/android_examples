package com.tencent.news.ui;

import java.io.File;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.entity.AbstractHttpEntity;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.DefaultHttpClient;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.LocalActivityManager;
import android.app.TabActivity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap.Config;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo.State;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.boss.EventId;
import com.tencent.news.cache.FavorSyncHelper;
import com.tencent.news.cache.RssChannelSyncHelper;
import com.tencent.news.cache.UserDBHelper;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpDataResponse;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.download.APPDownloadListener;
import com.tencent.news.download.DownloadConstants;
import com.tencent.news.download.DownloadDataCheck;
import com.tencent.news.download.DownloadManager;
import com.tencent.news.download.Downloader;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.model.pojo.CheckSubscribe;
import com.tencent.news.model.pojo.ExtendedChannels;
import com.tencent.news.model.pojo.ListMapData;
import com.tencent.news.model.pojo.NewsVersion;
import com.tencent.news.rss.RssActivity;
import com.tencent.news.rss.RssGuideFragmentActivity;
import com.tencent.news.rss.RssListBaseActivity;
import com.tencent.news.shareprefrence.SpConfig;
import com.tencent.news.shareprefrence.SpSetting;
import com.tencent.news.system.Application;
import com.tencent.news.system.NetStatusReceiver;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.NavigationBar;
import com.tencent.news.ui.view.NavigationBar.NavigationListener;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.news.utils.FileUtil;
import com.tencent.news.utils.InfoConfigUtil;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.ThemeSettingsHelper;
import com.tencent.news.utils.ThemeSettingsHelper.ThemeCallback;
import com.tencent.omg.webdev.WebDev;

public class MainActivity extends TabActivity implements ThemeCallback, APPDownloadListener {
	private static final String TAG = "MainActivity";
	private static final int CREATE_DIALOG_QUIT = 155;
	private static final int DIALOG_NEW_VERSION = 156;
	private static final int DIALOG_NEW_VERSION_INSTALL = 157;
	private static final long UPDATA_TIME = 24 * 60 * 60L;
	private static final int UPGRADE = 0x1;
	private static final int REPORTED_LOG = 0x2;
	private static final int DISMISS_MENU = 0x3;
	private static final int CHANGE_THEME = 0x4;
	private static final long DISMISS_TIME = 10L;
	private LocalActivityManager localManager;
	private TabHost mTabHost;
	private NavigationBar mNavigationBar = null;
	private NewsVersion mVersion = Application.getInstance().getVersion();
	private ExtendedChannels mExtendedChannel;
	private PopupWindow popupMenu;
	private Button btnModel = null, btnSet = null, btnFavorites = null, btnMyComment = null, btnExit = null, btnTheme = null, btnOffLineDownLoad = null;
	private SettingInfo settingData;
	private RelativeLayout menuLayout;
	private View mMask;
	private View mMenuMask;
	private List<String> mActivityId = new ArrayList<String>();
	private String mTab;
	private String mChannel;
	private int milliSeconds = 2 * 1000;
	private long keyCodeBackLastDownTime = Integer.MIN_VALUE;
	private Toast keyCodeBackToast = null;
	private Thread uploadThread = null;
	private ImageView btn_setting_show_new_version_tips = null;
	private boolean isClickUpdateNow = false;
	private int mState = DownloadConstants.T_DOWNLOAD;
	private String versionCode = "";
	private String updateUrl = "";
	protected ThemeSettingsHelper themeSettingsHelper = null;
	private ImageView menu_image_view1;
	private ImageView menu_image_view2;
	private ImageView menu_image_view3;
	private ImageView menu_image_view4;
	private ImageView menu_image_view5;
	private ImageView menu_image_view6;
	private int padding_top = 0, padding_bottom = 0,  padding_drawable = 0;
	private int spadding_top = 0, spadding_bottom = 0, spadding_drawable = 0;
	private int mailCount = 0, atCount = 0; //未读私信数量、未读“提到我的”评论数量	
	
	//RSS
	private RSSGuideFinishedReceiver mRSSGuideFinishedReceiver;
	private int mRSSIndex;
	private int mRSSGuideIndex;
	private TextView unreadTextView = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main_layout);
		if (savedInstanceState != null) {
			ListMapData channel = (ListMapData) savedInstanceState.getSerializable(Constants.SAVE_SUB_CHANNELLIST_KEY);
			NewsVersion version = (NewsVersion) savedInstanceState.getSerializable(Constants.SAVE_NEWS_VERSION_KEY);
			Application.getInstance().setChannelList(channel);
			Application.getInstance().setVersion(version);
		}
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(Application.getInstance().getApplicationContext());
		getIntentData(getIntent());
		compute_padding();
		initPopuWindows();
		InitView();
		InitListener();
		setupTabs();
		mHandler.sendEmptyMessageDelayed(UPGRADE, 1000);
		mHandler.sendEmptyMessageDelayed(REPORTED_LOG, 30000);
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(this);
		themeSettingsHelper.registerThemeCallback(this);
		themeSettingsHelper.loadDefaultTheme(this);
		RssChannelSyncHelper.getInstance().onAppStart();
		FavorSyncHelper.getInstance().sync();
		(new Timer()).schedule(mCheckNewSubscribe, 10000, 300000);
		
		RSSRefreshReceiver rssReceiver = new RSSRefreshReceiver();
		IntentFilter filter = new IntentFilter(RssActivity.RSS_MULTI_REFRESH_FINISH);
		registerReceiver(rssReceiver, filter);
	}
	
	private TimerTask mCheckNewSubscribe = new TimerTask() {
		@Override
		public void run() {
			//如果已经显示小红点，就不再刷新，节省流量。
			//这样会导致实际未读数与提示的未读数不一致
//			if(mNavigationBar.isRSSRedDotShow()) {
//				return;
//			}
			if (NetStatusReceiver.netStatus != NetStatusReceiver.NETSTATUS_INAVAILABLE) {	
				long time = SpConfig.getRSSRefreshTime() / 1000;
				HttpDataRequest request = TencentNews
						.getInstance()
						.getCheckNewSubscribeRequest(
								RssChannelSyncHelper.getInstance().getRssChannelIdString(), time);
				
				TaskManager.startHttpDataRequset(request, mCheckNewSubscribeCallback);
			}
		}
	};
	
	private void broadCastAtAndMailCounts(String act, int mailCount, int atCount){
		Intent intent = new Intent();
        intent.setAction(Constants.UPDATE_MAIL_AND_AT_COUNT);
        intent.putExtra("mailCount", mailCount);
        intent.putExtra("atCount", atCount);			        
        intent.putExtra("action", act);			        
        sendBroadcast(intent);
	}
	
	private HttpDataResponse mCheckNewSubscribeCallback = new HttpDataResponse() {
		@Override
		public void onHttpRecvOK(HttpTag tag, Object result) {
			if (tag.equals(HttpTag.CHECK_SUBSCRIBE_UPDATE)){
				CheckSubscribe check = (CheckSubscribe) result;
				if("0".equals(check.getRet())) {
					if("1".equals(check.getUpdateFlag())) {					
						SpConfig.setHasNewRSS(true);
						mNavigationBar.showRSSRedDot(true);
					} else {
						SpConfig.setHasNewRSS(false);
					}
				}
				
			    mailCount = check.getMail()==null? 0:Integer.parseInt(check.getMail());
				atCount = check.getAt()==null? 0:Integer.parseInt(check.getAt());
				//atCount = 5;
				//mailCount = 105;
				if (mailCount > 0 || atCount > 0) {
					broadCastAtAndMailCounts("update", atCount, atCount);
					setPopWdRemindRedDot(atCount, atCount);					
				}				
			}
		}
		
		@Override
		public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {	    
		    
		    
		}
		
		@Override
		public void onHttpRecvCancelled(HttpTag tag) {
			
		}
	};
	private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case UPGRADE:
				VersionUpdateCheck();
				break;
			case REPORTED_LOG:
				// 开发状�?不上报crash日志
				if (MobileUtil.getDebugMode()) {
					break;
				}

				uploadThread = new Thread(new Runnable() {

					@Override
					public void run() {
						File uploadDir = new File(Constants.LOG_PATH);
						File[] uploadFiles = uploadDir.listFiles();
						if (uploadFiles != null) {
							int reportNum = uploadFiles.length;
							if (reportNum > 0) {
								for (File curFile : uploadFiles) {
									String finalData = (String) FileUtil.readString(curFile.getPath());
									if (finalData != null && finalData.length() > 0) {
										try {
											if (send(finalData.getBytes())) {// TODO:Gzip
												curFile.delete();
											}
										} catch (Exception e) {
											e.printStackTrace();
										}
									}
									try {
										Thread.sleep(3000);
									} catch (InterruptedException e) {
										e.printStackTrace();
									}
								}
							}
						} else {
						}
					}
				});
				uploadThread.start();
				break;
			case DISMISS_MENU:
				dismissMenu();
				break;
			case CHANGE_THEME:
				settingData = SettingObservable.getInstance().getData();
				if (settingData != null && themeSettingsHelper.getCurrentThemePackage() == Constants.SETTING_THEME_NIGHT_MODE) {// 目前是夜间模�?
					themeSettingsHelper.changeTheme(Application.getInstance().getApplicationContext(), Constants.SETTING_THEME_DEFAULT_MODE);
				} else {
					themeSettingsHelper.changeTheme(Application.getInstance().getApplicationContext(), Constants.SETTING_THEME_NIGHT_MODE);
				}

				// String value = themeSettingsHelper.isNightTheme() ? "1" :
				// "0";
				// Statistics.getInstance().saveStatistics(Statistics.REPORTED_DATA_SETTING,
				// StatisticsUtil.generateCustomField(new String[] {
				// Statistics.REPORTED_DATA_KEY_NIGHT_MODE, value, "", "", "",
				// "", "" }));
				// Statistics.getInstance().reportAllInTime();

				WebDev.trackCustomEvent(MainActivity.this, EventId.BOSS_SETTING_NIGHTMODE, new String[] { themeSettingsHelper.isNightTheme() ? "1" : "0" });

				// SLog.d("### setTheme ###",
				// String.valueOf(themeSettingsHelper.getCurrentThemePackage()));
				SettingObservable.getInstance().setData(settingData);
				SpSetting.saveSetting(settingData);
			default:
				break;
			}
		}
	};

	private boolean send(byte[] strReport) {
		HttpClient httpClient = null;
		try {
			httpClient = new DefaultHttpClient();

			HttpPost httpPost = new HttpPost(TencentNews.QQNEWS_UPLOAD_LOG);

			AbstractHttpEntity entity = new ByteArrayEntity(strReport);
			httpPost.setEntity(entity);

			HttpResponse mHttpResponse = httpClient.execute(httpPost);

			if (mHttpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
				return true;
			}
		} catch (UnknownHostException e3) {
			e3.printStackTrace();
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			if (httpClient != null) {
				ClientConnectionManager ccm = httpClient.getConnectionManager();
				if (ccm != null) {
					ccm.closeExpiredConnections();
				}
			}
		}
		return false;

	}

	private void getIntentData(Intent intent) {
		try {
			if (intent != null) {
				Uri data = intent.getData();
				mTab = data.getQueryParameter("tab");
				mChannel = data.getQueryParameter("channel");
			}
		} catch (Exception e) {
			e.printStackTrace();
			mTab = TencentNews.NEWS;
			mChannel = TencentNews.NEW_TOP;
		}
	}

	private void InitView() {
		localManager = getLocalActivityManager();
		mNavigationBar = (NavigationBar) findViewById(R.id.main_navigation_bar);
		mMask = (View) findViewById(R.id.mask_view);
		mActivityId.add(TencentNews.NEWS);
		mActivityId.add(TencentNews.PHOTO);
		mActivityId.add(TencentNews.VIDEO);
		mActivityId.add(TencentNews.RSS);
		mActivityId.add(TencentNews.RSS_GUIDE);
	}

	private boolean isFileExist() {

		if ("".equals(updateUrl)) {
			return true;
		}

		String fileName = Downloader.getLocalfileName(updateUrl);
		String localAPKPath = Downloader.DOWNLOAD_PATH + "_" + Constants.APPID + "_" + fileName;
		File f = new File(localAPKPath);
		if (f.exists()) {
			SLog.d(TAG, "f.exists()");
			return true;
		} else {
			return false;
		}
	}

	private boolean isWifi() {

		ConnectivityManager conMan = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		State wifi = conMan.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState();
		SLog.d("hj", wifi.toString());
		if (wifi != null && wifi == State.CONNECTED) {
			SLog.d(TAG, "wifi State.CONNECTED");
			return true;
		}
		return false;
	}

	private void doSilentDownload() {

		if (isWifi() && mState != DownloadConstants.T_INSTALL) {
			SLog.d(TAG, "start silentDownload");
			SpConfig.setSilentDownloadFlag(Constants.SILENT_START_DOWNLOAD);
			DownloadManager.getInstance().doStateAction(Constants.APPID, mState, updateUrl, "com.tencent.news", "腾讯新闻", MainActivity.this, versionCode, false);
		}
	}

	private void checkNewVersionState(boolean isPopNewVersion) {

		versionCode = mVersion.getVersion();
		updateUrl = mVersion.getUrl();
		DownloadManager.getInstance().addAppListener(Constants.APPID, this);
		mState = DownloadDataCheck.getInstance().checkDBOption(Constants.APPID, versionCode, updateUrl);

		if (!isFileExist()) {
			mState = DownloadConstants.T_DOWNLOAD;
		}

		if (mState == DownloadConstants.T_INSTALL) {
			if (SpConfig.getSilentDownloadFlag() == Constants.SILENT_START_DOWNLOAD) {
				SpConfig.setSilentDownloadFlag(Constants.SILENT_DEFAULT);
				showDialog(DIALOG_NEW_VERSION_INSTALL);
			} else if (isPopNewVersion) {
				showDialog(DIALOG_NEW_VERSION);
			}
		} else {
			if (isPopNewVersion) {
				showDialog(DIALOG_NEW_VERSION);
			} else {
				doSilentDownload();
			}
		}
	}

	private void VersionUpdateCheck() {

		long oldTime = SpConfig.getNextUpdataTime();
		long currTime = System.currentTimeMillis() / 1000;
		if (MobileUtil.versionUpgrade(mVersion)) {
			checkNewVersionState(currTime >= oldTime);
		}
	}

	private void InitListener() {
		mNavigationBar.setOnNavigationListener(new NavigationListener() {
			@Override
			public void onOnNavigationBarClick(int nIndex, boolean refresh) {
				try {
					if (mTabHost != null) {
					    
					    if(nIndex == mRSSIndex) {
                            mNavigationBar.showRSSRedDot(false);
                        }
					    
					    //handle rss guide
	                    if(nIndex == mRSSIndex) {
	                        if(!SpConfig.getRSSGuideAlreadyRun()) {
	                            mTabHost.setCurrentTab(mRSSGuideIndex);
	                            if (refresh) {
	                                Activity activity = (Activity) localManager.getActivity(mActivityId.get(mRSSGuideIndex));
	                                if (activity instanceof RssGuideFragmentActivity) {
	                                    ((RssGuideFragmentActivity) activity).getData();
	                                }
	                            }
	                            return;
	                        }
	                    }
					    
						mTabHost.setCurrentTab(nIndex);
						if (mRSSIndex == nIndex){
						    WebDev.trackCustomEvent(MainActivity.this, EventId.BOSS_RSS_CLICK_TAB);
						}

						if (refresh) {
							Activity activity = (Activity) localManager.getActivity(mActivityId.get(nIndex));
							if (activity instanceof HomeChannelActivity) {
								((HomeChannelActivity) activity).setRefreshData();
							} else if (activity instanceof HomePhotoActivity) {
								((HomePhotoActivity) activity).setRefreshData();
							} else if (activity instanceof HomeVideoActivity) {
								((HomeVideoActivity) activity).setRefreshData();
							} else if (activity instanceof AbsChannelActivityNew) {
								((AbsChannelActivityNew) activity).getNewData();
							} else if (activity instanceof ExtendedChannelsActivity) {
								((ExtendedChannelsActivity) activity).setRefreshData();
							} else if (activity instanceof RssListBaseActivity) {
                                ((RssListBaseActivity) activity).onRefreshClick();
                            }
						}

					}
				} catch (OutOfMemoryError e) {
					e.printStackTrace();
				}
			}

		});

	}

	/**
	 * 设置Tab
	 */
	private void setupTabs() {
		mTabHost = this.getTabHost();
		Intent intent = new Intent(this, HomeChannelActivity.class);
		intent.putExtra(Constants.WEIXIN_CHANNEL, mChannel);
		mTabHost.addTab(mTabHost.newTabSpec(mActivityId.get(0)).setIndicator(mActivityId.get(0)).setContent(intent));

		mTabHost.addTab(mTabHost.newTabSpec(mActivityId.get(1)).setIndicator(mActivityId.get(1)).setContent(getExtraIntent(TencentNews.PHOTO, HomePhotoActivity.class)));

		mTabHost.addTab(mTabHost.newTabSpec(mActivityId.get(2)).setIndicator(mActivityId.get(2)).setContent(getExtraIntent(TencentNews.VIDEO, HomeVideoActivity.class)));

		mTabHost.addTab(mTabHost.newTabSpec(mActivityId.get(3)).setIndicator(mActivityId.get(3)).setContent(getExtraIntent(TencentNews.RSS, RssActivity.class)));
		mRSSIndex = 3;
		
		if(!SpConfig.getRSSGuideAlreadyRun()) {
		    mTabHost.addTab(mTabHost.newTabSpec(mActivityId.get(4)).setIndicator(mActivityId.get(4)).setContent(getExtraIntent(TencentNews.RSS_GUIDE, RssGuideFragmentActivity.class)));
		    mRSSGuideFinishedReceiver = new RSSGuideFinishedReceiver();
		    IntentFilter filter = new IntentFilter(Constants.RSS_GUIDE_FINISHED_ACTION);
	        registerReceiver(mRSSGuideFinishedReceiver, filter);
	        mRSSGuideIndex =4;
		}
		    
		mExtendedChannel = InfoConfigUtil.ReadExtendedChannels();
		if (mNavigationBar.isShowExtendedTab(mExtendedChannel)) {
			Intent intent1 = new Intent(this, ExtendedChannelsActivity.class);
			intent1.putExtra(Constants.WEIXIN_CHANNEL, mChannel);
			mTabHost.addTab(mTabHost.newTabSpec(mExtendedChannel.getName()).setIndicator(mExtendedChannel.getName()).setContent(intent1));
			mActivityId.add(mExtendedChannel.getName());
		}
		if (mTab != null) {
			for (int i = 0; i < mActivityId.size(); i++) {
				String tab = mActivityId.get(i);
				if (mTab.equals(tab)) {
					mTabHost.setCurrentTab(i);
					mNavigationBar.setDefault(i);
					break;
				}
			}
		}
	}

	private Intent getExtraIntent(String chlid, Class<? extends Object> cls) {
		Intent intent = new Intent();
		intent.setClass(this, cls);
		intent.putExtra(Constants.NEWS_CHLIDE_CHANNEL, chlid);
		intent.putExtra(Constants.IS_FROM_VIEWPAGER, false);
		intent.putExtra(Constants.IS_START_CHANNEL, true);
		return intent;
	}

	private void resumeState(Bundle savedInstanceState) {
		String currentTab = (String) savedInstanceState.get("currentTab");
		// HomeChannelActivity mChannel = (HomeChannelActivity)
		// localManager.getActivity(.get(0));
		SLog.e("onRestoreInstanceState", currentTab);
		if (mActivityId.get(0).equals(currentTab)) {
			mNavigationBar.setDefault(0);
		} else if (mActivityId.get(1).equals(currentTab)) {
			mNavigationBar.setDefault(1);
		} else if (mActivityId.get(2).equals(currentTab)) {
			mNavigationBar.setDefault(2);
		} else if (mActivityId.get(3).equals(currentTab)) {
			mNavigationBar.setDefault(3);
		} else if (mExtendedChannel.getName().equals(currentTab)) {
			mNavigationBar.setDefault(4);
		}
		if (mExtendedChannel != null && mExtendedChannel.getName() != null) {
			String id = mExtendedChannel.getName();
			ExtendedChannelsActivity mExtendedChannel = (ExtendedChannelsActivity) localManager.getActivity(id);
			if (mExtendedChannel != null) {
				int nIndex = savedInstanceState.getInt(Constants.SAVE_CURRENT_EXTENDED_BAR);
				mExtendedChannel.setActive(nIndex);
			}
		}
	}

	@Override
	public void onSaveInstanceState(Bundle savedInstanceState) {
		super.onSaveInstanceState(savedInstanceState);
		if (mExtendedChannel != null && mExtendedChannel.getName() != null) {
			String id = mExtendedChannel.getName();
			ExtendedChannelsActivity mExtendedChannel = (ExtendedChannelsActivity) localManager.getActivity(id);
			if (mExtendedChannel != null) {
				savedInstanceState.putInt(Constants.SAVE_CURRENT_EXTENDED_BAR, mExtendedChannel.getCurrExtendedChannel());
			}
		}
		savedInstanceState.putSerializable(Constants.SAVE_SUB_CHANNELLIST_KEY, Application.getInstance().getChannelList());
		savedInstanceState.putSerializable(Constants.SAVE_NEWS_VERSION_KEY, Application.getInstance().getVersion());
	}

	@Override
	public void onRestoreInstanceState(Bundle savedInstanceState) {
		super.onRestoreInstanceState(savedInstanceState);
		resumeState(savedInstanceState);
	}

	@Override
	public boolean dispatchKeyEvent(KeyEvent event) {
		if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
			if (event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {
				if (null == keyCodeBackToast) {
					keyCodeBackToast = Toast.makeText(this, getResources().getString(R.string.keycode_back_alert_message), Toast.LENGTH_SHORT);
					keyCodeBackToast.show();
				} else if (milliSeconds < System.currentTimeMillis() - keyCodeBackLastDownTime) {
					keyCodeBackToast.show();
				} else {
					keyCodeBackToast.cancel();
					keyCodeBackToast = null;
					mainExit();
				}
				keyCodeBackLastDownTime = System.currentTimeMillis();
			}
			return true;
		}
		if (event.getKeyCode() == KeyEvent.KEYCODE_MENU && event.getRepeatCount() > 0) {
			return true;
		}

		if ((event.getKeyCode() == KeyEvent.KEYCODE_MENU) && event.getAction() == KeyEvent.ACTION_UP) {
			popUpMenu();
			return true;
		}

		return super.dispatchKeyEvent(event);
	}

	public void popUpMenu() {
		if (popupMenu.isShowing()) {
			if (popupMenu != null) {
				popupMenu.dismiss();
			}
		} else {
			if (popupMenu != null) {
				setModelBtnView();
				setThemeBtnView();
				setPopWdRemindRedDot(atCount, mailCount);
				popupMenu.showAtLocation(this.findViewById(R.id.main_navigation_bar), Gravity.BOTTOM, 0, 0);
			}
		}

	}

	protected void setModelBtnView() {
		if (btnModel != null) {
			settingData = SettingObservable.getInstance().getData();
			Drawable modelIcon = null;
			if (settingData != null && settingData.isIfTextMode()) {
				if (themeSettingsHelper.isDefaultTheme()) {
					modelIcon = getResources().getDrawable(R.drawable.menu_photo_model);
					btnModel.setBackgroundResource(R.drawable.menu_selectitem);
					btnModel.setText(getResources().getString(R.string.setting_photo_mode_title));
					btnModel.setTextColor(getResources().getColor(R.color.menu_icon_color));
					// btnModel.setTextColor(R.drawable.menu_text_color);
				} else {
					modelIcon = getResources().getDrawable(R.drawable.night_menu_photo_model);
					btnModel.setBackgroundResource(R.drawable.night_menu_selectitem);
					btnModel.setText(getResources().getString(R.string.setting_photo_mode_title));
					btnModel.setTextColor(getResources().getColor(R.color.night_menu_icon_color));
					// btnModel.setTextColor(R.drawable.night_menu_text_color);
				}

			} else {
				if (themeSettingsHelper.isDefaultTheme()) {
					modelIcon = getResources().getDrawable(R.drawable.menu_text_model);
					btnModel.setBackgroundResource(R.drawable.menu_selectitem);
					btnModel.setText(getResources().getString(R.string.setting_text_mode_title));
					btnModel.setTextColor(getResources().getColor(R.color.menu_icon_color));
					// btnModel.setTextColor(R.drawable.menu_text_color);
				} else {
					modelIcon = getResources().getDrawable(R.drawable.night_menu_text_model);
					btnModel.setBackgroundResource(R.drawable.night_menu_selectitem);
					btnModel.setText(getResources().getString(R.string.setting_text_mode_title));
					btnModel.setTextColor(getResources().getColor(R.color.night_menu_icon_color));
					// btnModel.setTextColor(R.drawable.night_menu_text_color);
				}

			}

			modelIcon.setBounds(0, 0, modelIcon.getMinimumWidth(), modelIcon.getMinimumHeight());
			btnModel.setCompoundDrawables(null, modelIcon, null, null);
			btnModel.setPadding(0, padding_top, 0, padding_bottom);
			btnModel.setCompoundDrawablePadding(padding_drawable);
		}
	}

	protected void setThemeBtnView() {
		if (btnModel != null) {
			settingData = SettingObservable.getInstance().getData();
			Drawable modelIcon = null;
			if (settingData != null && themeSettingsHelper.getCurrentThemePackage() == Constants.SETTING_THEME_DEFAULT_MODE) {
				modelIcon = getResources().getDrawable(R.drawable.night_night_menu_theme_mode);
				btnTheme.setBackgroundResource(R.drawable.menu_selectitem);
				btnTheme.setText(getResources().getString(R.string.night_theme_mode_title));
				btnTheme.setTextColor(getResources().getColor(R.color.menu_icon_color));
				// btnTheme.setTextColor(R.drawable.menu_text_color);

				// btnTheme.setTextColor(R.drawable.menu_text_color);
			} else {
				modelIcon = getResources().getDrawable(R.drawable.night_menu_theme_mode);
				btnTheme.setBackgroundResource(R.drawable.night_menu_selectitem);
				btnTheme.setText(getResources().getString(R.string.theme_mode_title));
				btnTheme.setTextColor(getResources().getColor(R.color.night_menu_icon_color));
				// btnTheme.setTextColor(R.drawable.night_menu_text_color);
			}

			modelIcon.setBounds(0, 0, modelIcon.getMinimumWidth(), modelIcon.getMinimumHeight());
			btnTheme.setCompoundDrawables(null, modelIcon, null, null);
			btnTheme.setPadding(0, padding_top, 0, padding_bottom);
			btnTheme.setCompoundDrawablePadding(padding_drawable);
		}
	}

	protected void setSetBtnView() {
		if (btnModel != null) {
			// settingData = SettingObservable.getInstance().getData();
			Drawable modelIcon = null;
			if (themeSettingsHelper.isDefaultTheme()) {
				modelIcon = getResources().getDrawable(R.drawable.menu_setting);
				btnSet.setBackgroundResource(R.drawable.menu_selectitem);
				btnSet.setTextColor(getResources().getColor(R.color.menu_icon_color));
				// btnSet.setTextColor(R.drawable.menu_text_color);
			} else {
				modelIcon = getResources().getDrawable(R.drawable.night_menu_setting);
				btnSet.setBackgroundResource(R.drawable.night_menu_selectitem);
				btnSet.setTextColor(getResources().getColor(R.color.night_menu_icon_color));
				// btnSet.setTextColor(R.drawable.night_menu_text_color);
			}

			modelIcon.setBounds(0, 0, modelIcon.getMinimumWidth(), modelIcon.getMinimumHeight());
			btnSet.setCompoundDrawables(null, modelIcon, null, null);
			btnSet.setPadding(0, spadding_top, 0, spadding_bottom);
			btnSet.setCompoundDrawablePadding(spadding_drawable);
		}
	}

	protected void setFavoritesBtnView() {
		if (btnModel != null) {
			// settingData = SettingObservable.getInstance().getData();
			Drawable modelIcon = null;
			if (themeSettingsHelper.isDefaultTheme()) {
				modelIcon = getResources().getDrawable(R.drawable.menu_mycollection);
				btnFavorites.setBackgroundResource(R.drawable.menu_selectitem);
				btnFavorites.setTextColor(getResources().getColor(R.color.menu_icon_color));
				// btnExit.setTextColor(R.drawable.menu_text_color);
			} else {
				modelIcon = getResources().getDrawable(R.drawable.night_menu_mycollection);
				btnFavorites.setBackgroundResource(R.drawable.night_menu_selectitem);
				btnFavorites.setTextColor(getResources().getColor(R.color.night_menu_icon_color));
				// btnExit.setTextColor(R.drawable.night_menu_text_color);
			}
			modelIcon.setBounds(0, 0, modelIcon.getMinimumWidth(), modelIcon.getMinimumHeight());
			btnFavorites.setCompoundDrawables(null, modelIcon, null, null);
			btnFavorites.setPadding(0, spadding_top, 0, spadding_bottom);
			btnFavorites.setCompoundDrawablePadding(spadding_drawable);
		}
	}

	protected void setExitBtnView() {
		if (btnModel != null) {
			// settingData = SettingObservable.getInstance().getData();
			Drawable modelIcon = null;
			if (themeSettingsHelper.isDefaultTheme()) {
				modelIcon = getResources().getDrawable(R.drawable.menu_exit);
				btnExit.setBackgroundResource(R.drawable.menu_selectitem);
				btnExit.setTextColor(getResources().getColor(R.color.menu_icon_color));
				// btnExit.setTextColor(R.drawable.menu_text_color);
			} else {
				modelIcon = getResources().getDrawable(R.drawable.night_menu_exit);
				btnExit.setBackgroundResource(R.drawable.night_menu_selectitem);
				btnExit.setTextColor(getResources().getColor(R.color.night_menu_icon_color));
				// btnExit.setTextColor(R.drawable.night_menu_text_color);
			}
			modelIcon.setBounds(0, 0, modelIcon.getMinimumWidth(), modelIcon.getMinimumHeight());
			btnExit.setCompoundDrawables(null, modelIcon, null, null);
			btnExit.setPadding(0, spadding_top, 0, spadding_bottom);
			btnExit.setCompoundDrawablePadding(spadding_drawable);
		}
	}

	protected void setOffLineDownLoadBtnView() {
		if (btnModel != null) {
			// settingData = SettingObservable.getInstance().getData();
			Drawable modelIcon = null;
			if (themeSettingsHelper.isDefaultTheme()) {
				modelIcon = getResources().getDrawable(R.drawable.menu_offlinedownload);
				btnOffLineDownLoad.setBackgroundResource(R.drawable.menu_selectitem);
				// btnOffLineDownLoad.setText(getResources().getString(R.string.offlinedownload_title));
				btnOffLineDownLoad.setTextColor(getResources().getColor(R.color.menu_icon_color));
				// btnOffLineDownLoad.setTextColor(R.drawable.menu_text_color);
			} else {
				modelIcon = getResources().getDrawable(R.drawable.night_menu_offlinedownload);
				btnOffLineDownLoad.setBackgroundResource(R.drawable.night_menu_selectitem);
				// btnOffLineDownLoad.setText(getResources().getString(R.string.offlinedownload_title));
				btnOffLineDownLoad.setTextColor(getResources().getColor(R.color.night_menu_icon_color));
				// btnOffLineDownLoad.setTextColor(R.drawable.night_menu_text_color);
			}

			modelIcon.setBounds(0, 0, modelIcon.getMinimumWidth(), modelIcon.getMinimumHeight());
			btnOffLineDownLoad.setCompoundDrawables(null, modelIcon, null, null);
			btnOffLineDownLoad.setPadding(0, padding_top, 0, padding_bottom);
			btnOffLineDownLoad.setCompoundDrawablePadding(padding_drawable);

		}
	}
	protected void setMyCommentBtnView() {
        if (btnModel != null) {
            // settingData = SettingObservable.getInstance().getData();
            Drawable modelIcon = null;
            if (themeSettingsHelper.isDefaultTheme()) {
                modelIcon = getResources().getDrawable(R.drawable.menu_mymsg);
                btnMyComment.setBackgroundResource(R.drawable.menu_selectitem);
                btnMyComment.setTextColor(getResources().getColor(R.color.menu_icon_color));
                // btnExit.setTextColor(R.drawable.menu_text_color);
            } else {
                modelIcon = getResources().getDrawable(R.drawable.night_menu_mymsg);
                btnMyComment.setBackgroundResource(R.drawable.night_menu_selectitem);
                btnMyComment.setTextColor(getResources().getColor(R.color.night_menu_icon_color));
                // btnExit.setTextColor(R.drawable.night_menu_text_color);
            }
            modelIcon.setBounds(0, 0, modelIcon.getMinimumWidth(), modelIcon.getMinimumHeight());
            btnMyComment.setCompoundDrawables(null, modelIcon, null, null);
            btnMyComment.setPadding(0, padding_top, 0, padding_bottom);
            btnMyComment.setCompoundDrawablePadding(padding_drawable);
        }
    }
	protected void setMenuImageView() {
		if (themeSettingsHelper.isDefaultTheme()) {
			menu_image_view1.setBackgroundDrawable(getResources().getDrawable(R.drawable.verticalline));
			menu_image_view2.setBackgroundDrawable(getResources().getDrawable(R.drawable.verticalline));
			menu_image_view3.setBackgroundDrawable(getResources().getDrawable(R.drawable.verticalline));
			menu_image_view4.setBackgroundDrawable(getResources().getDrawable(R.drawable.verticalline2));
			menu_image_view5.setBackgroundDrawable(getResources().getDrawable(R.drawable.verticalline));
			menu_image_view6.setBackgroundDrawable(getResources().getDrawable(R.drawable.verticalline));
		} else {
			menu_image_view1.setBackgroundDrawable(getResources().getDrawable(R.drawable.night_verticalline));
			menu_image_view2.setBackgroundDrawable(getResources().getDrawable(R.drawable.night_verticalline));
			menu_image_view3.setBackgroundDrawable(getResources().getDrawable(R.drawable.night_verticalline));
			menu_image_view4.setBackgroundDrawable(getResources().getDrawable(R.drawable.night_verticalline2));
			menu_image_view5.setBackgroundDrawable(getResources().getDrawable(R.drawable.night_verticalline));
			menu_image_view6.setBackgroundDrawable(getResources().getDrawable(R.drawable.night_verticalline));
		}

	}

	protected void mainExit() {
		MainActivity.this.finish();
	}

	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		AlertDialog dialog = null;
		switch (id) {
		case CREATE_DIALOG_QUIT:
			mainExit();
			break;
		case DIALOG_NEW_VERSION: {
			if (mVersion != null) {

				dialog = new AlertDialog.Builder(MainActivity.this)//
						.setTitle("版本更新")//
						.setMessage(mVersion.getMessage())//
						.setPositiveButton("稍后再说", new OnClickListener() {//
									@Override
									public void onClick(DialogInterface dialog, int which) {

										btn_setting_show_new_version_tips.setVisibility(View.VISIBLE);
										long nextTime = System.currentTimeMillis() / 1000 + UPDATA_TIME;
										SpConfig.setNextUpdataTime(nextTime);
										doSilentDownload();
										dialog.cancel();
									}
								}).setNegativeButton("立即更新", new OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int which) {
								/*
								 * String url = mVersion.getUrl(); if (null !=
								 * url && url.length() > 0) { Intent intent =
								 * new Intent(Intent.ACTION_VIEW); intent
								 * .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
								 * intent.setData(Uri.parse(url));
								 * startActivity(intent); }
								 */

								isClickUpdateNow = true;
								Intent intent = new Intent();
								intent.setClass(MainActivity.this, SettingActivity.class);
								Bundle mBundle = new Bundle();
								mBundle.putInt(Constants.CHECK_UPDATE, Constants.FROM_UPDATE_NOW);
								intent.putExtras(mBundle);
								startActivity(intent);
							}
						}).setCancelable(false).create();
				dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {

					@Override
					public void onDismiss(DialogInterface dialog) {
						// TODO Auto-generated method stub
						if (!isClickUpdateNow) {
							btn_setting_show_new_version_tips.setVisibility(View.VISIBLE);
						} else {
							isClickUpdateNow = false;
						}
					}
				});
			}
			break;
		}
		case DIALOG_NEW_VERSION_INSTALL: {

			if (mVersion != null) {
				dialog = new AlertDialog.Builder(MainActivity.this)//
						.setMessage("我们在wifi环境下自动为您下载新版新闻客户端安装包，没有耗费您手机任何收费流量。\n" + mVersion.getMessage())//
						.setPositiveButton("取消", new OnClickListener() {//
									@Override
									public void onClick(DialogInterface dialog, int which) {

									}
								}).setNegativeButton("安装", new OnClickListener() {

							@Override
							public void onClick(DialogInterface dialog, int which) {
								DownloadManager.getInstance().doStateAction(Constants.APPID, mState, updateUrl, "com.tencent.news", "腾讯新闻", MainActivity.this, versionCode, true);
								dialog.cancel();
							}
						}).setCancelable(false).create();
				dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {

					@Override
					public void onDismiss(DialogInterface dialog) {
						// TODO Auto-generated method stub
						SpConfig.setSilentDownloadFlag(Constants.SILENT_DEFAULT);
					}
				});
			}
		}
		default:
			break;
		}
		return dialog;
	}
	
	private void setPopWdRemindRedDot(int atNum, int mailNum){
		if(unreadTextView==null){
			return;
		}
		if(atNum + mailNum > 99 ){
			unreadTextView.setVisibility(View.VISIBLE);
			unreadTextView.setText("99+");
		}else if(atNum + mailNum > 0){
			unreadTextView.setVisibility(View.VISIBLE);
			unreadTextView.setText(String.valueOf(atNum + mailNum));
		}else{
			unreadTextView.setVisibility(View.GONE);
		}
	}

	private void initPopuWindows() {
		menuLayout = (RelativeLayout) View.inflate(this, R.layout.main_menu, null);
		popupMenu = new PopupWindow(menuLayout, LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
		// 设置menu菜单背景
		popupMenu.setBackgroundDrawable(getResources().getDrawable(R.drawable.menu_background));
		// menu菜单获得焦点 如果没有获得焦点menu菜单中的控件事件无法响应
		popupMenu.setFocusable(true);
		// 设置显示和隐藏的动画
		popupMenu.setAnimationStyle(R.style.menushow);
		popupMenu.update();
		menuLayout.setFocusableInTouchMode(true);

		unreadTextView = (TextView) menuLayout.findViewById(R.id.main_menu_unread);
		mMenuMask = (View) menuLayout.findViewById(R.id.menu_mask);
		btnTheme = (Button) menuLayout.findViewById(R.id.btn_theme);
		btnModel = (Button) menuLayout.findViewById(R.id.btn_model);
		btnMyComment = (Button) menuLayout.findViewById(R.id.btn_mycomment);
		btnSet = (Button) menuLayout.findViewById(R.id.btn_set);
		btn_setting_show_new_version_tips = (ImageView) menuLayout.findViewById(R.id.btn_setting_show_new_version_tips);
		btnFavorites = (Button) menuLayout.findViewById(R.id.btn_favorites);
		btnExit = (Button) menuLayout.findViewById(R.id.btn_exit);
		btnOffLineDownLoad = (Button) menuLayout.findViewById(R.id.btn_offLineDownLoad);
		menu_image_view1 = (ImageView) menuLayout.findViewById(R.id.verticalline1);
		menu_image_view2 = (ImageView) menuLayout.findViewById(R.id.verticalline2);
		menu_image_view3 = (ImageView) menuLayout.findViewById(R.id.verticalline3);
		menu_image_view4 = (ImageView) menuLayout.findViewById(R.id.verticalline4);
		menu_image_view5 = (ImageView) menuLayout.findViewById(R.id.verticalline5);
		menu_image_view6 = (ImageView) menuLayout.findViewById(R.id.verticalline6);
		setModelBtnView();
		setThemeBtnView();
		setSetBtnView();
		setFavoritesBtnView();
		setExitBtnView();
		setMenuImageView();
		setOffLineDownLoadBtnView();
		setMyCommentBtnView();
		setPopWdRemindRedDot(atCount, mailCount);
		
		menuLayout.setOnKeyListener(new android.view.View.OnKeyListener() {
			public boolean onKey(View v, int keyCode, KeyEvent event) {
				if ((keyCode == KeyEvent.KEYCODE_MENU) && (event.getAction() == KeyEvent.ACTION_UP) && (popupMenu.isShowing())) {
					popupMenu.dismiss();
					return true;

				}
				setModelBtnView();
				setThemeBtnView();
				// setSetBtnView();
				// setExitBtnView();
				// setMenuImageView();
				// setOffLineDownLoadBtnView();
				return false;
			}

		});

		btnModel.setOnClickListener(new Button.OnClickListener() {
			@Override
			public void onClick(View v) {
				/*
				 * if (popupMenu.isShowing()) { if (popupMenu != null) {
				 * popupMenu.dismiss(); } }
				 */
				// mHandler.sendEmptyMessageDelayed(DISMISS_MENU, DISMISS_TIME);
				settingData = SettingObservable.getInstance().getData();
				if (settingData != null && settingData.isIfTextMode()) {// 目前是文字模式
					settingData.setIfTextMode(false);
				} else {
					settingData.setIfTextMode(true);
				}
				SettingObservable.getInstance().setData(settingData);
				SpSetting.saveSetting(settingData);

				// String value = ;
				// Statistics.getInstance().saveStatistics(Statistics.REPORTED_DATA_SETTING,
				// StatisticsUtil.generateCustomField(new String[] {
				// Statistics.REPORTED_DATA_KEY_TEXT_MODE, value, "", "", "",
				// "", "" }));
				// Statistics.getInstance().reportAllInTime();

				WebDev.trackCustomEvent(MainActivity.this, EventId.BOSS_SETTING_TEXTMODE, new String[] { settingData.isIfTextMode() ? "1" : "0" });

				mHandler.sendEmptyMessageDelayed(DISMISS_MENU, 2 * DISMISS_TIME);
			}
		});

		btnTheme.setOnClickListener(new Button.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (popupMenu.isShowing()) {
					if (popupMenu != null) {
						popupMenu.dismiss();
					}
				}
				mHandler.sendEmptyMessage(CHANGE_THEME);
				// mHandler.sendEmptyMessageDelayed(CHANGE_THEME, DISMISS_TIME);
			}
		});

		btnSet.setOnClickListener(new Button.OnClickListener() {
			@Override
			public void onClick(View v) {
				/*
				 * if (popupMenu.isShowing()) { if (popupMenu != null) {
				 * popupMenu.dismiss(); } }
				 */
				// mHandler.sendEmptyMessageDelayed(DISMISS_MENU, DISMISS_TIME);
				Intent intent = new Intent();
				intent.setClass(MainActivity.this, SettingActivity.class);

				if (btn_setting_show_new_version_tips.getVisibility() == View.VISIBLE) {
					btn_setting_show_new_version_tips.setVisibility(View.INVISIBLE);
					Bundle mBundle = new Bundle();
					mBundle.putInt(Constants.CHECK_UPDATE, Constants.FROM_SETTING);
					intent.putExtras(mBundle);
				}

				startActivity(intent);
				mHandler.sendEmptyMessageDelayed(DISMISS_MENU, 2 * DISMISS_TIME);
			}
		});

		btnOffLineDownLoad.setOnClickListener(new Button.OnClickListener() {
			@Override
			public void onClick(View v) {
				/*
				 * if (popupMenu.isShowing()) { if (popupMenu != null) {
				 * popupMenu.dismiss(); } }
				 */

				// Statistics.getInstance().saveStatistics(Statistics.REPORTED_DATA_SHOWING_WHAT,
				// StatisticsUtil.generateCustomField(new String[] {
				// "OFFLINE_CLICK_MENU", System.currentTimeMillis() + "", "",
				// "", "", "", "" }));
				// Statistics.getInstance().reportAllInTime();

				WebDev.trackCustomEvent(MainActivity.this, EventId.BOSS_OFFLINE_CLICK_MENU);

				Intent intent = new Intent(MainActivity.this, OfflineActivity.class);
				startActivity(intent);
				mHandler.sendEmptyMessageDelayed(DISMISS_MENU, 2 * DISMISS_TIME);
			}
		});

		btnFavorites.setOnClickListener(new Button.OnClickListener() {
			@Override
			public void onClick(View v) {

				WebDev.trackCustomEvent(MainActivity.this, EventId.BOSS_FAVORITES_CLICK_MENU);
				
				Intent intent = new Intent(MainActivity.this, FavoritesListActivity.class);
				Bundle mBundle = new Bundle();
				mBundle.putBoolean(Constants.IS_START_CHANNEL, true);
				intent.putExtras(mBundle);
				startActivity(intent);
				mHandler.sendEmptyMessageDelayed(DISMISS_MENU, 2 * DISMISS_TIME);
			}
		});

		btnMyComment.setOnClickListener(new Button.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (UserDBHelper.getInstance().getUserInfo() != null) {
					Intent intent = new Intent(MainActivity.this, CommentFragmentActivity.class);
					intent.setAction(Constants.UPDATE_MAIL_AND_AT_COUNT);
					intent.putExtra("action", "update");	
					intent.putExtra("mailCount", mailCount);
			        intent.putExtra("atCount", atCount);	
					startActivity(intent);					
				}else{
					Intent intent = new Intent();
					intent.setClass(MainActivity.this, LoginActivity.class);
					intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);						
					intent.putExtra(Constants.LOGIN_FROM, Constants.LOGIN_FROM_MY_MSG);					
					startActivity(intent);
				}
				mHandler.sendEmptyMessageDelayed(DISMISS_MENU, 2 * DISMISS_TIME);
			}
		});

		btnExit.setOnClickListener(new Button.OnClickListener() {
			@Override
			public void onClick(View v) {

				showDialog(CREATE_DIALOG_QUIT);
				mHandler.sendEmptyMessageDelayed(DISMISS_MENU, 2 * DISMISS_TIME);
			}
		});
	}

	private void dismissMenu() {
		if (popupMenu != null && popupMenu.isShowing()) {
			popupMenu.dismiss();
		}
	}

	@Override
	public boolean onTrackballEvent(MotionEvent event) {
		return true;
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();

//		Statistics.getInstance().refreshMap();
		TipsToast.getInstance().dismissTips();
		// Application.getInstance().statistics_app_start = 0;
		// Application.getInstance().statistics_app_end = 0;

		if (localManager != null) {
			localManager.removeAllActivities();
			localManager = null;
		}
		DownloadManager.getInstance().removeDownloaderTask(false);
		if (themeSettingsHelper != null) {
			themeSettingsHelper.unRegisterThemeCallback(this);
		}

	}

	public void applyTheme() {
		// Auto-generated method stub
		if (popupMenu.isShowing()) {
			if (popupMenu != null) {
				popupMenu.dismiss();
			}
		}
		themeSettingsHelper.setPopupWindowBackgroud(MainActivity.this, popupMenu, R.drawable.menu_background);
		themeSettingsHelper.setViewBackgroudColor(MainActivity.this, mMenuMask, R.color.mask_page_color);
		themeSettingsHelper.setViewBackgroudColor(MainActivity.this, mMask, R.color.mask_page_color);
		setSetBtnView();
		setFavoritesBtnView();
		setExitBtnView();
		setMenuImageView();
		setOffLineDownLoadBtnView();
		setMyCommentBtnView();
	}

	@Override
	public void downloadStateChanged(String TAG, int state, int n_progress, String t_progress) {
		// Auto-generated method stub
		mState = state;
		Application.getInstance().setDownloadState(mState);
	}

	private void compute_padding() {
		// padding_top = 0, padding_bottom = 0, padding_left = 0, padding_right
		// = 0, padding_drawable = 0
		final float scale = this.getResources().getDisplayMetrics().density;
		padding_top = (int) (15 * scale + 0.5f);
		padding_bottom = (int) (10 * scale + 0.5f);
		padding_drawable = (int) (5 * scale + 0.5f);
		spadding_top = (int) (0.85 * (15 * scale + 0.5f));
		spadding_bottom = (int) (0.85 * (10 * scale + 0.5f));
		spadding_drawable = (int) (5 * scale + 0.5f);
	}
	
	public class RSSRefreshReceiver extends BroadcastReceiver {
		public RSSRefreshReceiver() {
		}

		@Override
		public void onReceive(Context context, Intent intent) {
			mNavigationBar.showRSSRedDot(false);
			SpConfig.setHasNewRSS(false);
			SpConfig.setRSSRefreshTime(System.currentTimeMillis());
		}
	}
	
	   public class RSSGuideFinishedReceiver extends BroadcastReceiver {
	        public RSSGuideFinishedReceiver() {
	        }

	        @Override
	        public void onReceive(Context context, Intent intent) {
	            
	            mTabHost.setCurrentTab(mRSSIndex);
	            unregisterReceiver(mRSSGuideFinishedReceiver);
	        }
	    }
	   
}
