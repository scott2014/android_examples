package com.tencent.news.ui;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextSwitcher;
import android.widget.TextView;
import android.widget.ViewSwitcher.ViewFactory;

import com.tencent.news.R;
import com.tencent.news.boss.EventId;
import com.tencent.news.cache.RssChannelSyncHelper;
import com.tencent.news.cache.UserDBHelper;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.model.pojo.Comment;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.model.pojo.UserInfo;
import com.tencent.news.model.pojo.WriteBackState;
import com.tencent.news.shareprefrence.SpDraft;
import com.tencent.news.shareprefrence.SpForbidenCommentNews;
import com.tencent.news.shareprefrence.SpSetting;
import com.tencent.news.system.Application;
import com.tencent.news.system.NetStatusReceiver;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.system.observer.SettingObserver;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.news.utils.ThemeSettingsHelper;
import com.tencent.omg.webdev.WebDev;

public abstract class AbsWritingActivity extends BaseActivity implements SettingObserver, ViewFactory, OnClickListener {

	private SettingObservable settingObv;
	private SettingInfo settingData;

	// private static final int AREYOUSURE_DIALOG = 1024;

	protected static final int MAX_WORDS_COMMENT_NUM = 750;
	protected static final int MAX_WORDS_WEIBO_NUM = 140;
	protected static final int MAX_WORDS_SUGGEST_NUM = 1000;
	// protected static final String SUGGEST_TO = "@腾讯新闻客户端#意见反馈# ";

	protected static final String QQCOMMENT = "qqcomment";
	protected static final String QQWEIBO = ",qqweibo";
	protected static final String SINA = ",sina";
	protected static final String QZONE = ",qzone";

	abstract void assignUI();

	abstract int iAmWhich();

	abstract void sendWords();

	Comment comment;
	String itemIdForDraft;
	String replyIdForDraft;
	String imgUrl = "";
	String vid = "";
	String specialID = "";
	String graphicLiveID = "";
	String graphicLiveChlid = "";
	String channelId = "";
	Item mItem;
	String tranQQweiboStr = "";
	String commentQQweiboStr = "";
	String replyContent = "";
	String contentQqweibo = "";
	String lastInput = "";
	String shareType = QQCOMMENT;
	String shareTencent;
	String shareSina;
	String shareQzone;

	int long_short = 0;

	boolean if_share_to_tx_weibo = true;

	LinearLayout write_footer = null;
	View writingTitleBg = null;
	Button writingTitle_btn_back;
	TextView lastnum = null;
	TextView writingTitleText = null;
	TextView remainNumUnit = null;
	Button btn_send = null;
	EditText input = null;
	TextSwitcher remainNum = null;
	int remainWordsNum;
	TextView share_to = null;
	// ShareButton share_to_tencent = null;
	ImageView share_to_sina = null;

	LinearLayout view_suggest = null;
	// TODO:增加分享到Qzone按钮

	/**
	 * 要评论的新闻是不是被禁止评论了<br/>
	 * false该新闻没有被禁止,true表示该新闻禁止评论
	 */
	boolean isForbid = false;

//	long statistics_send_start;
//	long statistics_send_end;
//	long statistics_send_total;

	private View mMask;

	protected ThemeSettingsHelper themeSettingsHelper = null;

	@Override
	public View makeView() {
		Log.i("CJZ", "makeView");
		TextView t = new TextView(this);
		t.setText(t.getText().toString().trim());
		t.setTextColor(Color.parseColor("#414141"));
		t.setGravity(Gravity.CENTER);
		return t;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		settingObv = SettingObservable.getInstance();
		settingObv.registerObserver(AbsWritingActivity.this);

		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(this);

		setContentView(R.layout.activity_writing);

		Intent intent = getIntent();
		if (intent != null) {
			if (intent.hasExtra(Constants.WRITE_COMMENT_KEY)) {
				mItem = (Item) intent.getSerializableExtra(Constants.WRITE_COMMENT_KEY);
				contentQqweibo = "|| #我在看新闻# " + mItem.getTitle() + mItem.getUrl();

				long_short = mItem.getUrl().length() - 12;

				itemIdForDraft = mItem.getId();

				isForbid = SpForbidenCommentNews.getForbidenCommentNews(mItem.getId());

				graphicLiveID = mItem.getGraphicLiveID();
				specialID = mItem.getSpecialID();

			}
			if (intent.hasExtra(Constants.WRITE_COMMENT_CHANNEL_KEY)) {
				channelId = intent.getStringExtra(Constants.WRITE_COMMENT_CHANNEL_KEY);
			}
			if (intent.hasExtra(Constants.WRITE_COMMENT_IMG_KEY)) {
				imgUrl = intent.getStringExtra(Constants.WRITE_COMMENT_IMG_KEY);
			}
			if (intent.hasExtra(Constants.WRITE_COMMENT_VID_KEY)) {
				vid = intent.getStringExtra(Constants.WRITE_COMMENT_VID_KEY);
			}
			if (intent.hasExtra(Constants.WRITE_COMMENT_GRAPHICLIVECHLID_KEY)) {
				graphicLiveChlid = intent.getStringExtra(Constants.WRITE_COMMENT_GRAPHICLIVECHLID_KEY);
			}
			if (intent.hasExtra(Constants.WRITE_TRAN_COMMENT_KEY)) {
				comment = (Comment) intent.getParcelableExtra(Constants.WRITE_TRAN_COMMENT_KEY);
				replyIdForDraft = comment.getReplyId();
				String name = "";
				if (comment.isOpenMb()) {
					name = comment.getChar_name();
					if (TextUtils.isEmpty(name) || name.length() <= 0) {
						name = comment.getMb_nick_name();
						if (TextUtils.isEmpty(name) || name.length() <= 0) {
							name = comment.getNick();
						}
					}
				} else {
					name = comment.getNick();
				}

				replyContent = " || @" + name + ":" + comment.getReplyContent();

				if (iAmWhich() == Constants.WRITE_TRANS_COMMENT && replyContent.length() > 30 + long_short) {
					replyContent = replyContent.substring(0, 30 + long_short - 3) + "...";
				}
			}
		}
		initView();
		initListener();
		assignUI();
	}

	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		if (savedInstanceState != null && input != null) {
			input.setText(savedInstanceState.getString(Constants.SAVE_INPUT));
		}
		super.onRestoreInstanceState(savedInstanceState);
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		if (outState != null && input != null && input.getText() != null && input.getText().toString() != null && input.getText().toString().length() > 0) {
			outState.putString(Constants.SAVE_INPUT, input.getText().toString());
		}
		super.onSaveInstanceState(outState);
	}

	private void initView() {
		mMask = (View) findViewById(R.id.mask_view);

		write_footer = (LinearLayout) findViewById(R.id.write_footer);

		writingTitleBg = findViewById(R.id.writingTitleBg);
		writingTitle_btn_back = (Button) findViewById(R.id.writingTitle_btn_back);
		writingTitleText = (TextView) findViewById(R.id.writingTitleText);
		remainNumUnit = (TextView) findViewById(R.id.remainNumUnit);
		lastnum = (TextView) findViewById(R.id.lastnum);
		btn_send = (Button) findViewById(R.id.btn_send);
		input = (EditText) findViewById(R.id.input);
		view_suggest = (LinearLayout) findViewById(R.id.view_suggest);

		// TODO:1--->transcomment and comment, accordding by id and replyid to
		// load draft
		// transcomment:mItem.getId() + comment.getReplyId()-->load
		// comment:mItem.getId()-->load
		String draft = loadDraft(itemIdForDraft, replyIdForDraft);
		// TODO:2--->to set EditText value
		input.setText(draft);
		input.setSelection(draft.length(), draft.length());

		remainNum = (TextSwitcher) findViewById(R.id.remainNum);
		remainNum.setFactory(this);
		share_to = (TextView) findViewById(R.id.share_to);
		// share_to_tencent = (ShareButton) findViewById(R.id.share_to_tencent);
		share_to_sina = (ImageView) findViewById(R.id.share_to_sina);

		if (mItem != null && ("1".equalsIgnoreCase(mItem.getArticletype()) || "4".equalsIgnoreCase(mItem.getArticletype()))) {
			writingTitleBg.setBackgroundResource(R.drawable.detail_title_bar);
			writingTitle_btn_back.setBackgroundResource(R.drawable.detail_back_btn);
			writingTitleText.setTextColor(Color.parseColor("#cccccc"));
			btn_send.setBackgroundResource(R.drawable.btn_send_black_selector);

			ColorStateList night_csl = (ColorStateList) getResources().getColorStateList(R.drawable.btn_send_black_color_selector);
			if (night_csl != null) {
				btn_send.setTextColor(night_csl);
			}
		}

		Animation in = AnimationUtils.loadAnimation(this, R.anim.slide_down_in);
		Animation out = AnimationUtils.loadAnimation(this, R.anim.slide_up_out);
		remainNum.setInAnimation(in);
		remainNum.setOutAnimation(out);

		// if (UserDBHelper.getInstance().getUserInfo() != null) {
		// if (UserDBHelper.getInstance().getUserInfo().isOpenMBlog()) {
		// share_to_tencent.setShareButtonState(ShareButton.SHARE);
		// } else {
		// share_to_tencent.setShareButtonState(ShareButton.LOGOUT);
		// }
		// } else {
		// share_to_tencent.setShareButtonState(ShareButton.LOGOUT);
		// }

		// // 下一版删除start
		// share_to_tencent.setShareButtonState(ShareButton.SHARE);
		// // 下一版删除 end

		setShareTypeAndLimitWords();

		// initViewsByMode();
	}

	private void initViewsByMode() {
		themeSettingsHelper.setViewBackgroud(this, writingTitleBg, R.drawable.title_bar_bg);

		themeSettingsHelper.setViewBackgroud(this, writingTitle_btn_back, R.drawable.title_back_btn);

		ColorStateList csl = null;

		if (themeSettingsHelper.isNightTheme()) {
			writingTitleText.setTextColor(Color.parseColor("#f0f4f8"));
			writingTitle_btn_back.setTextColor(Color.parseColor("#f0f4f8"));

			csl = (ColorStateList) getResources().getColorStateList(R.drawable.night_btn_send_color_selector);

			if (csl != null)
				btn_send.setTextColor(csl);
		} else {
			writingTitleText.setTextColor(Color.parseColor("#ffffff"));
			writingTitle_btn_back.setTextColor(Color.parseColor("#ffffff"));

			csl = (ColorStateList) getResources().getColorStateList(R.drawable.btn_send_color_selector);

			if (csl != null)
				btn_send.setTextColor(csl);
		}

		themeSettingsHelper.setViewBackgroud(this, this.btn_send, R.drawable.title_complete_btn);
		themeSettingsHelper.setViewBackgroudColor(this, input, R.color.page_setting_bg_color);
		themeSettingsHelper.setViewBackgroudColor(this, view_suggest, R.color.page_setting_bg_color);

		if (themeSettingsHelper.isNightTheme()) {
			input.setHintTextColor(Color.parseColor("#88858b"));
			input.setTextColor(Color.parseColor("#f0f4f8"));
		} else {
			input.setHintTextColor(Color.parseColor("#999999"));
			input.setTextColor(Color.parseColor("#222222"));
		}
	}

	private void initListener() {
		btn_send.setOnClickListener(this);
		// share_to_tencent.setOnClickListener(this);
		share_to_sina.setOnClickListener(this);
		input.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {

			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void afterTextChanged(Editable s) {
				changeTextSwitcherNum();
			}
		});
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btn_send:

			lastInput = input.getText().toString();
			// if (isForbid) {
			// if (!share_to_tencent.isChecked()) {
			// SToast.ToastShort("请选择分享途径");
			// return;
			// }
			// } else {
			//
			// if (iAmWhich() != Constants.WRITE_TRANS_COMMENT) {
			// if (lastInput.length() <= 0) {
			// // SToast.ToastShort("请输入内容");
			// // showtips();
			// TipsToast.getInstance().showTipsWarning("请输入内容");
			// return;
			// }
			// } else {
			// if (!share_to_tencent.isChecked()) {
			// TipsToast.getInstance().showTipsWarning("请选择分享途径");
			// return;
			// }
			// }
			// }

			if (iAmWhich() == Constants.WRITE_COMMENT /*
													 * &&
													 * !share_to_tencent.isChecked
													 * ()
													 */&& lastInput.length() <= 0) {
				TipsToast.getInstance().showTipsWarning("请输入内容");
				return;
			}

			if (iAmWhich() == Constants.WRITE_SUGGEST && lastInput.length() <= 0) {
				TipsToast.getInstance().showTipsWarning("请输入内容");
				return;
			}

			if (/* share_to_tencent.isChecked() && */remainWordsNum < 0) {
				TipsToast.getInstance().showTipsWarning("输入字数太多啦");
				return;
			}

			if (UserDBHelper.getInstance().getUserInfo() != null) {
				if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_INAVAILABLE) {
					// SToast.ToastShort("无网络连接，请启用数据网络");
					TipsToast.getInstance().showTipsWarning("无网络连接\n请启用数据网络");
				} else {

					// if(UserDBHelper.getInstance().getUserInfo().isOpenMBlog()){
//					statistics_send_start = System.currentTimeMillis();
					sendWords();
					quitActivity();
					// } else {
					// TipsToast.getInstance().showTipsError("对不起\n您没有开通腾讯微博");
					// }
				}
			} else {
				Intent loginIntent = new Intent();
				loginIntent.setClass(AbsWritingActivity.this, LoginActivity.class);
				loginIntent.putExtra(Constants.LOGIN_FROM, Constants.LOGIN_FROM_SEND_BTN);
				startActivityForResult(loginIntent, Constants.REQUEST_CODE_LOGIN);
			}

			break;
		// case R.id.share_to_tencent:
		// buttonStateChange(share_to_tencent);
		// break;
		// case R.id.if_share_to:
		//
		// if_share_to_tx_weibo = !if_share_to_tx_weibo;
		// if (if_share_to_tx_weibo) {
		// if_share_to.setImageResource(R.drawable.setting_checked_bg);
		// } else {
		// if_share_to.setImageResource(R.drawable.setting_unchecked_bg);
		// }
		// buttonStateChange(share_to_tencent);
		// break;
		case R.id.writingTitle_btn_back:

			if (input.getText().toString().length() > 0) {
				// showDialog(AREYOUSURE_DIALOG);
				// TODO: save draft by sth.
				saveDraft(itemIdForDraft, replyIdForDraft, input.getText().toString());
			} else {
				deleteDraft(itemIdForDraft, replyIdForDraft);
			}
			Application.getInstance().hideSoftInputFromWindow(input.getWindowToken());
			quitActivity();
			break;
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			if (input.getText().toString().length() > 0) {
				// showDialog(AREYOUSURE_DIALOG);
				// TODO: save draft by sth.
				saveDraft(itemIdForDraft, replyIdForDraft, input.getText().toString());
			} else {
				deleteDraft(itemIdForDraft, replyIdForDraft);
			}
			Application.getInstance().hideSoftInputFromWindow(input.getWindowToken());
			quitActivity();
			return true;
		}

		return super.onKeyDown(keyCode, event);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (resultCode == RESULT_OK) {
			if (requestCode == Constants.REQUEST_CODE_LOGIN) {

				UserInfo userInfo = (UserInfo) data.getSerializableExtra(Constants.LOGIN_SUCCESS_BACK_USER_KEY);
				settingData = settingObv.getData();
				settingData.setUserInfo(userInfo);
				settingObv.setData(settingData);

				// Statistics.getInstance().saveStatistics(Statistics.REPORTED_DATA_SETTING,
				// StatisticsUtil.generateCustomField(new String[] {
				// Statistics.REPORTED_DATA_KEY_LOGIN_FROM_WHERE, "1", "", "",
				// "", "", "" }));

				// 因为现在的只有意见反馈继承自 Abswritingactivity
				WebDev.trackCustomEvent(this, EventId.BOSS_SETTING_LOGINFROM_SUGGEST);

				if (data.hasExtra(Constants.LOGIN_BACK) && Constants.LOGIN_FROM_SHARE_BTN == data.getIntExtra(Constants.LOGIN_BACK, Constants.LOGIN_FROM_SEND_BTN)) {
					if (userInfo.isOpenMBlog()) {
						// share_to_tencent.setShareButtonState(ShareButton.SHARE);
						setShareTypeAndLimitWords();

					} else {
						// share_to_tencent.setShareButtonState(ShareButton.LOGOUT);
						if (input != null && input.getText().length() <= 0) {
							TipsToast.getInstance().showTipsWarning("对不起\n您没有开通腾讯微博\n请输入评论内容");
							btn_send.setEnabled(false);
							return;
						}
					}
				} else {

					if (userInfo.isOpenMBlog()) {

//						statistics_send_start = System.currentTimeMillis();
						sendWords();
						quitActivity();

					} else {
						// share_to_tencent.setShareButtonState(ShareButton.LOGOUT);
						// share_to.setTextColor(Color.parseColor("#BEBEBE"));
						// lastnum.setVisibility(View.INVISIBLE);
						// remainNum.setVisibility(View.INVISIBLE);
						// remainNumUnit.setVisibility(View.INVISIBLE);
						if (input != null && input.getText().length() <= 0) {
							TipsToast.getInstance().showTipsWarning("请输入评论内容");
							btn_send.setEnabled(false);
							return;
						}
					}
				}

			}
		} else if (resultCode == RESULT_CANCELED) {

		}

	}

	@Override
	public void onHttpRecvOK(HttpTag tag, Object result) {

		btn_send.setEnabled(true);

//		statistics_send_end = System.currentTimeMillis();
//		statistics_send_total = statistics_send_end - statistics_send_start;

		if (tag.equals(HttpTag.SUGGEST_QQNEWS)) {
			TipsToast.getInstance().showTipsSuccess("感谢您的反馈!");
			deleteDraft(null, null);
			quitActivity();
		} else {

			WriteBackState wbs = (WriteBackState) result;
			if (wbs.getPublish().equals("0")) {

				int tipNum = 0;
				StringBuffer tip = new StringBuffer();

				int comment = 1;
				int tencent = 1;
				int sina = 1;
				int qzong = 1;

				if (wbs.getComment() != null) {
					if (wbs.getComment().getRet().equals("0")) {// 成功
						comment = 1;
					} else if (wbs.getComment().getRet().equals("1")) {// 失败
						comment = 2;
					} else if (wbs.getComment().getRet().equals("2")) {// 重新登录
						comment = 4;
					} else {// 其他,认为失败了
						comment = 2;
					}
				} else {
					comment = 3;
				}

				if (wbs.getQqweibo() != null) {

					if (wbs.getQqweibo().getRet().equals("0")) {// 成功
						tencent = 1;
					} else if (wbs.getQqweibo().getRet().equals("1")) {// 失败
						tencent = 2;
					} else if (wbs.getQqweibo().getRet().equals("2")) {// 重新登录
						tencent = 4;
					} else {
						tencent = 2;
					}
				} else {
					tencent = 3;
				}

				if (wbs.getSina() != null) {
					if (wbs.getSina().getRet().equals("0")) {
						sina = 1;
					} else {
						sina = 2;
					}
				} else {
					sina = 3;
				}

				if (wbs.getQzone() != null) {
					if (wbs.getQzone().getRet().equals("0")) {
						qzong = 1;
					} else {
						qzong = 2;
					}
				} else {
					qzong = 3;
				}

				// 暂时没有
				// TEST[start]
				sina = 3;
				qzong = 3;
				// TEST[end]

				tip.append(comment);
				tip.append(tencent);
				tip.append(sina);
				tip.append(qzong);

				if (tip.toString().indexOf("4") >= 0) {
					// TipsToast.getInstance().showTipsError("发表失败\n请重新登录账号");
					UserDBHelper.getInstance().logoutUserInfo();
					settingData = settingObv.getData();
					settingData.setUserInfo(null);
					settingObv.setData(settingData);
                    RssChannelSyncHelper.getInstance().onLogout();
					reLogin();
					return;
				}

				tipNum = Integer.parseInt(tip.toString());

				Log.i("CJZ", "结果码:" + tip.toString() + "--->" + tipNum);

				switch (tipNum) {
				case 1133:
					sendSuccess(tag);
					break;
				case 1233:
					// SToast.ToastLong("发表评论成功,同步到腾讯微博失败,请重试");
					// TipsToast.getInstance().showTipsSuccess("发表成功");
					sendSuccess(tag);
					break;
				case 1333:
					sendSuccess(tag);
					break;
				case 2133:
					// SToast.ToastLong("发表评论失败,同步到腾讯微博成功,请重试");
					// TipsToast.getInstance().showTipsSuccess("发表成功");
					sendSuccess(tag);
					break;
				case 2233:
					// SToast.ToastLong("发表失败,请重试");
					// if
					// (UserDBHelper.getInstance().getUserInfo().isOpenMBlog())
					// {
					// TipsToast.getInstance().showTipsError("发表失败");
					// } else {
					// TipsToast.getInstance().showTipsError("发表失败\n您没有开通腾讯微博");
					// }
					TipsToast.getInstance().showTipsError("发表失败\n请稍候再试");
					break;
				case 2333:
					// SToast.ToastLong("发表评论失败,请重试");
					TipsToast.getInstance().showTipsError("发表失败\n请稍候再试");
					break;
				case 3133:
					// SToast.ToastLong("同步到腾讯微博成功!");
					// SToast.ToastLong("发表成功");
					// TipsToast.getInstance().showTipsSuccess("发表成功");
					sendSuccess(tag);
					// quitActivity();
					break;
				case 3233:
					// SToast.ToastLong("同步到腾讯微博失败,请重试");
					if (UserDBHelper.getInstance().getUserInfo().isOpenMBlog()) {
						TipsToast.getInstance().showTipsError("发表失败\n请稍候再试");
					} else {
						// TODO:评论内容不能为空
						TipsToast.getInstance().showTipsError("发表失败\n您没有开通腾讯微博");
					}
					// sendSuccess(tag);
					break;
				case 3333:
					// 已被getPublish()拦截
					break;
				default:
					TipsToast.getInstance().showTipsError("发表失败\n请稍候再试");
					break;
				}
			} else {
				// SToast.ToastShort("发表失败,请重试");
				TipsToast.getInstance().showTipsError("发表失败\n请稍候再试");
			}
		}

		super.onHttpRecvOK(tag, result);
	}

	private void sendSuccess(HttpTag tag) {

		TipsToast.getInstance().showTipsSuccess("发表成功");

//		if (statistics_send_total > 0) {
//			Statistics.getInstance().saveStatistics(Statistics.REPORTED_DATA_WRITE, StatisticsUtil.generateCustomField(new String[] { "" + iAmWhich(),// 0意见反馈1评论,2转一下
//					channelId,// 频道名称
//					mItem != null ? mItem.getId() : "",// 文章id
//					mItem != null ? mItem.getCommentid() : "",// 评论id
//					"" + statistics_send_total,// 耗时
//					imgUrl,// 图片url分享到腾讯微博时图片的地址
//					vid,// 视频id分享到腾讯微博时视频id
//					comment != null ? comment.getReplyId() : "", "", "", "", "" }));
//			statistics_send_total = 0;
//		}

		if (tag.equals(HttpTag.PUBLISH_QQNEWS_MULTI)) {
			// SToast.ToastShort("发表成功");

			// TODO:--->delete draft by id
			deleteDraft(itemIdForDraft, replyIdForDraft);

			if (lastInput.length() > 0 && !mItem.getCommentid().equals(Constants.FORBID_COMMENT_ID)) {
				backComment();
			}
		} else if (tag.equals(HttpTag.PUBLISH_TRANS_COMMENT_MULTI)) {
			// SToast.ToastShort("发表成功");
			if (lastInput.length() > 0) {

				// TODO:--->delete draft by id and replyid
				deleteDraft(itemIdForDraft, replyIdForDraft);

				backTransComment();
			}
		}
		quitActivity();
	}

	@Override
	public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {
		btn_send.setEnabled(true);
		TipsToast.getInstance().showTipsError(msg);
		super.onHttpRecvError(tag, retCode, msg);
	}

	@Override
	public void onHttpRecvCancelled(HttpTag tag) {
		btn_send.setEnabled(true);

		super.onHttpRecvCancelled(tag);
	}

	@Override
	protected void onDestroy() {
		if (settingObv != null) {
			settingObv.removeObserver(this);
		}
		super.onDestroy();
	}

	@Override
	public void updateSetting(SettingInfo setting) {
		SpSetting.saveSetting(setting);
	}

	/**
	 * 添加自己的评论虚拟数据
	 */
	private void backComment() {
		Intent intent = new Intent();
		intent.setAction(Constants.WRITE_SUCCESS_ACTION);
		Comment c = new Comment();
		c.setReplyId(Constants.TAG_COMMENT_CANTBEUP);
		c.setHadUp(false);
		c.setSex(UserDBHelper.getInstance().getUserInfo().getSex());
		c.setHeadUrl(UserDBHelper.getInstance().getUserInfo().getHeadurl());
		c.setProvinceCity("腾讯网友");

		if (UserDBHelper.getInstance().getUserInfo() != null) {
			if (!TextUtils.isEmpty(UserDBHelper.getInstance().getUserInfo().getNick())) {
				c.setNick(UserDBHelper.getInstance().getUserInfo().getNick());
			} else {
				if (!TextUtils.isEmpty(UserDBHelper.getInstance().getUserInfo().getQqnick())) {
					c.setNick(UserDBHelper.getInstance().getUserInfo().getQqnick());
				} else {
					c.setNick("腾讯新闻用户");
				}
			}
		} else {
			c.setNick("腾讯新闻用户");
		}

		c.setPubTime("" + System.currentTimeMillis());
		c.setAgreeCount("0");

		String replyContent = lastInput.replaceAll("\n", " ");
		replyContent.replaceAll("  ", "");
		c.setReplyContent(replyContent);

		Comment[] cc = new Comment[1];
		cc[0] = c;
		intent.putExtra(Constants.WRITE_SUCCESS_SERVER_BACK_COMMENT, cc);
		intent.putExtra(Constants.WRITE_SUCCESS_SERVER_BACK_COMMENT_ITEM_ID, mItem.getId());
		sendBroadcast(intent);
	}

	private void backTransComment() {
		Comment[] cc = new Comment[2];
		Intent intent = new Intent();
		intent.setAction(Constants.WRITE_SUCCESS_ACTION);
		Comment c = new Comment();
		c.setReplyId(Constants.TAG_COMMENT_CANTBEUP);
		c.setHadUp(false);
		c.setSex(UserDBHelper.getInstance().getUserInfo().getSex());
		c.setHeadUrl(UserDBHelper.getInstance().getUserInfo().getHeadurl());
		c.setProvinceCity("腾讯网友");

		if (UserDBHelper.getInstance().getUserInfo() != null) {
			if (!TextUtils.isEmpty(UserDBHelper.getInstance().getUserInfo().getNick())) {
				c.setNick(UserDBHelper.getInstance().getUserInfo().getNick());
			} else {
				if (!TextUtils.isEmpty(UserDBHelper.getInstance().getUserInfo().getQqnick())) {
					c.setNick(UserDBHelper.getInstance().getUserInfo().getQqnick());
				} else {
					c.setNick("腾讯新闻用户");
				}
			}
		} else {
			c.setNick("腾讯新闻用户");
		}

		c.setPubTime("" + System.currentTimeMillis());
		c.setAgreeCount("0");

		String replyContent = lastInput.replaceAll("\n", " ");
		replyContent.replaceAll("  ", "");
		c.setReplyContent(replyContent);

		c.setReplyContent(replyContent);

		cc[0] = comment;
		cc[1] = c;// 盖楼我的评论在最后

		intent.putExtra(Constants.WRITE_SUCCESS_SERVER_BACK_COMMENT, cc);
		intent.putExtra(Constants.WRITE_SUCCESS_SERVER_BACK_COMMENT_ITEM_ID, mItem.getId());
		sendBroadcast(intent);
	}

	/**
	 * 初始化分享和写的字数限制
	 */
	private void setShareTypeAndLimitWords() {

		shareType = QQCOMMENT;

		String where = "";
		String str1 = null;
		String str2 = null;
		String str3 = null;

		// if (/*share_to_tencent.isChecked()*/) {
		// shareTencent = QQWEIBO;
		// str1 = "腾讯微博";
		// } else {
		// shareTencent = "";
		// str1 = "";
		// }

		if (share_to_sina.isSelected()) {
			shareSina = SINA;
			str2 = "新浪微博";
		} else {
			shareSina = "";
			str2 = "";
		}

		if (false) {// 暂时没有
			shareQzone = QZONE;
			str3 = "QQ空间";
		} else {
			shareQzone = "";
			str3 = "";
		}

		// shareType = shareType + shareTencent + shareSina + shareQzone;

		// 下一版去掉start
		if (lastInput.length() > 0) {
			shareType = shareType + shareTencent;
		} else {

			if (iAmWhich() != Constants.WRITE_SUGGEST && !SpForbidenCommentNews.getForbidenCommentNews(mItem.getId())) {
				shareType = shareType + shareTencent;
			} else {
				shareType = "qqweibo";
			}
		}
		// 下一版去掉end

		where = str1 + " " + str2 + " " + str3;

		// 本版本去掉,下一版的时候需要加上start
		// if (where.trim().length() > 0) {
		// share_to.setText("分享到 " + where);
		// } else {
		// share_to.setText("");
		// }
		// 本版本去掉,下一版的时候需要加上end

		changeTextSwitcherNum();

	}

	private void changeTextSwitcherNum() {
		if (iAmWhich() == Constants.WRITE_SUGGEST) {
			remainWordsNum = (MAX_WORDS_SUGGEST_NUM - input.getText().toString().length());
		} else {
			remainWordsNum = MAX_WORDS_WEIBO_NUM - (contentQqweibo.length() - long_short) - input.getText().toString().length()
					- (iAmWhich() == Constants.WRITE_TRANS_COMMENT ? replyContent.length() : 0);
		}

		if (remainWordsNum < 0) {
			lastnum.setText("超出");
		} else {
			lastnum.setText("还剩");
		}
		remainNum.setText("" + Math.abs(remainWordsNum));

		// if (!share_to_tencent.isChecked()) {
		// share_to.setTextColor(Color.parseColor("#BEBEBE"));
		// lastnum.setVisibility(View.INVISIBLE);
		// remainNum.setVisibility(View.INVISIBLE);
		// remainNumUnit.setVisibility(View.INVISIBLE);
		// } else {
		// share_to.setTextColor(Color.parseColor("#414141"));
		// lastnum.setVisibility(View.VISIBLE);
		// remainNum.setVisibility(View.VISIBLE);
		// remainNumUnit.setVisibility(View.VISIBLE);
		// }

		if (UserDBHelper.getInstance().getUserInfo() != null) {
			if (!UserDBHelper.getInstance().getUserInfo().isOpenMBlog()) {
				if (input.getText().toString().length() <= 0) {
					btn_send.setEnabled(false);
				} else {
					btn_send.setEnabled(true);
				}
			} else {
				// if (share_to_tencent.isChecked()) {
				// btn_send.setEnabled(true);
				// } else {
				if (input.getText().toString().length() <= 0) {
					btn_send.setEnabled(false);
				} else {
					btn_send.setEnabled(true);
				}
				// }
			}
		}
	}

	public void saveDraft(final String itemId, final String replyId, final String input) {
		if (input != null && input.length() > 0) {
			TaskManager.startRunnableRequest(new Runnable() {

				@Override
				public void run() {
					if (iAmWhich() == Constants.WRITE_COMMENT) {
						SpDraft.saveDraft(itemId, input, Constants.SP_DRAFT);
					} else if (iAmWhich() == Constants.WRITE_TRANS_COMMENT) {
						SpDraft.saveDraft(itemId + replyId, input, Constants.SP_DRAFT);
					} else {
						SpDraft.saveDraft(Constants.SUGGEST_ID, input, Constants.SP_DRAFT);
					}
				}
			});
		}
	}

	public void deleteDraft(String itemId, String replyId) {
		if (iAmWhich() == Constants.WRITE_COMMENT) {
			SpDraft.delDraft(itemId, Constants.SP_DRAFT);
		} else if (iAmWhich() == Constants.WRITE_TRANS_COMMENT) {
			SpDraft.delDraft(itemId + replyId, Constants.SP_DRAFT);
		} else {
			SpDraft.delDraft(Constants.SUGGEST_ID, Constants.SP_DRAFT);
		}
	}

	public String loadDraft(String itemId, String replyId) {
		if (iAmWhich() == Constants.WRITE_COMMENT) {
			return SpDraft.getDraft(itemId, Constants.SP_DRAFT);
		} else if (iAmWhich() == Constants.WRITE_TRANS_COMMENT) {
			return SpDraft.getDraft(itemId + replyId, Constants.SP_DRAFT);
		} else {
			return SpDraft.getDraft(Constants.SUGGEST_ID, Constants.SP_DRAFT);
		}
	}

	/**
	 * 登录态失效
	 */
	private void reLogin() {
		Intent i = new Intent();
		i.putExtra(Constants.WRITE_WHICH_KEY, iAmWhich());
		i.putExtra(Constants.WRITE_COMMENT_CHANNEL_KEY, channelId);
		i.putExtra(Constants.WRITE_COMMENT_KEY, mItem);
		i.putExtra(Constants.WRITE_COMMENT_VID_KEY, this.vid);
		i.putExtra(Constants.WRITE_COMMENT_GRAPHICLIVECHLID_KEY, this.graphicLiveChlid);
		i.putExtra(Constants.WRITE_COMMENT_IMG_KEY, this.imgUrl);
		i.putExtra(Constants.WRITE_COMMENT_SHARE_TYPE_KEY, this.shareType);
		if (iAmWhich() == Constants.WRITE_TRANS_COMMENT) {
			i.putExtra(Constants.WRITE_TRAN_QQ_WEIBO_KEY, this.tranQQweiboStr);
			i.putExtra(Constants.WRITE_TRAN_COMMENT_KEY, this.comment);
		} else if (iAmWhich() == Constants.WRITE_COMMENT) {
			i.putExtra(Constants.WRITE_COMMENT_QQ_WEIBO_KEY, this.commentQQweiboStr);
		}
		i.setClass(this, ReLoginActivity.class);
		startActivity(i);
	}

	@Override
	public void applyTheme() {
		initViewsByMode();
		themeSettingsHelper.setViewBackgroudColor(this, mMask, R.color.mask_page_color);
	}
}
