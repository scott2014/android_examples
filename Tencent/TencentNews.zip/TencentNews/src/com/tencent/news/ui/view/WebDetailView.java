package com.tencent.news.ui.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.tencent.news.R;
import com.tencent.news.utils.ThemeSettingsHelper;

public class WebDetailView extends FrameLayout{
	private Context mContext;
	private LinearLayout mLoadingLayout;
	private WebView mWebView;
	private FrameLayout mNewDetailLayout;

	private View mMask;
	private ThemeSettingsHelper themeSettingsHelper = null;
	
	public WebDetailView(Context context) {
		super(context);
		init(context);
	}

	public WebDetailView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init(context);
	}
	
	private void init(Context context){
		this.mContext = context;
		LayoutInflater.from(mContext).inflate(R.layout.web_detail_view_layout, this, true);
		mLoadingLayout = (LinearLayout)findViewById(R.id.web_detail_loading);
		mWebView = (WebView)findViewById(R.id.web_detail_webview);
		mNewDetailLayout = (FrameLayout)findViewById(R.id.web_detail_layout);
		mMask = (View)findViewById(R.id.web_detail_mask_view);
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(mContext);
		if(!themeSettingsHelper.isDefaultTheme()) {
			applyTheme();
		}
	}
		
	/**
	 * 应用样式
	 */
	private void applyTheme() {
		mLoadingLayout.setBackgroundResource(R.color.night_view_bg_color);
		mNewDetailLayout.setBackgroundResource(R.color.night_view_bg_color);
		mWebView.setBackgroundResource(R.color.night_view_bg_color);
		ImageView news_loading_icon =  (ImageView)findViewById(R.id.news_loading_icon);
		if(news_loading_icon != null) {
			news_loading_icon.setImageResource(R.drawable.night_news_loading_icon);
		}
	}
	
	public void Loading(){
		mLoadingLayout.setVisibility(View.VISIBLE);
	}
	
	public void loadComplete() {
		mWebView.setVisibility(View.VISIBLE);
		mLoadingLayout.setVisibility(View.GONE);
		themeSettingsHelper.setViewBackgroudColor(mContext, mMask, R.color.mask_webview_color);
	}
	
	public WebView getWebView(){
		return this.mWebView;
	}
	
	public FrameLayout getNewsDetailLayout(){
		return this.mNewDetailLayout;
	}
}
