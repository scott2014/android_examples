package com.tencent.news.ui;

import java.util.ArrayList;
import java.util.List;

import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TabHost;

import com.tencent.news.R;
import com.tencent.news.ui.view.AppNavigationBar;
import com.tencent.news.ui.view.AppNavigationBar.AppNavigationListener;
import com.tencent.omg.webdev.WebDev;

/**
 * 应用推荐入口
 * 
 * @author vincesun
 */

public class DownloadListActivity extends TabActivity implements OnClickListener {

	public static final String HOT_APP = "hot_app";// 热门应用
	public static final String QUALITY_APP = "quality_app";// 精品应用

	private TabHost mTabHost;
	private List<String> mActivityId = new ArrayList<String>();
	private AppNavigationBar mNavigationBar = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		overridePendingTransition(R.anim.push_left_in, R.anim.push_left_out);
		setContentView(R.layout.activity_download_main);
		InitView();
		setupTabs();
		InitListener();

	}

	protected void quitActivity() {
		finish();
		overridePendingTransition(R.anim.push_right_in, R.anim.push_right_out);
	}

	private void InitView() {
		mNavigationBar = (AppNavigationBar) findViewById(R.id.app_navigation_bar);
		mActivityId.add(HOT_APP);
		mActivityId.add(QUALITY_APP);
	}

	private void setupTabs() {
		mTabHost = this.getTabHost();
		Intent intent = new Intent(this, HotAppListActivity.class);
		mTabHost.addTab(mTabHost.newTabSpec(mActivityId.get(0)).setIndicator(mActivityId.get(0)).setContent(intent));
		// mTabHost.addTab(mTabHost.newTabSpec(mActivityId.get(1))
		// .setIndicator(mActivityId.get(1))
		// .setContent(new Intent(this, QualityAppListActivity.class)));
	}

	private void InitListener() {
		mNavigationBar.setOnNavigationListener(new AppNavigationListener() {

			@Override
			public void onNavigationBarClick(int nIndex) {
				if (mTabHost != null) {
					mTabHost.setCurrentTab(nIndex);
				}
			}
		});
	}

	@Override
	protected void onDestroy() {
		quitActivity();
		super.onDestroy();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
			quitActivity();
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_MENU) {
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.app_title_btn_back:
			quitActivity();
			break;
		default:
			break;
		}
	}

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}
}
