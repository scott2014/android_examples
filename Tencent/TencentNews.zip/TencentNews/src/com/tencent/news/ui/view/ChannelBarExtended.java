package com.tencent.news.ui.view;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.util.AttributeSet;

import com.tencent.news.model.pojo.Channel;
import com.tencent.news.model.pojo.ChannelList;
import com.tencent.news.model.pojo.DynamicChannel;
import com.tencent.news.model.pojo.ExtendedChannels;
import com.tencent.news.utils.InfoConfigUtil;

public class ChannelBarExtended extends ChannelBarBase {
	public ChannelBarExtended(Context context){
		super(context,false);
	}
	
	public ChannelBarExtended(Context context, AttributeSet attrs){
		super(context,attrs,false);
	}
	
	@Override
	public ChannelList getChannelList(){
		ChannelList retList = new ChannelList();
		List<Channel> chList = new ArrayList<Channel>();
		
		ExtendedChannels mExtendedChannel = InfoConfigUtil.ReadExtendedChannels();
		DynamicChannel[] channellist = mExtendedChannel.getChannellist();
		if(channellist != null && channellist.length > 0){
			int nChannelSize = channellist.length;
			for(int i = 0; i < nChannelSize; i++){
				DynamicChannel dChannel = channellist[i];
				Channel channel = new Channel();
				channel.setChlid(dChannel.getChlid());
				channel.setChlname(dChannel.getChlname());
				chList.add(channel);
			}
			retList.setChannelList(chList);
		}
		
		return retList;
	}

	@Override
	public void onClickSetUp() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object getChannelData() {
		ExtendedChannels mExtendedChannel = InfoConfigUtil.ReadExtendedChannels();
		return mExtendedChannel;
	}
}