package com.tencent.news.ui.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.ScrollView;

public class InterceptScrollView extends ScrollView {
	private boolean on = true;

	public InterceptScrollView(Context context) {
		super(context);
	}

	public InterceptScrollView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	public InterceptScrollView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	/**
	 * 开启滚动
	 */
	public void enable() {
		on = true;
	}

	/**
	 * 禁止滚动
	 */
	public void disable() {
		on = false;
	}

	@Override
	public boolean onInterceptTouchEvent(MotionEvent ev) {
		if (on) {
			return super.onInterceptTouchEvent(ev);
		} else {
			return false;
		}
	}
}
