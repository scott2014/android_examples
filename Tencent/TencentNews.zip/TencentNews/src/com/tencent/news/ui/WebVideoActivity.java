package com.tencent.news.ui;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.config.Constants;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.utils.SLog;
import com.tencent.omg.webdev.WebDev;

public class WebVideoActivity extends BaseActivity {
	private final static int MSG_VIDEO = 0x103;
	private final static int MSG_VIDEO_PAGE = 0x104;
	private final static long DELAY_TIME = 1000L;
	private final static long DELAY_TIME_PAGE = 100L;
	private String mUrl;
	private String mVid;
	private WebView mWebView;
	private TextView webVideoname;
	private Button webVideo_btn_back;
	private FrameLayout mLoadingLayout;
	private Item mItem;
	private String mChild;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_webvideo);

		Intent intent = getIntent();
		if (intent != null) {
			mVid = intent.getStringExtra(Constants.PLAY_VIDEO_VID_KEY);
			mUrl = intent.getStringExtra("playurl");
			// kiddyliu 2013-03-21
			mItem = (Item) intent.getSerializableExtra(Constants.NEWS_DETAIL_KEY);
			mChild = intent.getStringExtra(Constants.NEWS_CHANNEL_CHLID_KEY);
		}
		initView();
		initListener();
	}

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}

	private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if (msg != null) {
				switch (msg.what) {
				case MSG_VIDEO:
					playVideo();
					break;

				case MSG_VIDEO_PAGE:
					runPage();
					break;

				default:
					break;
				}
			}

			// if(msg != null && msg.what == MSG_VIDEO){
			// playVideo();
			// }

		}
	};

	private void initView() {
		mWebView = (WebView) findViewById(R.id.webVideoView);
		mWebView.getSettings().setJavaScriptEnabled(true);
		mWebView.getSettings().setSavePassword(false);
		mWebView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
		webVideoname = (TextView) findViewById(R.id.webVideoName);
		webVideo_btn_back = (Button) findViewById(R.id.webVideo_btn_back);
		mLoadingLayout = (FrameLayout) findViewById(R.id.web_viedo_loading);
		webVideoname.setText("腾讯新闻");
		mWebView.loadUrl(mUrl);
	}

	private void runPage() {
		mLoadingLayout.setVisibility(View.GONE);
		if (mHandler != null) {
			mHandler.sendEmptyMessageDelayed(MSG_VIDEO, DELAY_TIME);
		}
	}

	private void initListener() {
		mWebView.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView view, String url, Bitmap favicon) {
				SLog.i("webview", "onPageStarted" + url + favicon);
			}

			@Override
			public void onPageFinished(WebView view, String url) {
				super.onPageFinished(view, url);
				mHandler.sendEmptyMessageDelayed(MSG_VIDEO_PAGE, DELAY_TIME_PAGE);
				// mLoadingLayout.setVisibility(View.GONE);
				// if(mHandler != null){
				// mHandler.sendEmptyMessageDelayed(MSG_VIDEO, DELAY_TIME);
				// }
			}

			@Override
			public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
				super.onReceivedError(view, errorCode, description, failingUrl);
				mWebView.loadUrl(Constants.WEB_ERROR);
			}

		});

		webVideo_btn_back.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				destroyActivity();
			}
		});
	}

	private void playVideo() {
		Intent intent = new Intent();
		intent.putExtra(Constants.PLAY_VIDEO_VID_KEY, mVid);
		intent.putExtra(Constants.NEWS_CHANNEL_CHLID_KEY, mChild);
		intent.putExtra(Constants.NEWS_DETAIL_KEY, mItem); // kiddyliu
															// 2013-03-21
		intent.setClass(WebVideoActivity.this, PlayVideoActivity.class);
		startActivity(intent);
		destroyActivity();
	}

	private void destroyActivity() {
		if (mHandler != null) {
			mHandler.removeMessages(MSG_VIDEO);
			mHandler.removeMessages(MSG_VIDEO_PAGE);
		}
		quitActivity();
	}

	@Override
	protected void onDestroy() {
		destroyActivity();
		super.onDestroy();
	}

	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if ((keyCode == KeyEvent.KEYCODE_BACK)) {
			destroyActivity();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

}
