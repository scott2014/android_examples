package com.tencent.news.ui;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

import org.json.JSONException;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Picture;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup.LayoutParams;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebView.PictureListener;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.boss.EventId;
import com.tencent.news.cache.NewsDetailCache;
import com.tencent.news.cache.NewsDetailCache.CacheType;
import com.tencent.news.command.GetImageRequest;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.pojo.ExtendedChannels;
import com.tencent.news.model.pojo.Image;
import com.tencent.news.model.pojo.ImageResult;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.model.pojo.LiveInfo;
import com.tencent.news.model.pojo.LiveStatus;
import com.tencent.news.model.pojo.LiveTime;
import com.tencent.news.model.pojo.RssCatListItem;
import com.tencent.news.model.pojo.SimpleNewsDetail;
import com.tencent.news.model.pojo.SubProject;
import com.tencent.news.model.pojo.UserInfo;
import com.tencent.news.model.pojo.VideoValue;
import com.tencent.news.model.pojo.VoteInfo;
import com.tencent.news.shareprefrence.SpConfig;
import com.tencent.news.shareprefrence.SpTopicHadVoted;
import com.tencent.news.shareprefrence.SpUserHelp;
import com.tencent.news.system.AddCommentBroadcastReceiver;
import com.tencent.news.system.NetStatusReceiver;
import com.tencent.news.system.RefreshCommentNumBroadcastReceiver;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.adapter.ViewPagerAdapter;
import com.tencent.news.ui.view.CommentView;
import com.tencent.news.ui.view.NavigationBar;
import com.tencent.news.ui.view.NewsDetailView;
import com.tencent.news.ui.view.NewsWebView;
import com.tencent.news.ui.view.ShareDialog;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.news.ui.view.TitleBar;
import com.tencent.news.ui.view.ViewPagerEx;
import com.tencent.news.ui.view.WritingCommentView;
import com.tencent.news.ui.view.WritingCommentView.OnChangeClick;
import com.tencent.news.utils.DispatchClassUtil;
import com.tencent.news.utils.InfoConfigUtil;
import com.tencent.news.utils.IntentUtil;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.StringUtil;
import com.tencent.omg.webdev.WebDev;


public abstract class AbsNewsActivity extends NavActivity {
	protected static final int GENERAL_NEWS_DETAIL = 0;
	protected static final int PUSH_NEWS_DETAIL = 1;
	protected static final int WEIXIN_NEWS_DETAIL = 2;
	protected static final int WIDGET_NEWS_DETAIL = 3;
	protected static final int RELATED_NEWS_DETAIL = 4;
	protected static final int RESET_TITLE_BAR_SHARE_BTN = 8;
	public static final String INTERNAL_GOTO_URL = "http://inews.qq.com/getContent"; // 假接口，不用域名读写分离
	public static final String RELATE_NEWS       = "http://inews.qq.com/getRelateNews"; // 假接口，不用域名读写分离
    public static final String RSS_MEDIA_NEWS    = "http://inews.qq.com/getRssMedia"; // 假接口，不用域名读写分离
    public static final String RSS_MEDIA_HISTORY_NEWS    = "http://inews.qq.com/getRssHistory"; // 假接口，不用域名读写分离
    public static final String ACTIVITY_OPEN_FROM = "activity_open_from";  // 从哪个页面跳转过来的
	protected RelativeLayout mRootLayout;
	protected NewsWebView mWebView;
	protected WritingCommentView mWritingCommentView;
	protected CommentView mCommentView;
	protected TitleBar mTitleBar;
	protected ArrayList<String> imgUrlList = new ArrayList<String>();
	protected String mVideoImgUrl;
	protected String mTitleText;
	protected String mChild;
	private View mMask;
	protected NewsDetailCache mNewsDetailCache;
	protected float downX;
	protected float upX;
	protected float downY;
	protected float upY;
	protected Item mItem;
	protected boolean isSpecial = false;
	protected boolean isOffline = false;
	protected int mIsComment;
	protected AddCommentBroadcastReceiver receiver;
	protected RefreshCommentNumBroadcastReceiver mRefreshCommentReceiver;
	protected VoteInfo mVoteInfo;
	protected SubProject mSubProject;
	protected int mSourceType;
	protected String mClickPosition;
	protected LinearLayout mNewsLayout;
	private NewsDetailView mNewsDetailView;
	private ViewPagerEx mViewPager;
	protected int nCurrentPage = 0;
	private ViewPagerAdapter mViewPagerAdapter;
	protected NewsHandler mHandler = null;
	private List<Item> relatenews;
	private TreeMap<String, Object> attribute;
	private RssCatListItem card;
	private long loadUrlTime;
	private static int CLICK_TIME = 500;
	private String openFrom = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.detail_layout);
		setSourceType();
		getIntentData(getIntent());
		initView();
		initListener();
		getData();
		registerBroadReceiver();
	}
	
	@Override
	protected void onStart() {
		super.onStart();
	}

	@Override
	protected void onDestroy() {
		if (receiver != null) {
			unregisterReceiver(receiver);
			receiver = null;
		}
		if (mRefreshCommentReceiver != null) {
			unregisterReceiver(mRefreshCommentReceiver);
			mRefreshCommentReceiver = null;
		}
		if (imgUrlList != null) {
			imgUrlList.clear();
			imgUrlList = null;
		}
		if (mViewPagerAdapter != null) {
			mViewPagerAdapter.clearAdapterView();
		}

		if (mWebView != null) {
			mNewsDetailView.getNewsDetailLayout().removeView(mWebView);
			mWebView.removeAllViews();
			mWebView.destroy();
			mWebView = null;
			if(mRootLayout != null) {
			    mRootLayout.removeAllViews();
			}
		}
		TaskManager.cancelAllImageThread();
		TaskManager.clearImageCache();
		ShareDialog.getInstance().dismiss();
		super.onDestroy();
	}

	protected void initView() {
		mHandler = new NewsHandler(this);
		mRootLayout = (RelativeLayout) findViewById(R.id.news_detail_root_layout);
		mViewPager = (ViewPagerEx) findViewById(R.id.news_view_pager);
		mTitleBar = (TitleBar) findViewById(R.id.news_detail_title_bar);
		mMask = (View)findViewById(R.id.mask_view);
		mWritingCommentView = (WritingCommentView) findViewById(R.id.WritingCommentView);
		mNewsDetailView = new NewsDetailView(this);	
		mWebView = mNewsDetailView.getNewsWebView();
		openFrom = this.getIntent().getStringExtra(AbsNewsActivity.ACTIVITY_OPEN_FROM);
		mWebView.setReffer(openFrom);
		mCommentView = new CommentView(this);
		if(isOffline) {
			mWebView.setOffline();
			mCommentView.setOffline();
		}
		mTitleBar.ShowNewsBar(mTitleText);
		List<View> mViews = new ArrayList<View>();
		mViews.add(mNewsDetailView);
		mViews.add(mCommentView);
		mViewPagerAdapter = new ViewPagerAdapter(mViews);
		mViewPager.setAdapter(mViewPagerAdapter);
		mViewPager.setOffscreenPageLimit(1);
		mViewPager.setCurrentItem(mIsComment);
		mViewPager.setPageMargin(2);
		mViewPager.setOnPageChangeListener(new MyOnPageChangeListener());
		setTitleBackName();
		if (isInitComments()) {
			mWritingCommentView.setItem(mChild, mItem);
			mWritingCommentView.canWrite(false);
			mCommentView.init(mChild, mItem);
			mCommentView.setWritingCommentView(mWritingCommentView);
		}
	}

	
	private void setTitleBackName() {
		if(isRelateNews || (mItem != null && mItem.getIsRss())) {
			mTitleBar.setBackName("返回");
			return;
		}
		if(mNewsDetailCache.getMcahceType()==CacheType.FAVOR_CACHE){
			mTitleBar.setBackName("收藏");
			return;
		}
		ExtendedChannels channel = InfoConfigUtil.ReadExtendedChannels();
		if (mChild.equals(TencentNews.TOPIC) && NavigationBar.getSelected() == 3) {
			mTitleBar.setBackName("话题");
		} else {
			if (isSpecial) {
				mTitleBar.setBackName("专题");
			} else {
				if (channel != null && channel.getChlname() != null && NavigationBar.getSelected() == 4) {
					mTitleBar.setBackName(channel.getChlname());
				} else {
					if (isOffline)
						mTitleBar.setBackName(SpConfig.getChannelNameById(mChild));
					else
						mTitleBar.setBackName("新闻");
				}
			}
		}
	}

	protected void Loading() {
		mNewsDetailView.Loading();
	}

	protected void loadComplete() {
		mNewsDetailView.loadComplete();
	}

	protected void loadError() {
		mNewsDetailView.loadError();
	}

	/**
	 * 先判断是否有缓存，然后获取新闻内容
	 */
	protected void getQQnewsContentData() {
		Loading();
		TaskManager.startRunnableRequest(new Runnable() {
			@Override
			public void run() {

				SimpleNewsDetail detail = mNewsDetailCache.getNewsDetail();
				if (detail != null) {
					Message msg = Message.obtain();
					msg.obj = detail;
					mHandler.sendMessage(msg);
				} else {
					
					WebDev.trackCustomBeginKVEvent(AbsNewsActivity.this, EventId.ITIL_LOAD_DETAIL_TIME, getPts());
					
					HttpDataRequest request = TencentNews.getInstance().getSimpleHtmlContent(mItem.getId(), mChild, mNewsDetailCache.getMcahceType());
					TaskManager.startHttpDataRequset(request, AbsNewsActivity.this);
				}

			}
		});
	}

	private void getVideoLiveStatus() {
		if (mItem != null && mItem.getFlag() != null && mItem.getFlag().equals("6") && mWebView != null && mWebView.getProgId() != null) {
			HttpDataRequest request = TencentNews.getInstance().getVideoLiveStatus(mWebView.getProgId(), mItem.getId(), mChild);
			TaskManager.startHttpDataRequset(request, this);
		}
	}

	protected void initListener() {

		mWritingCommentView.setDetailCommentChangeClick(new OnChangeClick() {

			@Override
			public void change() {
				if (nCurrentPage == 0) {
					mViewPager.setCurrentItem(1);
				} else {
					mViewPager.setCurrentItem(0);
				}
			}
		});

		mNewsDetailView.setOnRetryClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				retryData();
			}

		});

		mTitleBar.setShareClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				ShareDialog.getInstance().showShareList(AbsNewsActivity.this, ShareDialog.SHARE_NORMAL_DETAIL, mTitleBar.getShareBtn());
			}
		});

		mTitleBar.setBackClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				targetActivity();
			}

		});

		mTitleBar.setTopClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (nCurrentPage == 0) {
					if (mWebView != null) {
						mWebView.loadUrl("javascript:scrollToTop()");
					}
				} else {
					mCommentView.upToTop();
				}
			}
		});

		if (mWebView != null) {
			mWebView.addJavascriptInterface(new TencentNewsScriptInterface(this), "TencentNews");
			mWebView.addJavascriptInterface(new NativeStorageInterface(this), "nativeStorage");
		}

		mWebView.setPictureListener(new PictureListener() {
			@Override
			public void onNewPicture(WebView view, Picture picture) {
				SLog.i("webview", "onNewPicture" + picture.getHeight());
			}
		});

		mWebView.setWebChromeClient(new WebChromeClient() {
			@Override
			public void onProgressChanged(WebView view, int newProgress) {
				SLog.i("webview", "onProgressChanged" + newProgress);
			}
			
			@Override
			public void onConsoleMessage(String message, int lineNumber, String sourceID) {
				SLog.d("jslogyy", message + " -- From line " + lineNumber + " of " + sourceID);
			}

		});

		mWebView.setWebViewClient(new WebViewClient() {
			
			@Override
			public void onPageStarted(WebView view, String url, Bitmap favicon) {
				SLog.i("webview", "onPageStarted" + url + favicon);
			}

			@Override
			public void onPageFinished(WebView view, String url) {
				super.onPageFinished(view, url);
				SLog.i("webview", "onPageFinished" + url);
				loadComplete();
				getVideoLiveStatus();
				/* loadVoteData(); */
			}

			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				long currentTime = System.currentTimeMillis();
				//防止快速多次点击
				if(Math.abs(loadUrlTime - currentTime) < CLICK_TIME) {
					return true;
				}
				if (url.startsWith(RELATE_NEWS) || url.startsWith(INTERNAL_GOTO_URL)) {
					Uri data = Uri.parse(url);
					Item item = null;
					String newsId = data.getQueryParameter("id");
					if(url.startsWith(RELATE_NEWS)) {
						item = getRelatenewsById(newsId);
					} else {
						item = getLinkByKey(newsId);						
					}
					if (item != null && item.getArticletype() != null) {
						Intent intent = new Intent();
						Bundle bundle = new Bundle();
						bundle.putSerializable(Constants.NEWS_DETAIL_KEY, item);
						bundle.putString(Constants.NEWS_CHANNEL_CHLID_KEY, mChild);
						bundle.putString(Constants.NEWS_DETAIL_TITLE_KEY, mTitleText);
						bundle.putString(Constants.NEWS_CLICK_ITEM_POSITION, "" + (mClickPosition + 1));
						intent.putExtras(bundle);
						intent.setClass(AbsNewsActivity.this, DispatchClassUtil.getClassName(item.getArticletype()));
						isRelateNews = true;
						startActivity(intent);
					}
				} else if(url.startsWith(RSS_MEDIA_NEWS)) {
				    RssCatListItem rssChannelListItem = new RssCatListItem();
				    rssChannelListItem.setChlid(card.getChlid());
				    rssChannelListItem.setChlname(card.getChlname());
                    rssChannelListItem.setUin(card.getUin());
				    rssChannelListItem.setEmpty(true);
                    Intent intent = new Intent();
                    Bundle bundle = new Bundle();
                    bundle.putSerializable(RssMediaActivity.RSS_MEDIA_ITEM, rssChannelListItem);
                    intent.putExtras(bundle);
                    intent.setClass(AbsNewsActivity.this, RssMediaActivity.class);
                    isRelateNews = false;
                    startActivity(intent);
				}else if(url.startsWith(RSS_MEDIA_HISTORY_NEWS)) {
                    RssCatListItem rssChannelListItem = new RssCatListItem();
                    rssChannelListItem.setChlid(card.getChlid());
                    rssChannelListItem.setChlname(card.getChlname());
                    rssChannelListItem.setUin(card.getUin());
                    rssChannelListItem.setEmpty(true);
                    Intent intent = new Intent();
                    Bundle bundle = new Bundle();
                    bundle.putSerializable(RssMediaActivity.RSS_MEDIA_ITEM, rssChannelListItem);
                    intent.putExtras(bundle);
                    intent.setClass(AbsNewsActivity.this, RssMediaHistoryActivity.class);
                    isRelateNews = false;
                    startActivity(intent);
                } else {
					//view.loadUrl(url);
					Intent i = new Intent();
                    i.setClass(AbsNewsActivity.this, WebBrowserActivity.class);
                    i.putExtra("url", url);
                    startActivity(i);
				}
				loadUrlTime = System.currentTimeMillis();
				return true;
			}

			@Override
			public void onLoadResource(WebView view, String url) {
				SLog.i("webview", "onLoadResource" + url);
			}

			@Override
			public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
				SLog.i("webview", "onLoadResource" + errorCode + description + failingUrl);
				super.onReceivedError(view, errorCode, description, failingUrl);
			}
		});

		mWebView.setOnLongClickListener(new OnLongClickListener() {
			@Override
			public boolean onLongClick(View v) {
				SLog.i("NewsDetailActivity", "长按事件");
				mWebView.loadUrl("javascript:tna.longClick = true");
				return false;
			}
		});
	}


	/**
	 * 根据新闻id，从相关新闻列表中获取列表信息
	 * 
	 * @param newsId
	 * @return
	 */
	private Item getRelatenewsById(String newsId) {
		int count = relatenews.size();
		if (count > 0) {
			for (int i = 0; i < count; i++) {
				Item it = relatenews.get(i);
				if (it.getId().equals(newsId)) {
					return it;
				}
			}
		}
		return null;
	}
	
	/**
	 * 根据新闻id，从属性列表中获取列表信息
	 * 
	 * @param key
	 * @return
	 */
	private Item getLinkByKey(String key) {
		if (attribute != null && attribute.containsKey(key)) {
			return (Item) attribute.get(key);
		}
		return null;	
	}

	protected static class NewsHandler extends Handler {
		private WeakReference<AbsNewsActivity> mOuterClass;

		NewsHandler(AbsNewsActivity activity) {
			mOuterClass = new WeakReference<AbsNewsActivity>(activity);
		}

		@Override
		public void handleMessage(android.os.Message msg) {
			super.handleMessage(msg);
			AbsNewsActivity mTheClass = mOuterClass.get();
			if (msg != null && msg.obj != null && mTheClass!=null) {
				SimpleNewsDetail detail = (SimpleNewsDetail) msg.obj;
				mTheClass.relatenews = detail.getRelate_news();
				mTheClass.attribute = detail.getAttribute();
				mTheClass.card = detail.getCard();
//				mTheClass.statistics_load_end_time = System.currentTimeMillis();
//				mTheClass.statistics_load_total = mTheClass.statistics_load_end_time - mTheClass.statistics_load_start_time;
//				if (mTheClass.statistics_load_total < 0) {
//					mTheClass.statistics_load_total = 0;
//				}

				if (detail != null && mTheClass.mWebView != null) {
					mTheClass.isShowUserHelp();
					mTheClass.shareNewsData(detail);
					mTheClass.InitImageUrl(detail);
					mTheClass.mWebView.LoadLocalWithData(mTheClass.mItem, detail);
					mTheClass.mCommentView.enterPageThenGetComments(isRelateNews);
					mTheClass.mWritingCommentView.canWrite(true);
					mTheClass.setCommentBarImgVid(detail);
					mTheClass.sendBroadCastforRead();
				} else {
					mTheClass.loadComplete();
				}
			}
		}
	}

	private void shareNewsData(SimpleNewsDetail detail) {
		mTitleBar.getShareBtn().setEnabled(true);
		ShareDialog.getInstance().setParams("", "", detail, mItem, mChild);
		ShareDialog.getInstance().setOpenFrom(openFrom);
	}

	private void isShowUserHelp() {
		if (SpUserHelp.getNewsDetailHelp()) {
			if (mSourceType == GENERAL_NEWS_DETAIL || mSourceType == PUSH_NEWS_DETAIL) {
				attachHelpView();
			}
		}
	}

	private void attachHelpView() {
		View v = new View(this);
		v.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT));
		v.setBackgroundResource(R.drawable.news_detail_help);
		mRootLayout.addView(v);
		v.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				mRootLayout.removeView(v);
				SpUserHelp.setNewsDetailHelp(false);
			}

		});
	}

	/**
	 * 判断是否是投票，若是投票获取投票数据
	 */
	private void getVoteInfo() {
		HttpDataRequest request = TencentNews.getInstance().getQQNewsVoteInfo(mItem.getVoteId(), mChild);
		TaskManager.startHttpDataRequset(request, this);
	}

	private void setCommentBarImgVid(SimpleNewsDetail detail) {
		if (detail != null && mItem != null) {
			TreeMap<String, Object> attribute = detail.getAttribute();
			if (attribute != null && attribute.containsKey("VIDEO_0")) {
				VideoValue dataMap = (VideoValue) attribute.get("VIDEO_0");
				if (dataMap != null) {
					String mVid = dataMap.getVid();
					String img = dataMap.getImg();
					mWritingCommentView.setVid(mVid);
					mWritingCommentView.setImg(img);
					mCommentView.setImg(img);
					ShareDialog.getInstance().setVid(mVid);
					ShareDialog.getInstance().setImageUrl(img);
				}
			} else {
				if (attribute != null && attribute.containsKey("IMG_0")) {
					Image dataMap = (Image) attribute.get("IMG_0");
					if (dataMap != null) {
						String url = dataMap.getUrl();
						mWritingCommentView.setImg(url);
						mCommentView.setImg(url);
						mWritingCommentView.setVid("");
						ShareDialog.getInstance().setImageUrl(url);
						ShareDialog.getInstance().setVid("");
					}
				} else {
					if (mItem.getThumbnails() != null && mItem.getThumbnails().length > 0) {
						mWritingCommentView.setImg(mItem.getThumbnails()[0]);
						mCommentView.setImg(mItem.getThumbnails()[0]);
						ShareDialog.getInstance().setImageUrl(mItem.getThumbnails()[0]);
					} else {
						mWritingCommentView.setImg("");
						mCommentView.setImg("");
						ShareDialog.getInstance().setImageUrl("");
					}
					mWritingCommentView.setVid("");
					ShareDialog.getInstance().setVid("");
				}
			}
		}
	}

	/**
	 * 初始化网页图片url和视频url
	 * 
	 * @param <list>
	 *            数据
	 */
	private void InitImageUrl(SimpleNewsDetail detail) {
		TreeMap<String, Object> attribute = detail.getAttribute();
		if (attribute.size() == 0) {
			return;
		}
		Iterator<?> keyIter = attribute.entrySet().iterator();
		while (keyIter.hasNext()) {
			@SuppressWarnings("unchecked")
			Map.Entry<String, Object> entry = (Map.Entry<String, Object>) keyIter.next();
			String key = (String) entry.getKey();
			if (key.indexOf("IMG") > -1 && attribute.containsKey(key)) {
				Image dataMap = (Image) attribute.get(key);
				if (dataMap != null) {
					String url = dataMap.getUrl();
					imgUrlList.add(url);
				}
			} else if (key.equals("VIDEO_0") && attribute.containsKey(key)) {
				VideoValue dataMap = (VideoValue) attribute.get(key);
				if (dataMap != null) {
					String img = (String) dataMap.getImg();
					mVideoImgUrl = img;
				}

			}
		}
		SLog.i("webview", "image url size+" + imgUrlList.size());
	}

	private void replaceWebImage(final String url, final String path) {
		try {
			if (mWebView != null && url != null && path != null) {
				final String id = StringUtil.toMd5(url);
				if (id != null && mWebView.isDestroy() && mHandler != null) {
					mHandler.post(new Runnable() {
						@Override
						public void run() {
							mWebView.loadUrl("javascript:replaceImage('" + id + "','" + path + "')");
						}
					});
				}
			}
		} catch (NullPointerException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 加载图片成功以后返回
	 * 如果有异常给予提示
	 * @param url
	 */
	private void getImageRequest(String url) {
		GetImageRequest request = new GetImageRequest();
		request.setGzip(false);
		request.setTag(url);
		request.setUrl(url);
		ImageResult result = TaskManager.startSmallImageTask(request, this);
		if (result.isResultOK() && result.getRetBitmap() != null) {
			SLog.w("webview", result.getImagePath());
			replaceWebImage(url, result.getImagePath());
		}
	}

	private void setVideoLiveStatus(final LiveStatus status) {
		try {
			if (mWebView != null && status != null && status.getLiveInfo() != null) {
				final LiveInfo info = status.getLiveInfo();
				final LiveTime time = info.getLiveTime();
				if (mWebView.isDestroy()) {
					mHandler.post(new Runnable() {
						@Override
						public void run() {
							mWebView.loadUrl("javascript:setVideoLiveStatus('" + info.getProgid() + "','" + status.getRetCode() + "', '" + time.getTimeStart()
									+ "', '" + time.getTimeEnd() + "', '" + time.getTimeCurr() + "')");
						}
					});
				}
			}
		} catch (NullPointerException e) {
			e.printStackTrace();
		}
	}
	
	private void sendBroadCastforRead() {
		Intent intent = new Intent();
		Bundle bundle = new Bundle();
		bundle.putSerializable(Constants.NEWS_ID_KEY, mItem);
		bundle.putString(Constants.NEWS_CLICK_ITEM_POSITION, mClickPosition);
		intent.putExtras(bundle);
		
		String action = IntentUtil.getReadBroadcastAction(getIntent());
		if (action != null) {
            intent.setAction(action);
		} else if (isSpecial) {
			intent.setAction(Constants.NEWS_HAD_READ_SPECIAL_ACTION + mChild);
		}else {
			intent.setAction(Constants.NEWS_HAD_READ_ACTION + mChild);
		}
		sendBroadcast(intent);
		
		Intent intent2 = new Intent();
		intent2.setAction(Constants.NEWS_HAD_READ_FOR_OFFLINE_ACTION);
		intent2.putExtras(bundle);
		sendBroadcast(intent2);
	}

	@Override
	public boolean dispatchTouchEvent(MotionEvent ev) {
		final float x = ev.getX();
		final float y = ev.getY();
		if (ev.getAction() == MotionEvent.ACTION_DOWN) {
			downX = x;
			downY = y;
		} else if (ev.getAction() == MotionEvent.ACTION_UP) {
			upX = x;
			upY = y;
			if (nCurrentPage == 0 && upX > downX && Math.abs(upX - downX) > MobileUtil.dpToPx(100) && Math.abs(upY - downY) / Math.abs(upX - downX) < 0.4) {
				targetActivity();
			}
		}
		return super.dispatchTouchEvent(ev);
	}

	@Override
	public void onHttpRecvOK(HttpTag tag, Object result) {
		if (tag.equals(HttpTag.SIMPLE_HTML_CONTENT)) {
			
			Properties p = getPts();
			WebDev.trackCustomEndKVEvent(AbsNewsActivity.this, EventId.ITIL_LOAD_DETAIL_TIME, p);
			Properties newp = new Properties(p);
			newp.setProperty(EventId.KEY_RESCODE, EventId.VALUE_RESCODE_SUCCESS);
			WebDev.trackCustomEvent(AbsNewsActivity.this, EventId.ITIL_LOAD_DETAIL_TIME_RESULT, newp);
			
			
			SimpleNewsDetail detail = (SimpleNewsDetail) result;
			Message msg = new Message();
			msg.obj = detail;
			mHandler.sendMessage(msg);
			mNewsDetailCache.setCacheDetailData(detail);
			mNewsDetailCache.saveNewsDetail();
		} else if (tag.equals(HttpTag.VIDEO_LIVE)) {
			LiveStatus status = (LiveStatus) result;
			setVideoLiveStatus(status);

		}
	}

	@Override
	public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {
		if (tag.equals(HttpTag.SIMPLE_HTML_CONTENT)) {
			
			Properties p = getPts();
			WebDev.trackCustomEndKVEvent(AbsNewsActivity.this, EventId.ITIL_LOAD_DETAIL_TIME, p);
			Properties newp = new Properties(p);
			newp.setProperty(EventId.KEY_RESCODE, EventId.VALUE_RESCODE_ERROR);
			WebDev.trackCustomEvent(AbsNewsActivity.this, EventId.ITIL_LOAD_DETAIL_TIME_RESULT, newp);
			
			TipsToast.getInstance().showTipsError(msg);
			loadError();
		} else if (tag.equals(HttpTag.VIDEO_LIVE)) {

		}
	}

	@Override
	public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm, String path) {
		switch (imageType) {
		case SMALL_IMAGE:
			if (mVideoImgUrl != null && ((String) tag).equals(mVideoImgUrl)) {
				replaceWebImage(mVideoImgUrl, path);
			} else {
				if (imgUrlList != null) {
					for (int i = 0; i < imgUrlList.size(); i++) {
						String url = imgUrlList.get(i);
						if (((String) tag).equals(url)) {
							replaceWebImage(url, path);
						}
					}
				}
			}
			break;
		default:
			break;
		}
	}
	
	@Override
	public void onImageRecvError(ImageType imageType, Object tag, int retCode) {
		switch (imageType) {
		case SMALL_IMAGE:
			if (mVideoImgUrl != null && ((String) tag).equals(mVideoImgUrl)) {
				replaceWebImage(mVideoImgUrl, String.valueOf(ImageResult.ERROR_NO_NET));
			} else {
				if (imgUrlList != null) {
					for (int i = 0; i < imgUrlList.size(); i++) {
						String url = imgUrlList.get(i);
						if (((String) tag).equals(url)) {
							replaceWebImage(url, String.valueOf(ImageResult.ERROR_NO_NET));
						}
					}
				}
			}
			break;
		default:
			break;
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, final Intent data) {
		if (resultCode == RESULT_OK) {
			if (requestCode == Constants.RQ_WATICH_IMAGE) {
				if (data != null && mWebView != null) {
					Log.i("Web Console", "back---->" + data.getIntExtra(Constants.WATICH_IMAGE_CURRENT_INDEX_BACK, -1));
					mHandler.post(new Runnable() {
						@Override
						public void run() {
							mWebView.loadUrl("javascript:tna.moveImageToClient(" + data.getIntExtra(Constants.WATICH_IMAGE_CURRENT_INDEX_BACK, -1) + ")");
						}
					});
				}
			} else if (requestCode == Constants.REQUEST_CODE_LOGIN) {
                if (card != null && data != null && data.hasExtra(Constants.LOGIN_SUCCESS_BACK_USER_KEY)) {
                    UserInfo userinfo = (UserInfo) data.getSerializableExtra(Constants.LOGIN_SUCCESS_BACK_USER_KEY);
                    if (userinfo != null && userinfo.getAccount() != null) {
                        Intent intent = new Intent();
                        intent.putExtra("uin", card.getUin());
                        intent.putExtra("nick", card.getChlname());
                        intent.putExtra("mediaHeadUrl", card.getIcon());
                        intent.setClass(this, ChatActivity.class);
                        startActivity(intent);
                    }
                }
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {

			if (ShareDialog.getInstance().isShowing()) {
				ShareDialog.getInstance().dismiss();
				return true;
			}

			targetActivity();
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_MENU) {
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	private Class<? extends Object> getClassName(String type) {
		if (type.equals("1")) {
			return PlayVideoActivity.class;
		} else if (type.equals("0")) {
			return WebVideoActivity.class;
		}
		return null;
	}

	class TencentNewsScriptInterface {

		Context mContext;

		/** Instantiate the interface and set the context */
		public TencentNewsScriptInterface(Context context) {
			mContext = context;
		}

		public void zoomImage(final String url, final String imgIndex) {
			if (!url.equals("file:///android_asset/default_img.png")) {
				Intent intent = new Intent();
				intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				intent.setClass(mContext, DetailPreViewActivity.class);
				intent.putStringArrayListExtra(Constants.PREVIEW_IMAGE_KEY, imgUrlList);
				intent.putExtra("index", Integer.parseInt(imgIndex));
				((Activity) mContext).startActivityForResult(intent, Constants.RQ_WATICH_IMAGE);
			}
		}
		
		public void setFristRssMedia() {
		    SpConfig.setFristRssMedia(true);
		}

		public void playVideo(final String currVid, final String currVType, final String currVUrl) {
			if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_INAVAILABLE) {
				TipsToast.getInstance().showTipsError(getString(R.string.string_http_data_nonet));
				return;
			}
			if (currVType.equals("1") && mWebView != null && mWebView.getPlayMode() != null) {
				Intent intent = new Intent();
				intent.setClass(mContext, getClassName(mWebView.getPlayMode()));
				intent.putExtra("playurl", mWebView.getPlayUrl());
				intent.putExtra(Constants.PLAY_VIDEO_VID_KEY, currVid);
				intent.putExtra(Constants.NEWS_DETAIL_KEY, mItem);
				intent.putExtra(Constants.NEWS_CHANNEL_CHLID_KEY, mChild);
				mContext.startActivity(intent);
			} else {
				Intent intent = new Intent();
				intent.setClass(mContext, LiveVideoActivity.class);
				intent.putExtra(Constants.LIVE_PLAY_URL, currVUrl);
				intent.putExtra(Constants.NEWS_DETAIL_KEY, mItem);
				intent.putExtra(Constants.PLAY_VIDEO_VID_KEY, mWebView.getProgId());
				intent.putExtra(Constants.NEWS_CHANNEL_CHLID_KEY, mChild);
				mContext.startActivity(intent);
			}
		}

		public void imageNeedsPrepare(String imgIndex) {
			if (imgUrlList != null && imgUrlList.size() > 0) {
				String image = imgUrlList.get(Integer.parseInt(imgIndex));
				getImageRequest(image);
				SLog.e("imageNeedsPrepare", "imgIndex" + imgIndex);
			}
		}

		public void showVideoImage() {
			if (mVideoImgUrl != null) {
				getImageRequest(mVideoImgUrl);
			}
		}

		public void submitVoteData(String a) {
			try {
				HttpDataRequest request = TencentNews.getInstance().reportInputVote(a);
				TaskManager.startHttpDataRequset(request, AbsNewsActivity.this);

			} catch (JSONException e) {
				e.printStackTrace();
			}
		}

		public void retryVoteData() {
			getVoteInfo();
		}
	}

	class NativeStorageInterface {
		Context mContext;

		public NativeStorageInterface(Context context) {
			mContext = context;
		}

		public void set(String name, String value) {
			if (name != null && value != null) {
				SpTopicHadVoted.saveVoteOptid(name, value);
			}
		}

		public String get(String name) {
			String str = null;
			if (name != null) {
				str = SpTopicHadVoted.getVoteOptid(name);
			}
			SLog.i("NativeStorageInterface", "&&" + str);
			return str;
		}

		public void clear(String name) {
			if (name != null) {
				SpTopicHadVoted.delVoteOptid(name);
			} else {
				SpTopicHadVoted.delVoteOptidAll();
			}
		}
	}

	public class MyOnPageChangeListener implements OnPageChangeListener {

		@Override
		public void onPageScrollStateChanged(int arg0) {

		}

		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {

		}

		@Override
		public void onPageSelected(int arg0) {
			nCurrentPage = arg0;
			mWritingCommentView.setDCPage(nCurrentPage);
			mWritingCommentView.refreshUI();

		}

	}

	@Override
	public void applyTheme() {
		if(mTitleBar != null){
			mTitleBar.applyTitleBarTheme(this);
		}
		
		if(mCommentView != null){
			mCommentView.applyTheme();
		}
		if(mNewsDetailView != null) {
			mNewsDetailView.applyTheme();
		}
		themeSettingsHelper.setViewBackgroudColor(this, mMask, R.color.mask_page_color);
		themeSettingsHelper.setViewBackgroudColor(this, mViewPager, R.color.viewpage_bg_color);
		themeSettingsHelper.setViewPagerMargin(this, mViewPager, R.drawable.viewpager_margin_color);
	}

	abstract protected void setSourceType();

	abstract protected void retryData();

	abstract protected void targetActivity();

	abstract protected void getData();

	abstract protected boolean isInitComments();

	abstract protected void registerBroadReceiver();

	abstract protected void getIntentData(Intent intent);
	
	abstract protected String iAmWhich();

	abstract protected Properties getPts();
	
 }