package com.tencent.news.ui.fragment;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.boss.EventId;
import com.tencent.news.cache.NewsMsgGroupCache;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.model.pojo.NewsMsg;
import com.tencent.news.model.pojo.NewsMsgGroup;
import com.tencent.news.system.NetStatusReceiver;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.ChatActivity;
import com.tencent.news.ui.adapter.PersonalMsgAdapter;
import com.tencent.news.ui.adapter.PersonalMsgAdapter.MsgViewHolder;
import com.tencent.news.ui.view.PullToRefreshFrameLayout;
import com.tencent.news.ui.view.PullRefreshListView.OnClickFootViewListener;
import com.tencent.news.ui.view.PullRefreshListView.OnRefreshListener;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.ThemeSettingsHelper;
import com.tencent.omg.webdev.WebDev;

/**
 * @author haiyandu
 * @since 2013-6-21
 */
public class PersonalFragment extends BaseFragment {
    private final static String TAG = PersonalFragment.class.getSimpleName();
    private final static String LIST_TAG = "Personal";
    private static final int GET_NEWS_MSG_GROUP_FROM_CACHE = 0X1000;
    private static final int GET_NEWS_MSG_GROUP_FROM_NET = 0X100;
    private final static long DELAY_TIME = 60 * 1000L;
    private PersonalMsgAdapter mAdapter;
    private String mLastTime = "0";
    private UpdateMsgReceiver mUpdateMsgReceiver;

    private NewsMsgGroupCache newsMsgGroupCache;
    private NewsMsgGroup mNewsMsgGroup;

    private Boolean mEditable = false;
    private Boolean mDeleted = true;
    private List<Boolean> isSelectedList;
    
    private View mRootView;
    
    LinearLayout cancel_news_group_Layout = null;
    private Button btnDelNewsGroup = null;
    private int mMsgNotReading = 0;
    
    private String mLoginUserUin = null;
    
    public static PersonalFragment newInstance(Boolean editable) {
        PersonalFragment f = new PersonalFragment();
        f.mEditable = editable;
        
        
        return f;
    }
    
    private Handler mHandler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg != null) {
                switch (msg.what) {
                    case GET_NEWS_MSG_GROUP_FROM_CACHE:
                        if (mNewsMsgGroup != null && mNewsMsgGroup.getData().size() > 0) { 
                            mAdapter.addDataList(mNewsMsgGroup.getData());
                            mAdapter.notifyDataSetChanged();
                            mListView.onRefreshComplete(true);
                            mFramelayout.showState(Constants.LIST);
                            mListView.setFootViewAddMore(true, "0".equals(mNewsMsgGroup.getAnymore()) == false, false);
                        }
                        
                        break;
                    case GET_NEWS_MSG_GROUP_FROM_NET:
                        
                        getNewsMsg("0");
                        break;
                    default:
                        break;
                }
            }
        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mRootView = inflater.inflate(R.layout.personal_fragment_layout, container, false);
        cancel_news_group_Layout = (LinearLayout) mRootView.findViewById(R.id.delete_bar);
        
        btnDelNewsGroup = (Button) mRootView.findViewById(R.id.btn_delete);
        mFramelayout = (PullToRefreshFrameLayout) mRootView.findViewById(R.id.important_list_content);
        mFramelayout.showState(Constants.LOADING);
        mListView = mFramelayout.getPullToRefreshListView();
        
        applyTheme();
        return mRootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mAdapter = new PersonalMsgAdapter(getActivity(), mListView);
        mListView.setAdapter(mAdapter);
        mListView.setPullTimeTag(LIST_TAG);

        setFragmentEditFlag(mEditable);
        
        getNewsMsgGroup();

        initListener();
        registerUpdateReceiver();
    }

    public void getUserUinInfo() {
        SettingInfo settingData = SettingObservable.getInstance().getData();
        if (settingData != null && settingData.getUserInfo() != null) {
            mLoginUserUin = settingData.getUserInfo().getUin();
        } else {
            mLoginUserUin = null;
        }
    }
    
    public void getNewsMsgGroup() {
        TaskManager.startRunnableRequest(new Runnable() {
            @Override
            public void run() {
                
                getUserUinInfo();
                
                if (mLoginUserUin != null) {
                    newsMsgGroupCache = new NewsMsgGroupCache("newsMsgGroupList" + mLoginUserUin);
                    mNewsMsgGroup = newsMsgGroupCache.getCacheData();
                    
                    mHandler.sendEmptyMessage(GET_NEWS_MSG_GROUP_FROM_CACHE);
                }
                
                getNewsMsg("0");
            }
        });
    }
    
    private void registerUpdateReceiver() {
        mUpdateMsgReceiver = new UpdateMsgReceiver();
        IntentFilter filter = new IntentFilter(Constants.REFRESH_MSG_LIST);
        getActivity().registerReceiver(mUpdateMsgReceiver, filter);
    }

    private void initListener() {
        mListView.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh() {
                getNewsMsg("0");
            }

        });

        mListView.setOnClickFootViewListener(new OnClickFootViewListener() {

            @Override
            public void onClickFootView() {
                getNewsMsg(mLastTime);
            }

        });

        mListView.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int nClickPosition = position - mListView.getHeaderViewsCount();
                if (mAdapter != null && nClickPosition >= 0 && nClickPosition < mAdapter.getCount()) {
                    
                    if (mEditable == true) {
                        doItemChecked(view, nClickPosition);
                    } else {
                        NewsMsg msg = mAdapter.getObjectItem(nClickPosition);
                        
                        Intent intent = new Intent();

                        intent.putExtra("uin", msg.getUin());
                        intent.putExtra("nick", msg.getNick());
                        intent.putExtra("mediaHeadUrl", msg.getHead());
                        intent.putExtra("newCount", Integer.parseInt(msg.getNewCount()));

                        intent.setClass(getActivity(), ChatActivity.class);
                        
                        msg.setNewCount("0");
                        mAdapter.notifyDataSetChanged();
                        
                        startActivity(intent);
                    }
                }
            }
        });

        mFramelayout.setRetryButtonClickedListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                OnRetryData();
            }

        });
        
        btnDelNewsGroup.setOnClickListener(new View.OnClickListener() {
            
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                
                if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_INAVAILABLE) {
                    TipsToast.getInstance().showTipsSuccess("网络连接失败，无法删除！");
                    return;
                }

                List<String> uinList = new ArrayList<String>();
                List<NewsMsg> msgList = mNewsMsgGroup.getData();

                for (int i = 0; i < isSelectedList.size(); ) {
                    if (isSelectedList.get(i) == true) {
                        String uin = msgList.get(i).getUin();
                        uinList.add(uin);
                        
                        if (msgList.get(i).getNewCount() != null) {
                        	int count = Integer.parseInt(msgList.get(i).getNewCount());
                        	sendMsgReadedBroadCast(count);
                        }
                        
                        mAdapter.deleteItemObject(i);
                        msgList.remove(i);
                        
                        removeChatMsgCache(uin);
                        
                        isSelectedList.remove(i);
                    } else {
                        i++;
                    }
                }
                
                changeFragmentEditFlag();
                
                if (uinList.size() > 0) {
                    delNewsMsg(uinList);
                    
                    newsMsgGroupCache.setCacheData(mNewsMsgGroup);
                }
            }
        });
    }
    
    private void removeChatMsgCache(String mUin) {
        if (mUin != null && mLoginUserUin != null) {
            File cacheFile = new File(Constants.CACHE_NEWS_MSG_PATH + mUin + "." + mLoginUserUin);
            if (cacheFile.isFile() && cacheFile.exists()) {
                cacheFile.delete();
            }
        }
    }
    
    private void sendMsgReadedBroadCast(int count) {
    	if (count > 0) {
            Intent i = new Intent();
            i.setAction(Constants.UPDATE_MAIL_AND_AT_COUNT);
            i.putExtra("mailCount", count);
            i.putExtra("action", "readed");
            getActivity().sendBroadcast(i);
        }
    }
    
    private void doItemChecked(View view, int nClickPosition) {

        MsgViewHolder holder = (MsgViewHolder) view.getTag();
        
        Boolean isSelected = isSelectedList.get(nClickPosition);
        isSelectedList.set(nClickPosition, !isSelected);
        
        mAdapter.showCheckBox(view, holder.checkIcon, nClickPosition);
    }
    
    protected void OnRetryData() {
        mFramelayout.showState(Constants.LOADING);
        getNewsMsg("0");
    }

    private void getNewsMsg(String time) {
        
//      WebDev.trackCustomBeginKVEven(getActivity(), EventId.ITIL_LOAD_MSG_COMMENT_BOOK_TIME);
        
        HttpDataRequest request = TencentNews.getInstance().getSubNewsMsgGroup(time);
        TaskManager.startHttpDataRequset(request, this);
    }

    private void delNewsMsg(List<String> uinList) {
        if (mDeleted == true) {
            mDeleted = false; // ��ֹδɾ��ɹ���ˢ����Ϣ�����
            HttpDataRequest request = TencentNews.getInstance().delSubNewsMsgGroup(uinList);
            TaskManager.startHttpDataRequset(request, this);
        }
    }

    private NewsMsg getNewsMsgItem(int index) {
        if (mAdapter != null) {
            List<NewsMsg> groupList = mAdapter.getDataList();
            if (groupList != null && index >= 0 && index < groupList.size())
                return groupList.get(index);
        }
        return null;
    }

    private String getGroupLastTime(NewsMsgGroup msg) {
        String time = null;
        if (msg != null) {
            List<NewsMsg> group = msg.getData();
            if (group != null && group.size() > 0) {
                NewsMsg news = group.get(group.size() - 1);
                time = news.getTime();
            }
        }
        return time;
    }
    
    private void refreshMsgNotReading() {
        
        mMsgNotReading = 0;
        List<NewsMsg> msgList = null;
        
        if (mNewsMsgGroup != null) {
            msgList = mNewsMsgGroup.getData();
        }
        
        if (msgList != null) {
            for (int i = 0; i < msgList.size(); i++) {
                String count = msgList.get(i).getNewCount();
                if (count != null && count.length() > 0) {
                    int k = Integer.parseInt(count);
                    if (k > 0) {
                        mMsgNotReading += k;
                    }
                }
            }
        }
        
        if (mMsgNotReading > 0) {
            sendRefreshMailCountBroadCast();
        }
    }

    private void sendRefreshMailCountBroadCast() {
        Intent intent = new Intent();
        intent.setAction(Constants.UPDATE_MAIL_AND_AT_COUNT);
        intent.putExtra("mailCount", mMsgNotReading);
        intent.putExtra("action", "update");
        
        if (getActivity() != null) {
            getActivity().sendBroadcast(intent);
        }
    }
    
    @Override
    public void onDestroyView() {
        if (mUpdateMsgReceiver != null) {
            getActivity().unregisterReceiver(mUpdateMsgReceiver);
            mUpdateMsgReceiver = null;
        }
        
        if (mHandler != null) {
            mHandler.removeMessages(GET_NEWS_MSG_GROUP_FROM_NET);
        }
        
        super.onDestroyView();
    }

    @Override
    public void onHttpRecvOK(HttpTag tag, Object result) {
        // TODO Auto-generated method stub
        NewsMsgGroup msg = null;
        
        if (tag.equals(HttpTag.DEL_SUBNEWS_GROUP)) {
            mDeleted = true;
            
            if ("0".equals((String) result)) {
                
                TipsToast.getInstance().showTipsSuccess("删除成功！");
            } else {
                TipsToast.getInstance().showTipsError("删除失败！");
            }
        } else if (tag.equals(HttpTag.SUB_NEWS_MSGGROUP)) {
            
            // �༭̬��ɾ��δ�ɹ������������������ˢ���б�
            if (mEditable == true || mDeleted == false) {
                mHandler.sendEmptyMessageDelayed(GET_NEWS_MSG_GROUP_FROM_NET, DELAY_TIME);
                return;
            }
            
            if ((msg = (NewsMsgGroup) result) != null) {
//                Log.i("bush", "msg not null");
                if ("0".equals(msg.getRet())) {
//                    Log.i("bush", "ret == 0");
                    if (msg.getData() != null) {
//                        Log.i("bush", "data not null");
                        mAdapter.addDataList(msg.getData());
                        mAdapter.notifyDataSetChanged();
                        mListView.onRefreshComplete(true);
                        mFramelayout.showState(Constants.LIST);
                        mListView.setFootViewAddMore(true, "0".equals(msg.getAnymore()) == false, false);
                        
                        newsMsgGroupCache.setCacheData(msg);
                        mNewsMsgGroup = msg;
                        
                        refreshMsgNotReading();
                        
                        mHandler.sendEmptyMessageDelayed(GET_NEWS_MSG_GROUP_FROM_NET, DELAY_TIME);
                    } else {
//                        Log.i("bush", "data null");
                        mFramelayout.showState(Constants.EMPTY);
                    }
                    
                } else {
//                    Log.i("bush", "ret not 0");
                    mFramelayout.showState(Constants.EMPTY);
                }
            } else {
//                Log.i("bush", "msg null");
                mFramelayout.showState(Constants.ERROR);
            }
        } 
        
        if (msg != null && msg.getAnymore() != null && msg.getAnymore().equals("0")) {
            mListView.setFootViewAddMore(true, false, false);
        } else {
            mListView.setFootViewAddMore(true, true, false);
        }
    }

    @Override
    public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {
        // TODO Auto-generated method stub
        if (tag.equals(HttpTag.SUB_NEWS_MSGGROUP)) {
            
            if (mAdapter.getCount() > 0) {
                Log.i("bush", "get group error: has data");
                mFramelayout.showState(Constants.LIST);
                mListView.onRefreshComplete(false);
                mListView.setFootViewAddMore(false, true, true);
            } else {
                Log.i("bush", "get group error: has no data");
                mFramelayout.showState(Constants.ERROR);
            }
        } else if (tag.equals(HttpTag.DEL_SUBNEWS_GROUP)) {
            TipsToast.getInstance().showTipsError("删除失败！");
        }
    }

    @Override
    public void onHttpRecvCancelled(HttpTag tag) {
        // TODO Auto-generated method stub

    }

    private class UpdateMsgReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(Constants.REFRESH_MSG_LIST)) {
                SLog.v(TAG,
                        intent.getStringExtra("content")
                                + intent.getIntExtra(Constants.NEWS_CLICK_ITEM_UIN, -1));
                String uin = intent.getStringExtra(Constants.NEWS_CLICK_ITEM_UIN);
                if (uin != null && uin.length() > 0) {
                    String content = intent.getStringExtra("content");
                    String time = intent.getStringExtra("time");
                    if (content != null && content.length() > 0 && time != null && time.length() > 0) {
                        List<NewsMsg> msgList = mNewsMsgGroup.getData();
                        for (int i = 0; i < msgList.size(); i++) {
                            NewsMsg msg = msgList.get(i);
                            if (msg.getUin().equals(uin)) {
                                msg.setMsg(content);
                                msg.setTime(time);
                                mAdapter.notifyDataSetChanged();
                                newsMsgGroupCache.setCacheData(mNewsMsgGroup);
                                break;
                            }
                        }
                    }
                }
            }
        }
    }
    
    public void setFragmentEditFlag(Boolean editable) {
        
        this.mEditable = editable;
        
        if (editable == false) {
            if (cancel_news_group_Layout != null) {
                cancel_news_group_Layout.setVisibility(View.GONE);
            }
            if (isSelectedList != null) {
                isSelectedList.clear();
                isSelectedList = null;
            }
        } else {
            if (cancel_news_group_Layout != null) {
                cancel_news_group_Layout.setVisibility(View.VISIBLE);
            }
            if (mAdapter != null) {
                mAdapter.initSelectedState();
            }
            isSelectedList = mAdapter.getIsSelected();
        }
       
        mAdapter.setShowCheckBox(editable);
        
        applyTheme();
    }
    
    public void changeFragmentEditFlag() {
        if (mEditable == true) {
            mEditable = false;
        } else {
            mEditable = true;
        }
        
        setFragmentEditFlag(mEditable);
        sendEditStatusBroadCast(mEditable);
    }
    
    private void sendEditStatusBroadCast(Boolean editable) {
        Intent intent = new Intent();
        intent.setAction(Constants.UPDATE_MSGGROUP_EDIT_STATUS);
        intent.putExtra("editable", editable);
        getActivity().sendBroadcast(intent);
    }
    
    public void applyTheme() {
        mFramelayout.applyFrameLayoutTheme();
        mListView.applyPullRefreshViewTheme();
       
        ThemeSettingsHelper themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(getActivity());
        themeSettingsHelper.setViewBackgroudColor(getActivity(), this.mListView, R.color.timeline_home_bg_color);
        themeSettingsHelper.setListViewSelector(getActivity(), this.mListView, R.drawable.list_selector);
        themeSettingsHelper.setListViewDivider(getActivity(), mListView, R.drawable.list_divider_line);
    }
}
