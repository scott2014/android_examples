package com.tencent.news.ui.adapter;

import java.util.ArrayList;
import java.util.List;

import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;

public class ViewPagerAdapter extends PagerAdapter {

	public List<View> mListViews;
	private boolean mIsOnLandscape = false; 
	private boolean mHasRecommendView = false; 
	private boolean mShowRecomendView = false;
	
	private boolean mSpecialInit = false;  // true: mView0 ~ 2 可用
	private View mView0;
	private View mView1;
	private View mView2;
	
	public ViewPagerAdapter(List<View> listViews) {
		setViews(listViews);
	}
	
	public void setViews(List<View> listViews) {
		clearAdapterView();
		if (listViews != null && listViews.size() == 3) {
			mSpecialInit = true;
			mHasRecommendView = true;
			mView0 = listViews.get(0);
			mView1 = listViews.get(1);
			mView2 = listViews.get(2);
			this.mListViews = new ArrayList<View>();
			this.mListViews.add(mView0);
			this.mListViews.add(mView2);
		} else if (listViews != null && listViews.size() == 2) {
			mSpecialInit = true;
			mHasRecommendView = false;
			mView0 = listViews.get(0);
			mView2 = listViews.get(1);
			this.mListViews = new ArrayList<View>();
			setupViews();
		} else {
			mHasRecommendView = false;
			this.mListViews = listViews;
		}
	}

	@Override
	public void destroyItem(View arg0, int arg1, Object arg2) {
		((ViewPager) arg0).removeView((View)arg2);
	}

	@Override
	public void finishUpdate(View arg0) {
	}

	@Override
	public int getCount() {
		return mListViews.size();
	}
	
	@Override
	public Object instantiateItem(View arg0, int arg1) {
		((ViewPager) arg0).addView(mListViews.get(arg1), 0);
		return mListViews.get(arg1);
	}

	@Override
	public boolean isViewFromObject(View arg0, Object arg1) {
		return arg0 == (arg1);
	}

	@Override
	public void restoreState(Parcelable arg0, ClassLoader arg1) {
	}

	@Override
	public Parcelable saveState() {
		return null;
	}

	public void clearAdapterView() {
		mView0 = null;
		mView1 = null;
		mView2 = null;
		if (mListViews != null) {
			mListViews.clear();
			mListViews = null;
		}
	}
	
	@Override
	public int getItemPosition(Object object) {
		if (!mHasRecommendView) {
			return POSITION_NONE;
		}
		
		int index = 0;
		for (; index < mListViews.size(); index++) {
			if (object.equals(mListViews.get(index))) {
				break;
			}
		}
		if (!mShowRecomendView && mListViews.size() == 3 && index == 2) {
			index = 1;
		}
		return index;
	}
	
	public boolean setShowRecomendView(boolean showRecomendView) {
		boolean changed = false;
		if (mHasRecommendView && this.mShowRecomendView != showRecomendView) {
			this.mShowRecomendView = showRecomendView;
			mListViews.clear();
			mListViews.add(mView0);
			if (mShowRecomendView) {
				mListViews.add(mView1);
			}
			if (!mIsOnLandscape) {
				mListViews.add(mView2);
			}
			changed = true;
		}
		return changed;
	}
	
	public boolean setOnLandscape(boolean isLandscape) {
		if (!mSpecialInit) {
			return false;
		}
		if (mIsOnLandscape != isLandscape) {
			mIsOnLandscape = isLandscape;
			setupViews();
			return true;
		}
		return false;
	}
	
	private void setupViews() {
		mListViews.clear();
		mListViews.add(mView0);

		if (mHasRecommendView && mShowRecomendView) {
			mListViews.add(mView1);
		}
		if (!mIsOnLandscape) {
			mListViews.add(mView2);
		}
	}
}
