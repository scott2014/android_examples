package com.tencent.news.ui.fragment;

import com.tencent.news.command.HttpDataResponse;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.ui.view.PullRefreshListView;
import com.tencent.news.ui.view.PullToRefreshFrameLayout;

import android.os.Bundle;
import android.support.v4.app.Fragment;

public class BaseFragment extends Fragment implements HttpDataResponse{
	protected PullToRefreshFrameLayout mFramelayout;
	protected PullRefreshListView mListView;
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
	
	@Override
	public void onHttpRecvOK(HttpTag tag, Object result) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void onHttpRecvCancelled(HttpTag tag) {
		// TODO Auto-generated method stub
		
	}
}
