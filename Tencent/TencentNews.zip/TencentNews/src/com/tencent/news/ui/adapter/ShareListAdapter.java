package com.tencent.news.ui.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.model.pojo.Share;

public class ShareListAdapter extends BaseAdapter {

	ArrayList<Share> appList;
	Context mContext;
	GridView gridView;

	public void setAppList(ArrayList<Share> appList) {
		this.appList = appList;
	}

	public ShareListAdapter(Context mContext, GridView gridView) {
		this.mContext = mContext;
		this.gridView = gridView;
	}

	@Override
	public int getCount() {
		return appList == null ? 0 : appList.size();
	}

	@Override
	public Object getItem(int position) {
		return appList == null ? null : appList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder = null;
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = LayoutInflater.from(mContext).inflate(R.layout.view_share_list_item, null);

			holder.app_icon = (ImageButton) convertView.findViewById(R.id.share_app_icon);
			holder.app_name = (TextView) convertView.findViewById(R.id.share_app_name);

			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		Share app = appList == null ? null : appList.get(position);

		if (app != null) {
			doDiffirence(app, holder);
		}

		return convertView;
	}

	private void doDiffirence(Share app, ViewHolder holder) {
		holder.app_icon.setBackgroundResource(app.getLogo());
		holder.app_name.setText(app.getShareName());
	}

	protected static class ViewHolder {
//		String id;
		ImageButton app_icon;
		TextView app_name;
	}

}
