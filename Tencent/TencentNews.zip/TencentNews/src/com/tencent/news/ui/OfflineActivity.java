package com.tencent.news.ui;

import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.ExpandableListView.OnGroupClickListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.anim.ResizeHeightAnimation;
import com.tencent.news.api.TencentNews;
import com.tencent.news.boss.EventId;
import com.tencent.news.cache.RssChannelSyncHelper;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.download.DownloadConstants;
import com.tencent.news.download.DownloadManager;
import com.tencent.news.download.OffLineDownloadListener;
import com.tencent.news.download.OffLineDownloadManagerNew;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.pojo.Channel;
import com.tencent.news.model.pojo.ChannelList;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.model.pojo.ListMapData;
import com.tencent.news.model.pojo.OfflineChannel;
import com.tencent.news.model.pojo.OfflinePreview;
import com.tencent.news.shareprefrence.SpConfig;
import com.tencent.news.shareprefrence.SpOffline;
import com.tencent.news.shareprefrence.SpOfflineOneChannelTime;
import com.tencent.news.shareprefrence.SpOfflineProgress;
import com.tencent.news.system.Application;
import com.tencent.news.system.NetStatusReceiver;
import com.tencent.news.system.OfflineNewsHadReadReceiver;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.adapter.OfflineAdapter;
import com.tencent.news.ui.view.IphoneTreeView;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.news.utils.DispatchClassUtil;
import com.tencent.news.utils.DownloaderStateCallBack;
import com.tencent.news.utils.FileUtil;
import com.tencent.news.utils.InfoConfigUtil;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.TempManager;
import com.tencent.omg.webdev.WebDev;

public class OfflineActivity extends BaseActivity implements OffLineDownloadListener, OnClickListener {

	private static final String TAG = "ol";

	private static final int READ_DOWNLOADED_DATA_FROM_LOCAL = 0x2;
	private static final int FINISH_ALL_OFFLINE = 0x3;
	private static final int REFRESH_PROGRESS_OFFLINE = 0x4;
	private static final int IF_DOWNLOAD_23G = 0x5;
	private static final int TIPSBIG = 0x6;
	private static final int TIPSSMALL = 0x7;
	public static final long AUTO_UPDATE_OFFLINE = 2 * 60 * 60 * 1000L;
	private static final long MANUAL_UPDATE_OFFLINE = 30 * 60 * 1000L;

	static Dialog dlg;
	TextView download_how_many;
	TextView download_how_many_unit;
	TextView downloadTips;
	TextView progressInit;
	TextView progressfinishsoon;
	ImageView network_status;
	LinearLayout downloadingWhat;
	TextView download_channle_name;
	TextView download_current;
	TextView download_all;
	ProgressBar progressBar;

	View mMask;
	ImageView noData;
	RelativeLayout offline_title;
	Button offline_title_btn_back;
	Button cancel_download;
	ImageButton btnStartDownload;

	OfflineChannel[] mOfflineChannels = null;
	List<OfflineChannel> mNeedDownload = null;

	IphoneTreeView downloadedDataListView;
	OfflineAdapter mOfflineAdapter;
	List<Channel> lcs;
	List<OfflinePreview> downloadedData = new ArrayList<OfflinePreview>();

	boolean beBackground = false;

	/**
	 * 是不是自动离线下载的,用来比较时间
	 */
	boolean isAutoDownload = false;

	boolean startDownCanBeClick = true;
	boolean hadCancel = false;
	boolean hideIng = false;

	float listView_downY = 0f;
	float listView_upY = 0f;

	NetStatusReceiver netReceiver;
	OfflineNewsHadReadReceiver mReceiver;
	long allTime;

	Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			if (msg != null) {

				switch (msg.what) {
				case TIPSBIG:
					downloadTips.startAnimation(mResizeHeightBigAnimation);
					break;
				case TIPSSMALL:
					Log.i("ol", "开始变小的动画");
					downloadTips.startAnimation(mResizeHeightSmallAnimation);
					break;
				case READ_DOWNLOADED_DATA_FROM_LOCAL:

					if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_WIFI) {
						if (downloadedData.size() <= 0) {
							autoDownLoad();
						} else {
							if (Math.abs(SpOffline.getUpdataAllTime() - System.currentTimeMillis()) > AUTO_UPDATE_OFFLINE) {
								autoDownLoad();
							}
						}
					}

					int size = downloadedData.size();
					SLog.i(TAG, "加载完本地有的之后" + size + "   adpater" + mOfflineAdapter.getGroupCount());
					if (size > 0) {
						noData.setVisibility(View.GONE);
						if (mOfflineAdapter != null) {
							mOfflineAdapter.setDownloadedData(downloadedData);
							mOfflineAdapter.notifyDataSetChanged();
						}
						for (int i = 0; i < size; i++) {
							downloadedDataListView.expandGroup(i);
						}
					} else {
						noData.setVisibility(View.VISIBLE);
					}

					break;
				case FINISH_ALL_OFFLINE:

					if (beBackground) {
						OffLineDownloadManagerNew.getInstance().stopNotification();
					}

					downloadedData = OffLineDownloadManagerNew.getInstance().getDownloadedData();

					if (mOfflineAdapter != null) {
						orderByLcs();
						mOfflineAdapter.setDownloadedData(downloadedData);
						mOfflineAdapter.notifyDataSetChanged();
					}

					int size3 = downloadedData.size();
					SLog.i(TAG, "FINISH_ALL_OFFLINE--->" + size3 + "分组个数--->" + mOfflineAdapter.getGroupCount());
					if (size3 > 0) {
						noData.setVisibility(View.GONE);
						for (int i = 0; i < size3; i++) {
							downloadedDataListView.expandGroup(i);
						}
					} else {
						noData.setVisibility(View.VISIBLE);
					}

					// startDownCanBeClick = true;
					if (OffLineDownloadManagerNew.getInstance().getState() != DownloadConstants.T_ERROR && OffLineDownloadManagerNew.getInstance().getState() != DownloadConstants.T_PAUSE
							&& downloadedData != null && downloadedData.size() > 0 && mNeedDownload.size() > 0) {
						showFinishTips("下载完成,共下载" + mNeedDownload.size() * 100 + "条新闻");
					}

					SLog.i("olTime", "所有下载耗时" + (System.currentTimeMillis() - allTime) + "ms");
					if (dlg != null && dlg.isShowing()) {
						dlg.dismiss();
					}

					break;
				case REFRESH_PROGRESS_OFFLINE:

					MsgObj obj = (MsgObj) msg.obj;

					if (obj.state == DownloadConstants.T_ERROR) {
						if (request != null) {
							request.setCancelled(true);
						}

						SpOfflineProgress.setChannelProgress(obj.channel, obj.n_progress);

						// Statistics.getInstance().saveStatistics(Statistics.REPORTED_DATA_SHOWING_WHAT,
						// StatisticsUtil.generateCustomField(new String[] {
						// "OFFLINE_ERROR_DOWNLOADER_T_ERROR",
						// System.currentTimeMillis() + "", "", "", "", "", ""
						// }));

						WebDev.trackCustomEvent(OfflineActivity.this, EventId.BOSS_OFFLINE_ERROR_DOWNLOADER_T_ERROR);

						// startDownCanBeClick = true;
						if (isAutoDownload) {
							isAutoDownload = false;
						}
						if (dlg != null && dlg.isShowing()) {
							dlg.dismiss();
						}
						int current = OffLineDownloadManagerNew.getInstance().getmTag();
						if (current > 0) {
							// if (!downloadTips.isShown()) {
							showFinishTips("网络不稳定，下载结束。已下载" + (current * 100) + "条新闻");
							// } else {
							// downloadTips.setText("下载出错,已下载" + (current * 100)
							// + "条新闻");
							// }

							downloadedData = OffLineDownloadManagerNew.getInstance().getDownloadedData();
							int size4 = downloadedData.size();
							if (mOfflineAdapter != null) {
								mOfflineAdapter.setDownloadedData(downloadedData);
								mOfflineAdapter.notifyDataSetChanged();
							}

							SLog.i(TAG, "下载出错--->" + size4 + "分组个数--->" + mOfflineAdapter.getGroupCount());
							if (size4 > 0) {
								noData.setVisibility(View.GONE);
								for (int i = 0; i < size4; i++) {
									downloadedDataListView.expandGroup(i);
								}
							} else {
								noData.setVisibility(View.VISIBLE);
							}

						} else {
							showFinishTips("网络不稳定，下载结束。");
						}
						return;
					}

					if (obj.state == DownloadConstants.T_PAUSE) {
						if (request != null) {
							request.setCancelled(true);
						}
						SpOfflineProgress.setChannelProgress(obj.channel, obj.n_progress);
						startDownCanBeClick = true;
						return;
					}

					if (obj.surplus == 0) {
						progressfinishsoon.setVisibility(View.VISIBLE);
						download_how_many.setVisibility(View.GONE);
						download_how_many_unit.setVisibility(View.GONE);
					} else {
						download_how_many.setText("" + obj.surplus);
						progressfinishsoon.setVisibility(View.GONE);
						download_how_many.setVisibility(View.VISIBLE);
						download_how_many_unit.setVisibility(View.VISIBLE);
					}
					download_channle_name.setText("" + SpConfig.getChannelNameById(obj.channel.getChlid()));
					if (obj.state != DownloadConstants.T_INSTALL) {
						download_current.setText("" + obj.n_progress);
						progressBar.setProgress(obj.n_progress);
					}
					if (obj.n_progress == 100) {

						// OffLineDownloadManagerNew.getInstance().addParseTask(obj.channal.getChlid());
						SpOfflineProgress.setChannelProgress(obj.channel, 0);

						if (obj.surplus == 0) {
							// 交给解析完成来发出完成的通知
							// mHandler.sendEmptyMessage(FINISH_ALL_OFFLINE);

//							Statistics.getInstance().saveStatistics(Statistics.REPORTED_DATA_SHOWING_WHAT,
//									StatisticsUtil.generateCustomField(new String[] { "OFFLINE_DOWNLOAD_ALL_SUCCESS", System.currentTimeMillis() + "", "", "", "", "", "" }));

							WebDev.trackCustomEvent(OfflineActivity.this, EventId.BOSS_OFFLINE_DOWNLOAD_ALL_SUCCESS);
							
						}
					}

					break;
				}
			}
			super.handleMessage(msg);
		}

	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		OffLineDownloadManagerNew.getInstance().addListener(this);

		setContentView(R.layout.activity_offline);

		initView();
		initListener();

		// 得到用户订制的频道信息,该过程完全应该由外界提供!
		lcs = getChannelList().getChannelList();
		if(SpConfig.getRSSGuideAlreadyRun()){
			Channel c = new Channel();
			c.setChlid(Constants.NEWS_SUB_ID);
			c.setChlname(this.getResources().getString(R.string.tencent_rss));
			SpConfig.putChannelIdAndName(c.getChlid(), this.getResources().getString(R.string.tencent_rss));
			lcs.add(c);
		}

		SLog.i(TAG, "onCreat()---到底是在干嘛?--->" + (DownloadConstants.T_UPDATE_PROGRESS == OffLineDownloadManagerNew.getInstance().getState()));

		// if (DownloadConstants.T_UPDATE_PROGRESS ==
		// OffLineDownloadManagerNew.getInstance().getState()) {
		// mNeedDownload =
		// OffLineDownloadManagerNew.getInstance().getNeedDownload();
		// downloadedData =
		// OffLineDownloadManagerNew.getInstance().getDownloadedData();
		// SLog.i(TAG, "onCreat()---正在下载加解压--->" + (downloadedData.size()));
		// if (downloadedData != null && downloadedData.size() > 0) {
		// mOfflineAdapter.setDownloadedData(downloadedData);
		// for (int i = 0, j = downloadedData.size(); i < j; i++) {
		// downloadedDataListView.expandGroup(i);
		// }
		// mOfflineAdapter.notifyDataSetChanged();
		// }
		// } else {
		loadAlreadyDownloadedData();
		// }

		SLog.i("ol", SLog.getTraceInfo() + "==============beBackground=" + beBackground + "state=" + OffLineDownloadManagerNew.getInstance().getState());

		registerBroadcastReceiver();
	}

	private void registerBroadcastReceiver() {
		mReceiver = new OfflineNewsHadReadReceiver(mOfflineAdapter);
		IntentFilter filter = new IntentFilter(Constants.NEWS_HAD_READ_FOR_OFFLINE_ACTION);
		registerReceiver(mReceiver, filter);

		IntentFilter filterNet = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
		netReceiver = new NetStatusReceiver(this, dlg);
		this.registerReceiver(netReceiver, filterNet);
	}

	@Override
	protected void onDestroy() {

		SLog.i("ol", SLog.getTraceInfo() + "==============beBackground=" + beBackground + "state=" + OffLineDownloadManagerNew.getInstance().getState());

		if (mReceiver != null) {
			unregisterReceiver(mReceiver);
			mReceiver = null;
		}
		if (netReceiver != null) {
			unregisterReceiver(netReceiver);
			netReceiver = null;
		}
		if (dlg != null) {
			dlg.hide();
			dlg.cancel();
			dlg.dismiss();
			dlg = null;
		}

		super.onDestroy();
	}

	/**
	 * 加载已经下好的频道预览
	 * 
	 * @author jackiecheng
	 */
	private void loadAlreadyDownloadedData() {

		TaskManager.startRunnableRequest(new Runnable() {

			@Override
			public void run() {

				Object o = FileUtil.readCache(new File(Constants.CACHE_OFFLINE_LIST_PATH));
				if (o != null && o instanceof List<?>) {
					downloadedData = (List<OfflinePreview>) o;
					if (downloadedData != null && downloadedData.size() > 0) {
						OffLineDownloadManagerNew.getInstance().setDownloadedData(downloadedData);
					} else {

					}

				} else {
					if (OffLineDownloadManagerNew.getInstance().getDownloadedData() != null && OffLineDownloadManagerNew.getInstance().getDownloadedData().size() > 0) {
						downloadedData = OffLineDownloadManagerNew.getInstance().getDownloadedData();
					}
				}

				orderByLcs();

				mHandler.sendEmptyMessage(READ_DOWNLOADED_DATA_FROM_LOCAL);
			}
		});
	}

	public ListMapData getListMapData() {
		ListMapData channel = Application.getInstance().getChannelList();
		if (channel == null) {
			channel = InfoConfigUtil.ReadSubChannel();
			if (channel == null) {
				ChannelList channelTemp = TempManager.getManager().getChannelListInfo(OfflineActivity.this);
				if (channelTemp != null && channelTemp.getChannelList() != null && channelTemp.getChannelList().size() > 0) {
					channel = InfoConfigUtil.translate(channelTemp, true);// 只初始化时使用true，其它时候用false
					channel.setVersion(channelTemp.getVersion());
				}
			}
			Application.getInstance().setChannelList(channel);
		}
		return channel;
	}

	public ChannelList getChannelList() {
		ListMapData channelMapData = getListMapData();
		ChannelList channel = InfoConfigUtil.translate(channelMapData, true);
		return channel;
	}

	private String getChannelString() {
		StringBuilder sb = new StringBuilder();
		if (lcs != null && lcs.size() > 0) {
			for (int i = 0, j = lcs.size(); i < j; i++) {
				if (i != 0) {
					sb.append(",");
				}
				String channelName = lcs.get(i).getChlid();
				sb.append(channelName);
				sb.append(":");
				sb.append(SpOffline.getChannelVersion(channelName));
			}
		}
		SLog.v("offline", "" + sb.toString());
		return sb.toString();
	}

	ResizeHeightAnimation mResizeHeightSmallAnimation;
	ResizeHeightAnimation mResizeHeightBigAnimation;

	private void initView() {

		mMask = findViewById(R.id.mask_view);
		offline_title = (RelativeLayout) findViewById(R.id.offline_title);
		offline_title_btn_back = (Button) findViewById(R.id.offline_title_btn_back);
		noData = (ImageView) findViewById(R.id.existData);
		downloadTips = (TextView) findViewById(R.id.downloadTips);
		downloadTips.clearAnimation();
		downloadTips.bringToFront();
		mResizeHeightSmallAnimation = new ResizeHeightAnimation(downloadTips, MobileUtil.dpToPx(40), 1);
		mResizeHeightSmallAnimation.setDuration(600);
		mResizeHeightBigAnimation = new ResizeHeightAnimation(downloadTips, 1, MobileUtil.dpToPx(40));
		mResizeHeightBigAnimation.setDuration(600);
		btnStartDownload = (ImageButton) findViewById(R.id.btnStartDownLoad);
		downloadedDataListView = (IphoneTreeView) findViewById(R.id.downloadedData);
		downloadedDataListView.setFloat(false);
		downloadedDataListView.addHeaderView(new View(this), 0);
		downloadedDataListView.setGroupIndicator(getResources().getDrawable(R.drawable.transparent_pic));
		mOfflineAdapter = new OfflineAdapter(this, downloadedDataListView, downloadedData);
		downloadedDataListView.setAdapter(mOfflineAdapter);

		buildDlg();
	}

	private void prepareDownloadUI() {

		SLog.d("ol", "准备界面");

		progressInit.setVisibility(View.VISIBLE);
		progressfinishsoon.setVisibility(View.GONE);
		download_how_many.setVisibility(View.GONE);
		download_how_many_unit.setVisibility(View.GONE);
		downloadingWhat.setVisibility(View.GONE);
		download_channle_name.setVisibility(View.GONE);
		download_current.setVisibility(View.GONE);
		download_all.setVisibility(View.GONE);
		progressBar.setVisibility(View.GONE);
	}

	private void downloadingUI() {

		SLog.d("ol", "下载界面");

		progressInit.setVisibility(View.GONE);
		progressfinishsoon.setVisibility(View.GONE);
		download_how_many.setVisibility(View.VISIBLE);
		download_how_many_unit.setVisibility(View.VISIBLE);
		downloadingWhat.setVisibility(View.VISIBLE);
		download_channle_name.setVisibility(View.VISIBLE);
		download_current.setVisibility(View.VISIBLE);
		download_all.setVisibility(View.VISIBLE);
		progressBar.setVisibility(View.VISIBLE);
	}

	private void showFinishTips(String str) {

		Log.i("ol", "条正在显示?:" + downloadTips.getHeight());
		downloadTips.setText(str);
		if (downloadTips.getHeight() < 10) {
			mHandler.sendEmptyMessage(TIPSBIG);
		}

	}

	private void hideFinishTips() {
		if (downloadTips.getHeight() > 20) {
			if (!hideIng) {
				hideIng = true;
				mHandler.sendEmptyMessage(TIPSSMALL);
			}
		}

	}

	private void initListener() {

		downloadTips.setOnClickListener(this);
		btnStartDownload.setOnClickListener(this);
		downloadedDataListView.setOnGroupClickListener(new OnGroupClickListener() {
			@Override
			public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
				return true;
			}
		});
		downloadedDataListView.setOnChildClickListener(new OnChildClickListener() {

			@Override
			public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {

				String chl = (String) mOfflineAdapter.getGroup(groupPosition);
				Item item = (Item) mOfflineAdapter.getChild(groupPosition, childPosition);
				Intent intent = new Intent();
				Bundle bundle = new Bundle();
				bundle.putString(Constants.NEWS_CHANNEL_CHLID_KEY, chl);
				if ("READ_MORE_OFF_LINE".equalsIgnoreCase(item.getId())) {
					intent.setClass(OfflineActivity.this, OfflineChannelListActivity.class);
				} else {
					bundle.putSerializable(Constants.NEWS_DETAIL_KEY, item);
					bundle.putString(Constants.NEWS_DETAIL_TITLE_KEY, "腾讯新闻");
					bundle.putBoolean(Constants.NEWS_DETAIL_FROM_OFFLINE_KEY, true);
					bundle.putString(Constants.NEWS_CLICK_ITEM_POSITION, "" + (groupPosition * 5 + childPosition + 1));
					intent.setClass(OfflineActivity.this, DispatchClassUtil.getClassName(item.getArticletype()));
				}
				intent.putExtras(bundle);
				startActivity(intent);

				return false;
			}
		});

		downloadedDataListView.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {

				float y = event.getY();
				if (event.getAction() == MotionEvent.ACTION_DOWN) {
					listView_downY = y;
				} else if (event.getAction() == MotionEvent.ACTION_UP) {
					listView_upY = y;
					if (Math.abs(listView_downY - listView_upY) > 20) {
						// if (/* downloadTips.isShown() &&
						// */DownloadConstants.T_UPDATE_PROGRESS !=
						// OffLineDownloadManagerNew.getInstance().getState()) {
						hideFinishTips();
						// }
					}
				}

				return false;
			}
		});

		mResizeHeightBigAnimation.setAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {
				downloadTips.setVisibility(View.VISIBLE);
			}

			@Override
			public void onAnimationRepeat(Animation animation) {

			}

			@Override
			public void onAnimationEnd(Animation animation) {

			}
		});

		mResizeHeightSmallAnimation.setAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {

			}

			@Override
			public void onAnimationRepeat(Animation animation) {

			}

			@Override
			public void onAnimationEnd(Animation animation) {
				Log.i("ol", "变小完毕");
				hideIng = false;
				downloadTips.setVisibility(View.INVISIBLE);
			}
		});
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {

		case R.id.activity_offline_title_str:
		case R.id.activity_offline_title_btn_click:
			if (downloadedData != null && downloadedData.size() > 0) {
				downloadedDataListView.setSelection(0);
			}
			break;

		case R.id.offline_title_btn_back:
			Intent intent = new Intent();
			intent.setClass(OfflineActivity.this, MainActivity.class);
			intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(intent);
			quitActivity();
			break;

		case R.id.cancel_download:

			SLog.e("ol", "==================取消了下载任务=================");

			// Statistics.getInstance().saveStatistics(Statistics.REPORTED_DATA_SHOWING_WHAT,
			// StatisticsUtil.generateCustomField(new String[] {
			// "OFFLINE_CLICK_CANCEL_DOWNLOAD_BTN", System.currentTimeMillis() +
			// "", "", "", "", "", "" }));

			WebDev.trackCustomEvent(OfflineActivity.this, EventId.BOSS_OFFLINE_CLICK_CANCEL_DOWNLOAD_BTN);

			if (dlg != null && dlg.isShowing()) {
				dlg.dismiss();
			}

			if (mNeedDownload != null) {
				mNeedDownload.clear();
			}
			hadCancel = true;

			if (request != null) {
				request.setCancelled(true);
			}
			if (isAutoDownload) {
				isAutoDownload = false;
			}

			OffLineDownloadManagerNew.getInstance().stopDownloadTask();
			SLog.i("ol", SLog.getTraceInfo() + "==============beBackground=" + beBackground + "state=" + OffLineDownloadManagerNew.getInstance().getState());
			if (beBackground) {
				OffLineDownloadManagerNew.getInstance().stopNotification();
			}

			// 取消之后刷一下列表

			downloadedData = OffLineDownloadManagerNew.getInstance().getDownloadedData();
			if (mOfflineAdapter != null) {
				orderByLcs();
				mOfflineAdapter.setDownloadedData(downloadedData);
				mOfflineAdapter.notifyDataSetChanged();
			}

			int size3 = downloadedData.size();
			SLog.i(TAG, "cancel_download--->" + size3 + "分组个数--->" + mOfflineAdapter.getGroupCount());
			if (size3 > 0) {
				noData.setVisibility(View.GONE);
				for (int i = 0; i < size3; i++) {
					downloadedDataListView.expandGroup(i);
				}
			} else {
				noData.setVisibility(View.VISIBLE);
			}

			break;
		case R.id.downloadTips:
			hideFinishTips();
			break;
		case R.id.btnStartDownLoad:

			if (startDownCanBeClick) {

//				Statistics.getInstance().saveStatistics(Statistics.REPORTED_DATA_SHOWING_WHAT,
//						StatisticsUtil.generateCustomField(new String[] { "OFFLINE_CLICK_START_DOWNLOAD_BTN", System.currentTimeMillis() + "", "", "", "", "", "" }));
				
				WebDev.trackCustomEvent(OfflineActivity.this, EventId.BOSS_OFFLINE_CLICK_START_DOWNLOAD_BTN);
				
				
				boolean needDownNew = false;
				for (int i = 0, j = lcs.size(); i < j; i++) {
					SLog.e("ol", lcs.get(i).getChlid() + "需不需要更新:" + (Math.abs(System.currentTimeMillis() - SpOfflineOneChannelTime.getUpdataChannelTimeNum(lcs.get(i).getChlid()))));
					if (Math.abs(System.currentTimeMillis() - SpOfflineOneChannelTime.getUpdataChannelTimeNum(lcs.get(i).getChlid())) > MANUAL_UPDATE_OFFLINE) {
						needDownNew = true;
						break;
					}
				}

				SLog.e("ol", "需不需要更新:" + needDownNew);

				if (downloadedData != null && downloadedData.size() > 0) {
					if (!needDownNew) {
						showFinishTips("已有" + downloadedData.size() * 100 + "条新闻可以阅读,请稍后更新");
					} else {
						hadCancel = false;
						hideFinishTips();
						startDownCanBeClick = false;
						isAutoDownload = false;
						if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_WIFI) {
							if (dlg != null && !dlg.isShowing() && !isFinishing()) {
								prepareDownloadUI();
								dlg.show();
							}
							getDownLoadList();
						} else if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_MOBILE) {
							if (!OfflineActivity.this.isFinishing()) {
								showDialog(IF_DOWNLOAD_23G);
							}
						} else {
							TipsToast.getInstance().showTipsError(this.getResources().getString(R.string.string_http_data_nonet));
							startDownCanBeClick = true;
//							Statistics.getInstance().saveStatistics(Statistics.REPORTED_DATA_SHOWING_WHAT,
//									StatisticsUtil.generateCustomField(new String[] { "OFFLINE_ERROR_NO_NET", System.currentTimeMillis() + "", "", "", "", "", "" }));
							WebDev.trackCustomEvent(OfflineActivity.this, EventId.BOSS_OFFLINE_ERROR_NO_NET);
						}
					}
				} else {

					hadCancel = false;
					hideFinishTips();
					startDownCanBeClick = false;
					isAutoDownload = false;
					if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_WIFI) {
						if (dlg != null && !dlg.isShowing() && !isFinishing()) {
							prepareDownloadUI();
							dlg.show();
						}
						getDownLoadList();
					} else if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_MOBILE) {
						if (!OfflineActivity.this.isFinishing()) {
							showDialog(IF_DOWNLOAD_23G);
						}
					} else {
						TipsToast.getInstance().showTipsError(this.getResources().getString(R.string.string_http_data_nonet));
						startDownCanBeClick = true;
//						Statistics.getInstance().saveStatistics(Statistics.REPORTED_DATA_SHOWING_WHAT,
//								StatisticsUtil.generateCustomField(new String[] { "OFFLINE_ERROR_NO_NET", System.currentTimeMillis() + "", "", "", "", "", "" }));
						WebDev.trackCustomEvent(OfflineActivity.this, EventId.BOSS_OFFLINE_ERROR_NO_NET);
					}
				}
			}
			break;
		default:
			break;
		}
	}

	long startGetTask;
	HttpDataRequest request;

	private void autoDownLoad() {
		startDownCanBeClick = false;
		isAutoDownload = true;
		hideFinishTips();
		prepareDownloadUI();
		if (dlg != null && !dlg.isShowing() && !isFinishing()) {
			dlg.show();
		}
		getDownLoadList();
	}

	private void getDownLoadList() {
		if (request == null || request.isCancelled()) {
			startGetTask = System.currentTimeMillis();
			request = TencentNews.getInstance().getOfflineList(getChannelString());
			TaskManager.startHttpDataRequset(request, OfflineActivity.this);
		}
	}

	private void PauseSilentDownload() {
		int mState = Application.getInstance().getDownloadState();
		SLog.d("hj", "offline Downloadstate:" + Integer.toHexString(mState));
		if (mState == DownloadConstants.T_UPDATE_PROGRESS && SpConfig.getSilentDownloadFlag() == Constants.SILENT_START_DOWNLOAD) {
			DownloadManager.getInstance().doStateAction(Constants.APPID, mState, "", "com.tencent.news", "腾讯新闻", DownloaderStateCallBack.getInstance(), "", false);
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {

			Intent intent = new Intent();
			intent.setClass(OfflineActivity.this, MainActivity.class);
			intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(intent);
			quitActivity();

			return true;
		} else if (keyCode == KeyEvent.KEYCODE_MENU) {
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public void onHttpRecvOK(HttpTag tag, Object result) {

		SLog.i("ol", "onHttpRecvOK()");

		if (HttpTag.OFFLINE_LIST.equals(tag)) {

			SLog.i("olTime", "获取下载任务耗时" + (System.currentTimeMillis() - startGetTask) + "ms");

			if (hadCancel) {
				if (isAutoDownload) {
					isAutoDownload = false;
				}
				startDownCanBeClick = true;

				SLog.e("ol", "onHttpRecvOK()取消走完startDownCanBeClick-->" + startDownCanBeClick);
				return;
			}

			// 获取下载任务
			if (result instanceof OfflineChannel[]) {
				mOfflineChannels = (OfflineChannel[]) result;
				if (mOfflineChannels != null && mOfflineChannels.length > 0) {
					mNeedDownload = new ArrayList<OfflineChannel>();

					for (int i = 0, j = mOfflineChannels.length; i < j; i++) {
						if ("0".equalsIgnoreCase(mOfflineChannels[i].getFlag())) {
							OfflineChannel oc = mOfflineChannels[i];
							String chlId = oc.getChlid();

							if (isAutoDownload) {// 自动下载

								// if
								// (SpOfflineOneChannelTime.getUpdataChannelTimeNum(chlId)
								// == 0L) {// 新添加的频道

								// if (Math.abs(SpOffline.getUpdataAllTime()
								// - System.currentTimeMillis()) >
								// MANUAL_UPDATE_OFFLINE) {//
								// 全量下载大于半小时才自动下载新添加的频道
								// mNeedDownload.add(oc);
								// }
								//
								// } else {// 已经下过的频道
								// }

								if (Math.abs(SpOfflineOneChannelTime.getUpdataChannelTimeNum(chlId) - System.currentTimeMillis()) > AUTO_UPDATE_OFFLINE) {// 下载已经超过2小时了,需要自动下载
									addNeedDownload(oc);
								}

							} else {// 手动下载

								if (SpOfflineOneChannelTime.getUpdataChannelTimeNum(chlId) == 0L) {// 新添加的频道

									addNeedDownload(oc);

								} else {// 已经下过的频道

									if (Math.abs(SpOfflineOneChannelTime.getUpdataChannelTimeNum(chlId) - System.currentTimeMillis()) > MANUAL_UPDATE_OFFLINE) {// 下载已经超过0.5小时了,需要下载
										addNeedDownload(oc);
									}

								}

							}
						}
					}

				}
			}

			if (mNeedDownload != null && mNeedDownload.size() > 0) {
				startDownload();
			} else {
				if (!isAutoDownload && downloadedData != null && downloadedData.size() > 0) {
					showFinishTips("已有" + downloadedData.size() * 100 + "条新闻可以阅读,请稍后更新");
				}
				if (dlg != null && dlg.isShowing()) {
					dlg.dismiss();
				}

			}
			if (isAutoDownload) {
				isAutoDownload = false;
			}
			// startDownCanBeClick = true;
			SLog.e("ol", "onHttpRecvOK()走完startDownCanBeClick-->" + startDownCanBeClick);
		}
	}

	private void addNeedDownload(OfflineChannel oc) {
		if (mNeedDownload != null && mNeedDownload.indexOf(oc) < 0) {
			mNeedDownload.add(oc);
		}
	}

	// boolean manualIgnoreTime = false;

	private void startDownload() {

		if (DownloadConstants.T_UPDATE_PROGRESS != OffLineDownloadManagerNew.getInstance().getState()) {
			hideFinishTips();
			downloadingUI();
			if (dlg != null && !dlg.isShowing() && !isFinishing()) {
				dlg.show();
			}
			// manualIgnoreTime = false;
			PauseSilentDownload();

			allTime = System.currentTimeMillis();

			SLog.e("ol", "===================得到下载任务之后开始下载===================");
			OffLineDownloadManagerNew.getInstance().addDownloadTask(mNeedDownload);
		}

	}

	@Override
	public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {
		request.setCancelled(true);
		startDownCanBeClick = true;
		if (isAutoDownload) {
			isAutoDownload = false;
		}
		if (dlg != null) {
			dlg.dismiss();
		}
		if (downloadedData != null && downloadedData.size() > 0) {
			noData.setVisibility(View.GONE);
		} else {
			noData.setVisibility(View.VISIBLE);
			TipsToast.getInstance().showTipsWarning(msg);
		}

		// Statistics.getInstance().saveStatistics(Statistics.REPORTED_DATA_SHOWING_WHAT,
		// StatisticsUtil.generateCustomField(new String[] {
		// "OFFLINE_ERROR_GET_DOWNLOAD_LIST_NO_NET", System.currentTimeMillis()
		// + "", "", "", "", "", "" }));

		WebDev.trackCustomEvent(OfflineActivity.this, EventId.BOSS_OFFLINE_ERROR_GET_DOWNLOAD_LIST_NO_NET);

		// SLog.e("ol", "onHttpRecvError()走完startDownCanBeClick-->" +
		// startDownCanBeClick);
	}

	@Override
	public void onHttpRecvCancelled(HttpTag tag) {
		request.setCancelled(true);
		startDownCanBeClick = true;
		if (isAutoDownload) {
			isAutoDownload = false;
		}
		if (dlg != null) {
			dlg.dismiss();
		}
		if (downloadedData != null && downloadedData.size() > 0) {
			noData.setVisibility(View.GONE);
		} else {
			noData.setVisibility(View.VISIBLE);
		}
		SLog.e("ol", "onHttpRecvCancelled()走完startDownCanBeClick-->" + startDownCanBeClick);
	}

	@Override
	public void downloadProgressChanged(int state, int n_progress, OfflineChannel channel, int surplus) {
		Message msg = mHandler.obtainMessage();

		SLog.e("olprogress", "state=" + dump(state) + ", n_progress=" + n_progress + ", SpOfflineProgress.getChannelProgress(channel)=" + SpOfflineProgress.getChannelProgress(channel) + ", channel="
				+ channel.getChlid() + ",surplus=" + surplus);

		if (n_progress < SpOfflineProgress.getChannelProgress(channel)) {
			n_progress = SpOfflineProgress.getChannelProgress(channel);
		}

		MsgObj msgobj = new MsgObj(state, n_progress, channel, surplus);
		msg.obj = msgobj;
		msg.what = REFRESH_PROGRESS_OFFLINE;
		mHandler.sendMessage(msg);

	}

	private String dump(int state) {
		switch (state) {
		case 0x301:
			return "T_DOWNLOAD";
		case 0x302:
			return "T_PAUSE";
		case 0x303:
			return "T_OPEN";
		case 0x304:
			return "T_INSTALL";
		case 0x305:
			return "T_UPDATE";
		case 0x306:
			return "T_UPDATE_PROGRESS";
		case 0x307:
			return "T_WAIT";
		case 0x308:
			return "T_ERROR";
		default:
			return "";
		}
	}

	class MsgObj {
		public int state;
		public int n_progress;
		public OfflineChannel channel;
		public int surplus;

		public MsgObj(int state, int n_progress, OfflineChannel channel, int surplus) {
			super();
			this.state = state;
			this.n_progress = n_progress;
			this.channel = channel;
			this.surplus = surplus;
		}
	}

	@Override
	protected void onRestart() {
		super.onRestart();
		SLog.i("ol", SLog.getTraceInfo() + "==============beBackground=" + beBackground + "正在下载=" + (DownloadConstants.T_UPDATE_PROGRESS == OffLineDownloadManagerNew.getInstance().getState()));
		beBackground = false;
		OffLineDownloadManagerNew.getInstance().killNotification();
	}

	@Override
	protected void onStop() {
		super.onStop();

		SLog.i("ol", SLog.getTraceInfo() + "==============beBackground=" + beBackground + "正在下载=" + (DownloadConstants.T_UPDATE_PROGRESS == OffLineDownloadManagerNew.getInstance().getState()));

		if (DownloadConstants.T_UPDATE_PROGRESS == OffLineDownloadManagerNew.getInstance().getState()) {
			beBackground = true;
			OffLineDownloadManagerNew.getInstance().doNotification();
		}
	}

	@Override
	public void afterParse() {

		SLog.d("ol", "解压解析完成的回调afterParse()");
		mHandler.sendEmptyMessage(FINISH_ALL_OFFLINE);
	}

	private void buildDlg() {
		if (dlg == null) {
			dlg = new Dialog(this, R.style.MMTheme_DataSheet);
		}

		LayoutInflater inflate = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

		RelativeLayout mLinearLayout;

		if (themeSettingsHelper.isDefaultTheme()) {
			mLinearLayout = (RelativeLayout) inflate.inflate(R.layout.dialog_offline_download, null);
		} else {
			mLinearLayout = (RelativeLayout) inflate.inflate(R.layout.night_dialog_offline_download, null);
		}

		mLinearLayout.setMinimumWidth(10000);
		dlg.setContentView(mLinearLayout);

		progressInit = (TextView) mLinearLayout.findViewById(R.id.progressInit);
		progressfinishsoon = (TextView) mLinearLayout.findViewById(R.id.progressfinishsoon);
		download_how_many = (TextView) mLinearLayout.findViewById(R.id.download_how_many);
		download_how_many_unit = (TextView) mLinearLayout.findViewById(R.id.download_how_many_unit);
		downloadingWhat = (LinearLayout) mLinearLayout.findViewById(R.id.downloadingWhat);
		download_channle_name = (TextView) mLinearLayout.findViewById(R.id.download_channle_name);
		download_current = (TextView) mLinearLayout.findViewById(R.id.download_current);
		download_all = (TextView) mLinearLayout.findViewById(R.id.download_all);
		progressBar = (ProgressBar) mLinearLayout.findViewById(R.id.progressBar);
		progressBar.setIndeterminate(false);
		cancel_download = (Button) mLinearLayout.findViewById(R.id.cancel_download);
		network_status = (ImageView) mLinearLayout.findViewById(R.id.network_status);

		if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_WIFI) {
			network_status.setVisibility(View.VISIBLE);
			network_status.setImageDrawable(getResources().getDrawable(R.drawable.offline_wifi_icon));
		} else if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_MOBILE) {
			network_status.setVisibility(View.VISIBLE);
			network_status.setImageDrawable(getResources().getDrawable(R.drawable.offline_notwifi_icon));
		} else {
			network_status.setVisibility(View.GONE);
		}

		cancel_download.setOnClickListener(this);

		Window w = dlg.getWindow();
		WindowManager.LayoutParams lp = w.getAttributes();
		lp.x = 0;
		final int cMakeBottom = -1000;
		lp.y = cMakeBottom;
		lp.width = WindowManager.LayoutParams.FILL_PARENT;
		lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
		lp.gravity = Gravity.BOTTOM;
		dlg.onWindowAttributesChanged(lp);
		dlg.setCancelable(false);
		dlg.setCanceledOnTouchOutside(false);
		dlg.setOnDismissListener(new OnDismissListener() {

			@Override
			public void onDismiss(DialogInterface dialog) {
				startDownCanBeClick = true;
			}
		});
	}

	@Override
	public void applyTheme() {
		themeSettingsHelper.setViewBackgroud(this, offline_title, R.drawable.title_bar_bg);
		themeSettingsHelper.setViewBackgroud(this, offline_title_btn_back, R.drawable.title_back_btn);
		themeSettingsHelper.setViewBackgroudColor(this, downloadTips, R.color.nettips_bg_color);
		themeSettingsHelper.setTextViewColor(this, downloadTips, R.color.nettips_text_color);
		// if (themeSettingsHelper.isNightTheme()) {
		// offline_title_btn_back.setTextColor(Color.parseColor("#f0f4f8"));
		// } else {
		// offline_title_btn_back.setTextColor(Color.parseColor("#ffffff"));
		// }
		themeSettingsHelper.setViewBackgroudColor(this, mMask, R.color.mask_page_color);

		if (themeSettingsHelper.isDefaultTheme()) {
			// downloadTips.setTextColor(Color.parseColor("#22678f"));
			btnStartDownload.setImageResource(R.drawable.btn_offline_download_selector);
		} else {
			btnStartDownload.setImageResource(R.drawable.night_btn_offline_download_selector);
			// downloadTips.setTextColor(Color.parseColor("#37270d"));
		}

		themeSettingsHelper.setViewBackgroudColor(this, this.downloadedDataListView, R.color.timeline_home_bg_color);
		themeSettingsHelper.setListViewSelector(this, this.downloadedDataListView, R.drawable.list_selector);
		downloadedDataListView.applyIphoneTreeView(this);
	}

	// private float downX;
	// private float upX;
	// private float downY;
	// private float upY;
	//
	// @Override
	// public boolean dispatchTouchEvent(MotionEvent ev) {
	// final float x = ev.getX();
	// final float y = ev.getY();
	// if (ev.getAction() == MotionEvent.ACTION_DOWN) {
	// downX = x;
	// downY = y;
	// } else if (ev.getAction() == MotionEvent.ACTION_UP) {
	// upX = x;
	// upY = y;
	// if (upX > downX && Math.abs(upX - downX) > MobileUtil.dpToPx(100) &&
	// Math.abs(upY - downY) / Math.abs(upX - downX) < 0.4) {
	// quitActivity();
	// return true;
	// }
	// }
	// return super.dispatchTouchEvent(ev);
	// }

	private String computDownloadSize() {
		String fileSizeStr = "";
		float fileSize = 0f;
		int needNum = 0;
		for (int i = 0, j = lcs.size(); i < j; i++) {
			if (Math.abs(System.currentTimeMillis() - SpOfflineOneChannelTime.getUpdataChannelTimeNum(lcs.get(i).getChlid())) > MANUAL_UPDATE_OFFLINE) {
				needNum++;
			}
		}

		if (lcs != null) {
			Random r = new Random();
			fileSize = needNum * (r.nextFloat() * 10f + 190.0f) / 1024.0f;
		}
		DecimalFormat df = new DecimalFormat("0.00");
		fileSizeStr = df.format(fileSize);
		return fileSizeStr;
	}

	@Override
	protected void onPrepareDialog(int id, Dialog dialog) {
		switch (id) {
		case IF_DOWNLOAD_23G:
			removeDialog(IF_DOWNLOAD_23G);
			dialog = new AlertDialog.Builder(this)//
					.setTitle("提醒")//
					.setMessage("您的手机正在使用非WIFI网络。离线阅读的下载功能大约耗费您" + computDownloadSize() + "M流量，确定继续下载吗？")//
					.setPositiveButton("取消下载", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int whichButton) {
							startDownCanBeClick = true;
							dialog.dismiss();
						}
					}).setNegativeButton("继续下载", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {

							dialog.dismiss();
							SLog.i("ol", "onCreateDialog 正在下载" + (DownloadConstants.T_UPDATE_PROGRESS == OffLineDownloadManagerNew.getInstance().getState()));
							if (DownloadConstants.T_UPDATE_PROGRESS != OffLineDownloadManagerNew.getInstance().getState()) {
								// if (downloadTips.isShown()) {
								hideFinishTips();
								// }
								prepareDownloadUI();
								if (dlg != null && !dlg.isShowing() && !isFinishing()) {
									SLog.d("ol", "弹出下载界面");
									dlg.show();
								}
								getDownLoadList();
							}

						}
					}).create();// 创建
			break;
		}

		super.onPrepareDialog(id, dialog);
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case IF_DOWNLOAD_23G:

			Dialog dialog = new AlertDialog.Builder(this)//
					.setTitle("提醒")//
					.setMessage("您的手机正在使用非WIFI网络。离线阅读的下载功能大约耗费您" + computDownloadSize() + "M流量，确定继续下载吗？")//
					.setPositiveButton("取消下载", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int whichButton) {
							startDownCanBeClick = true;
							dialog.dismiss();
						}
					}).setNegativeButton("继续下载", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {

							dialog.dismiss();
							SLog.i("ol", "onCreateDialog 正在下载" + (DownloadConstants.T_UPDATE_PROGRESS == OffLineDownloadManagerNew.getInstance().getState()));
							if (DownloadConstants.T_UPDATE_PROGRESS != OffLineDownloadManagerNew.getInstance().getState()) {
								// if (downloadTips.isShown()) {
								hideFinishTips();
								// }
								prepareDownloadUI();
								if (dlg != null && !dlg.isShowing() && !isFinishing()) {
									SLog.d("ol", "弹出下载界面");
									dlg.show();
								}
								getDownLoadList();
							}

						}
					}).create();// 创建
			return dialog;
		}
		return super.onCreateDialog(id);
	}

	private void orderByLcs() {
		if (downloadedData != null && downloadedData.size() > 0 && lcs != null && lcs.size() > 0) {

			List<OfflinePreview> orderedDownloadedData = new ArrayList<OfflinePreview>();
			HashMap<String, OfflinePreview> temp = new HashMap<String, OfflinePreview>();
			for (OfflinePreview op : downloadedData) {
				temp.put(op.getDownloadedChannel(), op);
			}
			for (Channel c : lcs) {
				OfflinePreview opFromMap = temp.get(c.getChlid());
				if (opFromMap != null) {
					orderedDownloadedData.add(opFromMap);
					temp.remove(c.getChlid());
				}
			}
			if (!temp.isEmpty()) {
				for (String i : temp.keySet()) {
					orderedDownloadedData.add(temp.get(i));
				}
			}
			downloadedData = orderedDownloadedData;
		}
	}

	@Override
	protected void onStart() {
		super.onStart();
		// Statistics.getInstance().saveStatistics(Statistics.REPORTED_DATA_SHOWING_WHAT,
		// StatisticsUtil.generateCustomField(new String[] {
		// "OFFLINE_ENTER_ACTIVITY", System.currentTimeMillis() + "", "", "",
		// "", "", "" }));

		WebDev.trackCustomEvent(OfflineActivity.this, EventId.BOSS_OFFLINE_ENTER_ACTIVITY);
	}

	long viewStart;
	long viewEnd;
	
	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
		viewStart = System.currentTimeMillis();
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
		viewEnd = System.currentTimeMillis();
		
		WebDev.trackCustomEvent(this, EventId.BOSS_OFFLINE_VIEW_TIME, ""+(viewEnd-viewStart));
	}
}
