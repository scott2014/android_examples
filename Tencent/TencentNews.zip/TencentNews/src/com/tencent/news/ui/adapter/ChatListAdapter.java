package com.tencent.news.ui.adapter;

import java.util.ArrayList;
import java.util.List;

import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.text.ClipboardManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.tencent.news.R;
import com.tencent.news.command.GetImageRequest;
import com.tencent.news.config.Constants;
import com.tencent.news.model.pojo.ChatMsg;
import com.tencent.news.model.pojo.ImageResult;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.StringUtil;


/**
 * @author haiyandu
 *
 */
public class ChatListAdapter extends AbsListAdapter<ChatMsg> implements OnLongClickListener {
	private final static String TAG = ChatListAdapter.class.getSimpleName();
	
	private final static long MINIMUM_TIME_DISTANCE = 10 * 60 * 1000L; // 10 minutes
	
	private List<ChatMsg> failedMsgList;
	private String mUin;

	public ChatListAdapter(Context context, String uin, ListView listView) {
		this.mContext = context;
		this.mUin = uin;
		this.mListView = listView;
		mDataList = new ArrayList<ChatMsg>();
		failedMsgList = new ArrayList<ChatMsg>();
	}

	public void addFailedMsg(ChatMsg msg) {
	    if (failedMsgList != null) {
	        failedMsgList.add(msg);
	    }
	    notifyDataSetChanged();
	}
	
	public List<ChatMsg> getFailedMsgList() {
		return failedMsgList;
	}
	
	public void setFailedIcon(ChatMsgHolder holder) {
	    for (int i = 0; i < failedMsgList.size(); i++) {
	        if (holder.id.equals(failedMsgList.get(i).getTime())) {
	            holder.failIcon.setVisibility(View.VISIBLE);
	            return;
	        }
	    }
	    holder.failIcon.setVisibility(View.GONE);
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ChatMsgHolder holder = null;
		int type = getItemViewType(position);
		switch(type){
		case Constants.TYPE_ITEM_SENDER: //左边的
			convertView = setReceverMode(convertView,position,holder);
			break;
		case Constants.TYPE_ITEM_RECEVER: // 右边的
			convertView = setSenderMode(convertView,position,holder);
			break;
		default:
			break;
		}
		return convertView;
	}
	
	private void setMsgTime(ChatMsgHolder holder, int position) {
		ChatMsg msg = mDataList.get(position);
		
		if (position == 0) {
			holder.time.setText(StringUtil.getPublishTime(Long.parseLong(msg.getTime() + "000")));
		} else {
			ChatMsg lastMsg = mDataList.get(position - 1);
			long curTime = Long.parseLong(msg.getTime() + "000");
			long lastTime = Long.parseLong(lastMsg.getTime() + "000");
			long deltaTime = curTime - lastTime;
			if (deltaTime < MINIMUM_TIME_DISTANCE) {
				holder.time.setText("");
			} else {
				holder.time.setText(StringUtil.getPublishTime(curTime));
			}
		}
	}
	
	private View setReceverMode(View convertView, int position, ChatMsgHolder holder){
		SLog.v(TAG, "setReceverMode--"+"position:" + position);
		if(convertView == null){
			holder = new ChatMsgHolder();
			convertView = LayoutInflater.from(mContext).inflate(R.layout.chat_item_recever, null);
			holder.userIcon = (ImageView)convertView.findViewById(R.id.recever_icon);
			holder.userAuth = (ImageView)convertView.findViewById(R.id.recever_vip_icon);
			holder.msg = (TextView)convertView.findViewById(R.id.recever_msg_content);
			holder.time = (TextView)convertView.findViewById(R.id.recever_time);
			convertView.setTag(holder);
		} else {
			holder = (ChatMsgHolder)convertView.getTag();
		}
		
		ChatMsg msg = mDataList.get(position);
		
		holder.id = msg.getTime();
		
		if(msg.getIsvip().equals("1")){
			holder.userAuth.setVisibility(View.VISIBLE);
		}else{
			holder.userAuth.setVisibility(View.GONE);
		}
		
		holder.msg.setTag(msg);
		holder.msg.setOnLongClickListener(this);
		
		if (themeSettingsHelper.isNightTheme()) {
		    holder.msg.setBackgroundResource(R.drawable.night_message_left_background);
		    holder.msg.setTextColor(Color.parseColor("#9fd1ff"));
		} else {
		    holder.msg.setBackgroundResource(R.drawable.message_left_background);
		    holder.msg.setTextColor(Color.parseColor("#005393"));
		}
		
		applyTheme(convertView, holder);
		
		if (msg.getMsg() != null) {
		    holder.msg.setText(msg.getMsg().trim());
		}
		
		setMsgTime(holder, position);
//		holder.time.setText(StringUtil.getPublishTime(Long.parseLong(msg.getTime()+"000")));
		
		setUserIcon(msg, holder);
		return convertView;
	}

	private View setSenderMode(View convertView, int position, ChatMsgHolder holder){
		SLog.v(TAG, "setSenderMode--"+"position:" + position);
		if(convertView == null){
			holder = new ChatMsgHolder();
			convertView = LayoutInflater.from(mContext).inflate(R.layout.chat_item_sender, null);
			holder.userIcon = (ImageView)convertView.findViewById(R.id.sender_icon);
			holder.userAuth = (ImageView)convertView.findViewById(R.id.sender_vip_icon);
			holder.msg = (TextView)convertView.findViewById(R.id.sender_msg_content);
			holder.time = (TextView)convertView.findViewById(R.id.sender_time);
			holder.failIcon = (ImageView) convertView.findViewById(R.id.message_fail_icon);
			convertView.setTag(holder);
		} else {
			holder = (ChatMsgHolder)convertView.getTag();
		}
		
		ChatMsg msg = mDataList.get(position);
		
		holder.id = msg.getTime();
		setFailedIcon(holder);
		
		if (msg.getIsvip().equals("1")) {
			holder.userAuth.setVisibility(View.VISIBLE);
		} else {
			holder.userAuth.setVisibility(View.GONE);
		}
		
		holder.msg.setTag(msg);
		holder.msg.setOnLongClickListener(this);
		
		if (themeSettingsHelper.isNightTheme()) {
            holder.msg.setBackgroundResource(R.drawable.night_message_right_background);
            holder.msg.setTextColor(Color.parseColor("#f0f4f8"));
        } else {
            holder.msg.setBackgroundResource(R.drawable.message_right_background);
            holder.msg.setTextColor(Color.parseColor("#444444"));
        }
		
		applyTheme(convertView, holder);
		
		holder.msg.setText(msg.getMsg().trim());
		setMsgTime(holder, position);
//		holder.time.setText(StringUtil.getPublishTime(Long.parseLong(msg.getTime() + "000")));
		
		setUserIcon(msg, holder);
		return convertView;
	}
	
	private void applyTheme(View convertView, ChatMsgHolder holder) {
	    themeSettingsHelper.setViewBackgroudColor(mContext, convertView, R.color.timeline_home_bg_color);
	}
	
	private void setUserIcon(ChatMsg msg, ChatMsgHolder holder){
		GetImageRequest request = new GetImageRequest();
		request.setGzip(false);
		request.setTag(msg.getTime());
		request.setUrl(msg.getSenderHead());
		ImageResult result = TaskManager.startSmallImageTask(request, this);
		
		if (result.isResultOK() && result.getRetBitmap() != null) {
			holder.userIcon.setImageBitmap(result.getRetBitmap());
		} else {
			holder.userIcon.setImageResource(R.drawable.default_comment_user_man_icon);
		}
	}
	
	@Override
	public int getItemViewType(int position) {	
		ChatMsg msg = mDataList.get(position);
		if(msg != null && mUin.equals(msg.getUin())){
			return Constants.TYPE_ITEM_SENDER;
		}
		return Constants.TYPE_ITEM_RECEVER;
	}
	
	@Override
	public int getViewTypeCount() {
		// Auto-generated method stub
		return 2;
	}
	
	@Override
	public boolean isEnabled(int position) {
		// TODO Auto-generated method stub
		return false;
	}
	
	@Override
	public void serListViewBusy(int currPosition, int tag) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changeStyleMode(int style) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm,
			String path) {
		// TODO Auto-generated method stub
		switch (imageType) {
		case SMALL_IMAGE:
			int countImage = mListView.getChildCount();
			for (int i = 0; i < countImage; i++) {
				ChatMsgHolder holder = (ChatMsgHolder) mListView.getChildAt(i).getTag();
				if (holder != null) {
					if (((String) tag).equals(holder.id)) {
						if(bm != null && holder.userIcon != null){
							holder.userIcon.setImageBitmap(bm);	
						} else {
						    holder.userIcon.setImageResource(R.drawable.default_comment_user_man_icon);
						}
					}
				}
			}
			break;
		default:
			break;
		}
	}

	@Override
	public void onImageRecvError(ImageType imageType, Object tag, int retCode) {
		// TODO Auto-generated method stub
		
	}

	private static class ChatMsgHolder{
		String id;
		ImageView userIcon;
		ImageView userAuth;
		TextView msg;
		TextView time;
		ImageView failIcon;
	}
	
	@Override
    public boolean onLongClick(View v) {
	    ChatMsg msg = (ChatMsg) v.getTag();
	    
        
	    int viewId = v.getId();
	    
	    switch (viewId) {
	        case R.id.recever_msg_content:
	        case R.id.sender_msg_content:
	            createDialog(msg);
	            
	    }
        
        return true;
    }
	
	private void createDialog(final ChatMsg msg) {
        Builder builder = new Builder(mContext);
        builder.setTitle("我的消息");
        builder.setItems(R.array.chat_msg_actions, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                case 0:
                    ClipboardManager clipBorad =(ClipboardManager) mContext.getSystemService(Context.CLIPBOARD_SERVICE);
                    clipBorad.setText(msg.getMsg());
//                  TipsToast.getInstance().showTipsSuccess(clipBorad.getText().toString());
                    Toast.makeText(mContext, "复制成功", Toast.LENGTH_SHORT).show();
                    
                    break;
                default:
                    break;
                }
            }
        });
        builder.create().show();
   }
}
