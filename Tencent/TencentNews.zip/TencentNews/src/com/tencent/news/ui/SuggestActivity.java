package com.tencent.news.ui;

import android.view.View;

import com.tencent.news.api.TencentNews;
import com.tencent.news.cache.UserDBHelper;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.config.Constants;
import com.tencent.news.task.TaskManager;
import com.tencent.omg.webdev.WebDev;

public class SuggestActivity extends AbsWritingActivity {

	@Override
	int iAmWhich() {
		return Constants.WRITE_SUGGEST;
	}

	@Override
	void assignUI() {
		writingTitleText.setText("意见反馈");
		input.setHint("您的意见会在微博@腾讯新闻客户端,我们将及时反馈");
		write_footer.setVisibility(View.GONE);
		share_to.setVisibility(View.GONE);
		// remainText.setVisibility(View.GONE);
	}

	@Override
	void sendWords() {

		HttpDataRequest request = TencentNews.getInstance().suggestQQNews(lastInput, UserDBHelper.getInstance().getUserInfo().getAccount(), UserDBHelper.getInstance().getUserInfo().getNick());
		TaskManager.startHttpDataRequset(request, SuggestActivity.this);

	}

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}
}
