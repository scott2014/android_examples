package com.tencent.news.ui;

import java.lang.reflect.Field;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings.LayoutAlgorithm;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ZoomButtonsController;

import com.tencent.news.R;
import com.tencent.news.config.Constants;
import com.tencent.news.model.pojo.ExtendedChannels;
import com.tencent.news.system.NetStatusReceiver;
import com.tencent.news.ui.view.NavigationBar;
import com.tencent.news.ui.view.TitleBar;
import com.tencent.news.utils.InfoConfigUtil;
import com.tencent.news.utils.MobileUtil;
import com.tencent.omg.webdev.WebDev;

public class WebBrowserActivity extends BaseActivity {
	private RelativeLayout web_tool_bar;
	private ImageButton mBackBtn;
	private ImageButton mForwardBtn;
	private ImageButton mRefreshBtn;
	private TitleBar mTitleBar;
	private View mMask;
	private View web_browser_mask_view;
	private LinearLayout mLoadingLayout;
	private ImageView mLoadingIcon;
	private WebView mWebView;
	private String mCurrUrl;
	private String mUrl;
	private String mTitleText;
	private String mBackText;
	protected float downX;
	protected float upX;
	protected float downY;
	protected float upY;
	private boolean disable_gesture_quit;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.web_browser_layout);
		getIntentData();
		initView();
		initListener();
	}

	private void getIntentData() {
		Intent intent = getIntent();
		if (intent != null) {
			mUrl = intent.getStringExtra("url");
			mTitleText = intent.getStringExtra("title");
			mBackText = intent.getStringExtra("backText");
			disable_gesture_quit = intent.getBooleanExtra("disable_gesture_quit", false);
		}
	}

	private void initView() {
		mLoadingIcon = (ImageView) findViewById(R.id.webbrowser_loading_icon);
		mTitleBar = (TitleBar) findViewById(R.id.web_detail_title_bar);
		mLoadingLayout = (LinearLayout) findViewById(R.id.web_detail_loading);
		mWebView = (WebView) findViewById(R.id.web_detail_webview);
		web_tool_bar = (RelativeLayout) findViewById(R.id.web_tool_bar);
		mBackBtn = (ImageButton) findViewById(R.id.web_back_btn);
		mForwardBtn = (ImageButton) findViewById(R.id.web_forward_btn);
		mRefreshBtn = (ImageButton) findViewById(R.id.web_refresh_btn);
		mMask = (View) findViewById(R.id.mask_view);
		web_browser_mask_view = (View) findViewById(R.id.web_browser_mask_view);
		mWebView.getSettings().setSavePassword(false);
		mWebView.getSettings().setDomStorageEnabled(true);
		mWebView.getSettings().setJavaScriptEnabled(true);
		mWebView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
		
		mWebView.getSettings().setSupportZoom(true); 
		mWebView.getSettings().setBuiltInZoomControls(true);
//		mWebView.getSettings().setDefaultZoom(WebSettings.ZoomDensity.FAR); 
		mWebView.getSettings().setLayoutAlgorithm(LayoutAlgorithm.SINGLE_COLUMN); 
//        mWebView.getSettings().setUseWideViewPort(true); 
//        mWebView.getSettings().setLoadWithOverviewMode(true); 
        setZoomControlGone(mWebView);
        
		mTitleBar.ShowNewsBar(mTitleText != null ? mTitleText : "腾讯新闻");
		mTitleBar.setBackName(mBackText != null ? mBackText : "返回");
		mTitleBar.setHideShare();
		mBackBtn.setEnabled(false);
		mForwardBtn.setEnabled(false);
		setTitleBackName();
		
		mWebView.loadUrl(mUrl);
	}

	// 去掉缩放按钮
	public void setZoomControlGone(View view){
        Class<?> classType;
        Field field;
        try {
            classType = WebView.class;
            field = classType.getDeclaredField("mZoomButtonsController");
            field.setAccessible(true);
            ZoomButtonsController mZoomButtonsController = new ZoomButtonsController(view);
            mZoomButtonsController.getZoomControls().setVisibility(View.GONE);
            try {
                field.set(view, mZoomButtonsController);
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        } catch (SecurityException e) {
            e.printStackTrace();
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        }
    }
	
	private void setTitleBackName() {
		ExtendedChannels channel = InfoConfigUtil.ReadExtendedChannels();
		if (channel != null && channel.getChlname() != null && NavigationBar.getSelected() == 4) {
			mTitleBar.setBackName(channel.getChlname());
		}
	}
	
	private void initListener() {
		mBackBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (mWebView.canGoBack()) {
					mWebView.goBack();
				}
			}
		});

		mForwardBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (mWebView.canGoForward()) {
					mWebView.goForward();
				}
			}
		});

		mRefreshBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (mWebView != null && NetStatusReceiver.netStatus != NetStatusReceiver.NETSTATUS_INAVAILABLE) {
					mWebView.loadUrl(mCurrUrl);
				}
			}
		});

		mTitleBar.setBackClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				quitActivity();
			}
		});

		mWebView.setWebChromeClient(new WebChromeClient() {
			public void onProgressChanged(WebView view, int progress) {
				/*
				 * mProtressBar.setProgress(progress); if(progress >= 100){
				 * mProtressBar.setVisibility(View.GONE); }else{
				 * mProtressBar.setVisibility(View.VISIBLE); }
				 */
			}
		});

		mWebView.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView view, String url, Bitmap favicon) {
				super.onPageStarted(view, url, favicon);
				if (!url.equals(Constants.WEB_ERROR)) {
					mCurrUrl = url;

				}
			}

			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				System.out.println("url------>" + url);

				view.loadUrl(url);
				return true;
			}

			@Override
			public void onPageFinished(WebView view, String url) {
				super.onPageFinished(view, url);
				mWebView.setVisibility(View.VISIBLE);
				web_browser_mask_view.setVisibility(View.VISIBLE);
				mLoadingLayout.setVisibility(View.GONE);
				if (mWebView.canGoBack()) {
					mBackBtn.setEnabled(true);
				} else {
					mBackBtn.setEnabled(false);
				}
				if (mWebView.canGoForward()) {
					mForwardBtn.setEnabled(true);
				} else {
					mForwardBtn.setEnabled(false);
				}
			}

			@Override
			public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
				super.onReceivedError(view, errorCode, description, failingUrl);
				if (mWebView != null) {
					mWebView.loadUrl(Constants.WEB_ERROR);
				}
			}

		});
	}

	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if ((keyCode == KeyEvent.KEYCODE_BACK)) {
			if (mWebView.canGoBack()) {
				if (Constants.WEB_ERROR.equals(mWebView.getUrl())) {
					quitActivity();
				} else {
					mWebView.goBack();
				}
				return true;
			}
			quitActivity();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public boolean dispatchTouchEvent(MotionEvent ev) {

		if (disable_gesture_quit == false) {
			final float x = ev.getX();
			final float y = ev.getY();
			if (ev.getAction() == MotionEvent.ACTION_DOWN) {
				downX = x;
				downY = y;
			} else if (ev.getAction() == MotionEvent.ACTION_UP) {
				upX = x;
				upY = y;
				if (upX > downX && Math.abs(upX - downX) > MobileUtil.dpToPx(100) && Math.abs(upY - downY) / Math.abs(upX - downX) < 0.4) {
					quitActivity();
				}
			}
		}

		return super.dispatchTouchEvent(ev);
	}

	@Override
	public void applyTheme() {
		// TODO Auto-generated method stub
		super.applyTheme();
		if (mTitleBar != null) {
			mTitleBar.applyTitleBarTheme(this);
		}
		themeSettingsHelper.setViewBackgroud(this, web_tool_bar, R.drawable.comment_list_title_bg);
		themeSettingsHelper.setImageButtonSrc(this, mBackBtn, R.drawable.web_back_btn);
		themeSettingsHelper.setImageButtonSrc(this, mForwardBtn, R.drawable.web_forward_btn);
		themeSettingsHelper.setImageButtonSrc(this, mRefreshBtn, R.drawable.web_refresh_btn);
		themeSettingsHelper.setViewBackgroudColor(this, web_browser_mask_view, R.color.mask_webview_color);
		themeSettingsHelper.setViewBackgroudColor(this, mMask, R.color.mask_page_color);
		themeSettingsHelper.setViewBackgroudColor(this, this.mLoadingLayout, R.color.sina_outh_loading_color);
		themeSettingsHelper.setImageViewSrc(this, mLoadingIcon, R.drawable.news_loading_icon);
	}

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}
}
