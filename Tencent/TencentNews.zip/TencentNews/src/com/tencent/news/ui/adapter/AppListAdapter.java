//package com.tencent.news.ui.adapter;
//
//import android.content.Context;
//import android.graphics.Bitmap;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.BaseAdapter;
//import android.widget.GridView;
//import android.widget.ImageView;
//import android.widget.TextView;
//
//import com.tencent.news.R;
//import com.tencent.news.command.GetImageRequest;
//import com.tencent.news.command.GetImageResponse;
//import com.tencent.news.model.pojo.App;
//import com.tencent.news.model.pojo.AppList;
//import com.tencent.news.model.pojo.ImageResult;
//import com.tencent.news.model.pojo.ImageType;
//import com.tencent.news.task.TaskManager;
//
//public class AppListAdapter extends BaseAdapter implements GetImageResponse {
//
//	AppList appList;
//	Context mContext;
//	GridView gridView;
//
//	public void setAppList(AppList appList) {
//		this.appList = appList;
//	}
//
//	public AppListAdapter(Context mContext, GridView gridView) {
//		this.mContext = mContext;
//		this.gridView = gridView;
//	}
//
//	@Override
//	public int getCount() {
//		return appList.getAppList() == null ? 0 : appList.getAppList().size();
//	}
//
//	@Override
//	public Object getItem(int position) {
//		return appList.getAppList() == null ? null : appList.getAppList().get(position);
//	}
//
//	@Override
//	public long getItemId(int position) {
//		return position;
//	}
//
//	@Override
//	public View getView(int position, View convertView, ViewGroup parent) {
//		ViewHolder holder = null;
//		if (convertView == null) {
//			holder = new ViewHolder();
//			convertView = LayoutInflater.from(mContext).inflate(R.layout.app_list_item, null);
//
//			holder.app_icon = (ImageView) convertView.findViewById(R.id.app_icon);
//			holder.app_name = (TextView) convertView.findViewById(R.id.app_name);
//
//			convertView.setTag(holder);
//		} else {
//			holder = (ViewHolder) convertView.getTag();
//		}
//
//		App app = appList.getAppList() == null ? null : appList.getAppList().get(position);
//
//		if (app != null) {
//			doDiffirence(app, holder);
//		}
//
//		return convertView;
//	}
//
//	private void doDiffirence(App app, ViewHolder holder) {
//
//		holder.id = app.getTxt();
//
//		GetImageRequest request = new GetImageRequest();
//		request.setGzip(false);
//		request.setTag(holder.id);
//		request.setUrl(app.getIco4());
//		ImageResult result = TaskManager.startPngImageTask(request, this);
//		if (result.isResultOK() && result.getRetBitmap() != null) {
//			holder.app_icon.setImageBitmap(result.getRetBitmap());
//		} else {
//			holder.app_icon.setImageResource(R.drawable.default_app_icon);
//		}
//
//		holder.app_name.setText(app.getTxt());
//	}
//
//	protected static class ViewHolder {
//		String id;
//		ImageView app_icon;
//		TextView app_name;
//	}
//
//	@Override
//	public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm, String path) {
//		switch (imageType) {
//		case PNG_IMAGE:
//			int countImage = gridView.getChildCount();
//			for (int i = 0; i < countImage; i++) {
//				ViewHolder viewHolder = (ViewHolder) gridView.getChildAt(i).getTag();
//				if (viewHolder != null) {
//					if (((String) tag).equals(viewHolder.id)) {
//						viewHolder.app_icon.setImageBitmap(bm);
//					}
//				}
//			}
//			break;
//		default:
//			break;
//		}
//	}
//
//	@Override
//	public void onImageRecvError(ImageType imageType, Object tag, int retCode) {
//		switch (imageType) {
//		case SMALL_IMAGE:
//			int countImage = gridView.getChildCount();
//			for (int i = 0; i < countImage; i++) {
//				ViewHolder viewHolder = (ViewHolder) gridView.getChildAt(i).getTag();
//				if (viewHolder != null) {
//					if (((String) tag).equals(viewHolder.id)) {
//						viewHolder.app_icon.setImageResource(R.drawable.default_app_icon);
//					}
//				}
//			}
//			break;
//		default:
//			break;
//		}
//
//	}
//
//}
