package com.tencent.news.ui;

import java.net.URI;
import java.net.UnknownHostException;
import java.util.Properties;

import org.apache.http.Header;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.ProtocolException;
import org.apache.http.client.RedirectHandler;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.ExecutionContext;
import org.apache.http.protocol.HttpContext;

import android.app.KeyguardManager;
import android.app.KeyguardManager.KeyguardLock;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaPlayer.OnVideoSizeChangedListener;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;

import com.tencent.news.R;
import com.tencent.news.boss.EventId;
import com.tencent.news.cache.UserDBHelper;
import com.tencent.news.config.Constants;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.ui.view.NewsVideoView;
import com.tencent.news.ui.view.PlayerController;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.news.utils.SLog;
import com.tencent.omg.webdev.WebDev;

//import com.tencent.news.ui.view.NewsMediaController;

public class LiveVideoActivity extends BaseActivity implements OnCompletionListener, OnErrorListener, OnPreparedListener, OnVideoSizeChangedListener {
	private static final int SHOW_VIDEO = 101;
	private String TAG = "LiveVideoActivity";
	private String livePlayUrl;
	private static final String AUTH = "&auth=1";
	private NewsVideoView mVideoView = null;
	// private NewsMediaController mMediaController = null;
	private PlayerController mMediaController = null;
	private LinearLayout mLoadingLayout;

	private int mPositionWhenPaused = -1;
	private boolean isplaying;
	private KeyguardManager mKeyguardManager = null;
	private KeyguardLock mKeyguardLock = null;
	private boolean fromRestart = false;
	Intent myIntent = null;
	private Item mItem;
	private String mChild;
	private String mVid;

	// 数据统计
	// private long statistics_visit_start_time;
	// private long statistics_visit_end_time;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		setContentView(R.layout.activity_live_video);

		// 控制处理锁屏相关状态
		mKeyguardManager = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
		mKeyguardLock = mKeyguardManager.newKeyguardLock("LiveVideoActivity");
		// 监控Home键，恢复锁屏状态
		final IntentFilter mHomeFilter = new IntentFilter(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
		registerReceiver(mHomePressReceiver, mHomeFilter);
		// 初始化，播放态去掉锁屏
		mKeyguardLock.disableKeyguard();

		InitViews();
		myIntent = getIntent();
		new Thread(new Runnable() {

			@Override
			public void run() {
				if (myIntent != null) {
					livePlayUrl = myIntent.getStringExtra(Constants.LIVE_PLAY_URL);
					mItem = (Item) myIntent.getSerializableExtra(Constants.NEWS_DETAIL_KEY);
					mChild = myIntent.getStringExtra(Constants.NEWS_CHANNEL_CHLID_KEY);
					mVid = myIntent.getStringExtra(Constants.PLAY_VIDEO_VID_KEY);
					SLog.i(TAG, " livePlayUrl--in-->" + livePlayUrl);
					// HttpClient httpClient = null;
					DefaultHttpClient httpClient = null;
					try {
						httpClient = new DefaultHttpClient();
						// -------------------------------
						httpClient.setRedirectHandler(new RedirectHandler() {

							@Override
							public boolean isRedirectRequested(HttpResponse response, HttpContext context) {
								SLog.i(TAG, "isRedirectRequested.context:" + context.toString());
								return false;
							}

							@Override
							public URI getLocationURI(HttpResponse response, HttpContext context) throws ProtocolException {

								return null;
							}
						});
						// -------------------------------

						HttpRequestBase requestBase = new HttpPost(livePlayUrl);
						if(UserDBHelper.getInstance().getUserInfo() != null){
							requestBase.addHeader("cookie", UserDBHelper.getInstance().getUserInfo().creatCookieStr());
							Log.v("lxn", UserDBHelper.getInstance().getUserInfo().creatCookieStr());
						}
						
						HttpContext context = new BasicHttpContext();
						HttpResponse mHttpResponse = httpClient.execute(requestBase, context);

						SLog.i(TAG, " mHttpResponse-->" + mHttpResponse.getStatusLine());
						if (mHttpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_MOVED_TEMPORARILY) {
							Header[] headerLocation = mHttpResponse.getHeaders("Location");
							if (headerLocation.length > 0) {
								livePlayUrl = headerLocation[0].toString().trim();
								int pos = livePlayUrl.lastIndexOf(" ");
								if (pos > 0) {
									livePlayUrl = livePlayUrl.substring(pos + 1);
								}
								SLog.i(TAG, " headerLocation-->" + livePlayUrl);
							}
						}

						if (mHttpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
							HttpUriRequest currentReq = (HttpUriRequest) context.getAttribute(ExecutionContext.HTTP_REQUEST);
							HttpHost currentHost = (HttpHost) context.getAttribute(ExecutionContext.HTTP_TARGET_HOST);
							String currentUrl = (currentReq.getURI().isAbsolute()) ? currentReq.getURI().toString() : (currentHost.toURI() + currentReq.getURI());
							SLog.i(TAG, " currentUrl-->" + currentUrl);
							livePlayUrl = currentUrl;
						}
					} catch (UnknownHostException e3) {
						Log.w(TAG, "unable to resolve host...");
					} catch (Exception e) {
						e.printStackTrace();
						// return false;
					} finally {
						if (httpClient != null) {
							ClientConnectionManager ccm = httpClient.getConnectionManager();
							if (ccm != null) {
								ccm.closeExpiredConnections();
							}
						}
					}
					// livePlayUrl="http://125.39.201.175:1863/3051487004.m3u8?apptype=qqnews_android&pla=unknow&time=1361875824&cdn=zijian";
					SLog.i(TAG, " livePlayUrl----->" + livePlayUrl);
				}
				// livePlayUrl="http://125.39.201.175:1863/3051487004.m3u8?apptype=qqnews_android&pla=unknow&time=1361875824&cdn=zijian";
				// livePlayUrl="http://125.39.201.159:1863/383038466.m3u8?apptype=qqnews_android&pla=unknow&time=1361959231&cdn=zijian";
				// livePlayUrl="http://101.226.54.62:1863/12346.m3u8";
				if (livePlayUrl == null || "".equals(livePlayUrl)) {
					TipsToast.getInstance().showTipsError("未找到视频地址");
					quitActivity();
					return;
				}
				SLog.d(TAG, livePlayUrl);
				Message msg = mHandler.obtainMessage(SHOW_VIDEO);
				mHandler.removeMessages(SHOW_VIDEO);
				mHandler.sendMessageDelayed(msg, 10);
				/*
				 * mVideoView.setVideoPath(livePlayUrl);
				 * mVideoView.requestFocus(); mVideoView.start();
				 */
			}
		}).start();
	}

	@Override
	protected void onStart() {
		// Auto-generated method stub
		// statistics_visit_start_time = System.currentTimeMillis();
		sendStatisticsBeginToBoss();
		super.onStart();
	}

	@Override
	protected void onStop() {
		// Auto-generated method stub
		// statistics_visit_end_time = System.currentTimeMillis();
		sendStatisticsEndToBoss();
		super.onStop();
	}

	@Override
	protected void onPause() {
		// Auto-generated method stub
		if (mVideoView != null && mVideoView.getVisibility() == View.VISIBLE) {
			isplaying = mVideoView.isPlaying();
			mPositionWhenPaused = mVideoView.getCurrentPosition();
			mKeyguardLock.disableKeyguard();
			mVideoView.pause();
		}
		super.onPause();
		WebDev.onPause(this);
	}

	private final BroadcastReceiver mHomePressReceiver = new BroadcastReceiver() {

		final String SYSTEM_DIALOG_REASON_KEY = "reason";
		final String SYSTEM_DIALOG_REASON_HOME_KEY = "homekey";

		@Override
		public void onReceive(Context context, Intent intent) {
			String action = intent.getAction();

			if (action.equals(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)) {
				String reason = intent.getStringExtra(SYSTEM_DIALOG_REASON_KEY);
				if (reason != null && reason.equals(SYSTEM_DIALOG_REASON_HOME_KEY)) {
					// 判断home键，回复锁屏状态
					mKeyguardLock.reenableKeyguard();
				}
			}
		}

	};

	@Override
	protected void onDestroy() {

		if (mHomePressReceiver != null) {
			unregisterReceiver(mHomePressReceiver);
		}
		mKeyguardLock.reenableKeyguard();
		super.onDestroy();
	}

	@Override
	protected void onRestart() {
		fromRestart = true;
		super.onRestart();
	}

	@Override
	protected void onResume() {
		if (mVideoView != null && mVideoView.getVisibility() == View.VISIBLE) {
			mKeyguardLock.disableKeyguard();
			if (fromRestart == true) {
				showLoading();
			}
			fromRestart = false;
			// mVideoView.start();
			if (isplaying) {
				mVideoView.start();
			} else {
				mVideoView.pause();
			}
			/*
			 * if(mPositionWhenPaused >= 0) {
			 * mVideoView.seekTo(mPositionWhenPaused);
			 * if(mVideoView.isPlaying()){ mVideoView.start(); }
			 * mPositionWhenPaused = -1; }
			 */
		}
		super.onResume();
		WebDev.onResume(this);
	}

	private void InitViews() {
		mVideoView = (NewsVideoView) findViewById(R.id.detail_video_view);
		// mVideoView = (VideoView)findViewById(R.id.detail_video_view);
		mLoadingLayout = (LinearLayout) findViewById(R.id.loading_layout);
		// mMediaController = new NewsMediaController(this);
		mMediaController = new PlayerController(this, mVideoView, true);
		// mMediaController = new MediaController(this);
		mVideoView.setMediaController(mMediaController);
		mVideoView.setOnCompletionListener(this);
		mVideoView.setOnErrorListener(this);
		mVideoView.setOnPreparedListener(this);
		mVideoView.setOnVideoSizeChangedListener(this);
		showLoading();
	}

	@Override
	public void onCompletion(MediaPlayer mp) {
		quitActivity();
	}

	@Override
	public boolean onError(MediaPlayer mp, int what, int extra) {
		hideLoading();
		return false;
	}

	@Override
	public void onPrepared(MediaPlayer mp) {
		// hideLoading();
	}

	@Override
	public void onVideoSizeChanged(MediaPlayer mp, int width, int height) {
		hideLoading();
	}

	private void showLoading() {
		mVideoView.setLoadingState(true);
		mLoadingLayout.setVisibility(View.VISIBLE);
	}

	private void hideLoading() {
		mVideoView.setLoadingState(false);
		mLoadingLayout.setVisibility(View.GONE);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
			quitActivity();
			return true;
		} else if (event.getKeyCode() == KeyEvent.KEYCODE_MENU && event.getRepeatCount() > 0) {
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	private void sendStatisticsBeginToBoss() {
		String strNewsID;
		if (mItem == null) {
			SLog.d("#####sendStatisticsToBoss#####", "mItem is empty!");
			return;
		}
		if (mItem.getId() == null || mItem.getId() == "") {
			strNewsID = "-";
		} else {
			strNewsID = mItem.getId();
		}

		if (mVid == null || mVid == "") {
			mVid = "-";
		}

		if (mChild == null || mChild == "") {
			mChild = "-";
		}

		Properties pts = new Properties();
		pts.setProperty(EventId.KEY_CHANNELID, mChild);
		pts.setProperty(EventId.KEY_NEWSID, strNewsID);
		pts.setProperty(EventId.KEY_VID, mVid);
		pts.setProperty(EventId.KEY_ISLIVE, EventId.VALUE_LIVE);
		WebDev.trackCustomBeginKVEvent(this, EventId.ITIL_PLAY_VIDEO_TIME, pts);

	}

	private void sendStatisticsEndToBoss() {
		String strNewsID;
		if (mItem == null) {
			SLog.d("#####sendStatisticsToBoss#####", "mItem is empty!");
			return;
		}
		if (mItem.getId() == null || mItem.getId() == "") {
			strNewsID = "-";
		} else {
			strNewsID = mItem.getId();
		}

		if (mVid == null || mVid == "") {
			mVid = "-";
		}

		if (mChild == null || mChild == "") {
			mChild = "-";
		}

		// mChild:频道 mVid:视频ID 1:表示是直播视频，0表示非直播视频
		// Statistics.getInstance().saveStatistics(Statistics.REPORTED_DATA_VIDEO,
		// StatisticsUtil.generateCustomField(new String[] { mChild, strNewsID,
		// mVid, "1", "" + statistics_visit_start_time, "" +
		// statistics_visit_end_time, "", "", "", "", "" }));

		Properties pts = new Properties();
		pts.setProperty(EventId.KEY_CHANNELID, mChild);
		pts.setProperty(EventId.KEY_NEWSID, strNewsID);
		pts.setProperty(EventId.KEY_VID, mVid);
		pts.setProperty(EventId.KEY_ISLIVE, EventId.VALUE_LIVE);
		WebDev.trackCustomEndKVEvent(this, EventId.ITIL_PLAY_VIDEO_TIME, pts);

	}

	private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case SHOW_VIDEO:
				mVideoView.setVideoPath(livePlayUrl);
				mVideoView.requestFocus();
				mVideoView.start();
				break;
			}
		}
	};

}
