package com.tencent.news.ui.fragment;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.tencent.news.R;
import com.tencent.news.cache.UserDBHelper;
import com.tencent.news.config.Constants;
import com.tencent.news.system.NetStatusReceiver;
import com.tencent.news.ui.view.CommentListView;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.news.utils.SLog;

public class AtFragment extends BaseFragment{
	
	private View atMeCommentView = null;	
	private CommentListView mCommentListView;
		
	public static AtFragment newInstance() {
	    AtFragment f = new AtFragment();
        return f;
    }
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
	
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
		atMeCommentView = inflater.inflate(R.layout.view_atmecomment, container, false);			
		mCommentListView = (CommentListView) atMeCommentView.findViewById(R.id.comment_list);
//		commentViewTips = (TextView) atMeCommentView.findViewById(R.id.commentViewTips);
//		mClickLoadComment = (ImageView) atMeCommentView.findViewById(R.id.offline_download_comment);	
//		mCommentViewRoot = (RelativeLayout) atMeCommentView.findViewById(R.id.comment_layout);		
		applyTheme();
        return atMeCommentView;  
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_INAVAILABLE) {			
			TipsToast.getInstance().showTipsWarning(getResources().getString(R.string.string_http_data_nonet));
		}else{
			mCommentListView.getAtMeComments("","",1);
		}
        
        //SLog.d("###getUserInfo###",UserDBHelper.getInstance().getUserInfo().toString());
        
    }
    
    @Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}
    public void applyTheme() {
        mCommentListView.applyTheme();
    }
    
    
}
