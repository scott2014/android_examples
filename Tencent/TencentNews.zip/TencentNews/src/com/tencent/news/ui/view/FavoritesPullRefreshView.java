package com.tencent.news.ui.view;

import android.content.Context;
import android.support.v4.view.MotionEventCompat;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.AbsListView.OnScrollListener;

import com.tencent.news.R;
import com.tencent.news.ui.view.PullHeadView.OnStateListerer;
import com.tencent.news.ui.view.PullRefreshListView.OnRefreshListener;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.ThemeSettingsHelper;

/**
* @author jianhu
* @version 创建时间：2013-7-3 下午6:19:54
* 收藏无内容下拉刷新界面
*/
public class FavoritesPullRefreshView extends RelativeLayout implements OnStateListerer {

    private static final int STATE_NORMAL = 0;
    private static final int STATE_READY = 1;
    private static final int STATE_PULL = 2;
    private static final int STATE_UPDATING = 3;
    private static final int INVALID_POINTER_ID = -1;
    private PullHeadView mListHeaderView;
    private int mActivePointerId;
    private float mLastY;
    private int mState;
    private boolean hasHeader = true;
    private int mTouchSlop;
    private OnRefreshListener mOnRefreshListener;
    
	private Context mContext = null;
    private TextView mTips = null;
    private ImageView mEmptyIcon = null;
    private Button mLoin = null;
	protected ThemeSettingsHelper themeSettingsHelper = null;
    private boolean isLogin = false;
	

	public FavoritesPullRefreshView(Context context, AttributeSet attrs) {
		super(context, attrs);
		mContext = context;		
		initView();
	}

	public FavoritesPullRefreshView(Context context) {
		super(context);
		mContext = context;
		initView();
	}
	
	public void initView() {
		LayoutInflater.from(mContext).inflate(R.layout.favorites_pull_to_refresh_empty_view, this, true);
		mListHeaderView = (PullHeadView) findViewById(R.id.pull_head_view);
        mEmptyIcon = (ImageView) findViewById(R.id.empty_img);
        mTips = (TextView) findViewById(R.id.empty_text_notice);
        mLoin = (Button) findViewById(R.id.btn_favorites_login);
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(mContext);
        mState = STATE_NORMAL;
        mListHeaderView.setStateListener(this);

	}
	
	public void applyTheme(){		
        themeSettingsHelper.setImageViewSrc(mContext, mEmptyIcon, R.drawable.collection_default);
        mListHeaderView.applyPullHeadViewTheme();
	}
	
    public void setHasLogin(boolean isLogin) {
        this.isLogin = isLogin;
        if(this.isLogin){
            mLoin.setVisibility(View.GONE);
        }else{
            mLoin.setVisibility(View.VISIBLE);
        }
    }
    
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (hasHeader) {
            if (mState == STATE_UPDATING) {
                return super.dispatchTouchEvent(ev);
            }
            final int action = ev.getAction() & MotionEventCompat.ACTION_MASK;
            switch (action) {
            case MotionEvent.ACTION_DOWN:
                mActivePointerId = MotionEventCompat.getPointerId(ev, 0);
                mLastY = ev.getY();
                isFirstViewTop();
                break;
            case MotionEvent.ACTION_MOVE:
                if (mActivePointerId == INVALID_POINTER_ID) {
                    break;
                }

                if (mState == STATE_NORMAL) {
                    isFirstViewTop();
                }

                if (mState == STATE_READY) {
                    final int activePointerId = mActivePointerId;
                    final int activePointerIndex = MotionEventCompat
                            .findPointerIndex(ev, activePointerId);
                    final float y = MotionEventCompat.getY(ev,
                            activePointerIndex);
                    final int deltaY = (int) (y - mLastY);
                    mLastY = y;
                    if (deltaY <= 0 || Math.abs(y) < mTouchSlop) {
                        mState = STATE_NORMAL;
                    } else {
                        mState = STATE_PULL;
                        ev.setAction(MotionEvent.ACTION_CANCEL);
                        super.dispatchTouchEvent(ev);
                    }
                }

                if (mState == STATE_PULL) {
                    final int activePointerId = mActivePointerId;
                    final int activePointerIndex = MotionEventCompat
                            .findPointerIndex(ev, activePointerId);
                    final float y = MotionEventCompat.getY(ev,
                            activePointerIndex);
                    final int deltaY = (int)(y - mLastY);
                    mLastY = y;
                    
                    final int headerHeight = mListHeaderView.getHeight();
                    setHeaderHeight(headerHeight + deltaY * 4/9);
                    return true;
                }

                break;
            case MotionEvent.ACTION_CANCEL:
            case MotionEvent.ACTION_UP:
                mActivePointerId = INVALID_POINTER_ID;
                if (mState == STATE_PULL) {
                    update();
                }
                break;
            case MotionEventCompat.ACTION_POINTER_DOWN:
                final int index = MotionEventCompat.getActionIndex(ev);
                final float y = MotionEventCompat.getY(ev, index);
                mLastY = y;
                mActivePointerId = MotionEventCompat.getPointerId(ev, index);
                break;
            case MotionEventCompat.ACTION_POINTER_UP:
                onSecondaryPointerUp(ev);
                break;
            }
        }
        return super.dispatchTouchEvent(ev);
    }
    
    private void onSecondaryPointerUp(MotionEvent ev) {
        final int pointerIndex = MotionEventCompat.getActionIndex(ev);
        final int pointerId = MotionEventCompat.getPointerId(ev, pointerIndex);
        if (pointerId == mActivePointerId) {
            final int newPointerIndex = pointerIndex == 0 ? 1 : 0;
            mLastY = MotionEventCompat.getY(ev, newPointerIndex);
            mActivePointerId = MotionEventCompat.getPointerId(ev,
                    newPointerIndex);
        }
    }

    private void setHeaderHeight(int height) {
        mListHeaderView.setHeaderHeight(height);
    }

    private boolean isFirstViewTop() {
//        final int count = getChildCount();
//        if (count == 0) {
//            return true;
//        }
//        final int firstVisiblePosition = this.getFirstVisiblePosition();
//        final View firstChildView = getChildAt(0);
//        boolean needs = firstChildView.getTop() == 0
//                && (firstVisiblePosition == 0);
//        if (needs) {
//            mState = STATE_READY;
//        }
//
//        return needs;
        
      mState = STATE_READY;
        return true;
    }

    /**
     * 在下拉刷新完成后更换状态
     * 
     * @param refreshSuccess
     *            是否获取数据成功
     */
    public void onRefreshComplete(boolean refreshSuccess) {
        if (mListHeaderView != null) {
            if (mState == STATE_UPDATING) {
                mListHeaderView.reset(STATE_NORMAL);
            }
            if(refreshSuccess){
                mListHeaderView.updateLastTimeLable();
            }
        }
    }

    public void setState(int state) {
        mState = state;
    }

    private void update() {
        if (mListHeaderView.isUpdateNeeded()) {
              mListHeaderView.startUpdate();
                mState = STATE_UPDATING;
            if (mOnRefreshListener != null) {
                mOnRefreshListener.onRefresh();
            }

        } else {
            mListHeaderView.reset(STATE_NORMAL);
        }
    }
    
    public void setOnRefreshListener(OnRefreshListener onRefreshListener) {
        mOnRefreshListener = onRefreshListener;
    }
    
    public boolean isHasHeader() {
        return hasHeader;
    }

    public void setHasHeader(boolean hasHeader) {
        this.hasHeader = hasHeader;
    }

    /* (non-Javadoc)
     * @see com.tencent.news.ui.view.PullHeadView.OnStateListerer#onReset()
     */
    @Override
    public void onReset() {
        // TODO Auto-generated method stub
        mState = STATE_NORMAL;
    }
    
    public void setPullTimeTag(String ptg) {
        mListHeaderView.setTimeTag(ptg);
    }
    
    public void setLoginButtonClickedListener(OnClickListener listener) {
        mLoin.setOnClickListener(listener);
    }
}
