package com.tencent.news.ui.adapter;

import java.util.ArrayList;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.text.NoCopySpan.Concrete;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import com.tencent.news.R;
import com.tencent.news.command.GetImageRequest;
import com.tencent.news.config.Constants;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.model.pojo.ImageResult;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.shareprefrence.SpNewsHadRead;
import com.tencent.news.system.ExternalStorageReceiver;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.PullRefreshListView;
import com.tencent.news.ui.view.WebViewForCell;
import com.tencent.news.utils.DefaulImageUtil;
import com.tencent.news.utils.ImageCacheNameUtil;
import com.tencent.news.utils.ImageUtil;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.StringUtil;
import com.tencent.news.utils.ThemeSettingsHelper;

public class ChannelListAdapter extends AbsListAdapter<Item> {
	protected int itemType;
	private final int FROM_LOCAL = 0;  //从本地缓存取图
	private final int FROM_REMOTE = 1; //从网络取图
    private static String TAG = "ChannelListAdapter";
    public WebViewForCell mCellWebView;

	private int list_title_color;
	private int list_abstract_color;
	private int list_image_count_color;
	private int list_comment_color;
	private int readed_news_title_color;
	private Drawable list_item_comment_icon;				
	private Drawable photo_list_image_icon;
	private Bitmap DefaultPhotoListImage;
	private Bitmap DefaultTimelineImage;
//    private Drawable mNightListItemBg;
//	private int night_list_title_color;
//	private int night_list_abstract_color;
//	private int night_list_image_count_color;
//	private int night_list_comment_color;
//	private Drawable night_list_item_comment_icon;				
//	private Drawable night_photo_list_image_icon;    
    
	private static Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if (msg != null && msg.obj != null) {
				if(msg.obj instanceof WebView){
					SLog.i(TAG, "handleMessage");
					WebView view=(WebView)msg.obj;
					WebViewTag getWebViewTag=(WebViewTag)view.getTag();
					int contentHeight=(int)(view.getContentHeight()*view.getScale());
					int viewHeight=view.getHeight();
					if(contentHeight>viewHeight){
						viewHeight = contentHeight;
					}
					int helfScreenHeight = (MobileUtil.getScreenHeightIntPx()-MobileUtil.dpToPx(7*2 + 18 ))/2;
					if(helfScreenHeight<viewHeight){
						viewHeight=helfScreenHeight;
					}
					
					//保存显示区域截图
					Bitmap bmp = view.getDrawingCache();
					if(bmp!=null){
						if(bmp.getHeight()>viewHeight){
							bmp=Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), viewHeight);
						}
						getWebViewTag.loading.setVisibility(View.GONE);
						getWebViewTag.loading.getLayoutParams().height=bmp.getHeight();
						getWebViewTag.loading_icon.getLayoutParams().height=bmp.getHeight();
						String filePath = ImageCacheNameUtil.getSmallImageFileName(getWebViewTag.item.getId()+getWebViewTag.theme);
						TaskManager.putImageInCache(ImageType.SMALL_IMAGE, filePath, bmp);
						if (ExternalStorageReceiver.isSDCardMounted) {
							ImageUtil.saveBitmap(bmp, filePath, ImageUtil.QUALITY_HIGH);
						}
					}else{
						if(getWebViewTag.handlenum<1){
							getWebViewTag.handlenum++;
							view.setTag(getWebViewTag);
							
							/*Message myMsg = Message.obtain();
							myMsg.obj = view;
							mHandler.sendMessageDelayed(myMsg, 300);*/
							
							if(view.getUrl().contains("?")){
								view.loadUrl(view.getUrl()+"&loadnum"+getWebViewTag.handlenum+"="+getWebViewTag.handlenum);
							}else{
								view.loadUrl(view.getUrl()+"?loadnum"+getWebViewTag.handlenum+"="+getWebViewTag.handlenum);
							}
						}
						SLog.i(TAG, "handleMessage bmp==null");
					}
				}
			}
		}
	};
	
	public void changeTheme() {
		loadResources();
		notifyDataSetChanged();
	}
	private void loadResources() {
		Resources rs = mContext.getResources();
		
		if(themeSettingsHelper.isNightTheme()){
			list_title_color = rs.getColor(R.color.night_list_title_color);
			list_abstract_color = rs.getColor(R.color.night_list_abstract_color);
			list_image_count_color = rs.getColor(R.color.night_list_image_count_color);
			list_comment_color = rs.getColor(R.color.night_list_comment_color);
			readed_news_title_color = rs.getColor(R.color.night_readed_news_title_color);
			list_item_comment_icon = rs.getDrawable(R.drawable.night_list_item_comment_icon);				
			photo_list_image_icon = rs.getDrawable(R.drawable.night_photo_list_image_icon);
			DefaultPhotoListImage = DefaulImageUtil.getNightDefaultPhotoListImage();
			DefaultTimelineImage = DefaulImageUtil.getNightDefaultTimelineImage();
		}else{
			list_title_color = rs.getColor(R.color.list_title_color);
			list_abstract_color = rs.getColor(R.color.list_abstract_color);
			list_image_count_color = rs.getColor(R.color.list_image_count_color);
			list_comment_color = rs.getColor(R.color.list_comment_color);
			readed_news_title_color = rs.getColor(R.color.readed_news_title_color);
			list_item_comment_icon = rs.getDrawable(R.drawable.list_item_comment_icon);				
			photo_list_image_icon = rs.getDrawable(R.drawable.photo_list_image_icon);
			DefaultPhotoListImage = DefaulImageUtil.getDefaultPhotoListImage();
			DefaultTimelineImage = DefaulImageUtil.getDefaultTimelineImage();
		}	
	}
	public ChannelListAdapter(Context context, ListView listView) {
		this.mContext = context;
		this.mListView = listView;
		loadResources();
		mDataList = new ArrayList<Item>();
		((PullRefreshListView) mListView).setSartListener(this);	
		SettingInfo settingInfo = SettingObservable.getInstance().getData();
		if (settingInfo != null && settingInfo.isIfTextMode()) {
			itemType = Constants.TYPE_ITEM_TEXT;
		} else {
			itemType = Constants.TYPE_ITEM_IMAGE;
		}
		//helfHeight = (MobileUtil.getScreenHeightIntPx()-MobileUtil.dpToPx(7*2 + 18 ))/2;
	}

	@Override
	public int getItemViewType(int position) {			
		Item item = mDataList.get(position);			
	    if(itemType == Constants.TYPE_ITEM_IMAGE && item !=null && 
	        item.getArticletype()!=null && item.getArticletype().trim().equals("1")){	    	
	    	styleType = Constants.TYPE_ITEM_THREE_PHOTO;	    	
	    }else if(item !=null && 
		        item.getArticletype()!=null && item.getArticletype().trim().equals("1101")){
	    	styleType = Constants.TYPE_ITEM_CELL;
	    }else{
	    	styleType = itemType;
	    }
		return styleType;
	}
	
	@Override
	public void changeStyleMode(int style) {
		this.itemType = style;
		notifyDataSetChanged();
	}
	
	
	@Override
	public int getViewTypeCount() {
		// Auto-generated method stub
		return 4;
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder = null;			
		int type = getItemViewType(position);
		SLog.i(TAG,"文章类型"+ String.valueOf(type));
		switch (type) {
		case Constants.TYPE_ITEM_TEXT:
			convertView = setTextMode(convertView, position, holder);
			break;
		case Constants.TYPE_ITEM_IMAGE:
			convertView = setImageMode(convertView, position, holder);
			break;
		case Constants.TYPE_ITEM_THREE_PHOTO:
			convertView = setMoreImageMode(convertView, position, holder);
			break;
		case Constants.TYPE_ITEM_CELL:
			convertView = mCellWebView;
			break;
		default:
			break;
		}
		//SLog.v("ChannelListAdapter  getView ", "" + position);
		return convertView;
	}

	private View setMoreImageMode(View convertView, int position, ViewHolder holder){			
		
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = LayoutInflater.from(mContext).inflate(R.layout.news_list_item_photos, null);			
			holder.title = (TextView)convertView.findViewById(R.id.list_title_text);			
			holder.commentIcon = (ImageView) convertView.findViewById(R.id.list_comments_image);
			holder.comments = (TextView) convertView.findViewById(R.id.list_comments_text);		
			holder.imageIcon = (ImageView) convertView.findViewById(R.id.list_image_count_icon);			
			holder.imageCount = (TextView) convertView.findViewById(R.id.list_image_count_text);
			holder.imageLeft = (ImageView)convertView.findViewById(R.id.left_image);			
			holder.imageMid = (ImageView)convertView.findViewById(R.id.mid_image);
			holder.imageRight = (ImageView)convertView.findViewById(R.id.right_image);
			convertView.setTag(holder);

			int paddingL = convertView.getPaddingLeft();
			int paddingR = convertView.getPaddingRight();
			int paddingT = convertView.getPaddingTop();
			int paddingB = convertView.getPaddingBottom();
			themeSettingsHelper.setViewBackgroud(mContext, convertView, R.drawable.news_item_bg_selector);
			convertView.setPadding(paddingL, paddingT, paddingR, paddingB);
		} else {
			holder = (ViewHolder) convertView.getTag();
			
			if(holder.theme != themeSettingsHelper.getCurrentThemePackage()) {
				holder.theme = themeSettingsHelper.getCurrentThemePackage();
				int paddingL = convertView.getPaddingLeft();
				int paddingR = convertView.getPaddingRight();
				int paddingT = convertView.getPaddingTop();
				int paddingB = convertView.getPaddingBottom();
				themeSettingsHelper.setViewBackgroud(mContext, convertView, R.drawable.news_item_bg_selector);
				convertView.setPadding(paddingL, paddingT, paddingR, paddingB);
			}
		}		
		
		applyThemeInItem(holder);
		
		Item item = mDataList.get(position);
		if(item==null || item.getId()==null){
			return convertView;
		}		
		holder.id = item.getId();
		holder.articletype = item.getArticletype();
		setTextData(item, holder);		
		
		if (!((PullRefreshListView) mListView).isBusy()) {
			setThreeSmallImage(item, holder, FROM_REMOTE);			
		} else {
			setThreeSmallImage(item, holder, FROM_LOCAL);
		}
		return convertView;		
	}
	
	private View setImageMode(View convertView, int position, ViewHolder holder) {
	    long begin = System.currentTimeMillis();
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = LayoutInflater.from(mContext).inflate(R.layout.news_list_item, null);
			holder.title = (TextView) convertView.findViewById(R.id.list_title_text);
			holder.stract = (TextView) convertView.findViewById(R.id.list_abstract_text);
			holder.comments = (TextView) convertView.findViewById(R.id.list_comments_text);
			holder.image = (ImageView) convertView.findViewById(R.id.list_item_image);			
			holder.flag = (ImageView) convertView.findViewById(R.id.list_item_flag);
			holder.commentIcon = (ImageView) convertView.findViewById(R.id.list_comments_image);
			holder.theme = themeSettingsHelper.getCurrentThemePackage();
			convertView.setTag(holder);
			
			int paddingL = convertView.getPaddingLeft();
			int paddingR = convertView.getPaddingRight();
			int paddingT = convertView.getPaddingTop();
			int paddingB = convertView.getPaddingBottom();
			themeSettingsHelper.setViewBackgroud(mContext, convertView, R.drawable.news_item_bg_selector);
			convertView.setPadding(paddingL, paddingT, paddingR, paddingB);
		} else {
			holder = (ViewHolder) convertView.getTag();
			if(holder.theme != themeSettingsHelper.getCurrentThemePackage()) {
				holder.theme = themeSettingsHelper.getCurrentThemePackage();
				int paddingL = convertView.getPaddingLeft();
				int paddingR = convertView.getPaddingRight();
				int paddingT = convertView.getPaddingTop();
				int paddingB = convertView.getPaddingBottom();
				themeSettingsHelper.setViewBackgroud(mContext, convertView, R.drawable.news_item_bg_selector);
				convertView.setPadding(paddingL, paddingT, paddingR, paddingB);
			}
		}

		applyThemeInItem(holder);
		SLog.v("rz", "tick : " + (System.currentTimeMillis() - begin));
		Item item = mDataList.get(position);
		if(item==null || item.getId()==null){
			return convertView;
		}
		holder.id = item.getId();
		holder.articletype = item.getArticletype();
		setTextData(item, holder);		
		
		SLog.v("rz", "tick : " + (System.currentTimeMillis() - begin));
		// TODO : RZ
		if (!((PullRefreshListView) mListView).isBusy()) {
			setSingleImage(item, holder, FROM_REMOTE);			
		} else {
			setSingleImage(item, holder, FROM_LOCAL);
		}
		SLog.v("rz", "tick : set image Mode : " + (System.currentTimeMillis() - begin));
		SLog.v("rz", "-----------------------------");
		return convertView;
	}

	private View setTextMode(View convertView, int position, ViewHolder holder) {
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = LayoutInflater.from(mContext).inflate(R.layout.news_list_text_item, null);
			holder.title = (TextView) convertView.findViewById(R.id.list_title_text);
			holder.stract = (TextView) convertView.findViewById(R.id.list_abstract_text);
			holder.commentIcon = (ImageView) convertView.findViewById(R.id.list_comments_image);
			holder.comments = (TextView) convertView.findViewById(R.id.list_comments_text);			
			holder.flag = (ImageView) convertView.findViewById(R.id.list_item_flag);
			holder.imageIcon = (ImageView) convertView.findViewById(R.id.list_image_count_icon);
			holder.imageCount = (TextView) convertView.findViewById(R.id.list_image_count_text);
			
			int paddingL = convertView.getPaddingLeft();
			int paddingR = convertView.getPaddingRight();
			int paddingT = convertView.getPaddingTop();
			int paddingB = convertView.getPaddingBottom();
			themeSettingsHelper.setViewBackgroud(mContext, convertView, R.drawable.news_item_bg_selector);
			convertView.setPadding(paddingL, paddingT, paddingR, paddingB);
			
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
			
			if(holder.theme != themeSettingsHelper.getCurrentThemePackage()) {
				holder.theme = themeSettingsHelper.getCurrentThemePackage();
				int paddingL = convertView.getPaddingLeft();
				int paddingR = convertView.getPaddingRight();
				int paddingT = convertView.getPaddingTop();
				int paddingB = convertView.getPaddingBottom();
				themeSettingsHelper.setViewBackgroud(mContext, convertView, R.drawable.news_item_bg_selector);
				convertView.setPadding(paddingL, paddingT, paddingR, paddingB);
			}
		}
		
		applyThemeInItem(holder);
		
		Item item = mDataList.get(position);		
		if(item != null && item.getId() != null){					
			if (SpNewsHadRead.isNewsHadRead(item.getId())) {
				holder.title.setTextColor(readed_news_title_color);
			} else {
				holder.title.setTextColor(list_title_color);
			}			
			holder.title.setText(StringUtil.replaceBlank(item.getTitle()));
			String stract = null;
			if (item.getBstract() != null) {
				stract = item.getBstract().trim();
				if (stract.length() > 30) {
					stract = stract.substring(0, 30);
				}
			}
			stract = StringUtil.replaceBlank(stract);
			stract = StringUtil.StringFilter(stract);
			holder.stract.setText(stract);
			if (Integer.parseInt(item.getCommentNum()) > 10000) {
				holder.comments.setText(StringUtil.tenTh2wan(item.getCommentNum()));
			} else {
				holder.comments.setText(item.getCommentNum());
			}

			if (item.getArticletype().equals("1")) {
				holder.imageIcon.setVisibility(View.VISIBLE);
				holder.imageCount.setVisibility(View.VISIBLE);
			} else {
				holder.imageIcon.setVisibility(View.GONE);
				holder.imageCount.setVisibility(View.GONE);
			}
			holder.imageCount.setText(item.getImageCount());
			setItemFlag(holder, item.getFlag());
		}
		return convertView;
	}

	protected static class ViewHolder {
		public TextView title;
		String id;
		String articletype;
		TextView stract;
		TextView comments;
		ImageView image;
		ImageView imageLeft;   //列表页三个小图中最左边的一个
		ImageView imageMid;    //列表页三个小图中中间的一个
		ImageView imageRight;  //列表页三个小图中最右边的一个
		ImageView flag;
		ImageView commentIcon;			
		ImageView imageIcon;
		TextView imageCount;
		WebView itemWebView;
		LinearLayout loading;
		ImageView loading_icon;
		int theme;
	}

	protected static class Tag{
		String id;	  //与ViewHolder中的id对应
		int position;  //如果是一张图position=0，如果是三张小图position=1，2，3分别表示左中右
	}
	
	protected static class WebViewTag{
		Item item;
		LinearLayout loading;
		ImageView loading_icon;
		int error_code;
		String theme;
		int handlenum;
	}
	
	@Override
	public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm, String path) {
		Tag mTag = (Tag) tag;
		switch (imageType) {
		case SMALL_IMAGE:
			int countImage = mListView.getChildCount();
			for (int i = 0; i < countImage; i++) {
				ViewHolder holder = (ViewHolder) mListView.getChildAt(i).getTag();
				if (holder != null) {
					if(((String)mTag.id).equals(holder.id)){
						switch(mTag.position){
							case 0:
								if(bm!=null){
									holder.image.setImageBitmap(bm);
								}									
								break;
							case 1:
								setSmallImage(holder.imageLeft,bm);
								break;
							case 2:
								setSmallImage(holder.imageMid,bm);
								break;								
							case 3:
								setSmallImage(holder.imageRight,bm);
								break;
							default:
							    break;
						}	
						break;
					}
				}
			}
			break;
		default:
			break;
		}
	}

	@Override
	public void onImageRecvError(ImageType imageType, Object tag, int retCode) {
	}

	protected void setTextData(Item item, ViewHolder holder) {
		if(item == null || holder==null || item.getId()==null){
			return;
		}
		if (SpNewsHadRead.isNewsHadRead(item.getId())) {
			holder.title.setTextColor(readed_news_title_color);
		} else {
			holder.title.setTextColor(list_title_color);
		}
		if (item.getTitle() != null) {
			holder.title.setText(item.getTitle().trim());
		}

		String stract = item.getBstract();
		if (stract != null && stract.length() > 28) {
			stract = stract.substring(0, 28);
		}
		if(holder.stract!=null){
			holder.stract.setText(stract);
		}
		if (Long.parseLong(item.getCommentNum()) > 10000) {
			holder.comments.setText(StringUtil.tenTh2wan(item.getCommentNum()));
		} else {
			holder.comments.setText(item.getCommentNum());
		}
		if(holder.imageCount!=null){
			holder.imageCount.setText(item.getImageCount());
		}
		if(holder.flag!=null){
			setItemFlag(holder, item.getFlag());
		}
	}

	private void setItemFlag(ViewHolder holder, String flag) {
		if ( flag == null || "0".equals(flag)) {
			holder.flag.setVisibility(View.GONE);
		} else {
			holder.flag.setVisibility(View.VISIBLE);
			if(themeSettingsHelper.isNightTheme()){
				setNightFlagIcon(holder.flag, flag);
			}else{
				setFlagIcon(holder.flag, flag);
			}
		}
	}

	private void setFlagIcon(ImageView imgView,String flag){			
		if ("1".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_scoop_icon);
		} else if ("2".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_tote_icon);
		} else if ("3".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_video_icon);
		} else if ("4".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_special_icon);
		} else if ("5".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_flash_icon);
		} else if ("6".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_live_icon);
		} else if ("7".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_redian);
		}
	}
	
	private void setNightFlagIcon(ImageView imgView,String flag){			
		if ("1".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_scoop_icon);
		} else if ("2".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_tote_icon);
		} else if ("3".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_video_icon);
		} else if ("4".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_special_icon);
		} else if ("5".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_flash_icon);
		} else if ("6".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_live_icon);
		} else if ("7".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_redian);
		}
	}
	
	@Override
	public void serListViewBusy(int currPosition, int tag) {
		if (itemType == Constants.TYPE_ITEM_TEXT) {
			return;
		}
		if (currPosition >= 0 && currPosition < mDataList.size()) {
			Item item = mDataList.get(currPosition);
			ViewHolder holder = (ViewHolder)mListView.getChildAt(tag).getTag();	
			if(item !=null && item.getArticletype()!=null && item.getArticletype().trim().equals("1")){
				setThreeSmallImage(item, holder, FROM_REMOTE);
			}else{
				setSingleImage(item, holder, FROM_REMOTE);
			}
		}
	}
	
    //夜间模式的处理
	public void applyThemeInItem(ViewHolder holder){
		if(holder==null){
			return;
		}

		if (holder.title != null) {
			holder.title.setTextColor(list_title_color);
		}
		if (holder.stract != null) {
			holder.stract.setTextColor(list_abstract_color);
		}
		if (holder.imageCount != null) {
			holder.imageCount.setTextColor(list_image_count_color);
		}
		if (holder.comments != null) {
			holder.comments.setTextColor(list_comment_color);
		}
		if (holder.commentIcon != null) {
			holder.commentIcon.setImageDrawable(list_item_comment_icon);
		}

		if (holder.imageIcon != null) {
			holder.imageIcon.setImageDrawable(photo_list_image_icon);
		}
	}
	
	private void setSingleImage(Item item, ViewHolder holder, int from){		
		
		if(item==null || holder==null || holder.id==null){
			return;
		}
		
		String url = "";		
		Bitmap bitmap = null;	
		Tag tag = new Tag();
		tag.id = holder.id;
		tag.position = 0;
		//url = (item.getThumbnails_qqnews_photo() != null && item.getThumbnails_qqnews_photo().length>0)?item.getThumbnails_qqnews_photo()[0]:"";
		url = (item.getThumbnails_qqnews() != null && item.getThumbnails_qqnews().length > 0) ? item.getThumbnails_qqnews()[0] : "";
		//url = "CELLFIN201305220000";
		
		bitmap = getBitMapImage(item, tag, Constants.TYPE_ITEM_IMAGE, url, from);	
		if(bitmap!=null && holder.image!=null){
			holder.image.setImageBitmap(bitmap);
		}		
	}
	
	private void setThreeSmallImage(Item item, ViewHolder holder, int from){
		String url = "";			
		Bitmap smallBitmapArr[] = new Bitmap[3];
		int mType = Constants.TYPE_ITEM_THREE_PHOTO;
		if(holder!=null && holder.id!=null && item!=null && item.getThumbnails_qqnews() != null && item.getThumbnails_qqnews().length>0){				
			int size = item.getThumbnails_qqnews().length>4? 4:item.getThumbnails_qqnews().length;
			for(int i=1; i< size; i++){				
				Tag tag = new Tag();
				tag.id = holder.id;
				tag.position = i;
				url = (item.getThumbnails_qqnews()[i]!=null && item.getThumbnails_qqnews()[i].length()>0)? item.getThumbnails_qqnews()[i]:"";
				smallBitmapArr[i-1]  = getBitMapImage(item, tag, mType, url, from);
			}			
			setSmallImage(holder.imageLeft,smallBitmapArr[0]);
			setSmallImage(holder.imageMid,smallBitmapArr[1]);
			setSmallImage(holder.imageRight,smallBitmapArr[2]);
		}		
	}
	
	protected Bitmap getBitMapImage(Item item, Tag tag,  int type, String url, int from){	
		
		if(url==null || url==""){
			return  getDefaultBitmap(type);
		}
		
		Bitmap retBitmap = null;	
		ImageResult result = null;		
		GetImageRequest request = new GetImageRequest();		
		
		request.setGzip(false);
		request.setTag(tag);
		request.setUrl(url);
		if(from == FROM_REMOTE){
			result = TaskManager.startSmallImageTask(request,this);
		}else{
			result = TaskManager.getLocalIconImage(request, this);
		}
		
		if(result.isResultOK() && result.getRetBitmap() != null){
			retBitmap = result.getRetBitmap();				
		}else{
			retBitmap = getDefaultBitmap(type);
		}		
		return retBitmap;
	}
	
	protected Bitmap getDefaultBitmap(int type){
		if(type==Constants.TYPE_ITEM_THREE_PHOTO){
			return DefaultPhotoListImage;
		}else{	
			return DefaultTimelineImage;
		}
	}
	
	private void setSmallImage(ImageView srcImage, Bitmap bm) {
		
		if(bm == null || srcImage==null){
			return;
		}
		
		int desImageViewWidth = 0;
		int desImageViewHeight = 0;
		int totalWidth = MobileUtil.getScreenWidthIntPx()-MobileUtil.dpToPx(7*2 + 18 );
			
		desImageViewWidth = totalWidth/3;
		desImageViewHeight = (int)(desImageViewWidth*0.7);
		LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) srcImage.getLayoutParams();
		lp.width = desImageViewWidth;
		lp.height = desImageViewHeight;
		srcImage.setLayoutParams(lp);
		srcImage.setScaleType(ScaleType.FIT_XY);	
		srcImage.setImageBitmap(bm);
	}	
}
