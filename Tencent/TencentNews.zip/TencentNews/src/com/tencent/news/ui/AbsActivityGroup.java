package com.tencent.news.ui;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import android.app.ActivityGroup;
import android.app.LocalActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.FrameLayout;
import com.tencent.news.R;
import com.tencent.news.boss.EventId;
import com.tencent.news.command.HttpDataResponse;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.pojo.ActivityViewInfo;
import com.tencent.news.model.pojo.Channel;
import com.tencent.news.model.pojo.ChannelList;
import com.tencent.news.system.ClearCacheReceiver;
import com.tencent.news.system.NetStatusReceiver;
import com.tencent.news.system.NetTipsReceiver;
import com.tencent.news.ui.view.ChannelBarBase;
import com.tencent.news.ui.view.ChannelBarBase.ChannelBarClickListener;
import com.tencent.news.ui.view.ChannelBarBase.ChannelBarRefreshListener;
import com.tencent.news.ui.view.NetTipsBar;
import com.tencent.news.ui.view.TitleBar;
import com.tencent.news.ui.view.ViewPagerEx;
import com.tencent.news.ui.view.ViewPagerEx.onPagerFinishedListener;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.ThemeSettingsHelper;
import com.tencent.news.utils.ThemeSettingsHelper.ThemeCallback;
import com.tencent.omg.webdev.WebDev;

public abstract class AbsActivityGroup extends ActivityGroup implements HttpDataResponse, ThemeCallback {
	private final static String TAG = AbsActivityGroup.class.getSimpleName();
	protected List<Channel> mChannels;
	protected ChannelBarBase mChannelBar = null;
	protected LocalActivityManager localManager;
	protected TitleBar mTitleBar = null;
	protected int nCurrChannel = 0;
	protected ViewPagerEx mChannelViewPager;
	protected List<ActivityViewInfo> mListActivityViews = null;
	protected NetTipsBar mNetTipsBar = null;
	protected NetTipsReceiver mNetTipsReceiver;
	protected ClearCacheReceiver mClearCacheReceiver;
	protected int nIndex = 0;
	protected NewsHandler mHandler = null;
	protected int nCount;
	protected Boolean mOneChannelHide = true;// 只剩一个频道时隐藏,如不隐藏在子类中设为false
	protected boolean mIsUpdate = false;
	protected ThemeSettingsHelper themeSettingsHelper = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContainerView(savedInstanceState);
		getIntentData(getIntent());
		initViewPager();
		showConnectState();
		initListener();
		registerNetTipsReceiver();
		getChannelData();
		initTheme();
	}

	private void initTheme() {
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(this);
		themeSettingsHelper.registerThemeCallback(this);
		themeSettingsHelper.loadDefaultTheme(this);
	}

	private void getIntentData(Intent intent) {
		localManager = getLocalActivityManager();
		mHandler = new NewsHandler(this);
		ChannelList ChannelList = mChannelBar.getChannelList();
		mChannels = ChannelList.getChannelList();
		if (intent != null) {
			String str = intent.getStringExtra(Constants.WEIXIN_CHANNEL);
			if (str != null && mChannels != null) {
				for (int i = 0; i < mChannels.size(); i++) {
					Channel channel = mChannels.get(i);
					if (str.equals(channel.getChlid())) {
						nIndex = i;
						break;
					}
				}
			}
		}
	}

	protected static class NewsHandler extends Handler {
		private WeakReference<AbsActivityGroup> mOuterClass;

		NewsHandler(AbsActivityGroup activity) {
			mOuterClass = new WeakReference<AbsActivityGroup>(activity);
		}

		@Override
		public void handleMessage(android.os.Message msg) {
			super.handleMessage(msg);
			AbsActivityGroup mTheClass = mOuterClass.get();
			if (msg != null) {
				if (msg.obj != null) {
					Boolean isTips = (Boolean) msg.obj;
					mTheClass.setLayout(isTips.booleanValue());
				}
				switch (msg.what) {
				case Constants.WHAT_CHANNEL_LOAD:
					mTheClass.mChannelBar.refresh();
					break;
				default:
					break;
				}
			}
		}
	}

	private void initViewPager() {
		mListActivityViews = new ArrayList<ActivityViewInfo>();
		if (mChannels == null) {
			SLog.v("HomeChannelActivity", "HomeChannelActivity loading the empty channel.");
			return;
		}
		nCount = mChannels.size();
		// 预加载2个频道
		for (int i = 0; i < nCount; ++i) {
			if (i < 2) {
				Channel channel = mChannels.get(i);
				Intent intent = new Intent();
				intent.setClass(this, getChannelClassName(channel));
				intent.putExtra(Constants.NEWS_CHLIDE_CHANNEL, channel.getChlid());
				intent.putExtra(Constants.IS_FROM_VIEWPAGER, true);
				intent.putExtra(Constants.IS_START_CHANNEL, i == 0 ? true : false);
				intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

				Window mWindow = localManager.startActivity(channel.getChlid(), intent);
				ActivityViewInfo avInfo = new ActivityViewInfo(channel.getChlid(), mWindow.getDecorView());
				mListActivityViews.add(avInfo);

			} else
				mListActivityViews.add(new ActivityViewInfo(null, null));

		} // of for
		mChannelViewPager.setOffscreenPageLimit(1);
		mChannelViewPager.setAdapter(new NewsChannelPagerAdapter(this, mListActivityViews));
		setCurrentChannel(nIndex);
		mChannelViewPager.setOnPageChangeListener(new ChannelOnPageChangeListener());
		mChannelViewPager.setPageMargin(2);
	}

	private void initListener() {
		mChannelBar.setOnChannelBarClickListener(new ChannelBarClickListener() {
			@Override
			public void onSelected(int nIndex) {
				mIsUpdate = true;
				nCurrChannel = nIndex;
				mChannelViewPager.setCurrentItem(nIndex, false);
			}

		});

		mChannelBar.setOnChannelBarRefreshListener(new ChannelBarRefreshListener() {
			@Override
			public void onRefresh(int nIndex) {
				ActivityViewInfo avInfoDefault = null;
				ActivityViewInfo avInfoCurrent = null;
				String firstChannel = "";

				if (mChannels != null && mChannels.size() > 0) {
					avInfoDefault = mListActivityViews.get(0);
					avInfoCurrent = mListActivityViews.get(nCurrChannel);
					firstChannel = mChannels.get(0).getChlid();
				}

				ChannelList ChannelList = mChannelBar.getChannelList();
				mChannels = ChannelList.getChannelList();

				if (mChannels != null && mChannels.size() > 0) {
					mChannelViewPager.removeAllViews();
					mListActivityViews.clear();
					RefreshInitData(avInfoDefault, avInfoCurrent, firstChannel, nIndex);

					nCurrChannel = nIndex;
					mChannelViewPager.setCurrentItem(nIndex, false);
				}
			}
		});

		mTitleBar.setTopClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				if (nCurrChannel < 0 || nCurrChannel >= mChannels.size())
					return;
				AbsChannelActivityNew absChannel = (AbsChannelActivityNew) localManager.getActivity(mChannels.get(nCurrChannel).getChlid());
				if (absChannel != null) {
					absChannel.setSelection();
				}
			}

		});

		mTitleBar.setSettingClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				
				WebDev.trackCustomEvent(AbsActivityGroup.this, EventId.BOSS_CLICK_SOFT_MENU);
				
				((MainActivity) getParent()).popUpMenu();
			}
		});

		mChannelViewPager.setPagerFinishedListener(new onPagerFinishedListener() {

			@Override
			public void onScrollFinished() {
				// TODO Auto-generated method stub
				if (NetStatusReceiver.netStatus != NetStatusReceiver.NETSTATUS_INAVAILABLE) {
					AbsChannelActivityNew absChannel = (AbsChannelActivityNew) localManager.getActivity(mChannels.get(nCurrChannel).getChlid());
					if (absChannel != null) {
						absChannel.getNewDataSilent(false);
					}
				}
			}
		});
	}

	private void RefreshInitData(ActivityViewInfo avInfoDefault, ActivityViewInfo avInfoCurrent, String firstChannel, int nIndex) {
		int nSize = mChannels.size();
		nCount = nSize;
		for (int i = 0; i < nSize; ++i) {
			mListActivityViews.add(new ActivityViewInfo(null, null));
		}
		Channel channel = mChannels.get(0);
		if (channel.equals(firstChannel)) {
			mListActivityViews.set(0, avInfoDefault);
		}
		if (nIndex > 0) {
			mListActivityViews.set(nIndex, avInfoCurrent);
		}

		mChannelViewPager.setOffscreenPageLimit(1);
		mChannelViewPager.setAdapter(new NewsChannelPagerAdapter(AbsActivityGroup.this, mListActivityViews));
		setCurrentChannel(nIndex);
		mChannelViewPager.setOnPageChangeListener(new ChannelOnPageChangeListener());
		mChannelViewPager.setPageMargin(2);

		showConnectState();
	}

	private void registerNetTipsReceiver() {
		IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
		mNetTipsReceiver = new NetTipsReceiver(mHandler);
		this.registerReceiver(mNetTipsReceiver, filter);

		IntentFilter filter2 = new IntentFilter(Constants.CLEAR_CAHCE_ACTION);
		mClearCacheReceiver = new ClearCacheReceiver(mNetTipsBar);
		this.registerReceiver(mClearCacheReceiver, filter2);

	}

	protected void showConnectState() {
		if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_INAVAILABLE) {
			setLayout(false);
		} else {
			setLayout(true);
		}
	}

	public int getCurrentChannel() {
		return this.nCurrChannel;
	}

	public void setCurrentChannel(int nIndex) {
		if (nCount == 0 || nCount <= nIndex) {
			return;
		}
		nCurrChannel = nIndex;
		mChannelBar.setActive(nIndex);
		mChannelViewPager.setCurrentItem(nIndex, false);
	}

	protected void setLayout(boolean bFlag) {
		// 只剩一个频道时判断是否隐藏
		if (nCount <= 1 && mOneChannelHide == true) {
			mChannelBar.setVisibility(View.GONE);
			if (bFlag) {
				mNetTipsBar.setVisibility(View.GONE);
				FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) mChannelViewPager.getLayoutParams();
				lp.topMargin = MobileUtil.dpToPx(44);
				mChannelViewPager.setLayoutParams(lp);
			} else {
				mNetTipsBar.setVisibility(View.VISIBLE);
				FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) mChannelViewPager.getLayoutParams();
				lp.topMargin = MobileUtil.dpToPx(79);
				mChannelViewPager.setLayoutParams(lp);

				FrameLayout.LayoutParams lp1 = (FrameLayout.LayoutParams) mNetTipsBar.getLayoutParams();
				lp1.topMargin = MobileUtil.dpToPx(44);
				mNetTipsBar.setLayoutParams(lp1);
			}
		} else {
			mChannelBar.setVisibility(View.VISIBLE);
			if (bFlag) {
				mNetTipsBar.setVisibility(View.GONE);
				FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) mChannelViewPager.getLayoutParams();
				lp.topMargin = MobileUtil.dpToPx(79);
				mChannelViewPager.setLayoutParams(lp);
			} else {
				mNetTipsBar.setVisibility(View.VISIBLE);
				FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) mChannelViewPager.getLayoutParams();
				lp.topMargin = MobileUtil.dpToPx(121);
				mChannelViewPager.setLayoutParams(lp);
			}
		}

	}

	public class NewsChannelPagerAdapter extends PagerAdapter {
		public List<ActivityViewInfo> mListActivityViewInfos;
		private Context mContext;

		public NewsChannelPagerAdapter(Context mContext, List<ActivityViewInfo> mListActivityViews) {
			this.mContext = mContext;
			mListActivityViewInfos = mListActivityViews;
		}

		@Override
		public void destroyItem(View arg0, int arg1, Object arg2) {
			if (arg1 >= mListActivityViews.size()) {
				return;
			}
			ActivityViewInfo avInfo = mListActivityViews.get(arg1);

			if (avInfo.mView != null) {

				localManager.destroyActivity(avInfo.mActivityId, true);
				((ViewPager) arg0).removeView(avInfo.mView);
				avInfo.mView = null;
				avInfo.mActivityId = null;
			}

		}

		@Override
		public void finishUpdate(View arg0) {

		}

		@Override
		public int getCount() {
			return mListActivityViewInfos.size();
		}

		@Override
		public Object instantiateItem(View arg0, int arg1) {
			ActivityViewInfo avinfo = mListActivityViewInfos.get(arg1);

			if (avinfo.mView == null) {
				Channel channel = mChannels.get(arg1);
				if (channel == null) {
					SLog.v("NewsChannelPagerAdapter", "instantiateItem channel is null.");
					return null;
				}
				Intent intent = new Intent();
				intent.setClass(mContext, getChannelClassName(channel));
				intent.putExtra(Constants.NEWS_CHLIDE_CHANNEL, channel.getChlid());
				intent.putExtra(Constants.IS_FROM_VIEWPAGER, true);
				intent.putExtra(Constants.IS_START_CHANNEL, false);
				intent.putExtra(Constants.IS_CURRENT_CHANNEL, nCurrChannel == arg1 ? true : false);
				intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				if (channel.getChlid() != null || channel.getChlid() != "") {
					Window mWindow = localManager.startActivity(channel.getChlid(), intent);
					avinfo.mActivityId = channel.getChlid();
					avinfo.mView = mWindow.getDecorView();
				} else {
					avinfo.mActivityId = null;
					avinfo.mView = null;
				}
			}
			((ViewPager) arg0).addView(avinfo.mView, 0);
			return avinfo.mView;

		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == (arg1);
		}

		@Override
		public void restoreState(Parcelable arg0, ClassLoader arg1) {
		}

		@Override
		public Parcelable saveState() {
			return null;
		}

		@Override
		public void startUpdate(View arg0) {
		}

		public int getItemPosition(Object object) {
			return POSITION_NONE;
		}
	}

	public class ChannelOnPageChangeListener implements OnPageChangeListener {

		@Override
		public void onPageScrollStateChanged(int arg0) {

			switch (arg0) {
			case ViewPager.SCROLL_STATE_DRAGGING:
				SLog.i("ViewPager", "ViewPager.SCROLL_STATE_DRAGGING");
				break;
			case ViewPager.SCROLL_STATE_SETTLING:
				SLog.i("ViewPager", "ViewPager.SCROLL_STATE_SETTLING");
				break;
			case ViewPager.SCROLL_STATE_IDLE:
				SLog.i("ViewPager", "ViewPager.SCROLL_STATE_IDLE");
				break;
			}

		}

		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {
			SLog.i("ViewPager", "arg0:arg1 —— " + arg0 + " : " + arg1);
			mChannelBar.scrollBySlide(arg0, arg1);
		}

		@Override
		public void onPageSelected(int arg0) {
			mChannelBar.setFocusByImageViewBg(arg0);
			nCurrChannel = arg0;
			mChannelBar.setSelectedState(arg0);
			if (NetStatusReceiver.netStatus != NetStatusReceiver.NETSTATUS_INAVAILABLE && mIsUpdate) {
				mIsUpdate = false;
				AbsChannelActivityNew absChannel = (AbsChannelActivityNew) localManager.getActivity(mChannels.get(nCurrChannel).getChlid());
				if (absChannel != null) {
					absChannel.getNewDataSilent(false);
				}
			}
			Properties pts = new Properties();
			pts.setProperty(EventId.KEY_CHANNELID, mChannels.get(nCurrChannel).getChlid());
			pts.setProperty(EventId.KEY_TIMESTAMP, "" + System.currentTimeMillis());
			WebDev.trackCustomEvent(AbsActivityGroup.this, EventId.BOSS_VIEW_CHANNEL_TIMESTAMP, pts);

		}
	}

	public void setRefreshData() {
		if (nCurrChannel < 0 || nCurrChannel >= mChannels.size())
			return;
		AbsChannelActivityNew absChannel = (AbsChannelActivityNew) localManager.getActivity(mChannels.get(nCurrChannel).getChlid());

		if (absChannel != null) {
			absChannel.getNewData();
		}

	}

	@Override
	public void onHttpRecvOK(HttpTag tag, Object result) {

	}

	@Override
	public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onHttpRecvCancelled(HttpTag tag) {
		// TODO Auto-generated method stub

	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		if (mNetTipsReceiver != null) {
			unregisterReceiver(mNetTipsReceiver);
			mNetTipsReceiver = null;
		}
		if (mClearCacheReceiver != null) {
			unregisterReceiver(mClearCacheReceiver);
			mClearCacheReceiver = null;
		}
		if (localManager != null) {
			localManager.removeAllActivities();
			localManager = null;
		}
		if (mHandler != null) {
			mHandler.removeCallbacksAndMessages(null);
			mHandler = null;
		}
		if (mListActivityViews != null) {
			mListActivityViews.clear();
			mListActivityViews = null;
		}
		if (mHandler != null) {
			mHandler.removeCallbacks(null);
			mHandler = null;
		}

		if (themeSettingsHelper != null) {
			themeSettingsHelper.unRegisterThemeCallback(this);
		}
	}

	@Override
	public void applyTheme() {
		// TODO Auto-generated method stub
		mTitleBar.applyTitleBarTheme(this);
		mChannelBar.applyChannelBarTheme(this);
		mNetTipsBar.applyNetTipsBarTheme(this);
		themeSettingsHelper.setViewBackgroudColor(this, mChannelViewPager, R.color.viewpage_bg_color);
		themeSettingsHelper.setViewPagerMargin(this, mChannelViewPager, R.drawable.viewpager_margin_color);
	}

	abstract protected void setContainerView(Bundle savedInstanceState);

	abstract protected Class<? extends Object> getChannelClassName(Object channel);

	abstract protected void getChannelData();
}
