/**
 * 图片等页面上部的频道导航基类
 */
package com.tencent.news.ui.view;

import java.util.List;

import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.model.pojo.Channel;
import com.tencent.news.model.pojo.ChannelList;
import com.tencent.news.ui.view.HorizontalScrollViewEx.OnScrollChangedListener;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.StringUtil;
import com.tencent.news.utils.ThemeSettingsHelper;

public abstract class ChannelBarBase extends FrameLayout implements OnClickListener, AnimationListener {
	private String TAG = "ChannelBarBase";
	protected Context mContext;
	protected Boolean bShowSetting=false;
	//private View oldview = null;
	private View viewSelected = null;
	private ChannelBarClickListener mListener;
	private ChannelBarRefreshListener mRefreshListener;
	private ImageView mImageViewChannelBg;
	private ImageButton channel_set_button;//频道设置按钮
	private ImageView channel_left_line;
	private ImageView channel_right_line;
	
	public HorizontalScrollViewEx mHorizontalScrollView;
	protected LinearLayout mChannalListLinearLayout=null, mChannelBarLayout=null;
	protected int mScreenWidth;//屏幕宽度
	protected float mChannelWidth;//一个channel的宽度
	protected int mImageBgWidth;//一个ImageView的宽度
	protected float mCurrentPosImageBg;//ImageView当前位置
	protected int mCurrentIndex;
	protected int mChannelNumber;//在一屏显示的频道数目
	protected int nChannelSize;
	protected int nOldChannelSize=0;//刷新前频道数
	protected Boolean bFirst = true;
	protected int mChannelBarWidth;//导航控件宽度
	protected int mChannelsWidth;//所有频道总宽度
	protected int textColor;//默认文字颜色
	protected Boolean isCheckLeftRightLine=true;
	protected ThemeSettingsHelper themeSettingsHelper = null; //支持夜间模式
	protected int int_left_line_bg;//导航条左侧背景值
	protected int int_right_line_bg;//导航条右侧背景值
	
	public ChannelBarBase(Context context){
		super(context);
		isCheckLeftRightLine=true;
		Init(context, false);
	}
	
	public ChannelBarBase(Context context, AttributeSet attrs){
		super(context,attrs);
		isCheckLeftRightLine=true;
		Init(context, false);
	}
	
	/**
	 * 
	 * @param context
	 * @param isShow 是否显示频道设置按钮
	 */
	public ChannelBarBase(Context context, Boolean isShowSet){
		super(context);
		isCheckLeftRightLine=true;
		Init(context, isShowSet);
	}
	
	/**
	 * 
	 * @param context
	 * @param attrs
	 * @param isShow 是否显示频道设置按钮
	 */
	public ChannelBarBase(Context context, AttributeSet attrs, Boolean isShowSet){
		super(context,attrs);
		isCheckLeftRightLine=true;
		Init(context, isShowSet);
	}
	
	private void Init(Context context, Boolean isShowSet){
		this.mContext = context;		
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(this.mContext);		
		LayoutInflater.from(mContext).inflate(R.layout.channel_bar_new_layout, this, true);
		mImageViewChannelBg = (ImageView)findViewById(R.id.channel_bg);
		mHorizontalScrollView = (HorizontalScrollViewEx)findViewById(R.id.hsv_channel_view);
		mChannelBarLayout = (LinearLayout)findViewById(R.id.channel_bar_layout);
		mChannalListLinearLayout = (LinearLayout)findViewById(R.id.channel_list_layout);
		channel_set_button = (ImageButton)findViewById(R.id.channel_set_button);
		channel_left_line = (ImageView)findViewById(R.id.channel_left_line);
		channel_right_line = (ImageView)findViewById(R.id.channel_right_line);
		
		mScreenWidth = MobileUtil.getScreenWidthIntPx();
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(context);	
		initView(isShowSet);
		scrollTouchListener();
	}
	
	private void initView(Boolean isShowSet){
		bShowSetting = isShowSet;
		ChannelList ChannelList = getChannelList();
		int button_width=0;
		if(isShowSet){
			channel_set_button.setVisibility(View.VISIBLE);
			channel_set_button.setOnClickListener(this);
			LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) channel_set_button.getLayoutParams();
			button_width = lp.width;
		}else{
			channel_set_button.setVisibility(View.GONE);
		}
		int channel_left_line_width=0;
		LinearLayout.LayoutParams lp_lf = (LinearLayout.LayoutParams) channel_left_line.getLayoutParams();
		channel_left_line_width = lp_lf.width;
		int channel_right_line_width=0;
		LinearLayout.LayoutParams lp_rf = (LinearLayout.LayoutParams) channel_right_line.getLayoutParams();
		channel_right_line_width = lp_rf.width;
		//button_width = (int)(mScreenWidth/480.0*80+0.5);
		SLog.i(TAG, " button_width " + String.valueOf(button_width)+" channel_left_line_width " + String.valueOf(channel_left_line_width));
		SLog.i(TAG, " ScreenWidth " + String.valueOf(mScreenWidth));
		
		mChannelNumber = getChannelNumber();
		//根据屏幕密度加载不同频道
		//mChannelWidth = (int)((mScreenWidth-button_width)/(mChannelNumber+0.5f));
		mChannelBarWidth=mScreenWidth-button_width-channel_left_line_width-channel_right_line_width;
		mChannelWidth = (int)((mScreenWidth-button_width-channel_left_line_width-channel_right_line_width)/mChannelNumber);
		
		if(ChannelList!=null){
			List<Channel> Channels = ChannelList.getChannelList();
			nChannelSize = Channels.size();
			mChannelsWidth = (int)(mChannelWidth*nChannelSize);
			if(Channels !=null && nChannelSize>0){
				//重新计算频道宽度
				FrameLayout viewTextChannel = (FrameLayout)LayoutInflater.from(mContext).inflate(R.layout.channel_bar_item, null);
				int maxSize= (int)((TextView)viewTextChannel.getChildAt(0)).getPaint().measureText("腾讯新闻");//最多是4个汉字
				int textChannelWidth=0;
				for(int i = 0; i < nChannelSize; ++i){
					Channel channel = Channels.get(i);
					int nTextSize = (int)((TextView)viewTextChannel.getChildAt(0)).getPaint().measureText(
							channel.getChlname());
					//SLog.i(TAG,"nTextSize:"+String.valueOf(nTextSize)+" text:"+channel.getChlname());
					if(textChannelWidth<nTextSize){
						textChannelWidth=nTextSize;
					}
				}
				SLog.i(TAG,"mChannelNumber:"+String.valueOf(mChannelNumber)+" mChannelWidth:"+String.valueOf(mChannelWidth));
				SLog.i(TAG,"textChannelWidth:"+String.valueOf(textChannelWidth)+" maxSize:"+String.valueOf(maxSize));
				if(textChannelWidth>maxSize){
					textChannelWidth=maxSize;
				}
				textChannelWidth=textChannelWidth+5;//保持频道间有空白
				if(textChannelWidth>mChannelWidth){
					mChannelNumber=(int)((mScreenWidth-button_width)/textChannelWidth);
					mChannelWidth = (int)((mScreenWidth-button_width)/mChannelNumber);
					mChannelsWidth = (int)(mChannelWidth*nChannelSize);
				}
				SLog.i(TAG,"mChannelNumber:"+String.valueOf(mChannelNumber)+" mChannelWidth:"+String.valueOf(mChannelWidth));
				for(int i = 0; i < nChannelSize; ++i){
					Channel channel = Channels.get(i);
					FrameLayout view = (FrameLayout)LayoutInflater.from(mContext).inflate(R.layout.channel_bar_item, null);
					((TextView)view.getChildAt(0)).setWidth((int)mChannelWidth);
					((TextView)view.getChildAt(0)).setText(StringUtil.subString(channel.getChlname(),3));
					
					view.setTag(i);
					view.setOnClickListener(this);
					
					if(themeSettingsHelper.isNightTheme()){
						((TextView)view.getChildAt(0)).setTextColor(Color.parseColor("#a2a9aa"));
					}
					
					if(i == 0){						
						textColor = ((TextView)view.getChildAt(0)).getCurrentTextColor();
						setChannelWidth(textChannelWidth);
						initImageViewPadding();
						
						mCurrentIndex = 0;
						viewSelected = view;
						viewSelected.setSelected(true);
					}
					mChannalListLinearLayout.addView(view);
				}
			}
		}
		//channel_left_line.setVisibility(View.GONE);
		if(isCheckLeftRightLine==true){
			//channel_left_line.setImageResource(R.drawable.channel_scroll_bar_bg);
			int_left_line_bg=R.drawable.channel_scroll_bar_bg;
			themeSettingsHelper.setImageViewSrc(mContext,channel_left_line, int_left_line_bg);
		}
		if(mChannelNumber<nChannelSize){
			//channel_right_line.setVisibility(View.VISIBLE);
			if(isCheckLeftRightLine==true || nOldChannelSize<nChannelSize){
				//channel_right_line.setImageResource(R.drawable.nav_rightarrow);
				int_right_line_bg=R.drawable.nav_rightarrow;
				themeSettingsHelper.setImageViewSrc(mContext,channel_right_line, int_right_line_bg);
			}
			mHorizontalScrollView.setPadding(0, mHorizontalScrollView.getPaddingTop(), 
					0, mHorizontalScrollView.getPaddingBottom());
		}else{
			//channel_right_line.setVisibility(View.GONE);
			//channel_right_line.setImageResource(R.drawable.channel_scroll_bar_bg);
			int_right_line_bg=R.drawable.channel_scroll_bar_bg;
			themeSettingsHelper.setImageViewSrc(mContext,channel_right_line, int_right_line_bg);
			//channel_left_line.setImageResource(R.drawable.channel_scroll_bar_bg);
			int_left_line_bg=R.drawable.channel_scroll_bar_bg;
			themeSettingsHelper.setImageViewSrc(mContext,channel_left_line, int_left_line_bg);
			if(mChannelNumber>=nChannelSize){
				//int paddingLeft = (int)(((mChannelNumber-nChannelSize)*mChannelWidth)/2);
				int paddingLeft = (mChannelBarWidth-mChannelsWidth)/2;
				if(button_width>=(paddingLeft*2)){
					paddingLeft=paddingLeft*2;
				}else{
					paddingLeft=paddingLeft+(int)(button_width/2);
				}
				mHorizontalScrollView.setPadding(paddingLeft, mHorizontalScrollView.getPaddingTop(), 
						mHorizontalScrollView.getPaddingRight(), mHorizontalScrollView.getPaddingBottom());
			}else{
				mHorizontalScrollView.setPadding(0, mHorizontalScrollView.getPaddingTop(), 
						0, mHorizontalScrollView.getPaddingBottom());
			}
		}
	}
	
	protected int getChannelNumber(){
		DisplayMetrics dm = MobileUtil.getDeviceDisplayMetrics(mContext);
		return (dm.density>=1.5f)?5:4;
	}
	
	private void initImageViewPadding(){
		int nImgSrcTopPad = MobileUtil.dpToPx(5);
		mImageViewChannelBg.getLayoutParams().width=(int)(mChannelWidth);
		int nInterval = ((int)mChannelWidth - mImageBgWidth) / 2;
		mImageViewChannelBg.setPadding(nInterval, nImgSrcTopPad, nInterval, nImgSrcTopPad);
		SLog.i(TAG,String.valueOf(nImgSrcTopPad));
	}
	
	public void setSelectedState(View v){
		if(viewSelected!=null){
			((TextView)((FrameLayout)viewSelected).getChildAt(0)).setTextColor(textColor);
		}
		viewSelected.setSelected(false);
		v.setSelected(true);
		viewSelected = v;
		if(themeSettingsHelper.isNightTheme()){
			((TextView)((FrameLayout)v).getChildAt(0)).setTextColor(Color.parseColor("#5fabf1"));
		}
		else{
			((TextView)((FrameLayout)v).getChildAt(0)).setTextColor(Color.parseColor("#0762a7"));
		}
	}
	
	public void setSelectedState(int nIndex){
		View v =(View)mChannalListLinearLayout.getChildAt(nIndex);
		setSelectedState(v);
		/*viewSelected.setSelected(false);
		v.setSelected(true);
		viewSelected = v;*/
	}
	
	public void setFocusByImageViewBg(AnimationListener mAnimationListener, int nIndex){
		TextView tv=(TextView)((FrameLayout)mChannalListLinearLayout.getChildAt(nIndex)).getChildAt(0);
		mCurrentIndex = nIndex;
		bFirst = false;
		mHorizontalScrollView.requestChildFocus(tv, tv);
	}
	
	public void setFocusByImageViewBg(int nIndex){
		TextView tv=(TextView)((FrameLayout)mChannalListLinearLayout.getChildAt(nIndex)).getChildAt(0);
		mCurrentIndex = nIndex;
		bFirst = false;
		mHorizontalScrollView.requestChildFocus(tv, tv);
	}
	
	public void scrollBySlide(int arg0,float nRate){
		float nPostion = (arg0+nRate)*mChannelWidth;
		
		if ( mCurrentPosImageBg != nPostion ) {
			TranslateAnimation animation = new TranslateAnimation( mCurrentPosImageBg, nPostion, 0, 0 );
			animation.setFillAfter( true );
			mCurrentPosImageBg = nPostion;
			mImageViewChannelBg.startAnimation( animation );
			animation = null;
		}
	}
	
	OnScrollChangedListener mOnScrollChangedListener=new OnScrollChangedListener(){

		@Override
		public void onScrollChanged(int l, int t, int oldl, int oldt) {
			// TODO Auto-generated method stub
			SLog.i(TAG, " onScrollChanged l:" + String.valueOf(l)+" t:" + String.valueOf(t)+" oldl:" + String.valueOf(oldl)+" oldt:" + String.valueOf(oldt));
			//SLog.i(TAG, " onScrollChanged getPaddingLeft:" + String.valueOf(getPaddingLeft())+" getPaddingRight:" + String.valueOf(getPaddingRight()));
			//SLog.i(TAG, " onScrollChanged getLeft:" + String.valueOf(getLeft())+" getRight:" + String.valueOf(getRight()));
			SLog.i(TAG, " onScrollChanged length:" + String.valueOf(mChannelWidth*nChannelSize)+" mChannelBarWidth:" + String.valueOf(mChannelBarWidth));
			SLog.i(TAG, " onScrollChanged channel_left_line:" + String.valueOf(channel_left_line.getWidth())+" channel_right_line:" + String.valueOf(channel_right_line.getWidth()));
			//channel_left_line = (ImageView)findViewById(R.id.channel_left_line);
			//channel_right_line = (ImageView)findViewById(R.id.channel_right_line);
			if(l>0){
				//channel_left_line.setVisibility(View.VISIBLE);
				//channel_left_line.setImageResource(R.drawable.nav_leftarrow);
				int_left_line_bg=R.drawable.nav_leftarrow;
				themeSettingsHelper.setImageViewSrc(mContext,channel_left_line, int_left_line_bg);
			}else{
				//channel_left_line.setVisibility(View.GONE);
				//channel_left_line.setImageResource(R.drawable.channel_scroll_bar_bg);
				themeSettingsHelper.setImageViewSrc(mContext,channel_left_line, R.drawable.channel_scroll_bar_bg);
				int_left_line_bg=R.drawable.channel_scroll_bar_bg;
			}
			
			if(mChannelsWidth-2<=l+mChannelBarWidth){
				//channel_right_line.setVisibility(View.GONE);
				//channel_right_line.setImageResource(R.drawable.channel_scroll_bar_bg);
				themeSettingsHelper.setImageViewSrc(mContext,channel_right_line, R.drawable.channel_scroll_bar_bg);
				int_right_line_bg=R.drawable.channel_scroll_bar_bg;
			}else{
				//channel_right_line.setVisibility(View.VISIBLE);
				//channel_right_line.setImageResource(R.drawable.nav_rightarrow);
				int_right_line_bg=R.drawable.nav_rightarrow;
				themeSettingsHelper.setImageViewSrc(mContext,channel_right_line, int_right_line_bg);
			}
		}
		
	};
	
	private void scrollTouchListener(){
		mHorizontalScrollView.setOnScrollChangedListener(mOnScrollChangedListener);
		/*mHorizontalScrollView.setOnTouchListener(new OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
				SLog.v(TAG, "v.getScrollX = " + v.getScrollX());
				return false;
			}
		});*/
	}
	
	@Override
	public void onClick(View v){
		if(v.getId()==R.id.channel_set_button){
			onClickSetUp();
			return;
		}
		if(viewSelected.equals(v)){
			return;
		}
		setSelectedState(v);
		/*viewSelected.setSelected(false);
		v.setSelected(true);
		viewSelected = v;*/
		if(this.mListener!=null){
			int nIndex = (Integer)viewSelected.getTag();
			translateImageBg(this,nIndex,20);
		}
	}
	
	public void translateImageBg(AnimationListener mAnimationListener, int nIndex, int duration){
		float nPosition = 0.0f;
		if(mCurrentIndex<nIndex){
			if(bFirst){
				bFirst = false;
				nPosition = (nIndex - mCurrentIndex) * mChannelWidth;
			}else{
				nPosition = (nIndex - mCurrentIndex) * mChannelWidth + mCurrentPosImageBg;
			}
		}else if(mCurrentIndex>nIndex){
			nPosition = mCurrentPosImageBg - ((mCurrentIndex - nIndex)*mChannelWidth);
		}else
			return;
		
		TranslateAnimation animation = new TranslateAnimation(mCurrentPosImageBg, nPosition, 0, 0);
		animation.setFillAfter(true);
		animation.setDuration(duration);
		mCurrentPosImageBg = nPosition;
		mCurrentIndex = nIndex;
		
		animation.setAnimationListener(mAnimationListener);
		mImageViewChannelBg.startAnimation(animation);
		mImageViewChannelBg.setFocusable(true);
	}
	
	public void translateImageBg( int nIndex )
	{
		mCurrentIndex = 0;
		float nPosition = (  nIndex - mCurrentIndex ) * mChannelWidth;
		
		TranslateAnimation animation = new TranslateAnimation( mCurrentPosImageBg,  nPosition , 0, 0 );
		animation.setFillAfter( true );
		mCurrentPosImageBg = nPosition;
		mCurrentIndex = nIndex;
		
		mImageViewChannelBg.startAnimation( animation );
		mImageViewChannelBg.setFocusable( true );
	}
	
	@Override
	public void onAnimationEnd(Animation animation) {
	}

	@Override
	public void onAnimationRepeat(Animation animation) {
	}

	@Override
	public void onAnimationStart(Animation animation) {
		mListener.onSelected( mCurrentIndex );
	}

	public void setActive(int nIndex){
		
		View v = mChannalListLinearLayout.getChildAt( nIndex );
		setSelectedState(v);
		/*viewSelected.setSelected(false);
		v.setSelected(true);
		viewSelected = v;*/
		
		translateImageBg( nIndex );
		
	}
	
	public void refresh(){
		//oldview=viewSelected;
		nOldChannelSize=nChannelSize;
		String textStr=(String)((TextView)((FrameLayout)viewSelected).getChildAt(0)).getText();
		int nIndex=0;
		ChannelList ChannelList = getChannelList();
		if(ChannelList!=null){
			List<Channel> Channels = ChannelList.getChannelList();
			nChannelSize = Channels.size();
			mChannelsWidth = (int)(mChannelWidth*nChannelSize);
			if(Channels !=null && nChannelSize>0){
				for(int i = 0; i < nChannelSize; ++i){
					Channel channel = Channels.get(i);
					if(channel.getChlname().equals(textStr)){
						nIndex = i;
					}
				}
			}
		}
		
		mChannalListLinearLayout.removeAllViews();
		isCheckLeftRightLine=false;
		initView(bShowSetting);
		if(mRefreshListener!=null){
			mRefreshListener.onRefresh(nIndex);
		}
		setFocusByImageViewBg(nIndex);
		//setActive(nIndex);
		//oldview=null;
	}
	
	
	public void setOnChannelBarClickListener(ChannelBarClickListener mListener){
		this.mListener = mListener;
	}
	
	public void setOnChannelBarRefreshListener(ChannelBarRefreshListener mListener){
		this.mRefreshListener = mListener;
	}
	
	public void applyChannelBarTheme(Context context) {		
		themeSettingsHelper.setViewBackgroud(context, this.mChannelBarLayout, R.drawable.channel_scroll_bar_bg);
		themeSettingsHelper.setImageViewSrc(context, this.channel_left_line, int_left_line_bg);		
		themeSettingsHelper.setImageViewSrc(context, this.channel_right_line, int_right_line_bg);
		themeSettingsHelper.setImageViewSrc(context, this.mImageViewChannelBg, R.drawable.channel_scroll_bar_selected);
		themeSettingsHelper.setImageButtonSrc(context, this.channel_set_button, R.drawable.nav_add_btn);
		int countnum=mChannalListLinearLayout.getChildCount();
		boolean setTextColor=true;
		for(int i = 0; i < countnum; ++i){
			TextView tv=(TextView)((FrameLayout)mChannalListLinearLayout.getChildAt(i)).getChildAt(0);
			if(mCurrentIndex!=i){
				if(themeSettingsHelper.isNightTheme()){
					tv.setTextColor(Color.parseColor("#a2a9aa"));
				}else{
					tv.setTextColor(Color.parseColor("#545557"));
				}
				if(setTextColor==true){
					textColor = tv.getCurrentTextColor();
					setTextColor=false;
				}
			}else{
				if(themeSettingsHelper.isNightTheme()){
					tv.setTextColor(Color.parseColor("#5fabf1"));
				}
				else{
					tv.setTextColor(Color.parseColor("#0762a7"));
				}
			}
		}
	}	

	public interface ChannelBarClickListener{
		public void onSelected(int nIndex);
	}
	
	public interface ChannelBarRefreshListener{
		public void onRefresh(int nIndex);
	}

	protected void setChannelWidth(int textChannelWidth){
		mImageBgWidth = MobileUtil.dpToPx(50);
		if(textChannelWidth>mImageBgWidth){
			mImageBgWidth=textChannelWidth;
		}
		mCurrentPosImageBg = (mChannelWidth - mImageBgWidth)/2;
	}
	
	/**
	 * 设置未读数
	 * @param text 未读数
	 * @param nIndex 第几个频道
	 * @param show 是否显示
	 */
	public void setNotReading(CharSequence text, int nIndex, boolean show){
		if(nIndex<0 || mChannalListLinearLayout.getChildCount()<=nIndex){
			return;
		}
		View v =(View)mChannalListLinearLayout.getChildAt(nIndex);
		TextView tView=((TextView)((FrameLayout)v).getChildAt(1));
		if(show){
			tView.setVisibility(View.VISIBLE);
		}else{
			tView.setVisibility(View.GONE);
		}
		tView.setText(text);
	}
	
	abstract public  ChannelList getChannelList();
	abstract public Object getChannelData();
	abstract public void onClickSetUp();
}
