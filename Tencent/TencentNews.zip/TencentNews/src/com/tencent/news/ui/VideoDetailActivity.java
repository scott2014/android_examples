package com.tencent.news.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.TreeMap;

import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.boss.EventId;
import com.tencent.news.cache.NewsDetailCache;
import com.tencent.news.cache.NewsDetailCache.CacheType;
import com.tencent.news.command.GetImageRequest;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.pojo.ExtendedChannels;
import com.tencent.news.model.pojo.ImageResult;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.model.pojo.SimpleNewsDetail;
import com.tencent.news.model.pojo.VideoValue;
import com.tencent.news.shareprefrence.SpUserHelp;
import com.tencent.news.system.AddCommentBroadcastReceiver;
import com.tencent.news.system.RefreshCommentNumBroadcastReceiver;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.CommentView;
import com.tencent.news.ui.view.NavigationBar;
import com.tencent.news.ui.view.ShareDialog;
import com.tencent.news.ui.view.VideoDetailView;
import com.tencent.news.ui.view.ViewPagerEx;
import com.tencent.news.ui.view.WritingCommentView;
import com.tencent.news.ui.view.WritingCommentView.OnChangeClick;
import com.tencent.news.utils.DefaulImageUtil;
import com.tencent.news.utils.InfoConfigUtil;
import com.tencent.news.utils.IntentUtil;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.StringUtil;
import com.tencent.omg.webdev.WebDev;

public class VideoDetailActivity extends BaseActivity {
	
	private long viewStart;
	private long viewEnd;
	
	private RelativeLayout mVideoRootLayout;
	private Item mItem;
	private TextView mDetailTitle;
	private TextView mDetailTime;
	private TextView mDetailComments;
	private TextView mDetailSource;
	private TextView mDetailContent;
	private ImageButton mVideoPlay;
	private Button mBackBtn;
	private ImageView mDetailImage;
	private ImageButton mShareBtn;
	private String mChlid;
	private String mVid;
	private float downX;
	private float upX;
	private float downY;
	private float upY;
	private NewsDetailCache mNewsDetailCache;
	private String mClickPosition;
	private AddCommentBroadcastReceiver receiver;
	private RefreshCommentNumBroadcastReceiver mRefreshCommentReceiver;
	private VideoDetailView mVideoDetailView;
	private ViewPagerEx mViewPager;
	private List<View> mViews = new ArrayList<View>();
	private int nCurrentPage = 0;
	protected CommentView mCommentView;
	protected WritingCommentView mWritingCommentView;
	private LinearLayout mClickTop;
	private View mMask;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.video_detail_layout);
		Intent intent = getIntent();
		if (intent != null) {
			Bundle bundle = intent.getExtras();
			mItem = (Item) bundle.getSerializable(Constants.NEWS_DETAIL_KEY);
			mChlid = bundle.getString(Constants.NEWS_CHANNEL_CHLID_KEY);
			mClickPosition = bundle.getString(Constants.NEWS_CLICK_ITEM_POSITION);
			//mNewsDetailCache = new NewsDetailCache(mItem.getId());
			mNewsDetailCache = new NewsDetailCache(mItem);
		}
		InitView();
		InitListener();
		InitData();
		getNetData();
		setVideoImage(mDetailImage);
		receiver = new AddCommentBroadcastReceiver(mCommentView, mItem.getId());
		registerReceiver(receiver, new IntentFilter(Constants.WRITE_SUCCESS_ACTION));
	}

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
//		statistics_visit_start_time = System.currentTimeMillis();
		super.onStart();
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
//		statistics_visit_end_time = System.currentTimeMillis();
//		statistics_visit_total = statistics_visit_end_time - statistics_visit_start_time;
//		Statistics.getInstance().saveStatistics(Statistics.REPORTED_DATA_NEWS_DETAIL,
//				StatisticsUtil.generateCustomField(new String[] { mItem.getId(), mChlid, "" + statistics_load_total, mClickPosition, "" + statistics_visit_total, "", "", "", "", "", "" }));
//		statistics_load_total = 0;
		super.onStop();
	}

	private void InitView() {

		mVideoDetailView = new VideoDetailView(this);
		mDetailImage = mVideoDetailView.getDetailImage();
		mVideoPlay = mVideoDetailView.getVideoPlay();
		mDetailContent = mVideoDetailView.getDetailContent();

		mDetailTitle = mVideoDetailView.getDetailTitle();
		mDetailTime = mVideoDetailView.getDetailTime();
		mDetailComments = mVideoDetailView.getDetailComments();
		mDetailSource = mVideoDetailView.getDetailSource();

		mVideoRootLayout = (RelativeLayout) findViewById(R.id.video_detail_root_layout);
		mWritingCommentView = (WritingCommentView) findViewById(R.id.VideoWritingCommentView);
		mBackBtn = (Button) findViewById(R.id.video_title_back_btn);
		mShareBtn = (ImageButton) findViewById(R.id.video_title_share_btn);
		mViewPager = (ViewPagerEx) findViewById(R.id.video_view_pager);
		mClickTop = (LinearLayout) findViewById(R.id.video_click_top);

		//
		mMask = (View) findViewById(R.id.mask_view);
		//
		mShareBtn.setEnabled(false);
		mCommentView = new CommentView(this);

		mViews.add(mVideoDetailView);
		mViews.add(mCommentView);
		mViewPager.setAdapter(new MyPagerAdapter(mViews));
		mViewPager.setOffscreenPageLimit(1);
		mViewPager.setCurrentItem(0);
		mViewPager.setOnPageChangeListener(new MyOnPageChangeListener());
		mWritingCommentView.setItem(mChlid, mItem);
		mWritingCommentView.refreshUI();
		mCommentView.init(mChlid, mItem);
		mCommentView.setWritingCommentView(mWritingCommentView);
		setTitleBackName();
	}

	private void InitData() {
		mDetailTitle.setText(mItem.getTitle());
		// mDetailComments.setText(mItem.getCommentNum());
		if (Integer.parseInt(mItem.getVideo_hits()) > 10000) {
			mDetailComments.setText(StringUtil.tenTh2wan(mItem.getVideo_hits()));
		} else {
			mDetailComments.setText(mItem.getVideo_hits());
		}
		mDetailTime.setText(StringUtil.cutDateString(mItem.getTime()));
		mDetailSource.setText(mItem.getSource());
	}

	private void setTitleBackName() {
		if(mNewsDetailCache.getMcahceType()==CacheType.FAVOR_CACHE){
			mBackBtn.setText("收藏");
			return;
		}
		ExtendedChannels channel = InfoConfigUtil.ReadExtendedChannels();
		if (mChlid.equals(TencentNews.VIDEO) && NavigationBar.getSelected() == 2) {
			mBackBtn.setText("视频");
		} else if (channel != null && channel.getChlname() != null && NavigationBar.getSelected() == 4) {
			mBackBtn.setText(channel.getChlname());
		}
	}

	private void InitListener() {
		mVideoPlay.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.setClass(VideoDetailActivity.this, PlayVideoActivity.class);
				intent.putExtra(Constants.PLAY_VIDEO_VID_KEY, mVid);
				intent.putExtra(Constants.NEWS_DETAIL_KEY, mItem);
				intent.putExtra(Constants.NEWS_CHANNEL_CHLID_KEY, mChlid);
				startActivity(intent);
			}

		});

		mBackBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				quitActivity();
			}

		});

		mShareBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				ShareDialog.getInstance().showShareList(VideoDetailActivity.this, ShareDialog.SHARE_MEDIA_DETAIL, mShareBtn);
			}

		});

		mClickTop.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (nCurrentPage == 1) {
					mCommentView.upToTop();
				}
			}

		});

		mWritingCommentView.setDetailCommentChangeClick(new OnChangeClick() {

			@Override
			public void change() {
				if (nCurrentPage == 0) {
					mViewPager.setCurrentItem(1);
				} else {
					mViewPager.setCurrentItem(0);
				}
			}
		});

	}

	private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if (msg != null && msg.obj != null) {
//				statistics_load_end_time = System.currentTimeMillis();
//				statistics_load_total = statistics_load_end_time - statistics_load_start_time;
//				if (statistics_load_total < 0) {
//					statistics_load_total = 0;
//				}
				SimpleNewsDetail detail = (SimpleNewsDetail) msg.obj;
				TreeMap<String, Object> attribute = detail.getAttribute();
				if (attribute.containsKey("VIDEO_0")) {
					VideoValue dataMap = (VideoValue) attribute.get("VIDEO_0");
					shareNewsData(detail);
					isShowVideoUserHelp();
					mVid = dataMap.getVid();
					mDetailContent.setText(dataMap.getDesc());
					String img = dataMap.getImg();
					getImageData(img);
					mCommentView.enterPageThenGetComments(false);
					mWritingCommentView.canWrite(true);
					mWritingCommentView.setVid(mVid);
					ShareDialog.getInstance().setVid(mVid);
					ShareDialog.getInstance().setImageUrl(img);

				}
			}
		}
	};

	private void shareNewsData(SimpleNewsDetail detail) {
		mShareBtn.setEnabled(true);
		ShareDialog.getInstance().setParams("", "", detail, mItem, mChlid);
	}

	private void isShowVideoUserHelp() {
		if (SpUserHelp.getNewsDetailHelp()) {
			attachHelpView();
		}
	}

	private void attachHelpView() {
		View v = new View(this);
		v.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT));
		v.setBackgroundResource(R.drawable.news_detail_help);
		mVideoRootLayout.addView(v);
		v.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				mVideoRootLayout.removeView(v);
				SpUserHelp.setNewsDetailHelp(false);
			}

		});
	}

	private void getNetData() {
		TaskManager.startRunnableRequest(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				SimpleNewsDetail detail = mNewsDetailCache.getNewsDetail();
				if (detail != null) {
					Message msg = Message.obtain();
					msg.obj = detail;
					mHandler.sendMessage(msg);
				} else {
					
					
					WebDev.trackCustomBeginKVEvent(VideoDetailActivity.this, EventId.ITIL_LOAD_DETAIL_TIME, getPts());
					
					HttpDataRequest request = TencentNews.getInstance().getSimpleHtmlContent(mItem.getId(), mChlid, mNewsDetailCache.getMcahceType());
					TaskManager.startHttpDataRequset(request, VideoDetailActivity.this);
				}
			}

		});
	}

	protected Properties getPts() {
		Properties pts = new Properties();
		pts.setProperty(EventId.KEY_NEWSID, mItem != null ? mItem.getId() : "");
		pts.setProperty(EventId.KEY_CHANNELID, mChlid);
		pts.setProperty(EventId.KEY_LISTPOS, "" + mClickPosition);
		pts.setProperty(EventId.KEY_DETAILTYPE, iAmWhich());
		return pts;
	}
	
	private String iAmWhich() {
		return "video";
	}

	private void getImageData(String url) {
		GetImageRequest request = new GetImageRequest();
		request.setGzip(false);
		request.setTag(url);
		request.setUrl(url);
		ImageResult result = TaskManager.startSmallImageTask(request, this);
		if (result.isResultOK() && result.getRetBitmap() != null) {
			/* setVideoImage(mDetailImage, result.getRetBitmap()); */
			mDetailImage.setImageBitmap(result.getRetBitmap());
			mVideoPlay.setVisibility(View.VISIBLE);
		} else {
			/*
			 * setVideoImage(mDetailImage,
			 * DefaulImageUtil.getDefaultVideoDetailImage());
			 */
			mDetailImage.setImageBitmap(DefaulImageUtil.getDefaultVideoDetailImage());
		}
	}

	private void setVideoImage(ImageView srcImage) {
		int desImageViewWidth = 0;
		int desImageViewHeight = 0;
		int totalWidth = MobileUtil.getScreenWidthIntPx() - MobileUtil.dpToPx(12 * 2);
		desImageViewWidth = totalWidth;
		desImageViewHeight = (int) (desImageViewWidth / 1.5);
		FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) srcImage.getLayoutParams();
		lp.width = desImageViewWidth;
		lp.height = desImageViewHeight;
		srcImage.setLayoutParams(lp);
		srcImage.setScaleType(ScaleType.FIT_XY);

	}

	private void sendBroadCastforRead() {
		Intent intent = new Intent();
		Bundle bundle = new Bundle();
        String action = IntentUtil.getReadBroadcastAction(getIntent());
        if (action != null) {
            intent.setAction(action);
        } else {
            intent.setAction(Constants.NEWS_HAD_READ_ACTION + mChlid);
        }
		bundle.putSerializable(Constants.NEWS_ID_KEY, mItem);
		intent.putExtras(bundle);
		sendBroadcast(intent);
	}

	@Override
	public void onHttpRecvOK(HttpTag tag, Object result) {
		// TODO Auto-generated method stub
		
		Properties p = getPts();
		WebDev.trackCustomEndKVEvent(VideoDetailActivity.this, EventId.ITIL_LOAD_DETAIL_TIME, p);
		Properties newp = new Properties(p);
		newp.setProperty(EventId.KEY_RESCODE, EventId.VALUE_RESCODE_SUCCESS);
		WebDev.trackCustomEvent(VideoDetailActivity.this, EventId.ITIL_LOAD_DETAIL_TIME_RESULT, newp);
		
		SimpleNewsDetail detail = (SimpleNewsDetail) result;
		Message msg = new Message();
		msg.obj = detail;
		mHandler.sendMessage(msg);
		mNewsDetailCache.setCacheDetailData(detail);
		mNewsDetailCache.saveNewsDetail();

		sendBroadCastforRead();
	}

	@Override
	public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {
		// TODO Auto-generated method stub

		Properties p = getPts();
		WebDev.trackCustomEndKVEvent(VideoDetailActivity.this, EventId.ITIL_LOAD_DETAIL_TIME, p);
		Properties newp = new Properties(p);
		newp.setProperty(EventId.KEY_RESCODE, EventId.VALUE_RESCODE_ERROR);
		WebDev.trackCustomEvent(VideoDetailActivity.this, EventId.ITIL_LOAD_DETAIL_TIME_RESULT, newp);
	}

	@Override
	public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm, String path) {
		// TODO Auto-generated method stub
		if (bm != null && bm != null) {
			mDetailImage.setImageBitmap(bm);
			mVideoPlay.setVisibility(View.VISIBLE);
		}
	}

	@Override
	public void onImageRecvError(ImageType imageType, Object tag, int retCode) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
			if (ShareDialog.getInstance().isShowing()) {
				ShareDialog.getInstance().dismiss();
				return true;
			}
			quitActivity();
			return true;
		} else if (event.getKeyCode() == KeyEvent.KEYCODE_MENU && event.getRepeatCount() > 0) {
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	protected void onDestroy() {
		if (receiver != null) {
			try {
				unregisterReceiver(receiver);
			} catch (Exception e) {
				SLog.e(e.toString());
			}
		}
		if (mRefreshCommentReceiver != null) {
			try {
				unregisterReceiver(mRefreshCommentReceiver);
			} catch (Exception e) {
				SLog.e(e.toString());
			}
		}

		ShareDialog.getInstance().dismiss();
		super.onDestroy();
	}

	@Override
	public boolean dispatchTouchEvent(MotionEvent ev) {
		// TODO Auto-generated method stub
		final float x = ev.getX();
		final float y = ev.getY();
		if (ev.getAction() == MotionEvent.ACTION_DOWN) {
			downX = x;
			downY = y;
		} else if (ev.getAction() == MotionEvent.ACTION_UP) {
			upX = x;
			upY = y;
			if (nCurrentPage == 0 && upX > downX && Math.abs(upX - downX) > MobileUtil.dpToPx(100) && Math.abs(upX - downX) > Math.abs(upY - downY)) {
				quitActivity();
			}
		}
		return super.dispatchTouchEvent(ev);
	}

	public class MyPagerAdapter extends PagerAdapter {

		public List<View> mListViews;

		public MyPagerAdapter(List<View> mListViews) {
			this.mListViews = mListViews;
		}

		@Override
		public void destroyItem(View arg0, int arg1, Object arg2) {
			((ViewPager) arg0).removeView(mListViews.get(arg1));
		}

		@Override
		public void finishUpdate(View arg0) {

		}

		@Override
		public int getCount() {
			return mListViews.size();
		}

		@Override
		public Object instantiateItem(View arg0, int arg1) {
			((ViewPager) arg0).addView(mListViews.get(arg1), 0);
			return mListViews.get(arg1);
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == (arg1);
		}

		@Override
		public void restoreState(Parcelable arg0, ClassLoader arg1) {

		}

		@Override
		public Parcelable saveState() {
			return null;
		}

		@Override
		public void startUpdate(View arg0) {

		}

	}

	public class MyOnPageChangeListener implements OnPageChangeListener {

		@Override
		public void onPageScrollStateChanged(int arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onPageSelected(int arg0) {
			// TODO Auto-generated method stub
			nCurrentPage = arg0;
			mWritingCommentView.setDCPage(nCurrentPage);
			mWritingCommentView.refreshUI();
		}

	}

	@Override
	public void applyTheme() {
		themeSettingsHelper.setViewBackgroudColor(this, mMask, R.color.mask_page_color);

	}

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
		viewStart = System.currentTimeMillis();
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
		viewEnd = System.currentTimeMillis();
		
		Properties p = new Properties(getPts());
		p.setProperty(EventId.KEY_VIEW_START, "" + viewStart);
		p.setProperty(EventId.KEY_VIEW_END, "" + viewEnd);
		WebDev.trackCustomEvent(this, EventId.BOSS_VIEW_DETAIL, p);
	}

}
