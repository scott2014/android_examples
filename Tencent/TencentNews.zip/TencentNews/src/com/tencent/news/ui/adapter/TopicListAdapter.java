package com.tencent.news.ui.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.command.GetImageRequest;
import com.tencent.news.config.Constants;
import com.tencent.news.model.pojo.ImageResult;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.shareprefrence.SpNewsHadRead;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.PullRefreshListView;
import com.tencent.news.utils.DefaulImageUtil;
import com.tencent.news.utils.StringUtil;

public class TopicListAdapter extends ChannelListAdapter {    
	public TopicListAdapter(Context context, ListView listView) {
		super(context, listView);
		//setListViewDivider();
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		TopicHolder holder = null;
		int type = getItemViewType(position);
		switch (type) {
		case Constants.TYPE_ITEM_TEXT:
			convertView = setTextMode(convertView, position, holder);
			break;
		case Constants.TYPE_ITEM_IMAGE:
			convertView = setImageMode(convertView, position, holder);
			break;
		default:
			break;
		}
		return convertView;
	}

	private View setImageMode(View convertView, int position, TopicHolder holder){
		if (convertView == null) {
			holder = new TopicHolder();
			convertView = LayoutInflater.from(mContext).inflate(R.layout.topic_list_item, null);			
			holder.title = (TextView) convertView.findViewById(R.id.topic_title_text);
			holder.comments = (TextView) convertView.findViewById(R.id.topic_comments_text);
			holder.commentIcon = (ImageView) convertView.findViewById(R.id.list_comments_icon);
			holder.stract = (TextView) convertView.findViewById(R.id.topic_abstract_text);
			holder.image = (ImageView) convertView.findViewById(R.id.topic_item_image);
			holder.qishu = (TextView) convertView.findViewById(R.id.topic_item_qishu);
			convertView.setTag(holder);
		} else {
			holder = (TopicHolder) convertView.getTag();
		}
		
		applyThemeForItem(holder);
		
		final Item item = mDataList.get(position);
		holder.id = item.getId();
		if ( item != null && holder!=null && holder.id!=null ) {			
			setTextData(item, holder);
			if (!((PullRefreshListView) mListView).isBusy()) {
				setTopicListImage(item, holder);
			} else {
				GetImageRequest request = new GetImageRequest();
				String url = (item.getThumbnails_qqnews() != null && item.getThumbnails_qqnews().length > 0) ? item
						.getThumbnails_qqnews()[0] : "";
				request.setUrl(url);
				request.setTag(holder.id);
				ImageResult result = TaskManager.getLocalIconImage(request,this);
				if (result.isResultOK() && result.getRetBitmap() != null) {					
					holder.image.setImageBitmap(result.getRetBitmap());
				} else {
					Bitmap tmpBitmap = null;
					if(themeSettingsHelper.isNightTheme()){
						tmpBitmap = DefaulImageUtil.getNightDefaultTopicListImage();
					}
					else{
						tmpBitmap = DefaulImageUtil.getDefaultTopicListImage();
					}
					//holder.image.setImageBitmap(DefaulImageUtil.getDefaultTopicListImage());
					if(tmpBitmap!=null){
						holder.image.setImageBitmap(tmpBitmap);
					}					
				}
			}
		}
		return convertView;
	}

	private View setTextMode(View convertView, int position, TopicHolder holder){
		if (convertView == null) {
			holder = new TopicHolder();
			convertView = LayoutInflater.from(mContext).inflate(R.layout.tipic_list_text_item, null);			
			holder.title = (TextView) convertView.findViewById(R.id.topic_title_text);
			holder.comments = (TextView) convertView.findViewById(R.id.topic_comments_text);
			holder.commentIcon = (ImageView) convertView.findViewById(R.id.list_comments_icon);
			holder.stract = (TextView) convertView.findViewById(R.id.topic_abstract_text);
			holder.qishu = (TextView) convertView.findViewById(R.id.topic_item_qishu);
			convertView.setTag(holder);
		} else {
			holder = (TopicHolder) convertView.getTag();
		}
		
		applyThemeForItem(holder);
		
		Item item = mDataList.get(position);
		setTextData(item, holder);
		return convertView;
	}
	
	private void setTopicListImage(Item item, TopicHolder holder) {
		if(item==null || holder==null || holder.image==null || item.getId()==null){
			return;
		}
		GetImageRequest request = new GetImageRequest();
		request.setGzip(false);
		request.setTag(item.getId());
		if (item != null && item.getThumbnails_qqnews() != null
				&& item.getThumbnails_qqnews().length > 0) {
			request.setUrl(item.getThumbnails_qqnews()[0]);
		}
		ImageResult result = TaskManager.startSmallImageTask(request, this);
		if (result.isResultOK() && result.getRetBitmap() != null) {			
			holder.image.setImageBitmap(result.getRetBitmap());
		} else {
			Bitmap tmpBitmap = null;
			if(themeSettingsHelper.isNightTheme()){
				tmpBitmap = DefaulImageUtil.getNightDefaultTopicListImage();
			}
			else{
				tmpBitmap = DefaulImageUtil.getDefaultTopicListImage();
			}
			//holder.image.setImageBitmap(DefaulImageUtil.getDefaultTopicListImage());
			if(tmpBitmap!=null){
				holder.image.setImageBitmap(tmpBitmap);
			}
		}
	}

	protected static class TopicHolder {		
		TextView title;
		TextView stract;
		TextView comments;
		TextView qishu;
		ImageView image;
		ImageView commentIcon;
		String id;
	}

	/*private void setListViewDivider() {
		mListView.setDivider(mContext.getResources().getDrawable(R.drawable.list_divider_line));
	}*/
	
	private void setTextData(Item item, TopicHolder holder) {
		if(item==null || holder==null || item.getId()==null){
			return;
		}
		
		if(SpNewsHadRead.isNewsHadRead(item.getId())) {
			if(themeSettingsHelper.isNightTheme()){
				holder.title.setTextColor(mContext.getResources().getColor(R.color.night_readed_news_title_color));
			}else{
				holder.title.setTextColor(mContext.getResources().getColor(R.color.readed_news_title_color));
			}
		} else {
			if(themeSettingsHelper.isNightTheme()){
				holder.title.setTextColor(mContext.getResources().getColor(R.color.night_list_title_color));
			}else{
				holder.title.setTextColor(mContext.getResources().getColor(R.color.list_title_color));
			}				
		}				
		
		holder.title.setText(StringUtil.replaceBlank(item.getTitle()));
		String stract = null;
		if (item.getBstract() != null) {
			stract = item.getBstract().trim();
			if (stract.length() > 30) {
				stract = stract.substring(0, 30);
			}
		}
		stract = StringUtil.StringFilter(stract);
		holder.stract.setText(stract);
		holder.qishu.setText("第" + item.getQishu() + "期");
		if (item.getCommentNum() != null && item.getCommentNum().length() > 0
				&& Integer.parseInt(item.getCommentNum()) > 10000) {
			holder.comments.setText(StringUtil.tenTh2wan(item.getCommentNum()));
		} else {
			holder.comments.setText(item.getCommentNum());
		}

	}

	@Override
	public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm,
			String path) {
		// TODO Auto-generated method stub
		if(bm==null){
			return;
		}
		switch (imageType) {
		case SMALL_IMAGE:
			int countImage = mListView.getChildCount();
			for (int i = 0; i < countImage; i++) {
				TopicHolder topicHolder = (TopicHolder) mListView.getChildAt(i)
						.getTag();
				if (topicHolder != null) {
					if (((String) tag).equals(topicHolder.id)) {										
						topicHolder.image.setImageBitmap(bm);
						break;
					}
				}
			}
			break;
		default:
			break;
		}
	}

	@Override
	public void changeStyleMode(int style) {
		super.changeStyleMode(style);
		//setListViewDivider();
	}

	@Override
	public void serListViewBusy(int currPosition, int tag) {
		if (styleType == Constants.TYPE_ITEM_TEXT) {
			return;
		}
		TopicHolder holder = (TopicHolder) mListView.getChildAt(tag).getTag();
		if (currPosition >= 0 && currPosition < mDataList.size()
				&& holder != null) {
			Item item = mDataList.get(currPosition);
			setTopicListImage(item, holder);
		}
	}
	
	public void applyThemeForItem(TopicHolder holder){
		if(holder==null){
			return;
		}
		if(themeSettingsHelper.isNightTheme()){//设置夜间模式图标和字体颜色	
			if(holder.title!=null){
				holder.title.setTextColor(mContext.getResources().getColor(R.color.night_list_title_color));
			}
			if(holder.stract!=null){
				 holder.stract.setTextColor(mContext.getResources().getColor(R.color.night_list_abstract_color));
			}			
			
			if(holder.comments!=null){
				holder.comments.setTextColor(mContext.getResources().getColor(R.color.night_list_comment_color));
			}
			if(holder.commentIcon != null){
				holder.commentIcon.setImageDrawable(mContext.getResources().getDrawable(R.drawable.night_list_item_comment_icon));				
			}			
			
		}
		else{
			if(holder.title!=null){
				holder.title.setTextColor(mContext.getResources().getColor(R.color.list_title_color));
			}
			if(holder.stract!=null){
				 holder.stract.setTextColor(mContext.getResources().getColor(R.color.list_abstract_color));
			}	
			
			if(holder.comments!=null){
				holder.comments.setTextColor(mContext.getResources().getColor(R.color.list_comment_color));
			}
			if(holder.commentIcon != null){
				holder.commentIcon.setImageDrawable(mContext.getResources().getDrawable(R.drawable.list_item_comment_icon));				
			}			
			
		}
	}
}
