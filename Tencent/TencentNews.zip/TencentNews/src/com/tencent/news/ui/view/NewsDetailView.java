package com.tencent.news.ui.view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.tencent.news.R;
import com.tencent.news.utils.ThemeSettingsHelper;

@SuppressLint("ResourceAsColor")
public class NewsDetailView extends FrameLayout{
	private Context mContext;
	private LinearLayout mFailedLayout;
	private LinearLayout mLoadingLayout;
	private NewsWebView mWebView;
	private FrameLayout mNewDetailLayout;
	private ThemeSettingsHelper themeSettingsHelper = null;
	private Runnable loadingRemoveRunnable;
	private Runnable failedRemoveRunnable;
	private Handler handler = new Handler();
	public NewsDetailView(Context context) {
		super(context);
		init(context);
	}

	public NewsDetailView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init(context);
	}
	
	private void init(Context context){
		this.mContext = context;
		LayoutInflater.from(mContext).inflate(R.layout.news_detail_view_layout, this, true);
		mFailedLayout = (LinearLayout)findViewById(R.id.load_news_failed);
		mLoadingLayout = (LinearLayout)findViewById(R.id.news_detail_loading);
		mWebView = (NewsWebView)findViewById(R.id.news_webview);
		mNewDetailLayout = (FrameLayout)findViewById(R.id.news_detail_layout);
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(mContext);
		initRemoveMenuRunnable();
	}
	
	/**
	 * 应用样式
	 */
	public void applyTheme() {
		themeSettingsHelper.setViewBackgroudColor(mContext, mNewDetailLayout, R.color.view_bg_color);
		themeSettingsHelper.setViewBackgroudColor(mContext, mLoadingLayout, R.color.view_bg_color);
		themeSettingsHelper.setViewBackgroudColor(mContext, mFailedLayout, R.color.view_bg_color);
		themeSettingsHelper.setViewBackgroudColor(mContext, mWebView, R.color.view_bg_color);		
		ImageView news_loading_icon =  (ImageView)findViewById(R.id.news_loading_icon);
		if(news_loading_icon != null) {
			themeSettingsHelper.setImageViewSrc(mContext, news_loading_icon, R.drawable.news_loading_icon);
		}
	}
	
	public void Loading(){
		mLoadingLayout.setVisibility(View.VISIBLE);
		mFailedLayout.setVisibility(View.GONE);
	}
	
	public void loadComplete() {
		if(themeSettingsHelper != null && themeSettingsHelper.isDefaultTheme()) {
			AlphaAnimation animation = new AlphaAnimation(0, 1); 
			animation.setDuration(300);
			animation.setFillAfter(true);
			mWebView.setAnimation(animation);
		}
		mWebView.setVisibility(View.VISIBLE);
		handler.postDelayed(loadingRemoveRunnable, 10);
	}
	
	/**
	 * 防止闪烁
	 */
	private void initRemoveMenuRunnable() {
		loadingRemoveRunnable = new Runnable() {
			@Override
			public void run() {
				mLoadingLayout.setVisibility(View.GONE);
				handler.removeCallbacks(loadingRemoveRunnable);
				handler.postDelayed(failedRemoveRunnable, 10);
			}
		};
		
		failedRemoveRunnable = new Runnable() {
			@Override
			public void run() {
				mFailedLayout.setVisibility(View.GONE);
				handler.removeCallbacks(failedRemoveRunnable);
			}
		};
		
	}

	public void loadError() {
		mWebView.setVisibility(View.GONE);
		mLoadingLayout.setVisibility(View.GONE);
		mFailedLayout.setVisibility(View.VISIBLE);
	}
	
	public NewsWebView getNewsWebView() {
		return this.mWebView;
	}
	
	public FrameLayout getNewsDetailLayout(){
		return this.mNewDetailLayout;
	}
	
	public void setOnRetryClickListener(OnClickListener clickListener) {
		mFailedLayout.setOnClickListener(clickListener);
	}
}
