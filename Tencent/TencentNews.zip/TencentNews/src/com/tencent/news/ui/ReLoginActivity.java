package com.tencent.news.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnDismissListener;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.ImageView;

import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.cache.RssChannelSyncHelper;
import com.tencent.news.cache.UserDBHelper;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpDataResponse;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.pojo.Comment;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.model.pojo.WriteBackState;
import com.tencent.news.shareprefrence.SpDraft;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.omg.webdev.WebDev;

public class ReLoginActivity extends Activity implements HttpDataResponse {

	private static final int RELOGIN_SURE = 0x01;

	Item mItem;
	int which;
	String channelId;
	String imgUrl = "";
	String vid = "";
	String graphicLiveID = "";
	String specialID = "";
	String graphicLiveChlid = "";
	String shareType;
	String qqweiboStr;
	String lastInput;
	String tranQQweiboStr;
	String commentQQweiboStr;
	Comment comment;
	Dialog mDialog = null;
	private String attr = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		ImageView im = new ImageView(this);
		im.setBackgroundResource(R.drawable.transparent_pic);
		setContentView(im);

		Intent intent = getIntent();
		if (intent != null) {
			if (intent.hasExtra(Constants.WRITE_COMMENT_KEY)) {
				mItem = (Item) intent.getSerializableExtra(Constants.WRITE_COMMENT_KEY);
				graphicLiveID = mItem.getGraphicLiveID();
				specialID = mItem.getSpecialID();
			}
			if (intent.hasExtra(Constants.WRITE_COMMENT_CHANNEL_KEY)) {
				channelId = intent.getStringExtra(Constants.WRITE_COMMENT_CHANNEL_KEY);
			}
			if (intent.hasExtra(Constants.WRITE_COMMENT_IMG_KEY)) {
				imgUrl = intent.getStringExtra(Constants.WRITE_COMMENT_IMG_KEY);
			}
			if (intent.hasExtra(Constants.WRITE_COMMENT_VID_KEY)) {
				vid = intent.getStringExtra(Constants.WRITE_COMMENT_VID_KEY);
			}
			if (intent.hasExtra(Constants.WRITE_COMMENT_GRAPHICLIVECHLID_KEY)) {
				graphicLiveChlid = intent.getStringExtra(Constants.WRITE_COMMENT_GRAPHICLIVECHLID_KEY);
			}
			if (intent.hasExtra(Constants.WRITE_COMMENT_SHARE_TYPE_KEY)) {
				shareType = intent.getStringExtra(Constants.WRITE_COMMENT_SHARE_TYPE_KEY);
			}
			if (intent.hasExtra(Constants.WRITE_COMMENT_QQ_WEIBO_KEY)) {
				commentQQweiboStr = intent.getStringExtra(Constants.WRITE_COMMENT_QQ_WEIBO_KEY);
			}
			if (intent.hasExtra(Constants.WRITE_TRAN_QQ_WEIBO_KEY)) {
				tranQQweiboStr = intent.getStringExtra(Constants.WRITE_TRAN_QQ_WEIBO_KEY);
			}
			if (intent.hasExtra(Constants.WRITE_TRAN_COMMENT_KEY)) {
				comment = (Comment) intent.getParcelableExtra(Constants.WRITE_TRAN_COMMENT_KEY);
				attr = comment.getCattr();
			}
			if (intent.hasExtra(Constants.WRITE_WHICH_KEY)) {
				which = intent.getIntExtra(Constants.WRITE_WHICH_KEY, -1);
			}

			lastInput = loadDraft(mItem.getId(), comment != null ? comment.getReplyId() : "");
		}

		showDialog(RELOGIN_SURE);
	}

	public String loadDraft(String itemId, String replyId) {
		if (which == Constants.WRITE_COMMENT) {
			return SpDraft.getDraft(itemId, Constants.SP_DRAFT);
		} else if (which == Constants.WRITE_TRANS_COMMENT) {
			return SpDraft.getDraft(itemId + replyId, Constants.SP_DRAFT);
		} else {
			return SpDraft.getDraft(Constants.SUGGEST_ID, Constants.SP_DRAFT);
		}
	}

	@Override
	protected void onPrepareDialog(int id, Dialog dialog) {
		super.onPrepareDialog(id, dialog);

	}

	@Override
	protected Dialog onCreateDialog(int id) {

		if (id == RELOGIN_SURE) {
			mDialog = new AlertDialog.Builder(ReLoginActivity.this).setTitle("腾讯新闻").setMessage("帐号身份已过期，是否重新登录发表评论？").setPositiveButton("取消", new OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					dismissDialog(RELOGIN_SURE);
					finish();
				}
			}).setNegativeButton("重新登录", new OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					Intent loginIntent = new Intent();
					loginIntent.setClass(ReLoginActivity.this, LoginActivity.class);
					loginIntent.putExtra(Constants.LOGIN_FROM, Constants.LOGIN_FROM_SEND_BTN);
					startActivityForResult(loginIntent, Constants.REQUEST_CODE_LOGIN);

				}
			}).create();

			mDialog.setOnDismissListener(new OnDismissListener() {

				@Override
				public void onDismiss(DialogInterface dialog) {
					finish();
				}
			});

		}
		return mDialog;
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {

		if (resultCode == RESULT_OK) {
			send(which);
		} else if (resultCode == RESULT_CANCELED) {

		}

		finish();
		super.onActivityResult(requestCode, resultCode, data);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			dismissDialog(RELOGIN_SURE);
			finish();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	private void send(int which) {
		HttpDataRequest request = null;
		switch (which) {
		case Constants.WRITE_COMMENT:
			request = TencentNews.getInstance().publishQQNewsMulti(shareType, channelId, mItem.getId(), mItem.getUrl(), mItem.getTitle(), mItem.getBstract(), mItem.getCommentid(), lastInput,
					commentQQweiboStr, imgUrl, vid, graphicLiveID, graphicLiveChlid, specialID,attr);
			break;
		case Constants.WRITE_TRANS_COMMENT:
			request = TencentNews.getInstance().transComment(shareType, channelId, mItem.getId(), mItem.getUrl(), mItem.getTitle(), mItem.getBstract(), mItem.getCommentid(), comment.getReplyId(),
					lastInput, tranQQweiboStr, imgUrl, vid, graphicLiveID, graphicLiveChlid, specialID,attr);
			break;
		case Constants.WRITE_SUGGEST:
			request = TencentNews.getInstance().suggestQQNews(lastInput, UserDBHelper.getInstance().getUserInfo().getAccount(), UserDBHelper.getInstance().getUserInfo().getNick());
			break;
		}
		TaskManager.startHttpDataRequset(request, this);
	}

	@Override
	public void onHttpRecvOK(HttpTag tag, Object result) {

		if (tag.equals(HttpTag.SUGGEST_QQNEWS)) {
			TipsToast.getInstance().showTipsSuccess("感谢您的反馈!");
			deleteDraft(null, null);
			finish();
		} else {

			WriteBackState wbs = (WriteBackState) result;
			if (wbs.getPublish().equals("0")) {

				int tipNum = 0;
				StringBuffer tip = new StringBuffer();

				int comment = 1;
				int tencent = 1;
				int sina = 1;
				int qzong = 1;

				if (wbs.getComment() != null) {
					if (wbs.getComment().getRet().equals("0")) {// 成功
						comment = 1;
					} else if (wbs.getComment().getRet().equals("1")) {// 失败
						comment = 2;
					} else if (wbs.getComment().getRet().equals("2")) {// 重新登录
						comment = 4;
					} else {// 其他,认为失败了
						comment = 2;
					}
				} else {
					comment = 3;
				}

				if (wbs.getQqweibo() != null) {

					if (wbs.getQqweibo().getRet().equals("0")) {// 成功
						tencent = 1;
					} else if (wbs.getQqweibo().getRet().equals("1")) {// 失败
						tencent = 2;
					} else if (wbs.getQqweibo().getRet().equals("2")) {// 重新登录
						tencent = 4;
					} else {
						tencent = 2;
					}
				} else {
					tencent = 3;
				}

				if (wbs.getSina() != null) {
					if (wbs.getSina().getRet().equals("0")) {
						sina = 1;
					} else {
						sina = 2;
					}
				} else {
					sina = 3;
				}

				if (wbs.getQzone() != null) {
					if (wbs.getQzone().getRet().equals("0")) {
						qzong = 1;
					} else {
						qzong = 2;
					}
				} else {
					qzong = 3;
				}

				// 暂时没有
				// TEST[start]
				sina = 3;
				qzong = 3;
				// TEST[end]

				tip.append(comment);
				tip.append(tencent);
				tip.append(sina);
				tip.append(qzong);

				if (tip.toString().indexOf("4") >= 0) {
					// TipsToast.getInstance().showTipsError("发表失败\n请重新登录账号");
					UserDBHelper.getInstance().logoutUserInfo();
                    RssChannelSyncHelper.getInstance().onLogout();
					reLogin();
					return;
				}

				tipNum = Integer.parseInt(tip.toString());

				Log.i("CJZ", "结果码:" + tip.toString() + "--->" + tipNum);

				switch (tipNum) {
				case 1133:
					sendSuccess(tag);
					break;
				case 1233:
					// SToast.ToastLong("发表评论成功,同步到腾讯微博失败,请重试");
					// TipsToast.getInstance().showTipsSuccess("发表成功");
					sendSuccess(tag);
					break;
				case 1333:
					sendSuccess(tag);
					break;
				case 2133:
					// SToast.ToastLong("发表评论失败,同步到腾讯微博成功,请重试");
					// TipsToast.getInstance().showTipsSuccess("发表成功");
					sendSuccess(tag);
					break;
				case 2233:
					// SToast.ToastLong("发表失败,请重试");
					// if
					// (UserDBHelper.getInstance().getUserInfo().isOpenMBlog())
					// {
					// TipsToast.getInstance().showTipsError("发表失败");
					// } else {
					// TipsToast.getInstance().showTipsError("发表失败\n您没有开通腾讯微博");
					// }
					TipsToast.getInstance().showTipsError("发表失败\n请稍候再试");
					break;
				case 2333:
					// SToast.ToastLong("发表评论失败,请重试");
					TipsToast.getInstance().showTipsError("发表失败\n请稍候再试");
					break;
				case 3133:
					// SToast.ToastLong("同步到腾讯微博成功!");
					// SToast.ToastLong("发表成功");
					// TipsToast.getInstance().showTipsSuccess("发表成功");
					sendSuccess(tag);
					// quitActivity();
					break;
				case 3233:
					// SToast.ToastLong("同步到腾讯微博失败,请重试");
					if (UserDBHelper.getInstance().getUserInfo().isOpenMBlog()) {
						TipsToast.getInstance().showTipsError("发表失败\n请稍候再试");
					} else {
						// TODO:评论内容不能为空
						TipsToast.getInstance().showTipsError("发表失败\n您没有开通腾讯微博");
					}
					// sendSuccess(tag);
					break;
				case 3333:
					// 已被getPublish()拦截
					break;
				default:
					TipsToast.getInstance().showTipsError("发表失败\n请稍候再试");
					break;
				}
			} else {
				// SToast.ToastShort("发表失败,请重试");
				TipsToast.getInstance().showTipsError("发表失败\n请稍候再试");
			}
		}

	}

	@Override
	public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {
	}

	@Override
	public void onHttpRecvCancelled(HttpTag tag) {
	}

	private void sendSuccess(HttpTag tag) {

		TipsToast.getInstance().showTipsSuccess("发表成功");

		if (tag.equals(HttpTag.PUBLISH_QQNEWS_MULTI)) {
			// SToast.ToastShort("发表成功");

			// TODO:--->delete draft by id
			deleteDraft(mItem.getId(), comment != null ? comment.getReplyId() : "");

			if (lastInput.length() > 0 && !mItem.getCommentid().equals(Constants.FORBID_COMMENT_ID)) {
				backComment();
			}
		} else if (tag.equals(HttpTag.PUBLISH_TRANS_COMMENT_MULTI)) {
			// SToast.ToastShort("发表成功");
			if (lastInput.length() > 0) {

				// TODO:--->delete draft by id and replyid
				deleteDraft(mItem.getId(), comment.getReplyId());

				backTransComment();
			}
		}
		finish();
	}

	public void deleteDraft(String itemId, String replyId) {
		if (which == Constants.WRITE_COMMENT) {
			SpDraft.delDraft(itemId, Constants.SP_DRAFT);
		} else if (which == Constants.WRITE_TRANS_COMMENT) {
			SpDraft.delDraft(itemId + replyId, Constants.SP_DRAFT);
		} else {
			SpDraft.delDraft(Constants.SUGGEST_ID, Constants.SP_DRAFT);
		}
	}

	/**
	 * 添加自己的评论虚拟数据
	 */
	private void backComment() {
		Intent intent = new Intent();
		intent.setAction(Constants.WRITE_SUCCESS_ACTION);
		Comment c = new Comment();
		c.setReplyId(Constants.TAG_COMMENT_CANTBEUP);
		c.setHadUp(false);

		c.setSex(UserDBHelper.getInstance().getUserInfo().getSex());
		c.setHeadUrl(UserDBHelper.getInstance().getUserInfo().getHeadurl());
		c.setProvinceCity("腾讯网友");

		if (UserDBHelper.getInstance().getUserInfo() != null) {

			if (UserDBHelper.getInstance().getUserInfo().isOpenMBlog()) {
				c.setIsOpenMb("1");
				c.setChar_name(UserDBHelper.getInstance().getUserInfo().getName());
				c.setMb_head_url(UserDBHelper.getInstance().getUserInfo().getHeadurl());
				c.setMb_nick_name(UserDBHelper.getInstance().getUserInfo().getNick());
			}

			if (!TextUtils.isEmpty(UserDBHelper.getInstance().getUserInfo().getNick())) {
				c.setNick(UserDBHelper.getInstance().getUserInfo().getNick());
			} else {
				if (!TextUtils.isEmpty(UserDBHelper.getInstance().getUserInfo().getQqnick())) {
					c.setNick(UserDBHelper.getInstance().getUserInfo().getQqnick());
				} else {
					c.setNick("腾讯新闻用户");
				}
			}
		} else {
			c.setNick("腾讯新闻用户");
		}

		c.setPubTime("" + System.currentTimeMillis());
		c.setAgreeCount("0");

		String replyContent = lastInput.replaceAll("\n", " ");
		replyContent.replaceAll("  ", "");
		c.setReplyContent(replyContent);

		Comment[] cc = new Comment[1];
		cc[0] = c;
		intent.putExtra(Constants.WRITE_SUCCESS_SERVER_BACK_COMMENT, cc);
		intent.putExtra(Constants.WRITE_SUCCESS_SERVER_BACK_COMMENT_ITEM_ID, mItem.getId());
		sendBroadcast(intent);
	}

	private void backTransComment() {
		Comment[] cc = new Comment[2];
		Intent intent = new Intent();
		intent.setAction(Constants.WRITE_SUCCESS_ACTION);
		Comment c = new Comment();
		c.setReplyId(Constants.TAG_COMMENT_CANTBEUP);
		c.setHadUp(false);
		c.setSex(UserDBHelper.getInstance().getUserInfo().getSex());
		c.setHeadUrl(UserDBHelper.getInstance().getUserInfo().getHeadurl());
		c.setProvinceCity("腾讯网友");

		if (UserDBHelper.getInstance().getUserInfo() != null) {

			if (UserDBHelper.getInstance().getUserInfo().isOpenMBlog()) {
				c.setIsOpenMb("1");
				c.setChar_name(UserDBHelper.getInstance().getUserInfo().getName());
				c.setMb_head_url(UserDBHelper.getInstance().getUserInfo().getHeadurl());
				c.setMb_nick_name(UserDBHelper.getInstance().getUserInfo().getNick());
			}

			if (!TextUtils.isEmpty(UserDBHelper.getInstance().getUserInfo().getNick())) {
				c.setNick(UserDBHelper.getInstance().getUserInfo().getNick());
			} else {
				if (!TextUtils.isEmpty(UserDBHelper.getInstance().getUserInfo().getQqnick())) {
					c.setNick(UserDBHelper.getInstance().getUserInfo().getQqnick());
				} else {
					c.setNick("腾讯新闻用户");
				}
			}
		} else {
			c.setNick("腾讯新闻用户");
		}

		c.setPubTime("" + System.currentTimeMillis());
		c.setAgreeCount("0");

		String replyContent = lastInput.replaceAll("\n", " ");
		replyContent.replaceAll("  ", "");
		c.setReplyContent(replyContent);

		c.setReplyContent(replyContent);

		cc[0] = comment;
		cc[1] = c;// 盖楼我的评论在最后

		intent.putExtra(Constants.WRITE_SUCCESS_SERVER_BACK_COMMENT, cc);
		intent.putExtra(Constants.WRITE_SUCCESS_SERVER_BACK_COMMENT_ITEM_ID, mItem.getId());
		sendBroadcast(intent);
	}

	/**
	 * 登录态失效
	 */
	private void reLogin() {
		Intent i = new Intent();
		i.putExtra(Constants.WRITE_WHICH_KEY, which);
		i.putExtra(Constants.WRITE_COMMENT_CHANNEL_KEY, channelId);
		i.putExtra(Constants.WRITE_COMMENT_KEY, mItem);
		i.putExtra(Constants.WRITE_COMMENT_VID_KEY, this.vid);
		i.putExtra(Constants.WRITE_COMMENT_IMG_KEY, this.imgUrl);
		i.putExtra(Constants.WRITE_COMMENT_SHARE_TYPE_KEY, this.shareType);
		if (which == Constants.WRITE_TRANS_COMMENT) {
			i.putExtra(Constants.WRITE_TRAN_QQ_WEIBO_KEY, this.tranQQweiboStr);
			i.putExtra(Constants.WRITE_TRAN_COMMENT_KEY, this.comment);
		} else if (which == Constants.WRITE_COMMENT) {
			i.putExtra(Constants.WRITE_COMMENT_QQ_WEIBO_KEY, this.commentQQweiboStr);
		}
		i.setClass(this, ReLoginActivity.class);
		startActivity(i);
	}

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}
}
