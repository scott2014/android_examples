package com.tencent.news.ui.view;

import android.content.Context;
import android.content.Intent;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.config.Constants;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.shareprefrence.SpForbidenCommentNews;
import com.tencent.news.ui.PublishActivity;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.StringUtil;
import com.tencent.news.utils.ThemeSettingsHelper;

public class WritingCommentView extends LinearLayout {

	public static final boolean STYLE_WHITE = false;
	public static final boolean STYLE_BLACK = true;

	// UI
	boolean isBlack = STYLE_WHITE;// false白, true黑
	int detailOrCommentPage = 0;// 0:底层页, 1:评论页
	boolean hasDownload = true;
	Context context;
	LinearLayout writing_comment;
	LinearLayout gotocommentlist;
	TextView commentNum;
	ImageView txWeiboIcon;
	ImageView sofa;
	TextView originalNews;
	LinearLayout downloadbox;
	ImageView download;
	Button btnInput;
	private View intercept_writing_comment;

	// data
	boolean canWrite = false;
	int cNum;
	String channelId;
	Item mItem = null;

	String vid = "";
	String graphicLiveChlid = "";
	String img = "";
	private ThemeSettingsHelper themeSettingsHelper = null;
	
	public WritingCommentView(Context context) {
		this(context, null);
	}

	public WritingCommentView(Context context, AttributeSet attrs) {
		super(context, attrs);
		this.context = context;

		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(context);
		TypedArray arrayType = context.obtainStyledAttributes(attrs, com.tencent.news.R.styleable.WritingCommentBar);
		isBlack = arrayType.getBoolean(R.styleable.WritingCommentBar_is_black, false);
		hasDownload = arrayType.getBoolean(R.styleable.WritingCommentBar_has_download_btn, true);
		arrayType.recycle();
		initView();
		
		
/*		btnInput.setBackgroundResource(R.drawable.night_comment_box);
		btnInput.setTextColor(Color.parseColor("#85888b"));
		commentNum.setTextColor(Color.parseColor("#f0f4f8"));
		originalNews.setTextColor(Color.parseColor("#f0f4f8"));*/
		
		themeSettingsHelper.setTextViewColor(context, commentNum, R.color.writing_comment_change_btn_color);
		themeSettingsHelper.setTextViewColor(context, originalNews, R.color.writing_comment_change_btn_color);
		themeSettingsHelper.setViewBackgroud(context, btnInput, R.drawable.comment_box);
		themeSettingsHelper.setTextViewColor(context, btnInput, R.color.writing_comment_hit_color);
		
		if (isBlack || themeSettingsHelper.isNightTheme()) {
			gotocommentlist.setBackgroundResource(R.drawable.goto_comment_selector_black);
			txWeiboIcon.setImageResource(R.drawable.comment_weibo_icon_black);
			sofa.setImageResource(R.drawable.comment_sofa_icon_black);
			writing_comment.setBackgroundResource(R.drawable.comment_floor_black);
			writing_comment.setPadding(MobileUtil.dpToPx(8), MobileUtil.dpToPx(8), MobileUtil.dpToPx(8), MobileUtil.dpToPx(8));
			if(isBlack){
			btnInput.setBackgroundResource(R.drawable.comment_box_black);
			commentNum.setTextColor(Color.parseColor("#d4d4d4"));
			originalNews.setTextColor(Color.parseColor("#d4d4d4"));
			if(themeSettingsHelper.isNightTheme()){
				themeSettingsHelper.setTextViewColor(context, commentNum, R.color.writing_comment_change_btn_color);
				themeSettingsHelper.setTextViewColor(context, originalNews, R.color.writing_comment_change_btn_color);
				themeSettingsHelper.setViewBackgroud(context, btnInput, R.drawable.comment_box);
				themeSettingsHelper.setTextViewColor(context, btnInput, R.color.writing_comment_hit_color);
/*				commentNum.setTextColor(R.color.night_writing_comment_change_btn_color);
				originalNews.setTextColor(R.color.night_writing_comment_change_btn_color);
				btnInput.setBackgroundResource(R.drawable.night_comment_box);
				btnInput.setTextColor(R.color.night_writing_comment_hit_color);*/
			}

			if (hasDownload) {
				downloadbox.setVisibility(View.VISIBLE);
				download.setVisibility(View.VISIBLE);
			} else {
				downloadbox.setVisibility(View.GONE);
				download.setVisibility(View.GONE);
			}
			}
		}
		btnInput.setPadding(MobileUtil.dpToPx(5), 0, MobileUtil.dpToPx(5), 0);
	}

	/**
	 * 初始化的命运啊!都是一样一样的~嚎~
	 * 
	 * @author jackiecheng
	 */
	private void initView() {
		LayoutInflater.from(context).inflate(R.layout.view_writing_comment, this, true);
		writing_comment = (LinearLayout) findViewById(R.id.writing_comment);
		gotocommentlist = (LinearLayout) findViewById(R.id.gotocommentlist);
		commentNum = (TextView) findViewById(R.id.commentNum);
		txWeiboIcon = (ImageView) findViewById(R.id.txWeiboIcon);
		sofa = (ImageView) findViewById(R.id.sofa);
		originalNews = (TextView) findViewById(R.id.originalNews);
		downloadbox = (LinearLayout) findViewById(R.id.downloadbox);
		download = (ImageView) findViewById(R.id.download);
		btnInput = (Button) findViewById(R.id.btn_input);
		intercept_writing_comment = (View) findViewById(R.id.intercept_writing_comment);
		initListener();
	}

	OnClickListener l = new OnClickListener() {

		@Override
		public void onClick(View v) {
			switch (v.getId()) {

			case R.id.gotocommentlist:
				if (mOnChangeClick != null) {
					mOnChangeClick.change();
				}
				break;

			case R.id.downloadbox:
				if (mOnDownloadClick != null && canWrite) {
					mOnDownloadClick.download();
				}
				break;
			case R.id.btn_input:
				if (!canWrite) {
					return;
				}
				Intent intent = new Intent();
				intent.putExtra(Constants.WRITE_COMMENT_CHANNEL_KEY, channelId);
				intent.putExtra(Constants.WRITE_COMMENT_KEY, mItem);
				intent.putExtra(Constants.WRITE_COMMENT_VID_KEY, vid);
				intent.putExtra(Constants.WRITE_COMMENT_GRAPHICLIVECHLID_KEY, graphicLiveChlid);
				intent.putExtra(Constants.WRITE_COMMENT_IMG_KEY, img);
				intent.setClass(context, PublishActivity.class);
				context.startActivity(intent);

				break;

			}
		}
	};

	private void initListener() {
		gotocommentlist.setOnClickListener(l);
		downloadbox.setOnClickListener(l);
		btnInput.setOnClickListener(l);
	}

	private void resetAllViews() {
		gotocommentlist.setVisibility(View.GONE);
		commentNum.setVisibility(View.GONE);
		txWeiboIcon.setVisibility(View.GONE);
		sofa.setVisibility(View.GONE);
		originalNews.setVisibility(View.GONE);
		downloadbox.setVisibility(View.GONE);
		download.setVisibility(View.GONE);

		if (isBlack) {
			if (detailOrCommentPage == 0) {
				if (hasDownload) {
					downloadbox.setVisibility(View.VISIBLE);
					download.setVisibility(View.VISIBLE);
				} else {
					downloadbox.setVisibility(View.GONE);
					download.setVisibility(View.GONE);
				}
			}
		}
	}

	/**
	 * 设置评论数
	 * 
	 * @param num
	 * @author jackiecheng
	 */
	public void setCommentNum(int num) {
		cNum = num;
		if(themeSettingsHelper.isNightTheme() || isBlack){
			if (num >= 10000) {
				commentNum.setText(StringUtil.tenTh2wan(num));
				txWeiboIcon.setImageResource(R.drawable.night_comment_lajiao2_icon);
			} else if (num >= 1000) {
				commentNum.setText("" + num);
				txWeiboIcon.setImageResource(R.drawable.night_comment_lajiao1_icon);
			} else if (num > 0) {
				commentNum.setText("" + num);
				txWeiboIcon.setImageResource(R.drawable.night_comment_weibo_icon);
			}
		}else{
			if (num >= 10000) {
				commentNum.setText(StringUtil.tenTh2wan(num));
				txWeiboIcon.setImageResource(R.drawable.comment_lajiao2_icon);
			} else if (num >= 1000) {
				commentNum.setText("" + num);
				txWeiboIcon.setImageResource(R.drawable.comment_lajiao1_icon);
			} else if (num > 0) {
				commentNum.setText("" + num);
				txWeiboIcon.setImageResource(R.drawable.comment_weibo_icon);
			}
		}

		if (mItem != null && (Constants.FORBID_COMMENT_ID.equals(mItem.getCommentid())) || SpForbidenCommentNews.getForbidenCommentNews(mItem.getId())) {
			cNum = -1;
		}

		refreshUI();
	}

	/**
	 * 无键盘,可评论,评论数大于0,新闻页
	 */
	private void UI_noKey_canComment_big0_detail() {
		resetAllViews();
		gotocommentlist.setVisibility(View.VISIBLE);
		commentNum.setVisibility(View.VISIBLE);
		txWeiboIcon.setVisibility(View.VISIBLE);
		btnInput.setVisibility(View.VISIBLE);
	}

	/**
	 * 无键盘,可评论,评论数大于0,评论页
	 */
	private void UI_noKey_canComment_big0_comment() {
		resetAllViews();
		gotocommentlist.setVisibility(View.VISIBLE);
		originalNews.setVisibility(View.VISIBLE);
		btnInput.setVisibility(View.VISIBLE);
	}

	/**
	 * 无键盘,禁评论,新闻页
	 */
	private void UI_noKey_canNotComment_detail() {
		resetAllViews();
		btnInput.setVisibility(View.VISIBLE);
		btnInput.setText("其实,也是有地方可以说两句的~");
	}

	/**
	 * 无键盘,禁评论,评论页
	 */
	private void UI_noKey_canNotComment_comment() {
		resetAllViews();
		btnInput.setVisibility(View.VISIBLE);
		btnInput.setText("其实,也是有地方可以说两句的~");
		gotocommentlist.setVisibility(View.VISIBLE);
		originalNews.setVisibility(View.VISIBLE);
	}

	/**
	 * 无键盘,可评论,评论数等于0,新闻页
	 */
	private void UI_noKey_canComment_eq0_detail() {
		resetAllViews();
		gotocommentlist.setVisibility(View.VISIBLE);
		sofa.setVisibility(View.VISIBLE);
		btnInput.setVisibility(View.VISIBLE);
	}

	/**
	 * 无键盘,可评论,评论数等于0,评论页
	 */
	private void UI_noKey_canComment_eq0_comment() {
		resetAllViews();
		gotocommentlist.setVisibility(View.VISIBLE);
		originalNews.setVisibility(View.VISIBLE);
		btnInput.setVisibility(View.VISIBLE);
	}

	public void setDCPage(int detailOrCommentPage) {
		this.detailOrCommentPage = detailOrCommentPage;
	}

	/**
	 * 刷界面,自从有了它,你好,我也好
	 * 
	 * @param detailOrCommentPage
	 * @author jackiecheng
	 */
	public void refreshUI() {

		if (detailOrCommentPage == 0) {
			if (cNum > 0) {
				UI_noKey_canComment_big0_detail();
			} else if (cNum == 0) {
				UI_noKey_canComment_eq0_detail();
			} else {
				UI_noKey_canNotComment_detail();
			}
		} else {
			if (cNum > 0) {
				UI_noKey_canComment_big0_comment();
			} else if (cNum == 0) {
				UI_noKey_canComment_eq0_comment();
			} else {
				UI_noKey_canNotComment_comment();
			}

		}
	}

	/**
	 * 初始化利器啊,不用不行啊!!
	 * 
	 * @param i
	 * @author jackiecheng
	 */
	public void setItem(String channelId, Item i) {
		mItem = i;
		this.channelId = channelId;
		try {
			cNum = Integer.parseInt(mItem.getCommentNum());
		} catch (Exception e) {
			cNum = 0;
		}
		setCommentNum(cNum);
	};

	// /**
	// * 这个是得等到[转一下]的时候再用哈
	// *
	// * @param c
	// * @author jackiecheng
	// */
	// public void setComment(Comment c) {
	// mComment = c;
	// }

	OnChangeClick mOnChangeClick;
	OnDownloadClick mOnDownloadClick;

	public interface OnChangeClick {
		public void change();
	}

	public OnChangeClick getmOnChangeClick() {
		return mOnChangeClick;
	}

	public void setDetailCommentChangeClick(OnChangeClick mOnChangeClick) {
		this.mOnChangeClick = mOnChangeClick;
	}

	public interface OnDownloadClick {
		public void download();
	}

	public OnDownloadClick getOnDownloadClick() {
		return mOnDownloadClick;
	}

	public void setOnDownloadClick(OnDownloadClick mOnDownloadClick) {
		this.mOnDownloadClick = mOnDownloadClick;
	}

	public void canWrite(boolean canWrite) {
		this.canWrite = canWrite;
	}

	public String getVid() {
		return vid;
	}

	public void setVid(String vid) {
		this.vid = vid;
	}

	public String getGraphicLiveChlid() {
		return graphicLiveChlid;
	}

	public void setGraphicLiveChlid(String graphicLiveChlid) {
		this.graphicLiveChlid = graphicLiveChlid;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public void setText(String text) {
		if (originalNews != null) {
			originalNews.setText(text);
		}
	}
	
	@Override
	public void setEnabled(boolean enabled) {
		super.setEnabled(enabled);
		btnInput.setEnabled(enabled);
		downloadbox.setEnabled(enabled);
		gotocommentlist.setEnabled(enabled);
		if(enabled){
			intercept_writing_comment.setVisibility(View.GONE);
		}else{
			intercept_writing_comment.setVisibility(View.VISIBLE);
		}
	}

}
