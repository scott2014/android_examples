package com.tencent.news.ui;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;

import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.boss.EventId;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.model.pojo.RssCatListItem;
import com.tencent.news.rss.RssListBaseActivity;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.TitleBar;
import com.tencent.omg.webdev.WebDev;

@SuppressLint("ResourceAsColor")
public class RssMediaHistoryActivity extends RssListBaseActivity {
    
    public static final String SUB_CLASS_NAME = "RssMediaHistoryActivity";

    private static final String RSS_HISTORY_TAG_PREFIX = "rss_history_";
    private RssCatListItem rssChannelListItem;

    private TitleBar mTitleBar = null;
    private View mMask;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rss_media_history_layout);
        initViews();
        initListener();
        initData();
        super.init();
        
        if (rssChannelListItem != null) {
            WebDev.trackCustomEvent(this, EventId.BOSS_RSS_CLICK_HISTORY, rssChannelListItem.getChlid());
        }
    }

    private void initViews() {
        mTitleBar = (TitleBar) findViewById(R.id.rss_title_bar);
        mMask = (View)findViewById(R.id.mask_view);

        mTitleBar.showBackBtn();
        mTitleBar.setBackName("返回");
    }

    private void initListener() {
        mTitleBar.setBackClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void initData() {
        Intent intent = getIntent();
        rssChannelListItem = (RssCatListItem) intent.getSerializableExtra(RssMediaActivity.RSS_MEDIA_ITEM);
        if (rssChannelListItem.getChlname() != null) {
            mTitleBar.setTitleText(rssChannelListItem.getChlname());
        }
    }

    @Override
    protected String getRssContentTag() {
        return RSS_HISTORY_TAG_PREFIX + rssChannelListItem.getChlid();
    }

    @Override
    public void applyTheme() {
        super.applyTheme();
        mTitleBar.applyTitleBarTheme(this);
        themeSettingsHelper.setViewBackgroudColor(this, mMask, R.color.mask_page_color);
    }
    
    @Override
    protected void doRefresh() {
        HttpDataRequest request = TencentNews.getInstance().getSubNewsIndex(rssChannelListItem.getChlid());
        TaskManager.startHttpDataRequset(request, this);
    }
    
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
            quitActivity();
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    protected String getSubClassName() {
        return SUB_CLASS_NAME;
    }
}
