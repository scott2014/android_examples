
package com.tencent.news.ui;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.boss.EventId;
import com.tencent.news.cache.RssChannelSyncHelper;
import com.tencent.news.command.GetImageRequest;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.model.pojo.ImageResult;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.model.pojo.RssCatListItem;
import com.tencent.news.model.pojo.RssSubItem;
import com.tencent.news.model.pojo.UserInfo;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.news.ui.view.TitleBar;
import com.tencent.news.utils.MobileUtil;
import com.tencent.omg.webdev.WebDev;

@SuppressLint("ResourceAsColor")
public class RssMediaActivity extends BaseActivity {
    
    public static final String RSS_MEDIA_ITEM = "RSS_MEDIA_ITEM";

    private float downX;
    private float upX;
    private float downY;
    private float upY;
    
    private RssCatListItem rssChannelListItem;
    private boolean rssChannelIsAdd;
    
    private RelativeLayout mRootLayout = null;
    private TitleBar mTitleBar = null;
    private View mMask;
    
    private boolean mGetIcon = false;
    private ImageView mMediaIcon = null;
    private ImageView mMediaIconCover = null;
    private TextView mMediaName = null;
    private TextView mMediaSubCount = null;
    
    private LinearLayout mDesc1Layout = null;
    private TextView mDescTitle1 = null;
    private TextView mDescContent1 = null;

    private LinearLayout mDesc2Layout = null;
    private TextView mDescTitle2 = null;
    private TextView mDescContent2 = null;

    private LinearLayout mBtnHistoryLayout = null;
    private TextView mTxtHistory = null;
    private ImageView mImgHistory = null;

    private ImageView mMediaDivider = null;
    
    private LinearLayout mBtnSendMsgLayout = null;
    private TextView mTxtSendMsg = null;
    private ImageView mImgSendMsg = null;
    
    private FrameLayout mBtnRssAddDel = null;
    private TextView mTxtRssAddDel = null;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rss_media_activity_layout);
        initViews();
        initListener();
        initData();
        
        if (rssChannelListItem != null) {
            WebDev.trackCustomEvent(this, EventId.BOSS_RSS_CLICK_MEDIA_CARD, rssChannelListItem.getChlid());
        }
    }

    private void initViews() {
        mRootLayout = (RelativeLayout) findViewById(R.id.root_layout);
        mMask = (View) findViewById(R.id.mask_view);
        mTitleBar = (TitleBar) findViewById(R.id.title_bar);
        
        mMediaIcon = (ImageView) findViewById(R.id.media_icon);
        mMediaIconCover = (ImageView) findViewById(R.id.media_icon_cover);
        mMediaName = (TextView) findViewById(R.id.media_name);
        mMediaSubCount = (TextView) findViewById(R.id.sub_count);
        
        mDesc1Layout = (LinearLayout) findViewById(R.id.desc1_layout);
        mDescTitle1 = (TextView) findViewById(R.id.desc_title1);
        mDescContent1 = (TextView) findViewById(R.id.desc_content1);
        
        mDesc2Layout = (LinearLayout) findViewById(R.id.desc2_layout);
        mDescTitle2 = (TextView) findViewById(R.id.desc_title2);
        mDescContent2 = (TextView) findViewById(R.id.desc_content2);
        
        mBtnHistoryLayout = (LinearLayout) findViewById(R.id.btn_history_layout);
        mTxtHistory = (TextView) findViewById(R.id.btn_history);
        mImgHistory = (ImageView) findViewById(R.id.img_history);
        
        mMediaDivider = (ImageView) findViewById(R.id.divider_line);
        
        mBtnSendMsgLayout = (LinearLayout) findViewById(R.id.btn_send_message_layout);
        mTxtSendMsg = (TextView) findViewById(R.id.btn_send_message);
        mImgSendMsg = (ImageView) findViewById(R.id.img_send_message);
        
        mBtnRssAddDel = (FrameLayout) findViewById(R.id.btn_add_del);
        mTxtRssAddDel = (TextView) findViewById(R.id.btn_add_del_text);
    }
    
    private void initListener() {
        mTitleBar.setBackClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                quitActivity();
            }
        });
        
        mBtnHistoryLayout.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                i.setClass(RssMediaActivity.this, RssMediaHistoryActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable(RSS_MEDIA_ITEM, rssChannelListItem);
                i.putExtras(bundle);
                RssMediaActivity.this.startActivity(i);
            }
        });
        
        mBtnSendMsgLayout.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                WebDev.trackCustomEvent(RssMediaActivity.this, EventId.BOSS_RSS_CLICK_SEND_MSG_TO_WRITOR);
                
                if (rssChannelListItem.getUin() != null
                        && rssChannelListItem.getUin().length() > 0) {
                    
                    Intent intent = new Intent();
                    SettingInfo settingData = SettingObservable.getInstance().getData();
                    if (settingData.getUserInfo() != null && settingData.getUserInfo().getUin() != null) {
                            intent.putExtra("uin", rssChannelListItem.getUin());
                            intent.putExtra("nick", rssChannelListItem.getChlname());
                            intent.putExtra("mediaHeadUrl", rssChannelListItem.getIcon());
                            intent.setClass(RssMediaActivity.this, ChatActivity.class);
                            startActivity(intent);
                    } else {
                        intent.setClass(RssMediaActivity.this, LoginActivity.class);
                        intent.putExtra(Constants.LOGIN_FROM, Constants.LOGIN_FROM_RSS_SEND);
                        startActivityForResult(intent, Constants.REQUEST_CODE_LOGIN);
                    }
                }
            }
        });
        
        mBtnRssAddDel.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (rssChannelListItem != null) {
                    if (rssChannelIsAdd) {
                        if (RssChannelSyncHelper.getInstance().getRssChannelCount() <= 1) {
                            TipsToast.getInstance().showTipsError(getResources().getString(R.string.add_rss_last_tips));
                            return;
                        } else {
                            RssChannelSyncHelper.getInstance().delChannel(rssChannelListItem.getChlid(), true);
                        }
                    } else {
                        RssChannelSyncHelper.getInstance().addChannel(rssChannelListItem.getChlid(), true);
                    }
                }
                changeRssStatus(!rssChannelIsAdd);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            if (requestCode == Constants.REQUEST_CODE_LOGIN) {
                if (data != null && data.hasExtra(Constants.LOGIN_SUCCESS_BACK_USER_KEY)) {
                    UserInfo userinfo = (UserInfo) data.getSerializableExtra(Constants.LOGIN_SUCCESS_BACK_USER_KEY);
                    if (userinfo != null && userinfo.getAccount() != null) {
                        Intent intent = new Intent();
                        intent.putExtra("uin", rssChannelListItem.getUin());
                        intent.putExtra("nick", rssChannelListItem.getChlname());
                        intent.putExtra("mediaHeadUrl", rssChannelListItem.getIcon());
                        intent.setClass(RssMediaActivity.this, ChatActivity.class);
                        startActivity(intent);
                    }
                }
                
            }
           
        } 
        
        super.onActivityResult(requestCode, resultCode, data);
    }
    
    @Override
    public void applyTheme() {
        super.applyTheme();
        themeSettingsHelper.setViewBackgroudColor(this, mRootLayout, R.color.root_bg_color);
        themeSettingsHelper.setViewBackgroudColor(this, mMask, R.color.mask_page_color);
        mTitleBar.applyTitleBarTheme(this);
        
        if (!mGetIcon) {
            themeSettingsHelper.setImageViewSrc(this, mMediaIcon, R.drawable.rss_placeholder_header);
        }
        themeSettingsHelper.setImageViewSrc(this, mMediaIconCover, R.drawable.media_icon_cover);
        themeSettingsHelper.setTextViewColor(this, mMediaName, R.color.media_txt_color);
        themeSettingsHelper.setTextViewColor(this, mMediaSubCount, R.color.media_txt_color_gray);
        
        themeSettingsHelper.setViewBackgroud(this, mDesc1Layout, R.drawable.media_btn_bg);
        themeSettingsHelper.setTextViewColor(this, mDescTitle1, R.color.media_txt_color_gray);
        themeSettingsHelper.setTextViewColor(this, mDescContent1, R.color.media_txt_color);

        themeSettingsHelper.setViewBackgroud(this, mDesc2Layout, R.drawable.media_btn_bg);
        themeSettingsHelper.setTextViewColor(this, mDescTitle2, R.color.media_txt_color_gray);
        themeSettingsHelper.setTextViewColor(this, mDescContent2, R.color.media_txt_color);

        themeSettingsHelper.setTextViewColor(this, mTxtHistory, R.color.media_txt_color);
        themeSettingsHelper.setImageViewSrc(this, mImgHistory, R.drawable.set_unfold);

        themeSettingsHelper.setViewBackgroud(this, mMediaDivider, R.drawable.media_divider);

        themeSettingsHelper.setTextViewColor(this, mTxtSendMsg, R.color.media_txt_color);
        themeSettingsHelper.setImageViewSrc(this, mImgSendMsg, R.drawable.set_unfold);

        mTitleBar.showBackBtn();
        mTitleBar.setBackName("返回");
        
        changeRssStatus(rssChannelIsAdd);
    }

    private void initData() {
        Intent intent = getIntent();
        if (intent != null) {
            rssChannelListItem = (RssCatListItem) intent.getSerializableExtra(RSS_MEDIA_ITEM);
            rssChannelIsAdd = RssChannelSyncHelper.getInstance().isBookedChannel(rssChannelListItem.getChlid());
            
            if (rssChannelListItem.isEmpty()) {
                HttpDataRequest request = TencentNews.getInstance().getRssSubItem(rssChannelListItem.getChlid());
                TaskManager.startHttpDataRequset(request, this);
            }
        }
        setData(rssChannelListItem);
        changeRssStatus(rssChannelIsAdd);
    }
    
    private void setData(RssCatListItem item) {
        if (rssChannelListItem != null) {
            if (rssChannelListItem.getChlname() != null) {
                mTitleBar.setTitleText(rssChannelListItem.getChlname());
                mMediaName.setText(rssChannelListItem.getChlname());
            }
            
            if (rssChannelListItem.getIcon() != null) {
                getImageData(rssChannelListItem.getIcon(), rssChannelListItem.getChlid());
            }
            if (rssChannelListItem.getSubCount() != null) {
                mMediaSubCount.setText(rssChannelListItem.getSubCount() + "人订阅");
            }

            if (rssChannelListItem.getDesc() != null) {
                mDescContent1.setText(rssChannelListItem.getDesc());
            }
            if (rssChannelListItem.getIntro() != null) {
                mDescContent2.setText(rssChannelListItem.getIntro());
            }
        }
    }
    
    // 改变订阅状态，重绘UI
    private void changeRssStatus(boolean book) {
        rssChannelIsAdd = book;

        if (rssChannelIsAdd) {
            themeSettingsHelper.setViewBackgroud(this, mBtnHistoryLayout, R.drawable.media_btn_top_selector);
            mMediaDivider.setVisibility(View.VISIBLE);
            mBtnSendMsgLayout.setVisibility(View.VISIBLE);
            themeSettingsHelper.setViewBackgroud(this, mBtnSendMsgLayout, R.drawable.media_btn_foot_selector);
            
            mBtnRssAddDel.setBackgroundResource(R.drawable.rss_btn_del_selector);
            mTxtRssAddDel.setText("取消订阅");
        } else {
            themeSettingsHelper.setViewBackgroud(this, mBtnHistoryLayout, R.drawable.media_btn_selector);
            mMediaDivider.setVisibility(View.GONE);
            mBtnSendMsgLayout.setVisibility(View.GONE);

            mBtnRssAddDel.setBackgroundResource(R.drawable.rss_btn_add_selector);
            mTxtRssAddDel.setText("订阅");
        }
    }

    /**
     * 获取图片数据
     */
    private void getImageData(String iconUrl, String chlid) {
        if (iconUrl != null && iconUrl.length() > 0) {
            GetImageRequest request = new GetImageRequest();
            request.setUrl(iconUrl);
            request.setTag(chlid);
            ImageResult result = TaskManager.startPngImageTask(request, this);
            if (result.isResultOK() && result.getRetBitmap() != null) {
                mMediaIcon.setImageBitmap(result.getRetBitmap());
                mGetIcon = true;
            }
        }
    }

    @Override
    public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm, String path) {
        switch (imageType) {
            case PNG_IMAGE:
                if (mMediaIcon != null) {
                    mMediaIcon.setImageBitmap(bm);
                    mGetIcon = true;
                }
                break;
            default:
                break;
        }
    }

    @Override
    public void onImageRecvError(ImageType imageType, Object tag, int retCode) {
        if (mMediaIcon != null) {
            mMediaIcon.setImageResource(R.drawable.rss_placeholder_header);
        }
    }
    
    @Override
    public void onHttpRecvOK(HttpTag tag, Object result) {
        if (tag.equals(HttpTag.GET_RSS_SUB_ITEM)) {
            RssSubItem rssSubItem = (RssSubItem) result;
            if (rssSubItem.getRet().equals("0")) {
                rssChannelListItem = rssSubItem.getChannelInfo();
                setData(rssChannelListItem);
            }
        }
    }
    
    @Override
    public Intent getIntent() {
        return super.getIntent();
    }
    
    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        final float x = ev.getX();
        final float y = ev.getY();
        if (ev.getAction() == MotionEvent.ACTION_DOWN) {
            downX = x;
            downY = y;
        } else if (ev.getAction() == MotionEvent.ACTION_UP) {
            upX = x;
            upY = y;
            if (upX > downX && Math.abs(upX - downX) > MobileUtil.dpToPx(100) && Math.abs(upY - downY) / Math.abs(upX - downX) < 0.4) {
                quitActivity();
            }
        }
        return super.dispatchTouchEvent(ev);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
            quitActivity();
        }
        return super.dispatchKeyEvent(event);
    }
}
