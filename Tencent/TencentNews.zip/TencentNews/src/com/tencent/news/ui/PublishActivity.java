package com.tencent.news.ui;

import java.util.Properties;

import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.boss.EventId;
import com.tencent.news.cache.RssChannelSyncHelper;
import com.tencent.news.cache.UserDBHelper;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpDataResponse;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.model.pojo.Comment;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.model.pojo.UserInfo;
import com.tencent.news.model.pojo.WriteBackState;
import com.tencent.news.shareprefrence.SpDraft;
import com.tencent.news.shareprefrence.SpForbidenCommentNews;
import com.tencent.news.shareprefrence.SpSetting;
import com.tencent.news.system.NetStatusReceiver;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.system.observer.SettingObserver;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.InputMethodEventView;
import com.tencent.news.ui.view.ShareDialog;
import com.tencent.news.ui.view.InputMethodEventView.InputMethodChangeLinstener;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.ThemeSettingsHelper;
import com.tencent.omg.webdev.WebDev;

public class PublishActivity extends Activity implements SettingObserver, OnClickListener, HttpDataResponse {

	private SettingObservable settingObv;
	private SettingInfo settingData;

	protected static final int MAX_WORDS_COMMENT_NUM = 750;
	protected static final int MAX_WORDS_WEIBO_NUM = 140;
	protected static final int MAX_WORDS_SUGGEST_NUM = 1000;

	protected static final String QQCOMMENT = "qqcomment";
	protected static final String QQWEIBO = ",qqweibo";

	Comment comment;
	String itemIdForDraft;
	String replyIdForDraft;
	String imgUrl = "";
	String vid = "";
	String specialID = "";
	String graphicLiveID = "";
	String graphicLiveChlid = "";
	String channelId = "";
	Item mItem;
	String tranQQweiboStr = "";
	String commentQQweiboStr = "";
	String replyContent = "";
	String contentQqweibo = "";
	String lastInput = "";
	String shareType = QQCOMMENT;
	String shareTencent;
	String shareSina;
	String shareQzone;
	private String attr = "";

	Properties pts;

	int long_short = 0;

	boolean if_share_to_tx_weibo = true;
	InputMethodEventView keyboardevent;
	RelativeLayout writing_comment;
	Button btn_send = null;
	EditText input = null;
	TextView remainNum = null;
	int remainWordsNum;
	ImageView shareToTXWeibo = null;
	TextView shareToTXWeiboText = null;
	View finishit;
	/**
	 * 要评论的新闻是不是被禁止评论了<br/>
	 * false该新闻没有被禁止,true表示该新闻禁止评论
	 */
	boolean isForbid = false;

	// long statistics_send_start;
	// long statistics_send_end;
	// long statistics_send_total;

	private ThemeSettingsHelper themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(this);

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		overridePendingTransition(R.anim.fade_in, 0);
		settingObv = SettingObservable.getInstance();
		settingObv.registerObserver(PublishActivity.this);

		setContentView(R.layout.activity_publish);

		Intent intent = getIntent();
		if (intent != null) {
			if (intent.hasExtra(Constants.WRITE_COMMENT_KEY)) {
				mItem = (Item) intent.getSerializableExtra(Constants.WRITE_COMMENT_KEY);
				contentQqweibo = " || #我在看新闻# " + mItem.getTitle() + mItem.getUrl();

				long_short = mItem.getUrl().length() - 12;

				itemIdForDraft = mItem.getId();

				isForbid = mItem.getCommentid().equals(Constants.FORBID_COMMENT_ID) || SpForbidenCommentNews.getForbidenCommentNews(mItem.getId());

				graphicLiveID = mItem.getGraphicLiveID();
				specialID = mItem.getSpecialID();

			}
			if (intent.hasExtra(Constants.WRITE_COMMENT_CHANNEL_KEY)) {
				channelId = intent.getStringExtra(Constants.WRITE_COMMENT_CHANNEL_KEY);
			}
			if (intent.hasExtra(Constants.WRITE_COMMENT_IMG_KEY)) {
				imgUrl = intent.getStringExtra(Constants.WRITE_COMMENT_IMG_KEY);
			}
			if (intent.hasExtra(Constants.WRITE_COMMENT_VID_KEY)) {
				vid = intent.getStringExtra(Constants.WRITE_COMMENT_VID_KEY);
			}
			if (intent.hasExtra(Constants.WRITE_COMMENT_GRAPHICLIVECHLID_KEY)) {
				graphicLiveChlid = intent.getStringExtra(Constants.WRITE_COMMENT_GRAPHICLIVECHLID_KEY);
			}
			if (intent.hasExtra(Constants.WRITE_TRAN_COMMENT_KEY)) {
				comment = (Comment) intent.getParcelableExtra(Constants.WRITE_TRAN_COMMENT_KEY);
				replyIdForDraft = comment.getReplyId();
				attr = comment.getCattr();
				String name = "";
				if (comment.isOpenMb()) {
					name = comment.getChar_name();
					if (TextUtils.isEmpty(name) || name.length() <= 0) {
						name = comment.getMb_nick_name();
						if (TextUtils.isEmpty(name) || name.length() <= 0) {
							name = comment.getNick();
						}
					}
				} else {
					name = comment.getNick();
				}

				replyContent = " || @" + name + ":" + comment.getReplyContent();

				if (iAmWhich() == Constants.WRITE_TRANS_COMMENT && replyContent.length() > 30 + long_short) {
					replyContent = replyContent.substring(0, 30 + long_short - 3) + "...";
				}
			}
		}
		initView();
		initListener();

		pts = new Properties();
		pts.setProperty(EventId.KEY_TYPE, "" + iAmWhich());
		pts.setProperty(EventId.KEY_CHANNELID, channelId);
		pts.setProperty(EventId.KEY_NEWSID, mItem != null ? mItem.getId() : "");
		pts.setProperty(EventId.KEY_REPLYID, replyIdForDraft != null ? replyIdForDraft : "");
		pts.setProperty(EventId.KEY_COMMENTID, mItem != null ? mItem.getCommentid() : "");
		pts.setProperty(EventId.KEY_IMAGEURL, imgUrl != null ? imgUrl : "");
		pts.setProperty(EventId.KEY_VID, vid != null ? vid : "");
	}

	private int iAmWhich() {

		if (comment != null) {
			return Constants.WRITE_TRANS_COMMENT;
		}

		return Constants.WRITE_COMMENT;
	}

	private void sendWords() {

		HttpDataRequest request = null;

		if (iAmWhich() == Constants.WRITE_COMMENT) {

			Log.d("Publish", "WRITE_COMMENT shareType before-->" + shareType);

			if (isForbid) {
				shareType = shareType.replaceFirst("qqcomment,", "");
			}

			Log.i("CJZ", "shareType after-->" + shareType);

			if (lastInput.length() <= 0) {
				commentQQweiboStr = "转" + contentQqweibo;
			} else {
				commentQQweiboStr = lastInput + contentQqweibo;
				saveDraft(itemIdForDraft, replyIdForDraft, lastInput);
			}

			if (!if_share_to_tx_weibo && lastInput.length() > MAX_WORDS_COMMENT_NUM) {
				lastInput.substring(0, MAX_WORDS_COMMENT_NUM);
			}

			request = TencentNews.getInstance().publishQQNewsMulti(shareType, channelId, mItem.getId(), mItem.getUrl(), mItem.getTitle(), mItem.getBstract(), mItem.getCommentid(), lastInput,
					commentQQweiboStr, imgUrl, vid, graphicLiveID, graphicLiveChlid, specialID, attr);

		} else {
			
			Log.d("Publish", "WRITE_TRANS_COMMENT shareType before-->" + shareType);
			if (lastInput.length() <= 0) {
				tranQQweiboStr = "转" + replyContent + " " + contentQqweibo;
			} else {
				tranQQweiboStr = lastInput + replyContent + " " + contentQqweibo;
				saveDraft(itemIdForDraft, replyIdForDraft, lastInput);
			}

			if (!if_share_to_tx_weibo && lastInput.length() > MAX_WORDS_COMMENT_NUM) {
				lastInput.substring(0, MAX_WORDS_COMMENT_NUM);
			}

			request = TencentNews.getInstance().transComment(shareType, channelId, mItem.getId(), mItem.getUrl(), mItem.getTitle(), mItem.getBstract(), mItem.getCommentid(), comment.getReplyId(),
					lastInput, tranQQweiboStr, imgUrl, vid, graphicLiveID, graphicLiveChlid, specialID, attr);

		}
		TaskManager.startHttpDataRequset(request, PublishActivity.this);
		btn_send.setEnabled(false);
	}

	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		if (savedInstanceState != null && input != null) {
			input.setText(savedInstanceState.getString(Constants.SAVE_INPUT));
		}
		super.onRestoreInstanceState(savedInstanceState);
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		if (outState != null && input != null && input.getText() != null && input.getText().toString() != null && input.getText().toString().length() > 0) {
			outState.putString(Constants.SAVE_INPUT, input.getText().toString());
		}
		super.onSaveInstanceState(outState);
	}

	private void initView() {

		keyboardevent = (InputMethodEventView) findViewById(R.id.keyboardevent);
		writing_comment = (RelativeLayout) findViewById(R.id.writing_comment);
		btn_send = (Button) findViewById(R.id.btn_send);
		input = (EditText) findViewById(R.id.input);
		shareToTXWeibo = (ImageView) findViewById(R.id.share_to_tencent);
		shareToTXWeiboText = (TextView) findViewById(R.id.share_to);
		remainNum = (TextView) findViewById(R.id.remainNum);
		finishit = findViewById(R.id.finishit);

		if (isForbid) {
			shareToTXWeibo.setVisibility(View.GONE);
		}

		// transcomment and comment, accordding by id and replyid to
		// load draft
		// transcomment:mItem.getId() + comment.getReplyId()-->load
		// comment:mItem.getId()-->load
		String draft = loadDraft(itemIdForDraft, replyIdForDraft);
		// to set EditText value
		input.setText(draft);
		input.setSelection(draft.length(), draft.length());
		themeSettingsHelper.setTextViewColor(this, input, R.color.publish_comment_text_color);
		themeSettingsHelper.setImageViewSrc(this, shareToTXWeibo, R.drawable.comment_write_check);
		if ((ThemeSettingsHelper.getThemeSettingsHelper(this).isNightTheme()) || mItem != null && ("1".equalsIgnoreCase(mItem.getArticletype()) || "4".equalsIgnoreCase(mItem.getArticletype()))) {

			btn_send.setBackgroundResource(R.drawable.btn_send_black_selector);

			writing_comment.setBackgroundResource(R.drawable.comment_floor_black_un);
			writing_comment.setPadding(MobileUtil.dpToPx(8), MobileUtil.dpToPx(8), MobileUtil.dpToPx(8), MobileUtil.dpToPx(8));

			ColorStateList night_csl = (ColorStateList) getResources().getColorStateList(R.drawable.btn_send_black_color_selector);
			if (night_csl != null) {
				btn_send.setTextColor(night_csl);
			}

			if (themeSettingsHelper.isNightTheme()) {
				input.setBackgroundResource(R.drawable.night_comment_box);
			} else {
				input.setBackgroundResource(R.drawable.comment_box_black);
			}

			input.setPadding(MobileUtil.dpToPx(5), 0, MobileUtil.dpToPx(5), 0);
		}

		setShareTypeAndLimitWords();
	}

	private void initListener() {
		btn_send.setOnClickListener(this);
		shareToTXWeibo.setOnClickListener(this);
		shareToTXWeiboText.setOnClickListener(this);
		finishit.setOnClickListener(this);
		input.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {

			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void afterTextChanged(Editable s) {
				changeTextSwitcherNum();
			}
		});
		keyboardevent.setmInputMethodChangeLinstener(new InputMethodChangeLinstener() {

			@Override
			public void onInputMethodOpen() {
			}

			@Override
			public void onInputMethodClose() {

				if (input.getText().toString().length() > 0) {
					saveDraft(itemIdForDraft, replyIdForDraft, input.getText().toString());
				} else {
					deleteDraft(itemIdForDraft, replyIdForDraft);
				}

				if (!PublishActivity.this.isFinishing()) {
					finish();
				}
			}
		});
	}

	@Override
	public void finish() {
		// Application.getInstance().hideSoftInputFromWindow(input.getWindowToken());
		super.finish();
		overridePendingTransition(0, R.anim.fade_out);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {

		case R.id.finishit:

			if (input.getText().toString().length() > 0) {
				saveDraft(itemIdForDraft, replyIdForDraft, input.getText().toString());
			} else {
				deleteDraft(itemIdForDraft, replyIdForDraft);
			}

			finish();
			break;

		case R.id.btn_send:

			lastInput = input.getText().toString();

			if (iAmWhich() == Constants.WRITE_COMMENT && !if_share_to_tx_weibo && lastInput.length() <= 0) {
				TipsToast.getInstance().showTipsWarning("请输入内容");
				return;
			}

			if (iAmWhich() == Constants.WRITE_SUGGEST && lastInput.length() <= 0) {
				TipsToast.getInstance().showTipsWarning("请输入内容");
				return;
			}

			if (if_share_to_tx_weibo && remainWordsNum < 0) {
				TipsToast.getInstance().showTipsWarning("输入字数太多啦");
				return;
			}

			if (UserDBHelper.getInstance().getUserInfo() != null) {
				if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_INAVAILABLE) {
					// SToast.ToastShort("无网络连接，请启用数据网络");
					TipsToast.getInstance().showTipsWarning("无网络连接\n请启用数据网络");
				} else {

					// if(UserDBHelper.getInstance().getUserInfo().isOpenMBlog()){
					// statistics_send_start = System.currentTimeMillis();
					WebDev.trackCustomBeginKVEvent(this, EventId.ITIL_SEND_WORDS_TIME, pts);
					sendWords();
					finish();
					// } else {
					// TipsToast.getInstance().showTipsError("对不起\n您没有开通腾讯微博");
					// }
				}
			} else {
				Intent loginIntent = new Intent();
				loginIntent.setClass(PublishActivity.this, LoginActivity.class);
				loginIntent.putExtra(Constants.LOGIN_FROM, Constants.LOGIN_FROM_SEND_BTN);
				startActivityForResult(loginIntent, Constants.REQUEST_CODE_LOGIN);
			}

			break;
		case R.id.share_to:
		case R.id.share_to_tencent:
			if (!isForbid) {
				if_share_to_tx_weibo = !if_share_to_tx_weibo;
				resetShareCheck();
				setShareTypeAndLimitWords();
				if (if_share_to_tx_weibo && UserDBHelper.getInstance().getUserInfo() == null) {
					Intent loginIntent = new Intent();
					loginIntent.setClass(this, LoginActivity.class);
					loginIntent.putExtra(Constants.LOGIN_FROM, Constants.LOGIN_FROM_SHARE_BTN);
					startActivityForResult(loginIntent, Constants.REQUEST_CODE_LOGIN);
				}
			} else {
				if_share_to_tx_weibo = true;
			}
			break;
		}
	}

	private void resetShareCheck() {
		if (if_share_to_tx_weibo) {
			themeSettingsHelper.setImageViewSrc(this, shareToTXWeibo, R.drawable.comment_write_check);
			remainNum.setVisibility(View.VISIBLE);
			reCountRemainWordNum();
		} else {
			themeSettingsHelper.setImageViewSrc(this, shareToTXWeibo, R.drawable.comment_write_checkbox);
			remainNum.setVisibility(View.INVISIBLE);
		}

		setSendState();

	}

	private void reCountRemainWordNum() {

		remainWordsNum = MAX_WORDS_WEIBO_NUM - (contentQqweibo.length() - long_short) - input.getText().toString().length() - replyContent.length();
		remainNum.setText("" + remainWordsNum);
		if (remainWordsNum < 0) {
			remainNum.setTextColor(Color.parseColor("#f66710"));
		} else {
			remainNum.setTextColor(Color.parseColor("#414141"));
		}
	}

	private void setSendState() {
		if (UserDBHelper.getInstance().getUserInfo() != null) {
			if (!UserDBHelper.getInstance().getUserInfo().isOpenMBlog()) {
				if (input.getText().toString().length() <= 0) {
					btn_send.setEnabled(false);
				} else {
					btn_send.setEnabled(true);
				}
			} else {
				if (if_share_to_tx_weibo) {
					if (remainWordsNum >= 0) {
						btn_send.setEnabled(true);
					} else {
						btn_send.setEnabled(false);
					}
				} else {
					if (input.getText().toString().length() <= 0) {
						btn_send.setEnabled(false);
					} else {
						btn_send.setEnabled(true);
					}
				}
			}
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (resultCode == RESULT_OK) {
			if (requestCode == Constants.REQUEST_CODE_LOGIN) {

				UserInfo userInfo = (UserInfo) data.getSerializableExtra(Constants.LOGIN_SUCCESS_BACK_USER_KEY);
				settingData = settingObv.getData();
				settingData.setUserInfo(userInfo);
				settingObv.setData(settingData);

				// Statistics.getInstance().saveStatistics(Statistics.REPORTED_DATA_SETTING,
				// StatisticsUtil.generateCustomField(new String[] {
				// Statistics.REPORTED_DATA_KEY_LOGIN_FROM_WHERE, "1", "", "",
				// "", "", "" }));

				WebDev.trackCustomEvent(this, EventId.BOSS_SETTING_LOGINFROM_WRITE_COMMENT);

				if (data.hasExtra(Constants.LOGIN_BACK) && Constants.LOGIN_FROM_SHARE_BTN == data.getIntExtra(Constants.LOGIN_BACK, Constants.LOGIN_FROM_SEND_BTN)) {
					if (userInfo.isOpenMBlog()) {

						setShareTypeAndLimitWords();

					} else {
						// share_to_tencent.setShareButtonState(ShareButton.LOGOUT);
						if (input != null && input.getText().length() <= 0) {
							TipsToast.getInstance().showTipsWarning("对不起\n您没有开通腾讯微博\n请输入评论内容");
							btn_send.setEnabled(false);
							return;
						}
					}
				} else {

					if (userInfo.isOpenMBlog()) {

						// statistics_send_start = System.currentTimeMillis();
						WebDev.trackCustomBeginKVEvent(this, EventId.ITIL_SEND_WORDS_TIME, pts);
						sendWords();
						finish();

					} else {
						// share_to_tencent.setShareButtonState(ShareButton.LOGOUT);
						// share_to.setTextColor(Color.parseColor("#BEBEBE"));
						// lastnum.setVisibility(View.INVISIBLE);
						// remainNum.setVisibility(View.INVISIBLE);
						// remainNumUnit.setVisibility(View.INVISIBLE);
						if (input != null && input.getText().length() <= 0) {
							TipsToast.getInstance().showTipsWarning("请输入评论内容");
							btn_send.setEnabled(false);
							return;
						} else {

							// statistics_send_start =
							// System.currentTimeMillis();
							WebDev.trackCustomBeginKVEvent(this, EventId.ITIL_SEND_WORDS_TIME, pts);
							sendWords();
							finish();

						}
					}
				}

			}
		} else if (resultCode == RESULT_CANCELED) {

		}

	}

	@Override
	public void onHttpRecvOK(HttpTag tag, Object result) {
		btn_send.setEnabled(true);

		// statistics_send_end = System.currentTimeMillis();
		// statistics_send_total = statistics_send_end - statistics_send_start;

		if (tag.equals(HttpTag.SUGGEST_QQNEWS)) {
			TipsToast.getInstance().showTipsSuccess("感谢您的反馈!");
			deleteDraft(null, null);
			finish();
		} else {

			WriteBackState wbs = (WriteBackState) result;
			if (wbs.getPublish().equals("0")) {

				int tipNum = 0;
				StringBuffer tip = new StringBuffer();

				int comment = 1;
				int tencent = 1;
				int sina = 1;
				int qzong = 1;

				if (wbs.getComment() != null) {
					if (wbs.getComment().getRet().equals("0")) {// 成功
						comment = 1;
					} else if (wbs.getComment().getRet().equals("1")) {// 失败
						comment = 2;
					} else if (wbs.getComment().getRet().equals("2")) {// 重新登录
						comment = 4;
					} else {// 其他,认为失败了
						comment = 2;
					}
				} else {
					comment = 3;
				}

				if (wbs.getQqweibo() != null) {

					if (wbs.getQqweibo().getRet().equals("0")) {// 成功
						tencent = 1;
					} else if (wbs.getQqweibo().getRet().equals("1")) {// 失败
						tencent = 2;
					} else if (wbs.getQqweibo().getRet().equals("2")) {// 重新登录
						tencent = 4;
					} else {
						tencent = 2;
					}
				} else {
					tencent = 3;
				}

				if (wbs.getSina() != null) {
					if (wbs.getSina().getRet().equals("0")) {
						sina = 1;
					} else {
						sina = 2;
					}
				} else {
					sina = 3;
				}

				if (wbs.getQzone() != null) {
					if (wbs.getQzone().getRet().equals("0")) {
						qzong = 1;
					} else {
						qzong = 2;
					}
				} else {
					qzong = 3;
				}

				// 暂时没有
				// TEST[start]
				sina = 3;
				qzong = 3;
				// TEST[end]

				tip.append(comment);
				tip.append(tencent);
				tip.append(sina);
				tip.append(qzong);

				if (tip.toString().indexOf("4") >= 0) {
					// TipsToast.getInstance().showTipsError("发表失败\n请重新登录账号");
					UserDBHelper.getInstance().logoutUserInfo();
					settingData = settingObv.getData();
					settingData.setUserInfo(null);
					settingObv.setData(settingData);
					RssChannelSyncHelper.getInstance().onLogout();
					reLogin();
					return;
				}

				tipNum = Integer.parseInt(tip.toString());

				Log.i("CJZ", "结果码:" + tip.toString() + "--->" + tipNum);

				switch (tipNum) {
				case 1133:
					sendSuccess(tag);
					break;
				case 1233:
					// SToast.ToastLong("发表评论成功,同步到腾讯微博失败,请重试");
					// TipsToast.getInstance().showTipsSuccess("发表成功");
					sendSuccess(tag);
					break;
				case 1333:
					sendSuccess(tag);
					break;
				case 2133:
					// SToast.ToastLong("发表评论失败,同步到腾讯微博成功,请重试");
					// TipsToast.getInstance().showTipsSuccess("发表成功");
					sendSuccess(tag);
					break;
				case 2233:
					// SToast.ToastLong("发表失败,请重试");
					// if
					// (UserDBHelper.getInstance().getUserInfo().isOpenMBlog())
					// {
					// TipsToast.getInstance().showTipsError("发表失败");
					// } else {
					// TipsToast.getInstance().showTipsError("发表失败\n您没有开通腾讯微博");
					// }
					TipsToast.getInstance().showTipsError("发表失败\n请稍候再试");
					break;
				case 2333:
					// SToast.ToastLong("发表评论失败,请重试");
					TipsToast.getInstance().showTipsError("发表失败\n请稍候再试");
					break;
				case 3133:
					// SToast.ToastLong("同步到腾讯微博成功!");
					// SToast.ToastLong("发表成功");
					// TipsToast.getInstance().showTipsSuccess("发表成功");
					sendSuccess(tag);
					// quitActivity();
					break;
				case 3233:
					// SToast.ToastLong("同步到腾讯微博失败,请重试");
					if (UserDBHelper.getInstance().getUserInfo().isOpenMBlog()) {
						TipsToast.getInstance().showTipsError("发表失败\n请稍候再试");
					} else {
						TipsToast.getInstance().showTipsError("发表失败\n您没有开通腾讯微博");
					}
					// sendSuccess(tag);
					break;
				case 3333:
					// 已被getPublish()拦截
					break;
				default:
					TipsToast.getInstance().showTipsError("发表失败\n请稍候再试");
					break;
				}
			} else {
				// SToast.ToastShort("发表失败,请重试");
				TipsToast.getInstance().showTipsError("发表失败\n请稍候再试");
			}
		}

	}

	private void sendSuccess(HttpTag tag) {

		TipsToast.getInstance().showTipsSuccess("发表成功");

		// if (statistics_send_total > 0) {
		// Statistics.getInstance().saveStatistics(Statistics.REPORTED_DATA_WRITE,
		// StatisticsUtil.generateCustomField(new String[] { "" + iAmWhich(),//
		// 0意见反馈1评论,2转一下
		// channelId,// 频道名称
		// mItem != null ? mItem.getId() : "",// 文章id
		// mItem != null ? mItem.getCommentid() : "",// 评论id
		// "" + statistics_send_total,// 耗时
		// imgUrl,// 图片url分享到腾讯微博时图片的地址
		// vid,// 视频id分享到腾讯微博时视频id
		// comment != null ? comment.getReplyId() : "", "", "", "", "" }));
		// statistics_send_total = 0;
		// }

		WebDev.trackCustomEndKVEvent(this, EventId.ITIL_SEND_WORDS_TIME, pts);
		Properties newpts = new Properties(pts);
		newpts.setProperty(EventId.KEY_RESCODE, EventId.VALUE_RESCODE_SUCCESS);
		WebDev.trackCustomEvent(this, EventId.ITIL_SEND_WORDS_TIME_RESULT, newpts);

		if (tag.equals(HttpTag.PUBLISH_QQNEWS_MULTI)) {
			// SToast.ToastShort("发表成功");

			deleteDraft(itemIdForDraft, replyIdForDraft);

			if (lastInput.length() > 0 && !mItem.getCommentid().equals(Constants.FORBID_COMMENT_ID)) {
				backComment();
			}
		} else if (tag.equals(HttpTag.PUBLISH_TRANS_COMMENT_MULTI)) {
			// SToast.ToastShort("发表成功");
			if (lastInput.length() > 0) {

				deleteDraft(itemIdForDraft, replyIdForDraft);

				backTransComment();
			}
		}
		finish();
	}

	@Override
	public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {

		WebDev.trackCustomEndKVEvent(this, EventId.ITIL_SEND_WORDS_TIME, pts);
		Properties newpts = new Properties(pts);
		newpts.setProperty(EventId.KEY_RESCODE, EventId.VALUE_RESCODE_ERROR);
		WebDev.trackCustomEvent(this, EventId.ITIL_SEND_WORDS_TIME_RESULT, newpts);

		btn_send.setEnabled(true);
		TipsToast.getInstance().showTipsError(msg);
	}

	@Override
	public void onHttpRecvCancelled(HttpTag tag) {
		btn_send.setEnabled(true);
	}

	@Override
	protected void onDestroy() {
		if (settingObv != null) {
			settingObv.removeObserver(this);
		}
		super.onDestroy();
	}

	@Override
	public void updateSetting(SettingInfo setting) {
		SpSetting.saveSetting(setting);
	}

	/**
	 * 添加自己的评论虚拟数据
	 */
	private void backComment() {
		Intent intent = new Intent();
		intent.setAction(Constants.WRITE_SUCCESS_ACTION);
		Comment c = new Comment();
		c.setReplyId(Constants.TAG_COMMENT_CANTBEUP);
		c.setHadUp(false);

		c.setSex(UserDBHelper.getInstance().getUserInfo().getSex());
		c.setHeadUrl(UserDBHelper.getInstance().getUserInfo().getHeadurl());
		c.setProvinceCity("腾讯网友");

		if (UserDBHelper.getInstance().getUserInfo() != null) {

			if (UserDBHelper.getInstance().getUserInfo().isOpenMBlog()) {
				c.setIsOpenMb("1");
				c.setChar_name(UserDBHelper.getInstance().getUserInfo().getName());
				c.setMb_head_url(UserDBHelper.getInstance().getUserInfo().getHeadurl());
				c.setMb_nick_name(UserDBHelper.getInstance().getUserInfo().getNick());
			}

			if (!TextUtils.isEmpty(UserDBHelper.getInstance().getUserInfo().getNick())) {
				c.setNick(UserDBHelper.getInstance().getUserInfo().getNick());
			} else {
				if (!TextUtils.isEmpty(UserDBHelper.getInstance().getUserInfo().getQqnick())) {
					c.setNick(UserDBHelper.getInstance().getUserInfo().getQqnick());
				} else {
					c.setNick("腾讯新闻用户");
				}
			}
		} else {
			c.setNick("腾讯新闻用户");
		}

		c.setPubTime("" + System.currentTimeMillis());
		c.setAgreeCount("0");

		String replyContent = lastInput.replaceAll("\n", " ");
		replyContent.replaceAll("  ", "");
		c.setReplyContent(replyContent);

		Comment[] cc = new Comment[1];
		cc[0] = c;
		intent.putExtra(Constants.WRITE_SUCCESS_SERVER_BACK_COMMENT, cc);
		intent.putExtra(Constants.WRITE_SUCCESS_SERVER_BACK_COMMENT_ITEM_ID, mItem.getId());
		sendBroadcast(intent);
	}

	private void backTransComment() {
		Comment[] cc = new Comment[2];
		Intent intent = new Intent();
		intent.setAction(Constants.WRITE_SUCCESS_ACTION);
		Comment c = new Comment();
		c.setReplyId(Constants.TAG_COMMENT_CANTBEUP);
		c.setHadUp(false);
		c.setSex(UserDBHelper.getInstance().getUserInfo().getSex());
		c.setHeadUrl(UserDBHelper.getInstance().getUserInfo().getHeadurl());
		c.setProvinceCity("腾讯网友");

		if (UserDBHelper.getInstance().getUserInfo() != null) {

			if (UserDBHelper.getInstance().getUserInfo().isOpenMBlog()) {
				c.setIsOpenMb("1");
				c.setChar_name(UserDBHelper.getInstance().getUserInfo().getName());
				c.setMb_head_url(UserDBHelper.getInstance().getUserInfo().getHeadurl());
				c.setMb_nick_name(UserDBHelper.getInstance().getUserInfo().getNick());
			}

			if (!TextUtils.isEmpty(UserDBHelper.getInstance().getUserInfo().getNick())) {
				c.setNick(UserDBHelper.getInstance().getUserInfo().getNick());
			} else {
				if (!TextUtils.isEmpty(UserDBHelper.getInstance().getUserInfo().getQqnick())) {
					c.setNick(UserDBHelper.getInstance().getUserInfo().getQqnick());
				} else {
					c.setNick("腾讯新闻用户");
				}
			}
		} else {
			c.setNick("腾讯新闻用户");
		}

		c.setPubTime("" + System.currentTimeMillis());
		c.setAgreeCount("0");

		String replyContent = lastInput.replaceAll("\n", " ");
		replyContent.replaceAll("  ", "");
		c.setReplyContent(replyContent);

		c.setReplyContent(replyContent);

		cc[0] = comment;
		cc[1] = c;// 盖楼我的评论在最后

		intent.putExtra(Constants.WRITE_SUCCESS_SERVER_BACK_COMMENT, cc);
		intent.putExtra(Constants.WRITE_SUCCESS_SERVER_BACK_COMMENT_ITEM_ID, mItem.getId());
		sendBroadcast(intent);
	}

	/**
	 * 初始化分享和写的字数限制
	 */
	private void setShareTypeAndLimitWords() {

		shareType = QQCOMMENT;

		if (if_share_to_tx_weibo) {
			shareTencent = QQWEIBO;
		} else {
			shareTencent = "";
		}

		if (lastInput.length() > 0) {
			shareType = shareType + shareTencent;
		} else {

			if (iAmWhich() != Constants.WRITE_SUGGEST && !SpForbidenCommentNews.getForbidenCommentNews(mItem.getId())) {
				shareType = shareType + shareTencent;
			} else {
				shareType = "qqweibo";
			}
		}

		changeTextSwitcherNum();

	}

	private void changeTextSwitcherNum() {
		if (iAmWhich() == Constants.WRITE_SUGGEST) {
			remainWordsNum = (MAX_WORDS_SUGGEST_NUM - input.getText().toString().length());
		} else {
			remainWordsNum = MAX_WORDS_WEIBO_NUM - (contentQqweibo.length() - long_short) - input.getText().toString().length()
					- (iAmWhich() == Constants.WRITE_TRANS_COMMENT ? replyContent.length() : 0);
		}

		remainNum.setText("" + remainWordsNum);

		if (remainWordsNum < 0) {
			remainNum.setTextColor(Color.parseColor("#f66710"));
		} else {
			remainNum.setTextColor(Color.parseColor("#414141"));
		}

		if (!if_share_to_tx_weibo) {
			remainNum.setVisibility(View.INVISIBLE);
		} else {
			remainNum.setVisibility(View.VISIBLE);
		}

		setSendState();
	}

	public void saveDraft(final String itemId, final String replyId, final String input) {
		if (input != null && input.length() > 0) {
			TaskManager.startRunnableRequest(new Runnable() {

				@Override
				public void run() {
					if (iAmWhich() == Constants.WRITE_COMMENT) {
						SpDraft.saveDraft(itemId, input, Constants.SP_DRAFT);
					} else if (iAmWhich() == Constants.WRITE_TRANS_COMMENT) {
						SpDraft.saveDraft(itemId + replyId, input, Constants.SP_DRAFT);
					} else {
						SpDraft.saveDraft(Constants.SUGGEST_ID, input, Constants.SP_DRAFT);
					}
				}
			});
		}
	}

	public void deleteDraft(String itemId, String replyId) {
		if (iAmWhich() == Constants.WRITE_COMMENT) {
			SpDraft.delDraft(itemId, Constants.SP_DRAFT);
		} else if (iAmWhich() == Constants.WRITE_TRANS_COMMENT) {
			SpDraft.delDraft(itemId + replyId, Constants.SP_DRAFT);
		} else {
			SpDraft.delDraft(Constants.SUGGEST_ID, Constants.SP_DRAFT);
		}
	}

	public String loadDraft(String itemId, String replyId) {
		if (iAmWhich() == Constants.WRITE_COMMENT) {
			return SpDraft.getDraft(itemId, Constants.SP_DRAFT);
		} else if (iAmWhich() == Constants.WRITE_TRANS_COMMENT) {
			return SpDraft.getDraft(itemId + replyId, Constants.SP_DRAFT);
		} else {
			return SpDraft.getDraft(Constants.SUGGEST_ID, Constants.SP_DRAFT);
		}
	}

	/**
	 * 登录态失效
	 */
	private void reLogin() {
		Intent i = new Intent();
		i.putExtra(Constants.WRITE_WHICH_KEY, iAmWhich());
		i.putExtra(Constants.WRITE_COMMENT_CHANNEL_KEY, channelId);
		i.putExtra(Constants.WRITE_COMMENT_KEY, mItem);
		i.putExtra(Constants.WRITE_COMMENT_VID_KEY, this.vid);
		i.putExtra(Constants.WRITE_COMMENT_GRAPHICLIVECHLID_KEY, this.graphicLiveChlid);
		i.putExtra(Constants.WRITE_COMMENT_IMG_KEY, this.imgUrl);
		i.putExtra(Constants.WRITE_COMMENT_SHARE_TYPE_KEY, this.shareType);
		if (iAmWhich() == Constants.WRITE_TRANS_COMMENT) {
			i.putExtra(Constants.WRITE_TRAN_QQ_WEIBO_KEY, this.tranQQweiboStr);
			i.putExtra(Constants.WRITE_TRAN_COMMENT_KEY, this.comment);
		} else if (iAmWhich() == Constants.WRITE_COMMENT) {
			i.putExtra(Constants.WRITE_COMMENT_QQ_WEIBO_KEY, this.commentQQweiboStr);
		}
		i.setClass(this, ReLoginActivity.class);
		startActivity(i);
	}

	@Override
	protected void onPause() {
		overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
		super.onPause();
		WebDev.onPause(this);
	}

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

}
