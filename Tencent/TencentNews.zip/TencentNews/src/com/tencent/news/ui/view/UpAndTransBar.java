package com.tencent.news.ui.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.tencent.news.R;
import com.tencent.news.utils.ThemeSettingsHelper;

public class UpAndTransBar extends LinearLayout {

	private Context mContext;
	private boolean hadUp;
	private LinearLayout view_cjz_bar;
	private ImageView up_one, tran_one, copy_one, article_one, del_one, set_hot, set_normal, send_msg;	
	private CommentListView commentListView;
	private ThemeSettingsHelper themeSettingsHelper = null;	
//	String newsUrl, commentId, replyId;

	public UpAndTransBar(Context context) {
		//super(context);		
		//initView(context);
		this(context, null);
	}

	public UpAndTransBar(Context context, AttributeSet attrs) {
		super(context, attrs);
		//initView(context);	
		mContext = context;
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(mContext);
		loadLayoutView(0);
	}	
	
	/*style: 
	 * 0-显示顶一下、评一下、复制  
	 * 1-显示顶、评一下、复制、原文
	 * 2-显示顶、评一下、复制、原文、删除*/
	public void loadLayoutView(int style){
		LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		inflater.inflate(R.layout.view_upandtrans_bar, this, true);		
			
		view_cjz_bar = (LinearLayout) findViewById(R.id.up_tran_container);
		up_one = (ImageView) findViewById(R.id.up_one);
		tran_one = (ImageView) findViewById(R.id.tran_one);
		copy_one = (ImageView) findViewById(R.id.copy_one);		
		article_one = (ImageView) findViewById(R.id.original_article);
		del_one = (ImageView) findViewById(R.id.del_one);
		set_hot = (ImageView) findViewById(R.id.set_hot);
		set_normal = (ImageView) findViewById(R.id.set_normal);
		send_msg = (ImageView) findViewById(R.id.send_msg);
		
		initListener();		
			
		applyTheme();		
	}
	
	public void showMediaView(int style){//如果是媒体人需要展示置顶/取消置顶、私信的权限
		if(set_hot!=null && set_normal!=null && article_one!=null 
		&& copy_one!=null && send_msg!=null && del_one!=null ){
			if(style==0){
				set_hot.setVisibility(View.VISIBLE);
				set_normal.setVisibility(View.GONE);
			}else{
				set_hot.setVisibility(View.GONE);
				set_normal.setVisibility(View.VISIBLE);
			}
			article_one.setVisibility(View.GONE);
			copy_one.setVisibility(View.GONE);
			send_msg.setVisibility(View.VISIBLE);
			del_one.setVisibility(View.VISIBLE);
		}		
	}

	public void showDelIcon(){
		if(del_one!=null){
			del_one.setVisibility(View.VISIBLE);
		}
	}
	
	public void hideDelIcon(){
		if(del_one!=null){
			del_one.setVisibility(View.GONE);
		}
	}
	
	public void hideOriginalArticleIcon(){
		if(article_one!=null){
			article_one.setVisibility(View.GONE);
		}
	}
	
//	private void initView(Context context) {	
//		mContext = context;
//		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(mContext);
//		LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//		inflater.inflate(R.layout.view_cjz_bar, this, true);
//		view_cjz_bar = (LinearLayout) findViewById(R.id.up_tran_container);
//		up_one = (ImageView) findViewById(R.id.up_one);
//		tran_one = (ImageView) findViewById(R.id.tran_one);
//		copy_one = (ImageView) findViewById(R.id.copy_one);
//		applyTheme();
//		initListener();
//	}

	private void initListener() {
		up_one.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (!hadUp) {
//					commentListView.upComment();
					commentListView.setOperationType(1);
				}
			}
		});

		tran_one.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				//commentListView.popWritingCommentWindow();
				commentListView.setOperationType(2);
			}
		});
		
		copy_one.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				//commentListView.copyComment();
				commentListView.setOperationType(3);
			}
		});
		
		if(article_one!=null){
			article_one.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {				
					commentListView.setOperationType(4);
				}
			});
		}
		if(del_one!=null){
			del_one.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {				
					commentListView.setOperationType(5);
				}
			});
		}
		if(set_hot!=null){
			set_hot.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {				
					commentListView.setOperationType(6);
				}
			});
		}
		if(set_normal!=null){
			set_normal.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {				
					commentListView.setOperationType(7);
				}
			});
		}
		if(send_msg!=null){
			send_msg.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {				
					commentListView.setOperationType(8);
				}
			});
		}
	}
	
	public void setCommentListView(CommentListView view){
		commentListView = view;
	}
	public void setUpState(boolean hadUp) {
		this.hadUp = hadUp;
		if (hadUp) {
			up_one.setImageResource(R.drawable.up_one_ed);
		} else {
			up_one.setImageResource(R.drawable.btn_up_selector);
		}
	}
	
	public void applyTheme(){
		
		if(themeSettingsHelper.isNightTheme()){
			view_cjz_bar.setBackgroundResource(R.drawable.night_pop_bg);
		}else{
			view_cjz_bar.setBackgroundResource(R.drawable.pop_bg);
		}
	}

}
