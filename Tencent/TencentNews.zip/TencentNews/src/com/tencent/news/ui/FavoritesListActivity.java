
package com.tencent.news.ui;

import android.R.integer;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.boss.EventId;
import com.tencent.news.cache.FavorDbItem;
import com.tencent.news.cache.FavorItemCache;
import com.tencent.news.cache.FavorSQLiteHelper;
import com.tencent.news.cache.FavorSyncHelper;
import com.tencent.news.cache.UserDBHelper;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.model.pojo.CachePageResult;
import com.tencent.news.model.pojo.FavorItemsByLoadMore;
import com.tencent.news.model.pojo.FavorItemsByRefresh;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.model.pojo.UserInfo;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.system.observer.SettingObserver;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.adapter.FavoriteslListAdapter;
import com.tencent.news.ui.adapter.FavoriteslListAdapter.ViewHolder;
import com.tencent.news.ui.view.FavoritesPullRefreshListView;
import com.tencent.news.ui.view.FavoritesPullRefreshView;
import com.tencent.news.ui.view.FavoritesPullToRefreshFrameLayout;
import com.tencent.news.ui.view.PullRefreshListView.OnClickFootViewListener;
import com.tencent.news.ui.view.PullRefreshListView.OnRefreshListener;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.SLog;
import com.tencent.omg.webdev.WebDev;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

public class FavoritesListActivity extends BaseActivity implements SettingObserver {
    private final static String TAG = FavoritesListActivity.class.getSimpleName();
    private final static int ENTER_PAGE_GET_NEW_DATA_FROM_NET = 1024;
    private final static int ENTER_PAGE_GET_NEW_DATA_FROM_CACHE = 512;
    private final static int LOAD_NEXT_PAGE_DATA_FROM_CACHE = 128;
    private final static int LOAD_MORE_ID_FROM_NET = 64;
    private final static int LOAD_ALL_END = 32;
    private final static int LOAD_MORE_BUT_REFRESH_UNBACK = 16;
    private final static int REFRESH_BUT_OTHER_UNCOMPLETE = 8;
    private final static int NO_DATA = 4;
    private final static int FAVOR_INDEX_COUNT = 200;
    private static final int CACHE_PAGE_SIZE = 20;

    private RelativeLayout mFavoriteslayout;
    private FavoritesPullToRefreshFrameLayout mFramelayout;
    private FavoritesPullRefreshListView mListView;
    private FavoritesPullRefreshView mEmptyView;
    private FavoriteslListAdapter mAdapter;
    private PopupWindow popupDeleteWindow;
    private LinearLayout cancel_favor_Layout;
    private Button btn_favorites_delete;
    private RelativeLayout favorites_title_click;
    private RelativeLayout favorites_title_bar;
    private Button btn_favorites_title_back;
    private Button btn_favorites_title_edit;
    private TextView favorites_title_str;
    private View mMask;
    private FavoritesReceiver mReceiver;
    private NewsHandler mHandler;
    private List<FavorDbItem> favorList;
    private FavorItemCache mCache;
    public FavorSQLiteHelper favorDB;
    private UserInfo uf;
    private CachePageResult<Item> cachePageResult;
    private List<Boolean> isSelected;
    private boolean isSelectedFlag = false;
    private List<Item> mFirstPageData;
    private List<Item> nextPageData;
    private String mChannel = "favorites";
    private boolean mIsStyleMode;
    private boolean isHttping = false;
    private boolean isFirstPageLoadItemsFromNet = false;
    private boolean isLoadMoreIds = false;
    private boolean isLoadAllEnd = false;
    private boolean isPullRefreshEmptyView = false;
    private int checkedCount = 0;
    private int start = 0;
    private int end = 0;
    private FavorDbItem lastNewsDbItem;
    private FavorItemsByRefresh mIdAndItemsList;
    private FavorItemsByLoadMore mItemsList;
    private float downX, downY, upX, upY;
    private long test_pull_time_start = 0;
    private long test_pull_time_end = 0;
    private long test_merge_time_start = 0;
    private long test_merge_time_end = 0;
    private long test_getpage_time_start = 0;
    private long test_getpage_time_end = 0;
    private Handler mHandler2;
    private int animationCount = 0;
    private int viewCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getIntentData(getIntent());
        InitContainerView(savedInstanceState);
        InitAdapter();
        InitListener();
        initListViewTag();
        setTitleBarText();
        registerBroadcastReceiver();
        mHandler = new NewsHandler(this);
        mHandler2 = new Handler();
        SettingObservable.getInstance().registerObserver(this);
        mCache = FavorItemCache.getInstance();
        favorDB = mCache.getFavorSQLiteHelper();
        getNewDataFromCache();
        SLog.i(TAG, "onCreate() " + mChannel);
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (mAdapter != null) {
            mAdapter.notifyDataSetChanged();
        }

        SLog.i(TAG, "onStart() " + mChannel);
        TaskManager.cancelAllImageThread();
    }

    @Override
    protected void onPause() {
        super.onPause();
        TaskManager.cancelAllThread();
        SLog.i(TAG, "onPause() " + mChannel);
    }

    @Override
    protected void onStop() {
        SLog.i(TAG, "onStop() " + mChannel);
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        SLog.i(TAG, "onDestroy() " + mChannel);

        if (mAdapter != null) {
            mAdapter.clearAdapterListData();
        }

        if (mReceiver != null) {
            try {
                unregisterReceiver(mReceiver);
            } catch (Exception e) {
                SLog.e(e.toString());
            }
        }

        SettingObservable.getInstance().removeObserver(this);
    }

    private static class NewsHandler extends Handler {
        private WeakReference<FavoritesListActivity> mOuterClass;

        NewsHandler(FavoritesListActivity activity) {
            mOuterClass = new WeakReference<FavoritesListActivity>(activity);
        }

        @Override
        public void handleMessage(android.os.Message msg) {
            super.handleMessage(msg);
            FavoritesListActivity mTheClass = mOuterClass.get();
            // if (favorList != null) {
            // favorites_title_str.setText("" + favorList.size());
            // }
            mTheClass.btn_favorites_title_edit.setVisibility(View.VISIBLE);
            switch (msg.what) {
                case ENTER_PAGE_GET_NEW_DATA_FROM_NET:
                    mTheClass.getNewDataSilent();
                    break;
                case LOAD_MORE_ID_FROM_NET:
                    mTheClass.getMoreFavoritesIndexAndItems();
                    break;
                case ENTER_PAGE_GET_NEW_DATA_FROM_CACHE:
                    mTheClass.showFirstPageData();
                    break;
                case LOAD_NEXT_PAGE_DATA_FROM_CACHE:
                    mTheClass.showNextPageData();
                    break;
                case LOAD_MORE_BUT_REFRESH_UNBACK:
                    mTheClass.mListView.setFootViewAddMore(false, true, true);
                    break;
                case REFRESH_BUT_OTHER_UNCOMPLETE:
                    mTheClass.setRefreshComplete(true);
                    // mTheClass.mListView.onRefreshComplete(true);
                    break;
                case LOAD_ALL_END:
                    mTheClass.isLoadAllEnd = true;
                    if (mTheClass.mAdapter.getDataList() != null && mTheClass.mAdapter.getDataList().size() > 0) {
                        mTheClass.mListView.setFootViewAddMore(true, false, false);
                    } else {
                        mTheClass.showEmptyTips();
                    }
                    break;
                case NO_DATA:
                    mTheClass.showEmptyTips();
                    break;
                default:
                    break;
            }
        }
    }

    private void InitListener() {
        mListView.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh() {
                isPullRefreshEmptyView = false;
                if (isSelectedFlag || uf == null) {
                    setRefreshComplete(true);
                    // mListView.onRefreshComplete(false);
                    return;
                }
                TaskManager.startRunnableRequestInPool(new Runnable() {
                    @Override
                    public void run() {
                        getNewDataSilent();
                    }
                });
            }

        });

        mListView.setOnClickFootViewListener(new OnClickFootViewListener() {

            @Override
            public void onClickFootView() {
                TaskManager.startRunnableRequestInPool(new Runnable() {
                    @Override
                    public void run() {
                        getMoreData();
                    }
                });
            }

        });

        mListView.setOnItemClickListener(new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                SLog.d(TAG, "position:" + position);

                int nClickPosition = position - mListView.getHeaderViewsCount();
                if(mAdapter.getDataList() != null){
                    if (nClickPosition >= 0 && nClickPosition < mAdapter.getDataList().size()) {
                        if (isSelectedFlag) {
                            doItemChecked(view, nClickPosition);
                        } else {
                            startNextActivity(nClickPosition);
                        }
                    }
                }
            }
        });

        mEmptyView.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh() {

                isPullRefreshEmptyView = true;
                if (isSelectedFlag || uf == null) {
                    setRefreshComplete(true);
                    // mEmptyView.onRefreshComplete(false);
                    return;
                }
                TaskManager.startRunnableRequestInPool(new Runnable() {
                    @Override
                    public void run() {
                        getNewDataSilent();
                    }
                });
            }

        });

        mFramelayout.setRetryButtonClickedListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                OnRetryData();
            }

        });
        mEmptyView.setLoginButtonClickedListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                doLogin();
            }

        });
        mListView.setLoginButtonClickedListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                doLogin();
            }

        });
        favorites_title_click.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                setSelection();
            }

        });
        favorites_title_str.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                setSelection();
            }

        });
        btn_favorites_title_back.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                quitActivity();
            }

        });
        btn_favorites_title_edit.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                doEdit();
            }

        });

        btn_favorites_delete.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                SLog.d(TAG, "btn_favorites_delete");
                doDelete();
            }

        });

    }

    /**
     * Title:showFirstPageData
     * 
     * @Description:显示首屏数据
     * @return void
     * @throws
     */
    private void showFirstPageData() {
        test_pull_time_end = System.currentTimeMillis();
        SLog.d(TAG, "pull_time:" + (test_pull_time_end - test_pull_time_start));

        start = mFirstPageData.size();
        end = start + CACHE_PAGE_SIZE;
        mAdapter.addDataList(mFirstPageData);
        mAdapter.notifyDataSetChanged();
        setRefreshComplete(true);
        // mListView.onRefreshComplete(true);
        mFramelayout.showState(Constants.LIST);
        mListView.setFootViewAddMore(true, true, false);
    }

    /**
     * Title:showNextPageData
     * 
     * @Description:显示加载更多数据
     * @return void
     * @throws
     */
    private void showNextPageData() {
        start += nextPageData.size();
        end = start + CACHE_PAGE_SIZE;
        mAdapter.addMoreDataList(nextPageData);
        mAdapter.notifyDataSetChanged();
        mFramelayout.showState(Constants.LIST);
        mListView.setFootViewAddMore(true, true, false);
    }

    /**
     * Title:doLogin
     * 
     * @Description:登录跳转，并接受返回值
     * @return void
     * @throws
     */
    private void doLogin() {
        Intent intent = new Intent(this, LoginActivity.class);
        this.startActivityForResult(intent, Constants.REQUEST_CODE_LOGIN);
    }

    /**
     * Title:doItemChecked
     * 
     * @Description:编辑状态item点击处理
     * @param view
     * @param nClickPosition
     * @return void
     * @throws
     */
    private void doItemChecked(View view, int nClickPosition) {

        ViewHolder holder = (ViewHolder) view.getTag();
        if (isSelected.get(nClickPosition)) {
            checkedCount--;
            isSelected.set(nClickPosition, false);
        } else {
            checkedCount++;
            isSelected.set(nClickPosition, true);
        }
        mAdapter.setIfChecked(view, holder.fill_place, nClickPosition);
        if (checkedCount > 0) {
            btn_favorites_delete.setText(this.getResources().getString(R.string.string_delete_favorites__text) + "("
                    + checkedCount + ")");
            btn_favorites_delete.setBackgroundResource(R.drawable.btn_delete_favorites_selector);
        } else {
            btn_favorites_delete.setText(this.getResources().getString(R.string.string_delete_favorites__text));
            btn_favorites_delete.setBackgroundResource(R.drawable.btn_delete_favorites_none_selector);
        }
    }

    /**
     * Title:resetCheckState
     * 
     * @Description:取消编辑后，置初始状态
     * @return void
     * @throws
     */
    private void resetCheckState() {
        isSelectedFlag = false;
        btn_favorites_title_back.setVisibility(View.VISIBLE);
        btn_favorites_title_edit.setText(this.getResources().getString(R.string.string_edit_favorites__text));
        // themeSettingsHelper.setViewBackgroudColor(this,
        // this.mFavoriteslayout, R.color.timeline_home_bg_color);
        themeSettingsHelper.setViewBackgroudColor(this, this.mListView, R.color.timeline_home_bg_color);
        themeSettingsHelper.setListViewSelector(this, this.mListView, R.drawable.list_selector);
        mAdapter.setShowCheckBox(isSelectedFlag);

        mAdapter.notifyDataSetChanged();
//        // //////////////////////
//        for (int i = 0; i < mListView.getChildCount(); i++) {
//            View view = mListView.getChildAt(i);
//            if (view.getTag() != null) {
//                viewCount++;
//            }
//        }
//        boolean flag = true;
//        for (int i = 0; i < mListView.getChildCount(); i++) {
//            View convertView = mListView.getChildAt(i);
//            if (convertView.getTag() != null) {
//                ViewHolder holder = (ViewHolder) convertView.getTag();
//                if (flag) {
//                    SLog.d(TAG, " resetCheckState top:" + holder.fill_place.getTop());
//                    mAdapter.setMarginTop(holder.fill_place.getTop());
//                    flag = false;
//                }
//                startAnimOut(holder);
//            }
//        }
        // ///////////////////////
    }

    private void startAnimIn(ViewHolder holder) {
        final ImageView checkView = holder.checkIcon;
        final ImageView fill_place = holder.fill_place;

        final int sceenWidth = MobileUtil.getScreenWidthIntPx();
        final Animation checkIn = new TranslateAnimation(0, -MobileUtil.dpToPx(40), 0, 0);
        holder.fill_place.setVisibility(View.VISIBLE);
        checkIn.setDuration(300);

        checkIn.setAnimationListener(new AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onAnimationEnd(Animation animation) {

                // TODO Auto-generated method stub
                mHandler2.post(new Runnable() {

                    @Override
                    public void run() {
                        // TODO Auto-generated method stub
                        RelativeLayout.LayoutParams llp = (RelativeLayout.LayoutParams) checkView.getLayoutParams();
                        llp.setMargins(sceenWidth - MobileUtil.dpToPx(60), fill_place.getTop(), 0, 0);
                        checkView.setLayoutParams(llp);
                        checkView.requestLayout();
                    }

                });
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
                // TODO Auto-generated method stub

            }
        });

        SLog.d(TAG, " startAnimIn top:" + holder.fill_place.getTop());
        RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(sceenWidth - MobileUtil.dpToPx(20), fill_place.getTop(), 0, 0);
        holder.checkIcon.setLayoutParams(lp);
        holder.checkIcon.requestLayout();

        mHandler2.post(new Runnable() {

            @Override
            public void run() {
                // TODO Auto-generated method stub
                checkView.startAnimation(checkIn);
            }
        });
    }

    private void startAnimOut(ViewHolder holder) {
        final TextView title = holder.itemTitle;
        final ImageView fillImageView = holder.fill_place;
        final ImageView checkView = holder.checkIcon;
        final int sceenWidth = MobileUtil.getScreenWidthIntPx();
        final Animation checkIn = new TranslateAnimation(0, MobileUtil.dpToPx(40), 0, 0);

        checkIn.setDuration(300);

        checkIn.setAnimationListener(new AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onAnimationEnd(Animation animation) {

                // TODO Auto-generated method stub
                mHandler2.post(new Runnable() {

                    @Override
                    public void run() {
                        // TODO Auto-generated method stub
                        RelativeLayout.LayoutParams llp = (RelativeLayout.LayoutParams) checkView.getLayoutParams();
                        llp.setMargins(sceenWidth, fillImageView.getTop(), 0, 0);
                        checkView.setLayoutParams(llp);
                        checkView.requestLayout();
                        fillImageView.setVisibility(View.GONE);

                        animationCount++;
                        if (animationCount >= viewCount) {
                            mAdapter.initSelectState();
                            mAdapter.setShowType(0);
                            mAdapter.notifyDataSetChanged();
                        }
                    }

                });

            }

            @Override
            public void onAnimationRepeat(Animation animation) {
                // TODO Auto-generated method stub

            }
        });

        mHandler2.post(new Runnable() {

            @Override
            public void run() {
                // TODO Auto-generated method stub
                checkView.startAnimation(checkIn);
            }
        });
    }

    // private void prepare() {
    // DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
    // speed = (int) (5 * displayMetrics.density);
    // pxWidth = (int) (checkBoxWidth * displayMetrics.density);
    // }

    /**
     * Title:doEdit
     * 
     * @Description:点击编辑后，置列表状态及popwindow
     * @return void
     * @throws
     */
    private void doEdit() {
        if (isSelectedFlag) {
            mListView.setLoginBtnEnable(true);
            popUpFavorBar();
            resetCheckState();
        } else {
            isSelectedFlag = true;
            checkedCount = 0;
            mListView.setLoginBtnEnable(false);
            btn_favorites_title_back.setVisibility(View.GONE);
            btn_favorites_title_edit.setText(this.getResources().getString(R.string.string_cancel_favorites__text));
            btn_favorites_delete.setText(this.getResources().getString(R.string.string_delete_favorites__text));
            btn_favorites_delete.setBackgroundResource(R.drawable.btn_delete_favorites_none_selector);
            popUpFavorBar();

            mAdapter.initSelectState();
            isSelected = mAdapter.getIsSelected();
            mAdapter.setShowCheckBox(isSelectedFlag);

            // ////////////////////////
            mAdapter.notifyDataSetChanged();
//            mHandler2.post(new Runnable() {
//
//                @Override
//                public void run() {
//                    // TODO Auto-generated method stub
//                    mAdapter.setShowType(1);
//                    int flag = 0;
//                    for (int i = 0; i < mListView.getChildCount(); i++) {
//                        View convertView = mListView.getChildAt(i);
//                        if (convertView.getTag() != null) {
//                            ViewHolder holder = (ViewHolder) convertView.getTag();
//                            // convertView.setBackgroundColor(FavoritesListActivity.this.getResources().getColor(R.color.transparent));
//                            flag = i;
//                            startAnimIn(holder);
//                        }
//                    }
//                }
//            });

            // ////////////////////
        }
    }

    // public void doShowAnimation() {
    // if (moveWidth < pxWidth) {
    // if (moveWidth + speed > pxWidth) {
    // moveWidth = pxWidth;
    // } else {
    // moveWidth += speed;
    // }
    // mAdapter.setCheckBoxWidth(moveWidth);
    // mAdapter.notifyDataSetChanged();
    // mHandler.sendEmptyMessage(SHOW_CHECK_BOX_ANIM);
    // }
    // }

    /**
     * Title:doDelete
     * 
     * @Description:点击删除按钮，执行选中item删除逻辑
     * @return void
     * @throws
     */
    private void doDelete() {

        if (checkedCount > 0) {
            WebDev.trackCustomEvent(this, EventId.BOSS_FAVORITES_LIST_CLICK_DEL_BTN, "" + checkedCount);
        }

        popUpFavorBar();
        if (checkedCount == isSelected.size() && isLoadAllEnd) {
            showEmptyTips();
        }
        if (isSelected.size() > 0) {
            List<String> newsIdList = new ArrayList<String>();
            for (int i = isSelected.size() - 1; i >= 0; i--) {
                if (isSelected.get(i)) {
                    newsIdList.add(mAdapter.getDataList().get(i).getId());
                    // thread 批量？
                    mCache.clearCache(mAdapter.getDataList().get(i).getId());
                    mAdapter.getDataList().remove(i);
                    favorList.remove(i);
                }
            }

            if (uf != null) {
                favorDB.updates(newsIdList, FavorDbItem.OP_DEL, uf.getAccount());
                FavorSyncHelper.getInstance().sync();
            } else {
                favorDB.updates(newsIdList, FavorDbItem.OP_DEL, FavorSyncHelper.getInstance().getDefaultUser());
            }

            start -= checkedCount;
            end = start + CACHE_PAGE_SIZE;
        }
         resetCheckState();
//        isSelectedFlag = false;
//        btn_favorites_title_back.setVisibility(View.VISIBLE);
//        btn_favorites_title_edit.setText(this.getResources().getString(R.string.string_edit_favorites__text));
//        // themeSettingsHelper.setViewBackgroudColor(this,
//        // this.mFavoriteslayout, R.color.timeline_home_bg_color);
//        themeSettingsHelper.setViewBackgroudColor(this, this.mListView, R.color.timeline_home_bg_color);
//        themeSettingsHelper.setListViewSelector(this, this.mListView, R.drawable.list_selector);
//        mAdapter.setShowCheckBox(isSelectedFlag);
//        mAdapter.initSelectState();
//        mAdapter.setShowType(0);
//        mAdapter.notifyDataSetChanged();
    }

    /**
     * Title:showEmptyTips
     * 
     * @Description:无内容时展示页面
     * @return void
     * @throws
     */
    private void showEmptyTips() {
        btn_favorites_title_edit.setVisibility(View.GONE);
        mEmptyView.onRefreshComplete(true);
        if(uf == null){
            mEmptyView.setHasHeader(false);
        }
        mFramelayout.showState(Constants.EMPTY);
    }

    /**
     * Title:setRefreshComplete
     * 
     * @Description:设置下拉刷新是否成功
     * @param refreshSuccess
     * @return void
     * @throws
     */
    private void setRefreshComplete(boolean refreshSuccess) {
        if (isPullRefreshEmptyView) {
            mEmptyView.onRefreshComplete(refreshSuccess);
        } else {
            mListView.onRefreshComplete(refreshSuccess);
        }
    }

    /**
     * Title:setLoginTipsVisible
     * 
     * @Description:设置是否显示登录bar和启用下拉刷新
     * @param bFlag
     * @return void
     * @throws
     */
    private void setLoginTipsVisible(boolean bFlag) {
//        mListView.setHasHeader(!bFlag);
//        mEmptyView.setHasHeader(!bFlag);
        //not login 
        mFramelayout.setLogin(!bFlag);
    }

    /**
     * Title:initListViewTag
     * 
     * @Description:设置listview timetag
     * @return void
     * @throws
     */
    private void initListViewTag() {
        mListView.setPullTimeTag(getListviewTimeTag());
        mEmptyView.setPullTimeTag(getListviewTimeTag() + "EMPTY");
        mFramelayout.showState(Constants.LOADING);
    }

    /**
     * Title:startNextActivity
     * 
     * @Description:点击item，跳转底层页
     * @param position
     * @return void
     * @throws
     */
    private void startNextActivity(int position) {
        Intent intent = new Intent();
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        Log.i("Test", "--->" + "position--->" + position);

        if (mAdapter != null && position >= 0) {
            Item item = mAdapter.getObjectItem(position);
            SLog.i("FavoritesListActivity", getClassName(item).toString());
            if (item != null && getClassName(item) != null) {
                Bundle bundle = new Bundle();
                bundle.putSerializable(Constants.NEWS_DETAIL_KEY, item);
                bundle.putString(Constants.NEWS_CHANNEL_CHLID_KEY, mChannel);
                bundle.putString(Constants.NEWS_DETAIL_TITLE_KEY, getChlidTitle());
                bundle.putString(Constants.NEWS_CLICK_ITEM_POSITION, "" + (position + 1));
                intent.putExtras(bundle);
                intent.setClass(FavoritesListActivity.this, getClassName(item));
                startActivity(intent);
            }
        }
    }

    /**
     * Title:registerBroadcastReceiver
     * 
     * @Description:注册从收藏列表进入底层页进行收藏 取消收藏操作的广播
     * @return void
     * @throws
     */
    private void registerBroadcastReceiver() {

        mReceiver = new FavoritesReceiver();
        IntentFilter filter = new IntentFilter(Constants.FAVOR_LIST_REFRESH_ACTION);
        registerReceiver(mReceiver, filter);

    }

    /**
     * Title:OnRetryData
     * 
     * @Description:TODO
     * @return void
     * @throws
     */
    private void OnRetryData() {

        SLog.i("page", mChannel + " : OnRetryData()");

        mFramelayout.showState(Constants.LOADING);
        TaskManager.startRunnableRequestInPool(new Runnable() {
            @Override
            public void run() {
                getNewDataSilent();
            }
        });
    }

    /**
     * Title:getNewDataFromCache
     * 
     * @Description:进入页面时从缓存读取数据，若登录再异步拉取最新数据
     * @return void
     * @throws
     */
    private void getNewDataFromCache() {
        TaskManager.startRunnableRequestInPool(new Runnable() {
            @Override
            public void run() {
                // List<Item> list = mCache.getCache();

                favorList = mCache.getCache();
                if (favorList != null) {
                    lastNewsDbItem = favorList.get(favorList.size() - 1);
                    start = 0;
                    end = CACHE_PAGE_SIZE;
                    cachePageResult = mCache.getCacheDataByPage(start, end);
                    mFirstPageData = cachePageResult.getCachePageData();

                    if (mFirstPageData != null && mFirstPageData.size() > 0) {
                        SLog.i(TAG, mChannel + " : getNewDataFromCache() 加载缓存");
                        mHandler.sendEmptyMessage(ENTER_PAGE_GET_NEW_DATA_FROM_CACHE);
                    }

                    if (uf == null && cachePageResult.getNeedLoadIds() != null) {
                        isHttping = true;
                        isFirstPageLoadItemsFromNet = true;
                        HttpDataRequest request = TencentNews.getInstance().getFavorListItems(
                                cachePageResult.getNeedLoadIds());
                        TaskManager.startHttpDataRequset(request, FavoritesListActivity.this);
                    }

                } else if (uf == null) {
                    mHandler.sendEmptyMessage(NO_DATA);
                }
                // 登录用户
                if (uf != null) {
                    SLog.i(TAG, mChannel + " : getNewDataFromCache() 读完缓存之后, 发起网络请求");
                    mHandler.sendEmptyMessage(ENTER_PAGE_GET_NEW_DATA_FROM_NET);
                }
            }
        });
    }

    /**
     * Title:getFavoritesIndexAndItems
     * 
     * @Description:1、第一次拉取id和items 2、当下拉刷新拉取的id不足时，增量拉取id和items
     * @param num 拉取数量
     * @param id 上次拉取的最后一个id
     * @param timestamp 上次拉取最后一个id是时间戳
     * @param id_type 上次拉取的收藏类型
     * @return void
     * @throws
     */
    private void getFavoritesIndexAndItems(final int num, final String id, final long timestamp, final int id_type) {
        TaskManager.startRunnableRequestInPool(new Runnable() {
            @Override
            public void run() {
                HttpDataRequest request = TencentNews.getInstance().getFavorList(num, id, timestamp, id_type);
                isHttping = true;
                TaskManager.startHttpDataRequset(request, FavoritesListActivity.this);
            }
        });

    }

    /**
     * Title:getMoreFavoritesIndexAndItems
     * 
     * @Description:增量拉取id 和items
     * @return void
     * @throws
     */
    private void getMoreFavoritesIndexAndItems() {

        if (lastNewsDbItem != null) {
            isLoadMoreIds = true;
            getFavoritesIndexAndItems(FAVOR_INDEX_COUNT, lastNewsDbItem.news_id, lastNewsDbItem.timestamp,
                    lastNewsDbItem.source);
        }

    }

    /**
     * Title:getNewDataSilent
     * 
     * @Description:从网络拉取最新id和items
     * @return void
     * @throws
     */
    private synchronized void getNewDataSilent() {
        if (isHttping) {
            mHandler.sendEmptyMessage(REFRESH_BUT_OTHER_UNCOMPLETE);
            return;
        }
        getFavoritesIndexAndItems(FAVOR_INDEX_COUNT, "", 0, 0);
    }

    /**
     * Title:getMoreData
     * 
     * @Description:加载更多数据
     * @return void
     * @throws
     */
    private synchronized void getMoreData() {

        if (isHttping) {
            mHandler.sendEmptyMessage(LOAD_MORE_BUT_REFRESH_UNBACK);
            return;
        }

        isHttping = true;
        cachePageResult = mCache.getCacheDataByPage(start, end);
        nextPageData = cachePageResult.getCachePageData();

        if (cachePageResult.getNeedLoadIds() != null) {

            // if (uf != null) {
            HttpDataRequest request = TencentNews.getInstance().getFavorListItems(cachePageResult.getNeedLoadIds());
            TaskManager.startHttpDataRequset(request, this);
            // } else {
            // TipsToast.getInstance().showTipsError("数据被破坏");
            // }
        } else {
            if (nextPageData.size() > 0) {
                isHttping = false;
                // 全都从磁盘上取到了,恭喜你~刷界面去吧
                mHandler.sendEmptyMessage(LOAD_NEXT_PAGE_DATA_FROM_CACHE);
            } else {
                if (uf != null) {
                    mHandler.sendEmptyMessage(LOAD_MORE_ID_FROM_NET);
                } else {
                    mHandler.sendEmptyMessage(LOAD_ALL_END);
                    isHttping = false;
                }

            }
        }
    }

    /**
     * Title:setSelection
     * 
     * @Description:跳转到列表顶部
     * @return void
     * @throws
     */
    public void setSelection() {
        if (mListView != null) {
            mListView.setSelection(0);
        }

    }

    /**
     * Title:saveGetMoreCache
     * 
     * @Description:将加载更多的数据写入缓存并加载显示下一页
     * @param list
     * @return void
     * @throws
     */
    private synchronized void saveGetMoreCache(List<Item> list) {
        nextPageData = mCache.polishingData(start, end, list);
        isHttping = false;
        mHandler.sendEmptyMessage(LOAD_NEXT_PAGE_DATA_FROM_CACHE);
    }

    /**
     * Title:savePullRefreshCache
     * 
     * @Description:保存下来刷新id和items
     * @param fmDataList
     * @return void
     * @throws
     */
    private synchronized void savePullRefreshCache(FavorItemsByRefresh fmDataList) {
        SLog.i(TAG, mChannel + " : 下拉刷新写缓存===========");

        test_merge_time_start = System.currentTimeMillis();

        favorList = mCache.generateCacheData(fmDataList.getIndex(), fmDataList.getListitems(), false);

        test_merge_time_end = System.currentTimeMillis();
        SLog.d(TAG, "merge:" + (test_merge_time_end - test_merge_time_start));

        if (favorList != null) {
            lastNewsDbItem = favorList.get(favorList.size() - 1);

            test_getpage_time_start = System.currentTimeMillis();
            start = 0;
            end = start + CACHE_PAGE_SIZE;
            cachePageResult = mCache.getCacheDataByPage(start, end);
            mFirstPageData = cachePageResult.getCachePageData();
            test_getpage_time_end = System.currentTimeMillis();
            SLog.d(TAG, "getPage:" + (test_getpage_time_end - test_getpage_time_start));
            if (mFirstPageData != null && mFirstPageData.size() > 0) {
                mHandler.sendEmptyMessage(ENTER_PAGE_GET_NEW_DATA_FROM_CACHE);
            }
        } else {
            mHandler.sendEmptyMessage(NO_DATA);
        }
        isHttping = false;
    }

    /**
     * Title:saveLoadMoreIdsCache
     * 
     * @Description:保存增量拉取id和items的数据
     * @param fmDataList
     * @return void
     * @throws
     */
    private synchronized void saveLoadMoreIdsCache(FavorItemsByRefresh fmDataList) {
        SLog.i(TAG, mChannel + " : 加载更多ids写缓存===========");
        favorList = mCache.generateCacheData(fmDataList.getIndex(), fmDataList.getListitems(), true);
        if (favorList != null) {
            lastNewsDbItem = favorList.get(favorList.size() - 1);
            cachePageResult = mCache.getCacheDataByPage(start, end);
            nextPageData = cachePageResult.getCachePageData();
            mHandler.sendEmptyMessage(LOAD_NEXT_PAGE_DATA_FROM_CACHE);
        } else {
            mHandler.sendEmptyMessage(LOAD_ALL_END);
        }

        isHttping = false;
    }

    /**
     * Title:changeNetState
     * 
     * @Description:设置互斥网络请求变量
     * @param ing
     * @return void
     * @throws
     */
    private synchronized void changeNetState(boolean ing) {
        isHttping = ing;
    }

    /**
     * Title:PullRefreshBack
     * 
     * @Description:处理下拉刷新数据
     * @return void
     * @throws
     */
    private void PullRefreshBack() {
        test_pull_time_start = System.currentTimeMillis();
        if (mIdAndItemsList != null) {
            if (mIdAndItemsList.getRet().equals("0") || mIdAndItemsList.getRet().equals("-2")) {
                Item[] items = mIdAndItemsList.getListitems();
                if (items != null && items.length > 0) {

                    isLoadAllEnd = false;
                    TaskManager.startRunnableRequestInPool(new Runnable() {
                        @Override
                        public void run() {
                            savePullRefreshCache(mIdAndItemsList);
                        }
                    });

                    SLog.i(TAG, mChannel + " : 发起的网络请求返回了,但回调的是onHttpRecvOK");

                } else {
                    mHandler.sendEmptyMessage(NO_DATA);
                    changeNetState(false);
                }
            } else if (mIdAndItemsList.getRet().equals("1")) {//数据拉取完毕，仍需要合并本地数据，处理其他终端全部删除数据
                TaskManager.startRunnableRequestInPool(new Runnable() {
                    @Override
                    public void run() {
                        savePullRefreshCache(mIdAndItemsList);
                    }
                });
                setRefreshComplete(true);
                // mListView.onRefreshComplete(true);
            } else {
                uf = null;
                setLoginTipsVisible(true);
                favorites_title_str.setText(this.getResources().getString(R.string.my_favorites_not_login));
                setRefreshComplete(true);
                // mListView.onRefreshComplete(true);
                changeNetState(false);
            }
        } else {
            mFramelayout.showState(Constants.ERROR);
            changeNetState(false);
        }
    }

    /**
     * Title:LoadMoreIdAndItemsBack
     * 
     * @Description:处理增量拉取id和items数据
     * @return void
     * @throws
     */
    private void LoadMoreIdAndItemsBack() {
        if (mIdAndItemsList != null) {
            if (mIdAndItemsList.getRet().equals("0") || mIdAndItemsList.getRet().equals("-2")) {
                if (mIdAndItemsList.getIndex() != null && mIdAndItemsList.getIndex().length > 0) {
                    TaskManager.startRunnableRequestInPool(new Runnable() {
                        @Override
                        public void run() {
                            saveLoadMoreIdsCache(mIdAndItemsList);
                        }
                    });

                    SLog.i(TAG, mChannel + " : 发起的网络请求返回了,但回调的是onHttpRecvOK");

                } else {
                    mHandler.sendEmptyMessage(LOAD_ALL_END);
                    changeNetState(false);
                }
            } else if (mIdAndItemsList.getRet().equals("1")) {
                mHandler.sendEmptyMessage(LOAD_ALL_END);
                changeNetState(false);
            } else {
                uf = null;
                setLoginTipsVisible(true);
                favorites_title_str.setText(this.getResources().getString(R.string.my_favorites_not_login));
                mHandler.sendEmptyMessage(LOAD_ALL_END);
                // mListView.setFootViewAddMore(true, true, false);
                changeNetState(false);
            }
        } else {
            mListView.setFootViewAddMore(true, true, false);
            changeNetState(false);
        }
    }

    /**
     * Title:LoadMoreItemsBack
     * 
     * @Description:处理加载更多数据
     * @return void
     * @throws
     */
    private void LoadMoreItemsBack() {
        if (mItemsList != null && (mItemsList.getRet().equals("0") || mItemsList.getRet().equals("-2"))) {
            if (mItemsList.getListitems() != null && mItemsList.getListitems().length > 0) {
                final List<Item> list = new ArrayList<Item>();
                for (Item mItem : mItemsList.getListitems()) {
                    list.add(mItem);
                }
                TaskManager.startRunnableRequestInPool(new Runnable() {
                    @Override
                    public void run() {
                        saveGetMoreCache(list);
                    }
                });
            } else {
                mListView.setFootViewAddMore(false, true, true);
                changeNetState(false);
            }
            if (mItemsList.getListitems_lost() != null) {
                for (int i = 0; i < mItemsList.getListitems_lost().length; i++) {
                    String newsId = mItemsList.getListitems_lost()[i];
                    FavorSyncHelper.getInstance().delFavor(newsId, 0);
                    FavorItemCache.getInstance().clearCache(newsId);
                }
            }
        } else {
            mListView.setFootViewAddMore(false, true, true);
            changeNetState(false);
        }

    }

    private void LoadFirstPageItemsBack() {
        if (mItemsList != null && "0".equals(mItemsList.getRet())) {
            if (mItemsList.getListitems() != null && mItemsList.getListitems().length > 0) {
                final List<Item> list = new ArrayList<Item>();
                for (Item mItem : mItemsList.getListitems()) {
                    list.add(mItem);
                }
                TaskManager.startRunnableRequestInPool(new Runnable() {
                    @Override
                    public void run() {
                        start = 0;
                        end = CACHE_PAGE_SIZE;
                        mFirstPageData = mCache.polishingData(start, end, list);
                        isHttping = false;
                        mHandler.sendEmptyMessage(ENTER_PAGE_GET_NEW_DATA_FROM_CACHE);
                    }
                });
            }
        }

    }

    /**
     * HttpTag.GET_FAVOR_LIST 
     * ret=0,正常;
     * ret=1,数据拉取完毕;
     * ret=-1,鉴权失败;
     * ret=-2,鉴权超时;
     * 
     * HttpTag.GET_FAVOR_LIST_ITEMS
     * ret=0,正常;
     * ret=1,存在无法拉取数据的id;   
     * */
    @Override
    public void onHttpRecvOK(HttpTag tag, Object result) {

        if (tag.equals(HttpTag.GET_FAVOR_LIST)) {
            mIdAndItemsList = null;
            mIdAndItemsList = (FavorItemsByRefresh) result;

            if (isLoadMoreIds) {
                LoadMoreIdAndItemsBack();
            } else {
                PullRefreshBack();
            }
        } else if (tag.equals(HttpTag.GET_FAVOR_LIST_ITEMS)) {
            mItemsList = (FavorItemsByLoadMore) result;
            if (isFirstPageLoadItemsFromNet) {
                LoadFirstPageItemsBack();
            } else {
                LoadMoreItemsBack();
            }
        }
        isFirstPageLoadItemsFromNet = false;
        isLoadMoreIds = false;
    }

    @Override
    public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {
        changeNetState(false);
        if (tag.equals(HttpTag.GET_FAVOR_LIST) && !isLoadMoreIds) {
            SLog.i(TAG, mChannel + " : 发起的网络请求返回了,但回调的是onHttpRecvError");
            if (mAdapter.getCount() > 0) {
                mFramelayout.showState(Constants.LIST);
                setRefreshComplete(false);
                // mListView.onRefreshComplete(false);
                mListView.setFootViewAddMore(false, true, true);
            } else {
                // 通过用户取消的防止出现错误界面
                mFramelayout.showState(Constants.ERROR);
            }

        } else if (tag.equals(HttpTag.GET_FAVOR_LIST_ITEMS) || isLoadMoreIds) {
            mListView.setFootViewAddMore(false, true, true);
        }

        isFirstPageLoadItemsFromNet = false;
        isLoadMoreIds = false;
    }

    @Override
    public void onHttpRecvCancelled(HttpTag tag) {
        changeNetState(false);
        if (tag.equals(HttpTag.GET_FAVOR_LIST) && !isLoadMoreIds) {
            if (mAdapter.getCount() > 0) {
                mFramelayout.showState(Constants.LIST);
                setRefreshComplete(false);
                // mListView.onRefreshComplete(false);
            }
        } else if (tag.equals(HttpTag.GET_FAVOR_LIST_ITEMS)) {
            // mIsGetMoreFinished = true;
            if (mListView != null) {
                mListView.setFootViewAddMore(true, true, true);
            }
        }
        isFirstPageLoadItemsFromNet = false;
        isLoadMoreIds = false;
    }

    @Override
    public void updateSetting(SettingInfo setting) {
        if (mListView != null) {
            mListView.setAutoLoading(true);
        }
        if (mAdapter != null && mListView != null && mIsStyleMode != setting.isIfTextMode()) {
            mIsStyleMode = setting.isIfTextMode();
            if (setting.isIfTextMode()) {
                mAdapter.changeStyleMode(Constants.TYPE_ITEM_TEXT);
            } else {
                mAdapter.changeStyleMode(Constants.TYPE_ITEM_IMAGE);
            }
        }
    }

    private void getIntentData(Intent intent) {
        SettingInfo settingInfo = SettingObservable.getInstance().getData();
        mIsStyleMode = settingInfo.isIfTextMode();
    }

    private void applyTitleBarTheme() {
        themeSettingsHelper.setViewBackgroud(this, this.favorites_title_bar, R.drawable.title_bar_bg);
        themeSettingsHelper.setViewBackgroud(this, this.btn_favorites_title_back, R.drawable.title_complete_btn);
        themeSettingsHelper.setViewBackgroud(this, this.btn_favorites_title_edit, R.drawable.title_complete_btn);
        themeSettingsHelper.setTextViewColor(this, this.favorites_title_str, R.color.activity_imgtxt_title_str_color);
    }

    @Override
    public void applyTheme() {

        applyTitleBarTheme();
        if (mAdapter != null) {
            mAdapter.notifyDataSetChanged();
        }
        if (mFavoriteslayout != null) {
            themeSettingsHelper.setViewBackgroudColor(this, this.mFavoriteslayout, R.color.timeline_home_bg_color);
        }
        if (mFramelayout != null) {
            mFramelayout.applyFrameLayoutTheme();
        }
        // if (themeSettingsHelper.isNightTheme()) {
        // mListView.setCacheColorHint(Color.parseColor("#FF000000"));
        // } else {
        // mListView.setCacheColorHint(Color.parseColor("#00000000"));
        // }
        themeSettingsHelper.setViewBackgroudColor(this, mMask, R.color.mask_page_color);
        themeSettingsHelper.setViewBackgroudColor(this, this.mListView, R.color.timeline_home_bg_color);
        themeSettingsHelper.setListViewSelector(this, this.mListView, R.drawable.list_selector);
        themeSettingsHelper.setListViewDivider(this, this.mListView, R.drawable.list_divider_line);
    }

    private void InitAdapter() {
        mAdapter = new FavoriteslListAdapter(this, mListView);
        mListView.setAdapter(mAdapter);
    }

    private void InitContainerView(Bundle savedInstanceState) {
        setContentView(R.layout.favorites_layout);
        mFavoriteslayout = (RelativeLayout) findViewById(R.id.favorites_layout);
        mMask = findViewById(R.id.mask_view);
        mFramelayout = (FavoritesPullToRefreshFrameLayout) findViewById(R.id.favorites_list_content);
        mListView = mFramelayout.getPullToRefreshListView();
        mEmptyView = mFramelayout.getmEmptyPullRefreshView();
        favorites_title_bar = (RelativeLayout) findViewById(R.id.favorites_title_bar);
        favorites_title_click = (RelativeLayout) findViewById(R.id.favorites_title_click);
        btn_favorites_title_back = (Button) findViewById(R.id.btn_favorites_title_back);
        btn_favorites_title_edit = (Button) findViewById(R.id.btn_favorites_title_edit);
        favorites_title_str = (TextView) findViewById(R.id.favorites_title_str);
        initPopUpFavorBar();
        mListView.setAutoLoading(true);
    }

    /**
     * Title:initPopUpFavorBar
     * 
     * @Description:初始化弹窗
     * @return void
     * @throws
     */
    private void initPopUpFavorBar() {

        cancel_favor_Layout = (LinearLayout) View.inflate(this, R.layout.favorites_pop_bar, null);
        btn_favorites_delete = (Button) cancel_favor_Layout.findViewById(R.id.favorites_btn_delete);
        popupDeleteWindow = new PopupWindow(cancel_favor_Layout, LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);

        // 这个是为了点击“返回Back”也能使其消失，并且并不会影响你的背景
        // popupDeleteWindow.setBackgroundDrawable(new BitmapDrawable());
        // 使其可点击
        popupDeleteWindow.setTouchable(true);
        // 使其聚集
        popupDeleteWindow.setFocusable(false);
        // 设置允许在外点击消失
        // popupDeleteWindow.setOutsideTouchable(false);
        // 设置显示和隐藏的动画
        popupDeleteWindow.setAnimationStyle(R.style.menushow);
        popupDeleteWindow.update();
    }

    public void popUpFavorBar() {
        if (popupDeleteWindow.isShowing()) {
            if (popupDeleteWindow != null) {
                popupDeleteWindow.dismiss();
            }
        } else {
            if (popupDeleteWindow != null) {
                popupDeleteWindow.showAtLocation(this.findViewById(R.id.favorites_layout), Gravity.BOTTOM, 0, 0);
            }
        }

    }

    private String getListviewTimeTag() {
        return mChannel;
    }

    private Class<? extends Object> getClassName(Item item) {
        if (item != null) {
            if (item.getArticletype().equals("1")) {
                return ImageDetailActivity.class;
            } else if (item.getArticletype().equals("5")) {
                return WebDetailActivity.class;
            } else if (item.getArticletype().equals("100")) {
                return SpecialListActivity.class;
            } else if (item.getArticletype().equals("7")) {
                return ImgTxtLiveActivity.class;
            } else if (item.getArticletype().equals("4")) {
                return VideoDetailActivity.class;
            }
        }
        return NewsDetailActivity.class;
    }

    private String getChlidTitle() {
        return "腾讯新闻";
    }

    /**
     * Title:setTitleBarText
     * 
     * @Description:进入收藏页，获取登录态和设置标题显示，并同步收藏列表
     * @return void
     * @throws
     */
    private void setTitleBarText() {

        uf = UserDBHelper.getInstance().getUserInfo();
        setLoginTipsVisible(uf == null);
        if (uf != null) {
            FavorSyncHelper.getInstance().sync();
            setLoginTipsVisible(uf == null);

            favorites_title_str.setText(this.getResources().getString(R.string.my_favorites_login));
        } else {
            favorites_title_str.setText(this.getResources().getString(R.string.my_favorites_not_login));
        }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        final float x = ev.getX();
        final float y = ev.getY();
        if (ev.getAction() == MotionEvent.ACTION_DOWN) {
            downX = x;
            downY = y;
        } else if (ev.getAction() == MotionEvent.ACTION_UP) {
            upX = x;
            upY = y;
            if (upX > downX && Math.abs(upX - downX) > MobileUtil.dpToPx(100)
                    && Math.abs(upY - downY) / Math.abs(upX - downX) < 0.4) {
                quitActivity();
            }
        }
        return super.dispatchTouchEvent(ev);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            if (isSelectedFlag) {
                doEdit();
            } else {
                quitActivity();
            }
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MENU) {
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    /*
     * 处理登录返回结果
     * @see android.support.v4.app.FragmentActivity#onActivityResult(int, int,
     * android.content.Intent)
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK && requestCode == Constants.REQUEST_CODE_LOGIN) {

            WebDev.trackCustomEvent(this, EventId.BOSS_SETTING_LOGINFROM_FAVORITES);

            if (data != null && data.hasExtra(Constants.LOGIN_SUCCESS_BACK_USER_KEY)) {
                uf = (UserInfo) data.getSerializableExtra(Constants.LOGIN_SUCCESS_BACK_USER_KEY);
                setLoginTipsVisible(false);
                mFramelayout.showState(Constants.LOADING);
                favorites_title_str.setText(this.getResources().getString(R.string.my_favorites_login));
                getNewDataFromCache();
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    /**
     * @author jianhu
     * @version 创建时间：2013-7-2 下午12:08:01 类说明
     */
    public class FavoritesReceiver extends BroadcastReceiver {

        private String newsId;
        private boolean isAdd;
        private Item item;
        private FavorDbItem favorDbItem;

        public FavoritesReceiver() {
        }

        /*
         * 处理从收藏页进入底层页添加、 取消 收藏后刷新列表，并停留在原位置
         * @see
         * android.content.BroadcastReceiver#onReceive(android.content.Context,
         * android.content.Intent)
         */
        @Override
        public void onReceive(Context context, Intent intent) {
            // TODO Auto-generated method stub
            SLog.d(TAG, "onReceive");
            if (intent != null && Constants.FAVOR_LIST_REFRESH_ACTION.equals(intent.getAction())) {
                newsId = intent.getStringExtra(Constants.FAVOR_LIST_REFRESH_ID);
                isAdd = intent.getBooleanExtra(Constants.FAVOR_LIST_OP_TYPE, false);
                SLog.d(TAG, "FAVOR_LIST_REFRESH_ACTION");
                if (newsId != null && !"".equals(newsId)) {
                    SLog.d(TAG, "FAVOR_LIST_REFRESH_ACTION:" + isAdd);
                    if (isAdd) {

                        favorDbItem = favorDB.findFavorItem(newsId, uf != null ? uf.getAccount() : FavorSyncHelper
                                .getInstance().getDefaultUser());
                        if (favorDbItem != null) {
                            favorList.add(0, favorDbItem);
                            start += 1;
                            end = start + CACHE_PAGE_SIZE;
                            // ///////////
                            item = (Item) intent.getSerializableExtra(Constants.FAVOR_LIST_ITEM);
                            item.setId(FavorSyncHelper.getInstance().translateId(item.getId()));
                            // //////////
                            // item = favorDB.findFavorCacheItem(newsId);
                            if (item != null) {
                                mAdapter.getDataList().add(0, item);
                            }
                        }
                        // getNewDataFromCache();
                    } else {
                        for (int i = mAdapter.getCount() - 1; i >= 0; i--) {
                            if (mAdapter.getDataList().get(i).getId().equals(newsId)) {
                                mAdapter.getDataList().remove(i);
                                favorList.remove(i);
                                start -= 1;
                                end = start + CACHE_PAGE_SIZE;
                                break;
                            }
                        }
                        if (mAdapter.getDataList().size() == 0 && isLoadAllEnd) {
                            showEmptyTips();
                        }
                    }
                }
            }
            // favorites_title_str.setText("" + favorList.size());
        }
    }
}
