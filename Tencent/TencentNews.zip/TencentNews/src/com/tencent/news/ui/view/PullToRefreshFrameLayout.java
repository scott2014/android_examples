package com.tencent.news.ui.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.config.Constants;
import com.tencent.news.utils.ThemeSettingsHelper;

public class PullToRefreshFrameLayout extends FrameLayout{
	private Context mContext;
	private boolean hasHeader;
	private boolean hasFooter;
	private boolean hasDivider;
	private boolean hasShadow;
	private PullRefreshListView pullToRefreshListView;
	private int nType;
	private RelativeLayout loadLayout = null;
	private RelativeLayout errorLayout = null;
	private RelativeLayout emptyLayout= null;
	private FrameLayout mBackGroudLayout= null;
	private ImageView mShadowTop = null;
	private ImageView mShadowBottom = null;
	private ImageView mLoadingImg = null;
	private TextView mTips= null;
	protected ThemeSettingsHelper themeSettingsHelper = null;
	
	public PullToRefreshFrameLayout(Context context) {
		this(context, null);
	}

	public PullToRefreshFrameLayout(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}
	
	public PullToRefreshFrameLayout(Context context, AttributeSet attrs,
			int defStyle) {
		super(context, attrs, defStyle);
		mContext = context;
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(mContext);
		TypedArray arrayType = context.obtainStyledAttributes(attrs, com.tencent.news.R.styleable.PullToRefreshFrameLayout);
		hasHeader = arrayType.getBoolean(R.styleable.PullToRefreshFrameLayout_has_header, false);
		hasFooter = arrayType.getBoolean(R.styleable.PullToRefreshFrameLayout_has_footer, false);
		hasDivider = arrayType.getBoolean(R.styleable.PullToRefreshFrameLayout_has_divider, false);
		hasShadow = arrayType.getBoolean(R.styleable.PullToRefreshFrameLayout_has_shadow, true);
		arrayType.recycle();
		Init();
	}

	private void Init(){
		LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		inflater.inflate(R.layout.pull_to_refresh_layout, this, true);
		pullToRefreshListView = (PullRefreshListView) findViewById(R.id.timeline_list);
		pullToRefreshListView.setHasHeader(hasHeader);
		pullToRefreshListView.setHasFooter(hasFooter);
		if(!hasDivider){
			pullToRefreshListView.setDivider(null);
			pullToRefreshListView.setDividerHeight(0);
		}
		pullToRefreshListView.initView();
		mBackGroudLayout = (FrameLayout)findViewById(R.id.pull_to_refresh_layout);
		loadLayout = (RelativeLayout)findViewById(R.id.loading_layout);
		errorLayout = (RelativeLayout)findViewById(R.id.error_layout);
		emptyLayout = (RelativeLayout)findViewById(R.id.empty_layout);
		mShadowTop = (ImageView)findViewById(R.id.list_top_shadow);
		mShadowBottom = (ImageView)findViewById(R.id.list_bottom_shadow);
		mLoadingImg = (ImageView)findViewById(R.id.loading_img);
		mTips = (TextView)findViewById(R.id.empty_text_notice);
		if(hasShadow){
			mShadowBottom.setVisibility(View.VISIBLE);
			mShadowTop.setVisibility(View.VISIBLE);
		}else{
			mShadowBottom.setVisibility(View.GONE);
			mShadowTop.setVisibility(View.GONE);
		}		
	}
	
	public void applyFrameLayoutTheme(){		
		themeSettingsHelper.setViewBackgroudColor(mContext, mBackGroudLayout, R.color.pull_to_refresh_bg_color);
		themeSettingsHelper.setViewBackgroud(mContext, mShadowTop, R.drawable.top_shadow_bg);
		themeSettingsHelper.setViewBackgroud(mContext, mShadowBottom, R.drawable.bottom_shadow_bg);
		themeSettingsHelper.setImageViewSrc(mContext, mLoadingImg, R.drawable.news_loading_icon);
		pullToRefreshListView.applyPullRefreshViewTheme();
	}

	public PullRefreshListView getPullToRefreshListView() {
		return pullToRefreshListView;
	}

	public void setPullToRefreshListView(PullRefreshListView pullToRefreshListView) {
		this.pullToRefreshListView = pullToRefreshListView;
	}
	
	public void showState(int nState){
		switch(nState){
		case Constants.LIST:
			pullToRefreshListView.setVisibility(View.VISIBLE);
			loadLayout.setVisibility(View.GONE);
			emptyLayout.setVisibility(View.GONE);
			errorLayout.setVisibility(View.GONE);
			break;
		case Constants.LOADING:
			loadLayout.setVisibility(View.VISIBLE);
			pullToRefreshListView.setVisibility(View.GONE);
			emptyLayout.setVisibility(View.GONE);
			errorLayout.setVisibility(View.GONE);
			break;
		case Constants.EMPTY:
			emptyLayout.setVisibility(View.VISIBLE);
			loadLayout.setVisibility(View.GONE);
			pullToRefreshListView.setVisibility(View.GONE);
			errorLayout.setVisibility(View.GONE);
			break;
		case Constants.ERROR:
			errorLayout.setVisibility(View.VISIBLE);
			emptyLayout.setVisibility(View.GONE);
			loadLayout.setVisibility(View.GONE);
			pullToRefreshListView.setVisibility(View.GONE);
			break;
		default:
			break;
		}
		nType = nState;
	}
	
	public void setRetryButtonClickedListener(OnClickListener listener){
		errorLayout.setOnClickListener(listener);
	}
	
	public int getStateType(){
		return this.nType;
	}
	
	public void setPullListViewTimeTag(String tag){
		pullToRefreshListView.setPullTimeTag(tag);
	}
	
	public void setTipsText(String text){
		mTips.setText(text);
	}
}
