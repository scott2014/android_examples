
package com.tencent.news.ui.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.command.GetImageRequest;
import com.tencent.news.command.GetImageResponse;
import com.tencent.news.config.Constants;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.model.pojo.ImageResult;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.shareprefrence.SpNewsHadRead;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.PullRefreshListView;
import com.tencent.news.utils.DefaulImageUtil;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.StringUtil;

import java.util.ArrayList;

public class RssNewsListAdapter extends AbsListAdapter<Item> implements GetImageResponse {

    protected int itemType;
    private final int FROM_LOCAL = 0; // 从本地缓存取图
    private final int FROM_REMOTE = 1; // 从网络取图
    private static String TAG = "RssNewsListAdapter";

    public RssNewsListAdapter(Context context, ListView listView) {
        this.mContext = context;
        this.mListView = listView;
        mDataList = new ArrayList<Item>();
        ((PullRefreshListView) mListView).setSartListener(this);
        SettingInfo settingInfo = SettingObservable.getInstance().getData();
        if (settingInfo != null && settingInfo.isIfTextMode()) {
            itemType = Constants.TYPE_ITEM_TEXT;
        } else {
            itemType = Constants.TYPE_ITEM_IMAGE;
        }
    }

    @Override
    public int getItemViewType(int position) {
        Item item = mDataList.get(position);
        if (itemType == Constants.TYPE_ITEM_IMAGE && item != null && item.getArticletype() != null
                && item.getArticletype().trim().equals("1")) {
            styleType = Constants.TYPE_ITEM_THREE_PHOTO;
        } else {
            styleType = itemType;
        }
        return styleType;
    }

    @Override
    public void changeStyleMode(int style) {
        this.itemType = style;
        notifyDataSetChanged();
    }

    @Override
    public int getViewTypeCount() {
        return 3;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        int type = getItemViewType(position);
        SLog.i(TAG, "文章类型" + String.valueOf(type));
        switch (type) {
            case Constants.TYPE_ITEM_TEXT:
                convertView = setTextMode(convertView, position, holder);
                break;
            case Constants.TYPE_ITEM_IMAGE:
                convertView = setImageMode(convertView, position, holder);
                break;
            case Constants.TYPE_ITEM_THREE_PHOTO:
                convertView = setMoreImageMode(convertView, position, holder);
                break;
            default:
                break;
        }
        return convertView;
    }

    private View setMoreImageMode(View convertView, int position, ViewHolder holder) {
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = LayoutInflater.from(mContext)
                    .inflate(R.layout.rss_list_item_photos, null);
            holder.root_layout = (LinearLayout) convertView.findViewById(R.id.item_root_layout);
            holder.author_name = (TextView) convertView.findViewById(R.id.author_name);
            holder.comments_image = (ImageView) convertView.findViewById(R.id.comments_image);
            holder.comments_text = (TextView) convertView.findViewById(R.id.comments_text);
            holder.publish_time = (TextView) convertView.findViewById(R.id.publish_time);
            holder.title = (TextView) convertView.findViewById(R.id.list_title_text);
            holder.imageLeft = (ImageView) convertView.findViewById(R.id.left_image);
            holder.imageMid = (ImageView) convertView.findViewById(R.id.mid_image);
            holder.imageRight = (ImageView) convertView.findViewById(R.id.right_image);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        applyThemeInItem(holder);

        Item item = mDataList.get(position);
        if (item == null || item.getId() == null) {
            return convertView;
        }
        holder.id = item.getId();
        holder.articletype = item.getArticletype();
        setTextData(item, holder);

        if (!((PullRefreshListView) mListView).isBusy()) {
            setThreeSmallImage(item, holder, FROM_REMOTE);
        } else {
            setThreeSmallImage(item, holder, FROM_LOCAL);
        }
        return convertView;
    }

    private View setImageMode(View convertView, int position, ViewHolder holder) {
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = LayoutInflater.from(mContext).inflate(R.layout.rss_list_item, null);
            holder.root_layout = (LinearLayout) convertView.findViewById(R.id.item_root_layout);
            holder.author_name = (TextView) convertView.findViewById(R.id.author_name);
            holder.comments_image = (ImageView) convertView.findViewById(R.id.comments_image);
            holder.comments_text = (TextView) convertView.findViewById(R.id.comments_text);
            holder.publish_time = (TextView) convertView.findViewById(R.id.publish_time);
            holder.title = (TextView) convertView.findViewById(R.id.list_title_text);
            holder.image = (ImageView) convertView.findViewById(R.id.list_item_image);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        applyThemeInItem(holder);

        Item item = mDataList.get(position);
        if (item == null || item.getId() == null) {
            return convertView;
        }
        holder.id = item.getId();
        holder.articletype = item.getArticletype();
        setTextData(item, holder);
        holder.image.setVisibility(View.VISIBLE);

        if (!((PullRefreshListView) mListView).isBusy()) {
            setSingleImage(item, holder, FROM_REMOTE);
        } else {
            setSingleImage(item, holder, FROM_LOCAL);
        }

        return convertView;
    }

    private View setTextMode(View convertView, int position, ViewHolder holder) {
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = LayoutInflater.from(mContext).inflate(R.layout.rss_list_item, null);
            holder.root_layout = (LinearLayout) convertView.findViewById(R.id.item_root_layout);
            holder.author_name = (TextView) convertView.findViewById(R.id.author_name);
            holder.comments_image = (ImageView) convertView.findViewById(R.id.comments_image);
            holder.comments_text = (TextView) convertView.findViewById(R.id.comments_text);
            holder.publish_time = (TextView) convertView.findViewById(R.id.publish_time);
            holder.title = (TextView) convertView.findViewById(R.id.list_title_text);
            holder.image = (ImageView) convertView.findViewById(R.id.list_item_image);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        applyThemeInItem(holder);

        Item item = mDataList.get(position);
        if (item == null || item.getId() == null) {
            return convertView;
        }
        holder.id = item.getId();
        holder.articletype = item.getArticletype();
        setTextData(item, holder);
        holder.image.setVisibility(View.GONE);
        return convertView;
    }

    protected static class ViewHolder {
        public String id;
        public String articletype;

        public LinearLayout root_layout;
        public TextView author_name;
        public ImageView comments_image;
        public TextView comments_text;
        public TextView publish_time;
        public TextView title;
        public ImageView image;
        public ImageView imageLeft; // 列表页三个小图中最左边的一个
        public ImageView imageMid; // 列表页三个小图中中间的一个
        public ImageView imageRight; // 列表页三个小图中最右边的一个
    }

    protected static class Tag {
        String id; // 与ViewHolder中的id对应
        int position; // 如果是一张图position=0，如果是三张小图position=1，2，3分别表示左中右
    }

    @Override
    public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm, String path) {
        // TODO Auto-generated method stub
        Tag mTag = (Tag) tag;
        switch (imageType) {
            case SMALL_IMAGE:
                int countImage = mListView.getChildCount();
                for (int i = 0; i < countImage; i++) {
                    ViewHolder holder = (ViewHolder) mListView.getChildAt(i).getTag();
                    if (holder != null) {
                        if (((String) mTag.id).equals(holder.id)) {
                            switch (mTag.position) {
                                case 0:
                                    if (bm != null) {
                                        holder.image.setImageBitmap(bm);
                                    }
                                    break;
                                case 1:
                                    setSmallImage(holder.imageLeft, bm);
                                    break;
                                case 2:
                                    setSmallImage(holder.imageMid, bm);
                                    break;
                                case 3:
                                    setSmallImage(holder.imageRight, bm);
                                    break;
                                default:
                                    break;
                            }
                            break;
                        }
                    }
                }
                break;
            default:
                break;
        }
    }

    @Override
    public void onImageRecvError(ImageType imageType, Object tag, int retCode) {
    }

    protected void setTextData(Item item, ViewHolder holder) {
        if (item == null || holder == null || item.getId() == null) {
            return;
        }

        if (SpNewsHadRead.isNewsHadRead(item.getId())) {
            if (themeSettingsHelper.isNightTheme()) {
                holder.title.setTextColor(mContext.getResources().getColor(
                        R.color.night_readed_news_title_color));
            } else {
                holder.title.setTextColor(mContext.getResources().getColor(
                        R.color.readed_news_title_color));
            }
        } else {
            if (themeSettingsHelper.isNightTheme()) {
                holder.title.setTextColor(mContext.getResources().getColor(
                        R.color.night_list_title_color));
            } else {
                holder.title.setTextColor(mContext.getResources()
                        .getColor(R.color.list_title_color));
            }
        }

        holder.author_name.setText(item.getChlname());
        if (item.getTitle() != null) {
            holder.title.setText(StringUtil.replaceBlank(item.getTitle()));
        }

        String num = item.getCommentNum();
        if (num == null || num.length() == 0 || num.equals("0")) {
            holder.comments_image.setVisibility(View.GONE);
            holder.comments_text.setVisibility(View.GONE);
        } else {
            holder.comments_image.setVisibility(View.VISIBLE);
            holder.comments_text.setVisibility(View.VISIBLE);
            if (Long.parseLong(num) > 10000) {
                holder.comments_text.setText(StringUtil.tenTh2wan(num));
            } else {
                holder.comments_text.setText(num);
            }
        }

        try {
            holder.publish_time.setText(StringUtil.getRelativeTimeStringEx(Long.valueOf(item
                    .getTimestamp()) * 1000));
        } catch (Exception e) {
            holder.publish_time.setText("");
        }
    }

    @Override
    public void serListViewBusy(int currPosition, int tag) {
        if (itemType == Constants.TYPE_ITEM_TEXT) {
            return;
        }
        if (currPosition >= 0 && currPosition < mDataList.size()) {
            Item item = mDataList.get(currPosition);
            ViewHolder holder = (ViewHolder) mListView.getChildAt(tag).getTag();
            if (item != null && item.getArticletype() != null
                    && item.getArticletype().trim().equals("1")) {
                setThreeSmallImage(item, holder, FROM_REMOTE);
            } else {
                setSingleImage(item, holder, FROM_REMOTE);
            }
        }
    }

    // 夜间模式的处理
    public void applyThemeInItem(ViewHolder holder) {
        if (holder == null) {
            return;
        }
        if (themeSettingsHelper.isNightTheme()) {// 设置夜间模式图标和字体颜色
            if (holder.root_layout != null) {
                holder.root_layout.setBackgroundDrawable(mContext.getResources().getDrawable(
                        R.drawable.night_rss_list_selector));
            }
            if (holder.author_name != null) {
                holder.author_name.setTextColor(mContext.getResources().getColor(
                        R.color.night_list_title_color));
            }
            if (holder.title != null) {
                holder.title.setTextColor(mContext.getResources().getColor(
                        R.color.night_list_title_color));
            }
            if (holder.comments_image != null) {
                holder.comments_image.setImageDrawable(mContext.getResources().getDrawable(
                        R.drawable.night_list_item_comment_icon));
            }
            if (holder.comments_text != null) {
                holder.comments_text.setTextColor(mContext.getResources().getColor(
                        R.color.night_list_comment_color));
            }
            if (holder.publish_time != null) {
                holder.publish_time.setTextColor(mContext.getResources().getColor(
                        R.color.night_list_comment_color));
            }
        } else {
            if (holder.root_layout != null) {
                holder.root_layout.setBackgroundDrawable(mContext.getResources().getDrawable(
                        R.drawable.rss_list_selector));
            }
            if (holder.author_name != null) {
                holder.author_name.setTextColor(mContext.getResources().getColor(
                        R.color.list_title_color));
            }
            if (holder.title != null) {
                holder.title.setTextColor(mContext.getResources()
                        .getColor(R.color.list_title_color));
            }
            if (holder.comments_image != null) {
                holder.comments_image.setImageDrawable(mContext.getResources().getDrawable(
                        R.drawable.list_item_comment_icon));
            }
            if (holder.comments_text != null) {
                holder.comments_text.setTextColor(mContext.getResources().getColor(
                        R.color.list_comment_color));
            }
            if (holder.publish_time != null) {
                holder.publish_time.setTextColor(mContext.getResources().getColor(
                        R.color.list_comment_color));
            }
        }
    }

    private void setSingleImage(Item item, ViewHolder holder, int from) {

        if (item == null || holder == null || holder.id == null) {
            return;
        }

        String url = "";
        Bitmap bitmap = null;
        Tag tag = new Tag();
        tag.id = holder.id;
        tag.position = 0;
        url = (item.getThumbnails_qqnews() != null && item.getThumbnails_qqnews().length > 0) ? item
                .getThumbnails_qqnews()[0] : "";

        bitmap = getBitMapImage(item, tag, Constants.TYPE_ITEM_IMAGE, url, from);
        if (bitmap != null && holder.image != null) {
            holder.image.setImageBitmap(bitmap);
        }
    }

    private void setThreeSmallImage(Item item, ViewHolder holder, int from) {
        String url = "";
        Bitmap smallBitmapArr[] = new Bitmap[3];
        int mType = Constants.TYPE_ITEM_THREE_PHOTO;
        if (holder != null && holder.id != null && item != null
                && item.getThumbnails_qqnews() != null && item.getThumbnails_qqnews().length > 0) {
            int size = item.getThumbnails_qqnews().length > 4 ? 4
                    : item.getThumbnails_qqnews().length;
            for (int i = 1; i < size; i++) {
                Tag tag = new Tag();
                tag.id = holder.id;
                tag.position = i;
                url = (item.getThumbnails_qqnews()[i] != null && item.getThumbnails_qqnews()[i]
                        .length() > 0) ? item.getThumbnails_qqnews()[i] : "";
                smallBitmapArr[i - 1] = getBitMapImage(item, tag, mType, url, from);
            }
            setSmallImage(holder.imageLeft, smallBitmapArr[0]);
            setSmallImage(holder.imageMid, smallBitmapArr[1]);
            setSmallImage(holder.imageRight, smallBitmapArr[2]);
        }
    }

    protected Bitmap getBitMapImage(Item item, Tag tag, int type, String url, int from) {

        if (url == null || url == "") {
            return getDefaultBitmap(type);
        }

        Bitmap retBitmap = null;
        ImageResult result = null;
        GetImageRequest request = new GetImageRequest();

        request.setGzip(false);
        request.setTag(tag);
        request.setUrl(url);
        if (from == FROM_REMOTE) {
            result = TaskManager.startSmallImageTask(request, this);
        } else {
            result = TaskManager.getLocalIconImage(request, this);
        }

        if (result.isResultOK() && result.getRetBitmap() != null) {
            retBitmap = result.getRetBitmap();
        } else {
            retBitmap = getDefaultBitmap(type);
        }
        return retBitmap;
    }

    protected Bitmap getDefaultBitmap(int type) {
        Bitmap retBitmap = null;
        if (type == Constants.TYPE_ITEM_THREE_PHOTO) {
            if (themeSettingsHelper.isNightTheme()) {
                retBitmap = DefaulImageUtil.getNightDefaultPhotoListImage();
            } else {
                retBitmap = DefaulImageUtil.getDefaultPhotoListImage();
            }
        } else {
            if (themeSettingsHelper.isNightTheme()) {
                retBitmap = DefaulImageUtil.getNightDefaultTimelineImage();
            } else {
                retBitmap = DefaulImageUtil.getDefaultTimelineImage();
            }
        }
        return retBitmap;
    }

    private void setSmallImage(ImageView srcImage, Bitmap bm) {

        if (bm == null || srcImage == null) {
            return;
        }

        int desImageViewWidth = 0;
        int desImageViewHeight = 0;
        int totalWidth = MobileUtil.getScreenWidthIntPx() - MobileUtil.dpToPx(7 * 2 + 48);

        desImageViewWidth = totalWidth / 3;
        desImageViewHeight = (int) (desImageViewWidth * 0.7);
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) srcImage.getLayoutParams();
        lp.width = desImageViewWidth;
        lp.height = desImageViewHeight;
        srcImage.setLayoutParams(lp);
        srcImage.setScaleType(ScaleType.FIT_XY);
        srcImage.setImageBitmap(bm);
    }

}
