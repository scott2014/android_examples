package com.tencent.news.ui.view;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import com.tencent.news.config.Constants;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.ui.SettingActivity;
import com.tencent.news.utils.ThemeSettingsHelper;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ImageView;

public class WebViewForCell extends FrameLayout {
	public enum JS_FUNC {
		channelDidAppear,
		channelDidDisappear,
		channelDidRefreshData,
		themeChanged,
		loginStatueChanged
	}
	
	public interface JsInterface {
		public void onWebCellReady();
		public void onWebCellError();
		public void onWebCellUIChanged();
	}
	
	private JsInterface mJsInterface;
	private String mChannel;
	private WebView mWebView;
	private ImageView mCoverImage;
	public boolean isFirstLoad;
	private int mContentHeight;   // dp
	private String mUrl;
	
	private Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			if(msg.what == 0) {
				if(isFirstLoad) {
					isFirstLoad = false;
					handler.sendEmptyMessage(1);
				} else {
					if(mCoverImage != null) {
						removeView(mCoverImage);
						mCoverImage = null;
					}
					saveScreenShot();
				}
			} else if(msg.what == 1) {
				DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
				final int speed = (int) (3 * displayMetrics.density);
				int cellHeight = (int) (mContentHeight * displayMetrics.density);
				int height = mWebView.getHeight();
				LayoutParams lp = (LayoutParams) mWebView.getLayoutParams();
				if (height < cellHeight) {
					if (height + speed > cellHeight) {
						lp.height = cellHeight;
					} else {
						lp.height += speed;
					}
					mWebView.requestLayout();
					handler.sendEmptyMessage(1);
				} else if(height == cellHeight) {
					saveScreenShot();
				}
			}
		}
	};
	
	public void updateTheme() {
		if(ThemeSettingsHelper.getThemeSettingsHelper(getContext()).isNightTheme()) {
			callJs(JS_FUNC.themeChanged, "theme_night");
		} else {
			callJs(JS_FUNC.themeChanged, "theme_default");
		}
	}
	public void showWebCell() {
		handler.sendEmptyMessage(0);		
	}
	private class JsCall implements JsInterface {
		public JsCall(){
		}

		@Override
		public void onWebCellReady() {
			mJsInterface.onWebCellReady();
		}

		@Override
		public void onWebCellError() {
			mJsInterface.onWebCellError();
		}

		@Override
		public void onWebCellUIChanged() {
			mJsInterface.onWebCellUIChanged();
			saveScreenShot();
		}

		public void queryData(final String url, String data, final String successCallback,
				String failedCallback) {
			new Thread(new Runnable() {
				public void run() {
					HttpGet request = new HttpGet(url);

					SettingInfo settingData = SettingObservable.getInstance().getData();
					if (settingData.getUserInfo() != null) {
						String uin = settingData.getUserInfo().getLuin();
						String key = settingData.getUserInfo().getLskey();
						request.setHeader("cookie", "luin=" + uin + "; lskey=" + key);
					}

					HttpClient client = new DefaultHttpClient();
					HttpResponse response = null;

					try {
						response = client.execute(request);
						int stateCode = response.getStatusLine().getStatusCode();
						if (stateCode == HttpStatus.SC_OK) {
							String result = EntityUtils.toString(response
									.getEntity());
							callJs(successCallback, result);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}).start();
		}
		
	}
	

	
	public void loadUrl(String url) {
		if(url != null && !url.equals(mUrl)) {
			mWebView.loadUrl(url);
			mUrl = url;
		}
	}
	
	public boolean isFirstLoad() {
		return isFirstLoad;
	}
	
	public void init(String channel, int contentHeight) {
		mChannel = channel;
		mContentHeight = contentHeight;
		
		File file = new File(Constants.WEBVIEW_SCREEN_SHOT_PATH + mChannel);
		isFirstLoad = !file.exists();
		
		mWebView = new WebView(getContext());
		mWebView.getSettings().setJavaScriptEnabled(true);
		
		addView(mWebView);
		if(isFirstLoad) {
			mWebView.setLayoutParams(new FrameLayout.LayoutParams(
					FrameLayout.LayoutParams.FILL_PARENT, 1));			
		} else {
			DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
			int cellHeight = (int) (mContentHeight * displayMetrics.density);
			mWebView.setLayoutParams(new FrameLayout.LayoutParams(
					FrameLayout.LayoutParams.FILL_PARENT, cellHeight));
		}
		
		if(!isFirstLoad) {
			mCoverImage = new ImageView(getContext());
			mCoverImage.setLayoutParams(new FrameLayout.LayoutParams(
					FrameLayout.LayoutParams.FILL_PARENT,
					FrameLayout.LayoutParams.FILL_PARENT));

			Bitmap screenShot = BitmapFactory.decodeFile(Constants.WEBVIEW_SCREEN_SHOT_PATH + mChannel);
			mCoverImage.setImageBitmap(screenShot);
			addView(mCoverImage);
		}
	}
	
//	@Override
//	protected void onLayout(boolean changed, int left, int top, int right,
//			int bottom) {
//		
//	}
	
	public void setCacheBackground(Drawable background) {
		
	}
	
	public void saveScreenShot() {
		handler.postDelayed(new Runnable() {
			@Override
			public void run() {
				if(mWebView.getWidth() <= 0 || mWebView.getHeight() <= 0) {
					return;
				}
				Bitmap screenShot = Bitmap.createBitmap(mWebView.getWidth(), mWebView.getHeight(), Config.ARGB_8888);
				Canvas canvas = new Canvas(screenShot);
				draw(canvas);
				File folder = new File(Constants.WEBVIEW_SCREEN_SHOT_PATH);
				if(!folder.exists()) {
					folder.mkdir();
				}
				final File file = new File(Constants.WEBVIEW_SCREEN_SHOT_PATH + mChannel);
				if(file != null) {
					FileOutputStream fos = null;
		            try {
		                fos = new FileOutputStream(file);
		                screenShot.compress(CompressFormat.PNG, 80, fos);
		            } catch (FileNotFoundException e) {
		            	e.printStackTrace();
		            } finally {
		            	if(fos != null) {
		            		try {
								fos.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
		            	}
		            }
				}
			}
		}, 400);
	}
	
	public WebViewForCell(Context context) {
		super(context);
	}
	

	public WebViewForCell(Context context, AttributeSet attr) {
		this(context, attr, 0);
	}

	public WebViewForCell(Context context, AttributeSet attr, int defStyle) {
		super(context, attr, defStyle);
	}
	
	public void initJsInterface(JsInterface js) {
		if(js != null) {
			mWebView.getSettings().setJavaScriptEnabled(true);
			mJsInterface = js;
			mWebView.addJavascriptInterface(new JsCall(), "JsInterface");
			mWebView.setWebChromeClient(new MyWebChromeClient());
		}
	}

	public void callJs(String func, Object param) {
		String jsFunc;
		if(param == null) {
			jsFunc = "javascript:" + func + "()";
		} else {			
			jsFunc = "javascript:" + func + "(" + param + ")";
		}
		mWebView.loadUrl(jsFunc);
	}
	
	public void callJs(JS_FUNC func, String param) {
		String jsFunc = "javascript:webCellManager.";
		switch(func) {
		case channelDidAppear:
			jsFunc += "channelDidAppear()";
			break;
		case channelDidDisappear:
			jsFunc += "channelDidDisappear()";
			break;
		case channelDidRefreshData:
			jsFunc += "channelDidRefreshData()";
			break;
		case themeChanged:
			jsFunc += "themeChanged('" + param + "')";
			break;
		case loginStatueChanged:
			jsFunc += "loginStatueChanged()";
			break;
		default:
			break;
		}
		mWebView.loadUrl(jsFunc);
	}
	
  final class MyWebChromeClient extends WebChromeClient {
	@Override
	public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
		result.confirm();
		return true;
	}
}
}
