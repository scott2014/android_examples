package com.tencent.news.ui;

import java.util.List;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpDataResponse;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.pojo.CheckSubscribe;
import com.tencent.news.model.pojo.NewsMsg;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.adapter.PersonalMsgAdapter;
import com.tencent.news.ui.fragment.AtFragment;
import com.tencent.news.ui.fragment.MyCommentFragment;
import com.tencent.news.ui.fragment.PersonalFragment;
import com.tencent.news.ui.view.ChannelBarBase.ChannelBarClickListener;
import com.tencent.news.ui.view.ChannelBarComment;
import com.tencent.news.ui.view.PullToRefreshFrameLayout;
import com.tencent.news.ui.view.TitleBar;
import com.tencent.news.ui.view.ViewPagerEx;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.ThemeSettingsHelper;
import com.tencent.omg.webdev.WebDev;

/**
 * @author haiyandu
 *
 */
public class CommentFragmentActivity extends BaseActivity {
	private RelativeLayout mTitleBar;
    private Button mBtnBack;
    private TextView mTitleText;
    private Button mBtnEdit;
	private ViewPagerEx mChannelViewPager;
	private ChannelBarComment mChannelBarComment;
	private CommentPagerAdapter mCommentPagerAdapter;
	protected int nCurrChannel = 0;
	private View mMask;
	protected int mScreenWidth;//屏幕宽度
	private final static int MAX_SHOW_NUMBER = 99;
	private Boolean mEditable = false, showAtCount = false;
	private int mMailCount = 0, mAtCount = 0;
    
    private UpdateEditStatusReceiver mUpdateEditStatusReceiver = null;
    private UpdateMailAndAtCountReceiver mMailCountReceiver = null;
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mycomment_activity_layout);
		Intent intent = getIntent();
		
		if (intent!=null && intent.getAction()!=null && 
           intent.getAction().equals(Constants.UPDATE_MAIL_AND_AT_COUNT) && 
           intent.hasExtra("action") && intent.getStringExtra("action").equals("update")) {
			
		   if(intent.hasExtra("mailCount")){
			   mMailCount = intent.getIntExtra("mailCount", 0);      		 
		   }
		   if(intent.hasExtra("atCount")){
			   mAtCount =  intent.getIntExtra("atCount", 0);  
		   }
	            
		}
		//SLog.d("==CommentFragmentActivity==","atCount" + String.valueOf(mAtCount));
		initView();
		initListener();		
		startRegisters();
	}
	
	private void initView() {
		mChannelViewPager = (ViewPagerEx) findViewById(R.id.comment_view_pager);
		mChannelBarComment = (ChannelBarComment) findViewById(R.id.comment_bar);
		mTitleBar = (RelativeLayout) findViewById(R.id.title_bar);
		mBtnBack = (Button) findViewById(R.id.btn_title_back);
		mTitleText = (TextView) findViewById(R.id.title_str);
		mBtnEdit = (Button) findViewById(R.id.btn_title_edit);
		mMask = (View) findViewById(R.id.mask_view_mycomment);
		mCommentPagerAdapter = new CommentPagerAdapter(getSupportFragmentManager(), mEditable);
		mChannelViewPager.setOnPageChangeListener(new ChannelOnPageChangeListener());
		mChannelViewPager.setAdapter(mCommentPagerAdapter);		
		
		if (mAtCount > 99) {
			showAtCount = true;
            mChannelBarComment.setNotReading("99+", 1, true);
        } else if(mAtCount > 0){
        	showAtCount = true;
        	mChannelBarComment.setNotReading(String.valueOf(mAtCount), 1, true);
        } else {
        	showAtCount = false;
            mChannelBarComment.setNotReading("", 1, false);
        }
	}
	
	private void startRegisters(){
		registerEditStatusReceiver();
		registerMailAndATCountReceiver();
	}

	private void initListener() {
		
		mChannelBarComment.setOnChannelBarClickListener(new ChannelBarClickListener() {
			@Override
			public void onSelected(int nIndex) {
				nCurrChannel = nIndex;
				mChannelViewPager.setCurrentItem(nIndex, false);
				
				if (nIndex != 2) {
				    mBtnEdit.setVisibility(View.GONE);
				} else {
				    mBtnEdit.setVisibility(View.VISIBLE);
				}
			}

		});
		
		mBtnBack.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				quitActivity();
			}
			
		});
		
		mBtnEdit.setOnClickListener(new View.OnClickListener() {
            
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                PersonalFragment mFragment = mCommentPagerAdapter.mPersonalFragment;
                
                if (mFragment != null) {
                    mFragment.changeFragmentEditFlag();
                }
                
            }
        });
	}

	public static class CommentPagerAdapter extends FragmentPagerAdapter {
	    
	    private Boolean mEditable;
	    public PersonalFragment mPersonalFragment = null;
	    
		public CommentPagerAdapter(FragmentManager fm, Boolean editable) {
			super(fm);
			this.mEditable = editable;
		}

		@Override
		public int getCount() {
			return 3;
		}

		@Override
		public Fragment getItem(int position) {
			Fragment fragment = null;
			switch (position) {
			case 0:
				fragment = MyCommentFragment.newInstance();				
				break;
			case 1:
				fragment = AtFragment.newInstance();
				break;
			case 2:
			    fragment = PersonalFragment.newInstance(mEditable); 
			    mPersonalFragment = (PersonalFragment) fragment;
				break;
			default:
				break;
			}
			return fragment;
		}
	}

	public class ChannelOnPageChangeListener implements OnPageChangeListener {

		@Override
		public void onPageScrollStateChanged(int arg0) {

			switch (arg0) {
			case ViewPager.SCROLL_STATE_DRAGGING:
				SLog.i("ViewPager", "ViewPager.SCROLL_STATE_DRAGGING");
				break;
			case ViewPager.SCROLL_STATE_SETTLING:
				SLog.i("ViewPager", "ViewPager.SCROLL_STATE_SETTLING");
				break;
			case ViewPager.SCROLL_STATE_IDLE:
				SLog.i("ViewPager", "ViewPager.SCROLL_STATE_IDLE");
				break;
			}

		}

		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {
			SLog.i("ViewPager", "arg0:arg1 —— " + arg0 + " : " + arg1);
			mChannelBarComment.scrollBySlide(arg0, arg1);
		}

		@Override
		public void onPageSelected(int arg0) {
			nCurrChannel = arg0;
			mChannelBarComment.setFocusByImageViewBg(arg0);
			mChannelBarComment.setSelectedState(arg0);
			if(nCurrChannel==1){
				showAtCount = false;
	            mChannelBarComment.setNotReading("", 1, false);
			}
			if (nCurrChannel != 2) {
                mBtnEdit.setVisibility(View.GONE);
            } else {
                mBtnEdit.setVisibility(View.VISIBLE);
            }
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
		    if (nCurrChannel == 2 && mEditable == true) {
	            PersonalFragment mFragment = mCommentPagerAdapter.mPersonalFragment;
                
                if (mFragment != null) {
                    mFragment.changeFragmentEditFlag();
                }
		    } else {
		        quitActivity();
		    }
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_MENU) {
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}
	
	@Override
	protected void onDestroy() {
	    super.onDestroy();
	    if (mUpdateEditStatusReceiver != null) {
	        this.unregisterReceiver(mUpdateEditStatusReceiver);
	        mUpdateEditStatusReceiver = null;
	    }
	    
	    if (mMailCountReceiver != null) {
	        this.unregisterReceiver(mMailCountReceiver);
	        mMailCountReceiver = null;
	    }
	}
	
	@Override
    public void applyTheme() {
        // Auto-generated method stub
        
        themeSettingsHelper.setViewBackgroud(this, this.mTitleBar, R.drawable.title_bar_bg);
        themeSettingsHelper.setViewBackgroud(this, this.mBtnBack, R.drawable.title_back_btn);    
        themeSettingsHelper.setViewBackgroud(this, this.mBtnEdit, R.drawable.btn_send_selector);    
        
        
	    mChannelBarComment.applyChannelBarTheme(this);
	    themeSettingsHelper.setViewBackgroudColor(this, mChannelViewPager, R.color.viewpage_bg_color);
	    themeSettingsHelper.setViewBackgroudColor(this, mMask, R.color.mask_page_color);
    }
	
	private void registerEditStatusReceiver() {
	    if (mUpdateEditStatusReceiver == null) {
	        mUpdateEditStatusReceiver = new UpdateEditStatusReceiver();
	        IntentFilter filter = new IntentFilter(Constants.UPDATE_MSGGROUP_EDIT_STATUS);
	        registerReceiver(mUpdateEditStatusReceiver, filter);
	    }
    }
	
	private class UpdateEditStatusReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(Constants.UPDATE_MSGGROUP_EDIT_STATUS)) {
                mEditable = intent.getBooleanExtra("editable", false);
                if (mEditable == true) {
                    mBtnEdit.setText("取消");
                    mBtnBack.setVisibility(View.GONE);
                    mChannelViewPager.setScrollable(false);
                } else {
                    mBtnEdit.setText("编辑");
                    mBtnBack.setVisibility(View.VISIBLE);
                    mChannelViewPager.setScrollable(true);
                }
                
                if (nCurrChannel == 2 && mEditable == true)
                    mBtnBack.setVisibility(View.GONE);
                else
                    mBtnBack.setVisibility(View.VISIBLE);
            }
        }
    }
	
	private void registerMailAndATCountReceiver() {
        if (mMailCountReceiver == null) {
            mMailCountReceiver = new UpdateMailAndAtCountReceiver();
            IntentFilter filter = new IntentFilter(Constants.UPDATE_MAIL_AND_AT_COUNT);
            registerReceiver(mMailCountReceiver, filter);
        }
    }
	
	private class UpdateMailAndAtCountReceiver extends BroadcastReceiver {
	    
	    @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(Constants.UPDATE_MAIL_AND_AT_COUNT) && intent.hasExtra("action")) {
                int mailCount = intent.getIntExtra("mailCount", 0);
                String action = intent.getStringExtra("action");
                
                if (action.equals("update")) {
                    mMailCount = mailCount;
                } else if (action.equals("readed")) {
                    mMailCount -= mailCount;
                }
                
                if(action!=null && action.equals("update") && intent.hasExtra("atCount")){
                	 mAtCount =  intent.getIntExtra("atCount", 0);  
		  			 if (mAtCount > 99) {
		     			showAtCount = true;
		                 mChannelBarComment.setNotReading("99+", 1, true);
		             } else if(mAtCount > 0){
		             	showAtCount = true;
		             	mChannelBarComment.setNotReading(String.valueOf(mAtCount), 1, true);
		             } else {
		             	showAtCount = false;
		                 mChannelBarComment.setNotReading("", 1, false);
		             }       
      		    }                         
                
                if (mMailCount > 0) {
                    if (mMailCount > 99) {
                        mChannelBarComment.setNotReading("99+", 2, true);
                    } else {
                        mChannelBarComment.setNotReading(mMailCount + "", 2, true);
                    }
                } else {
                    mChannelBarComment.setNotReading("", 2, false);
                }
            }
        }
	}
}
