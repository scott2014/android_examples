package com.tencent.news.ui.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.shareprefrence.SpNewsHadRead;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.StringUtil;
import com.tencent.news.utils.ThemeSettingsHelper;

public class PullImageHeadView extends FrameLayout {
	private Context mContext;
	private FrameLayout mClickLayout;
	private LinearLayout mLinearLayout;
	private FrameLayout mImageLayout;
	private LinearLayout mTextLayout;
	private ImageView headImage;
	private TextView headTitle;
	private ImageView headIcon;
	private Boolean isShowIcon = true;
	private TextView topic_item_qishu;
	private TextView mTextStyleTitle;
	private TextView mTextStyleAbstract;
	private TextView mTextStyleComments;
	private ImageView mTextStyleFlag;
	private ImageView mImageIcon;
	private ImageView mCommentIcon;
	private TextView mImageCount;
	private View mDivider;
	protected ThemeSettingsHelper themeSettingsHelper = null;
	protected SettingInfo settingInfo = null;

	public PullImageHeadView(Context context) {
		super(context);
		Init(context);
	}

	public PullImageHeadView(Context context, AttributeSet attrs) {
		super(context, attrs);
		Init(context);
	}

	public PullImageHeadView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		Init(context);
	}

	private void Init(Context context) {
		this.mContext = context;
		LayoutInflater.from(mContext).inflate(R.layout.pull_list_image_head,this, true);
		mLinearLayout = (LinearLayout) findViewById(R.id.linear_text_icon);
		headImage = (ImageView) findViewById(R.id.list_head_image);
		headTitle = (TextView) findViewById(R.id.list_head_title);
		headIcon = (ImageView) findViewById(R.id.list_head_type_icon);
		mImageLayout = (FrameLayout) findViewById(R.id.head_image_layout);
		mTextLayout = (LinearLayout) findViewById(R.id.head_text_layout);
		topic_item_qishu = (TextView) findViewById(R.id.topic_item_qishu);
		mTextStyleTitle = (TextView) findViewById(R.id.head_title_text);
		mTextStyleAbstract = (TextView) findViewById(R.id.head_abstract_text);
		mTextStyleComments = (TextView) findViewById(R.id.head_comments_text);
		mTextStyleFlag = (ImageView) findViewById(R.id.head_text_flag);
		mClickLayout = (FrameLayout) findViewById(R.id.head_click_layout);	
		mCommentIcon = (ImageView) findViewById(R.id.list_comments_image);
		mImageIcon = (ImageView) findViewById(R.id.head_image_icon);
		mImageCount = (TextView) findViewById(R.id.head_image_count_text);
		mDivider = (View) findViewById(R.id.image_head_devider);
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(this.mContext);
		settingInfo = SettingObservable.getInstance().getData();
	}
	
	public void applyImageHeadTheme(){	
		if(themeSettingsHelper.isNightTheme()){					
			if(mImageIcon!=null){
				mImageIcon.setImageResource(R.drawable.night_photo_list_image_icon);
			}
			if(mCommentIcon!=null){
				mCommentIcon.setImageResource(R.drawable.night_list_item_comment_icon);
			}
			if(mDivider!=null){
				mDivider.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.night_list_divider_line));
			}
			if(mTextLayout!=null){					
				mTextLayout.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.night_list_header_selector));
			}
			if(headImage!=null){
				headImage.setImageResource(R.drawable.night_list_head_default_image);
			}			
		}else{			
			if(mImageIcon!=null){
				mImageIcon.setImageResource(R.drawable.photo_list_image_icon);
			}
			if(mCommentIcon!=null){
				mCommentIcon.setImageResource(R.drawable.list_item_comment_icon);
			}
			if(mDivider!=null){
				mDivider.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.list_divider_line));
			}
			if(mTextLayout!=null){				
				mTextLayout.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.list_header_selector));
			}
			if(headImage!=null){
				headImage.setImageResource(R.drawable.list_head_default_image);
			}
		}			
	}

	public void setHeadTitle(String title, String qishu) {
		headTitle.setTextSize(16);
		if (qishu != null && !qishu.equals("")) {
			headTitle.setText("第" + qishu + "期\t\t" + title);
			isShowIcon = false;
		} else {
			headTitle.setText(title);
			if (MobileUtil.getScreenWidthIntPx() > (headTitle.getWidth()
					+ MobileUtil.dpToPx(5) + headIcon.getWidth()
					+ mLinearLayout.getPaddingLeft() + mLinearLayout
						.getPaddingRight())){
				isShowIcon = true;
			}
			else{
				isShowIcon = false;
			}
		}  		
	}

	public void setHeadImage(Bitmap bm) {
		if (bm != null) {
			headImage.setImageBitmap(bm);
		}
	}

	public void setHeadFlag(String flag) {
		if (("0".equals(flag) || flag == null) || (!isShowIcon)) {
			headIcon.setVisibility(View.GONE);
		} else {
			headIcon.setVisibility(View.VISIBLE);			
			if(themeSettingsHelper.isNightTheme()){
				setNightFlagIcon(headIcon, flag);
			}else{
				setFlagIcon(headIcon, flag);
			}			
		}
	}

	public void setHeadClickListener(OnClickListener listener) {
		mClickLayout.setOnClickListener(listener);
	}

	public void setStyleMode(boolean ismode) {
		if (ismode) {
			mTextLayout.setVisibility(View.VISIBLE);
			mImageLayout.setVisibility(View.GONE);
		} else {
			mImageLayout.setVisibility(View.VISIBLE);
			mTextLayout.setVisibility(View.GONE);
		}

	}

	public void setTextMode(Item item) {
		if (item != null) {
			if (SpNewsHadRead.isNewsHadRead(item.getId())) {
				if(themeSettingsHelper.isNightTheme()){
					mTextStyleTitle.setTextColor(mContext.getResources().getColor(R.color.night_readed_news_title_color));
				}else{
					mTextStyleTitle.setTextColor(mContext.getResources().getColor(R.color.readed_news_title_color));
				}
			} else {
				if(themeSettingsHelper.isNightTheme()){
					mTextStyleTitle.setTextColor(mContext.getResources().getColor(R.color.night_list_title_color));
				}else{
					mTextStyleTitle.setTextColor(mContext.getResources().getColor(R.color.list_title_color));
				}				
			}
			String stract = null;
			if (item.getBstract() != null) {
				stract = item.getBstract().trim();
				if (stract.length() > 35) {
					stract = stract.substring(0, 35);
				}
			}
			stract = StringUtil.StringFilter(stract);
			String qishu = item.getQishu();
			if(qishu != null && !qishu.equals("")){
				topic_item_qishu.setText("第" + qishu + "期");
			}else{
				topic_item_qishu.setVisibility(View.GONE);
			}
			mTextStyleTitle.setTextSize(20);
			mTextStyleTitle.setText(item.getTitle());
			mTextStyleAbstract.setText(stract);
			mTextStyleComments.setText(item.getCommentNum());
			if (item.getArticletype().equals("1")) {
				mImageIcon.setVisibility(View.VISIBLE);
				mImageCount.setVisibility(View.VISIBLE);
			} else {
				mImageIcon.setVisibility(View.GONE);
				mImageCount.setVisibility(View.GONE);
			}
			mImageCount.setText(item.getImageCount());
			String flag = item.getFlag();
			if ("0".equals(flag) || flag == null || (qishu != null && !qishu.equals(""))) {
				mTextStyleFlag.setVisibility(View.GONE);
			} else {
				mTextStyleFlag.setVisibility(View.VISIBLE);				
				if(themeSettingsHelper.isNightTheme()){
					setNightFlagIcon(mTextStyleFlag, flag);
				}else{
					setFlagIcon(mTextStyleFlag, flag);
				}				
				
			}
		}
	}	
	
	private void setFlagIcon(ImageView imgView,String flag){			
		if ("1".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_scoop_icon);
		} else if ("2".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_tote_icon);
		} else if ("3".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_video_icon);
		} else if ("4".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_special_icon);
		} else if ("5".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_flash_icon);
		} else if ("6".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_live_icon);
		} else if ("7".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_redian);
		}
	}
	
	private void setNightFlagIcon(ImageView imgView,String flag){			
		if ("1".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_scoop_icon);
		} else if ("2".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_tote_icon);
		} else if ("3".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_video_icon);
		} else if ("4".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_special_icon);
		} else if ("5".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_flash_icon);
		} else if ("6".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_live_icon);
		} else if ("7".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_redian);
		}
	}
	
}
