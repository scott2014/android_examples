//package com.tencent.news.ui.view;
//
//import android.content.Context;
//import android.content.res.TypedArray;
//import android.util.AttributeSet;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.widget.FrameLayout;
//import android.widget.ImageView;
//
//import com.tencent.news.R;
//
//public class ShareButton extends FrameLayout {
//
//	public static final int LOGOUT = 0;
//	public static final int NOTSHARE = 1;
//	public static final int SHARE = 2;
//
//	Context context;
//
//	int shareButtonicon;
//	int shareButtonState;
//
//	public int getShareButtonState() {
//		return shareButtonState;
//	}
//
//	public void setShareButtonState(int shareButtonState) {
//		this.shareButtonState = shareButtonState;
//		switch (shareButtonState) {
//		case LOGOUT:
//			share_button.setSelected(false);
//			share_checked.setVisibility(View.GONE);
//			break;
//		case NOTSHARE:
//			share_button.setSelected(true);
//			share_checked.setVisibility(View.GONE);
//			break;
//		case SHARE:
//			share_button.setSelected(true);
//			share_checked.setVisibility(View.VISIBLE);
//			break;
//		}
//	}
//
//	ImageView share_checked;
//	ImageView share_button;
//
//	public ShareButton(Context context, AttributeSet attrs) {
//		this(context, attrs, 0);
//	}
//
//	public ShareButton(Context context) {
//		this(context, null);
//	}
//
//	public ShareButton(Context context, AttributeSet attrs, int defStyle) {
//		super(context, attrs, defStyle);
//		this.context = context;
//
//		TypedArray arrayType = context.obtainStyledAttributes(attrs, com.tencent.news.R.styleable.ShareButton);
//		shareButtonicon = arrayType.getResourceId(R.styleable.ShareButton_image_icon, R.drawable.btn_share_tencent_selector);
//		shareButtonState = arrayType.getInt(R.styleable.ShareButton_state, LOGOUT);
//		arrayType.recycle();
//
//		initView();
//	}
//
//	private void initView() {
//		LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//		inflater.inflate(R.layout.view_share_button, this, true);
//		share_checked = (ImageView) findViewById(R.id.share_checked);
//		share_button = (ImageView) findViewById(R.id.share_button);
//		share_button.setImageResource(shareButtonicon);
//		setShareButtonState(shareButtonState);
//	}
//
//	public boolean isChecked() {
//		return this.getShareButtonState() == SHARE;
//	}
//}
