package com.tencent.news.ui;

import java.util.List;


import android.os.Bundle;
import android.widget.AbsListView;

import com.tencent.news.R;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.ui.adapter.ChannelListAdapter;
import com.tencent.news.ui.view.PullImageHeadView;
import com.tencent.news.ui.view.PullToRefreshFrameLayout;
import com.tencent.news.ui.view.WebViewForCell;
import com.tencent.omg.webdev.WebDev;

public class ImportantNewsActivity extends AbsChannelActivityNew implements WebViewForCell.JsInterface{

	@Override
	protected void InitContainerView(Bundle savedInstanceState){
		setContentView(R.layout.important_news_layout);
		mFramelayout = (PullToRefreshFrameLayout)findViewById(R.id.important_list_content);
		mListView = mFramelayout.getPullToRefreshListView();
	}

	@Override
	protected String getListviewTimeTag() {
		return mChannel;
	}

	@Override
	protected void addHeadView() {		
		mHeadView = new PullImageHeadView(this);		
		mListView.addHeaderView(mHeadView);
	}

	@Override
	protected void InitAdapter(){
		mAdapter = new ChannelListAdapter(this, mListView);
		mListView.setAdapter(mAdapter);
	}

	@Override
	protected synchronized void setHeadData(List<Item> list) {
		if(list != null && list.size()>0){
			mHeadItem = list.remove(0);
		}
	}

	@Override
	protected Class<? extends Object> getClassName(Item item) {
		if(item != null){
			if(item.getArticletype().equals("1")){
				return ImageDetailActivity.class;
			}else if(item.getArticletype().equals("5")){
				return WebDetailActivity.class;
			}else if(item.getArticletype().equals("100")){
				return SpecialListActivity.class;
			}else if(item.getArticletype().equals("7")){
				return ImgTxtLiveActivity.class;
			}
		}
		return NewsDetailActivity.class;
	}

	@Override
	protected String getChlidTitle() {
		return "腾讯新闻";
	}

	@Override
	protected boolean isRegisterNetTips() {
		return false;
	}

	@Override
	protected boolean isNeedHeadView() {
		return true;
	}

	@Override
	protected void createCellView() {
		if(mCellWebView == null) {
			mCellWebView = new WebViewForCell(this);
			mCellWebView.setVerticalScrollBarEnabled(false);
			mCellWebView.init(mChannel, Integer.parseInt(mCellItem.getHeight()));
			mCellWebView.initJsInterface(this);
			AbsListView.LayoutParams lp = new AbsListView.LayoutParams(
			AbsListView.LayoutParams.FILL_PARENT, AbsListView.LayoutParams.WRAP_CONTENT);
			mCellWebView.setLayoutParams(lp);
		}
	}

	@Override
	protected void removeCellView() {
		
	}

	@Override
	public void onWebCellReady() {
		runOnUiThread(new Runnable() {
			public void run() {
				if (mCellWebView.isFirstLoad()) {
					mAdapter.insertData(mCellItem, 0);
					mAdapter.notifyDataSetChanged();
				}
				mCellWebView.showWebCell();
			}
		});
	}

	@Override
	public void onWebCellError() {
	}

	@Override
	public void onWebCellUIChanged() {
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}
}
