package com.tencent.news.ui.adapter;

import java.util.List;

import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.tencent.news.R;
import com.tencent.news.command.GetImageRequest;
import com.tencent.news.model.pojo.ImageResult;
import com.tencent.news.system.Application;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.TouchImageView;
import com.tencent.news.ui.view.ViewPagerEx2;
import com.tencent.news.utils.DefaulImageUtil;

public class ImageDetailViewPagerAdapter extends PagerAdapter {
	
	public interface DisplayListener {
		void onShowImage(int index, Bundle dataBundle, TouchImageView view);
	}
	
	private List<Bundle> mImageList;
	private DisplayListener mDisplayListener = null;
	
	public void setData(List<Bundle>listData) {
		mImageList = listData;
	}
	
	public void setDisplayListener(DisplayListener mDownloadListener) {
		this.mDisplayListener = mDownloadListener;
	}
	
	@Override
	public int getCount() {
		return mImageList == null ? 1 : mImageList.size();
	}

	@Override
	public boolean isViewFromObject(View arg0, Object arg1) {
		boolean ret = arg0.equals(arg1);
		return ret;
	}

	public int getItemPosition(Object object) {
		return POSITION_NONE;
	}
	
    @Override
    public void setPrimaryItem(ViewGroup container, int position, Object object) {
        super.setPrimaryItem(container, position, object);
        TouchImageView imageView = null;
        if (object instanceof FrameLayout) {
	        FrameLayout rootLayout = (FrameLayout)object;
       	 	Object lastView = ((ViewPagerEx2)container).getCurrentView();
       	 
	        if (rootLayout != null && rootLayout.getChildCount() > 0 && rootLayout.getChildAt(0) instanceof TouchImageView) {
	        	imageView = (TouchImageView)rootLayout.getChildAt(0);
		        ((ViewPagerEx2)container).setCurrentView(imageView);
	        }
	        
	        // 重置上一个TouchImageView
			if (lastView != null && lastView instanceof TouchImageView && !lastView.equals(imageView)) {
				((TouchImageView) lastView).reset();
			}
        }

    	if (mDisplayListener != null && mImageList != null 
    			&& position >= 0 && position < mImageList.size()
    			&& imageView != null) {
    		mDisplayListener.onShowImage(position, mImageList.get(position), imageView);
    	}
    }
    
    @Override
    public Object instantiateItem(ViewGroup collection, int position){
		View view = LayoutInflater.from(Application.getInstance()).inflate(R.layout.iamge_detail_view_item, null, false);
		view.setTag(position);
		TouchImageView mZoomView = (TouchImageView) view.findViewById(R.id.gallerySubImage);
		mZoomView.setImageBitmap(DefaulImageUtil.getDefaultPhotoDetailImage());
    	collection.addView(view, 0);

		makeRequestTask(position, mZoomView);
    	return view;
    }
    
    @Override
    public void destroyItem(ViewGroup collection, int position, Object view){
        collection.removeView((View) view);
    }

	private void makeRequestTask(int nIndex, TouchImageView view) {
		if (mImageList != null && nIndex >= 0 && nIndex < mImageList.size()) {
			view.setTag(nIndex);
			Bundle bundle = mImageList.get(nIndex);
			String imageUrl = bundle.getString("image");
			
			GetImageRequest request = new GetImageRequest();
			request.setGzip(false);
			request.setTag(nIndex);
			request.setUrl(imageUrl);
			ImageResult result = TaskManager.startSmallImageTask(request, view);
			if (result != null && result.isResultOK() && result.getRetBitmap() != null) {
				view.setImageBitmap(result.getRetBitmap());
			} else {
				view.setImageBitmap(DefaulImageUtil.getDefaultPhotoDetailImage());
			}
		}
	}
}
