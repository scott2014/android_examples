package com.tencent.news.ui;

import java.util.ArrayList;

import java.util.List;
import android.annotation.SuppressLint;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.ClipboardManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.cache.ChatMsgCache;
import com.tencent.news.cache.NewsMsgGroupCache;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.model.pojo.ChatMsg;
import com.tencent.news.model.pojo.MsgRet;
import com.tencent.news.model.pojo.NewsMsgList;
import com.tencent.news.system.Application;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.adapter.ChatListAdapter;
import com.tencent.news.ui.view.ChatListView;
import com.tencent.news.ui.view.ChatListView.OnLoadDateListener;
import com.tencent.news.ui.view.InputMethodEventView.InputMethodChangeLinstener;
import com.tencent.news.ui.view.InputMethodEventView;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.news.ui.view.TitleBar;
import com.tencent.news.utils.SLog;

/**
 * @author haiyandu
 * @since 2013-6-25
 */
@SuppressLint("HandlerLeak")
public class ChatActivity extends BaseActivity {
    private final static String TAG = ChatActivity.class.getSimpleName();
    private final static long DELAY_TIME = 20 * 1000L;
    private static final int GET_NEWS_MSG_FROM_CACHE = 0x100;
    private static final int GET_NEWS_MSG_BACK = 0x200;
    private static final int GET_NEWS_MSG_BACK_INCREMENTAL = 0x400;
    private TitleBar mTitleBar;
    private RelativeLayout mLoading;
    private LinearLayout mChatComment;
    private ChatListView mChatListView;
    private ChatListAdapter mAdapter;
    private EditText mEditText;
    private Button mSendBtn;
    private View mTouch;
    private View mMask;
    private InputMethodEventView mKeyboardEvent;
    
    // 当上一个网络请求还未结束时不能启动下一个轮训请求
    private boolean isLoading = false;

    private String mUinString;
    private String mNickString;
    private int mNewsCount;

    private NewsMsgList mChatMsgList;
    private ChatMsgCache mChatMsgCache;
    
    // 登陆用户的账号信息
    private String mLoginUserUin;
    private String mLoginUserHeadUrl; // 登录用户的头像
    
    private ChatMsg mChatMsgToSend;
    
    // 服务器返回的最后一条数据，用于增量请求新消息时取时间点
    private ChatMsg mLastMsg = null;
    
    // 消息列表中最后一条有效消息，包括成功发送的消息，用于更新外面的组列表
    private ChatMsg mLastValueableMsg = null;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chat_activity_layout);
        getIntentData(getIntent());
        initView();
        initListener();
        
        getUserInfo();
        
        LoadChatMsgData();
    }
    
    private void getIntentData(Intent intent) {
        if (intent != null) {
            mUinString = intent.getStringExtra("uin");
            mNickString = intent.getStringExtra("nick");
            mNewsCount = intent.getIntExtra("newCount", 0);
            
            if (mNewsCount > 0) {
                Intent i = new Intent();
                i.setAction(Constants.UPDATE_MAIL_AND_AT_COUNT);
                i.putExtra("mailCount", mNewsCount);
                i.putExtra("action", "readed");
                sendBroadcast(i);
            }
        }
    }

    private void initView() {
        mKeyboardEvent = (InputMethodEventView) findViewById(R.id.chat_keyboardevent);
        mTouch = (View) findViewById(R.id.view_touch);
        mMask = (View) findViewById(R.id.mask_view);
        mLoading = (RelativeLayout) findViewById(R.id.chat_loading);
        mChatComment = (LinearLayout) findViewById(R.id.chat_comment);
        mSendBtn = (Button) findViewById(R.id.chat_btn_send);
        mEditText = (EditText) findViewById(R.id.chat_edit_input);
        mChatListView = (ChatListView) findViewById(R.id.chat_list_view);
        mTitleBar = (TitleBar) findViewById(R.id.chat_title_bar);
        mTitleBar.ShowSinaBar(R.string.mycomment_title);
        mTitleBar.ShowSinaBar(mNickString);
        mTitleBar.setBackName("返回");
        mSendBtn.setEnabled(false);
        mAdapter = new ChatListAdapter(this, mUinString, mChatListView);
        mChatListView.setAdapter(mAdapter);
    }
    
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            
            if (msg != null) {
                switch (msg.what) {
                case GET_NEWS_MSG_FROM_CACHE:
            		mAdapter.addDataList(mChatMsgList.getData());
            		mAdapter.notifyDataSetChanged();
            		mChatListView.setSelection(mAdapter.getCount());
            		mLoading.setVisibility(View.GONE);
                	break;
                case GET_NEWS_MSG_BACK:
                    getNewsMsgBack();
                    break;
                case GET_NEWS_MSG_BACK_INCREMENTAL:
                    getNewsMsgBackIncremental();
                	break;
                default:
                    break;
                }
            }
        }
    };

    @Override
    protected void onResume() {
        // TODO Auto-generated method stub
        super.onResume();
        
        if (isLoading == false) {
            // 马上拉取最新数据
            mHandler.sendEmptyMessage(GET_NEWS_MSG_BACK);
        }
    }

    @Override
    protected void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();
        
        if (mHandler != null) {
            mHandler.removeMessages(GET_NEWS_MSG_BACK);
            mHandler.removeMessages(GET_NEWS_MSG_BACK_INCREMENTAL);
        }
    }

    @Override
    protected void onPause() {
        // TODO Auto-generated method stub
        super.onPause();
        
        if (mHandler != null) {
        	mHandler.removeMessages(GET_NEWS_MSG_BACK);
            mHandler.removeMessages(GET_NEWS_MSG_BACK_INCREMENTAL);
        }
    }

    // 首先从缓存取，然后从网络刷
    private void LoadChatMsgData() {
    	TaskManager.startRunnableRequest(new Runnable() {
            @Override
            public void run() {
            	loadChatMsgCache();
            	if (mChatMsgList != null && mChatMsgList.getData() != null &&
            	        mChatMsgList.getData().size() > 0) {
            	    mHandler.sendEmptyMessage(GET_NEWS_MSG_FROM_CACHE);
            	}
            	
            	getNewsMsgBack();
            }
    	});
    }
    
    public void getUserInfo() {
        SettingInfo settingData = SettingObservable.getInstance().getData();
        if (settingData != null && settingData.getUserInfo() != null) {
            mLoginUserHeadUrl = settingData.getUserInfo().getHeadurl();
            mLoginUserUin = settingData.getUserInfo().getUin();
        } else {
            mLoginUserHeadUrl = null;
            mLoginUserUin = null;
        }
    }
    
    private void loadChatMsgCache() {
        
        getUserInfo();
        
        if (mLoginUserUin != null) {
            mChatMsgCache = new ChatMsgCache(mUinString, mLoginUserUin);
        }
        
        if (mChatMsgCache != null) {
            mChatMsgList = mChatMsgCache.getCacheData();
        } else {
            mChatMsgList = null;
        }
    }
    
    private void getNewsMsgBack() {
    	if (isLoading == false) {
    		isLoading = true;
    		Log.i("bush", "get news msg back request start ...");
    		HttpDataRequest request = TencentNews.getInstance().getSubNewsMsgListBack(mUinString);
    		TaskManager.startHttpDataRequset(request, this);
    	}
    }

    private void getNewsMsgBackIncremental() {
    	if (isLoading == false && mLastMsg != null) {
    		isLoading = true;
    		Log.i("bush", "send increment request start ...");
    		HttpDataRequest request = TencentNews.getInstance().getSubNewsMsgListBackIncremental(mUinString, mLastMsg.getTime());
            TaskManager.startHttpDataRequset(request, this);
    	}
    }
    
    private void getNewsMsgFront() {
    	String oldestTime = getOldestMsgTime();
    	Log.i("bush", "getNewsMsgFront : isLoading = " + isLoading + " oldestTime = " + oldestTime);
    	if (isLoading == false && oldestTime != null) {
    		isLoading = true;
    		Log.i("bush", "get news msg front request start ...");
    		HttpDataRequest request = TencentNews.getInstance().getSubNewsMsgListFront(mUinString, oldestTime);
            TaskManager.startHttpDataRequset(request, this);
    	}
    }

    private String getOldestMsgTime() {
    	List<ChatMsg> msgList = mAdapter.getDataList();
    	if (msgList != null && msgList.size() > 0) {
    		return msgList.get(0).getTime();
    	} else {
    	    return "" + System.currentTimeMillis() / 1000;
    	}
    }
    
    private void initListener() {
        mTitleBar.setBackClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
            	refreshChatMsgCache();
                quitActivity();
            }

        });

        mChatListView.setOnLoadDateListener(new OnLoadDateListener() {
            @Override
            public void OnLoadOldDate() {
                // TODO Auto-generated method stub
                getNewsMsgFront();
            }
        });
        
        mSendBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
            	CreateMsgBodyAndSend();
            }

        });

        mEditText.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                mChatListView.setSelection(mAdapter.getCount());
            }
        });
        
        mEditText.setOnLongClickListener(new View.OnLongClickListener() {
            
            @Override
            public boolean onLongClick(View v) {
                // TODO Auto-generated method stub
                
                return false;
            }
        });

        mEditText.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (mEditText.getText().toString().length() <= 0) {
                    mSendBtn.setEnabled(false);
                } else {
                    mSendBtn.setEnabled(true);
                }
            }
        });

        mTouch.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Application.getInstance().hideSoftInputFromWindow(mEditText.getWindowToken());
            }

        });

        mKeyboardEvent.setmInputMethodChangeLinstener(new InputMethodChangeLinstener() {

            @Override
            public void onInputMethodOpen() {
                mTouch.setVisibility(View.VISIBLE);
            }

            @Override
            public void onInputMethodClose() {
                mTouch.setVisibility(View.GONE);
            }
        });

    }
    
    private void createDialog() {
        Builder builder = new Builder(this);
        builder.setTitle("我的消息");
        builder.setItems(R.array.chat_msg_send_actions, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                case 0:
                    ClipboardManager clipBorad =(ClipboardManager) ChatActivity.this.getSystemService(Context.CLIPBOARD_SERVICE);
                    mEditText.setText(clipBorad.getText());
                    break;
                default:
                    break;
                }
            }
        });
        builder.create().show();
   }

    private ChatMsg createMsgBody() {
        ChatMsg chatMsg = null;
        
        String inputMsg = mEditText.getText().toString().trim();
        
        if (inputMsg.length() > 0) {
            chatMsg = new ChatMsg();
            chatMsg.setMsg(inputMsg);
            chatMsg.setTime("" + System.currentTimeMillis() / 1000);
            chatMsg.setIsvip("0");
            chatMsg.setSenderHead(mLoginUserHeadUrl);
            
            mChatMsgToSend = chatMsg;
        } else {
            Toast.makeText(this, "消息不能为空！", Toast.LENGTH_SHORT).show();
        }
        
        return chatMsg;
    }
    
    private void CreateMsgBodyAndSend() {
        
        ChatMsg chatMsg = createMsgBody();
        
        if (chatMsg != null) {
            mAdapter.getDataList().add(chatMsg);
            mAdapter.notifyDataSetChanged();
            mEditText.setText("");
            
            sendNewsMsg(); // 从网络发送
        } 
    }
    
    private void clearFailedMsg() {
    	List<ChatMsg> failedMsgList = mAdapter.getFailedMsgList();
    	int j = mAdapter.getDataList().size() - 1;
    	
    	while (failedMsgList.size() > 0) {
    		ChatMsg failedMsg = failedMsgList.remove(failedMsgList.size() - 1);
			for ( ; j >= 0; j--) {
				if (mAdapter.getDataList().get(j).getTime().equals(failedMsg.getTime())) {
					mAdapter.getDataList().remove(j);
					j--;
					break;
				}
			}
    	}
    }
    
    private void sendNewsMsg() {
        Log.i("bush", "send message request start ...");
        HttpDataRequest request = TencentNews.getInstance().addSubNewsMsg(mUinString, mChatMsgToSend.getMsg());
        TaskManager.startHttpDataRequset(request, ChatActivity.this);
    }

    private void sendUpdateMsgBroadCast(String uin, String content) {
        Intent i = new Intent();
        i.setAction(Constants.REFRESH_MSG_LIST);
        i.putExtra(Constants.NEWS_CLICK_ITEM_UIN, uin);
        i.putExtra("content", content);
        i.putExtra("time", "" + System.currentTimeMillis() / 1000);
        sendBroadcast(i);
    }

    private void refreshChatMsgCache() {
    	if (mChatMsgCache == null && mUinString != null) {
    		mChatMsgCache = new ChatMsgCache(mUinString, mLoginUserUin);
    	}
    	
    	if (mChatMsgList == null) {
    		mChatMsgList = new NewsMsgList();
    	}
    	
    	if (mAdapter.getDataList() != null) {
    		clearFailedMsg();
    		mChatMsgList.setData(mAdapter.getDataList());
    	}
    	
    	mChatMsgCache.setCacheData(mChatMsgList);
    }
    
    private void clearAllFakeMsg() {
        List<ChatMsg> msgList = mAdapter.getDataList();
        for (int i = msgList.size() - 1; i >= 0; i--) {
            if (msgList.get(i).equals(mLastMsg) == false) {
                mAdapter.getDataList().remove(i);
            } else {
                break;
            }
        }
    }
    
    @Override
    public void onHttpRecvOK(HttpTag tag, Object result) {
        NewsMsgList msg = null;
        
        isLoading = false;
        
        if (tag.equals(HttpTag.SUB_NEWS_MSGLIST_BACK)) {
            Log.i("bush", "SUB_NEWS_MSGLIST_BACK");
            msg = (NewsMsgList) result;
            
            if (msg != null && "0".equals(msg.getRet()) && msg.getData() != null &&
                    msg.getData().size() > 0) {
                Log.i("bush", "SUB_NEWS_MSGLIST_BACK : data count " + msg.getData().size());
                mAdapter.addDataList(msg.getData());
                mAdapter.notifyDataSetChanged();
                
                mLastMsg = msg.getData().get(msg.getData().size() - 1);
                mChatListView.setHeadViewAddMore(!("0".equals(msg.getAnymore())));
                
                mHandler.sendEmptyMessageDelayed(GET_NEWS_MSG_BACK_INCREMENTAL, DELAY_TIME);
            } else {
                Log.i("bush", "SUB_NEWS_MSGLIST_BACK : has no data");
                mChatListView.setHeadViewAddMore(false);
            }
            
            mLoading.setVisibility(View.GONE);
            
        } else if (tag.equals(HttpTag.SUB_NEWS_MSGLIST_BACK_INCREMENTAL)) {
            Log.i("bush", "SUB_NEWS_MSGLIST_BACK_INCREMENTAL");
            
        	msg = (NewsMsgList) result;
        	
        	if (msg != null && "0".equals(msg.getRet()) && msg.getData() != null
        	        && msg.getData().size() > 0) {
        	    
        	    Log.i("bush", "SUB_NEWS_MSGLIST_BACK_INCREMENTAL : data count " + msg.getData().size());
        	    
        	    clearAllFakeMsg(); // 删除所有假数据
        	    
        		mAdapter.addMoreDataList(msg.getData());
        		
        		mLastMsg = msg.getData().get(msg.getData().size() - 1);
        		
        		mAdapter.notifyDataSetChanged();
        		
        	} else {
        	    Log.i("bush", "SUB_NEWS_MSGLIST_BACK_INCREMENTAL : has no data");
        	}
        	
        	mHandler.sendEmptyMessageDelayed(GET_NEWS_MSG_BACK_INCREMENTAL, DELAY_TIME);
        	
        } else if (tag.equals(HttpTag.SUB_NEWS_MSGLIST_FRONT)) {
            Log.i("bush", "SUB_NEWS_MSGLIST_FRONT");
            msg = (NewsMsgList) result;
            if (msg != null && "0".equals(msg.getRet()) && msg.getData() != null) {
                Log.i("bush", "SUB_NEWS_MSGLIST_FRONT : data count " + msg.getData().size());
                mAdapter.addDataListBefore(msg.getData());
                mAdapter.notifyDataSetChanged();
                mChatListView.setSelection(msg.getData().size() + 1);
                mChatListView.setHeadViewAddMore(!("0".equals(msg.getAnymore())));
            } else {
                Log.i("bush", "SUB_NEWS_MSGLIST_FRONT : has no data");
                mChatListView.setHeadViewAddMore(false);
            }
            
        } else if (tag.equals(HttpTag.ADD_SUBNEWS_MSG)) {
            Log.i("bush", "ADD_SUBNEWS_MSG success with ret 0");
            MsgRet ret = (MsgRet) result;
            if (ret != null && "0".equals(ret.getRet())) {
                if (mChatMsgToSend != null) {
                    sendUpdateMsgBroadCast(mUinString, mChatMsgToSend.getMsg()); // 发送广播更新外面列表
                    mChatMsgToSend = null;
                }
            } else {
                Log.i("bush", "ADD_SUBNEWS_MSG success without ret 0");
                
                TipsToast.getInstance().showTipsError("消息发送失败!");
                mAdapter.addFailedMsg(mChatMsgToSend);
            }
        }
    }

    @Override
    public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {
    	
        isLoading = false;
        
        if (tag.equals(HttpTag.SUB_NEWS_MSGLIST_BACK)) {
            Log.i("bush", "SUB_NEWS_MSGLIST_BACK error");
            mChatListView.setHeadViewAddMore(false);
        } else if (tag.equals(HttpTag.SUB_NEWS_MSGLIST_BACK_INCREMENTAL)) {
            Log.i("bush", "SUB_NEWS_MSGLIST_BACK_INCREMENTAL error");
            
        }
        else if (tag.equals(HttpTag.SUB_NEWS_MSGLIST_FRONT)) {
            Log.i("bush", "SUB_NEWS_MSGLIST_FRONT error");
            mChatListView.setHeadViewAddMore(false);
            
        } else if (tag.equals(HttpTag.ADD_SUBNEWS_MSG)) {
            Log.i("bush", "ADD_SUBNEWS_MSG");
            mAdapter.addFailedMsg(mChatMsgToSend);
        }
        
        mLoading.setVisibility(View.GONE);
    }

    @Override
    public void onHttpRecvCancelled(HttpTag tag) {
    	
        if (tag.equals(HttpTag.SUB_NEWS_MSGLIST_BACK)) {
        	isLoading = false;
        	
        } else if (tag.equals(HttpTag.SUB_NEWS_MSGLIST_FRONT)) {
        	
        } else if (tag.equals(HttpTag.ADD_SUBNEWS_MSG)) {

        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
        	refreshChatMsgCache();
            quitActivity();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_MENU) {
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
    
    private void mySetBackground(View view, int id) {
        int bottom = view.getPaddingBottom();
        int top = view.getPaddingTop();
        int left = view.getPaddingLeft();
        int right = view.getPaddingRight();

        view.setBackgroundDrawable(getResources().getDrawable(id));

        view.setPadding(left, top, right, bottom);
    }
    
    @Override
    public void applyTheme() {
        mTitleBar.applyTitleBarTheme(this);
        themeSettingsHelper.setViewBackgroudColor(this, mChatListView, R.color.timeline_home_bg_color);
        themeSettingsHelper.setTextViewColor(this, mEditText, R.color.writing_comment_hit_color);
        
        ColorStateList csl = null;
        
        if (themeSettingsHelper.isNightTheme()) {
            mySetBackground(mChatComment, R.drawable.comment_floor_black);
            mySetBackground(mEditText, R.drawable.night_comment_box);
            mSendBtn.setBackgroundResource(R.drawable.btn_send_black_selector);
            csl = (ColorStateList) getResources().getColorStateList(R.drawable.btn_send_black_color_selector);
            mSendBtn.setTextColor(csl);
            
            mMask.setBackgroundResource(R.color.night_mask_page_color);
        } else {
            mySetBackground(mChatComment, R.drawable.comment_floor);
            mySetBackground(mEditText, R.drawable.comment_box);
            mSendBtn.setBackgroundResource(R.drawable.btn_new_send_selector);
            csl = (ColorStateList) getResources().getColorStateList(R.drawable.btn_send_color_selector);
            mSendBtn.setTextColor(csl);
            
            mMask.setBackgroundResource(R.color.mask_page_color);
        }
    }
}
