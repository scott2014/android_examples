package com.tencent.news.ui.view;

import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.tencent.news.R;

/**
 * 应用推荐tab-bar
 * @author vincesun
 */

public class AppNavigationBar extends LinearLayout implements View.OnClickListener {

	private Context mContext;
	private AppNavigationListener navigateListener;
	private View viewSelected = null;
	private LinearLayout mLinearLayout;
	private Button mButton_h;
	private Button mButton_q;
	private static int mSelected = 0;
	
	public AppNavigationBar(Context context) {
		super(context);
		init(context);
	}

	public AppNavigationBar(Context context, AttributeSet attrs) {
		super(context, attrs);
		init(context);
	}

	@Override
	public void onClick(View v) {
		if(v == null) return;
		boolean refresh = viewSelected.equals(v);
		viewSelected.setSelected(false);
		v.setSelected(true);
		viewSelected = v;
		if(navigateListener != null){
			int nIndex = (Integer)viewSelected.getTag();
			mSelected = nIndex;
			changeBtnColor(mSelected);
			navigateListener.onNavigationBarClick(nIndex);
		}
		
	}
	
	private void changeBtnColor(int index){
		if(index == 0){
			mButton_h.setTextColor(Color.rgb(7, 98, 167));
			mButton_q.setTextColor(Color.rgb(33, 33, 33));
		}else{
			mButton_h.setTextColor(Color.rgb(33, 33, 33));
			mButton_q.setTextColor(Color.rgb(7, 98, 167));
		}
	}
	
	private void init(Context context) {
		mContext = context;
		LayoutInflater.from(mContext).inflate(R.layout.layout_app_navigation_bar, this, true);
		mLinearLayout = (LinearLayout)findViewById(R.id.app_navigation_layout);
		mButton_h = (Button)findViewById(R.id.app_btn_h);
		mButton_q = (Button)findViewById(R.id.app_btn_q);
		
		for(int i = 0; i < mLinearLayout.getChildCount(); i++){
			View view = mLinearLayout.getChildAt(i);
			view.setTag(i);
			view.setOnClickListener(this);
			if(i == 0){
				viewSelected = view;
				viewSelected.setSelected(true);
			}
		}
			
	}
	
	public void setOnNavigationListener(AppNavigationListener listener){
		this.navigateListener = listener;
	}
	
	public interface AppNavigationListener{
		public void onNavigationBarClick(int nIndex);
	}

}
