package com.tencent.news.ui.view;

import java.util.Formatter;

import android.app.Service;
import android.content.Context;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.utils.SLog;

public class PlayerController extends LinearLayout {

	private static final String TAG = "PlayerController";
	private static final int STREAM_TYPE = AudioManager.STREAM_MUSIC;

	private MediaPlayerControl mPlayer;
	private Context mContext;
	private ProgressBar mProgress;
	private TextView mEndTime, mCurrentTime;
	private boolean mShowing;
	private boolean mDragging;
	private static final int FADE_OUT = 1;
	private static final int SHOW_PROGRESS = 2;
	private StringBuilder mFormatBuilder;
	private Formatter mFormatter;
	private ImageView mPauseButton;
	//private View.OnClickListener mBtnBackListener;
	//private ImageButton mBtnBack;
	private View mAnchorView;
	private static final int PLAYER_CONTROLLER_SHOW_TIME = 8000;// 控制栏在3秒钟之后消失
	private boolean isLive = false;
	private AudioManager mAudioManager;
	//private TextView mTitle;
	//private RelativeLayout mLayoutTitleBar;
	////private RelativeLayout mLayoutCenterArea;
	private LinearLayout mBottomLayout;
	//private TextView mLiveText;
	private  int winWidth;
    private boolean		mLoading=false;

	public PlayerController(Context context, View view, boolean isLiveStyle) {
		super(context);
		isLive = isLiveStyle;
		this.mContext = context;
		this.mAnchorView = view;
		mAudioManager = (AudioManager) mContext
				.getSystemService(Service.AUDIO_SERVICE);
		initControllerView(isLiveStyle);
	}

	public void setTitleBarVisible(boolean isVisible) {
		/*if (mLayoutTitleBar != null) {
			mLayoutTitleBar.setVisibility(isVisible == true ? ViewGroup.VISIBLE
					: ViewGroup.GONE);
		}*/
	}

	private void initControllerView(boolean isLiveStyle) {

		LayoutInflater inflate = (LayoutInflater) mContext
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		inflate.inflate(R.layout.media_controller, this, true);
		setBackgroundDrawable(mContext.getResources().getDrawable(
				R.color.transparent));

		ViewGroup parent = (ViewGroup) mAnchorView.getParent();
		parent.addView(this);
		setVisibility(ViewGroup.GONE);

		//mLayoutTitleBar = (RelativeLayout) findViewById(R.id.title_bar);
		//mBtnBack = (ImageButton) findViewById(R.id.btn_back);
		//mTitle = (TextView) findViewById(R.id.title);
		////mLayoutCenterArea = (RelativeLayout) findViewById(R.id.center_container);
		////mLayoutCenterArea.setOnTouchListener(centerAreaTouchListener);
		mBottomLayout = (LinearLayout) findViewById(R.id.bottom_container);
		//mLiveText = (TextView) findViewById(R.id.play_live_text);
		
		/*mLayoutTitleBar.setOnTouchListener(new OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
				show(true, PLAYER_CONTROLLER_SHOW_TIME);
				return true;
			}
			
		});*/

		mBottomLayout.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
				show(true, PLAYER_CONTROLLER_SHOW_TIME);
				return true;
			}

		});
		
		mPauseButton = (ImageView) findViewById(R.id.pause);
		if (mPauseButton != null) {
			mPauseButton.requestFocus();
			mPauseButton.setOnClickListener(mPauseListener);
		}
	}

	private OnTouchListener centerAreaTouchListener = new OnTouchListener() {
		@Override
		public boolean onTouch(View v, MotionEvent event) {
			if (event.getAction() == MotionEvent.ACTION_UP && mPlayer != null
					&& mPlayer.isPrepared()) {
				if (mShowing) {
					hide();
				} else {
					show(true, PLAYER_CONTROLLER_SHOW_TIME);
				}
			}

			return true;
		}
	};

	public void show() {
		show(true, PLAYER_CONTROLLER_SHOW_TIME);
	}

	public void show(boolean auto, int timeout) {
		if(mLoading==true){
			return;
		}

    	//if(mAnchorView != null && winWidth != mAnchorView.getWidth()){
    		//hide();
    	//}
    	winWidth = mAnchorView.getWidth();

		mShowing = true;
		setVisibility(ViewGroup.VISIBLE);
		updatePausePlay();
		
		if (mPlayer != null) {
			mHandler.sendEmptyMessage(SHOW_PROGRESS);
			Message msg = mHandler.obtainMessage(FADE_OUT);
			if (timeout != 0) {
				mHandler.removeMessages(FADE_OUT);
				mHandler.sendMessageDelayed(msg, timeout);
			}
		}

	}

	public void hide() {
		if (mShowing) {
			try {
				mHandler.removeMessages(SHOW_PROGRESS);
				setVisibility(ViewGroup.GONE);

			} catch (IllegalArgumentException ex) {
				SLog.i("Controller Pannel", ex.toString());
			}
			mShowing = false;
		}

	};


	private View.OnClickListener mPauseListener = new View.OnClickListener() {
		public void onClick(View v) {
			doPauseResume();
			show(true, PLAYER_CONTROLLER_SHOW_TIME);
		}
	};

	private void doPauseResume() {
		if (mPlayer.isPlaying()) {
			// mManuelPause=true;
			mPlayer.pause();

		} else {
			// mManuelPause=false;
			mPlayer.start();
		}
		updatePausePlay();
	}

	public void updatePausePlay() {

		ImageView button = (ImageView) findViewById(R.id.pause);
		if (button == null)
			return;

		if (mPlayer.isPlaying()) {
			button.setImageResource(R.drawable.ic_media_pause);
		} else {
			button.setImageResource(R.drawable.ic_media_play);
		}

	}

	private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			int pos;
			switch (msg.what) {
			case FADE_OUT:
				hide();
				break;
			case SHOW_PROGRESS:
				// QQLiveLog.i(TAG, "show_progress: mShowing" + mShowing);
				pos = setProgress();
				if (!mDragging && mShowing && mPlayer.isPlaying()) {
					msg = obtainMessage(SHOW_PROGRESS);
					sendMessageDelayed(msg, 1000 - (pos % 1000));
				}
				break;
			}
		}
	};

	private int setProgress() {
		if (mPlayer == null || mDragging) {
			return 0;
		}
		int position = mPlayer.getCurrentPosition();
		int duration = mPlayer.getDuration();
		if (mProgress != null) {
			if (duration > 0) {
				// use long to avoid overflow
				long pos = 1000L * position / duration;
				mProgress.setProgress((int) pos);
			}
			int percent;

			percent = mPlayer.getBufferPercentage();

			mProgress.setSecondaryProgress(percent * 10);
		}

		if (mEndTime != null) {
			mEndTime.setText(stringForTime(duration));
		}
		if (mCurrentTime != null) {
			mCurrentTime.setText(stringForTime(position));
		}
		return position;
	}

	private String stringForTime(int timeMs) {
		int totalSeconds = timeMs / 1000;

		int seconds = totalSeconds % 60;
		int minutes = (totalSeconds / 60) % 60;
		int hours = totalSeconds / 3600;

		mFormatBuilder.setLength(0);
		if (hours > 0) {
			return mFormatter.format("%d:%02d:%02d", hours, minutes, seconds)
					.toString();
		} else {
			return mFormatter.format("%02d:%02d", minutes, seconds).toString();
		}
	}

	public void releaseResource() {

	}

	public void setMediaPlayer(MediaPlayerControl player) {
		this.mPlayer = player;
	}

	public boolean isShowing() {
		return mShowing;
	}
	
	public void setLoadingState(boolean loadingState){
		mLoading=loadingState;
	}

	public interface MediaPlayerControl {
		void start();

		void pause();

		int getDuration();

		int getCurrentPosition();

		void seekTo(int pos);

		boolean isPlaying();

		int getBufferPercentage();

		int getCachePercentage(); // using sd card as cache

		boolean isPrepared();
	}

	/*public void setBtnBackListener(OnClickListener listener) {
		mBtnBackListener = listener;
		if (mBtnBack != null) {
			mBtnBack.setOnClickListener(mBtnBackListener);
		}
	}*/

	/**
	 * 音量控制
	 */
	OnSeekBarChangeListener mVolumeChangeListener = new SeekBar.OnSeekBarChangeListener() {
		@Override
		public void onProgressChanged(SeekBar seekBar, int progress,
				boolean fromUser) {
			if (fromUser) {
				mAudioManager.setStreamVolume(STREAM_TYPE, progress,
						AudioManager.FLAG_PLAY_SOUND);
			}
		}

		@Override
		public void onStartTrackingTouch(SeekBar seekBar) {
			show(true, 3600000);
		}

		@Override
		public void onStopTrackingTouch(SeekBar seekBar) {
			show(true, PLAYER_CONTROLLER_SHOW_TIME);
		}
	};

	/*public void setTitle(String title) {
		if (mTitle != null) {
			mTitle.setText(title);
		}
	}*/

	/*public void setTitleVisible(boolean isVisible) {
		if (mTitle != null) {
			mTitle.setVisibility(isVisible == true ? View.VISIBLE : View.GONE);
		}
	}*/

	/*public void setLiveText(String text){
		if(mLiveText != null){
			mLiveText.setText(text);
		}
	}*/
	
	public void destroy() {
	}

	public interface OnDragCompleteListener {
		void onDraged(SeekBar seekBar);
	};
}