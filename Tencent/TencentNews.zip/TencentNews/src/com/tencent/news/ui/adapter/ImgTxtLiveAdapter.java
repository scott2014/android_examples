package com.tencent.news.ui.adapter;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.util.SparseIntArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.command.GetImageRequest;
import com.tencent.news.command.GetImageResponse;
import com.tencent.news.model.pojo.ImageResult;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.model.pojo.ImgTxtLiveImage;
import com.tencent.news.model.pojo.ImgTxtLiveImageIndex;
import com.tencent.news.model.pojo.ImgTxtLiveInfo;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.PullRefreshListView;
import com.tencent.news.utils.DefaulImageUtil;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.StringUtil;

public class ImgTxtLiveAdapter extends AbsListAdapter<ImgTxtLiveInfo> implements GetImageResponse {

	public static SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
	private OnClickListener imageOnClickListener = null;
	private ArrayList<ImgTxtLiveImage> imageURLs = null;
	private int newSeq = 0;
	private long serverTime = 0L;
	private SparseIntArray imageIndex2position = null;

	public ImgTxtLiveAdapter(Context context, ListView listView) {
		this.mContext = context;
		this.mListView = listView;
		this.mDataList = new ArrayList<ImgTxtLiveInfo>();
		this.imageURLs = new ArrayList<ImgTxtLiveImage>();
		this.imageIndex2position = new SparseIntArray();

	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder = null;
		if (convertView == null) {
			holder = new ViewHolder();
			//夜间模式比较2的改法，时间有限哎，无奈的选择，因下面被重置，没有生效
			if(themeSettingsHelper.isDefaultTheme()){
				convertView = LayoutInflater.from(mContext).inflate(R.layout.imgtxtlive_list_item, null);
			}
			else{
				convertView = LayoutInflater.from(mContext).inflate(R.layout.night_imgtxtlive_list_item, null);
			}
			///
			loadSelfView(convertView, holder);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		ImgTxtLiveInfo item = mDataList.get(position);

		doDifference(position, item, holder);

		if (!((PullRefreshListView) mListView).isBusy()) {
			setImgTxtImage(item, holder);
		} else {
			if (null != item && null != item.getImage() && item.getImage().length > 0 && null != item.getImage()[0].getSmallimgurl() && 0 < item.getImage()[0].getSmallimgurl().length()) {
				GetImageRequest request = new GetImageRequest();
				request.setGzip(false);
				request.setTag(item.getId());
				request.setUrl(item.getImage()[0].getSmallimgurl());
				ImageResult result = TaskManager.getLocalIconImage(request, this);
				if (result.isResultOK() && result.getRetBitmap() != null) {
					showImgTxtImage(holder, result.getRetBitmap(), false);
				} else {
					showImgTxtImage(holder, result.getRetBitmap(), true);
				}
			}
		}

		return convertView;
	}

	private static class ViewHolder {
		LinearLayout live_content_bg;
		TextView live_time;
		TextView live_content;
		ImageView live_img_0;
		ImageView live_img_1;
		ImageView live_img_2;
		String id;
	}

	protected void doDifference(int position, ImgTxtLiveInfo item, final ViewHolder holder) {
		holder.id = item.getId();

		if (item.getRace_time() != null && item.getRace_time().trim().length() > 0) {
			holder.live_time.setText(item.getRace_time().trim());
		} else {

			Long time = Long.parseLong(item.getTime());

			SLog.i("CJZ", "mobile local time :" + sdf.format(new Date(System.currentTimeMillis())) + ", Delta:" + (serverTime - time) * 1000);

			item.setLocalTime(System.currentTimeMillis() - (serverTime - time) * 1000);

			SLog.i("CJZ", "input param :" + item.getLocalTime());
			holder.live_time.setText("" + StringUtil.getImageTextLiveTimeString(item.getLocalTime()));

		}
		//夜间模式比较2的改法
		if (newSeq > 0 && item.getNewSeq() > newSeq) {
			if(themeSettingsHelper.isDefaultTheme()){
				holder.live_content_bg.setBackgroundResource(R.drawable.txtlive_bubble_new);
				holder.live_time.setTextColor(Color.parseColor("#df8024"));
			}
			else{
				holder.live_content_bg.setBackgroundResource(R.drawable.night_txtlive_bubble_new);
				holder.live_time.setTextColor(Color.parseColor("#ff8c1c"));
			}
		} else {
			if(themeSettingsHelper.isDefaultTheme()){
				holder.live_content_bg.setBackgroundResource(R.drawable.txtlive_bubble);
				
				holder.live_time.setTextColor(Color.parseColor("#999999"));
			}
			else{
				//holder.live_content_bg.setBackgroundColor("#2f3133");
				//holder.live_content_bg.setBackgroundColor(Color.parseColor("#2f3133"));
				holder.live_content_bg.setBackgroundResource(R.drawable.night_txtlive_bubble);
				holder.live_time.setTextColor(Color.parseColor("#b0b5b8"));
			}
		}
		//

		if (null != imageOnClickListener) {
			ImgTxtLiveImageIndex imageIndex = new ImgTxtLiveImageIndex(getImageIndex(item), imageURLs, imageIndex2position);

			if (item != null && item.getImage() != null && item.getImage().length > 0) {
				holder.live_content.setText(item.getImage()[0].getDesc());
			} else {
				holder.live_content.setText(item.getContent());
			}
			//夜间模式添加
			if(themeSettingsHelper.isDefaultTheme()){
				holder.live_content.setTextColor(Color.parseColor("#222222"));
			}
			else{
				holder.live_content.setTextColor(Color.parseColor("#f0f4f8"));
			}
			//
			
			holder.live_img_0.setOnClickListener(imageOnClickListener);
			holder.live_img_0.setTag(imageIndex);
			holder.live_img_1.setOnClickListener(imageOnClickListener);
			holder.live_img_1.setTag(imageIndex);
			holder.live_img_2.setOnClickListener(imageOnClickListener);
			holder.live_img_2.setTag(imageIndex);
		}

		if (item.getImage() != null && item.getImage().length > 0) {
			switch (item.getImage().length) {
			case 1:
				holder.live_img_0.setVisibility(View.VISIBLE);// 目前只显示1张图片
				holder.live_img_1.setVisibility(View.GONE);
				holder.live_img_2.setVisibility(View.GONE);
				break;
			case 2:
				holder.live_img_0.setVisibility(View.VISIBLE);
				holder.live_img_1.setVisibility(View.GONE);
				holder.live_img_2.setVisibility(View.GONE);
				break;
			case 3:
				holder.live_img_0.setVisibility(View.VISIBLE);
				holder.live_img_1.setVisibility(View.GONE);
				holder.live_img_2.setVisibility(View.GONE);
				break;
			default:
				break;
			}
		} else {
			holder.live_img_0.setVisibility(View.GONE);
			holder.live_img_1.setVisibility(View.GONE);
			holder.live_img_2.setVisibility(View.GONE);
		}

	}

	private Object getResources() {
		// TODO Auto-generated method stub
		return null;
	}

	protected void loadSelfView(View convertView, ViewHolder holder) {

		holder.live_content_bg = (LinearLayout) convertView.findViewById(R.id.live_content_bg);
		holder.live_time = (TextView) convertView.findViewById(R.id.live_time);
		holder.live_content = (TextView) convertView.findViewById(R.id.live_content);
		holder.live_img_0 = (ImageView) convertView.findViewById(R.id.live_img_0);
		holder.live_img_1 = (ImageView) convertView.findViewById(R.id.live_img_1);
		holder.live_img_2 = (ImageView) convertView.findViewById(R.id.live_img_2);
	}

	@Override
	public void changeStyleMode(int style) {

	}

	@Override
	public void serListViewBusy(int currPosition, int tag) {
		if (currPosition >= 0 && currPosition < mDataList.size()) {
			ImgTxtLiveInfo item = mDataList.get(currPosition);
			setImgTxtImage(item, (ViewHolder) mListView.getChildAt(tag).getTag());
		}

	}

	protected void setImgTxtImage(ImgTxtLiveInfo item, ViewHolder holder) {
		if (null == item || null == item.getImage() || 0 >= item.getImage().length || null == item.getImage()[0].getSmallimgurl() || 0 >= item.getImage()[0].getSmallimgurl().length()) {
			return;
		}
		GetImageRequest request = new GetImageRequest();
		request.setTag(item.getId());
		request.setUrl(item.getImage()[0].getSmallimgurl());
		ImageResult result = TaskManager.startSmallImageTask(request, this);
		if (result.isResultOK() && result.getRetBitmap() != null) {
			showImgTxtImage(holder, result.getRetBitmap(), false);
		} else {
			showImgTxtImage(holder, result.getRetBitmap(), true);
		}
		return;
	}

	private void showImgTxtImage(ViewHolder holder, Bitmap bitmap, boolean isDefault) {
		if (null == holder) {
			return;
		}
		if (isDefault) {// now just the first one bitmap is used.
			if(themeSettingsHelper.isDefaultTheme()){
				holder.live_img_0.setImageBitmap(DefaulImageUtil.getDefaultImgTxtImage());
			}
			else{
				holder.live_img_0.setImageBitmap(DefaulImageUtil.getNightDefaultImgTxtImage());
			}
		} else {
			holder.live_img_0.setImageBitmap(bitmap);
		}
		return;
	}

	public OnClickListener getImageOnClickListener() {
		return imageOnClickListener;
	}

	public void setImageOnClickListener(OnClickListener imageOnClickListener) {
		this.imageOnClickListener = imageOnClickListener;
	}

	protected void getAllImageURLs() {

		imageURLs.clear();
		imageIndex2position.clear();

		Iterator<ImgTxtLiveInfo> iterator = this.mDataList.iterator();
		int index = 0, position = 0;
		while (iterator.hasNext()) {
			ImgTxtLiveInfo imageTextLiveinfo = iterator.next();
			if (null != imageTextLiveinfo && null != imageTextLiveinfo.getImage() && 0 < imageTextLiveinfo.getImage().length) {
				ImgTxtLiveImage imageInfo = imageTextLiveinfo.getImage()[0];
				this.imageURLs.add(imageInfo);
				this.imageIndex2position.put(index, position);
				++index;
			}
			++position;
		}
		return;
	}

	protected int getImageIndex(ImgTxtLiveInfo item) {
		int index = 0;
		for (int i = 0; i < imageURLs.size(); ++i) {
			if (null != item && null != item.getImage() && 0 < item.getImage().length && null != item.getImage()[0].getImgurl() && 0 < item.getImage()[0].getImgurl().length()) {
				if (item.getImage()[0].getImgurl().equals(imageURLs.get(i).getImgurl())) {
					index = i;
				}
			}
		}

		return index;

	}

	@Override
	public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm, String path) {
		// TODO Auto-generated method stub
		switch (imageType) {
		case SMALL_IMAGE: {
			int countImage = mListView.getChildCount();
			for (int i = 0; i < countImage; i++) {
				ViewHolder viewHolder = (ViewHolder) mListView.getChildAt(i).getTag();
				if (viewHolder != null) {
					if (((String) tag).equals(viewHolder.id)) {
						showImgTxtImage(viewHolder, bm, false);
						break;
					}// if
				}// if
			}// for
		}
			break;
		default:
			break;
		}

		return;
	}

	@Override
	public void onImageRecvError(ImageType imageType, Object tag, int retCode) {
		return;
	}

	public ArrayList<ImgTxtLiveImage> getImageURLs() {
		return imageURLs;
	}

	public void setImageURLs(ArrayList<ImgTxtLiveImage> imageURLs) {
		this.imageURLs = imageURLs;
	}

	@Override
	public void addDataList(List<ImgTxtLiveInfo> list) {
		// TODO Auto-generated method stub
		super.addDataList(list);
		getAllImageURLs();
		return;
	}

	@Override
	public void addDataListBefore(List<ImgTxtLiveInfo> list) {
		// TODO Auto-generated method stub
		super.addDataListBefore(list);
		getAllImageURLs();
		return;
	}

	@Override
	public void addMoreDataList(List<ImgTxtLiveInfo> list) {
		// TODO Auto-generated method stub
		super.addMoreDataList(list);
		getAllImageURLs();
		return;
	}

	public void setNewSeq(int newSeq) {
		this.newSeq = newSeq;
	}

	public long getServerTime() {
		return serverTime;
	}

	public void setServerTime(long serverTime) {
		this.serverTime = serverTime;
	}

}
