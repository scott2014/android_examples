package com.tencent.news.ui.view;

import android.view.MotionEvent;

public interface IViewPagerSubViewStatus {
	// 子view在父view中的位置。-1表示忽略此位置
	public final int NO_PARENT = -1;

    void setCurrentView(IViewPagerSubViewStatus currentView);
    IViewPagerSubViewStatus getCurrentView();
    
    void setIndexInParent(int index);
	int getIndexInParent();
	
	boolean handleMotionLeft(MotionEvent event);
	boolean handleMotionRight(MotionEvent event);
}
