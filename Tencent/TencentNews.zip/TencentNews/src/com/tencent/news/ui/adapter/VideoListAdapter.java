package com.tencent.news.ui.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.command.GetImageRequest;
import com.tencent.news.config.Constants;
import com.tencent.news.model.pojo.ImageResult;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.shareprefrence.SpNewsHadRead;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.PullRefreshListView;
import com.tencent.news.utils.DefaulImageUtil;
import com.tencent.news.utils.StringUtil;

public class VideoListAdapter extends ChannelListAdapter {

	public VideoListAdapter(Context context, ListView listView) {
		super(context, listView);
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		VideoHolder holder = null;
		int type = getItemViewType(position);
		switch(type){
		case Constants.TYPE_ITEM_TEXT:
			convertView = setTextMode(convertView, position, holder);
			break;
		case Constants.TYPE_ITEM_IMAGE:
			convertView = setImageMode(convertView, position, holder);
			break;
		default:
			break;
		}
		return convertView;
	}

	private View setImageMode(View convertView, int position, VideoHolder holder){
		if (convertView == null) {
			holder = new VideoHolder();
			convertView = LayoutInflater.from(mContext).inflate(R.layout.video_list_item, null);
			holder.image = (ImageView) convertView.findViewById(R.id.video_list_image);
			holder.timeout = (TextView) convertView.findViewById(R.id.video_list_timeout);
			holder.title = (TextView) convertView.findViewById(R.id.video_list_title);
			holder.playCount = (TextView) convertView.findViewById(R.id.video_list_play_count);
			holder.playIcon = (ImageView) convertView.findViewById(R.id.icon_video_list_play);
			convertView.setTag(holder);
		} else {
			holder = (VideoHolder) convertView.getTag();
		}

		if (mDataList != null && mDataList.size() > 0) {
			final Item item = mDataList.get(position);
			if (item != null) {
				holder.id = item.getId();
				setTextData(item, holder);
				if(!((PullRefreshListView)mListView).isBusy()){
					setVideoListImage(item, holder);
				}else{
					GetImageRequest request = new GetImageRequest();
					request.setUrl(item.getThumbnails_qqnews()[0]);
					request.setTag(holder.id);
					ImageResult result = TaskManager.getLocalIconImage(request, this);
					if(result.isResultOK() && result.getRetBitmap() != null){
						/*if(themeSettingsHelper.isNightTheme()){
							holder.image.setImageDrawable(ImageUtil.getBlackBitmap(result.getRetBitmap()));
						}else{
							holder.image.setImageBitmap(result.getRetBitmap());
						}*/
						holder.image.setImageBitmap(result.getRetBitmap());
					}else{
						Bitmap tmpBitmap = null;
						if(themeSettingsHelper.isNightTheme()){
							tmpBitmap = DefaulImageUtil.getNightDefaultTimelineImage();
						}
						else{
							tmpBitmap = DefaulImageUtil.getDefaultTimelineImage();
						}
						//holder.image.setImageBitmap(DefaulImageUtil.getDefaultTimelineImage());
						holder.image.setImageBitmap(tmpBitmap);
					}
				}
			}
		}
		return convertView;
	}
	
	private View setTextMode(View convertView, int position, VideoHolder holder){
		if (convertView == null) {
			holder = new VideoHolder();
			convertView = LayoutInflater.from(mContext).inflate(R.layout.video_list_text_item, null);
			holder.title = (TextView) convertView.findViewById(R.id.video_list_title);
			holder.playCount = (TextView) convertView.findViewById(R.id.video_list_play_count);
			holder.playIcon = (ImageView) convertView.findViewById(R.id.icon_video_list_play);
			convertView.setTag(holder);
		} else {
			holder = (VideoHolder) convertView.getTag();
		}
		if (mDataList != null && mDataList.size() > 0) {
			final Item item = mDataList.get(position);
			if (item != null) {
				setTextData(item, holder);
			}
		}
		return convertView;
	}
	private void setTextData(Item item, VideoHolder holder) {
		if(item==null || holder==null || item.getId()==null){
			return;
		}
		if (SpNewsHadRead.isNewsHadRead(item.getId())) {
			if(themeSettingsHelper.isNightTheme()){
				holder.title.setTextColor(mContext.getResources().getColor(R.color.night_readed_news_title_color));
			}else{
				holder.title.setTextColor(mContext.getResources().getColor(R.color.readed_news_title_color));
			}
		} else {
			if(themeSettingsHelper.isNightTheme()){
				holder.title.setTextColor(mContext.getResources().getColor(R.color.night_list_title_color));
			}else{
				holder.title.setTextColor(mContext.getResources().getColor(R.color.list_title_color));
			}				
		}			
			
		holder.title.setText(StringUtil.replaceBlank(item.getTitle()));
		if(holder.timeout!=null){
			holder.timeout.setText(item.getVideoTotalTime());
		}
		if(Integer.parseInt(item.getVideo_hits())>10000){
			holder.playCount.setText(StringUtil.tenTh2wan(item.getVideo_hits()));
		}else{
			holder.playCount.setText(item.getVideo_hits());
		}
	}

	protected static class VideoHolder {
		ImageView image;
		ImageView playIcon;
		TextView title;
		TextView timeout;
		TextView playCount;
		String id;
	}

	private void setVideoListImage(Item item, VideoHolder holder) {
		if(holder==null || null == item || item.getId()==null || null == item.getThumbnails_qqnews() || item.getThumbnails_qqnews().length==0){
			return;
		} 
		Bitmap tmpBitmap = null;
		GetImageRequest request = new GetImageRequest();
		request.setGzip(false);
		request.setTag(item.getId());
		request.setUrl(item.getThumbnails_qqnews()[0]);
		ImageResult result = TaskManager.startSmallImageTask(request, this);
		if (result.isResultOK() && result.getRetBitmap() != null) {
			/*if(themeSettingsHelper.isNightTheme()){
				holder.image.setImageDrawable(ImageUtil.getBlackBitmap(result.getRetBitmap()));
			}else{
				holder.image.setImageBitmap(result.getRetBitmap());
			}*/
			holder.image.setImageBitmap(result.getRetBitmap());
		} else {
			if(themeSettingsHelper.isNightTheme()){
				tmpBitmap = DefaulImageUtil.getNightDefaultTimelineImage();
			}
			else{
				tmpBitmap = DefaulImageUtil.getDefaultTimelineImage();
			}
			//holder.image.setImageBitmap(DefaulImageUtil.getDefaultTimelineImage());
			holder.image.setImageBitmap(tmpBitmap);
		}
	}

	@Override
	public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm, String path) {
		// TODO Auto-generated method stub
		switch (imageType) {
		case SMALL_IMAGE:
			int countImage = mListView.getChildCount();
			for (int i = 0; i < countImage; i++) {
				VideoHolder videoHolder = (VideoHolder) mListView.getChildAt(i).getTag();
				if (videoHolder != null) {
					if (((String) tag).equals(videoHolder.id)) {
						if(bm!=null && videoHolder.image!=null){
							videoHolder.image.setImageBitmap(bm);	
						}
					}
				}
			}
			break;
		default:
			break;
		}
	}

	@Override
	public void onImageRecvError(ImageType imageType, Object tag, int retCode) {
		// TODO Auto-generated method stub

	}
	
	@Override
	public void serListViewBusy(int currPosition, int tag) {
		if(styleType == Constants.TYPE_ITEM_TEXT){
			return;
		}
		VideoHolder holder = (VideoHolder)mListView.getChildAt(tag).getTag();
		if(currPosition >= 0 && currPosition < mDataList.size() && holder != null){
			Item item = mDataList.get(currPosition);			
			setVideoListImage(item, holder);			
		}
	}
}
