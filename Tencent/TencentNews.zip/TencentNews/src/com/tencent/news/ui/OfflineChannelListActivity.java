package com.tencent.news.ui;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.boss.EventId;
import com.tencent.news.config.Constants;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.shareprefrence.SpConfig;
import com.tencent.news.system.NewsHadReadReceiver;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.adapter.OfflineChannelListAdapter;
import com.tencent.news.ui.view.TitleBar;
import com.tencent.news.utils.DispatchClassUtil;
import com.tencent.news.utils.FileUtil;
import com.tencent.news.utils.MobileUtil;
import com.tencent.omg.webdev.WebDev;

public class OfflineChannelListActivity extends BaseActivity {

	ListView list_offline_channel;
	List<Item> listData;
	OfflineChannelListAdapter mOfflineChannelListAdapter;
	String channelId;

	RelativeLayout offline_channel_list_page;
	RelativeLayout offline_title;

	Handler mHandler;

	TextView offline_title_text;

	protected TitleBar mTitleBar = null;

	private NewsHadReadReceiver mReceiver;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_offline_channel_list);

		Intent intent = getIntent();
		if (intent != null) {
			Bundle bundle = intent.getExtras();
			channelId = bundle.getString(Constants.NEWS_CHANNEL_CHLID_KEY);
		}

		mTitleBar = (TitleBar) findViewById(R.id.channel_title_bar);
		mTitleBar.ShowNewsBar(SpConfig.getChannelNameById(channelId));
		mTitleBar.setBackName("离线阅读");
		mTitleBar.setHideShare();
		// offline_title_text = (TextView)
		// findViewById(R.id.offline_title_text);
		// offline_title_text.setText(SpConfig.getChannelNameById(channelId));

		mMask = findViewById(R.id.mask_view);
		offline_title = (RelativeLayout) findViewById(R.id.offline_title);
		offline_channel_list_page = (RelativeLayout) findViewById(R.id.offline_channel_list_page);
		list_offline_channel = (ListView) findViewById(R.id.list_offline_channel);
		listData = new ArrayList<Item>();
		mOfflineChannelListAdapter = new OfflineChannelListAdapter(this, list_offline_channel, listData);
		list_offline_channel.setAdapter(mOfflineChannelListAdapter);

		registerBroadcastReceiver();

		initListener();

		mHandler = new Handler(new IncomingHandlerCallback());
		loadOfflineChannelData();

		// Statistics.getInstance().saveStatistics(Statistics.REPORTED_DATA_SHOWING_WHAT,
		// StatisticsUtil.generateCustomField(new String[] {
		// "OFFLINE_CLICK_READ_MORE_" + channelId, System.currentTimeMillis() +
		// "", "", "", "", "", "" }));

		WebDev.trackCustomEvent(OfflineChannelListActivity.this, EventId.BOSS_OFFLINE_CLICK_READ_MORE, getPts());

	}

	private Properties getPts() {
		Properties pts = new Properties();
		pts.setProperty(EventId.KEY_CHANNELID, channelId);
		return pts;
	}
	
	protected void registerBroadcastReceiver() {
		mReceiver = new NewsHadReadReceiver(channelId, mOfflineChannelListAdapter, null);
		IntentFilter filter = new IntentFilter(Constants.NEWS_HAD_READ_ACTION + channelId);
		registerReceiver(mReceiver, filter);
	}

	@Override
	protected void onDestroy() {
		if (mReceiver != null) {
			unregisterReceiver(mReceiver);
			mReceiver = null;
		}
		super.onDestroy();
	}

	private void initListener() {

		mTitleBar.setBackClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {
				quitActivity();
			}
		});

		list_offline_channel.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				Item item = (Item) mOfflineChannelListAdapter.getItem(position);
				Intent intent = new Intent();
				Bundle bundle = new Bundle();
				bundle.putString(Constants.NEWS_CHANNEL_CHLID_KEY, channelId);
				bundle.putSerializable(Constants.NEWS_DETAIL_KEY, item);
				// bundle.putString(Constants.NEWS_DETAIL_TITLE_KEY, "离线新闻");
				bundle.putString(Constants.NEWS_DETAIL_TITLE_KEY, "腾讯新闻");
				bundle.putBoolean(Constants.NEWS_DETAIL_FROM_OFFLINE_KEY, true);
				bundle.putString(Constants.NEWS_CLICK_ITEM_POSITION, "" + position);
				intent.setClass(OfflineChannelListActivity.this, DispatchClassUtil.getClassName(item.getArticletype()));

				intent.putExtras(bundle);
				startActivity(intent);
			}
		});

		mTitleBar.setTopClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				list_offline_channel.setSelection(0);
			}

		});
	}

	private void loadOfflineChannelData() {
		TaskManager.startRunnableRequest(new Runnable() {

			@SuppressWarnings("unchecked")
			@Override
			public void run() {
				listData = (List<Item>) FileUtil.readCache(new File(Constants.CACHE_OFFLINE_PATH + channelId + ".ls"));
				mHandler.sendEmptyMessage(0);
			}
		});
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
			quitActivity();
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_MENU) {
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	class IncomingHandlerCallback implements Handler.Callback {

		@Override
		public boolean handleMessage(Message message) {
			switch (message.what) {
			case 0:
				if (mOfflineChannelListAdapter != null) {
					mOfflineChannelListAdapter.addDataList(listData);
					mOfflineChannelListAdapter.notifyDataSetChanged();
				}
				break;
			}
			return true;
		}
	}

	private float downX;
	private float upX;
	private float downY;
	private float upY;

	@Override
	public boolean dispatchTouchEvent(MotionEvent ev) {
		final float x = ev.getX();
		final float y = ev.getY();
		if (ev.getAction() == MotionEvent.ACTION_DOWN) {
			downX = x;
			downY = y;
		} else if (ev.getAction() == MotionEvent.ACTION_UP) {
			upX = x;
			upY = y;
			if (upX > downX && Math.abs(upX - downX) > MobileUtil.dpToPx(100) && Math.abs(upY - downY) / Math.abs(upX - downX) < 0.4) {
				quitActivity();
				return true;
			}
		}
		return super.dispatchTouchEvent(ev);
	}

	View mMask;

	@Override
	public void applyTheme() {
		mTitleBar.applyTitleBarTheme(this);

		themeSettingsHelper.setViewBackgroudColor(this, this.list_offline_channel, R.color.timeline_home_bg_color);

		themeSettingsHelper.setViewBackgroudColor(this, offline_channel_list_page, R.color.page_setting_bg_color);
		themeSettingsHelper.setViewBackgroud(this, offline_title, R.drawable.title_bar_bg);
		// themeSettingsHelper.setViewBackgroud(this, offline_title_btn_back,
		// R.drawable.title_back_btn);

		themeSettingsHelper.setViewBackgroudColor(this, mMask, R.color.mask_page_color);
		themeSettingsHelper.setListViewDivider(this, list_offline_channel, R.drawable.list_divider_line);

		themeSettingsHelper.setListViewSelector(this, list_offline_channel, R.drawable.list_selector);
	}

	long viewStart;
	long viewEnd;

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
		viewStart = System.currentTimeMillis();
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
		
		viewEnd = System.currentTimeMillis();
		
		Properties newP = new Properties(getPts());
		newP.setProperty(EventId.KEY_TIMEPERIOD, "" + (viewEnd - viewStart));
		WebDev.trackCustomEvent(this, EventId.BOSS_OFFLINE_ONE_CHANNEL_LIST_VIEW_TIME, newP);

	}
}
