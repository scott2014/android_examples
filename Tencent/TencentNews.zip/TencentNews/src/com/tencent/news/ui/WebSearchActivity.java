package com.tencent.news.ui;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;

import com.tencent.news.R;
import com.tencent.news.system.Application;
import com.tencent.news.system.NetStatusReceiver;
import com.tencent.omg.webdev.WebDev;

public class WebSearchActivity extends BaseActivity {
	private String mUrl;
	private LinearLayout mLoadingLayout;
	private WebView mWebView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.web_search_layout);
		getIntentData(getIntent());
		initView();
		initListener();
	}

	private void getIntentData(Intent intent) {
		if (intent != null) {
			mUrl = intent.getStringExtra("url");
		}
	}

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}

	@SuppressLint("SetJavaScriptEnabled")
	private void initView() {
		mLoadingLayout = (LinearLayout) findViewById(R.id.search_detail_loading);
		mWebView = (WebView) findViewById(R.id.search_webview);
		mWebView.getSettings().setSavePassword(false);
		mWebView.getSettings().setJavaScriptEnabled(true);
		mWebView.requestFocus();
		mWebView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
		mWebView.loadUrl(mUrl);
	}

	public void getNewData() {
		mLoadingLayout.setVisibility(View.VISIBLE);
		if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_INAVAILABLE) {
			mWebView.loadUrl("file:///android_asset/error.html");
		} else {
			mWebView.loadUrl(mUrl);
		}
	}

	private void initListener() {

		mWebView.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView view, String url, Bitmap favicon) {
				super.onPageStarted(view, url, favicon);
			}

			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				System.out.println("url------>" + url);
				Intent intent = new Intent();
				intent.putExtra("url", url);
				intent.setClass(WebSearchActivity.this, WebBrowserActivity.class);
				startActivity(intent);
				return true;
			}

			@Override
			public void onPageFinished(WebView view, String url) {
				super.onPageFinished(view, url);
				mLoadingLayout.setVisibility(View.GONE);
			}

			@Override
			public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
				super.onReceivedError(view, errorCode, description, failingUrl);
				mWebView.loadUrl("file:///android_asset/error.html");
				mLoadingLayout.setVisibility(View.GONE);
			}

		});
	}

	public void hideSoftKeyBoard() {
		if (mWebView != null) {
			Application.getInstance().hideSoftInputFromWindow(mWebView.getWindowToken());
		}
	}
}
