package com.tencent.news.ui.view;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.HorizontalScrollView;

public class HorizontalScrollViewEx extends HorizontalScrollView {
	private String TAG = "HorizontalScrollViewEx";
	OnScrollChangedListener mOnScrollChangedListener=null;

	public HorizontalScrollViewEx(Context context) {
		super(context);
    }

    public HorizontalScrollViewEx(Context context, AttributeSet attrs) {
    	super(context,attrs);
    }

    public HorizontalScrollViewEx(Context context, AttributeSet attrs, int defStyle) {
    	super(context,attrs,defStyle);
    }
    

	
	@Override
	protected void onScrollChanged(int l, int t, int oldl, int oldt) {
		super.onScrollChanged(l, t, oldl, oldt);
		if(mOnScrollChangedListener!=null){
			mOnScrollChangedListener.onScrollChanged(l, t, oldl, oldt);
		}
		/*SLog.i(TAG, " onScrollChanged l:" + String.valueOf(l)+" t:" + String.valueOf(t)+" oldl:" + String.valueOf(oldl)+" oldt:" + String.valueOf(oldt));
		SLog.i(TAG, " onScrollChanged getPaddingLeft:" + String.valueOf(getPaddingLeft())+" getPaddingRight:" + String.valueOf(getPaddingRight()));
		SLog.i(TAG, " onScrollChanged getLeft:" + String.valueOf(getLeft())+" getRight:" + String.valueOf(getRight()));*/
		//Rect outRect = new Rect();
        //getDrawingRect(outRect);
	}
	
	public void setOnScrollChangedListener(OnScrollChangedListener l){
		mOnScrollChangedListener=l;
	}
	
	 public interface OnScrollChangedListener{
		 void onScrollChanged(int l, int t, int oldl, int oldt);
	 }

}
