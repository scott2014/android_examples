package com.tencent.news.ui.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.config.Constants;
import com.tencent.news.utils.ThemeSettingsHelper;

public class TitleBar extends RelativeLayout {
	private Context mContext;
	private TextView title;
	private ImageButton btnShare,btnSetting;
	private Button btnAddChannel;	
	private ProgressBar mProgressBar;
	private Button mBackBtn;
	private Button mCompleteBtn;
	private LinearLayout mClickTop;
	private RelativeLayout  mLayout;	
	private ImageView remindRedDot; //未读信息小红点提示
	private boolean isRedDotShow = false; //未读信息小红点是否已经显示
	protected ThemeSettingsHelper themeSettingsHelper = null; //支持夜间模式
	
	public TitleBar(Context context) {
		super(context);
		Init(context);
	}

	public TitleBar(Context context, AttributeSet attrs) {
		super(context, attrs);
		Init(context);
	}

	public TitleBar(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		Init(context);
	}

	private void Init(Context context){
		this.mContext = context;
		LayoutInflater.from(mContext).inflate(R.layout.titlebar_layout,this,true);
		title = (TextView)findViewById(R.id.title_bar_text);
		btnShare = (ImageButton)findViewById(R.id.title_btn_share);
		btnSetting = (ImageButton)findViewById(R.id.title_btn_setting);
		btnAddChannel = (Button)findViewById(R.id.add_channel_btn);
		mProgressBar = (ProgressBar)findViewById(R.id.title_progressbar);
		mBackBtn = (Button)findViewById(R.id.title_bar_btn_back);
		mClickTop = (LinearLayout)findViewById(R.id.title_click_top);		
		mLayout = (RelativeLayout)findViewById(R.id.title_bar_layout);
		mCompleteBtn = (Button)findViewById(R.id.complete_btn);
		remindRedDot = (ImageView)findViewById(R.id.remind_red_dot);
		btnShare.setEnabled(false);
		btnSetting.setEnabled(false);			
		btnAddChannel.setEnabled(false);
		mCompleteBtn.setEnabled(false);
	}
	
	public void Refresh(){
		btnShare.setVisibility(View.GONE);
		btnSetting.setVisibility(View.GONE);
		mProgressBar.setVisibility(View.VISIBLE);
	}
	
	public void RefreshComplete(){
		//SLog.d("####RefreshComplete####","btnShare VISIBLE");
		btnShare.setVisibility(View.VISIBLE);
		btnSetting.setVisibility(View.VISIBLE);
		mProgressBar.setVisibility(View.GONE);
	}
	
	public void setTitleText(String text){		
		//title.setText(text);
		String strTitleText = text;
		if(Constants.IS_BETATESTING_APK){//如果是内部测试版apk
			strTitleText +=  getResources().getString(R.string.betatesting_titlebar);
		}
		title.setText(strTitleText);
	}
	
	public void setTitleText(int id){
		String text = mContext.getResources().getString(id);
		if(Constants.IS_BETATESTING_APK){//如果是内部测试版apk
			text +=  getResources().getString(R.string.betatesting_titlebar);
		}
		title.setText(text);		
	}
	
	public void setShareClickListener(OnClickListener listener){
		btnShare.setOnClickListener(listener);
	}
	
	public void setCompleteClickListener(OnClickListener listener){
	    mCompleteBtn.setOnClickListener(listener);
    }
	
	public void setSettingClickListener(OnClickListener listener){
		btnSetting.setOnClickListener(listener);
	}
	
	public void setBackClickListener(OnClickListener listener){
		mBackBtn.setOnClickListener(listener);
	}
	
	public void setTopClickListener(OnClickListener listener){
		mClickTop.setOnClickListener(listener);
	}
	
	public void showRemindRedDot(){
		if(remindRedDot!=null && !isRedDotShow){
			isRedDotShow = true;
			remindRedDot.setVisibility(View.VISIBLE);
		}
	}
	
	public void hideRemindRedDot(){
		if(remindRedDot!=null && isRedDotShow){
			isRedDotShow = false;
			remindRedDot.setVisibility(View.GONE);
		}
	}
	
	public void ShowElseBar(int id){
		String text = mContext.getResources().getString(id);
		//title.setText(text);
		setTitleText(text);
	}
	
	public void ShowSinaBar(int id){
		mBackBtn.setVisibility(View.VISIBLE);
		String text = mContext.getResources().getString(id);
		//title.setText(text);
		setTitleText(text);
	}
	
	public void ShowSinaBar(String text){
		mBackBtn.setVisibility(View.VISIBLE);
		setTitleText(text);
	}
	
	public void ShowNewsBar(String text){
		btnShare.setVisibility(View.VISIBLE);
		mBackBtn.setVisibility(View.VISIBLE);
		setTitleText(text);
	}
	
	public void showBackBtn() {
        mBackBtn.setVisibility(View.VISIBLE);
	}
	
	public void ShowMainBar(int textId, int drawableId){
		btnShare.setEnabled(true);
		btnShare.setVisibility(View.GONE);
		btnSetting.setEnabled(true);
		btnSetting.setVisibility(View.VISIBLE);
		btnAddChannel.setEnabled(false);
		btnAddChannel.setVisibility(View.GONE);
		mBackBtn.setVisibility(View.GONE);
		setTitleText(textId);
		btnShare.setImageDrawable(mContext.getResources().getDrawable(drawableId));
	}
	
	public void showmCompleteBtn(int textId) {
	    mCompleteBtn.setEnabled(true);
	    mCompleteBtn.setVisibility(View.VISIBLE);
	    mCompleteBtn.setText(textId);
	}
	   
	public void showAddRssChannelBtn(int textId) {
        btnAddChannel.setEnabled(true);
        btnAddChannel.setVisibility(View.VISIBLE);
        setTitleText(textId);
	}

    public void setAddRssClickListener(OnClickListener listener){
        btnAddChannel.setOnClickListener(listener);
    }
	
	public void setHideShare(){
		btnShare.setVisibility(View.GONE);
	}
	
	public ImageButton getShareBtn(){
		return this.btnShare;
	}
	
	public ImageButton getSettingBtn(){
		return this.btnSetting;
	}
	
	public void setBackName(String name){
		mBackBtn.setText(name);
	}	
	
    public void applyTitleBarTheme(Context context) {			
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(context);		
		themeSettingsHelper.setViewBackgroud(context, this.mLayout, R.drawable.title_bar_bg);
		themeSettingsHelper.setImageButtonSrc(context, this.btnShare, R.drawable.title_share_btn);	
		themeSettingsHelper.setImageButtonSrc(context, this.btnSetting, R.drawable.title_setting_btn); 
		themeSettingsHelper.setViewBackgroud(context, this.mBackBtn, R.drawable.title_back_btn);	
        themeSettingsHelper.setViewBackgroud(context, this.btnAddChannel, R.drawable.btn_send_selector);
        themeSettingsHelper.setViewBackgroud(context, this.mCompleteBtn, R.drawable.title_complete_btn);
	}
}
