package com.tencent.news.ui.view;

import android.content.Context;
import android.graphics.Rect;
import android.text.Editable;
import android.text.Selection;
import android.text.Spannable;
import android.text.TextUtils;
import android.text.method.ArrowKeyMovementMethod;
import android.text.method.MovementMethod;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.TextView;

/*
 * This is supposed to be a *very* thin veneer over TextView.
 * Do not make any changes here that do anything that a TextView
 * with a key listener and a movement method wouldn't do!
 */

/**
 * EditText is a thin veneer over TextView that configures itself to be
 * editable.
 * <p>
 * <b>XML attributes</b>
 * <p>
 * See {@link android.R.styleable#EditText EditText Attributes},
 * {@link android.R.styleable#TextView TextView Attributes},
 * {@link android.R.styleable#View View Attributes}
 */
public class CEditText extends TextView {

	
	CJZEditTextValueChangeListener cjzvcListener = null;
	
	public CEditText(Context context) {
		this(context, null);
	}

	public CEditText(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	@Override
	protected boolean getDefaultEditable() {
		return true;
	}

	@Override
	protected MovementMethod getDefaultMovementMethod() {
		return ArrowKeyMovementMethod.getInstance();
	}

	@Override
	public Editable getText() {
		return (Editable) super.getText();
	}

	@Override
	public void setText(CharSequence text, BufferType type) {
		super.setText(text, BufferType.EDITABLE);
	}

	/**
	 * Convenience for {@link Selection#setSelection(Spannable, int, int)}.
	 */
	public void setSelection(int start, int stop) {
		Selection.setSelection(getText(), start, stop);
	}

	/**
	 * Convenience for {@link Selection#setSelection(Spannable, int)}.
	 */
	public void setSelection(int index) {
		Selection.setSelection(getText(), index);
	}

	/**
	 * Convenience for {@link Selection#selectAll}.
	 */
	public void selectAll() {
		Selection.selectAll(getText());
	}

	/**
	 * Convenience for {@link Selection#extendSelection}.
	 */
	public void extendSelection(int index) {
		Selection.extendSelection(getText(), index);
	}

	@Override
	public void setEllipsize(TextUtils.TruncateAt ellipsis) {
		if (ellipsis == TextUtils.TruncateAt.MARQUEE) {
			throw new IllegalArgumentException(
					"EditText cannot use the ellipsize mode "
							+ "TextUtils.TruncateAt.MARQUEE");
		}
		super.setEllipsize(ellipsis);
	}
	
	
	
	
	
	
	@Override
	protected void onFocusChanged(boolean focused, int direction,
			Rect previouslyFocusedRect) {
		// Auto-generated method stub
		if(cjzvcListener != null){
			cjzvcListener.onValueChangeListener();
		}
		super.onFocusChanged(focused, direction, previouslyFocusedRect);
	}

	@Override
	protected void onTextChanged(CharSequence text, int start, int before,
			int after) {
		// Auto-generated method stub
		if(cjzvcListener != null){
			cjzvcListener.onValueChangeListener();
		}
		super.onTextChanged(text, start, before, after);
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		// Auto-generated method stub
		if(cjzvcListener != null){
			cjzvcListener.onValueChangeListener();
		}
		return super.onTouchEvent(event);
	}
	
	
	

	public void setOnCJZEditTextValueChangeListener(CJZEditTextValueChangeListener cjzvcListener){
		this.cjzvcListener = cjzvcListener;
	}
	
	public interface CJZEditTextValueChangeListener{
		public void onValueChangeListener();
	}
}
