package com.tencent.news.ui.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.tencent.news.R;

public class VideoDetailView extends FrameLayout {
	private Context mContext;
	
	private ImageView mDetailImage;
	private ImageButton mVideoPlay;
	private TextView mDetailContent;

	private TextView mDetailTitle;

	private TextView mDetailTime;

	private TextView mDetailComments;

	private TextView mDetailSource;
	
	
	public VideoDetailView(Context context) {
		super(context);
		init(context);
	}

	public VideoDetailView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init(context);
	}
	
	private void init(Context context){
		mContext = context;
		LayoutInflater.from(mContext).inflate(R.layout.video_detail_view_layout,this, true);
		mDetailImage = (ImageView) findViewById(R.id.video_detail_image);
		mVideoPlay = (ImageButton) findViewById(R.id.video_detail_play_btn);
		mDetailContent = (TextView) findViewById(R.id.video_detail_content);
		mDetailTitle = (TextView) findViewById(R.id.video_detail_title);
		mDetailTime = (TextView) findViewById(R.id.video_detail_time);
		mDetailComments = (TextView) findViewById(R.id.video_detail_comments);
		mDetailSource = (TextView) findViewById(R.id.video_detail_source);
		
	}
	
	public ImageView getDetailImage(){
		return mDetailImage;
	}

	public ImageButton getVideoPlay() {
		return mVideoPlay;
	}
	
	public TextView getDetailTitle(){
		return mDetailTitle;
	}

	public TextView getDetailTime(){
		return mDetailTime;
	}
	
	public TextView getDetailContent(){
		return mDetailContent;
	}
	public TextView getDetailComments(){
		return mDetailComments;
	}
	public TextView getDetailSource(){
		return mDetailSource;
	}
	

}
