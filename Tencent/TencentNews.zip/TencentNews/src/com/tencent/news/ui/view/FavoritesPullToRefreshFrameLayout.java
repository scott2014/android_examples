
package com.tencent.news.ui.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import com.tencent.news.R;
import com.tencent.news.config.Constants;
import com.tencent.news.utils.ThemeSettingsHelper;

/**
* @author jianhu
* @version 创建时间：2013-7-4 上午10:58:18
* 包含无内容是下拉刷新View、有内容时下拉刷新ListView及各种状态显示
*/
public class FavoritesPullToRefreshFrameLayout extends FrameLayout {
    private Context mContext;
    private boolean hasHeader;
    private boolean hasFooter;
    private boolean hasDivider;
    private boolean hasShadow;
    private FavoritesPullRefreshListView pullToRefreshListView;
    private FavoritesPullRefreshView mEmptyPullRefreshView;
    private int nType;
    private boolean isLogin = false;
    private RelativeLayout loadLayout = null;
    private RelativeLayout errorLayout = null;
    private RelativeLayout emptyPullRefreshLayout = null;
    private FrameLayout mBackGroudLayout = null;
    private ImageView mShadowTop = null;
    private ImageView mShadowBottom = null;
    private ImageView mLoadingImg = null;
    protected ThemeSettingsHelper themeSettingsHelper = null;

    public FavoritesPullToRefreshFrameLayout(Context context) {
        this(context, null);
    }

    public FavoritesPullToRefreshFrameLayout(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public FavoritesPullToRefreshFrameLayout(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        mContext = context;
        themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(mContext);
        TypedArray arrayType = context.obtainStyledAttributes(attrs,
                com.tencent.news.R.styleable.PullToRefreshFrameLayout);
        hasHeader = arrayType.getBoolean(R.styleable.PullToRefreshFrameLayout_has_header, false);
        hasFooter = arrayType.getBoolean(R.styleable.PullToRefreshFrameLayout_has_footer, false);
        hasDivider = arrayType.getBoolean(R.styleable.PullToRefreshFrameLayout_has_divider, false);
        hasShadow = arrayType.getBoolean(R.styleable.PullToRefreshFrameLayout_has_shadow, true);
        arrayType.recycle();
        Init();
    }

    private void Init() {
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.favorites_pull_to_refresh_layout, this, true);
        pullToRefreshListView = (FavoritesPullRefreshListView) findViewById(R.id.timeline_list);
        mEmptyPullRefreshView = (FavoritesPullRefreshView) findViewById(R.id.empty_pull_refresh_view);
        pullToRefreshListView.setHasHeader(hasHeader);
        pullToRefreshListView.setHasFooter(hasFooter);
        if (!hasDivider) {
            pullToRefreshListView.setDivider(null);
            pullToRefreshListView.setDividerHeight(0);
        }
        pullToRefreshListView.initView();
        mBackGroudLayout = (FrameLayout) findViewById(R.id.pull_to_refresh_layout);
        loadLayout = (RelativeLayout) findViewById(R.id.loading_layout);
        errorLayout = (RelativeLayout) findViewById(R.id.error_layout);
        emptyPullRefreshLayout = (RelativeLayout) findViewById(R.id.empty_pull_refresh_layout);
        mShadowTop = (ImageView) findViewById(R.id.list_top_shadow);
        mShadowBottom = (ImageView) findViewById(R.id.list_bottom_shadow);
        mLoadingImg = (ImageView) findViewById(R.id.loading_img);

        if (hasShadow) {
            mShadowBottom.setVisibility(View.VISIBLE);
            mShadowTop.setVisibility(View.VISIBLE);
        } else {
            mShadowBottom.setVisibility(View.GONE);
            mShadowTop.setVisibility(View.GONE);
        }
    }

    public void applyFrameLayoutTheme() {
        themeSettingsHelper.setViewBackgroudColor(mContext, mBackGroudLayout, R.color.pull_to_refresh_bg_color);
        themeSettingsHelper.setViewBackgroud(mContext, mShadowTop, R.drawable.top_shadow_bg);
        themeSettingsHelper.setViewBackgroud(mContext, mShadowBottom, R.drawable.bottom_shadow_bg);
        themeSettingsHelper.setImageViewSrc(mContext, mLoadingImg, R.drawable.news_loading_icon);
        pullToRefreshListView.applyPullRefreshViewTheme();
        mEmptyPullRefreshView.applyTheme();
    }

    public FavoritesPullRefreshListView getPullToRefreshListView() {
        return pullToRefreshListView;
    }

    public void setPullToRefreshListView(FavoritesPullRefreshListView pullToRefreshListView) {
        this.pullToRefreshListView = pullToRefreshListView;
    }

    public FavoritesPullRefreshView getmEmptyPullRefreshView() {
        return mEmptyPullRefreshView;
    }

    public void setmEmptyPullRefreshView(FavoritesPullRefreshView mEmptyPullRefreshView) {
        this.mEmptyPullRefreshView = mEmptyPullRefreshView;
    }

    public void showState(int nState) {
        switch (nState) {
            case Constants.LIST:
                pullToRefreshListView.setVisibility(View.VISIBLE);
                loadLayout.setVisibility(View.GONE);
                emptyPullRefreshLayout.setVisibility(View.GONE);
                errorLayout.setVisibility(View.GONE);
                break;
            case Constants.LOADING:
                loadLayout.setVisibility(View.VISIBLE);
                pullToRefreshListView.setVisibility(View.GONE);
                emptyPullRefreshLayout.setVisibility(View.GONE);
                errorLayout.setVisibility(View.GONE);
                break;
            case Constants.EMPTY:
//                emptyLayout.setVisibility(View.VISIBLE);
//                if (!isLogin) {
//                    mLoin.setVisibility(View.VISIBLE);
//                } else {
//                    mLoin.setVisibility(View.GONE);
//                }
                emptyPullRefreshLayout.setVisibility(View.VISIBLE);
                loadLayout.setVisibility(View.GONE);
                pullToRefreshListView.setVisibility(View.GONE);
                errorLayout.setVisibility(View.GONE);
                break;
            case Constants.ERROR:
                errorLayout.setVisibility(View.VISIBLE);
                loadLayout.setVisibility(View.GONE);
                emptyPullRefreshLayout.setVisibility(View.GONE);
                pullToRefreshListView.setVisibility(View.GONE);
                break;
            default:
                break;
        }
        nType = nState;
    }

    public void setRetryButtonClickedListener(OnClickListener listener) {
        errorLayout.setOnClickListener(listener);
    }

    public int getStateType() {
        return this.nType;
    }

//    public void setPullListViewTimeTag(String tag) {
//        pullToRefreshListView.setPullTimeTag(tag);
//        mEmptyPullRefreshView.setPullTimeTag(tag);
//        
//    }

    public void setLogin(boolean isLogin) {
        this.isLogin = isLogin;
        pullToRefreshListView.setHasLogin(this.isLogin);
        mEmptyPullRefreshView.setHasLogin(this.isLogin);
    }

}
