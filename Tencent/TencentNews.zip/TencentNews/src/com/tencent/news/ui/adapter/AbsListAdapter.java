package com.tencent.news.ui.adapter;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.widget.BaseAdapter;
import android.widget.ListView;

import com.tencent.news.command.GetImageResponse;
import com.tencent.news.config.Constants;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.ui.view.PullRefreshListView.startListener;
import com.tencent.news.utils.ThemeSettingsHelper;

public abstract class AbsListAdapter<T> extends BaseAdapter implements startListener,GetImageResponse{
	protected Context mContext;
	protected ListView mListView;
	protected List<T> mDataList;
	protected int styleType;
	protected ThemeSettingsHelper themeSettingsHelper = null; //支持夜间模式
	
	public AbsListAdapter() {
		SettingInfo settingInfo = SettingObservable.getInstance().getData();
		if (settingInfo != null && settingInfo.isIfTextMode()) {
			styleType = Constants.TYPE_ITEM_TEXT;
		} else {
			styleType = Constants.TYPE_ITEM_IMAGE;
		}		
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(mContext);			
	}

	public void addDataList(List<T> list) {
		if (this.mDataList != null) {
			this.mDataList.clear();
		} else {
			mDataList = new ArrayList<T>();
		}
		this.mDataList.addAll(list);
	}

	public void insertData(T item, int location) {
		if(mDataList == null) {
			mDataList = new ArrayList<T>();
		}
		
		if(location >= 0 && location <= mDataList.size()) {
			mDataList.add(location, item);
		}
	}
	
	public void addDataListBefore(List<T> list) {
		if (this.mDataList != null) {
			this.mDataList.addAll(0, list);
		} else {
			mDataList = new ArrayList<T>();
			this.mDataList.addAll(list);
		}
	}

	public void addMoreDataList(List<T> list) {
		if (this.mDataList == null) {
			this.mDataList = new ArrayList<T>();
		}
		this.mDataList.addAll(list);
	}

	public void clearAdapterListData() {
		if (mDataList != null) {
			mDataList.clear();
			mDataList = null;
		}
	}

	public List<T> getDataList() {
		if (mDataList != null) {
			return mDataList;
		}
		return null;
	}

	public T getObjectItem(int position) {
		if (mDataList != null && position < mDataList.size()) {
			return mDataList.get(position);
		}
		return null;
	}
	
	public void deleteItemObject(int position){
		if (mDataList != null && position < mDataList.size()) {
			mDataList.remove(position);
		}
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		if (mDataList != null) {
			return mDataList.size();
		} else {
			return 0;
		}
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return mDataList.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public int getItemViewType(int position) {
		return styleType;
	}

	@Override
	public int getViewTypeCount() {
		// Auto-generated method stub
		return 2;
	}
	
	@Override
	public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm,
			String path) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onImageRecvError(ImageType imageType, Object tag, int retCode) {
		// TODO Auto-generated method stub
		
	}

	abstract public void changeStyleMode(int style);
}
