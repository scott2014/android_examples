package com.tencent.news.ui.view;

import android.content.Context;
import android.util.AttributeSet;

import com.tencent.news.model.pojo.ChannelList;
import com.tencent.news.system.Application;
import com.tencent.news.utils.InfoConfigUtil;
import com.tencent.news.utils.TempManager;


public class ChannelBarVideo extends ChannelBarBase {
	public ChannelBarVideo(Context context){
		super(context);
	}
	
	public ChannelBarVideo(Context context, AttributeSet attrs){
		super(context,attrs);
	}
	
	@Override
	public ChannelList getChannelList(){
		ChannelList ChannelList = Application.getInstance().getVideoChannelList();
		if(ChannelList == null){
			ChannelList = InfoConfigUtil.ReadVideoSubChannel();
			//ChannelList = InfoConfigUtil.ReadSubChannel();//临时
			if(ChannelList == null){
				ChannelList = TempManager.getManager().getVideoChannelListInfo(mContext);
			}
			Application.getInstance().setVideoChannelList(ChannelList);
		}		
		return ChannelList;
	}

	@Override
	public void onClickSetUp() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object getChannelData() {
		// TODO Auto-generated method stub
		return null;
	}
}
