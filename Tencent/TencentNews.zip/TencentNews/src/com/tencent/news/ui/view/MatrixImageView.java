package com.tencent.news.ui.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.Point;
import android.graphics.PointF;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.ViewTreeObserver;

import com.tencent.news.utils.DefaulImageUtil;
import com.tencent.news.utils.SLog;

public class MatrixImageView extends SImageView {

	private static final String TAG = "MatrixImageView";

	// 一开始居中显示的Matrix大小
	private Matrix mOriginMatrix;

	// 当前显示的Matrix大小
	private Matrix mCurrentMatrix;

	// 一开始放大的倍数
	private float mOriginScale;

	// 最小放大倍数
	private float mMinScale;

	private static final float MIN_SCALE_SIZE = 1.0f;

	private static final float MAX_SCALE_SIZE = 3.0f;

	// 最大放大倍数
	private float mMaxScale;

	// 一开始水平方向的偏移量
	private float mOriginTranslateX;

	// 一开始垂直方向的偏移量
	private float mOriginTranslateY;

	private int mLogIndex = 0;

	// 控制第一次显示
	private boolean mFirstShowImage;

	// 记录上一次的放大倍数
	private float mBaseScaleTime;

	// 记录上一次的移动X坐标
	private PointF mBasePointTranslate;

	// ImageView的显示大小
	private Rect mImageViewRect;

	// 图片的显示大小
	private Rect mPictureRect;
	
	private Bitmap mBitmap = null;

	public MatrixImageView(Context context) {
		super(context);
		// Auto-generated constructor stub
		init(context);
	}

	public MatrixImageView(Context context, AttributeSet attrs) {
		super(context, attrs);
		// Auto-generated constructor stub
		init(context);
	}

	public MatrixImageView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		// Auto-generated constructor stub
		init(context);
	}

	private void init(Context context) {
		mOriginMatrix = new Matrix();
		mCurrentMatrix = new Matrix();
		mOriginScale = 0.0f;
		mMinScale = 0.0f;
		mMaxScale = 0.0f;
		mOriginTranslateX = 0.0f;
		mOriginTranslateY = 0.0f;
		mFirstShowImage = false;
		mImageViewRect = new Rect();
		mPictureRect = new Rect();
		mBasePointTranslate = new PointF();
	}

	@Override
	public void setImageBitmap(final Bitmap bm) {
		// Auto-generated method stub
		if (getScaleType() != ScaleType.MATRIX) {
			setScaleType(ScaleType.MATRIX);
		}
		mBitmap = bm;
		super.setImageBitmap(bm);

		int viewWidth = getWidth();
		int viewHeight = getHeight();
		if (viewWidth == 0 || viewHeight == 0) {
			mFirstShowImage = true;
			ViewTreeObserver vto = getViewTreeObserver();
			vto.addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
				public boolean onPreDraw() {
					if (mFirstShowImage) {
						getCenterInsideMatrix(mCurrentMatrix, bm.getWidth(), bm.getHeight(), getMeasuredWidth(), getMeasuredHeight());
						logMatrix(mCurrentMatrix);
						setImageMatrix(mCurrentMatrix);
						mFirstShowImage = false;
					}
					return true;
				}
			});

			return;
		}

		getCenterInsideMatrix(mCurrentMatrix, bm.getWidth(), bm.getHeight(), viewWidth, viewHeight);
		logMatrix(mCurrentMatrix);
		setImageMatrix(mCurrentMatrix);
	}

	public Bitmap getCurrentBitmap(){
		return this.mBitmap;
	}
	
	/**
	 * 获取居中显示的Matrix，大小设置在mt中
	 * 
	 * @param mt
	 * @param imageWidth
	 * @param imageHeight
	 * @param viewWidth
	 * @param viewHeight
	 */
	private void getCenterInsideMatrix(Matrix mt, int imageWidth, int imageHeight, int viewWidth, int viewHeight) {
		float iw = imageWidth;
		float ih = imageHeight;
		float vw = viewWidth;
		float vh = viewHeight;
		if (iw > 0 && ih > 0 && vw > 0 && vh > 0) {
			float widthScale;
			float heightScale;
			if(this.mBitmap.equals(DefaulImageUtil.getDefaultPhotoDetailImage())){
				widthScale = Math.min(viewWidth / iw, 1.0f);
				heightScale = Math.min(viewHeight / ih, 1.0f);
				mOriginScale = Math.min(widthScale, heightScale);
			}else{
				mOriginScale = computeSampleSize(viewWidth,viewHeight,iw,ih);
			}
	        mOriginTranslateX = (viewWidth  - iw * mOriginScale) / 2F;
	        mOriginTranslateY = (viewHeight - ih * mOriginScale) / 2F;
			float[] points = { mOriginScale, 0, mOriginTranslateX, 0, mOriginScale, mOriginTranslateY, 0, 0, 1.0f };
			mt.setValues(points);

			// 深拷贝一个
			mOriginMatrix.set(mt);

			mMinScale = MIN_SCALE_SIZE * mOriginScale;
			mMaxScale = Math.max(MAX_SCALE_SIZE * mOriginScale, MAX_SCALE_SIZE);
		}
	}

	private float computeSampleSize(float viewWidth,float viewHeight,float imageWidth,float imageHeight){
		float mScale;
		if(viewWidth >= imageWidth && viewHeight >= imageHeight){
			mScale = Math.min(viewWidth/imageWidth, viewHeight/imageHeight);
		}else if(viewWidth >= imageWidth && viewHeight <= imageHeight){
			mScale = viewHeight/imageHeight;
		}else if(viewWidth <= imageWidth && viewHeight >= imageHeight){
			mScale = viewWidth/imageWidth;
		}else{
			mScale = Math.max(viewWidth/imageWidth, viewHeight/imageHeight);
		}
		return mScale;
	}
	
	public void recordBaseScale() {
		float[] values = new float[9];
		mCurrentMatrix.getValues(values);
		mBaseScaleTime = values[0];
	}

	public void recordBasePoint() {
		float[] values = new float[9];
		mCurrentMatrix.getValues(values);
		mBasePointTranslate.x = values[2];
		mBasePointTranslate.y = values[5];
	}

	/**
	 * 放大显示，距离基准baseScale再进行放大
	 * 
	 * @param scale
	 *            放大倍数
	 * @param centerPoint
	 *            中点位置
	 */
	public void setScale(float scale, PointF centerPoint) {
		float[] values = new float[9];
		mCurrentMatrix.getValues(values);

		// 每次放大的倍数都按照之前保存的基准进行放大
		float finalScale = mBaseScaleTime * scale;

		if (finalScale < mMinScale) {
			finalScale = mMinScale;
		}

		if (finalScale > mMaxScale) {
			finalScale = mMaxScale;
		}

		// 近似靠近
		if (scale < 1.0 && finalScale >= (mOriginScale * 0.9f) && finalScale <= (mOriginScale * 1.1f)) {
			mCurrentMatrix.set(mOriginMatrix);
		} else {
			// 当前需要放大的倍数
			float curScale = finalScale / values[0];
			mCurrentMatrix.postScale(curScale, curScale, centerPoint.x, centerPoint.y);
			checkMatrixCenterDisplay(mCurrentMatrix);
		}

		logMatrix(mCurrentMatrix);
		setImageMatrix(mCurrentMatrix);
	}
	
	public void setScale(float scale) {
		float[] values = new float[9];
		mCurrentMatrix.getValues(values);

		float cx = getWidth() / 2F;
	    float cy = getHeight() / 2F;
		// 每次放大的倍数都按照之前保存的基准进行放大
		float finalScale = mBaseScaleTime * scale;

		if (finalScale < mMinScale) {
			finalScale = mMinScale;
		}

		if (finalScale > mMaxScale) {
			finalScale = mMaxScale;
		}
		float curScale = finalScale / values[0];
		mCurrentMatrix.postScale(curScale, curScale, cx, cy);
		logMatrix(mCurrentMatrix);
		setImageMatrix(mCurrentMatrix);
	}
	
	/**
	 * 检查是否居中显示，如果没有则调整位置
	 * 
	 * @param mt
	 */
	private void checkMatrixCenterDisplay(Matrix mt) {

		if (mt.equals(mOriginMatrix)) {
			return;
		}

		float[] values = new float[9];
		mt.getValues(values);

		int pictureWidth = (int) (mRelatedBitmap.getWidth() * values[0]);// 图片的宽度x缩放比例
		int pictureHeight = (int) (mRelatedBitmap.getHeight() * values[0]);// 图片的高度x缩放比例

		// 获取ImageView的边界
		getDrawingRect(mImageViewRect);
		SLog.d(TAG, "RECT mImageViewRect = " + mImageViewRect.toString());
		// 获取图片边界
		mPictureRect.set((int) values[2], (int) values[5], (int) values[2] + pictureWidth, (int) values[5] + pictureHeight);

		SLog.d(TAG, "RECT mPictureRect = " + mPictureRect.toString());

		if (mPictureRect.contains(mImageViewRect)) {
			return;
		}

		Point imageViewLeftTopConner = new Point();
		Point imageViewRightTopConner = new Point();
		Point imageViewLeftBottomConner = new Point();
		Point imageViewRightBottomConner = new Point();

		Point pictureLeftTopConner = new Point();
		Point pictureRightTopConner = new Point();
		Point pictureLeftBottomConner = new Point();
		Point pictureRightBottomConner = new Point();

		imageViewLeftTopConner.x = mImageViewRect.left;// 控件左上角x
		imageViewLeftTopConner.y = mImageViewRect.top;// 控件左上角y
		imageViewRightTopConner.x = mImageViewRect.right;// 控件右上角x
		imageViewRightTopConner.y = mImageViewRect.top;// 控件右上角y
		imageViewLeftBottomConner.x = mImageViewRect.left;// 控件左下角x
		imageViewLeftBottomConner.y = mImageViewRect.bottom;// 控件左下角y
		imageViewRightBottomConner.x = mImageViewRect.right;// 控件右下角x
		imageViewRightBottomConner.y = mImageViewRect.bottom;// 控件右下角y

		pictureLeftTopConner.x = mPictureRect.left;// 控件左上角x
		pictureLeftTopConner.y = mPictureRect.top;// 控件左上角y
		pictureRightTopConner.x = mPictureRect.right;// 控件右上角x
		pictureRightTopConner.y = mPictureRect.top;// 控件右上角y
		pictureLeftBottomConner.x = mPictureRect.left;// 控件左下角x
		pictureLeftBottomConner.y = mPictureRect.bottom;// 控件左下角y
		pictureRightBottomConner.x = mPictureRect.right;// 控件右下角x
		pictureRightBottomConner.y = mPictureRect.bottom;// 控件右下角y

		Point[] imageViewPoints = { imageViewLeftTopConner, imageViewLeftBottomConner, imageViewRightTopConner, imageViewRightBottomConner };
		Point[] picturePoints = { pictureLeftTopConner, pictureLeftBottomConner, pictureRightTopConner, pictureRightBottomConner };

		SLog.d(TAG, "MATRIX 处理前：" + mt.toString());
		logProcessIndex++;
		for (int index = LT; index <= RB; index++) {
			if (dealPictureTranslate(mt, imageViewPoints[index], picturePoints[index], index)) {
				break;
			}
		}
		SLog.d(TAG, "MATRIX 处理后：" + mt.toString());
	}

	private static final int LT = 0;
	private static final int LB = 1;
	private static final int RT = 2;
	private static final int RB = 3;

	private int logProcessIndex = 0;

	private boolean dealPictureTranslate(Matrix mt, Point imageViewPoint, Point picturePoint, int cornerType) {
		switch (cornerType) {
		case LT:
			// 共三种情况需要处理
			if (picturePoint.x > imageViewPoint.x || picturePoint.y > imageViewPoint.y) {
				pictureTranslateSwitch(mt, cornerType);
				SLog.d(TAG, logProcessIndex + "Process Picture Translate LT");
				return true;
			}
			break;

		case LB:
			// 共三种情况需要处理
			if (picturePoint.x > imageViewPoint.x || picturePoint.y < imageViewPoint.y) {
				pictureTranslateSwitch(mt, cornerType);
				SLog.d(TAG, logProcessIndex + "Process Picture Translate LB");
				return true;
			}
			break;

		case RT:
			// 共三种情况需要处理
			if (picturePoint.x < imageViewPoint.x || picturePoint.y > imageViewPoint.y) {
				pictureTranslateSwitch(mt, cornerType);
				SLog.d(TAG, logProcessIndex + "Process Picture Translate RT");
				return true;
			}
			break;

		case RB:
			// 共三种情况需要处理
			if (picturePoint.x < imageViewPoint.x || picturePoint.y < imageViewPoint.y) {
				pictureTranslateSwitch(mt, cornerType);
				SLog.d(TAG, logProcessIndex + "Process Picture Translate RB");
				return true;
			}
			break;

		default:
			break;
		}

		return false;
	}

	private void pictureTranslateSwitch(Matrix mt, int cornerType) {
		if (mImageViewRect.width() <= mPictureRect.width() && mImageViewRect.height() <= mPictureRect.height()) {
			pictureTranslateToPoint(mt, cornerType);
		} else if (mImageViewRect.width() > mPictureRect.width()) {
			pictureTranslateCenterHorizontal(mt);
			pictureTranslateCenterVertical(mt);
		} else {
			pictureTranslateCenterVertical(mt);
			pictureTranslateCenterVertical(mt);
		}
	}

	private void pictureTranslateCenterHorizontal(Matrix mt) {
		float[] values = new float[9];
		mt.getValues(values);

		float translateX = (mImageViewRect.width() - mPictureRect.width()) * 0.5f;
		values[2] = translateX;

		float translateY = values[5];

		// 顶部Y的坐标
		float Y1 = values[5];
		float Y2 = Y1 + mPictureRect.height();
		if (Y1 > 0 || Y2 < mImageViewRect.bottom) {
			if (Y1 > 0) {
				translateY = 0;
			} else {
				translateY = mImageViewRect.height() - mPictureRect.height();
			}
		}

		values[5] = translateY;

		mt.setValues(values);
	}

	private void pictureTranslateCenterVertical(Matrix mt) {
		float[] values = new float[9];
		mt.getValues(values);

		float translateY = (mImageViewRect.height() - mPictureRect.height()) * 0.5f;
		values[5] = translateY;

		float translateX = values[2];

		// 顶部Y的坐标
		float X1 = values[2];
		float X2 = X1 + mPictureRect.width();
		if (X1 > 0 || X2 < mImageViewRect.right) {
			if (X1 > 0) {
				translateX = 0;
			} else {
				translateX = mImageViewRect.width() - mPictureRect.width();
			}
		}

		values[2] = translateX;

		mt.setValues(values);
	}

	private void pictureTranslateToPoint(Matrix mt, int cornerType) {
		float[] values = new float[9];
		mt.getValues(values);
		float translateX = 0;
		float translateY = 0;
		switch (cornerType) {
		case LT:
			translateX = 0;
			translateY = 0;
			break;

		case LB:
			translateX = 0;
			translateY = mImageViewRect.height() - mPictureRect.height();
			break;

		case RT:
			translateX = mImageViewRect.width() - mPictureRect.width();
			translateY = 0;
			break;

		case RB:
			translateX = mImageViewRect.width() - mPictureRect.width();
			translateY = mImageViewRect.height() - mPictureRect.height();
			break;

		default:
			break;
		}

		values[2] = translateX;
		values[5] = translateY;
		mt.setValues(values);
	}

	public void setTranslate(float tX, float tY) {
		float nextTranslateX = mBasePointTranslate.x + tX;
		float nextTranslateY = mBasePointTranslate.y + tY;

		float[] values = new float[9];
		mCurrentMatrix.getValues(values);

		float curTranslateX = values[2];
		float curTranslateY = values[5];

		float curImageWidth = mRelatedBitmap.getWidth() * values[0];
		float curImageHeight = mRelatedBitmap.getHeight() * values[0];

		if (curImageWidth <= getWidth()) {
			// 说明原先就居中显示
			nextTranslateX = curTranslateX;
		} else {
			// 说明有足够空间进行左右移动
			if (nextTranslateX > curTranslateX && nextTranslateX > 0) {
				// 向右移动并且越界
				nextTranslateX = 0;
			} else if (nextTranslateX < curTranslateX) {
				// 向左移动
				float nextRight = nextTranslateX + curImageWidth;
				if (nextRight < getWidth()) {
					// 右侧越界
					nextTranslateX = getWidth() - curImageWidth;
				}
			}
		}

		if (curImageHeight <= getHeight()) {
			// 说明原先就居中显示
			nextTranslateY = curTranslateY;
		} else {
			// 说明有足够空间进行左右移动
			if (nextTranslateY > curTranslateY && nextTranslateY > 0) {
				// 向下移动并且越界
				nextTranslateY = 0;
			} else if (nextTranslateY < curTranslateY) {
				// 向上移动
				float nextBottom = nextTranslateY + curImageHeight;
				if (nextBottom < getHeight()) {
					// 下侧越界
					nextTranslateY = getHeight() - curImageHeight;
				}
			}
		}

		values[2] = nextTranslateX;
		values[5] = nextTranslateY;

		mCurrentMatrix.setValues(values);

		SLog.d(TAG, "移位后  Matrix =  " + mCurrentMatrix);
		setImageMatrix(mCurrentMatrix);
	}

	/**
	 * 是否放大显示
	 * 
	 * @return
	 */
	public boolean isZoomIn() {
		if (mRelatedBitmap == null) {
			return false;
		}
		return (!mCurrentMatrix.equals(mOriginMatrix));
	}

	/**
	 * 是否已经靠到最左边，这时可以相应向右滑动
	 * 
	 * @return
	 */
	public boolean isToLeftSide() {
		float[] values = new float[9];
		mCurrentMatrix.getValues(values);

		float imgLeft = values[2];

		if (imgLeft >= 0) {
			return true;
		}

		return false;
	}

	/**
	 * 是否已经靠到最右边，这时可以相应向左滑动
	 * 
	 * @return
	 */
	public boolean isToRightSide() {
		float[] values = new float[9];
		mCurrentMatrix.getValues(values);

		float imgLeft = values[2];
		float imgRight = imgLeft + mRelatedBitmap.getWidth() * values[0];

		if (imgRight <= getWidth()) {
			return true;
		}

		return false;
	}

	/**
	 * 是否已经靠到边
	 * 
	 * @return
	 */
	
	public boolean isToSide(){
		if(isToRightSide() || isToLeftSide()){
			return true;
		}
		return false;
	}
	
	/**
	 * 打印Matrix
	 * 
	 * @param mt
	 */
	private void logMatrix(Matrix mt) {
		mLogIndex++;
		float[] values = new float[9];
		mt.getValues(values);

		SLog.i(TAG, "M[" + mLogIndex + "]: = " + values[0] + "; " + values[1] + "; " + values[2] + ";");
		SLog.i(TAG, "        " + values[3] + "; " + values[4] + "; " + values[5] + ";");
		SLog.i(TAG, "        " + values[6] + "; " + values[7] + "; " + values[8] + ";");

	}

	public void restoreImage() {
		mCurrentMatrix.set(mOriginMatrix);
		setImageMatrix(mCurrentMatrix);
	}
}
