package com.tencent.news.ui;

import android.app.Activity;
import android.os.Bundle;


public abstract class NavActivity extends BaseActivity {

	protected static Boolean isRelateNews = false;
	// 是否是登录，分享等Activity
	protected static Activity mStackActivity;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (isRelateNews) {
			pushActivityStack();
		}
	}

	/**
	 * 
	 * 相关新闻管理多个Activity无限跳转时
	 * 
	 * 销毁访问中间态，只保留结尾Activity
	 * 
	 */
	private void pushActivityStack() {
		if (mStackActivity != null) {
			mStackActivity.finish();
		}
		mStackActivity = this;
	}

	/**
	 * 退出是清空状态位
	 */
	protected void quitActivity() {
		if (isRelateNews) {
			mStackActivity = null;
			isRelateNews = false;
		}
		super.quitActivity();
	}

}
