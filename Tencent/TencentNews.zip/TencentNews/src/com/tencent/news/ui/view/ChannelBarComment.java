package com.tencent.news.ui.view;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.util.AttributeSet;
import android.util.DisplayMetrics;

import com.tencent.news.R;
import com.tencent.news.model.pojo.Channel;
import com.tencent.news.model.pojo.ChannelList;
import com.tencent.news.utils.MobileUtil;


public class ChannelBarComment extends ChannelBarBase {
	public ChannelBarComment(Context context){
		super(context);
	}
	
	public ChannelBarComment(Context context, AttributeSet attrs){
		super(context,attrs);
	}
	
	@Override
	public ChannelList getChannelList(){
		String []comment = getResources().getStringArray(R.array.mycomment);
		ChannelList ChannelList = new ChannelList();
		List<Channel> Channels = new ArrayList<Channel>();
		for(int i = 0; i < comment.length; i++){
			Channel channel = new Channel();
			channel.setChlname(comment[i]);
			Channels.add(channel);
		}
		ChannelList.setChannelList(Channels);
		return ChannelList;
	}

	@Override
	public void onClickSetUp() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object getChannelData() {
		// TODO Auto-generated method stub
		return null;
	}
	
	protected int getChannelNumber(){
		DisplayMetrics dm = MobileUtil.getDeviceDisplayMetrics(mContext);
		return 3;
	}
	
	protected void setChannelWidth(int textChannelWidth){
		mImageBgWidth = MobileUtil.dpToPx(50);
		if(textChannelWidth>mImageBgWidth){
			mImageBgWidth=textChannelWidth+MobileUtil.dpToPx(10);
		}
		mCurrentPosImageBg = (mChannelWidth - mImageBgWidth)/2;
	}
}
