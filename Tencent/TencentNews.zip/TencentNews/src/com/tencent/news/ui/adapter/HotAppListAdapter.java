package com.tencent.news.ui.adapter;

import java.util.ArrayList;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.command.GetImageRequest;
import com.tencent.news.command.GetImageResponse;
import com.tencent.news.config.Constants;
import com.tencent.news.download.APPDownloadListener;
import com.tencent.news.download.DownloadConstants;
import com.tencent.news.download.DownloadDataCheck;
import com.tencent.news.download.DownloadManager;
import com.tencent.news.download.DownloadNetworkState;
import com.tencent.news.download.DownloadNetworkState.NetworkStateListener;
import com.tencent.news.model.pojo.HotAppListItem;
import com.tencent.news.model.pojo.ImageResult;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.system.Application;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.PullRefreshListView;
import com.tencent.news.ui.view.TextProgressBar;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.ThemeSettingsHelper;
//import com.tencent.news.utils.ThemeSettingsHelper;


/**
 * 热门应用
 * @author vincesun
 */


public class HotAppListAdapter extends AbsListAdapter<HotAppListItem> implements GetImageResponse, APPDownloadListener,NetworkStateListener {
	private int downloadState;
	private APPDownloadListener listener;
	private int nProgress;
	private static int mCount;
	private static ListView pListView;
	private static ThemeSettingsHelper pThemeSettingsHelper=null;
	private boolean mConnected;
	private static DownloadNetworkState networkState = null;
	
	public HotAppListAdapter(Context context, ListView listView) {
		this.mContext = context;
		this.mListView = listView;
		mDataList = new ArrayList<HotAppListItem>();
		pListView = listView;
		
		pThemeSettingsHelper = this.themeSettingsHelper;
		((PullRefreshListView) mListView).setSartListener(this);
	}
	
	public void initListener() {
		if (networkState == null) {
			networkState = DownloadNetworkState.g();
			networkState.setContext(Application.getInstance().getApplicationContext());
			networkState.addListener(this);
		}
	}
	
	public int getNetworkType() {
		if (networkState != null) {
			return networkState.getNetworkType();
		}
		return -1;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		HotAppListHolder holder = null;
		int type = getItemViewType(position);
		switch (type) {
		case Constants.TYPE_ITEM_TEXT:
			//暂留接口
			//convertView = setTextMode(convertView, position, holder);
			//break;
		case Constants.TYPE_ITEM_IMAGE:
			convertView = setImageMode(convertView, position,holder);
			break;
		default:
			break;
		}
		return convertView;
	}

	private View setImageMode(View convertView, int position,HotAppListHolder holder) {
		if (convertView == null) {
			holder = new HotAppListHolder();
			
			if (themeSettingsHelper.isNightTheme())
				convertView = LayoutInflater.from(mContext).inflate(R.layout.night_hot_app_list, null);
			else
				convertView = LayoutInflater.from(mContext).inflate(R.layout.hot_app_list, null);
			
			holder.view_hot_app_list = (View) convertView.findViewById(R.id.view_hot_app_list);
			holder.mIcon = (ImageView) convertView.findViewById(R.id.hot_app_icon);
			holder.mTitle = (TextView) convertView.findViewById(R.id.hot_app_txt_title);
			holder.mAbs = (TextView) convertView.findViewById(R.id.hot_app_abs);
			holder.mVer = (TextView) convertView.findViewById(R.id.hot_app_bb);
			holder.mBtn = (TextProgressBar) convertView.findViewById(R.id.updateBtn);
			
			convertView.setTag(holder);
		} else {
			holder = (HotAppListHolder) convertView.getTag();
		}
		
		if (themeSettingsHelper.isNightTheme())
		{
			holder.mTitle.setTextColor(Color.parseColor("#f0f4f8"));
			holder.mAbs.setTextColor(Color.parseColor("#b0b5b8"));
			holder.mVer.setTextColor(Color.parseColor("#b0b5b8"));
		}
		else
		{
			holder.mTitle.setTextColor(Color.parseColor("#414141"));
			holder.mAbs.setTextColor(Color.parseColor("#999999"));
			holder.mVer.setTextColor(Color.parseColor("#999999"));
		}
		
		this.themeSettingsHelper.setViewBackgroudColor(mContext, holder.view_hot_app_list, R.color.page_setting_bg_color);
		
		holder.mBtn.setTextSize(MobileUtil.dpToPx(14));

		HotAppListItem mItem = mDataList.get(position);
		holder.id = mItem.getId();
		holder.packageName = mItem.getApkName();
		initData(mItem, holder);
		if (!((PullRefreshListView) mListView).isBusy()) {
			initImageData(mItem, holder);
		}else{
			GetImageRequest request = new GetImageRequest();
			String url = (mItem.getIcon() != null && mItem.getIcon().length() > 0) ? mItem.getIcon() : "";
			request.setUrl(url);
			request.setTag(holder.id);
			ImageResult result = TaskManager.getLocalPngImage(request, this);
			if (result.isResultOK() && result.getRetBitmap() != null) {
				holder.mIcon.setImageBitmap(result.getRetBitmap());
			} else {
				if(pThemeSettingsHelper.isDefaultTheme()){
					holder.mIcon.setImageResource(R.drawable.default_app_icon);
				}
				else{
					holder.mIcon.setImageResource(R.drawable.night_default_app_icon);
				}
			}
		}
		
		return convertView;
	}

	private void initImageData(HotAppListItem item, HotAppListHolder holder) {
		if(null == item || null == item.getIcon() || item.getIcon().length() == 0){
			return;
		}
		
		GetImageRequest request = new GetImageRequest();
		String url = (item.getIcon() != null && item.getIcon().length() > 0) ? item.getIcon() : "";
		request.setUrl(url);
		request.setTag(item.getId());
		ImageResult result = TaskManager.startPngImageTask(request, this);
		if (result.isResultOK() && result.getRetBitmap() != null) {
			holder.mIcon.setImageBitmap(result.getRetBitmap());
		} else {
			if(pThemeSettingsHelper.isDefaultTheme()){
				holder.mIcon.setImageResource(R.drawable.default_app_icon);
			}
			else{
				holder.mIcon.setImageResource(R.drawable.night_default_app_icon);
			}
		}
	}

	private void initData(final HotAppListItem item, final HotAppListHolder holder) {

		if(item == null) {
			return;
		}
		if (mDataList != null) {
			holder.mTitle.setText(item.getName());
			holder.mAbs.setText(item.getDesc());
			String verTxt = "版本" + item.getVer() + " | " + item.getSize() + "M";
			holder.mVer.setText(verTxt);
			
			int state;
			
			state = DownloadDataCheck.getInstance().checkDBOption(item.getId(),item.getVer(),item.getUrl());
			if(state == DownloadConstants.T_PAUSE){
				nProgress = DownloadDataCheck.getInstance().getUpdateProgress(item.getId());
			}else{
				
				if(state != DownloadConstants.T_INSTALL) {
					nProgress = 0;
					state = DownloadDataCheck.getInstance().checkPackageByLocal(item.getId(), item.getApkName(), item.getVer());
				}else {
					nProgress = 100;
				}
				
			}
			
			holder.state = state;

			txtChange(holder, state, null,nProgress);
			DownloadManager.getInstance().addAppListener(item.getId(),this);
			listener = this;
			
			
			holder.mBtn.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					initListener();
					downloadState = getState(item.getId());
					if(downloadState == DownloadConstants.T_INSTALL || downloadState == DownloadConstants.T_OPEN) {
						
						Log.v("vincesun", "onClick:::::" + text(downloadState) + "==========" + item.getId());
						DownloadManager.getInstance().doStateAction(item.getId(), downloadState,item.getUrl(),item.getApkName(),item.getName(), listener,item.getVer(),true);
					}else{
//						if(!mConnected) {
//							TipsToast.getInstance().showTipsError("网络异常");
//							Log.v("vincesun", String.valueOf(mConnected));}
						if(getNetworkType() != DownloadNetworkState.NETWORK_TYPE_WIFI && downloadState !=DownloadConstants.T_UPDATE_PROGRESS) {
							if(mConnected){
								downloadAlert(item,downloadState,listener);
							}
						}else {
							downloadState = getState(item.getId());
							Log.v("vincesun", "onClick:::::" + text(downloadState) + "==========" + item.getId());
							DownloadManager.getInstance().doStateAction(item.getId(), downloadState,item.getUrl(),item.getApkName(),item.getName(), listener,item.getVer(),true);
						}
					}
					
				}
					
			});
		}
	}
	

	private int getState(String id) {
		int state = 0;
		int countText = mListView.getChildCount();
		for (int i = 0; i < countText; i++) {
			HotAppListHolder viewHolder = (HotAppListHolder) mListView.getChildAt(i).getTag();
			if (viewHolder != null) {
				if (id.equals(viewHolder.id)) {
					state = viewHolder.state;

				}
			}
		}
		return state;
	}

	// test
	private String text(int state) {
		String s = "";
		switch (state) {
		case DownloadConstants.T_DOWNLOAD:
			// 下载
			s = "下载";
			break;
		case DownloadConstants.T_PAUSE:
			// 继续下载
			s = "继续";
			break;
		case DownloadConstants.T_UPDATE:
			// 更新下载
			s = "更新";
			break;
		case DownloadConstants.T_OPEN:
			// 打开应用
			s = "启动";
			break;
		case DownloadConstants.T_INSTALL:
			// 启动安装
			s = "安装";
			break;

		case DownloadConstants.T_UPDATE_PROGRESS:
			// 停止
			// s=progress;
			break;
		default:
			break;
		}
		return s;
	}

	protected static class HotAppListHolder {
		View view_hot_app_list;
		ImageView mIcon;
		TextView mTitle;
		TextView mAbs;
		TextView mVer;
		TextProgressBar mBtn;
		String id;
		int state;
		String packageName;
	}

	@Override
	public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm, String path) {
		switch(imageType){
		case PNG_IMAGE:
			int countImage = mListView.getChildCount();
			for (int i = 0; i < countImage; i++) {
				HotAppListHolder viewHolder = (HotAppListHolder) mListView.getChildAt(i).getTag();
				if (viewHolder != null) {
					if (tag.equals(viewHolder.id)) {
						viewHolder.mIcon.setImageBitmap(bm);
						break;
					}
				}
			}
			break;
		default:
			break;
		}
	}

	@Override
	public void onImageRecvError(ImageType imageType, Object tag, int retCode) {

	}

	@Override
	public void serListViewBusy(int currPosition, int tag) {
		if (currPosition >= 0 && currPosition < mDataList.size()) {
			HotAppListItem item = mDataList.get(currPosition);
			HotAppListHolder holder = (HotAppListHolder) mListView.getChildAt(tag).getTag();
			if(item != null && holder != null) {
				initImageData(item,holder);
			}
			
		}
	}

	@Override
	public void changeStyleMode(int style) {

	}

	@Override
	public void downloadStateChanged(String TAG, int state, int n_progress, String t_progress) {

		int countText = mListView.getChildCount();
		for (int i = 0; i < countText; i++) {
			HotAppListHolder viewHolder = (HotAppListHolder) mListView.getChildAt(i).getTag();
			if (viewHolder != null) {
				if (TAG.equals(viewHolder.id)) {
					Log.v("vincesun", "change============downloadStateChanged" + state);
					txtChange(viewHolder, state, t_progress,n_progress);
					viewHolder.state = state;
					break;
				}
			}
		}
		
	}
	
	public static void packageStateChanged(String packageName,int state,int n_progress, String t_progress) {
		int countText = pListView.getChildCount();
		for (int i = 0; i < countText; i++) {
			HotAppListHolder viewHolder = (HotAppListHolder) pListView.getChildAt(i).getTag();
			if (viewHolder != null) {
				if (packageName.equals("package:"+viewHolder.packageName)) {
					txtChange(viewHolder, state, t_progress,n_progress);
					viewHolder.state = state;
					break;
				}
			}
		}
	}
	
	private static void txtChange(HotAppListHolder viewHolder, int state, String progress, int n_progress) {
		
		if (pThemeSettingsHelper.isNightTheme())
			viewHolder.mBtn.setTextColor(Color.parseColor("#f0f4f8"));
		else
			viewHolder.mBtn.setTextColor(Color.parseColor("#444444"));
		
		switch (state) {
		
			case DownloadConstants.T_DOWNLOAD:
				// 下载
				Log.v("vincesun", "change============txtChange::::下载" );
				
				viewHolder.mBtn.setProgress(0);
				viewHolder.mBtn.setText("下载");
				break;
			case DownloadConstants.T_PAUSE:
				// 继续下载
				Log.v("vincesun", "change============txtChange::::继续下载" );
				viewHolder.mBtn.setProgress(n_progress);
				viewHolder.mBtn.setText("继续");
				break;
			case DownloadConstants.T_UPDATE:
				// 更新下载
				Log.v("vincesun", "change============txtChange::::更新下载" );
				
				if (pThemeSettingsHelper.isNightTheme())
					viewHolder.mBtn.setTextColor(Color.parseColor("#5fabf1"));
				else
					viewHolder.mBtn.setTextColor(Color.rgb(7, 98, 167));
				
				viewHolder.mBtn.setProgress(0);
				viewHolder.mBtn.setText("更新");
				break;
			case DownloadConstants.T_OPEN:
				// 打开应用
				
				if (pThemeSettingsHelper.isNightTheme())
					viewHolder.mBtn.setTextColor(Color.parseColor("#b0b5b8"));
				else
					viewHolder.mBtn.setTextColor(Color.rgb(136, 136, 136));
				
				viewHolder.mBtn.setProgress(0);
				viewHolder.mBtn.setText("启动");
				break;
			case DownloadConstants.T_INSTALL:
				// 启动安装
				viewHolder.mBtn.setProgress(100);
				viewHolder.mBtn.setText("安装");
				break;
	
			case DownloadConstants.T_UPDATE_PROGRESS:
				// 停止
				Log.v("vincesun", "change============txtChange::::进度" +  progress + "======="+String.valueOf(n_progress));
				viewHolder.mBtn.setProgress(n_progress);
				viewHolder.mBtn.setText(progress);
				break;
				
			case DownloadConstants.T_WAIT:
				viewHolder.mBtn.setProgress(0);
				viewHolder.mBtn.setText("等待");
				break;
			default:
				break;
		}
		
	}

	
	
	private void downloadAlert(final HotAppListItem item,final int state,final APPDownloadListener listener) {

		Dialog dialog = new AlertDialog.Builder(mContext)
				.setTitle("下载提示")//
				.setMessage("你的网络为2G/3G网络,下载会消费手机流量,确定下载?")//
				.setPositiveButton("下载", new OnClickListener() {//
							@Override
							public void onClick(DialogInterface dialog,int which) {
								DownloadManager.getInstance().doStateAction(item.getId(), state,item.getUrl(),item.getApkName(),item.getName(), listener,item.getVer(),true);
							}
						}).setNegativeButton("取消", new OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.cancel();
					}
				}).create();
		dialog.show();
	
	}

	@Override
	public void onNetworkConnect(boolean connected) {
		mConnected = connected;
//		if(!connected){
//			TipsToast.getInstance().showTipsError("网络异常");
//		}
	}

}
