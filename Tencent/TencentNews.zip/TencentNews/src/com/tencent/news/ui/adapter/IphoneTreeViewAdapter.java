package com.tencent.news.ui.adapter;

import android.widget.BaseExpandableListAdapter;

public abstract class IphoneTreeViewAdapter extends BaseExpandableListAdapter {
	
}
