package com.tencent.news.ui.view;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.ListView;
import com.tencent.news.utils.SLog;

public class ChatListView extends ListView implements OnScrollListener {
	private final static String TAG = ChatListView.class.getSimpleName();
	private Context mContext;
	private ChatListHeadView mHeadView;
	private OnLoadDateListener mListener;
	private float mLastY;
	private float mY;
	private boolean isCanLoadMore = true;
	private boolean hasMoreData = false;
	
	public ChatListView(Context context) {
		super(context);
		initView(context);
	}

	public ChatListView(Context context, AttributeSet attrs) {
		super(context, attrs);
		initView(context);
	}

	public ChatListView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		initView(context);
	}

	private void initView(Context context){
		this.mContext = context;
		
		mHeadView = new ChatListHeadView(mContext);
		setHeaderDividersEnabled(false);
		setFooterDividersEnabled(false);
		addHeaderView(mHeadView, null, false);
		setOnScrollListener(this);
		/*MobileUtil.measureView(mHeadView);
		mHeight = mHeadView.getMeasuredHeight();*/
	}
	
	public void setOnLoadDateListener(OnLoadDateListener listener){
		this.mListener = listener;
	}
	
	@Override
	public boolean dispatchTouchEvent(MotionEvent ev) {
		final int action = ev.getAction();
		switch (action) {
		case MotionEvent.ACTION_DOWN:
			mY = ev.getY();
			break;
		case MotionEvent.ACTION_MOVE:
			mLastY = ev.getY();
			break;
		case MotionEvent.ACTION_CANCEL:
		case MotionEvent.ACTION_UP:
			break;
		}
		return super.dispatchTouchEvent(ev);
	}
	
	@Override
	public void onScrollStateChanged(AbsListView view, int scrollState) {
		// TODO Auto-generated method stub
	}

	@Override
	public void onScroll(AbsListView view, int firstVisibleItem,
			int visibleItemCount, int totalItemCount) {
		// TODO Auto-generated method stub
		SLog.v(TAG, "onScroll"+firstVisibleItem + isCanLoadMore + hasMoreData);
		
		int mRemainItem = totalItemCount - firstVisibleItem- visibleItemCount;
		
//		Log.i("bush", "firstVisible = " + firstVisibleItem + " mRemain = " + mRemainItem
//                + " getFirstVisible = " + getFirstVisiblePosition() + " can = " + isCanLoadMore
//                + " has more = " + hasMoreData);
		
		if(firstVisibleItem == 0 && mRemainItem != 0 && mLastY-mY > 0 && 
				getFirstVisiblePosition() == 0 && isCanLoadMore && hasMoreData){
			if(mListener != null){
			    Log.i("bush", "List view OnLoadOldDate");
				mListener.OnLoadOldDate();
			}
			isCanLoadMore = false;
		}
	}
	
	public void setHeadViewAddMore(boolean hasMoreData){
		isCanLoadMore = true;
		this.hasMoreData = hasMoreData;
		if (hasMoreData == false) {
		    Log.i("bush", "headview invisible");
			mHeadView.setPadding(0, -1 * mHeadView.getMeasuredHeight(), 0, 0);
		} else {
		    Log.i("bush", "headview visible");
			mHeadView.setPadding(0, 0, 0, 0);
		}
	}
	
	public interface OnLoadDateListener{
		public void OnLoadOldDate();
	}
}
