
package com.tencent.news.ui.view;

import android.R.bool;
import android.content.Context;
import android.util.AttributeSet;

import com.tencent.news.system.observable.SettingObservable;

/**
 * @author jianhu
 * @version 创建时间：2013-7-1 下午5:48:17 类说明 包含登录bar的下拉刷新ListView
 */
public class FavoritesPullRefreshListView extends PullRefreshListView {

    private Context mContext;
    private boolean hasLogin = false;
    private FavoritesLoginBar mLoginView = null;

    public FavoritesPullRefreshListView(Context context) {
        super(context);
        this.mContext = context;
    }

    public FavoritesPullRefreshListView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mContext = context;
    }

    public FavoritesPullRefreshListView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mContext = context;
    }

    @Override
    public void initView() {
        // TODO Auto-generated method stub
        super.initView();
        mLoginView = new FavoritesLoginBar(mContext);
    }

    public void setLoginButtonClickedListener(OnClickListener listener) {
        mLoginView.setBtnLoginClickListener(listener);
    }

    @Override
    public void setFootViewAddMore(boolean isAutoLoading, boolean hasMoreData, boolean isNeedRetry) {
        // TODO Auto-generated method stub
        isCanLoadMore = true;
        this.hasMoreData = hasMoreData;
        this.isNeedRetry = isNeedRetry;
        this.isAutoLoading = true;
        if (this.getFooterViewsCount() <= 0) {
            this.addFooterView(mFootView, null, false);
        }
        if (isNeedRetry) {
            mFootView.setErrorMsg();
            isCanLoadMore = false;
        } else {
            if (!hasMoreData) {
                try {
                    mFootView.showComplete();
                    /* this.removeFooterView(mFootView); */
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                if (!this.isAutoLoading) {
                    mFootView.showManualMessage();
                } else {
                    mFootView.showLoadingBar();
                }
                if (this.getFooterViewsCount() <= 0) {
                    this.addFooterView(mFootView, null, false);
                }
            }
        }
    }

    @Override
    public void Clear() {
        // TODO Auto-generated method stub
        super.Clear();
    }

    @Override
    public void applyPullRefreshViewTheme() {
        // TODO Auto-generated method stub
        super.applyPullRefreshViewTheme();
    }

    public void setHasLogin(boolean hasLogin) {
        this.hasLogin = hasLogin;
        if (mLoginView != null) {
            if (!this.hasLogin) {
                addFooterView(mLoginView);
            } else {
                removeFooterView(mLoginView);
            }
        }
    }
    
    public void setLoginBtnEnable(boolean isEnable){
        mLoginView.setLoginBtnEnable(isEnable);
    }

}
