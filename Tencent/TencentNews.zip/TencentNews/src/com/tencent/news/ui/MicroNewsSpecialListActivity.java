package com.tencent.news.ui;

import android.content.Intent;
import android.net.Uri;

import com.tencent.news.api.TencentNews;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.pojo.ItemsByLoadMore;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.omg.webdev.WebDev;

/**
 * 腾讯专题
 * 
 * @author jackiecheng
 * 
 */
public class MicroNewsSpecialListActivity extends AbsSpecialListActivity {
	private String mId;
	private String mType;

	protected void loading() {
		HttpDataRequest request = TencentNews.getInstance().getQQNewsListItems(mId, mChannel);
		TaskManager.startHttpDataRequset(request, this);
	}

	@Override
	protected void getDataIntent(Intent intent) {
		// TODO Auto-generated method stub
		if (intent != null) {
			Uri data = intent.getData();
			mId = data.getQueryParameter("nm");
			mType = data.getQueryParameter("type");
			mChannel = data.getQueryParameter("chlid");
			// mTitleText = "腾讯专题";
		}
	}

	@Override
	public void onHttpRecvOK(HttpTag tag, Object result) {
		super.onHttpRecvOK(tag, result);
		if (tag.equals(HttpTag.NEWS_LIST_ITEMS)) {
			ItemsByLoadMore mItemsByLoadMore = (ItemsByLoadMore) result;
			if (mItemsByLoadMore != null && mItemsByLoadMore.getNewslist() != null) {
				mItem = mItemsByLoadMore.getNewslist()[0];
				mSpecialNewsIds = mItem.getId();
				getSpecialNewsList(mSpecialNewsIds, mChannel);
			}
		}
	}

	@Override
	public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {
		if (tag.equals(HttpTag.NEWS_LIST_ITEMS)) {
			TipsToast.getInstance().showTipsError(msg);
			loadItemError = true;
			showState(ERROR);
		}
	}

	@Override
	protected void quit() {
		// TODO Auto-generated method stub
		if (mType.equals("0")) {
			quitActivity();
		} else {
			Intent intent = new Intent();
			intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			intent.setClass(this, MainActivity.class);
			startActivity(intent);
			quitActivity();
		}
	}

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}
}
