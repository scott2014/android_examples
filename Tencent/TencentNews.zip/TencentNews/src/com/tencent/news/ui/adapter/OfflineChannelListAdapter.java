package com.tencent.news.ui.adapter;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.shareprefrence.SpNewsHadRead;
import com.tencent.news.utils.StringUtil;

public class OfflineChannelListAdapter extends AbsListAdapter<Item> {

	public OfflineChannelListAdapter(Context context, ListView listView, List<Item> offLineData) {
		mContext = context;
		mDataList = offLineData;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		return setTextMode(convertView, position, null);
	}

	protected static class ViewHolder {
		public TextView title;
		TextView stract;
		TextView comments;
		ImageView comments_icon;
		ImageView flag;
		String id;
	}

	private View setTextMode(View convertView, int position, ViewHolder holder) {
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = LayoutInflater.from(mContext).inflate(R.layout.news_list_text_item, null);	
			holder.title = (TextView) convertView.findViewById(R.id.list_title_text);
			holder.stract = (TextView) convertView.findViewById(R.id.list_abstract_text);
			holder.comments = (TextView) convertView.findViewById(R.id.list_comments_text);
			holder.comments_icon = (ImageView) convertView.findViewById(R.id.list_comments_image);
			holder.flag = (ImageView) convertView.findViewById(R.id.list_item_flag);
			
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		applyThemeInItem(holder);
		
		Item item = (Item) mDataList.get(position);
		if (item != null) {
			
			if (SpNewsHadRead.isNewsHadRead(item.getId())) {
				if(themeSettingsHelper.isNightTheme()){
					holder.title.setTextColor(mContext.getResources().getColor(R.color.night_readed_news_title_color));
				}else{
					holder.title.setTextColor(mContext.getResources().getColor(R.color.readed_news_title_color));
				}
			} else {
				if(themeSettingsHelper.isNightTheme()){
					holder.title.setTextColor(mContext.getResources().getColor(R.color.night_list_title_color));
				}else{
					holder.title.setTextColor(mContext.getResources().getColor(R.color.list_title_color));
				}				
			}	
			
			holder.title.setText(StringUtil.replaceBlank(item.getTitle()));

			String stract = null;
			if (item.getBstract() != null) {
				stract = item.getBstract().trim();
				if (stract.length() > 30) {
					stract = stract.substring(0, 30);
				}
			}
			stract = StringUtil.replaceBlank(stract);
			stract = StringUtil.StringFilter(stract);
			holder.stract.setText(stract);
			
			if (Integer.parseInt(item.getCommentNum()) > 10000) {
				holder.comments.setText(StringUtil.tenTh2wan(item.getCommentNum()));
			} else {
				holder.comments.setText(item.getCommentNum());
			}
			
			setItemFlag(holder, item.getFlag());
			
			themeSettingsHelper.setImageViewSrc(mContext, holder.comments_icon, R.drawable.list_item_comment_icon);
		}
		return convertView;
	}
	
	public void applyThemeInItem(ViewHolder holder){
		if(holder==null){
			return;
		}
		
		if(themeSettingsHelper.isNightTheme()){//设置夜间模式图标和字体颜色	
			if(holder.title!=null){
				holder.title.setTextColor(mContext.getResources().getColor(R.color.night_list_title_color));
			}
			if(holder.stract!=null){
				 holder.stract.setTextColor(mContext.getResources().getColor(R.color.night_list_abstract_color));
			}			
			if(holder.comments!=null){
				holder.comments.setTextColor(mContext.getResources().getColor(R.color.night_list_comment_color));
			}
		}
		else{
			if(holder.title!=null){
				holder.title.setTextColor(mContext.getResources().getColor(R.color.list_title_color));
			}
			if(holder.stract!=null){
				 holder.stract.setTextColor(mContext.getResources().getColor(R.color.list_abstract_color));
			}			
			if(holder.comments!=null){
				holder.comments.setTextColor(mContext.getResources().getColor(R.color.list_comment_color));
			}
		}
	}
	
	private void setItemFlag(ViewHolder holder, String flag) {
		if (flag == null || "0".equals(flag) ) {
			holder.flag.setVisibility(View.GONE);
		} else {
			holder.flag.setVisibility(View.VISIBLE);
			if(themeSettingsHelper.isNightTheme()){
				setNightFlagIcon(holder.flag, flag);
			}else{
				setFlagIcon(holder.flag, flag);
			}
		}
	}
	
	private void setFlagIcon(ImageView imgView,String flag){			
		if ("1".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_scoop_icon);
		} else if ("2".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_tote_icon);
		} else if ("3".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_video_icon);
		} else if ("4".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_special_icon);
		} else if ("5".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_flash_icon);
		} else if ("6".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_live_icon);
		} else if ("7".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.flag_redian);
		}
	}
	
	private void setNightFlagIcon(ImageView imgView,String flag){			
		if ("1".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_scoop_icon);
		} else if ("2".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_tote_icon);
		} else if ("3".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_video_icon);
		} else if ("4".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_special_icon);
		} else if ("5".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_flash_icon);
		} else if ("6".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_live_icon);
		} else if ("7".equals(flag)) {
			imgView.setBackgroundResource(R.drawable.night_flag_redian);
		}
	}

	@Override
	public void changeStyleMode(int style) {
		this.styleType = style;
		notifyDataSetChanged();
	}

	@Override
	public void serListViewBusy(int currPosition, int tag) {
	}
}
