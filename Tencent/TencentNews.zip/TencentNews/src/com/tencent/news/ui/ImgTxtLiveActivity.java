package com.tencent.news.ui;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.SparseIntArray;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.animation.AlphaAnimation;
import android.view.animation.LinearInterpolator;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.ScrollView;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.boss.SpeedTest;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.pojo.ImgTxtLive;
import com.tencent.news.model.pojo.ImgTxtLiveImageIndex;
import com.tencent.news.model.pojo.ImgTxtLiveInfo;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.system.AddCommentBroadcastReceiver;
import com.tencent.news.system.RefreshCommentNumBroadcastReceiver;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.adapter.ImgTxtLiveAdapter;
import com.tencent.news.ui.adapter.ViewPagerAdapter;
import com.tencent.news.ui.view.CommentView;
import com.tencent.news.ui.view.MaxWidthHeightLinearLayout;
import com.tencent.news.ui.view.PullRefreshListView;
import com.tencent.news.ui.view.PullRefreshListView.OnClickFootViewListener;
import com.tencent.news.ui.view.PullRefreshListView.OnRefreshListener;
import com.tencent.news.ui.view.PullRefreshListView.OnScrollPositionListener;
import com.tencent.news.ui.view.PullToRefreshFrameLayout;
import com.tencent.news.ui.view.ShareDialog;
import com.tencent.news.ui.view.ViewPagerEx;
import com.tencent.news.ui.view.WritingCommentView;
import com.tencent.news.ui.view.WritingCommentView.OnChangeClick;
import com.tencent.news.utils.IntentUtil;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.ThemeSettingsHelper.ThemeCallback;
import com.tencent.omg.webdev.WebDev;

/**
 * 图文直播
 * 
 * @author jackiecheng
 * 
 */
public class ImgTxtLiveActivity extends NavActivity implements OnClickListener,ThemeCallback {

	static Handler mAutoLoadHandler;

	int startIdRefreshUninsertBoundary;
	List<ImgTxtLiveInfo> autoRefreshCacheData;
	int mCurrentPage = 0;
	private ViewPagerEx mViewPager;
	private List<View> mViews = new ArrayList<View>();
	WritingCommentView mWritingCommentView;

	ImageButton activity_imgtxt_title_share;
	CommentView mCommentView;
	View activity_imgtxt_title = null;
	TextView mImgTxtLiveTitle = null;
	MaxWidthHeightLinearLayout mImgTxtLiveSummary = null;
	TextView mImgTxtLiveSummaryContent = null;
	TextView mImgTxtLiveSummaryContentCopy = null;
	ScrollView imgtxtlive_summary_sc;
	TextView mFloatTime = null;

	// RotateAnimation imgtxtlivesummaryArrowAnim;
	// RotateAnimation imgtxtlivesummaryArrowAnim2;

	AlphaAnimation shouqiAlpha;
	AlphaAnimation zhankaiAlpha;

	ImageView activity_imgtxt_title_show_new_data_tips = null;
	// ImageView imgtxtlivesummary_arrow = null;
	int mImgTxtLiveSummaryHeight = 0;

	boolean isActivityLoading = true;

	View img_txt_live_loading = null;
	View img_txt_live_failed = null;

	ImgTxtLive itlFromNet = null;

	PullToRefreshFrameLayout mPullToRefreshFrameLayout = null;
	PullRefreshListView mListView = null;
	ImgTxtLiveAdapter mImgTxtLiveAdapter = null;
	List<ImgTxtLiveInfo> data;

	private static final String IMGTXTLIVE = "ImgTxtLive";

	private static final int refresh_summay_height = 330;

	private static final int retract_start = 0;
	private static final int retract_ing = 1;
	private static final int retract_end = 2;

	private static final int retract_start2 = 20;
	private static final int retract_ing2 = 21;
	private static final int retract_end2 = 22;

	private static final int retract_title_start = 3;
	private static final int retract_title_ing = 4;
	private static final int retract_title_end = 5;
	// private static final int retract_title_no_summary = 225;

	private static final int spread_title_start = 6;
	private static final int spread_title_ing = 7;
	private static final int spread_title_end = 8;

	private static final int spread_start = 9;
	private static final int spread_ing = 10;
	private static final int spread_end = 11;

	private static final int load_data_start = 12;
	private static final int load_data_ing = 13;
	private static final int load_data_end = 14;

	private static final int autoLoad = 15;

	int titlekuozhangshouqitop = 0;

	int summarykuozhangshouqitop = 0;

	int summarySpeed = 20;
	int titleSpeed = 20;

	int titlePaddingLeftFromxml;
	int titlePaddingTopFromxml;
	int titlePaddingRightFromxml;
	int titlePaddingBottomFromxml;

	int v3PaddingLeftFromxml;
	int v3PaddingTopFromxml;
	int v3PaddingRightFromxml;
	int v3PaddingBottomFromxml;

	/**
	 * 是否已经收起 false: 是展开的 true: 收起的
	 */
	private boolean isShowQi = false;
	/**
	 * 需要恢复title的bottom
	 */
	private boolean isNeedReloadBottom = false;
	/**
	 * 正在收起标题
	 */
	private boolean isShowQiTitleIng = false;
	/**
	 * 正在收起
	 */
	private boolean isShowQiIng = false;
	/**
	 * 正在展开标题
	 */
	private boolean isZhanKaiTitleIng = false;
	/**
	 * 正在展开
	 */
	private boolean isZhanKaiIng = false;
	/**
	 * 正在加载数据
	 */
	private boolean isLoading = false;
	/**
	 * 是否还有旧数据
	 */
	private boolean haveNoOldData = false;
	/**
	 * 是否可以自动加载
	 */
	private boolean isCanAutoLoad = true;

	private boolean canWork = true;

	private int delayMillis = 10000;

	LayoutParams lpTitle = new LayoutParams(0, 0);
	LayoutParams lpSummary = new LayoutParams(0, 0);

	private boolean isGoOnEnterActivityGetData = false;
	private String firstId = null;
	private String lastId = null;
	private String summeryVersion = "0";
	private String zhiboId = "0";// "4979";// "4636";// "4755";// 4636

	private String newsTitle;
	private Item item = null;

	private OnClickListener mImageOnClickListener = null;

	// for read broadcast
	private String mChild = null;
	private Item mItem = null;
	private String mClickPosition = null;
	private boolean isSpecial = false;

	private SparseIntArray imageIndex2position = null;
	private Button mBackBtn;
	
	
	//夜间模式
	private RelativeLayout activity_imgtxt_title_btn_click = null, imgtxtliveactivity_layout = null;
	private TextView activity_imgtxt_title_str = null, img_txt_live_failed_textview = null;
	private ImageView activity_imgtxt_title_refresh = null, img_txt_live_failed_imageview = null, img_txt_live_loading_color_imageview= null;
	private View mMask;
	///
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_imgtxtlive);

		Intent i = getIntent();
		if (i != null) {
			item = (Item) i.getSerializableExtra(Constants.NEWS_DETAIL_KEY);
			newsTitle = item.getTitle();
			zhiboId = item.getGraphicLiveID();
		}

		initView();
		initListener();
		initData();

		enterActivityShowLoading();
		enterActivityLoadNewData();
		registerBroadReceiver();
	}

	private void setupAutoLoadHandler() {
		if (mAutoLoadHandler == null) {
			mAutoLoadHandler = new Handler() {
				@Override
				public void handleMessage(Message msg) {
					SLog.i("CJZ", "开始自动刷新");
					if (mAutoLoadHandler != null && isCanAutoLoad) {
						mAutoLoadHandler.removeMessages(autoLoad);
						if (isLoading) {
							return;
						}
						SLog.i("CJZ", "真的开始自动刷新!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
						if (isGoOnEnterActivityGetData) {
							enterActivityLoadNewData();
						} else {
							autoGetNewData(firstId);
						}
					}
					super.handleMessage(msg);
				}
			};
		}
		mAutoLoadHandler.sendEmptyMessageDelayed(autoLoad, delayMillis);
	}

	@Override
	protected void onResume() {
		super.onResume();
		 WebDev.onResume(this); 
		isCanAutoLoad = true;
		setupAutoLoadHandler();
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this); 
		
		isCanAutoLoad = false;

		if (mAutoLoadHandler != null) {
			mAutoLoadHandler = null;
		}
	}

	@Override
	protected void onDestroy() {

		if (receiver != null) {
			try {
				unregisterReceiver(receiver);
			} catch (Exception e) {
				SLog.e(e.toString());
			}
		}
		if (receiver != null) {
			try {
				unregisterReceiver(mRefreshCommentReceiver);
			} catch (Exception e) {
				SLog.e(e.toString());
			}
		}

		isCanAutoLoad = false;

		if (mAutoLoadHandler != null) {
			mAutoLoadHandler = null;
		}
		super.onDestroy();
	}

	Handler mTitleHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {

			switch (msg.what) {

			case retract_title_start:
				mTitleHandler.removeMessages(retract_title_start);

				if (isShowQiTitleIng) {
					break;
				}

				titlePaddingLeftFromxml = mImgTxtLiveTitle.getPaddingLeft();
				titlePaddingTopFromxml = mImgTxtLiveTitle.getPaddingTop();
				titlePaddingRightFromxml = mImgTxtLiveTitle.getPaddingRight();
				if (!isNeedReloadBottom) {
					titlePaddingBottomFromxml = mImgTxtLiveTitle.getPaddingBottom();
				}

				titlekuozhangshouqitop = titlePaddingTopFromxml;

				mTitleHandler.sendEmptyMessage(retract_title_ing);

				break;

			case retract_title_ing:
				mTitleHandler.removeMessages(retract_title_ing);

				isShowQiTitleIng = true;

				SLog.i("CJZ", SLog.getTraceInfo() + "---->" + titlekuozhangshouqitop);

				titlekuozhangshouqitop = titlekuozhangshouqitop - titleSpeed;

				if (titlekuozhangshouqitop <= 0) {
					mTitleHandler.sendEmptyMessage(retract_title_end);
				} else {
					mImgTxtLiveTitle.setPadding(titlePaddingLeftFromxml, titlePaddingTopFromxml, titlePaddingRightFromxml, titlekuozhangshouqitop);
					mImgTxtLiveTitle.setLayoutParams(lpTitle);
					mTitleHandler.sendEmptyMessageDelayed(retract_title_ing, 10);
				}
				break;
			case retract_title_end:

				mImgTxtLiveTitle.setPadding(titlePaddingLeftFromxml, titlePaddingTopFromxml, titlePaddingRightFromxml, 0);
				mImgTxtLiveTitle.setLayoutParams(lpTitle);
				isShowQiTitleIng = false;

				break;

			case spread_title_start:
				mTitleHandler.removeMessages(spread_title_start);

				if (isZhanKaiTitleIng) {
					break;
				}

				titlekuozhangshouqitop = 0;

				mTitleHandler.sendEmptyMessage(spread_title_ing);

				break;

			case spread_title_ing:
				mTitleHandler.removeMessages(spread_title_ing);

				isZhanKaiTitleIng = true;

				SLog.i("CJZ", SLog.getTraceInfo() + "---->" + titlekuozhangshouqitop);

				titlekuozhangshouqitop = titlekuozhangshouqitop + titleSpeed;

				if (titlekuozhangshouqitop >= titlePaddingTopFromxml) {
					mTitleHandler.sendEmptyMessage(spread_title_end);
				} else {
					mImgTxtLiveTitle.setPadding(titlePaddingLeftFromxml, titlePaddingTopFromxml, titlePaddingRightFromxml, titlekuozhangshouqitop);
					mImgTxtLiveTitle.setLayoutParams(lpTitle);
					mTitleHandler.sendEmptyMessageDelayed(spread_title_ing, 8);
				}
				break;
			case spread_title_end:

				mImgTxtLiveTitle.setPadding(titlePaddingLeftFromxml, titlePaddingTopFromxml, titlePaddingRightFromxml, titlePaddingBottomFromxml);
				mImgTxtLiveTitle.setLayoutParams(lpTitle);
				isZhanKaiTitleIng = false;

				mHandler.sendEmptyMessage(spread_start);

				break;
			}
		}
	};

	Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {

			switch (msg.what) {

			case refresh_summay_height:
				lpSummary.width = LayoutParams.FILL_PARENT;

				SLog.i("CJZ", "summary高度:" + mImgTxtLiveSummaryContentCopy.getHeight());

				lpSummary.height = mImgTxtLiveSummaryContentCopy.getHeight();
				RelativeLayout.LayoutParams rlrefresh_summay_height = (RelativeLayout.LayoutParams) (mImgTxtLiveSummary.getLayoutParams());
				lpSummary.setMargins(rlrefresh_summay_height.leftMargin, 0, rlrefresh_summay_height.rightMargin, 0);
				mImgTxtLiveSummary.setLayoutParams(lpSummary);

				break;
			case retract_start:
				mHandler.removeMessages(retract_start);

				imgtxtlive_summary_sc.setVerticalFadingEdgeEnabled(false);

				activity_imgtxt_title.bringToFront();
				mImgTxtLiveTitle.bringToFront();

				mListView.setHasHeader(false);// 因为有下拉刷新,防抖动

				mImgTxtLiveSummaryHeight = mImgTxtLiveSummaryContentCopy.getHeight();
				mImgTxtLiveSummary.setAnimation(shouqiAlpha);
				mImgTxtLiveSummary.startAnimation(shouqiAlpha);
				// imgtxtlivesummary_arrow.startAnimation(imgtxtlivesummaryArrowAnim);

				lpSummary.width = LayoutParams.FILL_PARENT;
				lpSummary.height = mImgTxtLiveSummaryHeight;
				summarykuozhangshouqitop = mImgTxtLiveSummaryHeight;
				RelativeLayout.LayoutParams rl = (RelativeLayout.LayoutParams) (mImgTxtLiveSummary.getLayoutParams());
				lpSummary.setMargins(rl.leftMargin, 0, rl.rightMargin, 0);

				mHandler.sendEmptyMessage(retract_ing);

				break;
			case retract_ing:
				mHandler.removeMessages(retract_ing);

				isShowQiIng = true;

				summarykuozhangshouqitop = summarykuozhangshouqitop - summarySpeed;

				if (summarykuozhangshouqitop < 0) {
					mHandler.sendEmptyMessage(retract_end);
				} else {
					lpSummary.height = summarykuozhangshouqitop;
					mImgTxtLiveSummary.setLayoutParams(lpSummary);
					mHandler.sendEmptyMessageDelayed(retract_ing, 8);
				}

				break;
			case retract_end:

				isShowQiIng = false;
				isShowQi = true;// 是否收起,是

				summarykuozhangshouqitop = 0;
				lpSummary.height = summarykuozhangshouqitop;
				mImgTxtLiveSummary.setLayoutParams(lpSummary);
				mImgTxtLiveSummary.setVisibility(View.GONE);

				// mTitleHandler.sendEmptyMessage(retract_title_start);

				break;

			case retract_start2:
				mHandler.removeMessages(retract_start);

				activity_imgtxt_title.bringToFront();
				mImgTxtLiveTitle.bringToFront();

				mListView.setHasHeader(false);// 因为有下拉刷新,防抖动

				mImgTxtLiveSummaryHeight = mImgTxtLiveSummaryContentCopy.getHeight();
				mImgTxtLiveSummary.setAnimation(shouqiAlpha);
				mImgTxtLiveSummary.startAnimation(shouqiAlpha);
				// imgtxtlivesummary_arrow.startAnimation(imgtxtlivesummaryArrowAnim);

				lpSummary.width = LayoutParams.FILL_PARENT;
				lpSummary.height = mImgTxtLiveSummaryHeight;
				RelativeLayout.LayoutParams rl2 = (RelativeLayout.LayoutParams) (mImgTxtLiveSummary.getLayoutParams());
				lpSummary.setMargins(rl2.leftMargin, 0, rl2.rightMargin, 0);

				mHandler.sendEmptyMessage(retract_ing);

				mTitleHandler.sendEmptyMessage(retract_title_start);

				break;
			case retract_ing2:
				mHandler.removeMessages(retract_ing);

				isShowQiIng = true;

				summarykuozhangshouqitop = summarykuozhangshouqitop - summarySpeed;

				if (summarykuozhangshouqitop <= -mImgTxtLiveSummaryHeight) {
					mHandler.sendEmptyMessage(retract_end);
				} else {
					mImgTxtLiveSummary.setPadding(v3PaddingLeftFromxml, summarykuozhangshouqitop, v3PaddingRightFromxml, v3PaddingBottomFromxml);
					mImgTxtLiveSummary.setLayoutParams(lpSummary);
					mHandler.sendEmptyMessageDelayed(retract_ing, 10);
				}

				break;
			case retract_end2:

				isShowQiIng = false;
				isShowQi = true;// 是否收起,是

				// titlePaddingLeftFromxml = mImgTxtLiveTitle.getPaddingLeft();
				// titlePaddingTopFromxml = mImgTxtLiveTitle.getPaddingTop();
				// titlePaddingRightFromxml =
				// mImgTxtLiveTitle.getPaddingRight();
				// titlePaddingBottomFromxml =
				// mImgTxtLiveTitle.getPaddingBottom();
				//
				// mImgTxtLiveTitle.setPadding(titlePaddingLeftFromxml,
				// titlePaddingTopFromxml, titlePaddingRightFromxml, 0);

				mImgTxtLiveSummary.setLayoutParams(lpSummary);
				mImgTxtLiveSummary.setVisibility(View.GONE);
				summarykuozhangshouqitop = -mImgTxtLiveSummaryHeight;

				// int h = mImgTxtLiveTitle.getHeight();
				// // mImgTxtLiveTitle.setText("收起之后标题");
				// mImgTxtLiveTitle.setHeight(h);

				break;

			case spread_start:
				mHandler.removeMessages(spread_start);

				mImgTxtLiveSummary.setVisibility(View.VISIBLE);
				summarykuozhangshouqitop = 0;

				mImgTxtLiveSummaryHeight = mImgTxtLiveSummaryContentCopy.getHeight();

				mImgTxtLiveSummary.setAnimation(zhankaiAlpha);
				mImgTxtLiveSummary.startAnimation(zhankaiAlpha);
				// imgtxtlivesummary_arrow.startAnimation(imgtxtlivesummaryArrowAnim2);

				mHandler.sendEmptyMessage(spread_ing);

				break;
			case spread_ing:
				mHandler.removeMessages(spread_ing);

				isZhanKaiIng = true;
				summarykuozhangshouqitop = summarykuozhangshouqitop + summarySpeed;

				if (summarykuozhangshouqitop >= mImgTxtLiveSummaryHeight) {
					mHandler.sendEmptyMessage(spread_end);
				} else {
					lpSummary.height = summarykuozhangshouqitop;
					mImgTxtLiveSummary.setLayoutParams(lpSummary);
					mHandler.sendEmptyMessageDelayed(spread_ing, 8);
				}

				break;
			case spread_end:
				isZhanKaiIng = false;
				isShowQi = false;// 是否收起,否

				// titlePaddingLeftFromxml = mImgTxtLiveTitle.getPaddingLeft();
				// titlePaddingTopFromxml = mImgTxtLiveTitle.getPaddingTop();
				// titlePaddingRightFromxml =
				// mImgTxtLiveTitle.getPaddingRight();
				//
				// mImgTxtLiveTitle.setPadding(titlePaddingLeftFromxml,
				// titlePaddingTopFromxml, titlePaddingRightFromxml,
				// titlePaddingBottomFromxml);

				lpSummary.height = mImgTxtLiveSummaryHeight;
				mImgTxtLiveSummary.setLayoutParams(lpSummary);
				mListView.setHasHeader(true);
				// imgtxtlive_summary_sc.setVerticalFadingEdgeEnabled(true);

				break;

			case load_data_start:

				if (itlFromNet.getFirstId() != null) {
					firstId = itlFromNet.getFirstId();
				}

				// 方案3:
				if (mCurrentPage == 0 && mListView.getFirstVisiblePosition() == 0 /*&& mListView.mCurrentState == ListState.INIT_STATE*/) {
					mHandler.sendEmptyMessageDelayed(load_data_ing, 10);
				} else {

					autoRefreshCacheData.addAll(0, itlFromNet.array2List(startIdRefreshUninsertBoundary + 1));

					activity_imgtxt_title_show_new_data_tips.setVisibility(View.VISIBLE);
				}

				break;
			case load_data_ing:

				mImgTxtLiveAdapter.addDataListBefore(autoRefreshCacheData);// 在整个数据的开始加入缓存的新数据
				mImgTxtLiveAdapter.addDataListBefore(itlFromNet.array2List(startIdRefreshUninsertBoundary + 1));// 在整个数据的开始加入新数据

				mImgTxtLiveAdapter.setNewSeq(startIdRefreshUninsertBoundary);

				mImgTxtLiveAdapter.notifyDataSetChanged();
				mListView.setSelection(autoRefreshCacheData.size() + itlFromNet.getInfo().length + 1);
				autoRefreshCacheData.clear();

				mHandler.sendEmptyMessage(load_data_end);

				break;
			case load_data_end:

				try {
					smoothScrollToPosition(0);
				} catch (Exception e) {
					e.printStackTrace();
					mListView.setSelection(0);
				}

				initFloatTime();

				try {
					startIdRefreshUninsertBoundary = Integer.parseInt(firstId);
				} catch (Exception e) {
					startIdRefreshUninsertBoundary = Integer.MAX_VALUE;// 所有的不变黄
				}

				activity_imgtxt_title_show_new_data_tips.setVisibility(View.GONE);

				break;

			default:
				break;
			}

			super.handleMessage(msg);
		}

	};

	private void initView() {

		this.getIntentData(getIntent());
		//夜间模式
		activity_imgtxt_title_btn_click = (RelativeLayout) findViewById(R.id.activity_imgtxt_title_btn_click);
		activity_imgtxt_title_str = (TextView) findViewById(R.id.activity_imgtxt_title_str);
		activity_imgtxt_title_refresh = (ImageView) findViewById(R.id.activity_imgtxt_title_refresh);
		img_txt_live_failed_imageview = (ImageView) findViewById(R.id.img_txt_live_failed_imageview);
		img_txt_live_failed_textview = (TextView) findViewById(R.id.img_txt_live_failed_textview);
		img_txt_live_loading_color_imageview = (ImageView) findViewById(R.id.img_txt_live_loading_color_imageview);
		mMask = (View)findViewById(R.id.mask_view);
		
		//

		activity_imgtxt_title = findViewById(R.id.activity_imgtxt_title);
		mBackBtn = (Button) findViewById(R.id.activity_imgtxt_title_btn_back);
		setTitleBackName();

		View v = LayoutInflater.from(this).inflate(R.layout.view_imgtxtlive, null);
		//
		imgtxtliveactivity_layout = (RelativeLayout) v.findViewById(R.id.imgtxtliveactivity_layout);
		//
		mImgTxtLiveTitle = (TextView) v.findViewById(R.id.imgtxtlive_title);
		mImgTxtLiveSummary = (MaxWidthHeightLinearLayout) v.findViewById(R.id.imgtxtlive_summary);
		mImgTxtLiveSummaryContent = (TextView) v.findViewById(R.id.imgtxtlivesummary_content);
		mImgTxtLiveSummaryContentCopy = (TextView) v.findViewById(R.id.imgtxtlivesummary_content_copy);
		imgtxtlive_summary_sc = (ScrollView) v.findViewById(R.id.imgtxtlive_summary_sc);
		mFloatTime = (TextView) v.findViewById(R.id.live_float_time);
		mPullToRefreshFrameLayout = (PullToRefreshFrameLayout) v.findViewById(R.id.live_listview);

		v3PaddingLeftFromxml = mImgTxtLiveSummary.getPaddingLeft();
		v3PaddingTopFromxml = mImgTxtLiveSummary.getPaddingTop();
		v3PaddingRightFromxml = mImgTxtLiveSummary.getPaddingRight();
		v3PaddingBottomFromxml = mImgTxtLiveSummary.getPaddingBottom();

		activity_imgtxt_title_show_new_data_tips = (ImageView) findViewById(R.id.activity_imgtxt_title_show_new_data_tips);

		shouqiAlpha = new AlphaAnimation(1.0f, 0.0f);
		shouqiAlpha.setInterpolator(new LinearInterpolator());
		shouqiAlpha.setDuration(500);
		shouqiAlpha.setFillAfter(true);

		zhankaiAlpha = new AlphaAnimation(0.0f, 1.0f);
		zhankaiAlpha.setInterpolator(new LinearInterpolator());
		zhankaiAlpha.setDuration(500);
		zhankaiAlpha.setFillAfter(true);

		mListView = mPullToRefreshFrameLayout.getPullToRefreshListView();
		mListView.setSelector(R.drawable.img_txt_live_list_selector);
		mListView.setPullTimeTag(IMGTXTLIVE);

		// mCommentBar.init(mChild, item);
		// mCommentBar.setCanBeClicked(false);
		// mCommentBar.enterPageThenGetComments();

		lpTitle.width = LayoutParams.FILL_PARENT;
		lpTitle.height = LayoutParams.WRAP_CONTENT;

		lpSummary.addRule(RelativeLayout.BELOW, R.id.imgtxtlive_title);

		activity_imgtxt_title_share = (ImageButton) findViewById(R.id.activity_imgtxt_title_share);
		img_txt_live_loading = findViewById(R.id.img_txt_live_loading);
		img_txt_live_failed = findViewById(R.id.img_txt_live_failed);
		mViewPager = (ViewPagerEx) findViewById(R.id.img_txt_live_pager);
		mWritingCommentView = (WritingCommentView) findViewById(R.id.ImgTxtLiveWritingCommentView);

		mCommentView = new CommentView(this);
		mViews.add(v);
		mViews.add(mCommentView);
		mViewPager.setAdapter(new ViewPagerAdapter(mViews));
		mViewPager.setOffscreenPageLimit(1);
		mViewPager.setCurrentItem(0);
		mViewPager.setOnPageChangeListener(new MyOnPageChangeListener());

		mWritingCommentView.setItem(mChild, mItem);
		mWritingCommentView.canWrite(false);
		mWritingCommentView.setText("直播");
		mCommentView.init(mChild, mItem);
		mCommentView.setWritingCommentView(mWritingCommentView);
	}

	private void initData() {

		data = new ArrayList<ImgTxtLiveInfo>();
		autoRefreshCacheData = new ArrayList<ImgTxtLiveInfo>();

		mImgTxtLiveAdapter = new ImgTxtLiveAdapter(ImgTxtLiveActivity.this, mListView);
		mListView.setAdapter(mImgTxtLiveAdapter);
		mPullToRefreshFrameLayout.showState(Constants.LIST);
		mImgTxtLiveAdapter.setImageOnClickListener(mImageOnClickListener);
		((PullRefreshListView) mListView).setSartListener(mImgTxtLiveAdapter);

	}

	OnClickListener c = new OnClickListener() {

		@Override
		public void onClick(View v) {
			if (!canWork) {
				return;
			}

			if (isShowQiIng || isShowQiTitleIng || isZhanKaiIng || isZhanKaiTitleIng) {
				return;
			}

			if (!isShowQiIng && !isZhanKaiIng) {
				if (isShowQi) {
					mHandler.sendEmptyMessage(spread_start);
				} else {
					mHandler.sendEmptyMessage(retract_start);
				}
			}

		}
	};

	private void initListener() {

		mImgTxtLiveTitle.setOnClickListener(c);
		mImgTxtLiveSummary.setOnClickListener(c);
		mImgTxtLiveSummaryContent.setOnClickListener(c);
		activity_imgtxt_title_share.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				ShareDialog.getInstance().showShareList(ImgTxtLiveActivity.this, ShareDialog.SHARE_NORMAL_DETAIL, activity_imgtxt_title_share);
			}
		});
		mWritingCommentView.setDetailCommentChangeClick(new OnChangeClick() {

			@Override
			public void change() {
				if (mCurrentPage == 0) {
					mViewPager.setCurrentItem(1);
				} else {
					mViewPager.setCurrentItem(0);
				}
			}
		});

		mListView.setOnTouchListener(new OnTouchListener() {// 目的只为防抖动!!

					@Override
					public boolean onTouch(View v, MotionEvent event) {
						if (event.getAction() == MotionEvent.ACTION_DOWN && isShowQi) {
							if (!mListView.isHasHeader()) {
								mListView.setHasHeader(true);
							}
						} else if (event.getAction() == MotionEvent.ACTION_UP && !isShowQiIng) {
							if (!mListView.isHasHeader()) {
								mListView.setHasHeader(true);
							}
						}
						return false;
					}
				});

		mListView.setOnRefreshListener(new OnRefreshListener() {

			@Override
			public void onRefresh() {

				if (isLoading) {
					mListView.onRefreshComplete(true);
				} else {
					if (mImgTxtLiveAdapter.getCount() <= 0) {
						getNewDataButListNoData();
					} else {

						if (firstId != null) {
							getNewData(firstId);
						}
					}
				}

			}
		});

		mListView.setOnClickFootViewListener(new OnClickFootViewListener() {

			@Override
			public void onClickFootView() {

				if (lastId != null && !haveNoOldData) {
					loadOldData(lastId);
				}
			}
		});

		img_txt_live_loading.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				return true;
			}
		});

		img_txt_live_failed.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				enterActivityLoadNewData();
			}
		});

		mImageOnClickListener = new OnClickListener() {

			@Override
			public void onClick(View v) {
				ImgTxtLiveImageIndex imageIndex = (ImgTxtLiveImageIndex) v.getTag();

				if (null == imageIndex) {
					return;
				}
				imageIndex2position = imageIndex.getImageIndex2position();

				Intent intent = new Intent();
				intent.setClass(ImgTxtLiveActivity.this, LivePreViewActivity.class);
				intent.putExtra(Constants.PREVIEW_IMAGE_KEY, imageIndex.getImageURLs());
				intent.putExtra(Constants.PREVIEW_IMAGE_INDEX_KEY, imageIndex.getIndex());
				startActivityForResult(intent, Constants.REQUEST_CODE_IMAGE_TEXT_LIVE);
			}
		};

		mListView.setOnScrollPositionListener(new OnScrollPositionListener() {

			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {

			}

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
				if (firstVisibleItem > 0 && firstVisibleItem <= mImgTxtLiveAdapter.getDataList().size()) {
					Long time = Long.parseLong(mImgTxtLiveAdapter.getDataList().get(firstVisibleItem - 1).getTime());
					mFloatTime.setText(ImgTxtLiveAdapter.sdf.format(new Date(time * 1000)));
					old = firstVisibleItem;
				}
			}
		});

	}

	int old = -1;

	/**
	 * 进入界面时获取数据
	 */
	private void enterActivityLoadNewData() {
		if (isLoading) {
			return;
		}
		enterActivityShowLoading();
		
		HttpDataRequest mRequest = TencentNews.getInstance().getImgTxtLive(zhiboId, "" + Integer.MAX_VALUE, "20", "0", summeryVersion);
		mRequest.setTag(HttpTag.IMG_TXT_LIVE_NEW_DATA);
		TaskManager.startHttpDataRequset(mRequest, this);
		isLoading = true;
	}

	/**
	 * 普通的下拉刷新
	 * 
	 * @param startIdFromLocal
	 */
	private void getNewData(String startIdFromLocal) {
		if (isLoading) {
			return;
		}

		HttpDataRequest mRequest = TencentNews.getInstance().getImgTxtLive(zhiboId, startIdFromLocal, "20", "1", summeryVersion);
		mRequest.setTag(HttpTag.IMG_TXT_LIVE_REFRESH_DATA);
		TaskManager.startHttpDataRequset(mRequest, this);
		isLoading = true;
	}

	private void autoGetNewData(String startIdFromLocal) {
		if (isLoading) {
			return;
		}
		HttpDataRequest mRequest = TencentNews.getInstance().getImgTxtLive(zhiboId, startIdFromLocal, "20", "1", summeryVersion);
		mRequest.setTag(HttpTag.IMG_TXT_LIVE_AUTO_REFRESH_DATA);
		TaskManager.startHttpDataRequset(mRequest, this);
		isLoading = true;
	}

	/**
	 * 直播列表没数据时,下拉刷新
	 */
	private void getNewDataButListNoData() {
		enterActivityLoadNewData();
	}
	
	/**
	 * 设置返回按钮名称
	 */
	private void setTitleBackName() {
		if(isRelateNews) {
			mBackBtn.setText("返回");
			return;
		}
	}

	/**
	 * 加载更多
	 * 
	 * @param startIdFromLocal
	 */
	private void loadOldData(String startIdFromLocal) {
		HttpDataRequest mRequest = TencentNews.getInstance().getImgTxtLive(zhiboId, startIdFromLocal, "20", "0", summeryVersion);
		mRequest.setTag(HttpTag.IMG_TXT_LIVE_LOAD_MORE_DATA);
		TaskManager.startHttpDataRequset(mRequest, this);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.activity_imgtxt_title_btn_back:
			quitActivity();
			break;
		case R.id.activity_imgtxt_title_btn_click:
		case R.id.activity_imgtxt_title_show_new_data_tips:
			// case R.id.activity_imgtxt_title_refresh:

			if (mCurrentPage == 0) {
				if (isGoOnEnterActivityGetData) {
					enterActivityLoadNewData();
				} else {
					getNewData(firstId);
				}
				mListView.setSelection(0);
			} else {
				mCommentView.upToTop();
			}

			break;

		default:
			break;
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {

			if (ShareDialog.getInstance().isShowing()) {
				ShareDialog.getInstance().dismiss();
				return true;
			}
			// if (mCommentBar.isUpTranBarShowing()) {
			// mCommentBar.closeUpTranBar();
			// return true;
			// }
			// if (mCommentBar.isOpened()) {
			// mCommentBar.animateClose();
			// return true;
			// }
			quitActivity();
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_MENU) {
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public void onHttpRecvOK(HttpTag tag, Object result) {

		isLoading = false;

		// TODO:需要优化

		if (result != null) {
			itlFromNet = (ImgTxtLive) result;

			if (itlFromNet != null && itlFromNet.getRet() != null) {// 网络有返回

				mImgTxtLiveAdapter.setServerTime(Long.parseLong(itlFromNet.getServer_time()));

				if (tag.equals(HttpTag.IMG_TXT_LIVE_NEW_DATA)) {// 进入直播时

					isActivityLoading = false;

					mCommentView.enterPageThenGetComments(isRelateNews);
					mWritingCommentView.canWrite(true);

					activity_imgtxt_title_share.setEnabled(true);
					ShareDialog.getInstance().setParams("", "", null, mItem, mChild);

					ShareDialog.getInstance().setImageUrl(mItem.getThumbnails_qqnews()[0]);

					mListView.onRefreshComplete(true);

					if (itlFromNet.getRet().equals("0")) {// 列表有新数据了

						this.summeryVersion = itlFromNet.getSummary().getVersion();

						if (mImgTxtLiveAdapter.getDataList().size() > 0) {// 本来就有数据

							mHandler.sendEmptyMessage(load_data_start);// 播放动画

							isGoOnEnterActivityGetData = false;

						} else {// 本来没有数据

							mPullToRefreshFrameLayout.showState(Constants.LIST);

							firstId = itlFromNet.getFirstId();
							lastId = itlFromNet.getLastId();

							try {
								startIdRefreshUninsertBoundary = Integer.parseInt(firstId);
							} catch (Exception e) {
								startIdRefreshUninsertBoundary = Integer.MAX_VALUE;// 所有的不变黄
							}

							mImgTxtLiveAdapter.addDataList(itlFromNet.array2List(startIdRefreshUninsertBoundary));

							initFloatTime();

							mImgTxtLiveAdapter.notifyDataSetChanged();

							isGoOnEnterActivityGetData = false;
						}

					} else if (itlFromNet.getRet().equals("1")) {// 列表没有新数据

						if (mImgTxtLiveAdapter.getDataList().size() > 0) {// 本来有数据

							mPullToRefreshFrameLayout.showState(Constants.LIST);// 啥也不干

							isGoOnEnterActivityGetData = false;

						} else {// 本来没有数据

							mPullToRefreshFrameLayout.showState(Constants.EMPTY);// 直播列表置空

							firstId = "" + Integer.MAX_VALUE;// 起始位置置为最大
							isGoOnEnterActivityGetData = true;
						}

					} else if (itlFromNet.getRet().equals("2")) {// 直播列表暂无数据
						mPullToRefreshFrameLayout.showState(Constants.EMPTY);
						isGoOnEnterActivityGetData = true;
					}

					// mImgTxtLiveTitle.setText(itlFromNet.getIntro().getTopic());//
					// 更新标题
					mImgTxtLiveTitle.setText(newsTitle);// 更新标题

					if (itlFromNet.getSummary() != null && itlFromNet.getSummary().getCnt() != null && itlFromNet.getSummary().getCnt().length() > 0 && itlFromNet.getSummary().getVersion() != null) {
						mImgTxtLiveSummaryContent.setText(itlFromNet.getSummary().getCnt());// 更新回顾内容
						mImgTxtLiveSummaryContentCopy.setText(itlFromNet.getSummary().getCnt());
						mHandler.sendEmptyMessageDelayed(refresh_summay_height, 10);
						// mImgTxtLiveSummary.setVisibility(View.VISIBLE);
						summeryVersion = itlFromNet.getSummary().getVersion();
						canWork = true;
					} else {
						mImgTxtLiveSummary.setVisibility(View.GONE);
						// mTitleHandler.sendEmptyMessage(retract_title_no_summary);
						canWork = false;
					}

					mListView.setFootViewAddMore(true, true, false);

					showActivityData();// 去掉刚进入界面的等待状态
					if (mAutoLoadHandler != null) {
						try {
							mAutoLoadHandler.sendEmptyMessageDelayed(autoLoad, 1000 * Long.parseLong(itlFromNet.getRefresh_time()));
						} catch (Exception e) {
							mAutoLoadHandler.sendEmptyMessageDelayed(autoLoad, delayMillis);
						}
					}

				} else if (tag.equals(HttpTag.IMG_TXT_LIVE_REFRESH_DATA)) {// 下拉刷新
					isActivityLoading = false;
					mListView.onRefreshComplete(true);

					if (itlFromNet.getRet().equals("0") || (autoRefreshCacheData != null && autoRefreshCacheData.size() > 0)) {// 有新数据

						if (mImgTxtLiveAdapter.getDataList().size() > 0) {// 本来有数据

							mHandler.sendEmptyMessage(load_data_start);// 开始动画
							isGoOnEnterActivityGetData = false;
						} else {// 本来没有数据

							mPullToRefreshFrameLayout.showState(Constants.LIST);

							firstId = itlFromNet.getFirstId();// 起始位置为刷新后的最大id

							mImgTxtLiveAdapter.addDataList(itlFromNet.array2List(0));// 直接添加数据
							initFloatTime();
							mImgTxtLiveAdapter.notifyDataSetChanged();// 直接刷新界面
							isGoOnEnterActivityGetData = false;
						}
					} else if (itlFromNet.getRet().equals("1")) {// 列表没有新数据

						if (mImgTxtLiveAdapter.getDataList().size() > 0) {// 本来有

							mPullToRefreshFrameLayout.showState(Constants.LIST);
							isGoOnEnterActivityGetData = false;
						} else {// 本来没有

							mPullToRefreshFrameLayout.showState(Constants.EMPTY);
							isGoOnEnterActivityGetData = true;
						}

					} else if (itlFromNet.getRet().equals("2")) {// 直播列表暂无数据
						mPullToRefreshFrameLayout.showState(Constants.EMPTY);
						isGoOnEnterActivityGetData = true;
					}

					// mImgTxtLiveTitle.setText(itlFromNet.getIntro().getTopic());

					if (haveNoOldData) {
						mListView.setFootViewAddMore(true, false, false);
					} else {
						mListView.setFootViewAddMore(true, true, false);
					}

					if (itlFromNet.getSummary() != null && itlFromNet.getSummary().getCnt() != null && itlFromNet.getSummary().getCnt().length() > 0 && itlFromNet.getSummary().getVersion() != null) {
						mImgTxtLiveSummaryContent.setText(itlFromNet.getSummary().getCnt());// 更新回顾内容
						mImgTxtLiveSummaryContentCopy.setText(itlFromNet.getSummary().getCnt());
						mImgTxtLiveSummaryContentCopy.invalidate();
						mHandler.sendEmptyMessageDelayed(refresh_summay_height, 10);
						// mImgTxtLiveSummary.setVisibility(View.VISIBLE);
						summeryVersion = itlFromNet.getSummary().getVersion();
						canWork = true;
					}

					showActivityData();
					if (mAutoLoadHandler != null) {
						try {
							mAutoLoadHandler.sendEmptyMessageDelayed(autoLoad, 1000 * Long.parseLong(itlFromNet.getRefresh_time()));
						} catch (Exception e) {
							mAutoLoadHandler.sendEmptyMessageDelayed(autoLoad, delayMillis);
						}
					}

				} else if (tag.equals(HttpTag.IMG_TXT_LIVE_LOAD_MORE_DATA)) {// 加载更古老的新闻

					if (itlFromNet.getRet().equals("0")) {// 有新数据

						if (mImgTxtLiveAdapter.getDataList().size() > 0) {// 本来有数据

							mListView.setFootViewAddMore(true, true, false);

							lastId = itlFromNet.getLastId();// 结束位置为加载后的最小id

						} else {

						}

						mImgTxtLiveAdapter.addMoreDataList(itlFromNet.array2List(-1));// 添加更多数据
						mImgTxtLiveAdapter.notifyDataSetChanged();// 直接刷新界面

					} else if (itlFromNet.getRet().equals("1")) {// 没有更新

						haveNoOldData = true;
						mListView.setFootViewAddMore(true, false, false);

					} else if (itlFromNet.getRet().equals("2")) {// 没有更古老的数据

						haveNoOldData = true;
						mListView.setFootViewAddMore(true, false, false);

					}

				} else if (tag.equals(HttpTag.IMG_TXT_LIVE_AUTO_REFRESH_DATA)) {// 自动刷新

					isActivityLoading = false;

					if (itlFromNet.getRet().equals("0") || (autoRefreshCacheData != null && autoRefreshCacheData.size() > 0)) {// 有新数据

						if (mImgTxtLiveAdapter.getDataList().size() > 0) {// 本来有数据

							mHandler.sendEmptyMessage(load_data_start);// 开始动画
							isGoOnEnterActivityGetData = false;
						} else {// 本来没有数据

							mPullToRefreshFrameLayout.showState(Constants.LIST);

							firstId = itlFromNet.getFirstId();// 起始位置为刷新后的最大id

							mImgTxtLiveAdapter.addDataList(itlFromNet.array2List(0));// 直接添加数据
							initFloatTime();
							mImgTxtLiveAdapter.notifyDataSetChanged();// 直接刷新界面
							isGoOnEnterActivityGetData = false;
						}
					} else if (itlFromNet.getRet().equals("1")) {// 列表没有新数据

						if (mImgTxtLiveAdapter.getDataList().size() > 0) {// 本来有

							mPullToRefreshFrameLayout.showState(Constants.LIST);
							isGoOnEnterActivityGetData = false;
						} else {// 本来没有

							mPullToRefreshFrameLayout.showState(Constants.EMPTY);
							isGoOnEnterActivityGetData = true;
						}

					} else if (itlFromNet.getRet().equals("2")) {// 直播列表暂无数据
						mPullToRefreshFrameLayout.showState(Constants.EMPTY);
						isGoOnEnterActivityGetData = true;
					}

					// mImgTxtLiveTitle.setText(itlFromNet.getIntro().getTopic());

					if (haveNoOldData) {
						mListView.setFootViewAddMore(true, false, false);
					} else {
						mListView.setFootViewAddMore(true, true, false);
					}

					if (itlFromNet.getSummary() != null && itlFromNet.getSummary().getCnt() != null && itlFromNet.getSummary().getCnt().length() > 0 && itlFromNet.getSummary().getVersion() != null) {
						mImgTxtLiveSummaryContent.setText(itlFromNet.getSummary().getCnt());// 更新回顾内容
						mImgTxtLiveSummaryContentCopy.setText(itlFromNet.getSummary().getCnt());
						mHandler.sendEmptyMessageDelayed(refresh_summay_height, 10);
						// mImgTxtLiveSummary.setVisibility(View.VISIBLE);
						summeryVersion = itlFromNet.getSummary().getVersion();
						canWork = true;
					}

					showActivityData();

					if (mAutoLoadHandler != null) {
						try {
							mAutoLoadHandler.sendEmptyMessageDelayed(autoLoad, 1000 * Long.parseLong(itlFromNet.getRefresh_time()));
						} catch (Exception e) {
							mAutoLoadHandler.sendEmptyMessageDelayed(autoLoad, delayMillis);
						}
					}
				}
			}

		}
	}

	@Override
	public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {

		WebDev.trackCustomEvent(this, SpeedTest.ITIL_ERROR_LOADPICTEXTLIVE, msg);

		isLoading = false;
		if (mAutoLoadHandler != null) {
			try {
				mAutoLoadHandler.sendEmptyMessageDelayed(autoLoad, 1000 * Long.parseLong(itlFromNet.getRefresh_time()));
			} catch (Exception e) {
				mAutoLoadHandler.sendEmptyMessageDelayed(autoLoad, delayMillis);
			}
		}

		if (tag.equals(HttpTag.IMG_TXT_LIVE_NEW_DATA)) {// 刚进直播界面

			
			showActivityError();
			isGoOnEnterActivityGetData = true;
			isActivityLoading = true;

		} else if (tag.equals(HttpTag.IMG_TXT_LIVE_REFRESH_DATA)) {// 下拉刷新
			mListView.onRefreshComplete(true);
			if (mImgTxtLiveAdapter.getCount() > 0) {// 本来有数据
				isGoOnEnterActivityGetData = false;
			} else {
				isGoOnEnterActivityGetData = true;
			}

		} else if (tag.equals(HttpTag.IMG_TXT_LIVE_LOAD_MORE_DATA)) {// 加载更古老的新闻
			mListView.setFootViewAddMore(false, true, true);
			isGoOnEnterActivityGetData = false;
		} else if (tag.equals(HttpTag.IMG_TXT_LIVE_AUTO_REFRESH_DATA)) {// 自动刷新
			mListView.onRefreshComplete(true);
			if (mImgTxtLiveAdapter.getCount() > 0) {// 本来有数据
				isGoOnEnterActivityGetData = false;
			} else {
				isGoOnEnterActivityGetData = true;
			}
		}
	}

	@Override
	public void onHttpRecvCancelled(HttpTag tag) {

		isLoading = false;
		mListView.onRefreshComplete(true);

		if (mImgTxtLiveAdapter.getCount() > 0) {// 本来有数据
			isGoOnEnterActivityGetData = false;
		} else {
			isGoOnEnterActivityGetData = true;
		}

		if (mAutoLoadHandler != null) {
			try {
				mAutoLoadHandler.sendEmptyMessageDelayed(autoLoad, 1000 * Long.parseLong(itlFromNet.getRefresh_time()));
			} catch (Exception e) {
				mAutoLoadHandler.sendEmptyMessageDelayed(autoLoad, delayMillis);
			}
		}

	}

	private void enterActivityShowLoading() {

		if (isActivityLoading) {
			img_txt_live_loading.bringToFront();
			img_txt_live_loading.setVisibility(View.VISIBLE);
			img_txt_live_failed.setVisibility(View.GONE);
		} else {
			img_txt_live_loading.setVisibility(View.GONE);
			img_txt_live_failed.setVisibility(View.GONE);
			mPullToRefreshFrameLayout.showState(Constants.LOADING);
		}
	}

	private void showActivityData() {
		img_txt_live_loading.setVisibility(View.GONE);
		img_txt_live_failed.setVisibility(View.GONE);
		sendBroadCastforRead();
	}

	private void showActivityError() {
		img_txt_live_failed.bringToFront();
		img_txt_live_failed.setVisibility(View.VISIBLE);
		img_txt_live_loading.setVisibility(View.GONE);
	}

	private void smoothScrollToPosition(int position) throws Exception {
		Class<ListView> clazz = (Class<ListView>) mListView.getClass().getSuperclass();
		Class[] clzs = new Class[1];
		clzs[0] = int.class;
		Method m = clazz.getMethod("smoothScrollToPosition", clzs);
		if (!m.isAccessible()) {
			m.setAccessible(true);
		}
		m.invoke(mListView, position);
	}

	private void getIntentData(Intent intent) {
		if (null == intent) {
			return;
		}
		Bundle bundle = intent.getExtras();
		mItem = (Item) bundle.getSerializable(Constants.NEWS_DETAIL_KEY);
		mChild = bundle.getString(Constants.NEWS_CHANNEL_CHLID_KEY);
		mClickPosition = bundle.getString(Constants.NEWS_CLICK_ITEM_POSITION);
		isSpecial = bundle.getBoolean(Constants.IS_SPECIAL_KEY);
		return;
	}

	private void sendBroadCastforRead() {
		Intent intent = new Intent();
		Bundle bundle = new Bundle();
		bundle.putSerializable(Constants.NEWS_ID_KEY, mItem);
		bundle.putString(Constants.NEWS_CLICK_ITEM_POSITION, mClickPosition);
		intent.putExtras(bundle);

        String action = IntentUtil.getReadBroadcastAction(getIntent());
        if (action != null) {
            intent.setAction(action);
        } else if (isSpecial) {
			intent.setAction(Constants.NEWS_HAD_READ_SPECIAL_ACTION + mChild);
		} else {
			intent.setAction(Constants.NEWS_HAD_READ_ACTION + mChild);
		}
		sendBroadcast(intent);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);

		if (null == data) {
			return;
		}

		switch (requestCode) {
		case Constants.REQUEST_CODE_IMAGE_TEXT_LIVE: {
			if (RESULT_OK == resultCode) {
				int index = data.getIntExtra(Constants.IMAGE_TEXT_LIVE_KEY_IMAGE_RESULT_INDEX, 0);
				int position = this.imageIndex2position.get(index, 0) + this.mListView.getHeaderViewsCount();
				mListView.setSelection(position);
			} else if (RESULT_CANCELED == resultCode) {

			}
		}
			break;
		default:
			break;
		}
	}

	private float downX;
	private float downY;
	private float upX;
	private float upY;

	@Override
	public boolean dispatchTouchEvent(MotionEvent ev) {
		final float x = ev.getX();
		final float y = ev.getY();
		if (ev.getAction() == MotionEvent.ACTION_DOWN) {
			downX = x;
			downY = y;
		} else if (ev.getAction() == MotionEvent.ACTION_UP) {
			upX = x;
			upY = y;
			if (mCurrentPage == 0 && upX > downX && Math.abs(upX - downX) > MobileUtil.dpToPx(100) && Math.abs(upY - downY) / Math.abs(upX - downX) < 0.4) {
				quitActivity();
				return true;
			}
		}
		return super.dispatchTouchEvent(ev);
	}

	private void initFloatTime() {
		if (itlFromNet != null && itlFromNet.getInfo() != null && itlFromNet.getInfo().length > 0) {
			Long time = Long.parseLong(itlFromNet.getInfo()[0].getTime());
			mFloatTime.setText(ImgTxtLiveAdapter.sdf.format(new Date(time * 1000)));
			mFloatTime.setVisibility(View.VISIBLE);
		} else {
			if (!mFloatTime.isShown()) {
				mFloatTime.setVisibility(View.GONE);
			}
		}
	}

	AddCommentBroadcastReceiver receiver;
	RefreshCommentNumBroadcastReceiver mRefreshCommentReceiver;

	private void registerBroadReceiver() {
		receiver = new AddCommentBroadcastReceiver(mCommentView, mItem.getId());
		registerReceiver(receiver, new IntentFilter(Constants.WRITE_SUCCESS_ACTION));

		mRefreshCommentReceiver = new RefreshCommentNumBroadcastReceiver(mItem.getId(), null, null, mWritingCommentView);
		registerReceiver(mRefreshCommentReceiver, new IntentFilter(Constants.REFRESH_COMMENT_NUMBER_ACTION));
	}

	public class MyOnPageChangeListener implements OnPageChangeListener {

		@Override
		public void onPageScrollStateChanged(int arg0) {

		}

		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {

		}

		@Override
		public void onPageSelected(int arg0) {
			mCurrentPage = arg0;
			mWritingCommentView.setDCPage(mCurrentPage);
			mWritingCommentView.refreshUI();
		}

	}
	
	@Override
	public void applyTheme() {
		// TODO Auto-generated method stub
		//标题栏
		themeSettingsHelper.setViewBackgroud(this, this.activity_imgtxt_title, R.drawable.title_bar_bg);//标题栏背景
		themeSettingsHelper.setViewBackgroud(this, this.mBackBtn, R.drawable.title_back_btn);//返回按钮“新闻”
		themeSettingsHelper.setTextViewColor(this, this.activity_imgtxt_title_str, R.color.activity_imgtxt_title_str_color);//"图文直播"颜色
		themeSettingsHelper.setViewBackgroud(this, this.activity_imgtxt_title_btn_click, R.drawable.title_click_bg);//点击态
		//themeSettingsHelper.setImageViewSrc(this, this.activity_imgtxt_title_show_new_data_tips, R.drawable.show_new_data_tips);//缺图XXX
		themeSettingsHelper.setImageViewSrc(this, this.activity_imgtxt_title_refresh, R.drawable.refresh_btn);//刷新
		themeSettingsHelper.setImageButtonSrc(this, this.activity_imgtxt_title_share, R.drawable.title_share_btn);//共享按钮
		
		//WritingCommentView公共组件已经被别人改过了，这里就不用改了，嘿嘿~~~
		
		//loading
		themeSettingsHelper.setViewBackgroudColor(this, this.img_txt_live_loading, R.color.img_txt_live_loading_color);
		themeSettingsHelper.setImageViewSrc(this, this.img_txt_live_loading_color_imageview, R.drawable.news_loading_icon);
		//加载出错条框
		themeSettingsHelper.setViewBackgroudColor(this, this.img_txt_live_failed, R.color.img_txt_live_failed_color);//颜色值未给,貌似，不用给~~~奇怪
		themeSettingsHelper.setImageViewSrc(this, this.img_txt_live_failed_imageview, R.drawable.load_list_error_icon);
		themeSettingsHelper.setTextViewColor(this, this.img_txt_live_failed_textview, R.color.img_txt_live_failed_textview_color);//颜色值未给
		
		//imgtxtlive_title
		themeSettingsHelper.setViewBackgroudColor(this, this.imgtxtliveactivity_layout, R.color.imgtxtliveactivity_layout_color);
		themeSettingsHelper.setTextViewColor(this, this.mImgTxtLiveTitle, R.color.imgtxtlive_title_color);
		themeSettingsHelper.setTextViewColor(this, this.mImgTxtLiveSummaryContent, R.color.imgtxtlivesummary_content_color);
		
		//timeview
		themeSettingsHelper.setTextViewColor(this, this.mFloatTime, R.color.live_float_time_color);
		themeSettingsHelper.setViewBackgroud(this, this.mFloatTime, R.drawable.txtlive_time_bg);
		
		//mViewPager
		themeSettingsHelper.setViewBackgroudColor(this, this.mViewPager, R.color.img_txt_live_pager_color);
		
		//applyFrameLayoutTheme
		mPullToRefreshFrameLayout.applyFrameLayoutTheme();
		//mImgTxtLiveAdapter
		//mImgTxtLiveAdapter.applymImgTxtLiveAdapter(this);
		
		themeSettingsHelper.setListViewDivider(this, this.mListView, R.drawable.list_divider_line);
		themeSettingsHelper.setListViewSelector(this, this.mListView, R.drawable.img_txt_live_list_selector);
		
		
		themeSettingsHelper.setViewBackgroudColor(this, mMask, R.color.mask_page_color);
		//themeSettingsHelper.setViewBackgroud(this, this.special_report, R.drawable.title_bar_bg);
		//themeSettingsHelper.setViewBackgroud(this, this.special_report, R.drawable.title_bar_bg);
	}
	
}
