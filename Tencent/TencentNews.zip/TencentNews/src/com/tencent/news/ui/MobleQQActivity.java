
package com.tencent.news.ui;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.util.Date;

import org.apache.http.conn.ConnectTimeoutException;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

import com.tencent.news.R;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.model.pojo.MobleQQAccountsInfo;
import com.tencent.news.system.Application;
import com.tencent.news.ui.view.ShareDialog;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.omg.webdev.WebDev;
import com.tencent.open.HttpStatusException;
import com.tencent.open.NetworkUnavailableException;
import com.tencent.tauth.Constants;
import com.tencent.tauth.IRequestListener;
import com.tencent.tauth.IUiListener;
import com.tencent.tauth.Tencent;
import com.tencent.tauth.UiError;

public class MobleQQActivity extends Activity implements OnClickListener {
    private static final String packageName = "com.tencent.mobileqq";// 这个假的。。。
    private static final int TIMELINE_SUPPORTED_MOBLEQQ_VERSION = 41;
    private static final String SCOPE = "get_user_info,get_simple_userinfo,get_user_profile,get_app_friends,"
            + "add_share,add_topic,list_album,upload_pic,add_album,set_user_face,get_vip_info,get_vip_rich_info,get_intimate_friends_weibo,match_nick_tips_weibo";
    public static final String APP_ID = "100383922";// 这个id目前是iso的 222222
                                                 // QQ6BF159C6
    private static final int REQUEST_UPLOAD_PIC = 1000;
    private static final int REQUEST_SET_AVATAR = 2;
    private Dialog mProgressDialog;
    private MobleQQAccountsInfo mInfo = null;
    private Tencent mTencent;

    private Item newsItem;
    private String imgUrl;
    private String title;
    private String description;

    private static final int UNINSTALLED = 0x001;
    private static final int INSTALLED = 0x002;
    private static final int LOWVERSION = 0x003;

    private Context ctxContext = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // setContentView(R.layout.activity_moble_qq);
        // setContentView(R.layout.mobleqq_layout);
        // Intent i = getIntent();
        // if (i != null) {
        ctxContext = this.getApplicationContext();
        sendMobleQQ();
        // }
    }

    private void sendMobleQQ() {

        // 检测版本
        int result = -1;
        result = checkPackageByLocal(packageName, String.valueOf(TIMELINE_SUPPORTED_MOBLEQQ_VERSION));
        if (result == UNINSTALLED) {
            TipsToast.getInstance().showTipsSoftWarning("对不起，您尚未安装手机QQ");
            finish();
            return;
        } else if (result == LOWVERSION) {
            TipsToast.getInstance().showTipsSoftWarning("您当前版本手机QQ暂不支持分享\n请您升级您的手机QQ");
            finish();
            return;
        }
        //

        mTencent = Tencent.createInstance(APP_ID, ctxContext);// 这个id目前是iso的
        ShareToQQ();
    }

    public void ShareToQQ() {
        // Log.v("lxn", "3:" + mTencent.getOpenId() + "##" +
        // mTencent.getAccessToken());
        // if (mInfo != null) {
        // long time2 = System.currentTimeMillis();
        // long ex = (mInfo.getExpires() - time2) / 1000;
        // Log.v("lxn", "yijingdengluguo");
        // Log.v("lxn", "openid=" + mInfo.getOpenId());
        // Log.v("lxn", "accestoken=" + mInfo.getAccessToken());
        // Log.v("lxn", "expires=" + ex);
        //
        // mTencent.setOpenId(mInfo.getOpenId());
        // mTencent.setAccessToken(mInfo.getAccessToken(), Long.toString(ex));
        // }
        Bundle bundle = new Bundle();

        setShareInformation(bundle);
        doShareToQQ(bundle);
    }

    /*
     * 设置分享的内容
     * @param params 对于专题和独家新闻分享做特殊处理
     */
    public void setShareInformation(Bundle params) {
        try {
            newsItem = ShareDialog.getInstance().getNewsItem();
            imgUrl = ShareDialog.getInstance().getImageUrl();
            if ("4".equals(newsItem.getFlag())) {// 如果是专题，则采用专题列表页的标题和摘要
                title = "专题新闻:" + ShareDialog.getInstance().getSpecialReportTitle();
                description = ShareDialog.getInstance().getSpecialReportIntro();
            } else {
                title = newsItem.getTitle();
                description = newsItem.getBstract();
            }
            params.putString("site", "");
            params.putString("appName", "腾讯新闻");
            Log.v("lxn", "targeturl=" + newsItem.getUrl() + "#title=" + title.trim() + "#summary=" + description.trim()
                    + "#imageurl=" + newsItem.getThumbnails_qqnews()[0]);
            params.putString("targetUrl", newsItem.getUrl());
            params.putString("title", title.trim());
            //params.putString("messagetail", "腾讯新闻客户端");
            //params.putString("appSource", "腾讯新闻100383922");
            if (description.trim().length() > 0) {
                params.putString("summary", description.trim());
            } else {
                params.putString("summary", " ");
            }
            if ("1".equals(newsItem.getFlag())) {// 如果是独家新闻，则分享图片，首先采用列表页图片，其次采用内容页图片，最后图片置空
                try {
                    if ((newsItem.getThumbnails_qqnews()[0]).length() > 0) {
                        params.putString("imageUrl", newsItem.getThumbnails_qqnews()[0]);
                    } else if (imgUrl != null && imgUrl.length() > 0) {
                        params.putString("imageUrl", imgUrl);
                    } else {
                        params.putString("imageUrl", "");
                    }
                } catch (Exception ee) {
                    ee.printStackTrace();
                    params.putString("imageUrl", "");
                } catch (OutOfMemoryError e) {
                    e.printStackTrace();
                    params.putString("imageUrl", "");
                }
            } else {
                try {
                    if (imgUrl != null && imgUrl.length() > 0) {
                        params.putString("imageUrl", imgUrl);
                    } else {
                        if (Integer.parseInt(newsItem.getImageCount()) > 0) {
                            params.putString("imageUrl", newsItem.getThumbnails_qqnews()[0]);
                        } else {
                            params.putString("imageUrl", "");
                        }
                    }
                } catch (Exception ee) {
                    ee.printStackTrace();
                    params.putString("imageUrl", "");
                } catch (OutOfMemoryError e) {
                    e.printStackTrace();
                    params.putString("imageUrl", "");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
     * 分享到qq
     * @param params 分享的内容 bundle.putString("title", "标题");
     * bundle.putString("imageUrl",
     * "http://img3.cache.netease.com/photo/0005/2013-03-07/8PBKS8G400BV0005.jpg"
     * ); bundle.putString("targetUrl", "http://3g.baidu.com/");
     * bundle.putString("summary", "摘要"); bundle.putString("site", "");
     * bundle.putString("appName", "腾讯新闻");
     */
    private void doShareToQQ(Bundle params) {
        mTencent.shareToQQ(MobleQQActivity.this, params, new BaseUiListener() {
            protected void doComplete(JSONObject values) {
                // showResult("shareToQQ:", "onComplete");

                finish();
            }

            @Override
            public void onError(UiError e) {
                // showResult("shareToQQ:", "onError code:" + e.errorCode +
                // ", msg:"
                // + e.errorMessage + ", detail:" + e.errorDetail);

                finish();
            }

            @Override
            public void onCancel() {
                // showResult("shareToQQ", "onCancel");

                finish();
            }
        });
    }

    private class BaseApiListener implements IRequestListener {
        private String mScope = "all";
        private Boolean mNeedReAuth = false;

        public BaseApiListener(String scope, boolean needReAuth) {
            mScope = scope;
            mNeedReAuth = needReAuth;
        }

        @Override
        public void onComplete(final JSONObject response, Object state) {
            // showResult("IRequestListener.onComplete:", response.toString());
            doComplete(response, state);
        }

        protected void doComplete(JSONObject response, Object state) {
            try {
                int ret = response.getInt("ret");
                if (ret == 100030) {
                    if (mNeedReAuth) {
                        Runnable r = new Runnable() {
                            public void run() {
                                mTencent.reAuth(MobleQQActivity.this, mScope, new BaseUiListener());
                            }
                        };
                        MobleQQActivity.this.runOnUiThread(r);
                    }
                }
                // azrael 2/1注释掉了, 这里为何要在api返回的时候设置token呢,
                // 如果cgi返回的值没有token, 则会清空原来的token
                // String token = response.getString("access_token");
                // String expire = response.getString("expires_in");
                // String openid = response.getString("openid");
                // mTencent.setAccessToken(token, expire);
                // mTencent.setOpenId(openid);
            } catch (JSONException e) {
                e.printStackTrace();
                Log.e("toddtest", response.toString());
            }

        }

        @Override
        public void onIOException(final IOException e, Object state) {
            // showResult("IRequestListener.onIOException:", e.getMessage());
        }

        @Override
        public void onMalformedURLException(final MalformedURLException e, Object state) {
            // showResult("IRequestListener.onMalformedURLException",
            // e.toString());
        }

        @Override
        public void onJSONException(final JSONException e, Object state) {
            // showResult("IRequestListener.onJSONException:", e.getMessage());
        }

        @Override
        public void onConnectTimeoutException(ConnectTimeoutException arg0, Object arg1) {
            // showResult("IRequestListener.onConnectTimeoutException:",
            // arg0.getMessage());

        }

        @Override
        public void onSocketTimeoutException(SocketTimeoutException arg0, Object arg1) {
            // showResult("IRequestListener.SocketTimeoutException:",
            // arg0.getMessage());
        }

        @Override
        public void onUnknowException(Exception arg0, Object arg1) {
            // showResult("IRequestListener.onUnknowException:",
            // arg0.getMessage());
        }

        @Override
        public void onHttpStatusException(HttpStatusException arg0, Object arg1) {
            // showResult("IRequestListener.HttpStatusException:",
            // arg0.getMessage());
        }

        @Override
        public void onNetworkUnavailableException(NetworkUnavailableException arg0, Object arg1) {
            // showResult("IRequestListener.onNetworkUnavailableException:",
            // arg0.getMessage());
        }
    }

    private class BaseUiListener implements IUiListener {

        @Override
        public void onComplete(JSONObject response) {
            // mBaseMessageText.setText("onComplete:");
            // mMessageText.setText(response.toString());
            doComplete(response);
        }

        protected void doComplete(JSONObject values) {

        }

        @Override
        public void onError(UiError e) {
            // showResult("onError:", "code:" + e.errorCode + ", msg:"
            // + e.errorMessage + ", detail:" + e.errorDetail);
        }

        @Override
        public void onCancel() {
            // showResult("onCancel", "");
        }
    }

    /*
     * 账号信息保存
     * @param str 登陆后qq返回的response字符串
     */
    private void parseAccountsInfo(String str) {
        Log.v("lxn", "2:" + mTencent.getOpenId() + "##" + mTencent.getAccessToken());
        Log.v("lxn", "response:" + str);
        mInfo = new MobleQQAccountsInfo();
        if (str != null && str.length() > 0) {
            // Log.v("lxn","str exist!");
            int n = str.indexOf("{");
            str = str.substring(n + 1, str.length());
            String subDatas[] = str.split(",");
            for (int i = 0; i < subDatas.length; i++) {
                // Log.v("lxn","subDates"+i+"="+subDatas[i]);
                String data = subDatas[i].trim();
                String str2[] = data.split(":\"");

                if (data.startsWith("\"openid")) {

                    if (str2[1].length() > 0) {// 去除字符串末尾的双引号
                        str2[1] = str2[1].substring(0, str2[1].length() - 1);
                    }
                    Log.v("lxn", "openid:" + str2[1]);
                    mInfo.setOpenId(str2[1]);
                } else if (data.startsWith("\"access_token")) {

                    if (str2[1].length() > 0) {// 去除字符串末尾的双引号和大括号
                        str2[1] = str2[1].substring(0, str2[1].length() - 2);
                    }
                    Log.v("lxn", "access_token:" + str2[1]);
                    mInfo.setAccessToken(str2[1]);
                } else if (data.startsWith("\"expires_in")) {

                    if (str2[1].length() > 0) {// 去除字符串末尾的双引号
                        str2[1] = str2[1].substring(0, str2[1].length() - 1);
                    }
                    Log.v("lxn", "expires_in1:" + str2[1]);
                    long time = System.currentTimeMillis();
                    Log.v("lxn", "time:" + time);
                    long gap = (str2[1] != null && str2[1].length() > 0) ? Long.parseLong(str2[1]) : 0;
                    Log.v("lxn", "gap:" + gap);
                    mInfo.setExpires(gap * 1000 + time);
                    Log.v("lxn", "gap+time:" + gap + time);
                }
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.v("sample", "onActivityResult:" + requestCode);
        // must call mTencent.onActivityResult.
        if (mTencent == null) {
            return;
        }
        if (!mTencent.onActivityResult(requestCode, resultCode, data)) {
            if (data != null) {
                if (requestCode == REQUEST_UPLOAD_PIC) {
                    doUploadPic(data.getData());
                } else if (requestCode == REQUEST_SET_AVATAR) {
                    doSetAvatar(data.getData());
                }
            }
        }
        finish();
    }

    private void doUploadPic(Uri uri) {
        if (ready()) {
            Bundle params = new Bundle();

            byte[] buff = null;
            try {
                InputStream is = getContentResolver().openInputStream(uri);
                ByteArrayOutputStream outSteam = new ByteArrayOutputStream();
                byte[] buffer = new byte[1024];
                int len = 0;
                while ((len = is.read(buffer)) != -1) {
                    outSteam.write(buffer, 0, len);
                }
                outSteam.close();
                is.close();
                buff = outSteam.toByteArray();
            } catch (IOException e) {
                e.printStackTrace();
            }

            params.putByteArray("picture", buff);// 必须.上传照片的文件名以及图片的内容（在发送请求时，图片内容以二进制数据流的形式发送，见下面的请求示例），注意照片名称不能超过30个字符。
            params.putString("photodesc", "QQ登陆SDK：UploadPic测试" + new Date());// 照片描述，注意照片描述不能超过200个字符。
            params.putString("title", "QQ登陆SDK：UploadPic测试" + System.currentTimeMillis() + ".png");// 照片的命名，必须以.jpg,
                                                                                                   // .gif,
                                                                                                   // .png,
                                                                                                   // .jpeg,
                                                                                                   // .bmp此类后缀结尾。
            // bundle.putString("albumid",
            // "564546-asdfs-feawfe5545-45454");//相册id，不填则传到默认相册
            params.putString("x", "0-360");// 照片拍摄时的地理位置的经度。请使用原始数据（纯经纬度，0-360）。
            params.putString("y", "0-360");// 照片拍摄时的地理位置的纬度。请使用原始数据（纯经纬度，0-360）。

            mTencent.requestAsync(Constants.GRAPH_UPLOAD_PIC, params, Constants.HTTP_POST, new BaseApiListener(
                    "upload_pic", true), null);

            mProgressDialog.show();
        }
    }

    private boolean ready() {
        boolean ready = mTencent.isSessionValid() && mTencent.getOpenId() != null;
        if (!ready)
            Toast.makeText(this, "login and get openId first, please!", Toast.LENGTH_SHORT).show();
        return ready;
    }

    private void doSetAvatar(Uri uri) {
        Bundle params = new Bundle();
        params.putString(Constants.PARAM_AVATAR_URI, uri.toString());
        // 这个return_activity是可选的
        // params.putString(Constants.PARAM_AVATAR_RETURN_ACTIVITY,
        // "com.tencent.sample.ReturnActivity");

        mTencent.setAvatar(this, params, new BaseUiListener());
        // mTencent.setAvatar(this, params, new BaseUiListener(), R.anim.zoomin,
        // R.anim.zoomout);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        // getMenuInflater().inflate(R.menu.moble_qq, menu);
        return true;
    }

    @Override
    public void onClick(View arg0) {
        // TODO Auto-generated method stub

    }

    // 检测本机是否安装此应用
    private int checkPackageByLocal(String packageName, String versionCode) {
        int state = UNINSTALLED;
        PackageInfo packageInfo = null;
        String mVersionCode = null;
        try {
            Context context = Application.getInstance().getApplicationContext();
            packageInfo = context.getPackageManager().getPackageInfo(packageName, 0);
            if (packageInfo != null) {
                // 启动
                state = INSTALLED;
                mVersionCode = packageInfo.versionName;
                Log.v("lxn", "versionlocal=" + mVersionCode + "#versionsing=" + versionCode);
                if (CompareVersion(mVersionCode, versionCode)) {
                    state = LOWVERSION;
                }
            }
        } catch (NameNotFoundException e) {
            e.printStackTrace();
        }
        return state;
    }

    private boolean CompareVersion(String versionByLocal, String versionByNet) {
        boolean isUpdated = false;
        String temp = "";
        String letter_pattern = "[^0-9]";
        versionByLocal = versionByLocal.replaceAll(letter_pattern, "");
        versionByNet = versionByNet.replaceAll(letter_pattern, "");
        versionByLocal = versionByLocal.replace(".", "");
        versionByNet = versionByNet.replace(".", "");
        int len = 0;
        if (versionByLocal.length() > versionByNet.length()) {
            len = versionByLocal.length() - versionByNet.length();
            temp = versionByNet;
            if (len != 0) {
                for (int i = 0; i < len; i++) {
                    temp += "0";
                }
                if (Long.valueOf(versionByLocal) < Long.valueOf(temp)) {
                    isUpdated = true;
                }

            }
        } else if (versionByLocal.length() == versionByNet.length()) {
            if (Long.valueOf(versionByNet) > Long.valueOf(versionByLocal)) {
                isUpdated = true;
            }
        } else {
            len = versionByNet.length() - versionByLocal.length();
            temp = versionByLocal;
            if (len != 0) {
                for (int i = 0; i < len; i++) {
                    temp += "0";
                }
                if (Long.valueOf(versionByNet) > Long.valueOf(temp)) {
                    isUpdated = true;
                }
            }
        }

        return isUpdated;
    }

    @Override
    protected void onResume() {
        super.onResume();
        WebDev.onResume(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        WebDev.onPause(this);
    }
}
