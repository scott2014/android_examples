package com.tencent.news.ui;

import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;

import com.tencent.news.R;
import com.tencent.news.shareprefrence.SpUpdate;
import com.tencent.news.utils.MobileUtil;
import com.tencent.omg.webdev.WebDev;

public class GuideActivity extends BaseActivity {

	private ViewPager welcome_page;

	private AwesomePagerAdapter awesomeAdapter;

	private LayoutInflater mInflater;
	List<View> mListViews;
	ImageButton guideEnd;
	boolean gotoSetting = false;
	private int nCurrentPage = 0;
	private float downX;
	private float upX;
	private float downY;
	private float upY;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_guide);

		Intent i = getIntent();

		if (i != null && i.hasExtra("GuidFrom")) {
			if (i.getStringExtra("GuidFrom").equals("SplashActivity")) {
				gotoSetting = false;

//				/**
//				 * 用户在浏览新手引导时上传安装和更新的日志
//				 */
//				Statistics.getInstance().reportAll();

			}
		} else {
			gotoSetting = true;
		}

		awesomeAdapter = new AwesomePagerAdapter();
		welcome_page = (ViewPager) findViewById(R.id.welcome_page);
		welcome_page.setOffscreenPageLimit(2);
		welcome_page.setAdapter(awesomeAdapter);
		welcome_page.setOnPageChangeListener(new OnPageChangeListener() {

			@Override
			public void onPageScrollStateChanged(int arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onPageSelected(int arg0) {
				// TODO Auto-generated method stub
				nCurrentPage = arg0;
			}

		});

		mListViews = new ArrayList<View>();
		mInflater = getLayoutInflater();
		mListViews.add(mInflater.inflate(R.layout.guide_page1, null));
		mListViews.add(mInflater.inflate(R.layout.guide_page2, null));
		// mListViews.add(mInflater.inflate(R.layout.guide_page3, null));
		// mListViews.add(mInflater.inflate(R.layout.guide_page4, null));
		guideEnd = (ImageButton) mListViews.get(mListViews.size() - 1).findViewById(R.id.guide_end);

		guideEnd.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				quitActivity();
				if (gotoSetting) {

				} else {
					startNextActivity();
				}
			}
		});
	}

	private void startNextActivity() {
		Intent intent = new Intent();
		intent.setClass(GuideActivity.this, MainActivity.class);
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		SpUpdate.saveVer(MobileUtil.getVersionCode());
		startActivity(intent);
		GuideActivity.this.finish();
		overridePendingTransition(R.anim.push_left_in, R.anim.push_left_out);
	}

	private class AwesomePagerAdapter extends PagerAdapter {

		@Override
		public int getCount() {
			return mListViews.size();
		}

		@Override
		public Object instantiateItem(View collection, int position) {
			((ViewPager) collection).addView(mListViews.get(position), 0);
			return mListViews.get(position);
		}

		@Override
		public void destroyItem(View collection, int position, Object view) {
			((ViewPager) collection).removeView(mListViews.get(position));
		}

		@Override
		public boolean isViewFromObject(View view, Object object) {
			return view == (object);
		}

	}

	@Override
	public boolean dispatchTouchEvent(MotionEvent ev) {
		// TODO Auto-generated method stub
		final float x = ev.getX();
		final float y = ev.getY();
		if (ev.getAction() == MotionEvent.ACTION_DOWN) {
			downX = x;
			downY = y;
		} else if (ev.getAction() == MotionEvent.ACTION_UP) {
			upX = x;
			upY = y;
			if (upX < downX && Math.abs(upX - downX) > MobileUtil.dpToPx(100) && Math.abs(upX - downX) > Math.abs(upY - downY)) {
				if (nCurrentPage == mListViews.size() - 1) {
					startNextActivity();
				}
			}
		}
		return super.dispatchTouchEvent(ev);
	}

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}
}
