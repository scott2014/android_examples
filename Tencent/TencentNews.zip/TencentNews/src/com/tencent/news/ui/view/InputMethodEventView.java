package com.tencent.news.ui.view;

import android.content.Context;
import android.os.Handler;
import android.util.AttributeSet;
import android.widget.RelativeLayout;

import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.SLog;

public class InputMethodEventView extends RelativeLayout {

	private static final int SOFTKEY_MAX_HEIGHT = 150;
	private static final int SOFTKEY_MIN_HEIGHT = 100;
	private Handler uiHandler = new Handler();

	InputMethodChangeLinstener mInputMethodChangeLinstener;

	public InputMethodChangeLinstener getmInputMethodChangeLinstener() {
		return mInputMethodChangeLinstener;
	}

	public void setmInputMethodChangeLinstener(InputMethodChangeLinstener mInputMethodChangeLinstener) {
		this.mInputMethodChangeLinstener = mInputMethodChangeLinstener;
	}

	public interface InputMethodChangeLinstener {
		void onInputMethodOpen();

		void onInputMethodClose();
	}

	public InputMethodEventView(Context context) {
		super(context);
	}

	public InputMethodEventView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public InputMethodEventView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	@Override
	protected void onSizeChanged(int w, final int h, int oldw, final int oldh) {
		super.onSizeChanged(w, h, oldw, oldh);

		if (mInputMethodChangeLinstener != null) {
			uiHandler.post(new Runnable() {

				@Override
				public void run() {

					SLog.i("cjz", "oldh=" + oldh + ", " + "h=" + h + ", " + "oldh - h=" + (oldh - h));

					if (oldh - h > SOFTKEY_MIN_HEIGHT) {
						SLog.i("cjz", "onInputMethodOpen");
						mInputMethodChangeLinstener.onInputMethodOpen();
					} else {
						
						if (oldh != 0 && MobileUtil.getScreenHeightIntPx()-h < SOFTKEY_MAX_HEIGHT) {
							SLog.i("cjz", "onInputMethodClose");
							mInputMethodChangeLinstener.onInputMethodClose();
						}
					}
				}
			});
		}

	}
}
