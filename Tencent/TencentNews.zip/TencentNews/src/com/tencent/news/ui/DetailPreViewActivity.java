package com.tencent.news.ui;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.config.Constants;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.adapter.ImageDetailViewPagerAdapter;
import com.tencent.news.ui.adapter.ImageDetailViewPagerAdapter.DisplayListener;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.news.ui.view.TouchImageView;
import com.tencent.news.ui.view.ViewPagerEx2;
import com.tencent.news.ui.view.ViewPagerEx2.OverScrollListener;
import com.tencent.news.utils.DefaulImageUtil;
import com.tencent.news.utils.ImageCacheNameUtil;
import com.tencent.news.utils.ImageUtil;
import com.tencent.news.utils.ThemeSettingsHelper;
import com.tencent.omg.webdev.WebDev;

public class DetailPreViewActivity extends Activity {
	private TextView mTextCount;
	private ImageView mGapLine;
	private ImageButton mDownLoadBtn;
	private ViewPagerEx2 mImagesViewPager;
	private ImageDetailViewPagerAdapter mImageDetailViewPagerAdapter;
	private List<String> mImageUrl;
	private List<Bundle> mDataList;
	private int nImageCount;
	private int nCurrScreen;
	private int mImgIndex;
	protected ThemeSettingsHelper themeSettingsHelper = null;
	private View mMask;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		overridePendingTransition(R.anim.popup_enter, R.anim.popup_exit);

		setContentView(R.layout.view_image_layout);
		Intent intent = getIntent();
		if (intent != null) {
			mImageUrl = intent.getStringArrayListExtra(Constants.PREVIEW_IMAGE_KEY);
			mImgIndex = intent.getIntExtra("index", 0);
			nCurrScreen = mImgIndex;
		}
		InitView();
		InitListener();
		addImage();

		// themeSettingsHelper.registerThemeCallback(this);
		// themeSettingsHelper.loadDefaultTheme(this);

	}

	@Override
	protected void onDestroy() {
		super.onDestroy();

		if (mImageUrl != null) {
			mImageUrl.clear();
			mImageUrl = null;
		}
		TaskManager.cancelAllImageThread();

		// if(themeSettingsHelper != null){
		// themeSettingsHelper.unRegisterThemeCallback(this);
		// }
	}

	private void InitView() {
		mImagesViewPager = (ViewPagerEx2) findViewById(R.id.image_detail_viewpager);
		mImageDetailViewPagerAdapter = new ImageDetailViewPagerAdapter();
		mImagesViewPager.setAdapter(mImageDetailViewPagerAdapter);
		mImageDetailViewPagerAdapter.setDisplayListener(new DisplayListener() {
			@Override
			public void onShowImage(int index, Bundle dataBundle, TouchImageView view) {
				view.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						quitActivity();
					}
				});
			}
		});
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(this);
		mMask = (View) findViewById(R.id.detailpremask_view);
		if (themeSettingsHelper.isDefaultTheme()) {
			mMask.setBackgroundColor(getResources().getColor(R.color.mask_page_color));
		} else {
			mMask.setBackgroundColor(getResources().getColor(R.color.night_mask_page_color));
		}

		mTextCount = (TextView) findViewById(R.id.image_text_count);
		mGapLine = (ImageView) findViewById(R.id.download_gap_line);
		mDownLoadBtn = (ImageButton) findViewById(R.id.download_image_btn);
	}

	private void InitListener() {
		mDownLoadBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				String path = ImageCacheNameUtil.getSaveImageFileName(mImageUrl.get(nCurrScreen));
				Bitmap showBitmap = mImagesViewPager.getCurrentBitmap();
				if (showBitmap != null && !showBitmap.equals(DefaulImageUtil.getDefaultPhotoDetailImage())) {
					boolean bFlag = ImageUtil.saveBitmap(showBitmap, path, ImageUtil.QUALITY_HIGH);
					if (bFlag) {
						Uri localUri = Uri.fromFile(new File(path));
						Intent localIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, localUri);
						sendBroadcast(localIntent);

						TipsToast.getInstance().showTipsSuccess("已下载到相册");
					} else {
						TipsToast.getInstance().showTipsError("下载失败");
					}
				}
			}
		});

		mImagesViewPager.setOnPageChangeListener(new OnPageChangeListener() {
			@Override
			public void onPageSelected(int arg0) {
				nCurrScreen = arg0;
				mTextCount.setText((nCurrScreen + 1) + "/" + nImageCount);
			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
			}

			@Override
			public void onPageScrollStateChanged(int arg0) {
			}
		});

		mImagesViewPager.setOverScrollListener(new OverScrollListener() {
			@Override
			public void onOverScrollToRight() {
			}

			@Override
			public void onOverScrollToLeft() {
				quitActivity();
			}
		});
	}

	protected void quitActivity() {
		if (mImgIndex != nCurrScreen) {
			Intent intent = new Intent();
			intent.putExtra(Constants.WATICH_IMAGE_CURRENT_INDEX_BACK, nCurrScreen);
			setResult(RESULT_OK, intent);
		}

		finish();
		overridePendingTransition(0, R.anim.popup_exit);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			quitActivity();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	private void addImage() {
		nImageCount = mImageUrl.size();
		mDataList = new ArrayList<Bundle>(nImageCount);
		if (nImageCount > 0 && nImageCount <= 1) {
			mTextCount.setVisibility(View.GONE);
			mGapLine.setVisibility(View.GONE);
		} else {
			int n = mImgIndex + 1;
			mTextCount.setText(n + "/" + nImageCount);
		}

		for (int i = 0; i < nImageCount; i++) {
			Bundle bundle = new Bundle();
			bundle.putString("image", mImageUrl.get(i));
			mDataList.add(bundle);
		}

		mImageDetailViewPagerAdapter.setData(mDataList);
		mImagesViewPager.setCurrentItem(mImgIndex);
	}

	// @Override
	// public void applyTheme() {
	// TODO Auto-generated method stub
	// }
	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}
}
