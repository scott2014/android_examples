package com.tencent.news.ui.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.utils.ThemeSettingsHelper;
/**
 * 加载重试提示布局实现类
 * @author hanyandu
 *
 */
public class LoadAndRetryBar extends LinearLayout {

	private Context mContext = null;
	private ProgressBar loadingBar;
	private TextView loadingTile = null;
	private LinearLayout thisView;
	
	private LinearLayout layout;
	private LinearLayout shortLayout;
	private TextView shortText;
	protected ThemeSettingsHelper themeSettingsHelper = null;
	

	public LoadAndRetryBar(Context context, AttributeSet attrs) {
		super(context, attrs);
		mContext = context;		
		initView();
	}

	public LoadAndRetryBar(Context context) {
		super(context);
		mContext = context;
		initView();
	}
	
	public void initView() {
		LayoutInflater.from(mContext).inflate(R.layout.view_layout_loading_bar, this, true);
		loadingBar = (ProgressBar)findViewById(R.id.loading_progress);
		loadingTile = (TextView)findViewById(R.id.loading_textview);
		thisView = (LinearLayout) findViewById(R.id.loading_and_retry_bar);
		
		layout = (LinearLayout) findViewById(R.id.layout);
		shortLayout = (LinearLayout) findViewById(R.id.layout_short);
		shortText = (TextView) findViewById(R.id.loading_textview_short);		
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(mContext);
	}
	
	public void applyBarTheme(){			
		themeSettingsHelper.setViewBackgroud(mContext, thisView, R.drawable.loading_bar_bg);
		themeSettingsHelper.setTextViewColor(mContext, loadingTile, R.color.loading_bar_text_color);
		themeSettingsHelper.setTextViewColor(mContext, shortText, R.color.loading_bar_text_color);
	}
	
	/**
	 * 显示加载错误提示
	 * @param msg
	 */
	public void setErrorMsg() {
		thisView.setVisibility(View.VISIBLE);
		layout.setVisibility(GONE);
		shortLayout.setVisibility(VISIBLE);
		shortText.setText(getResources().getString(R.string.loading_error));
	}
	
	/**
	 * 显示手动加载更多
	 */
	public void showManualMessage() {
		thisView.setVisibility(View.VISIBLE);
		layout.setVisibility(GONE);
		shortLayout.setVisibility(VISIBLE);
		shortText.setText(R.string.click_for_loading_more);
	}
	
	/**
	 * 显示加载内容完毕
	 * @param msg
	 */
	public void showComplete(){
		thisView.setVisibility(View.VISIBLE);
		layout.setVisibility(GONE);
		shortLayout.setVisibility(VISIBLE);
		shortText.setText(R.string.all_has_show);
	}
	
	
	/**
	 * 显示自动加载
	 */
	public void showLoadingBar() {
		thisView.setVisibility(View.VISIBLE);
		layout.setVisibility(VISIBLE);
		shortLayout.setVisibility(GONE);
		loadingTile.setText(R.string.loading_wait);
	}
	
	public void showNoIndicatorBar(String info) {
		thisView.setVisibility(View.VISIBLE);
		layout.setVisibility(GONE);
		shortLayout.setVisibility(VISIBLE);
		shortText.setText(info.trim());
	}
	
	public void dismiss() {
		thisView.setVisibility(GONE);
	}
	
	public void setRetryButtonOnClickListener(OnClickListener clickListener) {
		loadingTile.setOnClickListener(clickListener);
	}

}
