package com.tencent.news.ui.view;

import java.lang.reflect.Field;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;

import com.tencent.news.R;
import com.tencent.news.utils.ThemeSettingsHelper;

public class IphoneTreeView extends ExpandableListView {
	public static final String TAG = "IphoneTreeView";
	private static final boolean DEBUG = false;
	private View mFloatingGroupView;
	private View mInvisableGroupView;
	private View mConvertView;
	private int mFloatingGroupViewGroupPosition = -1;
	private Drawable mGroupIndicator;
	private Drawable mGroupExpanded;
	private final Rect tmpRect = new Rect();
	private boolean mDraw;
	private boolean isFloat = false;

	protected ThemeSettingsHelper themeSettingsHelper = null; // 支持夜间模式

	public IphoneTreeView(Context context) {
		super(context);
		init();
	}

	public IphoneTreeView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	public IphoneTreeView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init();
	}

	private OnTouchListener listener = new OnTouchListener() {
		@Override
		public boolean onTouch(View v, MotionEvent event) {
			switch (event.getAction()) {
			case MotionEvent.ACTION_DOWN:
				v.setPressed(true);
				invalidate();
				return true;
			case MotionEvent.ACTION_CANCEL:
				v.setPressed(false);
				invalidate();
				break;
			case MotionEvent.ACTION_UP:
				if (v.isPressed()) {
					v.setPressed(false);
					// collapseGroup(mFloatingGroupViewGroupPosition);
					// setSelectedGroup(mFloatingGroupViewGroupPosition);
					mFloatingGroupView = null;
				}
				return true;
			}
			return false;
		}
	};

	public void setGroupIndicator(Drawable groupIndicator) {
		super.setGroupIndicator(groupIndicator);
		mGroupIndicator = groupIndicator;
		if (groupIndicator != null && groupIndicator != mGroupExpanded) {
			mGroupExpanded = groupIndicator;// .getConstantState().newDrawable();
		}
	}

	private Object getField(String field) {
		Class<ExpandableListView> clazz = (Class<ExpandableListView>) getClass().getSuperclass();
		try {
			Field f = clazz.getDeclaredField(field);
			if (!f.isAccessible()) {
				f.setAccessible(true);
			}
			return f.get(this);
		} catch (Exception e) {
			// e.printStackTrace();
		}
		return null;
	}

	private void init() {
		mGroupIndicator = (Drawable) getField("mGroupIndicator");
		setGroupIndicator(mGroupIndicator);
	}

	@Override
	public boolean dispatchTouchEvent(MotionEvent ev) {
		if (mFloatingGroupView != null) {
			mFloatingGroupView.getGlobalVisibleRect(tmpRect);
			if (tmpRect.contains((int) ev.getX(), (int) ev.getY())) {
				return true;
			}
			// if (tmpRect.contains((int) ev.getX(), (int) ev.getY())) {
			// //--->start add by cjz 2012-11-26 15:51:45,让事件透下去
			// mFloatingGroupView.setPressed(false);
			// //<---end add by cjz 2012-11-26 15:51:42
			// boolean b = mFloatingGroupView.dispatchTouchEvent(ev);
			// if (b)
			// return b;
			// } else {
			// mFloatingGroupView.setPressed(false);
			// invalidate();
			// }
		}
		try {// Only for Android 2.2
			return super.dispatchTouchEvent(ev);
		} catch (ArrayIndexOutOfBoundsException e) {
			return true;
		} catch (Throwable e) {
			e.printStackTrace(); // 这里要小心
			return true;
		}
	}

	@Override
	protected void dispatchDraw(Canvas canvas) {
		final int childCount = getChildCount();
		View firstView = null;
		View nextView = null;
		switch (childCount) {
		case 0:
			super.dispatchDraw(canvas);
			return;
		case 1:
			firstView = getChildAt(0);
			break;
		default:
			firstView = getChildAt(0);
			nextView = getChildAt(1);
			break;
		}
		mDraw = true;
		int firstPos = getFirstVisiblePosition();
		if (VERSION.SDK_INT < 8) {// Android 2.2
			firstPos -= getHeaderViewsCount();
		}
		for (int i = 0; i < childCount; i++) {
			View child = getChildAt(i);
			if (child.getBottom() > 0 && i + 1 < childCount) {
				firstView = child;
				nextView = getChildAt(i + 1);
				firstPos += i;
				break;
			}
		}
		long packedPos = getExpandableListPosition(firstPos);
		final int groupPos = getPackedPositionGroup(packedPos);
		final int type = getPackedPositionType(packedPos);
		if (DEBUG) {
			Log.d(TAG, "groupPos:" + groupPos);
			Log.d(TAG, "first view type:" + type);
		}
		mInvisableGroupView = null;
		if (groupPos != -1 && isGroupExpanded(groupPos)) {
			if (isFloat/*
						 * mFloatingGroupView == null || type ==
						 * PACKED_POSITION_TYPE_GROUP
						 */) {
				mFloatingGroupViewGroupPosition = groupPos;
				mFloatingGroupView = getExpandableListAdapter().getGroupView(groupPos, true, mConvertView, this);
				// /夜间模式傻瓜版改法，未生效？
				// /
				themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(this.getContext());// ?
				//
				if (themeSettingsHelper.isDefaultTheme()) {
					mFloatingGroupView.findViewById(R.id.bar_view).setBackgroundResource(R.drawable.special_report_section_bg);
				} else {
					mFloatingGroupView.findViewById(R.id.bar_view).setBackgroundResource(R.drawable.night_special_report_section_bg);
				}
				// //////

				if (mFloatingGroupView != mConvertView) {
					mConvertView = mFloatingGroupView;
				}
				mFloatingGroupView.setSelected(firstView.isSelected());
				mFloatingGroupView.setOnTouchListener(listener);
				if (getPackedPositionType(packedPos) == PACKED_POSITION_TYPE_GROUP) {
					mInvisableGroupView = firstView;
				}
				measureScrapChild(mFloatingGroupView, groupPos, MeasureSpec.UNSPECIFIED, firstView.getWidth());
				mFloatingGroupView.layout(0, 0, +mFloatingGroupView.getMeasuredWidth(), mFloatingGroupView.getMeasuredHeight());
				if (DEBUG) {
					Log.d(TAG, "create mFloatingGroupView (" + mFloatingGroupView.getMeasuredWidth() + "," + mFloatingGroupView.getMeasuredHeight() + ")");
				}
			}
		} else {
			mFloatingGroupView = null;
		}
		super.dispatchDraw(canvas);
		// draw floatingGroupView
		if (mFloatingGroupView != null) {
			packedPos = getExpandableListPosition(firstPos + 1);
			if (DEBUG) {
				Log.d(TAG, "next view type:" + getPackedPositionType(packedPos));
			}
			int dy = 0;
			Drawable divider = null;
			if (getPackedPositionType(packedPos) == PACKED_POSITION_TYPE_GROUP && nextView != null) {
				int t = nextView.getTop();
				int b = mFloatingGroupView.getBottom();
				if (t < b) {
					dy = t - b;
					divider = getDivider();
				}
			}
			canvas.translate(0, dy);
			if (mFloatingGroupView.isPressed()) {
				Drawable selector = getSelector();
				Rect bounds = new Rect(selector.getBounds().left, mFloatingGroupView.getTop(), selector.getBounds().right, mFloatingGroupView.getBottom());
				selector.setBounds(bounds);
				getSelector().draw(canvas);
			}
			canvas.translate(getPaddingLeft(), 0);
			mFloatingGroupView.draw(canvas);
			canvas.translate(-getPaddingLeft(), 0);
			if (mGroupExpanded.isStateful()) {
				mGroupExpanded.setState(new int[] { android.R.attr.state_expanded });
			}
			// mGroupExpanded.setBounds((Integer) getField("mIndicatorLeft"),
			// mFloatingGroupView.getTop(), (Integer)
			// getField("mIndicatorRight"), mFloatingGroupView.getBottom());
			mGroupExpanded.setBounds(0, mFloatingGroupView.getTop(), 0, mFloatingGroupView.getBottom());
			mGroupExpanded.draw(canvas);
			if (divider != null) {
				divider.setBounds(mFloatingGroupView.getLeft(), mFloatingGroupView.getBottom() - getDividerHeight(), mFloatingGroupView.getRight(), mFloatingGroupView.getBottom());
				canvas.clipRect(mFloatingGroupView.getLeft(), mFloatingGroupView.getBottom() - getDividerHeight() + dy, mFloatingGroupView.getRight(), mFloatingGroupView.getBottom() + dy);
				divider.draw(canvas);
			}
			canvas.translate(0, -dy);
		}
		mDraw = false;
	}

	@Override
	public View getChildAt(int index) {
		View child = super.getChildAt(index);
		if (mDraw) {
			if (mFloatingGroupView != null && child == mInvisableGroupView) {
				super.setGroupIndicator(null);
			} else {
				super.setGroupIndicator(mGroupIndicator);
			}
		}
		return child;
	}

	@Override
	protected boolean drawChild(Canvas canvas, View child, long drawingTime) {
		boolean b = true;
		if (child != mInvisableGroupView) {
			b = super.drawChild(canvas, child, drawingTime);
		}
		return b;
	}

	private void measureScrapChild(View child, int position, int widthMeasureSpec, int width) {
		LayoutParams p = (LayoutParams) child.getLayoutParams();
		if (p == null) {
			p = new LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0);
			child.setLayoutParams(p);
		}
		// p.viewType = mAdapter.getItemViewType(position);
		int childWidthSpec = ViewGroup.getChildMeasureSpec(widthMeasureSpec, getPaddingLeft() + getPaddingRight(), width);
		int lpHeight = p.height;
		int childHeightSpec;
		if (lpHeight > 0) {
			childHeightSpec = MeasureSpec.makeMeasureSpec(lpHeight, MeasureSpec.EXACTLY);
		} else {
			childHeightSpec = MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED);
		}
		child.measure(childWidthSpec, childHeightSpec);
	}

	@Override
	protected boolean isInFilterMode() {
		return true;
	}

	/**
	 * 列表头部Header
	 */
	private View mListHeader;

	/**
	 * 头部Header高度。
	 */
	private int mHeadHeight;
	private TopHeadShowListener mTopShowListener;
	float fy = 0;

	/**
	 * 当前是否可以下滑显示头部
	 */
	boolean canDisplay = false;

	@Override
	public boolean onTouchEvent(MotionEvent ev) {
		float ydis;
		if (ev.getAction() == MotionEvent.ACTION_UP || ev.getAction() == MotionEvent.ACTION_CANCEL) {
			canDisplay = false;
			int paddintTop = mListHeader.getPaddingTop();
			int showLimitHeight = (mHeadHeight / 5) * 2;// 2/5显示与隐藏的界限
			if (paddintTop < 0 && paddintTop >= -showLimitHeight) {
				// 显示
				mListHeader.setPadding(mListHeader.getPaddingLeft(), 0, mListHeader.getPaddingRight(), mListHeader.getPaddingBottom());
				requestLayout();
			} else if (paddintTop < -showLimitHeight && paddintTop > -mHeadHeight) {
				// 隐藏
				hideHeader();
			}
		} else if (ev.getAction() == MotionEvent.ACTION_DOWN) {
			fy = ev.getY();
			// 列表已经滑到顶的情况下，向下滑动才能显示header
			if (getFirstVisiblePosition() == 0) {
				canDisplay = true;
			}
		} else if (ev.getAction() == MotionEvent.ACTION_MOVE) {
			ydis = fy - ev.getY();
			fy = ev.getY();
			if (ydis < -1) {
				if (getFirstVisiblePosition() == 0 && mListHeader != null && mTopShowListener != null) {
					if (canDisplay) {
						if (mListHeader.getPaddingTop() <= -mHeadHeight) {
							// 之前是隐藏状态，现在变为显示状态
							mTopShowListener.onTopHeadShow();
						}
						int newpaddingTop = mListHeader.getPaddingTop() - (int) ydis;
						if (newpaddingTop > 0) {
							newpaddingTop = 0;
						}
						mListHeader.setPadding(mListHeader.getPaddingLeft(), newpaddingTop, mListHeader.getPaddingRight(), mListHeader.getPaddingBottom());
					}
				}
			}
			if (ydis > 1) {
				if (mListHeader != null && mTopShowListener != null) {
					int newpaddingTop = mListHeader.getPaddingTop() - (int) ydis;
					if (newpaddingTop < -mHeadHeight) {
						newpaddingTop = -mHeadHeight;
						if (mListHeader.getPaddingTop() > -mHeadHeight) {
							// 之前为显示状态，现在变为隐藏状态
							mTopShowListener.onTopHeadHide();
						}
					}
					mListHeader.setPadding(mListHeader.getPaddingLeft(), newpaddingTop, mListHeader.getPaddingRight(), mListHeader.getPaddingBottom());
				}
			}
			if (getFirstVisiblePosition() != 0) {
				canDisplay = false;
			}
		}
		return super.onTouchEvent(ev);
	}

	public void addHeaderView(View v, int headHeight) {
		mListHeader = v;
		mHeadHeight = headHeight;
		mListHeader.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				if (mTopShowListener != null) {
					mTopShowListener.onHeaderClicked(v);
				}
			}
		});
		super.addHeaderView(v);
	}

	public void setTopShowListener(TopHeadShowListener listener) {
		mTopShowListener = listener;
	}

	/**
	 * 设置head的paddingTop
	 * 
	 * @param paddingtop
	 */
	private void setHeaderPaddingTop(int paddingtop) {
		mListHeader.setPadding(mListHeader.getPaddingLeft(), paddingtop, mListHeader.getPaddingRight(), mListHeader.getPaddingBottom());
	}

	/**
	 * 隐藏列表Header
	 */
	public void hideHeader() {
		setHeaderPaddingTop(-mHeadHeight);
		// mListHeader.findViewById(R.id.refresh_divider).setVisibility(View.INVISIBLE);
	}

	/**
	 * 列表Header显示相关回调。
	 * 
	 * @author vinneywang
	 * 
	 */
	public interface TopHeadShowListener {
		/**
		 * TopHead显示的回调。
		 */
		public void onTopHeadShow();

		/**
		 * TopHead隐藏的回调。
		 */
		public void onTopHeadHide();

		/**
		 * TopHead点击的回调。
		 * 
		 * @param v
		 */
		public void onHeaderClicked(View v);
	}

	public void setFloat(boolean isFloat) {
		this.isFloat = isFloat;
	}

	public void applyIphoneTreeView(Context context) {
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(context);
		// themeSettingsHelper.setViewBackgroud(context,
		// this.mFloatingGroupView, R.drawable.special_report_section_bg);

		// themeSettingsHelper.setImageButtonSrc(context, this.btnShare,
		// R.drawable.title_share_btn);
		// themeSettingsHelper.setImageButtonSrc(context, this.btnSetting,
		// R.drawable.title_setting_btn);
		// themeSettingsHelper.setViewBackgroud(context, this.mBackBtn,
		// R.drawable.title_back_btn);
	}
}
