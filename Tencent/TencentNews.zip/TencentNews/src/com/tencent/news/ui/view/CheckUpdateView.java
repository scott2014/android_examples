package com.tencent.news.ui.view;

import java.io.File;
import java.lang.ref.WeakReference;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.boss.EventId;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpDataResponse;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.download.APPDownloadListener;
import com.tencent.news.download.DownloadConstants;
import com.tencent.news.download.DownloadDataCheck;
import com.tencent.news.download.DownloadManager;
import com.tencent.news.download.Downloader;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.pojo.NewsVersion;
import com.tencent.news.shareprefrence.SpConfig;
import com.tencent.news.system.Application;
import com.tencent.news.system.NetStatusReceiver;
import com.tencent.news.task.TaskManager;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.ThemeSettingsHelper;
import com.tencent.omg.webdev.WebDev;


/**
* @author jianhu
* @version 创建时间：2013-5-2 下午12:16:42
* 检查更新bar
* 
* 
* 
*/
public class CheckUpdateView  extends LinearLayout implements  APPDownloadListener, HttpDataResponse{
	
	
	private final static int CHECK_UPDATE = 1028;
	private final static int ENTER_PAGE = 1;
	private final static int CLICK_CHECKBAR = 2;
	private final static int CLICK_BTN = 3;
	
	private Context mContext;
	
	private ImageView icon_update = null;
	private ImageView checkUpdateDesc = null;
//	private TextView txtView_update = null;
	private TextProgressBar checkUpdateButton;
	private Dialog dialog;
	private TextView checkUpdateTitle;
	private Toast toast = null;
	
	private boolean isSendReq = false;
	private int responseType = 0;
	private boolean isBtnClickable = true;
	private boolean isCheckUpdateBarClickable = true;
	private boolean isInstall = false;
	private NewsHandler mHandler = null;
	private int mState = DownloadConstants.T_DOWNLOAD;
	
	protected ThemeSettingsHelper themeSettingsHelper = null;
	
	private String versionCode = "";
	private String updateUrl = "";
	

	private NewsVersion mVersion = Application.getInstance().getVersion();

	public CheckUpdateView(Context context) {
		super(context);
		initView(context);
	}
	
	public CheckUpdateView(Context context, AttributeSet attrs) {
		super(context, attrs);
		initView(context);
	}
	
	private void initView(Context context){
		mContext = context;
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(mContext);
		LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		
		if (themeSettingsHelper.isNightTheme())
			inflater.inflate(R.layout.night_view_check_update_item, this, true);
		else
			inflater.inflate(R.layout.view_check_update_item, this, true);
		
		icon_update = (ImageView) findViewById(R.id.icon_update);
		checkUpdateTitle = (TextView) findViewById(R.id.txtView_update);
		checkUpdateDesc = (ImageView) findViewById(R.id.check_update_desciption);
//		txtView_update = (TextView) findViewById(R.id.txtView_update);
		checkUpdateButton = (TextProgressBar) findViewById(R.id.updateBtn);
		
		if (themeSettingsHelper.isNightTheme())
			checkUpdateButton.setTextColor(0xfff0f4f8);
		else
			checkUpdateButton.setTextColor(Color.BLACK);
//		checkUpdateButton.setTextColor(Color.BLACK);
		
		checkUpdateButton.setTextSize(MobileUtil.dpToPx(14));
		
		init();
		initViewsByMode();
		checkState();
		initListener();
	}
	
	private void initViewsByMode()
	{
		themeSettingsHelper.setViewBackgroudColor(mContext, this, R.color.viewpage_bg_color);
		themeSettingsHelper.setTextViewColor(mContext, checkUpdateTitle, R.color.list_title_color);
		themeSettingsHelper.setImageViewSrc(mContext, icon_update, R.drawable.icon_setting_update);
	}
	
	public void init(){
		SLog.d("hj", "doanload:addListener");
		DownloadManager.getInstance().addAppListener(Constants.APPID, this);
		mHandler = new NewsHandler(this);
	}
	
	private boolean isFileExist(){
		
		if("".equals(updateUrl)){
			return true;
		}
		String fileName = Downloader.getLocalfileName(updateUrl);
		String localAPKPath = Downloader.DOWNLOAD_PATH + "_" + Constants.APPID + "_" + fileName;
		File f = new File(localAPKPath);
		if(f.exists()){
			SLog.d("hj", "f.exists()");
			return true;
		}else{
			return false;
		}
	}
	
	private void checkState(){
		
		isCheckUpdateBarClickable = false;
		if(mVersion != null ){
			SLog.d("hj", "mVersion is not null: " + mVersion.getMessage());
			if(MobileUtil.versionUpgrade(mVersion)){
				SpConfig.setCheckUpdateFlag(true);
			}
			versionCode = mVersion.getVersion();
			updateUrl = mVersion.getUrl();
		}
			mState = DownloadDataCheck.getInstance().checkDBOption(Constants.APPID, versionCode, updateUrl);
			if(mState == DownloadConstants.T_INSTALL && !isFileExist()){
				mState = DownloadConstants.T_DOWNLOAD;
			}
			if (mState == DownloadConstants.T_PAUSE) {
				int progress = DownloadDataCheck.getInstance().getUpdateProgress(Constants.APPID);
				setTitle(true);
				checkUpdateButton.setProgress(progress);
				checkUpdateButton.setText("继续");
			} else {
				setProgressState(0, "");
			}
	}
	
	private void initListener(){
		
		this.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				
				WebDev.trackCustomEvent(mContext, EventId.BOSS_SETTING_CHECKUPDATE);
				
				SLog.d("hj", "checkUpdateView clicked");
				
				if(SpConfig.getCheckUpdateFlag()){
					doClick();
				}else{
					if(!isCheckUpdateBarClickable || isSendReq){
						return ;
					}
					if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_INAVAILABLE) {
						TipsToast.getInstance().showTipsError(mContext.getResources().getString(R.string.string_http_data_nonet));
						return;
					}
					
					isSendReq = true;
					if (mVersion != null && MobileUtil.versionUpgrade(mVersion)) {
						mHandler.sendEmptyMessage(CHECK_UPDATE);
					} else {
						responseType = 2;
						getNewsVersionInfo();
					}
				}
			}
		});
		
		checkUpdateButton.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				
				WebDev.trackCustomEvent(mContext, EventId.BOSS_SETTING_CHECKUPDATE);
				
				//   Auto-generated method stub
				SLog.d("hj", "checkUpdateButton is clicked");
				doClick();
			}
			
		});
	}
	
	private void doClick(){
		if (!isBtnClickable) {
			return;
		}
		
		if (!isInstall && NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_INAVAILABLE) {
			TipsToast.getInstance().showTipsError(mContext.getResources().getString(R.string.string_http_data_nonet));
			return;
		}
		
		start();
	}
	private void showDialog(){
			
		if(MobileUtil.versionUpgrade(mVersion)){//test remember change state !
			SpConfig.setCheckUpdateFlag(true);
			dialog = new AlertDialog.Builder(mContext).setTitle(mContext.getResources().getString(R.string.dialog_check_title) + convert(mVersion.getVersion()))
					.setMessage(mVersion.getMessage())
					.setPositiveButton(mContext.getResources().getString(R.string.dialog_ignore_update),
							new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface dialog, int which) {
									
									cancel();

								}
							})
					.setNegativeButton(mContext.getResources().getString(R.string.dialog_start_update),
							new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface dialog, int which) {
									
									start();

								}
							}).setCancelable(false).create();
			dialog.setOnDismissListener(new DialogInterface.OnDismissListener(){

				@Override
				public void onDismiss(DialogInterface dialog) {
					//   Auto-generated method stub
					SLog.d("hj", "setting check update dialog onDismiss");
					isSendReq = false;
				}
			});
			dialog.show();
			}else{
/*				dialog = new AlertDialog.Builder(mContext)
				.setTitle(mContext.getResources().getString(R.string.dialog_title))
				.setMessage(mContext.getResources().getString(R.string.dialog_newest_version))
				.setPositiveButton(mContext.getResources().getString(R.string.dialog_ok),
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int which) {
								
							}
						}).create();*/		
									
				   if (toast == null) {
			            toast = Toast.makeText(mContext, getResources().getString(R.string.dialog_newest_version), Toast.LENGTH_SHORT);
			        } else {
			            toast.setText(getResources().getString(R.string.dialog_newest_version));
			        }
			        toast.show();
					isSendReq = false;
			    }
	}
	
	private String convert(String versionCode) {

		StringBuilder sb = new StringBuilder("v");
		for (int i = 0; i < versionCode.length() - 1; ++i) {
			sb.append(versionCode.charAt(i) + ".");
		}
		sb.append(versionCode.charAt(versionCode.length() - 1));
		return sb.toString();
	}
	
	private static class NewsHandler extends Handler {
		private WeakReference<CheckUpdateView> mOuterClass;

		NewsHandler(CheckUpdateView view) {
			mOuterClass = new WeakReference<CheckUpdateView>(view);
		}

		@Override
		public void handleMessage(android.os.Message msg) {
			super.handleMessage(msg);
			CheckUpdateView mTheClass = mOuterClass.get();
			
			switch (msg.what) {
			case CHECK_UPDATE:
				mTheClass.showDialog();
				break;
			}
		}
	}
	
	private void getNewsVersionInfo(){
		SLog.d("hj", "send check update req");
		new Thread(new Runnable(){

			@Override
			public void run() {
				//   Auto-generated method stub
				
				HttpDataRequest request = TencentNews.getInstance().getQQNewsVersionInfo();
				TaskManager.startHttpDataRequset(request, CheckUpdateView.this);
			}
			
		}).start();

	}
	
	@Override
	public void onHttpRecvOK(HttpTag tag, Object result) {
		//   Auto-generated method stub
		if (tag.equals(HttpTag.NEWS_CHECK_UPDATE)) {
			SLog.d("NEWS_CHECK_UPDATE");
			mVersion = (NewsVersion) result;
			Application.getInstance().setVersion(mVersion);
			SLog.d("hj", mVersion.getMessage() + " "+mVersion.getUrl() + " "+ mVersion.getVersion());
			
			switch(responseType){
			case ENTER_PAGE:
				if(mVersion != null && MobileUtil.versionUpgrade(mVersion)){
					checkUpdateButton.setVisibility(View.VISIBLE);
					checkUpdateDesc.setVisibility(View.VISIBLE);
					isCheckUpdateBarClickable = false;
					SpConfig.setCheckUpdateFlag(true);
				}
				break;
			case CLICK_CHECKBAR:
				mHandler.sendEmptyMessage(CHECK_UPDATE);
				break;
			case CLICK_BTN:
				start();
				break;
			default:
				break;
			}
		}
	}

	@Override
	public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {
		//   Auto-generated method stub
		isSendReq = false;
		
	}

	@Override
	public void onHttpRecvCancelled(HttpTag tag) {
		//   Auto-generated method stub
		isSendReq = false;
		
	}
	
	public void start(){
		
		SLog.d("hj", "download start");
		SpConfig.setSilentDownloadFlag(Constants.SILENT_DEFAULT);
		if(mVersion != null ){
			versionCode = mVersion.getVersion();
			updateUrl = mVersion.getUrl();
		}
		
		isCheckUpdateBarClickable = false;
		setTitle(true);
		checkUpdateDesc.setVisibility(View.VISIBLE);
		checkUpdateButton.setVisibility(View.VISIBLE);
		DownloadManager.getInstance().doStateAction(Constants.APPID, mState, updateUrl, "com.tencent.news", "腾讯新闻", this, versionCode,true);
	}
	
/*	public void install() {
		File installFile = new File("/sdcard/MyTencentNews.apk");
		if(installFile.exists()){
			Intent intent = new Intent(Intent.ACTION_VIEW);
			intent.setDataAndType(Uri.fromFile(installFile),
					"application/vnd.android.package-archive");
			context.startActivity(intent);	
		}
	}*/	
	
	private void cancel(){
		
		isCheckUpdateBarClickable = false;
		setTitle(true);
		checkUpdateDesc.setVisibility(View.VISIBLE);
		checkUpdateButton.setVisibility(View.VISIBLE);
		
		if (themeSettingsHelper.isNightTheme())
			checkUpdateButton.setTextColor(0xff5fabf1);
		else
			checkUpdateButton.setTextColor(0xFF0762A7);
		
//		checkUpdateButton.setTextColor(0xFF0762A7);
		
		checkUpdateButton.setProgress(0);
		checkUpdateButton.setText("更新");
	}

	@Override
	public void downloadStateChanged(String TAG, int state, int n_progress,
			String t_progress) {
		//   Auto-generated method stub
		mState = state;
		setProgressState(n_progress, t_progress);
	}
	
	private void setTitle(boolean isNew){
		if(isNew){
			checkUpdateTitle.setText(mContext.getResources().getString(R.string.setting_check_update_title_new));

		}else{
			checkUpdateTitle.setText(mContext.getResources().getString(R.string.setting_check_update_title));
		}
	}
	private void setProgressState(int n_progress, String t_progress){
		 
		SLog.d("hj", "setProgressState");
		Application.getInstance().setDownloadState(mState);
		if(mState == DownloadConstants.T_DOWNLOAD){
		
/*			if(mVersion != null && MobileUtil.versionUpgrade(mVersion)){
				SLog.d("hj", "newVersion");
				setTitle(true);
				checkUpdateButton.setTextColor(0xFF0762A7);
			}else{
				SLog.d("hj", "isCheckUpdateBarClickable true");
				setTitle(false);
				isCheckUpdateBarClickable = true;
				checkUpdateButton.setVisibility(View.INVISIBLE);
				checkUpdateDesc.setVisibility(View.INVISIBLE);
			}*/	
					
			if(SpConfig.getCheckUpdateFlag()){
				SLog.d("hj", "newVersion");
				setTitle(true);
//				checkUpdateButton.setTextColor(0xFF0762A7);
				if (themeSettingsHelper.isNightTheme())
					checkUpdateButton.setTextColor(0xff5fabf1);
				else
					checkUpdateButton.setTextColor(0xFF0762A7);
			}else{
				SLog.d("hj", "isCheckUpdateBarClickable true");
				setTitle(false);
				isCheckUpdateBarClickable = true;
				checkUpdateButton.setVisibility(View.INVISIBLE);
				checkUpdateDesc.setVisibility(View.INVISIBLE);
			}
			
		}else{
			setTitle(true);
//			checkUpdateButton.setTextColor(Color.BLACK);
			if (themeSettingsHelper.isNightTheme())
				checkUpdateButton.setTextColor(0xfff0f4f8);
			else
				checkUpdateButton.setTextColor(Color.BLACK);
		}
		
		isInstall = false;
		
		switch(mState){
		case DownloadConstants.T_DOWNLOAD:
			//下载
			checkUpdateButton.setProgress(0);
			checkUpdateButton.setText("更新");
			break;
		case DownloadConstants.T_PAUSE:
			//继续下载
			checkUpdateButton.setProgress(n_progress);
			checkUpdateButton.setText("继续");
			break;
		case DownloadConstants.T_UPDATE:
			//更新下载
			checkUpdateButton.setProgress(0);
			checkUpdateButton.setText("更新");
			break;
		case DownloadConstants.T_OPEN:
			//打开应用
			//checkUpdateButton.setProgress(n_progress, "启动");
			break;
		case DownloadConstants.T_INSTALL:
			//启动安装
			isInstall = true;
			checkUpdateButton.setProgress(100);
			checkUpdateButton.setText("安装");
			break;

		case DownloadConstants.T_UPDATE_PROGRESS:
			//停止
			checkUpdateButton.setProgress(n_progress);
			checkUpdateButton.setText(t_progress);
			break;
		default:
			break;
	}
		isBtnClickable = true;
	}
	
}
