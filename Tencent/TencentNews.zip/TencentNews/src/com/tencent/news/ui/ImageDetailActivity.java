package com.tencent.news.ui;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.boss.EventId;
import com.tencent.news.cache.NewsDetailCache;
import com.tencent.news.cache.NewsDetailCache.CacheType;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.pojo.ExtendedChannels;
import com.tencent.news.model.pojo.Image;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.model.pojo.SimpleNewsDetail;
import com.tencent.news.shareprefrence.SpUserHelp;
import com.tencent.news.system.AddCommentBroadcastReceiver;
import com.tencent.news.system.Application;
import com.tencent.news.system.RefreshCommentNumBroadcastReceiver;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.adapter.ImageDetailViewPagerAdapter;
import com.tencent.news.ui.adapter.ImageDetailViewPagerAdapter.DisplayListener;
import com.tencent.news.ui.adapter.ViewPagerAdapter;
import com.tencent.news.ui.view.CommentView;
import com.tencent.news.ui.view.ImageDetailView;
import com.tencent.news.ui.view.ImageRecommendView;
import com.tencent.news.ui.view.NavigationBar;
import com.tencent.news.ui.view.ShareDialog;
import com.tencent.news.ui.view.ShareDialog.ShareDismissListener;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.news.ui.view.TouchImageView;
import com.tencent.news.ui.view.ViewPagerEx;
import com.tencent.news.ui.view.ViewPagerEx2;
import com.tencent.news.ui.view.ViewPagerEx2.OverScrollListener;
import com.tencent.news.ui.view.WritingCommentView;
import com.tencent.news.ui.view.WritingCommentView.OnChangeClick;
import com.tencent.news.ui.view.WritingCommentView.OnDownloadClick;
import com.tencent.news.utils.DefaulImageUtil;
import com.tencent.news.utils.ImageCacheNameUtil;
import com.tencent.news.utils.ImageUtil;
import com.tencent.news.utils.InfoConfigUtil;
import com.tencent.news.utils.IntentUtil;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.StringUtil;
import com.tencent.omg.webdev.WebDev;

public class ImageDetailActivity extends NavActivity {

	private long viewStart;
	private long viewEnd;

	private int IMAGE_ON_CLICK = 1;
	private int RECOMMEND_VIEW_CHANGED = 110; // 第一层ViewPager内容变化
	private int IMAGE_DETAIL_CHANGED = 111; // 第二层（图片层）ViewPager内容变化
	private View mHelp;
	private TextView mTitle;
	private RelativeLayout mImageRootLayout;
	private ViewPagerEx2 mImagesViewPager;
	private ImageDetailViewPagerAdapter mImageDetailViewPagerAdapter;
	private FrameLayout mDetailTitle;
	private LinearLayout mLinearLayou;
	private TextView mPicContent;
	private View mView;
	private Item mItem;
	private ScrollView mScrollView;
	private Button mBackBtn;
	private ImageButton mShareBtn;
	private ViewPagerEx2 mViewPager;
	private ViewPagerAdapter mViewPagerAdapter;
	private CommentView mCommentView;
	private ImageDetailView mDetailView;
	private WritingCommentView mWritingCommentView;
	private String mChild;
	private LinearLayout mClickTop;
	private List<Bundle> mImageList = new ArrayList<Bundle>();
	private NewsDetailCache mNewsDetailCache;
	private boolean bPortrait = true; // 竖屏
	private boolean bFlag;
	private int nCurrImage = 0;
	private int nCurrentPage = 0;
	private AddCommentBroadcastReceiver receiver;
	private RefreshCommentNumBroadcastReceiver mRefreshCommentReceiver;
	private String mClickPosition;
	private int mWidth = MobileUtil.getScreenWidthIntPx();
	private int mHeight = MobileUtil.getScreenHeightIntPx();
	private String mTitleText;
	private boolean isSpecial;
	private boolean isWidgetFrom;
	private List<View> mViews = new ArrayList<View>();
	private ImageRecommendView mImageRecommendView;
	private GridView mGridView;
	private FrameLayout mFrameLayout;
	private int moreImageLayoutWidthW;// 竖屏相关推荐宽度
	private int moreImageLayoutWidthH;// 竖屏相关推荐宽度
	private List<Item> moreImage;
	private int moreImageSize = 0;
	private int mScreenWidth;// 屏幕宽度
	private int mScreenHeight;// 屏幕高度
	private boolean hasShowMoreImagePage = false;// 相关推荐页面显示�?
	private boolean mTouchDownOnScrollView = false;
	private View mMask;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		hasShowMoreImagePage = false;
		setContentView(R.layout.image_detail_layout);
		getIntentData(getIntent());
		InitView();
		InitListener();
		getData();
		registerBroadReceiver();
		setScreenOrientation();
	}

	private void getIntentData(Intent intent) {
		if (intent != null) {
			Bundle bundle = intent.getExtras();
			mItem = (Item) bundle.getSerializable(Constants.NEWS_DETAIL_KEY);
			mChild = bundle.getString(Constants.NEWS_CHANNEL_CHLID_KEY);
			mClickPosition = bundle.getString(Constants.NEWS_CLICK_ITEM_POSITION);
			mTitleText = bundle.getString(Constants.NEWS_DETAIL_TITLE_KEY);
			isSpecial = bundle.getBoolean(Constants.IS_SPECIAL_KEY);
			isWidgetFrom = bundle.getBoolean(Constants.IS_WIDGET_FROM_KEY);
			// mNewsDetailCache = new NewsDetailCache(mItem.getId());
			mNewsDetailCache = new NewsDetailCache(mItem);
		}
	}

	private void registerBroadReceiver() {
		receiver = new AddCommentBroadcastReceiver(mCommentView, mItem.getId());
		registerReceiver(receiver, new IntentFilter(Constants.WRITE_SUCCESS_ACTION));

		mRefreshCommentReceiver = new RefreshCommentNumBroadcastReceiver(mItem.getId(), null, null, mWritingCommentView);
		registerReceiver(mRefreshCommentReceiver, new IntentFilter(Constants.REFRESH_COMMENT_NUMBER_ACTION));
	}

	@Override
	protected void onStart() {
		// statistics_visit_start_time = System.currentTimeMillis();
		super.onStart();
	}

	@Override
	protected void onStop() {
		// statistics_visit_end_time = System.currentTimeMillis();
		// statistics_visit_total = statistics_visit_end_time -
		// statistics_visit_start_time;
		// Statistics.getInstance().saveStatistics(Statistics.REPORTED_DATA_NEWS_DETAIL,
		// StatisticsUtil.generateCustomField(new String[] { mItem.getId(),
		// mChild, "" + statistics_load_total, mClickPosition, "" +
		// statistics_visit_total, "", "", "", "", "", "" }));
		// statistics_load_total = 0;
		super.onStop();
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
			mWritingCommentView.setVisibility(View.GONE);
			mView.setVisibility(View.GONE);
			mShareBtn.setVisibility(View.GONE);
			mWritingCommentView.setVisibility(View.INVISIBLE);
			getTextViewSize(newConfig.orientation);
			bPortrait = false;
		} else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
			if (!bFlag) {
				mWritingCommentView.setVisibility(View.VISIBLE);
				mView.setVisibility(View.VISIBLE);
			}
			mShareBtn.setVisibility(View.VISIBLE);
			getTextViewSize(newConfig.orientation);
			bPortrait = true;
		}

		setLandscape(!bPortrait);
		setGridViewLayout();
	}

	private void InitView() {
		mImageRootLayout = (RelativeLayout) findViewById(R.id.image_detail_root_layout);
		mTitle = (TextView) findViewById(R.id.photo_detail_title);
		mViewPager = (ViewPagerEx2) findViewById(R.id.image_detail_viewpager);
		mViewPager.setDiscardAllMotionEvent(true);
		mWritingCommentView = (WritingCommentView) findViewById(R.id.image_Writing_CommentView);
		mBackBtn = (Button) findViewById(R.id.photo_title_back_btn);
		mShareBtn = (ImageButton) findViewById(R.id.photo_title_share_btn);
		mDetailTitle = (FrameLayout) findViewById(R.id.photo_detail_title_layout);
		mClickTop = (LinearLayout) findViewById(R.id.image_click_top);
		mTitle.setText(mTitleText);
		mMask = (View) findViewById(R.id.mask_view);
		mDetailView = new ImageDetailView(this);
		setTitleBackName();

		mView = mDetailView.getView();
		mImagesViewPager = mDetailView.getImagesViewPager();
		mImageDetailViewPagerAdapter = new ImageDetailViewPagerAdapter();

		mImageDetailViewPagerAdapter.setDisplayListener(new DisplayListener() {
			@Override
			public void onShowImage(int index, Bundle dataBundle, TouchImageView view) {
				view.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						mHandler.sendEmptyMessage(IMAGE_ON_CLICK);
					}
				});
			}
		});

		mImagesViewPager.setAdapter(mImageDetailViewPagerAdapter);
		mImagesViewPager.setOnPageChangeListener(new OnPageChangeListener() {
			@Override
			public void onPageSelected(int arg0) {
				nCurrImage = arg0;
				setImageDesc(nCurrImage);

				boolean showRecommend = mImageList != null && arg0 == mImageList.size() - 1;
				if (mViewPagerAdapter.setShowRecomendView(showRecommend)) {
					mHandler.sendEmptyMessage(RECOMMEND_VIEW_CHANGED);
				}
			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
			}

			@Override
			public void onPageScrollStateChanged(int arg0) {
			}
		});

		mViewPager.setOverScrollListener(new OverScrollListener() {
			@Override
			public void onOverScrollToRight() {
				if (mViewPagerAdapter.getCount() == 1) {
					TipsToast.getInstance().showTipsSoftWarning("最后一页");
				}
			}

			@Override
			public void onOverScrollToLeft() {
				quitActivity();
			}
		});

		mViewPager.addSubView(mImagesViewPager, 0);
		mPicContent = mDetailView.getTextView();
		mLinearLayou = mDetailView.getLinearLayout();
		mScrollView = mDetailView.getScrollView();
		mShareBtn.setEnabled(false);

		mViews = new ArrayList<View>();
		mViews.add(mDetailView);
		mViews.add(initMoreImageLayout());
		mViews.add(initCommentList());
		mViewPagerAdapter = new ViewPagerAdapter(mViews);
		mViewPager.setAdapter(mViewPagerAdapter);
		mViewPager.setOffscreenPageLimit(1);
		mViewPager.setCurrentItem(0);
		mViewPager.setOnPageChangeListener(new MainPageChangeListener());
		mWritingCommentView.setItem(mChild, mItem);
		mWritingCommentView.refreshUI();
		mCommentView.init(mChild, mItem);
		mCommentView.setWritingCommentView(mWritingCommentView);
		mCommentView.applyTheme();
	}

	private void setImageDesc(int index) {
		if (mImageList != null && index < mImageList.size()) {
			String page = "(" + (index + 1) + "/" + mImageDetailViewPagerAdapter.getCount() + ")";
			Bundle bundle = mImageList.get(index);
			String text = bundle.getString("text");
			String image = bundle.getString("image");
			mPicContent.setText(StringUtil.replaceBlank(page + text));
			setScreenOrientation();
			mScrollView.scrollTo(0, 0);
			ShareDialog.getInstance().setImageUrl(image);
		}
	}

	private void setTitleBackName() {
		if (isRelateNews) {
			mBackBtn.setText("返回");
			return;
		}
		if(mNewsDetailCache.getMcahceType()==CacheType.FAVOR_CACHE){
			mBackBtn.setText("收藏");
			return;
		}
		ExtendedChannels channel = InfoConfigUtil.ReadExtendedChannels();
		if (NavigationBar.getSelected() == 1) {
			mBackBtn.setText("图片");
		} else {
			if (isSpecial) {
				mBackBtn.setText("专题");
			} else {
				if (channel != null && channel.getChlname() != null && NavigationBar.getSelected() == 4) {
					mBackBtn.setText(channel.getChlname());
				} else {
					mBackBtn.setText("新闻");
				}
			}
		}
	}

	/**
	 * 相关推荐
	 * 
	 * @return
	 */
	private View initMoreImageLayout() {
		if (mImageRecommendView == null) {
			mScreenWidth = MobileUtil.getScreenWidthIntPx();
			mScreenHeight = MobileUtil.getScreenHeightIntPx();
			mImageRecommendView = new ImageRecommendView(this);
			mFrameLayout = mImageRecommendView.getFrameLayout();
			FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) mFrameLayout.getLayoutParams();
			moreImageLayoutWidthW = lp.width;
			moreImageLayoutWidthH = mScreenHeight + moreImageLayoutWidthW - mScreenWidth;
			if (moreImageLayoutWidthH > (moreImageLayoutWidthW * 2)) {
				moreImageLayoutWidthH = moreImageLayoutWidthW * 2;
			}
			mGridView = mImageRecommendView.getGridView();
			mGridView.setOnItemClickListener(new OnItemClickListener() {
				public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
					SLog.i(String.valueOf(position));
					if (moreImageSize > position) {
						Item localItem = moreImage.get(position);
						Intent localIntent = new Intent(ImageDetailActivity.this, ImageDetailActivity.class);

						localIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						Bundle bundle = new Bundle();
						bundle.putSerializable(Constants.NEWS_DETAIL_KEY, localItem);
						bundle.putString(Constants.NEWS_CHANNEL_CHLID_KEY, mChild);
						bundle.putString(Constants.NEWS_DETAIL_TITLE_KEY, mTitleText);
						bundle.putString(Constants.NEWS_CLICK_ITEM_POSITION, "0");
						localIntent.putExtras(bundle);
						// resetImageDetail(localIntent);
						startActivity(localIntent);
						finish();
						overridePendingTransition(R.anim.push_right_in, R.anim.push_right_out);
					}
				}
			});
		}
		return mImageRecommendView;
	}

	private View initCommentList() {
		LinearLayout mLinearLayout = new LinearLayout(Application.getInstance());
		mLinearLayout.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT));
		mLinearLayout.setOrientation(LinearLayout.VERTICAL);

		View v = new View(this);
		v.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, MobileUtil.dpToPx(48)));
		v.setBackgroundColor(Color.parseColor("#000000"));

		mCommentView = new CommentView(this);
		mCommentView.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT, 1));
		View view = new View(Application.getInstance());
		view.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, MobileUtil.dpToPx(48)));
		view.setBackgroundColor(Color.parseColor("#f6f6f6"));
		mLinearLayout.addView(v);
		mLinearLayout.addView(mCommentView);
		mLinearLayout.addView(view);
		return mLinearLayout;
	}

	private void setScreenOrientation() {
		int orientation = getResources().getConfiguration().orientation;
		if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
			mWritingCommentView.setVisibility(View.GONE);
			mView.setVisibility(View.GONE);
			mShareBtn.setVisibility(View.GONE);
			getTextViewSize(orientation);
			hideUserHelp();
			bPortrait = false;
		} else if (orientation == Configuration.ORIENTATION_PORTRAIT) {
			if (!bFlag) {
				mWritingCommentView.setVisibility(View.VISIBLE);
				mView.setVisibility(View.VISIBLE);
			}
			getTextViewSize(orientation);
			bPortrait = true;
		}

		setLandscape(!bPortrait);
	}

	private void setLandscape(boolean landscape) {
		mViewPager.setBlockOverMoveLeftEvent(landscape);
		if (mViewPagerAdapter.setOnLandscape(landscape)) {
			mHandler.sendEmptyMessage(RECOMMEND_VIEW_CHANGED);
		}
	}

	private void Loading() {
		mLinearLayou.setVisibility(View.GONE);
	}

	private void LoadingComplete() {
		mLinearLayou.setVisibility(View.VISIBLE);
	}

	private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {

			if (msg.what == IMAGE_ON_CLICK) {
				if (mDetailTitle.getVisibility() == View.VISIBLE || mLinearLayou.getVisibility() == View.VISIBLE) {
					mWritingCommentView.setVisibility(View.GONE);
					mDetailTitle.setVisibility(View.GONE);
					mLinearLayou.setVisibility(View.GONE);
					bFlag = true;
				} else {
					mDetailTitle.setVisibility(View.VISIBLE);
					mLinearLayou.setVisibility(View.VISIBLE);
					if (!bPortrait) {
						mView.setVisibility(View.GONE);
						mWritingCommentView.setVisibility(View.GONE);
					} else {
						mView.setVisibility(View.VISIBLE);
						mWritingCommentView.setVisibility(View.VISIBLE);
					}
					bFlag = false;
				}
			} else if (msg.what == RECOMMEND_VIEW_CHANGED) {
				mViewPagerAdapter.notifyDataSetChanged();
			} else if (msg.what == IMAGE_DETAIL_CHANGED) {
				mImageDetailViewPagerAdapter.notifyDataSetChanged();
			} else {
				if (msg != null && msg.obj != null) {
					SimpleNewsDetail detail = (SimpleNewsDetail) msg.obj;
					// statistics_load_end_time = System.currentTimeMillis();
					// statistics_load_total = statistics_load_end_time -
					// statistics_load_start_time;
					// if(statistics_load_total<0) {
					// statistics_load_total = 0;
					// }
					SLog.i("ImageDetailActivity", "请求完成" + detail.toString() + mImageList);
					if (detail != null && mImageList != null) {
						shareNewsData(detail);
						isShowUserHelp();
						InitMoreImage(detail);
						InitImageList(detail);
						mViewPager.setDiscardAllMotionEvent(false);

						// now, mImageList is ready
						mImageDetailViewPagerAdapter.setData(mImageList);
						mHandler.sendEmptyMessage(IMAGE_DETAIL_CHANGED);
						mImagesViewPager.setCurrentItem(0);
						setImageDesc(0);

						if (mImageList.size() > 0) {
							Bundle bundle = mImageList.get(0);
							String image = bundle.getString("image");
							mCommentView.enterPageThenGetComments(isRelateNews);
							mWritingCommentView.canWrite(true);
							mWritingCommentView.setImg(image);
							mCommentView.setImg(image);
							ShareDialog.getInstance().setImageUrl(image);
							LoadingComplete();
						}
					}
				}

			}
			SLog.i("ImageDetailActivity", "请求完成返回");
		}
	};

	private void shareNewsData(SimpleNewsDetail detail) {
		mShareBtn.setEnabled(true);
		ShareDialog.getInstance().setParams("", "", detail, mItem, mChild);
	}

	private void isShowUserHelp() {
		if (SpUserHelp.getNewsDetailHelp()) {
			if (!isWidgetFrom) {
				attachHelpView();
			}
		}
	}

	private void attachHelpView() {
		mHelp = new View(this);
		mHelp.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT));
		mHelp.setBackgroundResource(R.drawable.news_detail_help);
		mImageRootLayout.addView(mHelp);
		mHelp.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				mImageRootLayout.removeView(mHelp);
				SpUserHelp.setNewsDetailHelp(false);
			}

		});
	}

	private void InitListener() {
		mWritingCommentView.setDetailCommentChangeClick(new OnChangeClick() {

			@Override
			public void change() {
				if (nCurrentPage < mViewPagerAdapter.getCount() - 1) {
					if (mViewPagerAdapter.setShowRecomendView(false)) {
						mHandler.sendEmptyMessage(RECOMMEND_VIEW_CHANGED);
					}
					mViewPager.setCurrentItem(mViewPagerAdapter.getCount() - 1);
				} else {
					mViewPager.setCurrentItem(0);
				}
			}
		});

		mWritingCommentView.setOnDownloadClick(new OnDownloadClick() {

			@Override
			public void download() {
				if (mImageList != null && mImageList.size() > 0) {
					Bundle bundle = mImageList.get(nCurrImage);
					String image = bundle.getString("image");
					String path = ImageCacheNameUtil.getSaveImageFileName(image);
					Bitmap showBitmap = mImagesViewPager.getCurrentBitmap();
					if (showBitmap != null && !showBitmap.equals(DefaulImageUtil.getDefaultPhotoDetailImage())) {
						boolean bFlag = ImageUtil.saveBitmap(showBitmap, path, ImageUtil.QUALITY_HIGH);
						if (bFlag) {
							Uri localUri = Uri.fromFile(new File(path));
							Intent localIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, localUri);
							sendBroadcast(localIntent);

							TipsToast.getInstance().showTipsSuccess("已下载到相册");

							// Statistics.getInstance().saveStatistics(Statistics.REPORTED_DATA_NEWS_DETAIL,
							// StatisticsUtil.generateCustomField(new String[] {
							// mItem.getId(), mChild, "", "", "", "", image, "",
							// "", "", "" }));

							WebDev.trackCustomEvent(ImageDetailActivity.this, EventId.BOSS_IMAGE_DOWNLOAD, new String[] { mItem.getId(), mChild, image });

						} else {
							TipsToast.getInstance().showTipsError("下载失败");
						}
					}
				}
			}
		});

		mBackBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				quitActivity();
			}

		});

		mShareBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				ShareDialog.getInstance().showShareList(ImageDetailActivity.this, ShareDialog.SHARE_MEDIA_DETAIL, mShareBtn);
				setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
			}

		});

		ShareDialog.getInstance().setShareDismissListener(new ShareDismissListener() {

			@Override
			public void OnDlgdismiss(DialogInterface dialog) {
				if (nCurrentPage == 0) {
					setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_USER);
				}
			}
		});

		mClickTop.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (nCurrentPage == mViewPagerAdapter.getCount() - 1) {
					mCommentView.upToTop();
				}
			}
		});
	}

	private void hideUserHelp() {
		mImageRootLayout.removeView(mHelp);
		SpUserHelp.setNewsDetailHelp(false);
	}

	private void getData() {
		Loading();

		TaskManager.startRunnableRequest(new Runnable() {
			@Override
			public void run() {
				SimpleNewsDetail detail = mNewsDetailCache.getNewsDetail();
				// statistics_load_start_time = System.currentTimeMillis();
				if (detail != null) {
					Message msg = Message.obtain();
					msg.obj = detail;
					mHandler.sendMessageDelayed(msg, 20);
				} else {

					WebDev.trackCustomBeginKVEvent(ImageDetailActivity.this, EventId.ITIL_LOAD_DETAIL_TIME, getPts());

					HttpDataRequest request = TencentNews.getInstance().getSimpleHtmlContent(mItem.getId(), mChild, mNewsDetailCache.getMcahceType());
					TaskManager.startHttpDataRequset(request, ImageDetailActivity.this);
				}
			}
		});
	}

	private Properties getPts() {
		Properties pts = new Properties();
		pts.setProperty(EventId.KEY_NEWSID, mItem != null ? mItem.getId() : "");
		pts.setProperty(EventId.KEY_CHANNELID, mChild);
		pts.setProperty(EventId.KEY_DETAILTYPE, iAmWhich());
		return pts;
	}

	private String iAmWhich() {
		return "image";
	}

	@Override
	public void onHttpRecvOK(HttpTag tag, Object result) {

		Properties p = getPts();
		WebDev.trackCustomEndKVEvent(ImageDetailActivity.this, EventId.ITIL_LOAD_DETAIL_TIME, p);
		Properties newp = new Properties(p);
		newp.setProperty(EventId.KEY_RESCODE, EventId.VALUE_RESCODE_SUCCESS);
		WebDev.trackCustomEvent(ImageDetailActivity.this, EventId.ITIL_LOAD_DETAIL_TIME_RESULT, newp);

		SimpleNewsDetail detail = (SimpleNewsDetail) result;
		Message msg = new Message();
		msg.obj = detail;
		mHandler.sendMessage(msg);

		mNewsDetailCache.setCacheDetailData(detail);
		mNewsDetailCache.saveNewsDetail();

		sendBroadCastforRead();
	}

	private void sendBroadCastforRead() {
		Intent intent = new Intent();
		Bundle bundle = new Bundle();

		String action = IntentUtil.getReadBroadcastAction(getIntent());
		if (action != null) {
			intent.setAction(action);
		} else if (isSpecial) {
			intent.setAction(Constants.NEWS_HAD_READ_SPECIAL_ACTION + mChild);
		} else {
			intent.setAction(Constants.NEWS_HAD_READ_ACTION + mChild);
		}
		bundle.putSerializable(Constants.NEWS_ID_KEY, mItem);
		bundle.putString(Constants.NEWS_CLICK_ITEM_POSITION, mClickPosition);
		intent.putExtras(bundle);
		sendBroadcast(intent);
	}

	@Override
	public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {

		Properties p = getPts();
		WebDev.trackCustomEndKVEvent(ImageDetailActivity.this, EventId.ITIL_LOAD_DETAIL_TIME, p);
		Properties newp = new Properties(p);
		newp.setProperty(EventId.KEY_RESCODE, EventId.VALUE_RESCODE_ERROR);
		WebDev.trackCustomEvent(ImageDetailActivity.this, EventId.ITIL_LOAD_DETAIL_TIME_RESULT, newp);

		TipsToast.getInstance().showTipsError(msg);
		SLog.i("ImageDetailActivity", msg);
	}

	private void getTextViewSize(final int flag) {
		if (flag == Configuration.ORIENTATION_LANDSCAPE) {
			hideUserHelp();
			int width = Math.max(mWidth, mHeight);
			calculateTextViewLine(mPicContent, width - MobileUtil.dpToPx(28));
		} else if (flag == Configuration.ORIENTATION_PORTRAIT) {
			int width = Math.min(mWidth, mHeight);
			calculateTextViewLine(mPicContent, width - MobileUtil.dpToPx(28));
		}
		mScrollView.scrollTo(0, 0);
	}

	private void calculateTextViewLine(final TextView view, int width) {
		String text = (String) view.getText();
		Paint paint = new Paint();
		paint.setTextSize(view.getTextSize());
		int size = (int) paint.measureText(text);
		int line = size / width;
		if (size % width != 0) {
			line++;
		}

		if (text != null) {
			if (line > 3) {
				setLayoutParams(125);
			} else {
				setLayoutParams(75);
			}
		}
	}

	/**
	 * 初始化相关推荐数�?
	 * 
	 * @param detail
	 */
	private void InitMoreImage(SimpleNewsDetail detail) {
		if (moreImage != null) {
			// moreImage.re
		}
		moreImage = detail.getRelate_news();
		if (moreImage != null) {
			for (int i = moreImage.size() - 1; i >= 0; i--) {
				if (!"1".equals(moreImage.get(i).getArticletype())) {
					moreImage.remove(i);
				}
			}
		}
		if (moreImage.size() > 4) {
			int loops = moreImage.size() - 4;
			for (; loops > 0; loops--) {
				moreImage.remove(4);// 相关图片超过四个要删�?
			}
		}
		moreImageSize = moreImage.size();
		int intSize = mViews.size();
		if (moreImage != null && moreImage.size() > 0) {
			if (intSize == 2) {
				mViews.add(1, initMoreImageLayout());
			}
			mImageRecommendView.setdata(moreImage);
		} else {
			if (intSize == 3) {
				mViewPager.removeAllViews();
				mViews.remove(1);
				SLog.i("ImageDetailActivity", "InitMoreImage mViewPagerAdapter size:" + String.valueOf(mViewPagerAdapter.mListViews.size()));
			}
		}

		// mViewPagerAdapter.mListViews.clear();
		// mViewPagerAdapter.mListViews.addAll(mViews);
		mViewPagerAdapter.setViews(mViews);
		mViewPagerAdapter.notifyDataSetChanged();
		mViewPager.invalidate();
	}

	// /**
	// * 更换图片文章重设显示内容
	// * @param paramIntent
	// */
	// private void resetImageDetail(Intent paramIntent){
	// getIntentData(getIntent());
	// //InitView();
	// //InitListener();
	// getData();
	// //registerBroadReceiver();
	// }

	/**
	 * 设置相关图片页显示方�?
	 */
	private void setGridViewLayout() {
		if (mGridView != null) {
			FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) mFrameLayout.getLayoutParams();
			if (!bPortrait) {
				mGridView.setNumColumns(4);
				lp.width = moreImageLayoutWidthH;
				mFrameLayout.setLayoutParams(lp);
			} else {
				mGridView.setNumColumns(2);
				lp.width = moreImageLayoutWidthW;
				mFrameLayout.setLayoutParams(lp);
			}
		}
	}

	private void InitImageList(SimpleNewsDetail detail) {
		if (mImageList == null) {
			return;
		}

		TreeMap<String, Object> attribute = detail.getAttribute();
		Bundle bundle = new Bundle();
		Iterator<?> keyIter = attribute.entrySet().iterator();
		while (keyIter.hasNext()) {
			@SuppressWarnings("unchecked")
			Map.Entry<String, Object> entry = (Map.Entry<String, Object>) keyIter.next();
			String key = (String) entry.getKey();
			if (key.indexOf("IMG") > -1 && attribute.containsKey(key)) {
				Image imgObj = (Image) attribute.get(key);
				String url = imgObj.getUrl();
				String desc = imgObj.getDesc();
				bundle = new Bundle();
				bundle.putString("image", url);
				bundle.putString("text", desc);
				mImageList.add(bundle);
			}
		}

	}

	private void setLayoutParams(int height) {
		LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) mScrollView.getLayoutParams();
		lp.height = MobileUtil.dpToPx(height);
		mScrollView.setLayoutParams(lp);
	}

	public class MainPageChangeListener implements OnPageChangeListener {

		@Override
		public void onPageScrollStateChanged(int arg0) {
			switch (arg0) {
			case ViewPagerEx.SCROLL_STATE_DRAGGING:
				break;
			case ViewPagerEx.SCROLL_STATE_SETTLING:
				break;
			case ViewPagerEx.SCROLL_STATE_IDLE:
				if (nCurrentPage < mViewPagerAdapter.getCount() - 1) {
					setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_USER);
				} else {
					int orientation = getResources().getConfiguration().orientation;
					if (orientation == Configuration.ORIENTATION_PORTRAIT && nCurrentPage == mViewPagerAdapter.getCount() - 1) {
						setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
					}
				}
				break;
			}
		}

		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {
			if (!bPortrait && arg0 >= 1) {
				mViewPager.scrollTo(mViewPager.getWidth(), 0);
			}
			// SLog.i("ImageDetailActivity",
			// "onPageScrolled arg0:"+String.valueOf(arg0)+" arg1:"+String.valueOf(arg1)+" arg2:"+String.valueOf(arg2));
		}

		@Override
		public void onPageSelected(int arg0) {
			if (arg0 == 0) {
				boolean showRecommend = mImageList != null && nCurrImage == mImageList.size() - 1;
				if (mViewPagerAdapter.setShowRecomendView(showRecommend)) {
					mHandler.sendEmptyMessage(RECOMMEND_VIEW_CHANGED);
				}
			}

			nCurrentPage = arg0;
			int localCommentDCPage = 0;
			if (arg0 == mViewPagerAdapter.getCount() - 1) {
				localCommentDCPage = 1;
			}
			mWritingCommentView.setDCPage(localCommentDCPage);
			mWritingCommentView.refreshUI();

			if (bPortrait) {
				mView.setVisibility(View.VISIBLE);
				mWritingCommentView.setVisibility(View.VISIBLE);

				if (localCommentDCPage == 1) {
					// SLog.d("####onPageScrolled####","arg0 == 1 && arg1 == 0");
					mDetailTitle.setVisibility(View.VISIBLE);
					mWritingCommentView.setVisibility(View.VISIBLE);
				} else if (localCommentDCPage == 0) {
					if (bFlag) {
						mDetailTitle.setVisibility(View.GONE);
						mWritingCommentView.setVisibility(View.GONE);
					} else {
						mDetailTitle.setVisibility(View.VISIBLE);
						mWritingCommentView.setVisibility(View.VISIBLE);
					}
				}
			} else {
				mView.setVisibility(View.GONE);
				mWritingCommentView.setVisibility(View.GONE);
			}
			if (mGridView != null && arg0 == 1 && mViewPagerAdapter.getCount() == 3) {
				mDetailTitle.setVisibility(View.VISIBLE);
				setGridViewLayout();
				mShareBtn.setEnabled(false);
				mWritingCommentView.setVisibility(View.INVISIBLE);
				hasShowMoreImagePage = true;
			} else if (hasShowMoreImagePage && bPortrait) {
				mShareBtn.setEnabled(true);
				mWritingCommentView.setVisibility(View.VISIBLE);
			}
			SLog.d("-----onPageSelected-----", "pageNumber=" + arg0);
			/*
			 * if(!bPortrait && arg0>=1){ mViewPager.setCurrentItem(1); }
			 */
		}

	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
			if (ShareDialog.getInstance().isShowing()) {
				ShareDialog.getInstance().dismiss();
				return true;
			}
			quitActivity();
			return true;
		} else if (event.getKeyCode() == KeyEvent.KEYCODE_MENU && event.getRepeatCount() > 0) {
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	protected void onDestroy() {
		if (receiver != null) {
			try {
				unregisterReceiver(receiver);
			} catch (Exception e) {
				SLog.e(e.toString());
			}
		}
		if (mRefreshCommentReceiver != null) {
			try {
				unregisterReceiver(mRefreshCommentReceiver);
			} catch (Exception e) {
				SLog.e(e.toString());
			}
		}
		if (mImageList != null) {
			mImageList.clear();
			mImageList = null;
		}
		TaskManager.cancelAllImageThread();
		TaskManager.clearImageCache();
		ShareDialog.getInstance().dismiss();
		super.onDestroy();
	}

	@SuppressLint("ResourceAsColor")
	@Override
	public void applyTheme() {
		// Auto-generated method stub
		super.applyTheme();
		themeSettingsHelper.setViewBackgroudColor(this, mMask, R.color.mask_page_color);
	}

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
		viewStart = System.currentTimeMillis();
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
		viewEnd = System.currentTimeMillis();
		
		Properties p = new Properties(getPts());
		p.setProperty(EventId.KEY_VIEW_START, "" + viewStart);
		p.setProperty(EventId.KEY_VIEW_END, "" + viewEnd);
		WebDev.trackCustomEvent(this, EventId.BOSS_VIEW_DETAIL, p);
	}
}
