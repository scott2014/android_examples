package com.tencent.news.ui;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.boss.EventId;
import com.tencent.news.cache.FavorSyncHelper;
import com.tencent.news.cache.RssChannelSyncHelper;
import com.tencent.news.cache.UserDBHelper;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.model.pojo.SimpleNewsDetail;
import com.tencent.news.model.pojo.UserInfo;
import com.tencent.news.model.pojo.UserInfoFromServerJsonFormat;
import com.tencent.news.shareprefrence.SpSetting;
import com.tencent.news.system.Application;
import com.tencent.news.system.NetStatusReceiver;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.news.utils.MobileUtil;
import com.tencent.omg.webdev.WebDev;

import oicq.wlogin_sdk.request.WUserSigInfo;
import oicq.wlogin_sdk.request.WloginSimpleInfo;
import oicq.wlogin_sdk.request.WtloginHelper;
import oicq.wlogin_sdk.tools.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoginActivity extends BaseActivity {

	WUserSigInfo info = null;

	UserInfo finalUserInfo;
	// private static final int STEP_LONGIN = 0;
	private static final int KEYBOARD_OPEN = 1;
	private static final int KEYBOARD_CLOSE = 2;
	private static final int LOGIN_ING = 3;
	//
	// private static final int STEP_VERIFY = 1;

	// InputMethodEventView forInputMethod;
	ScrollView login_container;
	// ImageView login_logo;
	EditText account;
	EditText password;
	Button btn_login;
	Button loginTitle_btn_back;
	String preAccount=null;//本次登录前的帐号

	RelativeLayout verification;
	ImageView verificationCodeImage;
	TextView refreshVerificationCode;
	EditText verificationCode;
	Button verificationok;

	RelativeLayout login_page = null;
	RelativeLayout login_title = null;
	LinearLayout view_login = null;

	int enterFromWhere;
	boolean isLoginIng = false;

	private View mMask;

	private View login_divider;

	TextView txtView_login;

	Handler scrollHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {

			case KEYBOARD_OPEN:
				login_container.smoothScrollBy(0, login_container.getHeight());
				break;
			case KEYBOARD_CLOSE:
				login_container.smoothScrollBy(0, 0);
				break;
			}
			super.handleMessage(msg);
		}

	};

	String something[] = { "正在登录", "正在登录", "（正在登录）", "（（正在登录））", "（（（正在登录）））", "（（　正在登录　））", "（　　正在登录　　）", "正在登录" };
	Handler loginTextHandler = new Handler() {
		int i = 0;

		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {

			case LOGIN_ING:
				if (i > something.length - 1) {
					i = 0;
				}
				btn_login.setText(something[i]);
				verificationok.setText(something[i]);
				if (isLoginIng) {
					i++;
					loginTextHandler.sendEmptyMessageDelayed(LOGIN_ING, 400);
				} else {
					btn_login.setText("登录");
					verificationok.setText("确定");
					verificationok.setEnabled(true);
					account.setEnabled(true);
					password.setEnabled(true);
					verificationCode.setEnabled(true);
					verification.setEnabled(true);
					verificationCodeImage.setEnabled(true);
					refreshVerificationCode.setEnabled(true);
					btn_login.setEnabled(true);
				}
				break;
			}
			super.handleMessage(msg);
		}

	};

	private SimpleNewsDetail mNewsDetail;
	private Item mItem;
	private int mShareType;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_login);
		Intent it = getIntent();
		if (it != null) {
			if (it.hasExtra(Constants.LOGIN_FROM)) {
				enterFromWhere = it.getIntExtra(Constants.LOGIN_FROM, Constants.LOGIN_FROM_SETTING);
			}
			if (it.hasExtra(Constants.NEWS_SHARE_CONTENT)) {
				mNewsDetail = (SimpleNewsDetail) it.getSerializableExtra(Constants.NEWS_SHARE_CONTENT);
			}
			if (it.hasExtra(Constants.NEWS_SHARE_ITEM)) {
				mItem = (Item) it.getSerializableExtra(Constants.NEWS_SHARE_ITEM);
			}
			if (it.hasExtra(Constants.NEWS_SHARE_TYPE)) {
				mShareType = it.getIntExtra(Constants.NEWS_SHARE_TYPE, 0);
			}

		}

		Application.getInstance().helper = new WtloginHelperAsync(this);
		info = new WUserSigInfo();

		initView();
		initListener();

	}

	private void initView() {
		// forInputMethod = (InputMethodEventView)
		// findViewById(R.id.forInputMethod);
		mMask = (View) findViewById(R.id.mask_view);

		txtView_login = (TextView) findViewById(R.id.txtView_login);

		login_container = (ScrollView) findViewById(R.id.login_container);
		// login_logo = (ImageView) findViewById(R.id.login_logo);
		account = (EditText) findViewById(R.id.account);
		account.requestFocus();
		password = (EditText) findViewById(R.id.password);
		btn_login = (Button) findViewById(R.id.btn_login);
		loginTitle_btn_back = (Button) findViewById(R.id.loginTitle_btn_back);
		verification = (RelativeLayout) findViewById(R.id.verification);
		verificationCodeImage = (ImageView) findViewById(R.id.verificationCodeImage);
		verificationCode = (EditText) findViewById(R.id.verificationCode);
		refreshVerificationCode = (TextView) findViewById(R.id.refreshVerificationCode);
		verificationok = (Button) findViewById(R.id.verificationok);

		login_page = (RelativeLayout) findViewById(R.id.login_page);
		login_title = (RelativeLayout) findViewById(R.id.loginTitle);
		view_login = (LinearLayout) findViewById(R.id.view_login);

		login_divider = (View) findViewById(R.id.login_divider);
	}

	private void initListener() {
		// forInputMethod.setmInputMethodChangeLinstener(new
		// InputMethodChangeLinstener() {
		//
		// @Override
		// public void onInputMethodOpen() {
		// scrollHandler.sendEmptyMessageDelayed(KEYBOARD_OPEN, 50);
		// }
		//
		// @Override
		// public void onInputMethodClose() {
		// scrollHandler.sendEmptyMessageDelayed(KEYBOARD_CLOSE, 50);
		// }
		// });

		btn_login.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (checkInput()) {
					// TipsToast.getInstance().showTipsWarning("正在登录\n请稍候");
					btn_login.setEnabled(false);
					account.setEnabled(false);
					password.setEnabled(false);
					isLoginIng = true;

					UserInfo uf = UserDBHelper.getInstance().getUserInfo();//本次登录前帐号
					preAccount = uf != null ? uf.getAccount() : "0";

					loginTextHandler.sendEmptyMessage(LOGIN_ING);
					Application.getInstance().helper.GetStWithPasswd(account.getText().toString(), Constants.WTLOGIN_APPID, password.getText().toString(), info, 0);
				}
			}
		});
		verificationCodeImage.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Application.getInstance().helper.RefreshPictureData(account.getText().toString(), 0);
			}
		});
		refreshVerificationCode.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Application.getInstance().helper.RefreshPictureData(account.getText().toString(), 0);
			}
		});
		verificationok.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (checkInput()) {
					loginTextHandler.sendEmptyMessage(LOGIN_ING);
					verificationok.setEnabled(false);
					isLoginIng = true;
					Application.getInstance().helper.CheckPictureAndGetSt(account.getText().toString(), verificationCode.getText().toString().getBytes(), info, 0);
				}
			}
		});
		loginTitle_btn_back.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Application.getInstance().hideSoftInputFromWindow(account.getWindowToken());
				Application.getInstance().hideSoftInputFromWindow(password.getWindowToken());
				Application.getInstance().hideSoftInputFromWindow(verificationCode.getWindowToken());
				quitActivity();
			}
		});
	}

	private boolean checkInput() {

		if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_INAVAILABLE) {
			TipsToast.getInstance().showTipsWarning("无网络连接\n请启用数据网络");
			return false;
		}

		if (account.getText().toString().length() <= 0) {
			account.requestFocus();
			TipsToast.getInstance().showTipsWarning("请输入帐号");
			return false;
		}
		if (password.getText().toString().length() <= 0) {
			password.requestFocus();
			TipsToast.getInstance().showTipsWarning("请输入密码");
			return false;
		}
		if (verificationCodeImage.isShown()) {
			if (verificationCode.getText().toString().length() <= 0) {
				verificationCode.requestFocus();
				TipsToast.getInstance().showTipsWarning("请输入验证码");
				return false;
			} else {

				Pattern pattern = Pattern.compile(Constants.VERIFICATION_CODE_REG);
				Matcher matcher = pattern.matcher(verificationCode.getText());
				if (!matcher.find()) {
					verificationCode.requestFocus();
					verificationCode.setText("");
					TipsToast.getInstance().showTipsError("请4位有效验证码");
					return false;
				}
			}
		}
		return true;
	}

	class WtloginHelperAsync extends WtloginHelper {

		public WtloginHelperAsync(Context context) {
			super(context);
		}

		@Override
		public void OnGetStWithPasswd(String userAccount, long dwAppid, String userPasswd, WUserSigInfo userSigInfo, int ret) {
			Log.i("LOGIN", "OnGetStWithPasswd():ret-->" + ret);

			isLoginIng = false;

			if (ret == util.S_GET_IMAGE) {// 需要验证码

				TipsToast.getInstance().showTipsWarning("请输入验证码");
				byte[] image_buf = new byte[0];
				image_buf = Application.getInstance().helper.GetPictureData(userAccount);
				if (image_buf == null) {
					return;
				}
				Bitmap bm = BitmapFactory.decodeByteArray(image_buf, 0, image_buf.length);
				verificationCodeImage.setImageBitmap(bm);
				verification.setVisibility(View.VISIBLE);
				login_container.setVisibility(View.GONE);
			} else if (ret == util.S_SUCCESS) {// 成功

				verification.setVisibility(View.GONE);
				prepareCookie(userAccount, userSigInfo);

			} else if (ret == util.S_PWD_WRONG) {
				Log.i("LOGIN", "帐号密码错误");
				TipsToast.getInstance().showTipsError("帐号或密码错误\n请重新输入");
				password.setText("");
				password.requestFocus();
			} else if (ret == util.E_NO_RET) {// 没有网络
				Log.i("LOGIN", "没有网络");
				TipsToast.getInstance().showTipsError("无法连接到网络\n请稍后再试");
			} else if (ret == util.E_PENDING) {
				TipsToast.getInstance().showTipsWarning("正在登录\n请稍候");
			} else if (ret == 5) {
				TipsToast.getInstance().showTipsError("您输入的帐号不存在\n请确认后重新输入");
			} else {
				Log.i("LOGIN", "ret-->" + ret + ",helper.GetLastErrMsg()-->" + Application.getInstance().helper.GetLastErrMsg());
				if (Application.getInstance().helper.GetLastErrMsg() != null && Application.getInstance().helper.GetLastErrMsg().length() > 0) {
					TipsToast.getInstance().showTipsError("" + Application.getInstance().helper.GetLastErrMsg());
				} else {
					TipsToast.getInstance().showTipsError("登录失败\n请重试");
				}
			}

		}

		@Override
		public void OnRefreshPictureData(String userAccount, byte[] pictureData, int ret) {

			Log.i("LOGIN", "OnRefreshPictureData():ret-->" + ret);

			if (ret == util.S_SUCCESS) {
				byte[] image_buf = new byte[0];
				image_buf = Application.getInstance().helper.GetPictureData(userAccount);
				Bitmap bm = BitmapFactory.decodeByteArray(image_buf, 0, image_buf.length);
				verificationCodeImage.setImageBitmap(bm);
			}
		}

		public void OnCheckPictureAndGetSt(String userAccount, byte[] userInput, WUserSigInfo userSigInfo, int ret) {

			isLoginIng = false;

			Log.i("LOGIN", "OnCheckPictureAndGetSt():ret-->" + ret);

			if (ret == util.S_SUCCESS) {

				prepareCookie(userAccount, userSigInfo);

			} else if (ret == util.S_GET_IMAGE) {
				byte[] image_buf = new byte[0];
				image_buf = Application.getInstance().helper.GetPictureData(account.getText().toString());
				if (image_buf == null) {
					return;
				}
				Bitmap bm = BitmapFactory.decodeByteArray(image_buf, 0, image_buf.length);
				verificationCodeImage.setImageBitmap(bm);
				verificationCode.setText("");
				TipsToast.getInstance().showTipsWarning("验证码错误\n请重新输入");
			} else if (ret == util.S_PWD_WRONG) {

				TipsToast.getInstance().showTipsError("帐号或密码错误\n请重新输入");

				password.setText("");
				password.requestFocus();
				verificationCode.setText("");
				verification.setVisibility(View.GONE);
				login_container.setVisibility(View.VISIBLE);

			} else {
				TipsToast.getInstance().showTipsError(Application.getInstance().helper.GetLastErrMsg());
				password.setText("");
				password.requestFocus();
				verificationCode.setText("");
				verification.setVisibility(View.GONE);
				login_container.setVisibility(View.VISIBLE);
			}

		}
	}

	private void prepareCookie(String userAccount, WUserSigInfo userSigInfo) {

		WloginSimpleInfo userInfo = new WloginSimpleInfo();
		Application.getInstance().helper.GetBasicUserInfo(userAccount, userInfo);

		finalUserInfo = new UserInfo();
		finalUserInfo.setAccount(userAccount);
		finalUserInfo.setUin("" + userInfo._uin);
		finalUserInfo.setLuin("" + userInfo._uin);
		finalUserInfo.setLskey(new String(userSigInfo._lsKey));
		finalUserInfo.setSkey(new String(userSigInfo._sKey));
		finalUserInfo.setSex("" + userInfo._gander[0]);

		UserDBHelper.getInstance().saveUserInfo(finalUserInfo);
		verification.setVisibility(View.GONE);
		login_container.setVisibility(View.VISIBLE);
		TaskManager.startHttpDataRequset(TencentNews.getInstance().getUserInfo(), this);

	}

	@Override
	public void onHttpRecvOK(HttpTag tag, Object result) {
		if (tag.equals(HttpTag.GET_USER_INFO_AFTER_WTLOGIN)) {

			UserInfoFromServerJsonFormat uifsjsonf = (UserInfoFromServerJsonFormat) result;

			if (uifsjsonf != null && uifsjsonf.getRetcode().equals("0")) {

				if (finalUserInfo != null) {
					
					finalUserInfo.setQqnick(uifsjsonf.getQqnick());
					finalUserInfo.setName(uifsjsonf.getName());
					finalUserInfo.setNick(uifsjsonf.getNick());
					finalUserInfo.setHeadurl(uifsjsonf.getHead());
					finalUserInfo.setOpenMBlog("1".equals(uifsjsonf.getMBStat()));
					finalUserInfo.setOpenQZone("1".equals(uifsjsonf.getQZoneStat()));
					finalUserInfo.setOpenWeiXin("1".equals(uifsjsonf.getWeiXinStat()));
					finalUserInfo.setMediaID(uifsjsonf.getMediaID());
					finalUserInfo.setEnUin(uifsjsonf.getEnUin());
					finalUserInfo.setQQHead(uifsjsonf.getQQHead());

					UserDBHelper.getInstance().saveUserInfo(finalUserInfo);
					Application.userInfo = finalUserInfo;
					SettingInfo sd = SettingObservable.getInstance().getData();
					sd.setUserInfo(finalUserInfo);
					SettingObservable.getInstance().setData(sd);
					SpSetting.saveSetting(sd);

					TipsToast.getInstance().showTipsSuccess("登录成功");
	                RssChannelSyncHelper.getInstance().onLoginSuccess(finalUserInfo.getUin());
	                //清理缓存
	                if(preAccount!=null && preAccount.length()>2 && finalUserInfo.getAccount()!=null && finalUserInfo.getAccount().length()>2 && !preAccount.equals(finalUserInfo.getAccount())){
	                	//与上次登录不是同一个帐号，清理收藏缓存
	                	//FavorItemCache.getInstance().clearCache(); //2013/07/03 用例评审 确认保留缓存
	                }
					FavorSyncHelper.getInstance().onLoginSuccess();

					if (Constants.LOGIN_FROM_SHARE_TENCENT_WEIBO == enterFromWhere) {

						if (mShareType == ShareInterfaceActivity.TENCENT_WEIBO && !UserDBHelper.getInstance().getUserInfo().isOpenMBlog()) {
							TipsToast.getInstance().showTipsWarning("未开通腾讯微博\n无法分享");
							quitActivity();
							return;
						}

						if (mShareType == ShareInterfaceActivity.TENCENT_QZONE && !UserDBHelper.getInstance().getUserInfo().isOpenQZone()) {
							TipsToast.getInstance().showTipsWarning("未开通QQ空间\n无法分享");
							quitActivity();
							return;
						}

						switch (mShareType) {
						case ShareInterfaceActivity.TENCENT_WEIBO:
							WebDev.trackCustomEvent(this, EventId.BOSS_SETTING_LOGINFROM_SHARE_TENCENT_WEIBO);
							break;
						case ShareInterfaceActivity.TENCENT_QZONE:
							WebDev.trackCustomEvent(this, EventId.BOSS_SETTING_LOGINFROM_SHARE_TENCENT_QZONE);
							break;
						default:
							break;
						}

						Intent intent = new Intent();
						intent.setClass(LoginActivity.this, ShareInterfaceActivity.class);
						intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						intent.putExtra(Constants.NEWS_SHARE_CONTENT, mNewsDetail);
						intent.putExtra(Constants.NEWS_SHARE_ITEM, mItem);
						intent.putExtra(Constants.NEWS_SHARE_TYPE, mShareType);
						startActivity(intent);

					} else if(Constants.LOGIN_FROM_MY_MSG == enterFromWhere){
						Intent intent = new Intent(LoginActivity.this, CommentFragmentActivity.class);
						startActivity(intent);						
						//TODO:自选股登录跳转
//					} else if(Constants.LOGIN_FROM_PORTFOLIO == enterFromWhere){
//						Intent intent = new Intent(LoginActivity.this, PortfolioListActivity.class);
//						startActivity(intent);						
					}else {

						Intent i = new Intent();
						i.putExtra(Constants.LOGIN_SUCCESS_BACK_USER_KEY, finalUserInfo);
						i.putExtra(Constants.LOGIN_BACK, enterFromWhere);
						setResult(RESULT_OK, i);
					}

					quitActivity();
				}

			} else {
				Intent i = new Intent();
				i.putExtra(Constants.LOGIN_SUCCESS_BACK_USER_KEY, "");
				i.putExtra(Constants.LOGIN_BACK, enterFromWhere);
				setResult(RESULT_CANCELED, i);
				TipsToast.getInstance().showTipsError("登录失败\n请重试");
				quitActivity();
			}

		}
		super.onHttpRecvOK(tag, result);
	}

	@Override
	public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {
		super.onHttpRecvError(tag, retCode, msg);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			if (isLoginIng) {
				isLoginIng = false;
				return true;
			}

			Application.getInstance().hideSoftInputFromWindow(password.getWindowToken());
			quitActivity();
			return true;
		}

		return super.onKeyDown(keyCode, event);
	}

	@Override
	public void applyTheme() {
		if (themeSettingsHelper.isNightTheme()) {
			account.setHintTextColor(Color.parseColor("#88858b"));
			account.setTextColor(Color.parseColor("#f0f4f8"));
			password.setHintTextColor(Color.parseColor("#88858b"));
			password.setTextColor(Color.parseColor("#f0f4f8"));

			btn_login.setTextColor(Color.parseColor("#f0f4f8"));

			login_divider.setBackgroundColor(Color.parseColor("#171819"));

			loginTitle_btn_back.setTextColor(Color.parseColor("#f0f4f8"));
			txtView_login.setTextColor(Color.parseColor("#f0f4f8"));
		} else {
			account.setHintTextColor(Color.parseColor("#999999"));
			account.setTextColor(Color.parseColor("#222222"));
			password.setHintTextColor(Color.parseColor("#999999"));
			password.setTextColor(Color.parseColor("#222222"));

			btn_login.setTextColor(Color.parseColor("#ffffff"));

			login_divider.setBackgroundColor(Color.parseColor("#999999"));

			loginTitle_btn_back.setTextColor(Color.parseColor("#ffffff"));
			txtView_login.setTextColor(Color.parseColor("#ffffff"));
		}

		themeSettingsHelper.setViewBackgroud(this, account, R.drawable.login_input_account);
		themeSettingsHelper.setViewBackgroud(this, password, R.drawable.login_input_password);
		themeSettingsHelper.setViewBackgroud(this, btn_login, R.drawable.btn_login_selector);

		themeSettingsHelper.setViewBackgroudColor(this, login_page, R.color.page_setting_bg_color);
		themeSettingsHelper.setViewBackgroud(this, login_title, R.drawable.title_bar_bg);
		themeSettingsHelper.setViewBackgroud(this, loginTitle_btn_back, R.drawable.title_back_btn);
		themeSettingsHelper.setViewBackgroudColor(this, view_login, R.color.page_setting_bg_color);

		account.setPadding(MobileUtil.dpToPx(15), MobileUtil.dpToPx(2), MobileUtil.dpToPx(15), MobileUtil.dpToPx(2));
		password.setPadding(MobileUtil.dpToPx(15), MobileUtil.dpToPx(2), MobileUtil.dpToPx(15), MobileUtil.dpToPx(2));

		themeSettingsHelper.setViewBackgroudColor(this, mMask, R.color.mask_page_color);
	}

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}
}
