package com.tencent.news.ui;

import java.util.Properties;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.boss.EventId;
import com.tencent.news.command.GetImageRequest;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.pojo.ImageResult;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.model.pojo.ShareQQWeiboResponse;
import com.tencent.news.model.pojo.ShareQzoneResponse;
import com.tencent.news.model.pojo.ShareWeChatFriendsResponse;
import com.tencent.news.model.pojo.SimpleNewsDetail;
import com.tencent.news.model.pojo.SinaAccountsInfo;
import com.tencent.news.model.pojo.SinaResponse;
import com.tencent.news.model.pojo.WXUserInfo;
import com.tencent.news.shareprefrence.SpConfig;
import com.tencent.news.shareprefrence.SpDraft;
import com.tencent.news.system.Application;
import com.tencent.news.system.NetStatusReceiver;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.ShareDialog;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.news.utils.ThemeSettingsHelper;
import com.tencent.omg.webdev.WebDev;

public class ShareInterfaceActivity extends BaseActivity {

	public final static int SINA_WEIBO = 0x201;
	public final static int TENCENT_WEIBO = 0x202;
	public final static int TENCENT_QZONE = 0x203;
	public final static int WECHAT_FRIEND_ZONE = 0x204;
	public final static int SHOW_QUIT_ACTIVITY = 0x301;

	private static final int MAX_WORDS_SUGGEST_NUM = 140;
	private static final int WECHAT_F_MAX_WORDS_SUGGEST_NUM = 200;
	// private static final String SHARE_SEND_WORDS = " #我看腾讯新闻# ";
	private static final String SHARE_SEPCIALREPORT_WORDS = "专题新闻：";
	private String shareMediaName = " #我在看腾讯新闻# ";

	private int mShareType;
	private Item mItem;
	private SimpleNewsDetail mNewsDetail;
	private int long_short;
	private int nomalWords;

	private String title;
	private String stitle;
	private String bstract;

	// View:title
	private Button sTitleBackBtn;
	private TextView sTitleTxt;
	private Button sTitleSubmit;
	// View:Main
	private EditText sEditMainTxt;
	private ImageView sImageMain;
	private ImageView sShareMessageIcon;
	private TextView sShareMessage;
	private TextView sWordsTxt;
	private View mMask;
	private int remainWordsNum;
	private String mVid;
	private String mImg;
	private CharSequence temp;
	private ImageView sVideoIcon;
	private RelativeLayout sShareMsgUIbg;
	private RelativeLayout sShareMessagePic;
	private RelativeLayout sShareMessageTitle;
	private RelativeLayout sShareMessageWriteFloor;
	private LinearLayout sShareMessageFoot;
	private LinearLayout sShareMessageMain;

	private boolean isSend;
	private String aType;

	private boolean isChange = false;
	protected ThemeSettingsHelper themeSettingsHelper = null;

	private Properties pts;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(this);
		overridePendingTransition(R.anim.push_down_in, R.anim.push_down_out);
		setContentView(R.layout.activity_shareinterface);
		getIntentData(getIntent());
		initView();
		applyShareUITheme();
		initData();
		initListener();
	}

	private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if (msg != null) {
				switch (msg.what) {
				case SINA_WEIBO:
					shareSinaWeibo();
					quitActivity();
					break;
				case TENCENT_WEIBO:
					shareTencentWeibo();
					quitActivity();
					break;

				case TENCENT_QZONE:
					shareTencentQZone();
					quitActivity();
					break;

				case WECHAT_FRIEND_ZONE:
					shareWeChatFriendZone();
					quitActivity();
					break;

				case SHOW_QUIT_ACTIVITY:
					quitActivity();
					break;

				default:
					break;
				}
				Application.getInstance().hideSoftInputFromWindow(sEditMainTxt.getApplicationWindowToken());
				ShareInterfaceActivity.this.finish();
			}
		}
	};

	private void getIntentData(Intent intent) {
		if (intent != null) {
			mShareType = intent.getIntExtra(Constants.NEWS_SHARE_TYPE, 0);
		}
	}

	private void initData() {
		mItem = ShareDialog.getInstance().getNewsItem();
		mImg = ShareDialog.getInstance().getImageUrl();
		Log.v("lxn", "artitletype=" + mItem.getFlag());
		String titleTxt = titleTxtHander(mShareType);
		sTitleTxt.setText(titleTxt);

		if (mItem != null && mItem.getChlname() != null) {
			shareMediaName = " #我在看" + mItem.getChlname() + "# ";
		}
		if ("4".equals(mItem.getFlag())) {
			aType = "zhuanti";
			title = ShareDialog.getInstance().getSpecialReportTitle();
			stitle = SHARE_SEPCIALREPORT_WORDS + title;
			bstract = ShareDialog.getInstance().getSpecialReportIntro();
		} else {
			if ("1".equals(mItem.getFlag())) {
				Log.v("lxn", "imagecount=" + Integer.parseInt(mItem.getImageCount()));
				if ((mItem.getThumbnails_qqnews()[0]).length() > 0) {
					// setMsgImg(msg, newsItem,
					// newsItem.getThumbnails_qqnews()[0]);
					mImg = mItem.getThumbnails_qqnews()[0];
				}
			}
			aType = "";
			if (mItem != null) {
				stitle = title = mItem.getTitle();
				bstract = mItem.getBstract();
			}
			mNewsDetail = ShareDialog.getInstance().getNewsDetail();
			mVid = ShareDialog.getInstance().getVid();

			/*
			 * if ("3".equals(mItem.getFlag())) {
			 * sVideoIcon.setVisibility(View.VISIBLE); } else {
			 * sVideoIcon.setVisibility(View.GONE); }
			 */

			if (mVid != null && !"".equals(mVid)) {
				sVideoIcon.setVisibility(View.VISIBLE);
			} else {
				sVideoIcon.setVisibility(View.GONE);
			}
		}

		// sShareMessage.setText(SHARE_SEND_WORDS + title);
		// nomalWords = (" ||" + SHARE_SEND_WORDS + stitle).length() + 12;
		sShareMessage.setText(shareMediaName + title);
		nomalWords = (" ||" + shareMediaName + stitle).length() + 12;
		setImg(mImg);
		loadDraftMessage(mShareType);
	}

	private void setImg(String imgUrl) {
		if (imgUrl == null || imgUrl.equals("")) {
			sImageMain.setImageResource(R.drawable.icon);
			return;
		}
		GetImageRequest request = new GetImageRequest();
		request.setTag(mItem.getId());
		request.setGzip(false);
		request.setUrl(imgUrl);
		ImageResult sresult = TaskManager.startSmallImageTask(request, this);
		if (sresult.isResultOK() && sresult.getRetBitmap() != null) {
			sImageMain.setImageBitmap(sresult.getRetBitmap());
		}
	}

	private void loadDraftMessage(int type) {
		if (mItem.getId() == null) {
			return;
		}
		String txt = "";

		switch (type) {
		case SINA_WEIBO:
			txt = loadDraft(SINA_WEIBO + mItem.getId());
			sEditMainTxt.setText(loadDraft(SINA_WEIBO + mItem.getId()));
			break;

		case TENCENT_WEIBO:
			txt = loadDraft(TENCENT_WEIBO + mItem.getId());
			sEditMainTxt.setText(loadDraft(TENCENT_WEIBO + mItem.getId()));
			break;

		case TENCENT_QZONE:
			txt = loadDraft(TENCENT_QZONE + mItem.getId());
			sEditMainTxt.setText(loadDraft(TENCENT_QZONE + mItem.getId()));
			break;
		case WECHAT_FRIEND_ZONE:
			txt = loadDraft(WECHAT_FRIEND_ZONE + mItem.getId());
			sEditMainTxt.setText(loadDraft(WECHAT_FRIEND_ZONE + mItem.getId()));
			break;

		default:
			break;

		}
		if (txt.length() != 0) {
			sEditMainTxt.setSelection(txt.length());
		}
		changeTextSwitcherNum();
	}

	private void saveDraftMessage(int type) {
		if (mItem.getId() == null) {
			return;
		}
		switch (type) {
		case SINA_WEIBO:
			saveDraft(SINA_WEIBO);
			break;

		case TENCENT_WEIBO:
			saveDraft(TENCENT_WEIBO);
			break;

		case TENCENT_QZONE:
			saveDraft(TENCENT_QZONE);
			break;

		case WECHAT_FRIEND_ZONE:
			saveDraft(WECHAT_FRIEND_ZONE);
			break;

		default:
			break;

		}
	}

	private void initView() {

		// View:title
		sShareMsgUIbg = (RelativeLayout) findViewById(R.id.share_msg_bg);
		sShareMessageTitle = (RelativeLayout) findViewById(R.id.share_message_title);
		sShareMessagePic = (RelativeLayout) findViewById(R.id.share_message_pic);
		sShareMessageWriteFloor = (RelativeLayout) findViewById(R.id.share_write_floor_layout);
		sShareMessageMain = (LinearLayout) findViewById(R.id.share_message_main);
		sShareMessageFoot = (LinearLayout) findViewById(R.id.share_message_foot);

		sTitleBackBtn = (Button) findViewById(R.id.share_message_title_btn_back);
		sTitleSubmit = (Button) findViewById(R.id.share_message_title_submit);
		sEditMainTxt = (EditText) findViewById(R.id.share_massage_edittxt);
		sEditMainTxt.requestFocus();

		sShareMessageIcon = (ImageView) findViewById(R.id.share_photo_icon);
		sVideoIcon = (ImageView) findViewById(R.id.share_message_video_icon);
		sImageMain = (ImageView) findViewById(R.id.share_massage_photo);

		sShareMessage = (TextView) findViewById(R.id.share_message_txt);
		sTitleTxt = (TextView) findViewById(R.id.share_message_title_str);
		sWordsTxt = (TextView) findViewById(R.id.share_message_txtnum);

		mMask = (View) findViewById(R.id.mask_view);
		// sWordsTxt.setText(MAX_WORDS_SUGGEST_NUM + "");
		// sEditMainTxt.getPaint().setFlags(Paint. UNDERLINE_TEXT_FLAG );
	}

	private void applyShareUITheme() {
		if (themeSettingsHelper.isDefaultTheme()) {
			return;
		}
		Context cxt = Application.getInstance().getApplicationContext();
		if (sShareMsgUIbg != null) {
			sShareMsgUIbg.setBackgroundResource(R.drawable.night_share_message_background);
		}
		if (sShareMessageTitle != null) {
			sShareMessageTitle.setBackgroundResource(R.drawable.night_share_title_bar_bg);
		}
		if (sShareMessagePic != null) {
			sShareMessagePic.setBackgroundResource(R.drawable.night_share_photo_floor);
		}
		if (sShareMessageWriteFloor != null) {
			sShareMessageWriteFloor.setBackgroundResource(R.drawable.night_share_write_floor);
		}
		/*
		 * if(sShareMessageMain!=null){
		 * 
		 * }
		 */
		if (sShareMessageFoot != null) {
			sShareMessageFoot.setBackgroundResource(R.drawable.night_share_write_floor_foot);
		}
		if (sTitleBackBtn != null) {
			sTitleBackBtn.setBackgroundResource(R.drawable.night_share_title_back_btn);
			sTitleBackBtn.setTextColor(cxt.getResources().getColor(R.color.night_list_title_color));
		}
		if (sTitleSubmit != null) {
			sTitleSubmit.setBackgroundResource(R.drawable.night_share_btn_send_selector);
			sTitleSubmit.setTextColor(cxt.getResources().getColor(R.color.night_list_title_color));
		}
		if (sEditMainTxt != null) {
			sEditMainTxt.setHintTextColor(cxt.getResources().getColor(R.color.night_list_comment_color));
			sEditMainTxt.setTextColor(cxt.getResources().getColor(R.color.night_list_title_color));
		}
		if (sShareMessageIcon != null) {
			sShareMessageIcon.setImageResource(R.drawable.night_share_photo_biezhen);
		}
		if (sVideoIcon != null) {
			sVideoIcon.setImageResource(R.drawable.night_share_video_icon);
		}
		/*
		 * if(sImageMain!=null){
		 * 
		 * }
		 */
		if (sShareMessage != null) {
			sShareMessage.setTextColor(cxt.getResources().getColor(R.color.night_list_comment_color));
		}
		if (sTitleTxt != null) {
			sTitleTxt.setTextColor(cxt.getResources().getColor(R.color.night_list_comment_color));
		}
		if (sWordsTxt != null) {
			sWordsTxt.setTextColor(cxt.getResources().getColor(R.color.night_list_comment_color));
		}
		if (mMask != null) {
			mMask.setBackgroundColor(cxt.getResources().getColor(R.color.mask_page_color));
		}
	}

	private void initListener() {
		sTitleBackBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// Auto-generated method stub
				Application.getInstance().hideSoftInputFromWindow(sEditMainTxt.getApplicationWindowToken());
				if (sEditMainTxt.getText().toString() != null) {
					saveDraftMessage(mShareType);
				}
				// quitActivity();
				if (mHandler != null) {
					mHandler.sendEmptyMessageDelayed(SHOW_QUIT_ACTIVITY, 300);
				}
			}
		});

		sTitleSubmit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// Auto-generated method stub
				if (mHandler != null) {
					if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_INAVAILABLE) {
						TipsToast.getInstance().showTipsError("网络异常");
					} else {
						if (isSend) {
							mHandler.sendEmptyMessage(mShareType);
						}
					}
				}
			}
		});

		sEditMainTxt.addTextChangedListener(new TextWatcher() {

			@Override
			public void afterTextChanged(Editable arg0) {
				if (isChange) {
					return;
				}

				/*
				 * int start = sEditMainTxt.getSelectionStart(); int end =
				 * sEditMainTxt.getSelectionEnd();
				 */

				if (temp.length() > MAX_WORDS_SUGGEST_NUM) {
					// TipsToast.getInstance().showTipsError("超出字数限制");
					// arg0.delete(start - 1, end);
					isChange = true;
					sEditMainTxt.setText(arg0);
					sEditMainTxt.setSelection(temp.length());
					// changeTextSwitcherNum();
					isChange = false;
					sEditMainTxt.invalidate();
				}

			}

			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
				if (isChange) {
					return;
				}
				temp = arg0;

			}

			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {

				changeTextSwitcherNum();
			}
		});

	}

	private String titleTxtHander(int type) {
		String title = "";
		switch (type) {
		case SINA_WEIBO:
			title = "新浪微博";
			break;

		case TENCENT_WEIBO:
			title = "腾讯微博";
			break;

		case TENCENT_QZONE:
			title = "QQ空间";
			break;

		case WECHAT_FRIEND_ZONE:
			title = "微信朋友圈";
			break;
		default:
			break;

		}

		return title;
	}

	private void initProperties(String keytype) {
		pts = new Properties();
		pts.setProperty(EventId.KEY_TYPE, keytype);
		pts.setProperty(EventId.KEY_CHANNELID, ShareDialog.getInstance().getChannelId());
		pts.setProperty(EventId.KEY_NEWSID, ShareDialog.getInstance().getNewsItem() != null ? ShareDialog.getInstance().getNewsItem().getId() : "");
		pts.setProperty(EventId.KEY_COMMENTID, ShareDialog.getInstance().getNewsItem() != null ? ShareDialog.getInstance().getNewsItem().getCommentid() : "");
		pts.setProperty(EventId.KEY_IMAGEURL, mImg != null ? mImg : "");
		pts.setProperty(EventId.KEY_VID, mVid != null ? mVid : "");
		WebDev.trackCustomBeginKVEvent(this, EventId.ITIL_SEND_WORDS_TIME, pts);
	}

	private void shareSinaWeibo() {
		SinaAccountsInfo info = SpConfig.getSinaAccountInfo();
		String token = null;
		if (info != null) {
			token = info.getToken();
		}

		String inputTxt = sEditMainTxt.getText().toString().trim();
		if (inputTxt.equals("")) {
			inputTxt = "转";
		}

		// String content_qqweibo = inputTxt + " ||" + SHARE_SEND_WORDS + stitle
		// + mItem.getUrl();
		String content_qqweibo = inputTxt + " ||" + shareMediaName + stitle + mItem.getUrl();
		HttpDataRequest request = TencentNews.getInstance().shareSinaWeibo(mItem.getId(), token, content_qqweibo, mImg, mVid, bstract, title, mItem.getSpecialID(), mItem.getUrl(), aType);
		TaskManager.startHttpDataRequset(request, this);
		initProperties(EventId.VALUE_SINA_WEIBO);
	}

	private void shareTencentWeibo() {
		String inputTxt = sEditMainTxt.getText().toString().trim();
		if (inputTxt.equals("")) {
			inputTxt = "转";
		}

		// String content_qqweibo = inputTxt + " ||" + SHARE_SEND_WORDS + stitle
		// + mItem.getUrl();
		String content_qqweibo = inputTxt + " ||" + shareMediaName + stitle + mItem.getUrl();
		HttpDataRequest request = TencentNews.getInstance().shareTencentWeibo(mItem.getId(), "", content_qqweibo, mImg, mVid, bstract, title, mItem.getSpecialID(), mItem.getUrl(), aType);
		TaskManager.startHttpDataRequset(request, this);
		initProperties(EventId.VALUE_TENCENT_WEIBO);
	}

	private void shareTencentQZone() {
		String desc = sEditMainTxt.getText().toString() + " ||" + title;
		String content = sEditMainTxt.getText().toString().trim();
		HttpDataRequest request = TencentNews.getInstance().shareTencentQzone(mItem.getId(), mItem.getUrl(), title, bstract, desc, mImg, mVid, content, aType);
		TaskManager.startHttpDataRequset(request, this);
		initProperties(EventId.VALUE_QZONE);
	}

	@Deprecated
	private void shareWeChatFriendZone() {

		WXUserInfo info = SpConfig.loadWXSendAuthResp();

		String token = null;
		if (info != null) {
			token = info.getToken();
		}
		String content = sEditMainTxt.getText().toString().trim();
		HttpDataRequest request = TencentNews.getInstance().shareWeChatFriendZone(mItem.getId(), token, title, mItem.getUrl(), content, mImg, mItem.getFlag(), mVid);
		TaskManager.startHttpDataRequset(request, this);
	}

	private void changeTextSwitcherNum() {

		if (mShareType == SINA_WEIBO || mShareType == TENCENT_WEIBO) {
			remainWordsNum = MAX_WORDS_SUGGEST_NUM - sEditMainTxt.getText().toString().length() - nomalWords;
		} else if (mShareType == WECHAT_FRIEND_ZONE) {
			remainWordsNum = WECHAT_F_MAX_WORDS_SUGGEST_NUM - sEditMainTxt.getText().toString().length();
		} else {
			remainWordsNum = MAX_WORDS_SUGGEST_NUM - sEditMainTxt.getText().toString().length();
		}

		if (remainWordsNum < 0) {
			sWordsTxt.setTextColor(Color.RED);
			// sWordsTxt.setText(0 + "");
			sWordsTxt.setText(remainWordsNum + "");
			isSend = false;
			sTitleSubmit.setClickable(false);
			if (themeSettingsHelper.isDefaultTheme()) {
				sTitleSubmit.setBackgroundResource(R.drawable.share_title_back_btn);
			} else {
				sTitleSubmit.setBackgroundResource(R.drawable.night_share_title_back_btn);
			}
			sTitleSubmit.setTextColor(Color.rgb(170, 170, 170));
		} else {
			if (themeSettingsHelper.isDefaultTheme()) {
				sWordsTxt.setTextColor(Color.rgb(153, 153, 153));
			} else {
				sWordsTxt.setTextColor(getResources().getColor(R.color.night_list_comment_color));
			}
			sWordsTxt.setText(remainWordsNum + "");
			isSend = true;
			sTitleSubmit.setClickable(true);
			if (themeSettingsHelper.isDefaultTheme()) {
				sTitleSubmit.setBackgroundResource(R.drawable.share_btn_send_selector);
				sTitleSubmit.setTextColor(getResources().getColor(R.drawable.btn_send_color_selector));
			} else {
				sTitleSubmit.setBackgroundResource(R.drawable.night_share_btn_send_selector);
				sTitleSubmit.setTextColor(getResources().getColor(R.drawable.night_btn_send_color_selector));
			}
		}

	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		mHandler.removeMessages(SINA_WEIBO);
		mHandler.removeMessages(TENCENT_WEIBO);
		mHandler.removeMessages(TENCENT_QZONE);
		mHandler.removeMessages(WECHAT_FRIEND_ZONE);
		mHandler.removeMessages(SHOW_QUIT_ACTIVITY);
	}

	@Override
	public void onHttpRecvOK(HttpTag tag, Object result) {
		String shareType = "";
		String resCode = "";
		if (tag.equals(HttpTag.SHARE_SINA_WEIBO)) {
			shareType = "4";
			SinaResponse response = (SinaResponse) result;
			resCode = response.getRet();
			if (response != null && response.getRet() != null) {
				if (response.getRet().equals("0")) {
					TipsToast.getInstance().showTipsSuccess("分享成功");
					delDraft(SINA_WEIBO);
				} else if (response.getRet().equals("1")) {
					TipsToast.getInstance().showTipsError("分享失败");
					saveDraft(SINA_WEIBO);
				} else if (response.getRet().equals("2")) {
					TipsToast.getInstance().showTipsError("登录失效");
					saveDraft(SINA_WEIBO);
					SpConfig.delSinaAccountsInfo();
				}
			}
		} else if (tag.equals(HttpTag.SHARE_TENCENT_WEIBO)) {
			shareType = "3";
			ShareQQWeiboResponse response = (ShareQQWeiboResponse) result;
			resCode = response.getRet();
			if (response != null && response.getRet() != null) {
				if (response.getRet().equals("0")) {
					TipsToast.getInstance().showTipsSuccess("分享成功");
					delDraft(TENCENT_WEIBO);
				} else if (response.getRet().equals("1")) {
					TipsToast.getInstance().showTipsError("分享失败");
					saveDraft(TENCENT_WEIBO);
				} else if (response.getRet().equals("2")) {
					TipsToast.getInstance().showTipsError("登录失效");
					saveDraft(TENCENT_WEIBO);
					reLogin();
				}
			}
		} else if (tag.equals(HttpTag.SHARE_TENCENT_QZONE)) {
			shareType = "5";
			ShareQzoneResponse response = (ShareQzoneResponse) result;
			resCode = response.getRet();
			if (response != null && response.getRet() != null) {
				if (response.getRet().equals("0")) {
					TipsToast.getInstance().showTipsSuccess("分享成功");
					delDraft(TENCENT_QZONE);
				} else if (response.getRet().equals("1")) {
					TipsToast.getInstance().showTipsError("分享失败");
					saveDraft(TENCENT_QZONE);
				} else if (response.getRet().equals("2")) {
					TipsToast.getInstance().showTipsError("登录失效");
					saveDraft(TENCENT_QZONE);
					reLogin();
				}
			}
		} else if (tag.equals(HttpTag.SHARE_WECHAT_FRIEND_ZONE)) {
			ShareWeChatFriendsResponse response = (ShareWeChatFriendsResponse) result;
			if (response.getRet().equals("0")) {
				TipsToast.getInstance().showTipsSuccess("分享成功");
				delDraft(WECHAT_FRIEND_ZONE);
			} else if (response.getRet().equals("1")) {
				TipsToast.getInstance().showTipsError("分享失败");
				saveDraft(WECHAT_FRIEND_ZONE);
			} else if (response.getRet().equals("2")) {
				TipsToast.getInstance().showTipsError("登录失效");
				saveDraft(WECHAT_FRIEND_ZONE);
				// reLogin();
				// delete token
				SpConfig.delWXSendAuthResp();
			}
		} else {
		}

		/*
		 * 0意见反馈 1评论 2转一下 3腾讯微博 4新浪微博 5QZone 6微信好友 7微信朋友圈
		 */
		//
		// Statistics.getInstance().saveStatistics(Statistics.REPORTED_DATA_WRITE,
		// StatisticsUtil.generateCustomField(
		// new String[] { shareType,
		// ShareDialog.getInstance().getChannelId(),// 频道名称
		// ShareDialog.getInstance().getNewsItem() != null ?
		// ShareDialog.getInstance().getNewsItem().getId(): "",// 文章id
		// ShareDialog.getInstance().getNewsItem() != null ?
		// ShareDialog.getInstance().getNewsItem().getCommentid(): "",// 评论id
		// "",// 耗时
		// ShareDialog.getInstance().getImageUrl(),// 图片url分享到腾讯微博时图片的地址
		// ShareDialog.getInstance().getVid(),// 视频id分享到腾讯微博时视频id
		// "",// 回复id
		// resCode,// 分享状态
		// "", "", "" }));

		WebDev.trackCustomEndKVEvent(this, EventId.ITIL_SEND_WORDS_TIME, pts);
		Properties newpts = new Properties(pts);
		newpts.setProperty(EventId.KEY_RESCODE, resCode);
		WebDev.trackCustomEvent(this, EventId.BOSS_SHARE_NEWS_RESULT, newpts);// 此处要和ITIL_SEND_WORDS_TIME_RESULT区别
	}

	private void reLogin() {
		Intent intent = new Intent();
		intent.setClass(this, LoginActivity.class);
		intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		intent.putExtra(Constants.LOGIN_FROM, Constants.LOGIN_FROM_SHARE_TENCENT_WEIBO);
		this.startActivity(intent);
	}

	private void saveDraft(int id) {
		if (mItem != null || sEditMainTxt.getText().toString() != null) {
			SpDraft.saveDraft(id + mItem.getId(), sEditMainTxt.getText().toString(), Constants.SHARE_DRAFT);
		}
	}

	private String loadDraft(String id) {
		return SpDraft.getDraft(id, Constants.SHARE_DRAFT);
	}

	private void delDraft(int id) {
		SpDraft.delDraft(id + mItem.getId(), Constants.SHARE_DRAFT);
	}

	@Override
	public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {

		WebDev.trackCustomEndKVEvent(this, EventId.ITIL_SEND_WORDS_TIME, pts);
		Properties newpts = new Properties(pts);
		newpts.setProperty(EventId.KEY_RESCODE, EventId.VALUE_RESCODE_ERROR);
		WebDev.trackCustomEvent(this, EventId.ITIL_SEND_WORDS_TIME_RESULT, newpts);

		TipsToast.getInstance().showTipsError("分享失败");
		if (tag.equals(HttpTag.SHARE_SINA_WEIBO)) {
			saveDraft(SINA_WEIBO);
		} else if (tag.equals(HttpTag.SHARE_TENCENT_WEIBO)) {
			saveDraft(TENCENT_WEIBO);
		} else if (tag.equals(HttpTag.SHARE_TENCENT_QZONE)) {
			saveDraft(TENCENT_QZONE);
		} else if (tag.equals(HttpTag.SHARE_WECHAT_FRIEND_ZONE)) {
			saveDraft(WECHAT_FRIEND_ZONE);
		} else {
		}
	}

	@Override
	public void onHttpRecvCancelled(HttpTag tag) {

	}

	@Override
	public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm, String path) {
		if (bm != null) {
			sImageMain.setImageBitmap(bm);
		}
	}

	@Override
	public void onImageRecvError(ImageType imageType, Object tag, int retCode) {
		// add default pic
		sImageMain.setImageResource(R.drawable.icon);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
			if (mHandler != null) {
				if (sEditMainTxt.getText().toString() != null) {
					saveDraftMessage(mShareType);
				}
				mHandler.sendEmptyMessageDelayed(SHOW_QUIT_ACTIVITY, 100);
			}
			return true;
		} else if (event.getKeyCode() == KeyEvent.KEYCODE_MENU && event.getRepeatCount() > 0) {
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	protected void quitActivity() {
		finish();
		overridePendingTransition(R.anim.push_down_in, R.anim.push_down_out);
	}

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}
}
