package com.tencent.news.ui;

import java.util.List;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

import com.tencent.news.R;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.ui.adapter.TopicListAdapter;
import com.tencent.news.ui.view.NetTipsBar;
import com.tencent.news.ui.view.PullImageHeadView;
import com.tencent.news.ui.view.PullToRefreshFrameLayout;
import com.tencent.news.ui.view.TitleBar;
import com.tencent.omg.webdev.WebDev;


public class TopicActivity extends AbsChannelActivityNew {
	
	@Override
	protected void InitContainerView(Bundle savedInstanceState){
		setContentView(R.layout.topic_layout);
		mFramelayout = (PullToRefreshFrameLayout)findViewById(R.id.topic_list_content);
		mListView = mFramelayout.getPullToRefreshListView();
		mTitleBar = (TitleBar)findViewById(R.id.topic_title_bar);
		mTitleBar.bringToFront();
		mNetTipsBar = (NetTipsBar)findViewById(R.id.topic_nettips_bar);
		mTitleBar.ShowElseBar(R.string.title_topic);
		if(mIsViewPager){
			mTitleBar.setVisibility(View.GONE);
		}
		
		mTitleBar.setTopClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				setSelection();
			}
			
		});
		
		
	}

	@Override
	protected String getListviewTimeTag() {
		// TODO Auto-generated method stub
		return mChannel;
	}
	
	@Override
	protected void InitAdapter(){
		mAdapter = new TopicListAdapter(this, mListView);
		mListView.setAdapter(mAdapter);
	}

	@Override
	protected void addHeadView() {
		mHeadView = new PullImageHeadView(this);
		mListView.addHeaderView(mHeadView);	
		
	}

	@Override
	protected synchronized void setHeadData(List<Item> list) {
		if(list != null && list.size()>0){
			mHeadItem = list.remove(0);
		}
		
	}

	@Override
	protected Class<? extends Object> getClassName(Item item) {
		// TODO Auto-generated method stub
		return NewsDetailActivity.class;
	}

	@Override
	protected String getChlidTitle() {
		// TODO Auto-generated method stub
		return "今日话题";
	}

	@Override
	protected boolean isRegisterNetTips() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	protected boolean isNeedHeadView() {
		// TODO Auto-generated method stub
		return true;
	}
	
	@Override
	protected void setLayout(boolean bFlag) {
		if (mNetTipsBar != null) {
			if (bFlag) {
				mNetTipsBar.setVisibility(View.GONE);
			} else {
				mNetTipsBar.bringToFront();
				mNetTipsBar.setVisibility(View.VISIBLE);
			}
		}
	}
	
	@Override
	public void applyTheme(){
		super.applyTheme();		
		mTitleBar.applyTitleBarTheme(this);
		mNetTipsBar.applyNetTipsBarTheme(this);
		/*if(mAdapter!=null){
			mAdapter.notifyDataSetChanged();
		}
		if(mFramelayout!=null){
			mFramelayout.applyFrameLayoutTheme();
		}		
		if(mHeadView!=null){
			mHeadView.applyImageHeadTheme();
		}
		if(mListView!=null){
			themeSettingsHelper.setViewBackgroudColor(this, this.mListView, R.color.timeline_home_bg_color);
			themeSettingsHelper.setListViewSelector(this, this.mListView, R.drawable.list_selector);
			themeSettingsHelper.setListViewDivider(this, this.mListView, R.drawable.list_divider_line);
		}*/
	}

	@Override
	protected void createCellView() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void removeCellView() {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}
}
