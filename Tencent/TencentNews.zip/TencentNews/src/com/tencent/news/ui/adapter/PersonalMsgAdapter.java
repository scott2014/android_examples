package com.tencent.news.ui.adapter;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import com.tencent.news.R;
import com.tencent.news.command.GetImageRequest;
import com.tencent.news.config.Constants;
import com.tencent.news.model.pojo.ImageResult;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.model.pojo.NewsMsg;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.adapter.FavoriteslListAdapter.ViewHolder;
import com.tencent.news.ui.view.PullRefreshListView;
import com.tencent.news.utils.StringUtil;

/**
 * @author haiyandu
 * @since  2013-6-21
 */
public class PersonalMsgAdapter extends AbsListAdapter<NewsMsg> {
    
    private boolean isShowCheckBox = false;
    private List<Boolean> isSelectedList;

	public PersonalMsgAdapter(Context context, ListView listView) {
		this.mContext = context;
		this.mListView = listView;	
		mDataList = new ArrayList<NewsMsg>();
		isSelectedList = new ArrayList<Boolean>();
		((PullRefreshListView) mListView).setSartListener(this);	
	}
	
	@Override
    public void addDataList(List<NewsMsg> list) {
        // TODO Auto-generated method stub
        super.addDataList(list);
        initSelectedState();
    }
	
	public void initSelectedState() {
	    isSelectedList.clear();
        for (int i = 0; i < mDataList.size(); i++) {
            isSelectedList.add(false);
        }
	}
	
	public List<Boolean> getIsSelected() {
        return isSelectedList;
    }
	
	public void setShowCheckBox(boolean editable) {
	    this.isShowCheckBox = editable;
	}

	// 不分图片模式和文字模式，都有头像
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		return setImageMode(convertView, position, null);
	}

	private View setImageMode(View convertView, int position, MsgViewHolder holder) {
		if(convertView == null){
			holder = new MsgViewHolder();
			convertView = LayoutInflater.from(mContext).inflate(R.layout.personal_msg_item_layout, null);
			holder.userIcon = (ImageView)convertView.findViewById(R.id.msg_user_icon);
			holder.userAuth = (ImageView)convertView.findViewById(R.id.msg_user_vip_icon);
			holder.userName = (TextView)convertView.findViewById(R.id.msg_list_item_user_name);
			holder.userTime = (TextView)convertView.findViewById(R.id.msg_list_item_time);
			holder.userContent = (TextView)convertView.findViewById(R.id.msg_list_item_content);
			holder.userMsgCount = (TextView) convertView.findViewById(R.id.msg_user_count_icon);
			holder.checkIcon = (ImageView) convertView.findViewById(R.id.check_icon);
			convertView.setTag(holder);
		} else {
			holder = (MsgViewHolder)convertView.getTag();
		}
		
		NewsMsg msg = mDataList.get(position);
		holder.id = msg.getTime();
		if (msg.getIsvip().equals("1")) {
			holder.userAuth.setVisibility(View.VISIBLE);
		} else {
			holder.userAuth.setVisibility(View.GONE);
		}
		
		holder.userName.setText(msg.getNick());
		
		if (themeSettingsHelper.isNightTheme()) {
		    holder.userName.setTextColor(Color.parseColor("#f0f4f8"));
		} else {
		    holder.userName.setTextColor(Color.parseColor("#444444"));
		}
		
		
		holder.userContent.setText(msg.getMsg());
		holder.userTime.setText(StringUtil.getPublishTime(Long.parseLong(msg.getTime()+"000")));
		
		if (msg.getNewCount().equals("0")) {
		    holder.userMsgCount.setVisibility(View.GONE);
		} else {
		    holder.userMsgCount.setVisibility(View.VISIBLE);
		    holder.userMsgCount.setText(msg.getNewCount());
		}
		
		showCheckBox(convertView, holder.checkIcon, position);
		
		if (!((PullRefreshListView) mListView).isBusy()) {
			setUserIcon(msg, holder);
		} else {
			GetImageRequest request = new GetImageRequest();
			request.setUrl(msg.getHead());
			request.setTag(holder.id);
			ImageResult result = TaskManager.getLocalIconImage(request, this);
			if (result.isResultOK() && result.getRetBitmap() != null){
			    holder.userIcon.setImageBitmap(result.getRetBitmap()); 
			} else {
				holder.userIcon.setImageResource(R.drawable.default_comment_user_man_icon);
			}
		}
		return convertView;
	}
	
	public void showCheckBox(View convertView, ImageView checkIcon, int position) {
	    if (themeSettingsHelper.isNightTheme()) {
            if (isShowCheckBox) {
                checkIcon.setVisibility(View.VISIBLE);
                if (isSelectedList.get(position)) {
                    convertView.setBackgroundColor(mContext.getResources().getColor(R.color.night_checked));
                    checkIcon.setImageResource(R.drawable.collection_checked);

                } else {
                    convertView.setBackgroundColor(mContext.getResources().getColor(R.color.night_view_bg_color));
                    checkIcon.setImageResource(R.drawable.night_collection_check_box);
                }
            } else {
                convertView.setBackgroundColor(mContext.getResources().getColor(R.color.transparent));
                checkIcon.setVisibility(View.GONE);
            }
        } else {
            if (isShowCheckBox) {
                checkIcon.setVisibility(View.VISIBLE);
                if (isSelectedList.get(position)) {
                    convertView.setBackgroundColor(mContext.getResources().getColor(R.color.checked));
                    checkIcon.setImageResource(R.drawable.collection_checked);

                } else {
                    convertView.setBackgroundColor(mContext.getResources().getColor(R.color.view_bg_color));
                    checkIcon.setImageResource(R.drawable.collection_check_box);
                }
            } else {
                convertView.setBackgroundColor(mContext.getResources().getColor(R.color.transparent));
                checkIcon.setVisibility(View.GONE);
            }
        }
	    
	}
	
	private void setUserIcon(NewsMsg msg, MsgViewHolder holder){
		GetImageRequest request = new GetImageRequest();
		request.setGzip(false);
		request.setTag(msg.getTime());
		request.setUrl(msg.getHead());
		ImageResult result = TaskManager.startSmallImageTask(request, this);
		if (result.isResultOK() && result.getRetBitmap() != null) {
			holder.userIcon.setImageBitmap(result.getRetBitmap());
		}else{
			holder.userIcon.setImageResource(R.drawable.default_comment_user_man_icon);
		}
	}
	
	@Override
	public int getItemViewType(int position) {	
		return styleType;
	}
	
	@Override
	public int getViewTypeCount() {
		// Auto-generated method stub
		return 1;
	}
	
	@Override
	public void changeStyleMode(int style) {
		// TODO Auto-generated method stub
		styleType = style;
		notifyDataSetChanged();
	}
	
	@Override
	public void serListViewBusy(int currPosition, int tag) {
		// TODO Auto-generated method stub
		if(styleType == Constants.TYPE_ITEM_TEXT){
			return;
		}
		MsgViewHolder holder = (MsgViewHolder)mListView.getChildAt(tag).getTag();
		if(currPosition >= 0 && currPosition < mDataList.size() && holder != null){
			NewsMsg msg = mDataList.get(currPosition);			
			setUserIcon(msg, holder);		
		}
	}

	@Override
	public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm,
			String path) {
		// TODO Auto-generated method stub
		switch (imageType) {
		case SMALL_IMAGE:
			int countImage = mListView.getChildCount();
			for (int i = 0; i < countImage; i++) {
				MsgViewHolder holder = (MsgViewHolder) mListView.getChildAt(i).getTag();
				if (holder != null) {
					if (((String) tag).equals(holder.id)) {
						if (bm != null && holder.userIcon != null) {
							holder.userIcon.setImageBitmap(bm);	
						}
					}
				}
			}
			break;
		default:
			break;
		}
	}

	@Override
	public void onImageRecvError(ImageType imageType, Object tag, int retCode) {
		// TODO Auto-generated method stub
		
	}

	public static class MsgViewHolder {
		String id;
		ImageView userIcon;
		ImageView userAuth;
		TextView userName;
		TextView userTime;
		TextView userContent;
		TextView userMsgCount;
		public ImageView checkIcon;
		boolean checked;
	}
}
