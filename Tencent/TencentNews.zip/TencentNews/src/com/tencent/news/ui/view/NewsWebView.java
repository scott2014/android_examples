package com.tencent.news.ui.view;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;

import com.tencent.news.cache.RssChannelSyncHelper;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.model.pojo.BroadCast;
import com.tencent.news.model.pojo.Editor;
import com.tencent.news.model.pojo.Image;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.model.pojo.RssCatListItem;
import com.tencent.news.model.pojo.SimpleNewsDetail;
import com.tencent.news.model.pojo.VideoValue;
import com.tencent.news.shareprefrence.SpConfig;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.ui.AbsNewsActivity;
import com.tencent.news.ui.RssMediaHistoryActivity;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.StringUtil;
import com.tencent.news.utils.TempManager;
import com.tencent.news.utils.ThemeSettingsHelper;

public class NewsWebView extends WebView {

    private ThemeSettingsHelper themeSettingsHelper  = null;
    private Context             mContext;
    private String              mImageStyle;
    private String              mVideoStyle;
    private int                 mWidth;
    private int                 mHeight;
    private int                 nFont;
    private int                 mStyleMode;
    private boolean             isDestroy            = true;
    private boolean             isOffline            = false;
    private String              reffer;
    private String              mProgid;
    private String              mPlayMode;
    private String              mPlayUrl;
    private String              themePrefix          = "";
    private String              mTitle_template      = "<div class=\"title %s\" align=\"left\">%s</div>";
    private String              mTypeFlag_template   = "<img id=\"type_flag\" src=\"%s\" />";
    private String              mTime_template       = "<div class=\"title_bar\"><span class=\"src\">%s</span><span id=\"post_time\" class=\"src\">%s</span>";
    private String              mVote_template_title = "<span class=\"type_vote\">%s</span>";
    private String              js_url               = "http://mat1.gtimg.com/www/js/newsapp/vote_android/webkitVote20130530.js";

    public NewsWebView(Context context) {
        super(context);
        InitView(context);
    }

    public NewsWebView(Context context, AttributeSet attrs) {
        super(context, attrs);
        InitView(context);
    }

    public NewsWebView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        InitView(context);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void InitView(Context context) {
        mContext = context;
        setBackgroundColor(Color.WHITE);
        getSettings().setDefaultTextEncodingName("UTF-8");
        getSettings().setSupportZoom(true);
        getSettings().supportMultipleWindows();
        getSettings().setJavaScriptEnabled(true);
        getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        /* getSettings().setBlockNetworkImage(true); */
        clearFocus();
        clearView();
        setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        initSettingData();
        themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(mContext);
        if (!themeSettingsHelper.isDefaultTheme()) {
            themePrefix = "night_";
        }
    }

    /**
     * 设置来源
     * 
     * @param rf
     */
    public void setReffer(String rf) {
        this.reffer = rf;
    }

    /**
     * 是否是离线模式
     */
    public void setOffline() {
        isOffline = true;
        mStyleMode = 1;
        mImageStyle = "image imageText";
        mVideoStyle = "video videoText";
    }

    /**
     * 初始化文字模式的样式
     */
    private void initSettingData() {
        mWidth = MobileUtil.getScreenWidthIntPx();
        mHeight = MobileUtil.getScreenHeightIntPx() - MobileUtil.dpToPx(50) - MobileUtil.dpToPx(45);
        SettingInfo settingInfo = SettingObservable.getInstance().getData();
        nFont = settingInfo.getTextSize() + 1;
        if (settingInfo.isIfTextMode()) {
            mStyleMode = 1;
            mImageStyle = "image imageText";
            mVideoStyle = "video videoText";
        } else {
            mImageStyle = "image";
            mVideoStyle = "video";
            mStyleMode = 0;
        }
    }

    /**
     * 生成评论数模版
     */
    private String getCommentCountTemplate(String TypeFlag, String num, Boolean isShow) {
        String style = isShow ? "" : "style=\"display:none;\"";
        StringBuilder sb = new StringBuilder();
        sb.append("<span id=\"comment_count\" " + style + " class=\"src " + TypeFlag + "\">");
        sb.append("<img src=\"./images/" + themePrefix + "comment_icon.png\"/><label>" + num + "</label>");
        sb.append("</span>");
        return sb.toString();
    }

    /**
     * 生成分割线HTML
     * 
     */
    private String getSeperationTemplate() {
        StringBuilder sb = new StringBuilder();
        sb.append("<div id=\"seperation\">");
        sb.append("<img src=\"./images/" + themePrefix + "text_seperation_line.png\"/>");
        sb.append("</div>");
        return sb.toString();
    }

    /**
     * 生成摘要部分模版
     * 
     * @param str
     *            <String> 摘要内容
     * @return
     */
    private String getSummaryTpl(String str) {
        StringBuilder sb = new StringBuilder();
        sb.append("<div class=\"summary\">");
        sb.append(str);
        sb.append("</div>");
        return sb.toString();
    }

    /**
     * 生成结语部分模版
     * 
     * @param str
     *            <String> 结语内容
     * @return
     */
    private String getRemarksTpl(String str) {
        StringBuilder sb = new StringBuilder();
        sb.append("<div class=\"summary\" style=\"margin-top:10px;\">");
        sb.append(str);
        sb.append("</div>");
        return sb.toString();
    }

    /**
     * 生成图片部分投票
     * 
     * @param voteId
     *            投票id
     * @return
     */
    private String getVoteTpl(String voteId) {
        SettingInfo settingInfo = SettingObservable.getInstance().getData();
        if (settingInfo.isIfTextMode() || isOffline) {
            return createTextVoteTpl(voteId);
        } else {
            return createVoteTpl(voteId);
        }
    }

    /**
     * 生成文字模式投票
     * 
     * @param voteId
     *            投票id
     * @return
     */
    private String createTextVoteTpl(String voteId) {
        StringBuilder sb = new StringBuilder();
        sb.append("<div id=\"VoteContainer\" class=\"voteText\"></div>");
        sb.append("<script type=\"text/javascript\">");
        sb.append("var voteConfig = {");
        sb.append("    container : 'VoteContainer',");
        sb.append("    voteUrl   : 'http://r.inews.qq.com/getQQVoteInfo?otype=jsonpval&id=" + voteId + "',");
        sb.append("    submitUrl : 'http://input.vote.qq.com/survey.php',");
        sb.append("    voteJsUrl : '" + js_url + "',");
        sb.append("    loading   : true,");
        sb.append("    errorTip  : true,");
        sb.append("    subStr    : 22");
        sb.append("};");
        sb.append("function loadVoteJsComplete() {");
        sb.append("if(!webkitVote) {");
        sb.append("	return;");
        sb.append("}");
        sb.append("webkitVote.postData = function(a) {");
        sb.append("	if (typeof window.TencentNews != 'undefined') {");
        sb.append("		window.TencentNews.submitVoteData(JSON.stringify(a));");
        sb.append("		return;");
        sb.append("	}");
        sb.append("};");
        sb.append("webkitVote.init();");
        sb.append("}");
        sb.append("</script>");
        return sb.toString();
    }

    /**
     * 生成图片模式投票
     * 
     * @param voteId
     *            投票id
     * @return
     */
    private String createVoteTpl(String voteId) {
        StringBuilder sb = new StringBuilder();
        sb.append("<div id=\"VoteContainer\" class=\"voteLoading\"></div>");
        sb.append("<script language=\"javascript\" src=\"" + js_url + "\" id=\"VoteJs\" charset=\"utf-8\"></script>");
        sb.append("<script type=\"text/javascript\">");
        sb.append("var voteConfig = {");
        sb.append("    container : 'VoteContainer',");
        sb.append("    voteUrl   : 'http://r.inews.qq.com/getQQVoteInfo?otype=jsonpval&id=" + voteId + "',");
        sb.append("    submitUrl : 'http://input.vote.qq.com/survey.php',");
        sb.append("    voteJsUrl : '" + js_url + "',");
        sb.append("    loading   : true,");
        sb.append("    errorTip  : true,");
        sb.append("    subStr    : 22");
        sb.append("};");
        sb.append("webkitVote.postData = function(a) {");
        sb.append("	if (typeof window.TencentNews != 'undefined') {");
        sb.append("		window.TencentNews.submitVoteData(JSON.stringify(a));");
        sb.append("		return;");
        sb.append("	}");
        sb.append("};");
        sb.append("setTimeout(function(){webkitVote.init();}, 500);");
        sb.append("</script>");
        return sb.toString();
    }

    /**
     * 生成图片部分HTML
     * 
     * @param id
     *            <String> 图片ID, url的Md5值
     * @param index
     *            <String> 图片在相册或者文章中的位置
     * @param source
     *            <String> 图片路径
     * @param width
     *            <int> 图片宽度
     * @param height
     *            <int> 图片高度
     * @param desc
     *            <String> 图片描述
     * @return 拼接好的图片部分HTML
     */
    private String getImageTpl(String id, String index, String source, String width, String height, String desc) {
        StringBuilder sb = new StringBuilder();
        Boolean isDesc = (!desc.trim().equals("")) ? true : false;
        if (isDesc) {
            sb.append("<div class=\"" + mImageStyle + "\">");
        } else {
            sb.append("<div class=\"" + mImageStyle + "\" style=\"margin-bottom:10px\">");
        }
        sb.append("<img id=\"" + id + "\" index=\"" + index + "\" src=\"\" data-natural-width=\"" + width + "\" data-natural-height=\"" + height + "\" />");
        sb.append("</div>");
        if (isDesc) {
            sb.append("<div class=\"image_desc\">");
            sb.append(desc);
            sb.append("</div>");
        }
        return sb.toString();
    }

    /**
     * 生成视频部分HTML
     * 
     * @param <String>
     *            vid
     * @param <String>
     *            vtype 视频播放类型
     * @param <String>
     *            vurl 视频播放url
     * @param <String>
     *            id
     * @param <String>
     *            width 视频缩略图宽度
     * @param <String>
     *            height 视频缩略图高度
     * @param <String>
     *            isCopyright 是否是有版权，播放类型：0是无版权，1是有版权
     * @return 拼接好的视频部分HTML
     */
    private String getVideoTpl(String vid, String vtype, String vurl, String id, String width, String height, String isCopyright) {
        StringBuilder sb = new StringBuilder();
        sb.append("<div class=\"" + mVideoStyle + "\">");
        sb.append("<span id=\"" + vid + "\" class=\"mod_player\" vid=\"" + vid + "\" vtype=\"" + vtype + "\" vurl=\"" + vurl + "\">");
        sb.append("<img id=\"" + id + "\" src=\"\" data-natural-width=\"" + width + "\" data-natural-height=\"" + height + "\"/>");
        sb.append("<span>");
        sb.append("<a href=\"javascript:void(0)\"></a>");
        sb.append("</span>");
        sb.append("<label id=\"countdown\"></label>");
        if (isCopyright.equals("0")) {
            sb.append("<span class=\"video_icon\"></span>");
        }
        sb.append("</span>");
        sb.append("</div>");
        return sb.toString();
    }

    /**
     * 拼接文章中链接
     * 
     * @link 
     *       http://tapd.oa.com/v3/newsapp/wikis/view/%2525E6%252596%2525B0%2525E7
     *       %252589%252588html%2525E5%2525BA%252595%2525E5%2525B1%252582
     * @param item
     *            <Item> Item对象
     * @param key
     *            <String> 文章链接的key值
     * @return
     */
    private String getLinkTpl(Item item, String key) {
        StringBuilder sb = new StringBuilder();
        String title = item.getShowTitle() != null ? item.getShowTitle() : item.getTitle();
        sb.append("<a href=\"" + AbsNewsActivity.INTERNAL_GOTO_URL + "?id=" + key + "\">" + title + "</a>");
        return sb.toString();
    }

    /**
     * 生成相关新闻模版
     * 
     * @param relateNews
     * @return
     */
    @SuppressLint("SimpleDateFormat")
    private String getRelateNewsTpl(List<Item> relateNews) {
        int len = relateNews.size();
        len = Math.min(len, 4);
        StringBuilder sb = new StringBuilder();
        String shortPostTime = "";
        sb.append("<div class=\"relatedNews\">");
        sb.append("  <div class=\"rTitle\">相关新闻</div>");
        sb.append("  <ul class=\"list\">");
        for (int i = 0; i < len; i++) {
            Item item = relateNews.get(i);
            sb.append("<li class=\"clearfix\">");
            sb.append("<a href=\"" + AbsNewsActivity.RELATE_NEWS + "?id=" + item.getId() + "\">" + item.getTitle());
            sb.append("<br>");
            try {
                SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date postTime = formater.parse(item.getTime());
                formater.applyPattern("yyyy-MM-dd");
                shortPostTime = formater.format(postTime);
            } catch (ParseException px) {
            }
            sb.append("<span>" + shortPostTime + "</span>");
            sb.append("</a>");
            sb.append("</li>");
        }
        sb.append("  </ul>");
        sb.append("</div>");
        return sb.toString();
    }

    /**
     * 渲染编辑部分模版
     * 
     * @param e
     * @return
     */
    private String getEditorsTpl(Editor e) {
        StringBuilder sb = new StringBuilder();
        String url = "http://m.3g.qq.com/account_guest.html?aid=" + e.getId() + "&fr=5";
        Boolean isLink = (e.getFlag().equals("0") || e.getFlag().equals(0)) ? false : true;
        sb.append("<div class=\"editors\">");
        sb.append("  <div class=\"eText\">");
        sb.append("		    <span>" + e.getTitle() + "</span>");
        if (isLink) {
            sb.append("<a href=\"" + url + "\">" + e.getNick() + "</a>");
        } else {
            sb.append("<span class=\"noIcon\">" + e.getNick() + "</span>");
        }
        sb.append("</div>");
        sb.append("  <div class=\"eIcon\">");
        if (isLink) {
            sb.append("<a href=\"" + url + "\">");
        }
        if (e.getHeadimg().trim().equals("")) {
            sb.append("<img src=\"images/default_comment_user_man_icon.png\" width=\"60\" height=\"60\">");
        } else {
            sb.append("<img src=\"" + e.getHeadimg() + "\" width=\"60\" height=\"60\">");
        }
        if (isLink) {
            sb.append("</a>");
        }
        sb.append("  </div>");
        sb.append("</div>");
        return sb.toString();
    }

    /**
     * 获取话题期数模版
     * 
     * @return
     */
    private String getTopicIssueTemplate(String qishu) {
        StringBuilder sb = new StringBuilder();
        sb.append("<div id=\"topic_issue\">第" + qishu + "期</div>");
        return sb.toString();
    }

    /**
     * 根据数据渲染WebView
     * 
     * @param <item>
     *            列表页传递过来的数据
     * @param <detail>
     *            从线上拉取的数据
     * @since ${date} ${time}
     * @return
     */
    @SuppressLint("SimpleDateFormat")
    public String LoadLocalWithData(Item item, SimpleNewsDetail detail) {

        StringBuilder sb = new StringBuilder();
        if (item == null) {
            return null;
        }
        // 话题期刊数
        if (item != null && item.getQishu() != null && !item.getQishu().equals("")) {
            sb.append(getTopicIssueTemplate(item.getQishu()));
        }

        // 标题
        String hasTopicIssue = item.getQishu() == null || item.getQishu().equals("") ? "" : "has_topic_issue";
        sb.append(String.format(mTitle_template, hasTopicIssue, item.getTitle()));

        // 发布时间
        String shortPostTime = "";
        try {
            if (item.getTime() != null) {
                SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date postTime = formater.parse(item.getTime());
                formater.applyPattern("MM-dd HH:mm");
                shortPostTime = formater.format(postTime);
            }
        } catch (ParseException px) {
        }

        String autherSrc = item.getSource() != null ? item.getSource() : item.getChlname() != null ? item.getChlname() : "";
        sb.append(String.format(mTime_template, autherSrc, shortPostTime));

        // 文章类型图标
        if (!getTypeImagePath(item).equals("")) {
            sb.append(String.format(mTypeFlag_template, getTypeImagePath(item)));
        }

        // 投票类型增加文字
        if (item.getFlag() != null && item.getFlag().equals("2")) {
            sb.append(String.format(mVote_template_title, "投票"));
        }

        // 评论数
        String hasTypeFlag = getTypeImagePath(item).equals("") ? "" : "has_type_flag";
        if (item.getCommentNum() != null && !item.getCommentNum().equals("0")) {
            sb.append(getCommentCountTemplate(hasTypeFlag, item.getCommentNum(), true));
        } else {
            sb.append(getCommentCountTemplate(hasTypeFlag, item.getCommentNum(), false));
        }

        sb.append("</div>");

        // 正文分隔线
        sb.append(getSeperationTemplate());

        // 导语
        String intro = detail.getIntro();
        if (intro != null && !intro.equals("")) {
            sb.append(getSummaryTpl(intro));
        }

        // 正文包括图片视频等
        TreeMap<String, Object> attribute = detail.getAttribute();
        String contentText = detail.getText();
        try {
            String image_pattern = "<!--(([A-Z]+)_(\\d+))-->";
            Pattern pattern = Pattern.compile(image_pattern);
            Matcher matcher = pattern.matcher(contentText);
            Log.i("DataTagName", matcher.toString());
            while (matcher.find()) {
                String all = matcher.group();
                Log.i("DataTagName", all);
                String key = matcher.group(1);
                if (key != null && attribute.containsKey(key)) {

                    // 图片
                    if (key.indexOf("IMG") > -1) {
                        String index = matcher.group(3);
                        Image imgObj = (Image) attribute.get(key);
                        String url = imgObj.getUrl();
                        String id = StringUtil.toMd5(url);
                        String height = imgObj.getHeight();
                        String width = imgObj.getWidth();
                        String desc = imgObj.getDesc();
                        String imgTpl = getImageTpl(id, index, url, width, height, desc);
                        contentText = contentText.replaceAll("<P>" + all + "</P>", imgTpl);
                        continue;
                    }

                    // 视频
                    if (key.indexOf("VIDEO") > -1) {
                        VideoValue obj = (VideoValue) attribute.get(key);
                        String video = "";
                        String vtype = obj.getVideoSourceType();
                        String vid = obj.getVid();
                        String img = obj.getImg();
                        String id = StringUtil.toMd5(img);
                        String height = obj.getHeight();
                        String width = obj.getWidth();
                        // 视频类型：1是普通视频，2是直播视频
                        if (vtype.equals("1")) {
                            String isCopyright = obj.getPlayMode();
                            mPlayUrl = obj.getPlayUrl();
                            mPlayMode = isCopyright;
                            video = getVideoTpl(vid, vtype, "", id, width, height, isCopyright);
                        } else {
                            if (obj.getBroadCast() != null) {
                                BroadCast broadcast = obj.getBroadCast();
                                String progid = broadcast.getProgid();
                                mProgid = progid;
                                String liveUrl = broadcast.getUrl();
                                video = getVideoTpl(progid, vtype, liveUrl, progid, width, height, "");
                            }
                        }
                        contentText = contentText.replaceAll(all, video);
                        continue;
                    }

                    // 相关新闻
                    if (key.indexOf("LINK") > -1) {
                        Item it = (Item) attribute.get(key);
                        String linkTpl = getLinkTpl(it, key);
                        contentText = contentText.replaceAll(all, linkTpl);
                        continue;
                    }

                }
            }
        } catch (Exception ex) {
            Log.i("DataTagName", "matcher error");
        }

        // 统一替换标签
        if (contentText != null) {
            String html_pattern = "<!--([^-]+?)-->";
            contentText = contentText.replaceAll(html_pattern, "<$1>");
            sb.append(contentText);
        }

        // 结语
        String remarks = detail.getRemarks();
        if (remarks != null && !remarks.equals("")) {
            sb.append(getRemarksTpl(remarks));
        }
        
        //查看原文
        if(item != null && item.getOrigUrl() != null && !item.getOrigUrl().equals("")) {
            sb.append(getOrigUrlTpl(item));
        }

        // 投票
        Boolean isVote = (item != null && item.getVoteId() != null && !item.getVoteId().equals("")) ? true : false;
        if (isVote) {
            sb.append(getVoteTpl(item.getVoteId()));
        }

        // 编辑信息
        Editor ed = detail.getEditor();
        if (ed != null) {
            sb.append(getEditorsTpl(ed));
        }

        // 媒体名片
        if (detail.getCard() != null && !RssMediaHistoryActivity.SUB_CLASS_NAME.equals(reffer)) {
            RssCatListItem card = detail.getCard();
            sb.append(createMediaTpl(card, item));
        }

        // 相关新闻
        List<Item> relateNews = detail.getRelate_news();
        if (relateNews != null) {
            int l = relateNews.size();
            if (l > 0) {
                sb.append(getRelateNewsTpl(relateNews));
            }
        }

        String mTemplate = TempManager.getManager().getTemplate(mContext, TempManager.TEMP_NAME);
        mTemplate = mTemplate.replace("{{template_content}}", sb.toString());
        mTemplate = mTemplate.replace("{{webview_width}}", "" + mWidth);
        mTemplate = mTemplate.replace("{{webview_height}}", "" + mHeight);
        mTemplate = mTemplate.replace("{{template_font_size_index}}", "" + nFont);
        mTemplate = mTemplate.replace("{{is_text_mode}}", "" + mStyleMode);
        mTemplate = mTemplate.replace("{{theme_prefix}}", "" + themePrefix);
        mTemplate = mTemplate.replace("{{is_default_theme}}", "" + themePrefix);
        loadDataWithBaseURL("file:///android_asset/", mTemplate, "text/html", "UTF-8", null);
        return mTemplate;
    }

    /**
     * 生成查看原文
     * @param item
     * @return 
     */
    private String getOrigUrlTpl(Item item) {
        StringBuilder sb = new StringBuilder();
        sb.append("<div class=\"origUrl\">");
        sb.append("    <a href=\"" + item.getOrigUrl() + "\">阅读原文</a>");
        sb.append("</div>");
        return sb.toString();        
    }
    
    /**
     * 查看媒体名片
     * 
     * @param item
     * @return
     */
    private String createMediaTpl(RssCatListItem card, Item item) {
        StringBuilder sb = new StringBuilder();
        if (RssChannelSyncHelper.getInstance().isBookedChannel(card.getChlid())) {
            sb.append("<div id=\"RssMedia\">");
            SettingInfo settingInfo = SettingObservable.getInstance().getData();
            if (settingInfo.isIfTextMode()) {
                sb.append("    <div class=\"rss-media-text\" style=\"left:15px\">");
            } else {
                sb.append("    <div class=\"icon-img\">");
                sb.append("        <img src=\"" + card.getIcon() + "\" width=\"61\" height=\"61\"/>");
                sb.append("    </div>");
                sb.append("    <a class=\"icon-mask\" href=\"" + AbsNewsActivity.RSS_MEDIA_NEWS + "\">&nbsp;</a>");
                sb.append("    <div class=\"rss-media-text\">");
            }
            sb.append("<div class=\"history-text\"><h5>查看历史文章</h5></div>");
            sb.append("    </div>");
            sb.append("    <div class=\"rss-media-arrow\"></div>");
            if (settingInfo.isIfTextMode()) {
                sb.append("<a href=\"" + AbsNewsActivity.RSS_MEDIA_HISTORY_NEWS + "\" class=\"open-history\" style=\"left:15px\">&nbsp;</a>");
            } else {
                sb.append("<a href=\"" + AbsNewsActivity.RSS_MEDIA_HISTORY_NEWS + "\" class=\"open-history\">&nbsp;</a>");
            }
            sb.append("    <div class=\"press\"></div>");
            sb.append("</div>");
        } else {
            if(!SpConfig.getFristRssMedia()) {         
                sb.append("<div id=\"RssTooltips\">");
                sb.append("<p>查看媒体信息，并<span>订阅</span>该媒体</p>");
                sb.append("<div class=\"arrow\">");
                sb.append("  </div>");
                sb.append("</div>");
                sb.append("<a id=\"RssMedia\" href=\"" + AbsNewsActivity.RSS_MEDIA_NEWS + "\" class=\"blue-border\">");
            } else {
                sb.append("<a id=\"RssMedia\" href=\"" + AbsNewsActivity.RSS_MEDIA_NEWS + "\">");                  
            }            
            SettingInfo settingInfo = SettingObservable.getInstance().getData();
            if (settingInfo.isIfTextMode()) {
                sb.append("    <div class=\"rss-media-text\" style=\"left:15px\">");
            } else {
                sb.append("    <div class=\"icon-img\">");
                sb.append("        <img src=\"" + card.getIcon() + "\" width=\"61\" height=\"61\"/>");
                sb.append("    </div>");
                sb.append("    <div class=\"icon-mask\"></div>");
                sb.append("    <div class=\"rss-media-text\">");
            }
            sb.append("<h5>" + card.getChlname() + "</h5>");
            sb.append("<div class=\"rss-info\">" + card.getIntro() + "</div>");
            sb.append("    </div>");
            sb.append("    <div class=\"rss-media-arrow\"></div>");
            sb.append("    <div class=\"press\"></div>");
            sb.append("</a>");
        }
        return sb.toString();
    }

    private String getTypeImagePath(Item item) {
        String flag = item.getFlag();
        String path = "";
        if (flag != null) {
            if (flag.equals("1")) {
                path = "./images/" + themePrefix + "flag_scoop_icon_h.png";
            } else if (flag.equals("2")) {
                path = "./images/" + themePrefix + "flag_tote_icon.png";
            } else if (flag.equals("3")) {
                path = "./images/" + themePrefix + "flag_video_icon_h.png";
            } else if (flag.equals("4")) {
                path = "./images/" + themePrefix + "flag_special_icon.png";
            } else if (flag.equals("5")) {
                path = "./images/" + themePrefix + "flag_flash_icon_h.png";
            } else if (flag.equals("6")) {
                path = "./images/" + themePrefix + "flag_live.png";
            } else if (flag.equals("7")) {
                path = "./images/" + themePrefix + "flag_redian.png";
            } else {
                path = "";
            }
        }
        return path;
    }

    public boolean isDestroy() {
        return this.isDestroy;
    }

    public String getProgId() {
        return this.mProgid;
    }

    public String getPlayMode() {
        return this.mPlayMode;
    }

    public String getPlayUrl() {
        return this.mPlayUrl;
    }

    public int getStyleMode() {
        return this.mStyleMode;
    }

    @Override
    public void destroy() {
        // TODO Auto-generated method stub
        isDestroy = false;
        super.destroy();
    }
}