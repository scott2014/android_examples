package com.tencent.news.ui;

import android.os.Bundle;

import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.model.pojo.ChannelList;
import com.tencent.news.system.Application;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.ChannelBarVideo;
import com.tencent.news.ui.view.NetTipsBar;
import com.tencent.news.ui.view.TitleBar;
import com.tencent.news.ui.view.ViewPagerEx;
import com.tencent.news.utils.InfoConfigUtil;
import com.tencent.omg.webdev.WebDev;

public class HomeVideoActivity extends AbsActivityGroup {

	@Override
	protected void setContainerView(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		setContentView(R.layout.home_video_layout);
		mChannelViewPager = (ViewPagerEx) findViewById(R.id.channel_view_pager);
		mTitleBar = (TitleBar) findViewById(R.id.channel_title_bar);
		mTitleBar.setTitleText(R.string.title_video);
		mChannelBar = (ChannelBarVideo) findViewById(R.id.channel_bar);
		mNetTipsBar = (NetTipsBar) findViewById(R.id.news_nettips_bar);
	}

	@Override
	protected Class<? extends Object> getChannelClassName(Object channel) {
		// TODO Auto-generated method stub
		return VideoActivity.class;
	}

	@Override
	protected void getChannelData() {
		// TODO Auto-generated method stub
		HttpDataRequest request = TencentNews.getInstance().getSubChannels(TencentNews.VIDEO);
		TaskManager.startHttpDataRequset(request, this);
	}

	@Override
	public void onRestoreInstanceState(Bundle savedInstanceState) {
		super.onRestoreInstanceState(savedInstanceState);
		setCurrentChannel(savedInstanceState.getInt(Constants.VIDEO_CURRENT_CHANNEL));
	}

	@Override
	public void onSaveInstanceState(Bundle savedInstanceState) {
		super.onSaveInstanceState(savedInstanceState);
		savedInstanceState.putInt(Constants.VIDEO_CURRENT_CHANNEL, nCurrChannel);
	}

	@Override
	public void onHttpRecvOK(HttpTag tag, Object result) {
		if (tag.equals(HttpTag.GET_SUB_CHANNELS)) {
			ChannelList channel = (ChannelList) result;
			Application.getInstance().setVideoChannelList(channel);
			InfoConfigUtil.WriteVideoSubChannel(channel);
			// mChannelBar.refresh();
		}
	}

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}
}
