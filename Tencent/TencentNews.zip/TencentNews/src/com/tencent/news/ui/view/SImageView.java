package com.tencent.news.ui.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.AttributeSet;
import android.widget.ImageView;

public class SImageView extends ImageView {

	protected Bitmap mRelatedBitmap;

	public SImageView(Context context) {
		super(context);
		// Auto-generated constructor stub
	}

	public SImageView(Context context, AttributeSet attrs) {
		super(context, attrs);
		// Auto-generated constructor stub
	}

	public SImageView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		// Auto-generated constructor stub
	}

	public Bitmap getRelatedBitmap() {
		return mRelatedBitmap;
	}

	@Override
	public void setImageBitmap(Bitmap bm) {
		// Auto-generated method stub
		this.mRelatedBitmap = bm;
		super.setImageBitmap(bm);
	}

	public void setDefaultBitmap(Bitmap bm) {
		if (getScaleType() != ScaleType.CENTER_INSIDE) {
			setScaleType(ScaleType.CENTER_INSIDE);
		}
		super.setImageBitmap(bm);
	}

	public void recycle() {
		super.setImageBitmap(null);
		if ((this.mRelatedBitmap != null) && (!this.mRelatedBitmap.isRecycled())) {
			this.mRelatedBitmap.recycle();
			this.mRelatedBitmap = null;
		}
	}
}
