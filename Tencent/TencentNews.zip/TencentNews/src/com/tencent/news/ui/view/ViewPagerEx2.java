package com.tencent.news.ui.view;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import com.tencent.news.utils.MobileUtil;

// 可嵌套的ViewPager
public class ViewPagerEx2 extends ViewPagerEx implements IViewPagerSubViewStatus {
	private final int MOVE_TRIGGER = 6;
	private int moveTrigger = MOVE_TRIGGER;
	
	private float downX = 0;
	private float downY = 0;
	private float lastMoveX = 0;
//	private float lastMoveY = 0;
	private int touchDownItemIndex = 0;
	private boolean isSecondPointerDown = false;
	private boolean isSubViewHandledEvent = false;
	private boolean directionChanged = false;
//	private boolean isInterceptTouch = false;
	
	private boolean needCheckDirection = false;
	private boolean directionChecked = false;
	
	private boolean blockOverMoveRightEvent = false;
	private boolean blockOverMoveLeftEvent = false;

	private boolean mDiscardAllMotionEvent = false;
	
	private int mIndexInParent = IViewPagerSubViewStatus.NO_PARENT;

	// 手势刚开始的方向
	private static final int NONE = 0;
	private static final int RIGHT = 1;
	private static final int LEFT = 2;
	private int mMotionStartDiection = NONE;

	// 如果子view是动态变化的，只能靠设置mCurrentView来判断当前显示的view
	private IViewPagerSubViewStatus mCurrentView = null;
	public ArrayList<IViewPagerSubViewStatus> mSubViewList = new ArrayList<IViewPagerSubViewStatus>();
	
	public interface OverScrollListener {
		void onOverScrollToLeft();
		void onOverScrollToRight();
	}

	private OverScrollListener mOverScrollListener = null;

	public ViewPagerEx2(Context context) {
		super(context);
	}
	
	public ViewPagerEx2(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public void setOverScrollListener(OverScrollListener listener){
		this.mOverScrollListener = listener;
	}

	public void addSubView(IViewPagerSubViewStatus subView, int index) {
		if (subView instanceof View) {
			subView.setIndexInParent(index);
			mSubViewList.add(subView);
		}
	}
	
	private IViewPagerSubViewStatus findTouchedSubView() {
		IViewPagerSubViewStatus subView = mCurrentView;
		if (subView == null) {
			for (int i = 0; i < mSubViewList.size(); i++) {
				IViewPagerSubViewStatus view = mSubViewList.get(i);
				int index = view.getIndexInParent();
				if (index == -1 || index == touchDownItemIndex) {
					subView = view;
					break;
				}
			}
		}
		return subView;
	}

    @Override
	public boolean onInterceptTouchEvent(MotionEvent event) {
    	if (event.getActionMasked() == MotionEvent.ACTION_POINTER_DOWN) {
    		isSecondPointerDown = true;
    	}
    	if (isSecondPointerDown || isSubViewHandledEvent) {
    		return false;
    	}
    	
    	int action = event.getAction();
    	if (action == MotionEvent.ACTION_MOVE) {
	    	float x = event.getX();
	    	if (Math.abs(x - lastMoveX) <= moveTrigger) {
	    		return false;
	    	}
	    	
    		IViewPagerSubViewStatus subView = findTouchedSubView();
    		if (subView != null) {
	    		if (x - lastMoveX > moveTrigger) {
	    			// mouse moving right
	    			if (subView.handleMotionRight(event)) {
	    				isSubViewHandledEvent = true;
	    				return false;
	    			} else if (this.handleMotionRight(event)) {
//	    				isInterceptTouch = true;
	    				return true;
	    			}
	    		} else if (x - lastMoveX < -moveTrigger) {
	    			// mouse moving left
	    			if (subView.handleMotionLeft(event)) {
	    				isSubViewHandledEvent = true;
	    				return false;
	    			} else if (this.handleMotionLeft(event)) {
//	    				isInterceptTouch = true;
	    				return true;
	    			}
	    		}
    		}
    	}
    	
    	boolean ret = super.onInterceptTouchEvent(event);
//    	isInterceptTouch = ret;
    	return ret;
	}
    
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
    	int action = ev.getAction();
    	if (action == MotionEvent.ACTION_DOWN) {
    		mScroller.abortAnimation();
    		mMotionStartDiection = NONE;
    		isSecondPointerDown = false;
    		isSubViewHandledEvent = false;
    		directionChanged = false;
//    		isInterceptTouch = false;
    		needCheckDirection = false;
    		directionChecked = false;
    		touchDownItemIndex = this.getCurrentItem();
    		downX = ev.getX();
    		downY = ev.getY();
    		lastMoveX = downX;
//    		lastMoveY = downY;
    	}

    	return super.dispatchTouchEvent(ev);
    }

	@Override
	public boolean onTouchEvent(MotionEvent event) {
    	int action = event.getAction();

    	if (action == MotionEvent.ACTION_UP) {
    		moveTrigger = MOVE_TRIGGER;
    	}

		IViewPagerSubViewStatus subView = findTouchedSubView();
    	if (action == MotionEvent.ACTION_MOVE) {
    		float x = event.getX();
	    	if (Math.abs(x - lastMoveX) <= moveTrigger) {
	    		return false;
	    	}
	    	moveTrigger = 0;
    		if (subView != null && !directionChanged) {
	    		if (x - lastMoveX > moveTrigger) {
	    			// mouse moving right
	    			if (x - lastMoveX > MOVE_TRIGGER && needCheckDirection(subView)) {
		    			if (mMotionStartDiection == NONE) {
		    				mMotionStartDiection = RIGHT;
		    			}
		    			directionChanged = mMotionStartDiection != RIGHT;
	    			}
//	    			if (!isInterceptTouch && subView.handleMotionRight(event)) {
//	    				boolean handled = ((View)subView).onTouchEvent(event);
//	    				isSubViewHandledEvent = isSubViewHandledEvent || handled;
//		    			saveLastMotionEvent(event);
//	    				return handled;
//	    			}
	    		} else if (x - lastMoveX < -moveTrigger) {
	    			// mouse moving left
	    			if (x - lastMoveX < -MOVE_TRIGGER && needCheckDirection(subView)) {
		    			if (mMotionStartDiection == NONE) {
		    				mMotionStartDiection = LEFT;
		    			}
		    			directionChanged = mMotionStartDiection != LEFT;
	    			}
//	    			if (!isInterceptTouch && subView.handleMotionLeft(event)) {
//	    				boolean handled = ((View)subView).onTouchEvent(event);
//	    				isSubViewHandledEvent = isSubViewHandledEvent || handled;
//		    			saveLastMotionEvent(event);
//	    				return handled;
//	    			}
	    		}
    		}
    		if (isSubViewHandledEvent || directionChanged) {
    			saveLastMotionEvent(event);
    			return true;
    		}
    	}
    	
    	boolean ret = true;
    	try {
			if (action == MotionEvent.ACTION_UP ) {
				if (!isSubViewHandledEvent && !directionChanged) {
					checkOverScroll(event);
				} else if (directionChanged) {
					final long now = SystemClock.uptimeMillis();
					event = MotionEvent.obtain(now, now,
							MotionEvent.ACTION_CANCEL, 0.0f, 0.0f, 0);
					ret = super.onTouchEvent(event);
					event.recycle();
					return ret;
				}
			}

//			if (checkBlockMotionEvemt(event)) {
//				return true;
//			}
		
	    	if (!mDiscardAllMotionEvent) {
	    		saveLastMotionEvent(event);
	    		ret = super.onTouchEvent(event);
	    	}
    	} catch(Exception e) {}
    	return ret;
    }
    
    private void checkOverScroll(MotionEvent ev) {
		if (mIndexInParent == IViewPagerSubViewStatus.NO_PARENT) {
			float upX = ev.getX();
			float upY = ev.getY();
			boolean moveHorizontal = Math.abs(upX - downX) > MobileUtil.dpToPx(100) && Math.abs(upX - downX) > Math.abs(upY - downY);

			if (upX > downX && moveHorizontal) {
				// mouse moving right
				if (touchDownItemIndex == 0) {
					IViewPagerSubViewStatus subView = findTouchedSubView();
					if (subView == null || !subView.handleMotionRight(ev)) {
						if (mOverScrollListener != null) {
							mOverScrollListener.onOverScrollToLeft();
						}
					}
				}
			} else if (upX < downX && moveHorizontal) {
				// mouse moving left
				if (touchDownItemIndex == this.getAdapter().getCount() - 1) {
					IViewPagerSubViewStatus subView = findTouchedSubView();
					if (subView == null || !subView.handleMotionLeft(ev)) {
						if (mOverScrollListener != null) {
							mOverScrollListener.onOverScrollToRight();
						}
					}
				}
			}
		}
    }

    private boolean checkBlockMotionEvemt(MotionEvent event) {
    	boolean handled = false;
    	int action = event.getAction();
    	if (action == MotionEvent.ACTION_MOVE && (blockOverMoveRightEvent || blockOverMoveLeftEvent)) {
    		float x = event.getX();
    		if (x - lastMoveX > moveTrigger && blockOverMoveRightEvent && this.getCurrentItem() == 0) {
    			// mouse moving right
    			saveLastMotionEvent(event);
    			handled = true;
    		} else if (x - lastMoveX < -moveTrigger && blockOverMoveLeftEvent && this.getCurrentItem() == this.getAdapter().getCount() - 1) {
    			// mouse moving left
    			saveLastMotionEvent(event);
    			handled = true;
    		}
    	}
    	return handled;
    }
	
    @Override
    public void setIndexInParent(int index) {
    	mIndexInParent = index;
    }

	@Override
	public int getIndexInParent() {
		return mIndexInParent;
	}

	@Override
	public boolean handleMotionLeft(MotionEvent event) {
		if (mIndexInParent == IViewPagerSubViewStatus.NO_PARENT) {
			return true;
		}
		boolean handle = !(touchDownItemIndex == this.getAdapter().getCount() - 1);
		if (!handle) {
    		IViewPagerSubViewStatus subView = findTouchedSubView();
    		if (subView != null) {
    			handle = subView.handleMotionLeft(event);
    		}
		}
		return handle;
	}

	@Override
	public boolean handleMotionRight(MotionEvent event) {
		if (mIndexInParent == IViewPagerSubViewStatus.NO_PARENT) {
			return true;
		}
		boolean handle = !(touchDownItemIndex == 0);
		if (!handle) {
    		IViewPagerSubViewStatus subView = findTouchedSubView();
    		if (subView != null) {
    			handle = subView.handleMotionRight(event);
    		}
		}
		return handle;
	}

	@Override
	public void setCurrentView(IViewPagerSubViewStatus currentView) {
		mCurrentView = currentView;
	}

	@Override
	public IViewPagerSubViewStatus getCurrentView() {
		return mCurrentView;
	}
	
	public Bitmap getCurrentBitmap() {
		if (mCurrentView != null && mCurrentView instanceof TouchImageView) {
			return ((TouchImageView) mCurrentView).getImageBitmap();
		}
		return null;
	}

	public void setBlockOverMoveRightEvent(boolean blockOverMoveRightEvent) {
		this.blockOverMoveRightEvent = blockOverMoveRightEvent;
	}

	public void setBlockOverMoveLeftEvent(boolean blockOverMoveLeftEvent) {
		this.blockOverMoveLeftEvent = blockOverMoveLeftEvent;
	}
	
	public void setDiscardAllMotionEvent(boolean discardAllMotionEvent) {
		this.mDiscardAllMotionEvent = discardAllMotionEvent;
	}
	
	private boolean needCheckDirection(IViewPagerSubViewStatus subView) {
		// 只有第一页需要检查滑动方向的变化。因为第一页要判断向右滑动后退出
		if (!directionChecked && subView != null) {
			int index = subView.getIndexInParent();
			if (index == 0 || (index > 0 && index == this.getAdapter().getCount() - 1)) {
				if (subView instanceof ViewPagerEx2) {
					// 现在需求不论手势方向，只需要判断第一个（屏蔽退出的手势），
					needCheckDirection = ((ViewPagerEx2)subView).getCurrentItem() == 0;
				}
			}
			directionChecked = true;
		}
		return needCheckDirection;
	}

	private void saveLastMotionEvent(MotionEvent ev) {
		IViewPagerSubViewStatus subView = findTouchedSubView();
		if (needCheckDirection(subView)) {
				lastMoveX = ev.getX();
//				lastMoveY = ev.getY();
		}
	}
}
