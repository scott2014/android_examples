package com.tencent.news.ui.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.tencent.news.R;

public class LoadingView extends FrameLayout {
	Context mContext=null;
	ImageView mLodingViewRotate=null;
	Animation mRotateAnimation=null;

	public LoadingView(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		init(context);
	}

	public LoadingView(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		init(context);
	}

	public LoadingView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		// TODO Auto-generated constructor stub
		init(context);
	}
	
	private void init(Context context){
		mContext=context;
		initView();
		initAnimation();
	}
	
	private void initView(){
		LayoutInflater.from(mContext).inflate(R.layout.loading_view, this, true);
		mLodingViewRotate=(ImageView)findViewById(R.id.loading_view_rotate);
	}
	
	private void initAnimation(){
		mRotateAnimation=AnimationUtils.loadAnimation(mContext, R.anim.loading_animation);
		loadingStartAnimation();
	}
	
	public void loadingStartAnimation(){
		mLodingViewRotate.startAnimation(mRotateAnimation);
	}
	
	public void loadingClearAnimation(){
		mLodingViewRotate.clearAnimation();
	}

}
