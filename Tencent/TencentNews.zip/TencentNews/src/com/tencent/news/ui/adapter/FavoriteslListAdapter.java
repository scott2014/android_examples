
package com.tencent.news.ui.adapter;

import android.R.integer;
import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.command.GetImageRequest;
import com.tencent.news.command.GetImageResponse;
import com.tencent.news.config.Constants;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.model.pojo.ImageResult;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.PullRefreshListView;
import com.tencent.news.utils.DefaulImageUtil;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.StringUtil;

import java.util.ArrayList;
import java.util.List;

@SuppressLint("UseSparseArrays")
public class FavoriteslListAdapter extends AbsListAdapter<Item> implements GetImageResponse {

    protected int itemType;
    private final int FROM_LOCAL = 0; // 从本地缓存取图
    private final int FROM_REMOTE = 1; // 从网络取图
    private final int SHOW_CHECK_BOX_ANIM = 1;
    private final int HIDE_CHECK_BOX_ANIM = 2;
    private List<Boolean> isSelected;
    private boolean isShowCheckBox = false;
    private int top;
    private int sceenWidth;
    private int showType;
    private static String TAG = "FavoriteslListAdapter";

    public FavoriteslListAdapter(Context context, ListView listView) {
        this.mContext = context;
        this.mListView = listView;
        mDataList = new ArrayList<Item>();
        isSelected = new ArrayList<Boolean>();
        sceenWidth = MobileUtil.getScreenWidthIntPx();
        ((PullRefreshListView) mListView).setSartListener(this);
        SettingInfo settingInfo = SettingObservable.getInstance().getData();
        if (settingInfo != null && settingInfo.isIfTextMode()) {
            itemType = Constants.TYPE_ITEM_TEXT;
        } else {
            itemType = Constants.TYPE_ITEM_IMAGE;
        }
    }

    @Override
    public int getItemViewType(int position) {
        Item item = mDataList.get(position);
        if (itemType == Constants.TYPE_ITEM_IMAGE && item != null && item.getArticletype() != null
                && item.getArticletype().trim().equals("1")) {
            styleType = Constants.TYPE_ITEM_THREE_PHOTO;
        } else {
            styleType = itemType;
        }
        return styleType;
    }

    @Override
    public void changeStyleMode(int style) {
        // TODO Auto-generated method stub
        this.itemType = style;
        notifyDataSetChanged();
    }

    @Override
    public int getViewTypeCount() {
        // Auto-generated method stub
        return 3;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        int type = getItemViewType(position);
        SLog.i(TAG, "文章类型" + String.valueOf(type));
        switch (type) {
            case Constants.TYPE_ITEM_TEXT:
                convertView = setTextMode(convertView, position, holder);
                break;
            case Constants.TYPE_ITEM_IMAGE:
                convertView = setImageMode(convertView, position, holder, parent);
                break;
            case Constants.TYPE_ITEM_THREE_PHOTO:
                convertView = setMoreImageMode(convertView, position, holder);
                break;
            default:
                break;
        }
        return convertView;
    }

    private String formatSource(String Source) {

        int s = Integer.parseInt(Source);
        String res = "腾讯新闻";
        switch (s) {
            case 0:
                res = "腾讯新闻";
                break;
            case 1:
                res = "QQ浏览器";
            case 2:
                res = "微云";

            default:
                break;
        }
        return res;
    }

    public void setIfChecked(View convertView, ImageView checkIcon, int position) {
        if (themeSettingsHelper.isNightTheme()) {
            if (isSelected.get(position)) {
                convertView.setBackgroundColor(mContext.getResources().getColor(R.color.night_checked));
                checkIcon.setImageResource(R.drawable.collection_checked);
            } else {
                convertView.setBackgroundColor(mContext.getResources().getColor(R.color.night_view_bg_color));
                checkIcon.setImageResource(R.drawable.night_collection_check_box);
            }
        } else {
            if (isSelected.get(position)) {
                convertView.setBackgroundColor(mContext.getResources().getColor(R.color.checked));
                checkIcon.setImageResource(R.drawable.collection_checked);

            } else {
                convertView.setBackgroundColor(mContext.getResources().getColor(R.color.view_bg_color));
                checkIcon.setImageResource(R.drawable.collection_check_box);
            }
        }
    }

    public void showCheckBox(View convertView, ViewHolder holder, int position, ViewGroup parent) {
        if (isShowCheckBox) {
            holder.fill_place.setVisibility(View.VISIBLE);
            setIfChecked(convertView, holder.fill_place, position);
        }else {
            holder.fill_place.setVisibility(View.GONE);
          convertView.setBackgroundColor(mContext.getResources().getColor(R.color.transparent));
        }

//        if (showType == SHOW_CHECK_BOX_ANIM) {
//            if (isShowCheckBox) {
//                setIfChecked(convertView, holder.checkIcon, position);
//                SLog.d(TAG, " SHOW_CHECK_BOX_ANIM top:" + holder.fill_place.getTop());
//                RelativeLayout.LayoutParams llp = (RelativeLayout.LayoutParams) holder.checkIcon.getLayoutParams();
//                llp.setMargins(sceenWidth - MobileUtil.dpToPx(60), holder.fill_place.getTop(), 0, 0);
//                holder.checkIcon.setLayoutParams(llp);
//                holder.checkIcon.requestLayout();
//                holder.fill_place.setVisibility(View.VISIBLE);
//
//            } else {
//                setIfChecked(convertView, holder.checkIcon, position);
//                convertView.setBackgroundColor(mContext.getResources().getColor(R.color.transparent));
//                SLog.d(TAG, " top:" + this.top);
//                RelativeLayout.LayoutParams llp = (RelativeLayout.LayoutParams) holder.checkIcon.getLayoutParams();
//                llp.setMargins(sceenWidth, holder.fill_place.getTop(), 0, 0);
//                holder.checkIcon.setLayoutParams(llp);
//                holder.checkIcon.requestLayout();
//                holder.fill_place.setVisibility(View.GONE);
//            }
//        } else if (showType == SHOW_CHECK_BOX_ANIM) {
//
//        } else {
//            if (isShowCheckBox) {
//                holder.fill_place.setVisibility(View.VISIBLE);
//            }else {
//                setIfChecked(convertView, holder.checkIcon, position);
//                convertView.setBackgroundColor(mContext.getResources().getColor(R.color.transparent));
//                SLog.d(TAG, " top:" + this.top);
//                RelativeLayout.LayoutParams llp = (RelativeLayout.LayoutParams) holder.checkIcon.getLayoutParams();
//                llp.setMargins(sceenWidth, holder.fill_place.getTop(), 0, 0);
//                holder.checkIcon.setLayoutParams(llp);
//                holder.checkIcon.requestLayout();
//                holder.fill_place.setVisibility(View.GONE);
//            }
//        }

    }

    private View setMoreImageMode(View convertView, int position, ViewHolder holder) {

        if (convertView == null) {
            holder = new ViewHolder();
            convertView = LayoutInflater.from(mContext).inflate(R.layout.favorites_list_item_photos, null);
            holder.sourceImage = (ImageView) convertView.findViewById(R.id.list_item_source_img);
            holder.sourceTitle = (TextView) convertView.findViewById(R.id.list_item_source_text);
            holder.itemTitle = (TextView) convertView.findViewById(R.id.list_title_text);
            holder.time = (TextView) convertView.findViewById(R.id.list_item_time);
            holder.imageLeft = (ImageView) convertView.findViewById(R.id.left_image);
            holder.imageMid = (ImageView) convertView.findViewById(R.id.mid_image);
            holder.imageRight = (ImageView) convertView.findViewById(R.id.right_image);
            holder.fill_place = (ImageView) convertView.findViewById(R.id.fill_place);
            holder.checkIcon = (ImageView) convertView.findViewById(R.id.check_icon);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        showCheckBox(convertView, holder, position, null);
        holder.positon = position;
        applyThemeInItem(holder);

        Item item = mDataList.get(position);
        if (item == null || item.getId() == null) {
            return convertView;
        }
        holder.id = item.getId();
        holder.articletype = item.getArticletype();
        setTextData(item, holder);

        if (!((PullRefreshListView) mListView).isBusy()) {
            setThreeSmallImage(item, holder, FROM_REMOTE);
            setSourceImage(item, holder, FROM_REMOTE);
        } else {
            setThreeSmallImage(item, holder, FROM_LOCAL);
            setSourceImage(item, holder, FROM_LOCAL);
        }
        return convertView;
    }

    private View setImageMode(View convertView, int position, ViewHolder holder, ViewGroup parent) {
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = LayoutInflater.from(mContext).inflate(R.layout.favorites_list_item, null);
            holder.sourceImage = (ImageView) convertView.findViewById(R.id.list_item_source_img);
            holder.sourceTitle = (TextView) convertView.findViewById(R.id.list_item_source_text);
            holder.itemTitle = (TextView) convertView.findViewById(R.id.list_title_text);
            holder.time = (TextView) convertView.findViewById(R.id.list_item_time);
            holder.itemImage = (ImageView) convertView.findViewById(R.id.list_item_image);
            holder.fill_place = (ImageView) convertView.findViewById(R.id.fill_place);
            holder.checkIcon = (ImageView) convertView.findViewById(R.id.check_icon);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        showCheckBox(convertView, holder, position, parent);
        holder.positon = position;
        applyThemeInItem(holder);

        Item item = mDataList.get(position);
        if (item == null || item.getId() == null) {
            return convertView;
        }
        holder.id = item.getId();
        holder.articletype = item.getArticletype();
        setTextData(item, holder);

        if (!((PullRefreshListView) mListView).isBusy()) {
            setSingleImage(item, holder, FROM_REMOTE);
            setSourceImage(item, holder, FROM_REMOTE);
        } else {
            setSingleImage(item, holder, FROM_LOCAL);
            setSourceImage(item, holder, FROM_LOCAL);
        }

        return convertView;
    }

    private View setTextMode(View convertView, int position, ViewHolder holder) {
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = LayoutInflater.from(mContext).inflate(R.layout.favorites_list_text_item, null);
            holder.sourceImage = (ImageView) convertView.findViewById(R.id.list_item_source_img);
            holder.sourceTitle = (TextView) convertView.findViewById(R.id.list_item_source_text);
            holder.itemTitle = (TextView) convertView.findViewById(R.id.list_title_text);
            holder.time = (TextView) convertView.findViewById(R.id.list_item_time);
            holder.fill_place = (ImageView) convertView.findViewById(R.id.fill_place);
            holder.checkIcon = (ImageView) convertView.findViewById(R.id.check_icon);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        showCheckBox(convertView, holder, position, null);
        holder.positon = position;
        applyThemeInItem(holder);

        Item item = mDataList.get(position);
        if (item != null && item.getId() != null) {
            holder.id = item.getId();
            if (themeSettingsHelper.isNightTheme()) {
                holder.sourceTitle.setTextColor(mContext.getResources().getColor(R.color.night_list_title_color));
            } else {
                holder.sourceTitle.setTextColor(mContext.getResources().getColor(R.color.list_title_color));
            }
            if (item.getChlname() != null && !"".equals(item.getChlname())) {
                holder.sourceTitle.setText(item.getChlname());
            } else {
                if (item.getFavorSource() != null) {
                    holder.sourceTitle.setText(formatSource(item.getFavorSource()));
                }
            }
            if (holder.itemTitle != null) {
                holder.itemTitle.setText(item.getTitle());
            }
            if (holder.time != null) {
                holder.time.setText(StringUtil.getFavoritesTime((Long.parseLong(item.getFavorTimestamp()) * 1000)));
            }
        }
        if (!((PullRefreshListView) mListView).isBusy()) {
            setSourceImage(item, holder, FROM_REMOTE);
        } else {
            setSourceImage(item, holder, FROM_LOCAL);
        }
        return convertView;
    }

    public static class ViewHolder {
        public TextView sourceTitle;
        String id;
        int positon;
        String articletype;
        public TextView itemTitle;
        TextView time;
        ImageView sourceImage;
        ImageView itemImage;
        ImageView imageLeft; // 列表页三个小图中最左边的一个
        ImageView imageMid; // 列表页三个小图中中间的一个
        ImageView imageRight; // 列表页三个小图中最右边的一个
        public ImageView checkIcon;
        public ImageView fill_place;
    }

    protected static class Tag {
        String id; // 与ViewHolder中的id对应
        int position; // 如果是一张图position=0，如果是三张小图position=1，2，3分别表示左中右,收藏来源图position=4
    }

    @Override
    public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm, String path) {
        // TODO Auto-generated method stub
        Tag mTag = (Tag) tag;
        switch (imageType) {
            case SMALL_IMAGE:
                int countImage = mListView.getChildCount();
                for (int i = 0; i < countImage; i++) {
                    ViewHolder holder = (ViewHolder) mListView.getChildAt(i).getTag();
                    if (holder != null) {
                        if (((String) mTag.id).equals(holder.id)) {
                            switch (mTag.position) {
                                case 0:
                                    if (bm != null) {
                                        holder.itemImage.setImageBitmap(bm);
                                    }
                                    break;
                                case 1:
                                    setSmallImage(holder.imageLeft, bm);
                                    break;
                                case 2:
                                    setSmallImage(holder.imageMid, bm);
                                    break;
                                case 3:
                                    setSmallImage(holder.imageRight, bm);
                                    break;
                                case 4:
                                    if (bm != null) {
                                        holder.sourceImage.setImageBitmap(bm);
                                    }
                                    break;
                                default:
                                    break;
                            }
                            break;
                        }
                    }
                }
                break;
            default:
                break;
        }
    }

    @Override
    public void onImageRecvError(ImageType imageType, Object tag, int retCode) {
        // TODO Auto-generated method stub

    }

    protected void setTextData(Item item, ViewHolder holder) {
        if (item == null || holder == null || item.getId() == null) {
            return;
        }
        if (themeSettingsHelper.isNightTheme()) {
            holder.sourceTitle.setTextColor(mContext.getResources().getColor(R.color.night_list_title_color));
        } else {
            holder.sourceTitle.setTextColor(mContext.getResources().getColor(R.color.list_title_color));
        }
        if (item.getChlname() != null && !"".equals(item.getChlname())) {
            holder.sourceTitle.setText(item.getChlname());
        } else {
            if (item.getFavorSource() != null) {
                holder.sourceTitle.setText(formatSource(item.getFavorSource()));
            }
        }

        if (holder.itemTitle != null) {
            holder.itemTitle.setText(item.getTitle());
        }
        if (holder.time != null) {
            holder.time.setText(StringUtil.getFavoritesTime((Long.parseLong(item.getFavorTimestamp()) * 1000)));
        }
    }

    @Override
    public void serListViewBusy(int currPosition, int tag) {
        // TODO Auto-generated method stub
        if (itemType == Constants.TYPE_ITEM_TEXT) {
            return;
        }
        if (currPosition >= 0 && currPosition < mDataList.size()) {
            Item item = mDataList.get(currPosition);
            ViewHolder holder = (ViewHolder) mListView.getChildAt(tag).getTag();
            setSourceImage(item, holder, FROM_REMOTE);
            if (item != null && item.getArticletype() != null && item.getArticletype().trim().equals("1")) {
                setThreeSmallImage(item, holder, FROM_REMOTE);
            } else {
                setSingleImage(item, holder, FROM_REMOTE);
            }
        }
    }

    // 夜间模式的处理
    public void applyThemeInItem(ViewHolder holder) {
        if (holder == null) {
            return;
        }
        if (themeSettingsHelper.isNightTheme()) {// 设置夜间模式图标和字体颜色
            if (holder.sourceTitle != null) {
                holder.sourceTitle.setTextColor(mContext.getResources().getColor(R.color.night_list_title_color));
            }
            if (holder.itemTitle != null) {
                holder.itemTitle.setTextColor(mContext.getResources().getColor(R.color.night_list_abstract_color));
            }
            if (holder.time != null) {
                holder.time.setTextColor(mContext.getResources().getColor(R.color.night_list_comment_color));
            }
        } else {
            if (holder.sourceTitle != null) {
                holder.sourceTitle.setTextColor(mContext.getResources().getColor(R.color.list_title_color));
            }
            if (holder.itemTitle != null) {
                holder.itemTitle.setTextColor(mContext.getResources().getColor(R.color.list_abstract_color));
            }
            if (holder.time != null) {
                holder.time.setTextColor(mContext.getResources().getColor(R.color.list_comment_color));
            }
        }
    }

    private void setSingleImage(Item item, ViewHolder holder, int from) {

        if (item == null || holder == null || holder.id == null) {
            return;
        }

        String url = "";
        Bitmap bitmap = null;
        Tag tag = new Tag();
        tag.id = holder.id;
        tag.position = 0;
        // url = (item.getThumbnails_qqnews_photo() != null &&
        // item.getThumbnails_qqnews_photo().length>0)?item.getThumbnails_qqnews_photo()[0]:"";
        url = (item.getThumbnails_qqnews() != null && item.getThumbnails_qqnews().length > 0) ? item
                .getThumbnails_qqnews()[0] : "";
        // url = "CELLFIN201305220000";

        if (!"".equals(url)) {
            holder.itemImage.setVisibility(View.VISIBLE);
            bitmap = getBitMapImage(item, tag, Constants.TYPE_ITEM_IMAGE, url, from);
            if (bitmap != null && holder.itemImage != null) {
                holder.itemImage.setImageBitmap(bitmap);
            }
        } else {
            holder.itemImage.setVisibility(View.GONE);
        }

    }

    private void setSourceImage(Item item, ViewHolder holder, int from) {

        if (item == null || holder == null || holder.id == null) {
            return;
        }

        if (item.getChlname() != null && !"".equals(item.getChlname())) {
            if (item.getChlsicon() != null && !"".equals(item.getChlsicon())) {

                String url = item.getChlsicon();
                Tag tag = new Tag();
                tag.id = holder.id;
                tag.position = 4;
                Bitmap bitmap;
                bitmap = getBitMapImage(item, tag, Constants.TYPE_ITEM_IMAGE, url, from);
                if (bitmap != null && holder.sourceImage != null) {
                    holder.sourceImage.setImageBitmap(bitmap);
                }
            }
        } else {
            holder.sourceImage.setImageResource(R.drawable.collection_news_logo);
        }

    }

    private void setThreeSmallImage(Item item, ViewHolder holder, int from) {
        String url = "";
        Bitmap smallBitmapArr[] = new Bitmap[3];
        int mType = Constants.TYPE_ITEM_THREE_PHOTO;
        if (holder != null && holder.id != null && item != null && item.getThumbnails_qqnews() != null
                && item.getThumbnails_qqnews().length > 0) {
            int size = item.getThumbnails_qqnews().length > 4 ? 4 : item.getThumbnails_qqnews().length;
            for (int i = 1; i < size; i++) {
                Tag tag = new Tag();
                tag.id = holder.id;
                tag.position = i;
                url = (item.getThumbnails_qqnews()[i] != null && item.getThumbnails_qqnews()[i].length() > 0) ? item
                        .getThumbnails_qqnews()[i] : "";
                smallBitmapArr[i - 1] = getBitMapImage(item, tag, mType, url, from);
            }
            setSmallImage(holder.imageLeft, smallBitmapArr[0]);
            setSmallImage(holder.imageMid, smallBitmapArr[1]);
            setSmallImage(holder.imageRight, smallBitmapArr[2]);
        }
    }

    protected Bitmap getBitMapImage(Item item, Tag tag, int type, String url, int from) {

        if (url == null || url == "") {
            return getDefaultBitmap(type);
        }

        Bitmap retBitmap = null;
        ImageResult result = null;
        GetImageRequest request = new GetImageRequest();

        request.setGzip(false);
        request.setTag(tag);
        request.setUrl(url);
        if (from == FROM_REMOTE) {
            result = TaskManager.startSmallImageTask(request, this);
        } else {
            result = TaskManager.getLocalIconImage(request, this);
        }

        if (result.isResultOK() && result.getRetBitmap() != null) {
            retBitmap = result.getRetBitmap();
        } else {
            retBitmap = getDefaultBitmap(type);
        }
        return retBitmap;
    }

    protected Bitmap getDefaultBitmap(int type) {
        Bitmap retBitmap = null;
        if (type == Constants.TYPE_ITEM_THREE_PHOTO) {
            if (themeSettingsHelper.isNightTheme()) {
                retBitmap = DefaulImageUtil.getNightDefaultPhotoListImage();
            } else {
                retBitmap = DefaulImageUtil.getDefaultPhotoListImage();
            }
        } else {
            if (themeSettingsHelper.isNightTheme()) {
                retBitmap = DefaulImageUtil.getNightDefaultTimelineImage();
            } else {
                retBitmap = DefaulImageUtil.getDefaultTimelineImage();
            }
        }
        return retBitmap;
    }

    private void setSmallImage(ImageView srcImage, Bitmap bm) {

        if (bm == null || srcImage == null) {
            return;
        }

        int desImageViewWidth = 0;
        int desImageViewHeight = 0;
        int totalWidth = 0;
        if (isShowCheckBox) {

            totalWidth = MobileUtil.getScreenWidthIntPx() - MobileUtil.dpToPx(7 * 2 + 18 + 30 + 12 + 30 + 10);
            desImageViewWidth = totalWidth / 3;
            desImageViewHeight = srcImage.getHeight();
            srcImage.setScaleType(ScaleType.CENTER_CROP);
        } else {
            totalWidth = MobileUtil.getScreenWidthIntPx() - MobileUtil.dpToPx(7 * 2 + 18 + 30 + 12);
            desImageViewWidth = totalWidth / 3;
            desImageViewHeight = (int) (desImageViewWidth * 0.7);
            srcImage.setScaleType(ScaleType.FIT_XY);

        }
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) srcImage.getLayoutParams();
        lp.width = desImageViewWidth;
        lp.height = desImageViewHeight;
        srcImage.setLayoutParams(lp);
        srcImage.setImageBitmap(bm);
    }

    public boolean isShowCheckBox() {
        return isShowCheckBox;
    }

    public void setShowCheckBox(boolean isShowCheckBox) {
        this.isShowCheckBox = isShowCheckBox;
    }

    public void initSelectState() {
        isSelected.clear();
        for (int i = 0; i < mDataList.size(); i++) {
            isSelected.add(false);
        }
    }

    public List<Boolean> getIsSelected() {
        return isSelected;
    }

    public void setMarginTop(int top) {
        this.top = top;
    }

    public void setShowType(int showType) {
        this.showType = showType;

    }

    @Override
    public void addDataList(List<Item> list) {
        // TODO Auto-generated method stub
        super.addDataList(list);
        initSelectState();
    }

    @Override
    public void addMoreDataList(List<Item> list) {
        // TODO Auto-generated method stub
        super.addMoreDataList(list);
        for (int i = 0; i < list.size(); i++) {
            isSelected.add(false);
        }
    }

}
