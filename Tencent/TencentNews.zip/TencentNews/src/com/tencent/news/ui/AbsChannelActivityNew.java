package com.tencent.news.ui;

import java.util.ArrayList;
import java.util.List;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import com.tencent.news.R;
import com.tencent.news.cache.NewsItemCache;
import com.tencent.news.cache.NewsItemCache.QueryCacheCallback;
import com.tencent.news.command.GetImageRequest;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.model.pojo.ImageResult;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.system.NetStatusReceiver;
import com.tencent.news.system.NetTipsReceiver;
import com.tencent.news.system.NewsHadReadReceiver;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.system.observer.SettingObserver;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.adapter.ChannelListAdapter;
import com.tencent.news.ui.view.NetTipsBar;
import com.tencent.news.ui.view.PullImageHeadView;
import com.tencent.news.ui.view.PullRefreshListView;
import com.tencent.news.ui.view.WebViewForCell;
import com.tencent.news.ui.view.PullRefreshListView.OnClickFootViewListener;
import com.tencent.news.ui.view.PullRefreshListView.OnRefreshListener;
import com.tencent.news.ui.view.PullToRefreshFrameLayout;
import com.tencent.news.ui.view.TitleBar;
import com.tencent.news.ui.view.WebViewForCell.JS_FUNC;
import com.tencent.news.utils.DefaulImageUtil;
import com.tencent.news.utils.SLog;

public abstract class AbsChannelActivityNew extends BaseActivity implements SettingObserver {
	private final static String TAG = AbsChannelActivityNew.class.getSimpleName();

	protected PullToRefreshFrameLayout mFramelayout;
	protected PullRefreshListView mListView;
	protected ChannelListAdapter mAdapter;
	protected PullImageHeadView mHeadView;
	protected NetTipsBar mNetTipsBar;
	protected TitleBar mTitleBar;
	protected Item mHeadItem; // head item
	protected Item mCellItem;
	protected WebViewForCell mCellWebView;
	protected int nPage = -1;
	protected int nCount = 20;
	protected int nTotalPage = 10;
	protected NewsHadReadReceiver mReceiver;
	protected NetTipsReceiver mNetTipsReceiver;
	protected NewsItemCache mCache;
	protected boolean mIsCurrChannel = false;
	protected Boolean mIsStartChannel = false;
	protected Boolean mIsViewPager = false;
	protected String mChannel;
	protected boolean mIsStyleMode;
	private long mLastRefreshTime = 0;

	private QueryCacheCallback cacheCallback = new QueryCacheCallback() {
		
		@Override
		public void onStartQueryFromServer(HttpTag queryTag) {
			if (queryTag.equals(HttpTag.NEWS_NEWS_TOP)) {
			} else if (queryTag.equals(HttpTag.NEWS_LIST_ITEMS)) {
			}
		}
		
		@Override
		public void onQueryError(HttpTag queryTag) {
			if (queryTag.equals(HttpTag.NEWS_NEWS_TOP)) {
				if (mAdapter.getCount() > 0) {
					mFramelayout.showState(Constants.LIST);
					mListView.onRefreshComplete(false);
					mListView.setFootViewAddMore(false, true, true);
				} else {
					mFramelayout.showState(Constants.ERROR);
				}

			} else if (queryTag.equals(HttpTag.NEWS_LIST_ITEMS)) {
				mListView.setFootViewAddMore(true, true, true);
			}
		}
		
		@Override
		public void onQueryComplete(HttpTag queryTag, final List<Item> result) {
			if (queryTag.equals(HttpTag.NEWS_NEWS_TOP)) {
				mLastRefreshTime = java.lang.System.currentTimeMillis();
				
				if(result != null && result.size() > 0) {
					
					nTotalPage = result.size() / nCount;
					if (result.size() % nCount != 0) {
						nTotalPage++;
					}

					nPage = 0;
					List<Item> list = new ArrayList<Item>();

					int count = result.size() > nCount ? nCount : result.size();
					for (int i = 0; i < count; i++) {
						Item item = result.get(i);
						if (item != null && item.getTitle() != null) {
							list.add(item);
						}
					}

					setHeadData(list);
					getHeadData();

					handleCellItem(list);
					mAdapter.addDataList(list);
					mAdapter.notifyDataSetChanged();
					
					mListView.onRefreshComplete(true);
					mFramelayout.showState(Constants.LIST);
					mListView.setFootViewAddMore(true, true, false);
				}				
			} else if (queryTag.equals(HttpTag.NEWS_LIST_ITEMS)) {
				//如果是startChannel, 而且是加载Cache里第一页的item。成功后，刷新整个list。
				if (mIsStartChannel && nPage == -1) {
					getNewDataSilent(true);
				}
				
				if(result == null || result.size() == 0) {
					return;
				}
				
				if(mHeadItem == null) {
					setHeadData(result);
					getHeadData();
				}
				handleCellItem(result);
				
				(new Handler()).post(new Runnable() {
					@Override
					public void run() {						
						mAdapter.addMoreDataList(result);
						mFramelayout.showState(Constants.LIST);
						mListView.setFootViewAddMore(true, true, false);
						mAdapter.notifyDataSetChanged();
					}
				});
				
				nPage++;
			}
		}

		@Override
		public void onQueryingFromServer(HttpTag queryTag) {
			if (queryTag.equals(HttpTag.NEWS_NEWS_TOP)) {				
				mListView.onRefreshComplete(true);
			} else if (queryTag.equals(HttpTag.NEWS_LIST_ITEMS)) {
				mListView.setFootViewAddMore(false, true, true);
			}
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getIntentData(getIntent());
		InitContainerView(savedInstanceState);
		addHeadView();
		InitAdapter();
		InitListener();
		initListViewTag();
		initNetTips();
		registerBroadcastReceiver();
		registerNetTipsReceiver();
		SettingObservable.getInstance().registerObserver(this);
		mCache = new NewsItemCache(this, mChannel, cacheCallback);
		mCache.getCacheDataByPage(0);
		SLog.i(TAG, "onCreate() " + mChannel);
	}

	@Override
	protected void onStart() {
		super.onStart();
		SLog.i(TAG, "onStart() " + mChannel);
		if (mAdapter != null) {
			mAdapter.notifyDataSetChanged();
		}

//		statistics_read_channel_list_start = System.currentTimeMillis();
		TaskManager.cancelAllImageThread();
	}

	@Override
	protected void onPause() {
		super.onPause();
		TaskManager.cancelAllThread();
		if(mCellWebView != null) {
			mCellWebView.callJs(JS_FUNC.channelDidDisappear, null);
		}
		SLog.i(TAG, "onPause() " + mChannel);
	}

	@Override
	protected void onStop() {
//		statistics_read_channel_list_end = System.currentTimeMillis();
//		statistics_read_channel_list_total = statistics_read_channel_list_end - statistics_read_channel_list_start;
		SLog.i(TAG, "onStop() " + mChannel);
		super.onStop();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		SLog.i(TAG, "onDestroy() " + mChannel);

		if (mAdapter != null) {
			mAdapter.clearAdapterListData();
		}
		if (mListView != null && mHeadView != null) {
			mListView.removeHeaderView(mHeadView);
			mListView.setAdapter(null);
		}

		if (mReceiver != null) {
			try {
				unregisterReceiver(mReceiver);
			} catch (Exception e) {
				SLog.e(e.toString());
			}
		}

		if (mNetTipsReceiver != null) {
			try {
				unregisterReceiver(mNetTipsReceiver);
			} catch (Exception e) {
				SLog.e(e.toString());
			}
		}
		SettingObservable.getInstance().removeObserver(this);
	}

	private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if (msg != null && msg.obj != null) {
				Boolean isTips = (Boolean) msg.obj;
				setLayout(isTips.booleanValue());
			}
		}
	};

	protected void InitListener() {
		mListView.setOnRefreshListener(new OnRefreshListener() {
			@Override
			public void onRefresh() {
				getNewDataSilent(true);
				if(mCellWebView != null) {
					mCellWebView.callJs(JS_FUNC.channelDidRefreshData, null);
				}
			}

		});

		mListView.setOnClickFootViewListener(new OnClickFootViewListener() {
			@Override
			public void onClickFootView() {
				if(nPage + 1 >= nTotalPage) {
					mListView.setFootViewAddMore(true, false, false);
				} else { 					
					mCache.getCacheDataByPage(nPage + 1);
				}
			}
		});

		mListView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				startNextActivity(position);
			}

		});

		if (mHeadView != null) {
			mHeadView.setHeadClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					onClickListHead();
				}
			});
		}

		mFramelayout.setRetryButtonClickedListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				OnRetryData();
			}
		});
	}

	private void initNetTips() {
		if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_INAVAILABLE) {
			setLayout(false);
		} else {
			setLayout(true);
		}
	}

	protected void setLayout(boolean bFlag) {
		if (mNetTipsBar != null && !mIsViewPager) {
			if (bFlag) {
				mNetTipsBar.setVisibility(View.GONE);
			} else {
				mNetTipsBar.setVisibility(View.VISIBLE);
			}
		}
	}

	protected void initListViewTag() {
		mListView.setPullTimeTag(getListviewTimeTag());
		mFramelayout.showState(Constants.LOADING);
	}

	protected void startNextActivity(int position) {
		Intent intent = new Intent();
		intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		Log.i("Test", "--->" + "position--->" + position);

		int nClickPosition = position - mListView.getHeaderViewsCount();
		if (mAdapter != null && nClickPosition >= 0) {
			Item item = mAdapter.getObjectItem(nClickPosition);
			SLog.i("AbsChannelActivityNew", getClassName(item).toString());
			if (item != null && getClassName(item) != null) {
				Bundle bundle = new Bundle();
				bundle.putSerializable(Constants.NEWS_DETAIL_KEY, item);
				bundle.putString(Constants.NEWS_CHANNEL_CHLID_KEY, mChannel);
				bundle.putString(Constants.NEWS_DETAIL_TITLE_KEY, getChlidTitle());
				bundle.putString(Constants.NEWS_CLICK_ITEM_POSITION, "" + (nClickPosition + 1));
				intent.putExtras(bundle);
				intent.setClass(AbsChannelActivityNew.this, getClassName(item));
				startActivity(intent);
			}
		}
	}

	protected void onClickListHead() {
		Intent intent = new Intent();
		intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		Bundle bundle = new Bundle();
		bundle.putSerializable(Constants.NEWS_DETAIL_KEY, mHeadItem);
		bundle.putString(Constants.NEWS_CHANNEL_CHLID_KEY, mChannel);
		bundle.putString(Constants.NEWS_DETAIL_TITLE_KEY, getChlidTitle());
		bundle.putString(Constants.NEWS_CLICK_ITEM_POSITION, "0");
		intent.putExtras(bundle);
		intent.setClass(AbsChannelActivityNew.this, getClassName(mHeadItem));
		startActivity(intent);
	}

	protected void registerNetTipsReceiver() {
		if (isRegisterNetTips()) {
			IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
			mNetTipsReceiver = new NetTipsReceiver(mHandler);
			this.registerReceiver(mNetTipsReceiver, filter);
		}
	}

	protected void registerBroadcastReceiver() {
		mReceiver = new NewsHadReadReceiver(mChannel, mAdapter, mHeadView);
		IntentFilter filter = new IntentFilter(Constants.NEWS_HAD_READ_ACTION + mChannel);
		registerReceiver(mReceiver, filter);
	}

	protected void OnRetryData() {

		SLog.i("page", mChannel + " : OnRetryData()");

		mFramelayout.showState(Constants.LOADING);
		TaskManager.startRunnableRequestInPool(new Runnable() {
			@Override
			public void run() {
				getNewDataSilent(true);
			}
		});
	}

	/**
	 * 下拉刷新
	 */
	protected synchronized void getNewData() {
		mListView.startUpdateImmediate();
	}

	/**
	 * 刚进入界面时先从缓存读取,再刷新,此时需要后台去取网络,而不在UI上引起察觉
	 */
	protected synchronized void getNewDataSilent(boolean always) {
		if(always || (System.currentTimeMillis() - mLastRefreshTime > 600000)) {
			mCache.getLatestData();
		}
		if(mCellWebView != null) {
			mCellWebView.callJs(JS_FUNC.channelDidRefreshData, "");
		}
	}

	protected void getHeadData() {
		String url = null;
		if (mHeadView == null)
			return;
		if (mIsStyleMode) {
			mHeadView.setStyleMode(true);
			mHeadView.setTextMode(mHeadItem);

		} else {
			mHeadView.setStyleMode(false);
			if (mHeadItem != null) {
				if (mHeadItem.getThumbnails() != null && mHeadItem.getThumbnails().length > 0) {
					url = mHeadItem.getThumbnails()[0];
				} else {
					url = "";
				}
				mHeadView.setHeadTitle(mHeadItem.getTitle(), mHeadItem.getQishu());
				mHeadView.setHeadFlag(mHeadItem.getFlag());
			}
			GetImageRequest request = new GetImageRequest();
			request.setGzip(false);
			request.setUrl(url);
			ImageResult result = TaskManager.startLargeImageTask(request, this);
			if (result.isResultOK() && result.getRetBitmap() != null) {
				mHeadView.setHeadImage(result.getRetBitmap());
			} else {
				if (themeSettingsHelper.isDefaultTheme()) {
					mHeadView.setHeadImage(DefaulImageUtil.getDefaultListHeadImage());
				} else {
					mHeadView.setHeadImage(DefaulImageUtil.getNightDefaultListHeadImage());
				}
			}
		}
	}

	public void setSelection() {
		if (mListView != null) {
			mListView.setSelection(0);
		}
	}

	@Override
	public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm, String path) {
		if (bm != null && mHeadView != null) {
			mHeadView.setHeadImage(bm);
		}
	}

	@Override
	public void onImageRecvError(ImageType imageType, Object tag, int retCode) {
	}

	@Override
	public void updateSetting(SettingInfo setting) {
		if (mListView != null && setting != null) {
			mListView.setAutoLoading(setting.isIfAutoLoadMore());
		}
		if (mAdapter != null && mListView != null && mIsStyleMode != setting.isIfTextMode()) {
			mIsStyleMode = setting.isIfTextMode();
			if (setting.isIfTextMode()) {
				if (isNeedHeadView() && mHeadView != null) {
					mHeadView.setStyleMode(mIsStyleMode);
					getHeadData();
				}
				mAdapter.changeStyleMode(Constants.TYPE_ITEM_TEXT);
			} else {
				if (isNeedHeadView()) {
					if (mHeadView != null) {
						mHeadView.setStyleMode(mIsStyleMode);
						getHeadData();
					}
				}
				mAdapter.changeStyleMode(Constants.TYPE_ITEM_IMAGE);
			}
		}
	}

	protected void getIntentData(Intent intent) {
		if (intent != null) {
			mChannel = intent.getStringExtra(Constants.NEWS_CHLIDE_CHANNEL);
			mIsStartChannel = intent.getBooleanExtra(Constants.IS_START_CHANNEL, false);
			mIsViewPager = intent.getBooleanExtra(Constants.IS_FROM_VIEWPAGER, false);
			mIsCurrChannel = intent.getBooleanExtra(Constants.IS_CURRENT_CHANNEL, false);
		}
		SettingInfo settingInfo = SettingObservable.getInstance().getData();
		mIsStyleMode = settingInfo.isIfTextMode();
	}

	@SuppressLint("ResourceAsColor")
    @Override
    public void applyTheme() {
		if (mAdapter != null) {
			mAdapter.changeTheme();
		}
		if (mFramelayout != null) {
			mFramelayout.applyFrameLayoutTheme();
		}
		if (mHeadView != null) {
			mHeadView.applyImageHeadTheme();
		}
		getHeadData();
		
		if(mCellWebView != null) {
			mCellWebView.updateTheme();
		}
		
		themeSettingsHelper.setViewBackgroudColor(this, this.mListView, R.color.timeline_home_bg_color);
		themeSettingsHelper.setListViewSelector(this, this.mListView, R.drawable.list_selector);
//		themeSettingsHelper.setListViewDivider(this, this.mListView, R.drawable.list_divider_line);
	}
	
	protected synchronized void handleCellItem(List<Item> list) {		
		for(int i = 0; i < list.size(); i++) {
			Item item = list.get(i);
			if (item != null
					&& item.getArticletype() != null
					&& (item.getArticletype().trim().equals("1101") || 
						item.getArticletype().trim().equals("1201"))) {
				list.remove(i);
				return;
			}
		}
//		mCellItem = null;
//		for(int i = 0; i < list.size(); i++) {
//			Item item = list.get(i);
//			if(item != null && item.getArticletype() != null && item.getArticletype().trim().equals("1101")) {
//				mCellItem = list.get(i);
//
//				if(mCellWebView == null) {
//					createCellView();
//					mAdapter.mCellWebView = mCellWebView;
//				}
//				if (mCellWebView.isFirstLoad()) {
//					list.remove(i);
//				}
//				mCellWebView.loadUrl("file:///android_asset/stock.html");
//				break;
//			}
//		}
	}

	abstract protected void createCellView();
	
	abstract protected void removeCellView();
	
	abstract protected boolean isNeedHeadView();

	abstract protected void setHeadData(List<Item> list);

	abstract protected void InitAdapter();

	abstract protected void addHeadView();

	abstract protected void InitContainerView(Bundle savedInstanceState);

	abstract protected String getListviewTimeTag();

	abstract protected Class<? extends Object> getClassName(Item item);

	abstract protected String getChlidTitle();

	abstract protected boolean isRegisterNetTips();

}
