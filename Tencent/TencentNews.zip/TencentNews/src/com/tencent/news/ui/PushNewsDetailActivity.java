package com.tencent.news.ui;

import java.util.Properties;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Message;
import com.tencent.news.api.TencentNews;
import com.tencent.news.boss.EventId;
import com.tencent.news.cache.NewsDetailCache;
import com.tencent.news.cache.NewsDetailCache.CacheType;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.download.OffLineDownloadManagerNew;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.pojo.FullNewsDetail;
import com.tencent.news.system.AddCommentBroadcastReceiver;
import com.tencent.news.system.RefreshCommentNumBroadcastReceiver;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.news.utils.SLog;
import com.tencent.omg.webdev.WebDev;

public class PushNewsDetailActivity extends AbsNewsActivity {
	
	private long viewStart;
	private long viewEnd;
	
	private String mId;
	private String newsFrom="";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		stopBackgroundDownload();
		super.onCreate(savedInstanceState);
	}

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
		viewStart = System.currentTimeMillis();
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
		viewEnd = System.currentTimeMillis();
		
		Properties newp = new Properties(getPts());
		newp.setProperty(EventId.KEY_VIEW_START, "" + viewStart);
		newp.setProperty(EventId.KEY_VIEW_END, "" + viewEnd);
		WebDev.trackCustomEvent(this, EventId.BOSS_VIEW_DETAIL, newp);
	}
	
	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		stopBackgroundDownload();
		getIntentData(intent);
		getFullHtmlContent();
		if (receiver != null) {
			receiver.setComment_bar(mCommentView);
			receiver.setId(mId);
		}
		if (mRefreshCommentReceiver != null) {
			mRefreshCommentReceiver.setmWebView(mWebView);
			mRefreshCommentReceiver.setmItemId(mId);
		}
		SLog.i("PushNewsDetailActivity", "onNewIntent");
	}

	private void stopBackgroundDownload() {
		OffLineDownloadManagerNew.getInstance().stopDownloadTask();
		OffLineDownloadManagerNew.getInstance().killNotification();
	}

	@Override
	protected void targetActivity() {
		Intent intent = new Intent();
		intent.setClass(PushNewsDetailActivity.this, MainActivity.class);
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		startActivity(intent);
		quitActivity();
	}

	@Override
	protected void getData() {
		Loading();
		getFullHtmlContent();
	}

	private void getFullHtmlContent() {

		WebDev.trackCustomBeginKVEvent(PushNewsDetailActivity.this, EventId.ITIL_LOAD_DETAIL_TIME, getPts());

		//HttpDataRequest request = TencentNews.getInstance().getQQNewsFullHtmlContent(mId, "push",mChild);
		HttpDataRequest request = null;
		if(newsFrom!=null && newsFrom.length()>0){
			request = TencentNews.getInstance().getQQNewsFullHtmlContent(mId, newsFrom,mChild);
		}else{
			request = TencentNews.getInstance().getQQNewsFullHtmlContent(mId, "push",mChild);
		}
		
		TaskManager.startHttpDataRequset(request, this);
	}

	@Override
	protected boolean isInitComments() {
		return false;
	}

	@Override
	protected void registerBroadReceiver() {
		receiver = new AddCommentBroadcastReceiver(mCommentView, mId);
		registerReceiver(receiver, new IntentFilter(Constants.WRITE_SUCCESS_ACTION));

		mRefreshCommentReceiver = new RefreshCommentNumBroadcastReceiver(mId, null, mWebView, mWritingCommentView);
		registerReceiver(mRefreshCommentReceiver, new IntentFilter(Constants.REFRESH_COMMENT_NUMBER_ACTION));
	}

	@Override
	protected void getIntentData(Intent intent) {
		if (intent != null && intent.getExtras() != null) {
			Bundle bundle = intent.getExtras();
			mChild = bundle.getString(Constants.NEWS_CHANNEL_CHLID_KEY);
			mTitleText = bundle.getString(Constants.NEWS_DETAIL_TITLE_KEY);
			mId = bundle.getString("pushserviceid");
			newsFrom = bundle.getString("newFrom");
			mNewsDetailCache = new NewsDetailCache(mId, CacheType.NEWS_CACHE);
			
			WebDev.trackCustomEvent(this, EventId.BOSS_PUSH_CLICK_NOTIFICATION, getPts());
		}
	}

	@Override
	public void onHttpRecvOK(HttpTag tag, Object result) {
		super.onHttpRecvOK(tag, result);
		if (tag.equals(HttpTag.FULL_HTML_CONTENT)) {
			
			Properties p = getPts();
			WebDev.trackCustomEndKVEvent(PushNewsDetailActivity.this, EventId.ITIL_LOAD_DETAIL_TIME, p);
			Properties newp = new Properties(p);
			newp.setProperty(EventId.KEY_RESCODE, EventId.VALUE_RESCODE_SUCCESS);
			WebDev.trackCustomEvent(PushNewsDetailActivity.this, EventId.ITIL_LOAD_DETAIL_TIME_RESULT, newp);
			
			
			FullNewsDetail detail = (FullNewsDetail) result;
			mItem = detail.getmItem();
			mWritingCommentView.setItem(mChild, mItem);
			mWritingCommentView.canWrite(false);
			mCommentView.init(mChild, mItem);
			mCommentView.setWritingCommentView(mWritingCommentView);

			Message msg = new Message();
			msg.obj = detail.getmDetail();
			mHandler.sendMessage(msg);
			mNewsDetailCache.setCacheDetailData(detail.getmDetail());
			mNewsDetailCache.saveNewsDetail();
		}
	}

	@Override
	public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {
		if (tag.equals(HttpTag.FULL_HTML_CONTENT)) {
			
			Properties p = getPts();
			WebDev.trackCustomEndKVEvent(PushNewsDetailActivity.this, EventId.ITIL_LOAD_DETAIL_TIME, p);
			Properties newp = new Properties(p);
			newp.setProperty(EventId.KEY_RESCODE, EventId.VALUE_RESCODE_ERROR);
			WebDev.trackCustomEvent(PushNewsDetailActivity.this, EventId.ITIL_LOAD_DETAIL_TIME_RESULT, newp);
			
			
			TipsToast.getInstance().showTipsError(msg);
			loadError();
		}
	}

	@Override
	protected void retryData() {
		getFullHtmlContent();
	}

	@Override
	protected void setSourceType() {
		mSourceType = PUSH_NEWS_DETAIL;
	}

	@Override
	protected String iAmWhich() {
		return "push";
	}

	@Override
	protected Properties getPts() {
		Properties pts = new Properties();
		pts.setProperty(EventId.KEY_NEWSID, mItem != null ? mItem.getId() : mId);
		pts.setProperty(EventId.KEY_CHANNELID, mChild);
		pts.setProperty(EventId.KEY_DETAILTYPE, iAmWhich());
		return pts;
	}
}
