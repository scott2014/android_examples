package com.tencent.news.ui;

import java.util.ArrayList;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.command.GetImageRequest;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.model.pojo.HotAppList;
import com.tencent.news.model.pojo.HotAppListItem;
import com.tencent.news.model.pojo.ImageResult;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.system.NetStatusReceiver;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.system.observer.SettingObserver;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.adapter.HotAppListAdapter;
import com.tencent.news.ui.view.NetTipsBar;
import com.tencent.news.ui.view.PullImageHeadView;
import com.tencent.news.ui.view.PullRefreshListView;
import com.tencent.news.ui.view.PullRefreshListView.OnClickFootViewListener;
import com.tencent.news.ui.view.PullRefreshListView.OnRefreshListener;
import com.tencent.news.ui.view.PullToRefreshFrameLayout;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.news.ui.view.TitleBar;
import com.tencent.omg.webdev.WebDev;

public class HotAppListActivity extends BaseActivity implements SettingObserver {
	private static final String HOT_APP_LIST_TAG = "hot_app_list";
	private static final int GET_BANNER_IMAGE_OK = 0x201;
	private static final int GET_ALL_DATA_OK = 0x202;

	private PullToRefreshFrameLayout mFramelayout;
	private PullRefreshListView mListView;
	protected PullImageHeadView mHeadView;
	private HotAppListAdapter mAdapter;
	private ArrayList<HotAppListItem> mListItem;
	private HotAppList mHotAppList;
	private String mBannerURL;
	private ImageView mBannerImage;
	private String mRemain;// 剩余页数
	private LinearLayout headerView;
	private TitleBar mTitleBar;
	protected NetTipsBar mNetTipsBar;
	private int pageIndex = 0;
	private boolean isHasHeader;

	private View mMask;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Log.v("vincesun", "create");
		setContentView(R.layout.activity_download_hot);
		initView();
		initData();
		InitListener();
		initNetTips();
		SettingObservable.getInstance().registerObserver(this);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (mHotAppList != null) {
			mHotAppList = null;
		}

		if (mListItem != null && mListItem.size() > 0) {
			mListItem = null;
		}
	}

	protected void showConnectState() {
		if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_INAVAILABLE) {
			setLayout(false);
		} else {
			setLayout(true);
		}
	}

	private void initData() {
		mAdapter = new HotAppListAdapter(this, mListView);
		getNetFromNet();
	}

	private void getNetFromNet() {
		String page = String.valueOf(pageIndex);
		HttpDataRequest request = TencentNews.getInstance().getHotAppList(page);
		TaskManager.startHttpDataRequset(request, this);
	}

	protected void InitListener() {
		mListView.setOnRefreshListener(new OnRefreshListener() {
			@Override
			public void onRefresh() {
				getNewData();
			}

		});

		mListView.setOnClickFootViewListener(new OnClickFootViewListener() {

			@Override
			public void onClickFootView() {
				getMoreData();
			}

		});

		mFramelayout.setRetryButtonClickedListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				OnRetryData();
			}

		});

		mTitleBar.setBackClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				quitActivity();
			}

		});

		mTitleBar.setTopClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (mListView != null) {
					mListView.setSelection(0);
				}
			}

		});
	}

	protected void OnRetryData() {

		initData();
		mFramelayout.showState(Constants.LOADING);
	}

	/**
	 * 下拉刷新
	 */
	protected synchronized void getNewData() {
		mListView.setSelection(0);
		pageIndex = 0;
		initData();
	}

	private void initView() {
		mFramelayout = (PullToRefreshFrameLayout) findViewById(R.id.hot_app_listview);
		mListView = mFramelayout.getPullToRefreshListView();

		mMask = (View) findViewById(R.id.mask_view);

		mFramelayout.showState(Constants.LOADING);
		mListView.setPullTimeTag(HOT_APP_LIST_TAG);
		mTitleBar = (TitleBar) findViewById(R.id.hot_title_bar);
		mTitleBar.ShowSinaBar(R.string.app_recomm);
		mTitleBar.setBackName("设置");
	}

	private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if (msg != null) {
				switch (msg.what) {

				case GET_BANNER_IMAGE_OK:
					headerOption();
					break;

				case GET_ALL_DATA_OK:
					listViewOption(msg);
					break;

				default:
					break;
				}
			}
		}

	};

	private void listViewOption(Message msg) {
		if (msg != null && msg.obj != null && msg.obj instanceof HotAppList) {
			mHotAppList = (HotAppList) msg.obj;
			mBannerURL = mHotAppList.getBannerURL();
			String mBannerIMG = mHotAppList.getBannerIMG();
			mListItem = mHotAppList.getListItem();

			// mListItem = mHotAppList.getListItem();
			mRemain = mHotAppList.getRemain();

			if (mBannerURL != null && mBannerIMG != null) {
				headerOption();
				getBannerImageData(mBannerIMG);
			}

			if (mListItem != null) {
				initAdapter(mListItem);

			}
			mListView.onRefreshComplete(true);
			mFramelayout.showState(Constants.LIST);
			mListView.setFootViewAddMore(true, true, false);
		}
	}

	private void initAdapter(ArrayList<HotAppListItem> mListItem) {
		// HotAppListAdapter mAdapter = new HotAppListAdapter(this,mListView);
		if (pageIndex != 0) {
			mAdapter.addMoreDataList(mListItem);
		} else {
			mAdapter.addDataList(mListItem);
			mListView.setAdapter(mAdapter);
		}

		mAdapter.notifyDataSetChanged();
	}

	private void getBannerImageData(String url) {
		GetImageRequest request = new GetImageRequest();
		request.setUrl(url);
		ImageResult result = TaskManager.startLargeImageTask(request, this);
		if (result.isResultOK() && result.getRetBitmap() != null) {
			mBannerImage.setImageBitmap(result.getRetBitmap());
		} else {
			if (themeSettingsHelper.isNightTheme()) {
				mBannerImage.setImageResource(R.drawable.night_list_head_default_image);
			} else {
				mBannerImage.setImageResource(R.drawable.list_head_default_image);
			}
		}
	}

	private void headerOption() {

		if (!isHasHeader) {
			headerView = (LinearLayout) LayoutInflater.from(this).inflate(R.layout.hot_app_header, null);
			mListView.addHeaderView(headerView);
			mBannerImage = (ImageView) findViewById(R.id.hot_list_head_image);
			isHasHeader = true;
		}

		headerView.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(Intent.ACTION_VIEW);
				intent.setData(Uri.parse(mBannerURL));
				startActivity(intent);

			}
		});

	}

	private void getMoreData() {
		if (Integer.parseInt(mRemain) > 0) {
			pageIndex++;
			getNetFromNet();
		} else {
			mListView.setFootViewAddMore(true, false, false);
		}
	}

	private void initNetTips() {
		if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_INAVAILABLE) {
			setLayout(false);

		} else {
			setLayout(true);
		}
	}

	protected void setLayout(boolean bFlag) {
		if (mNetTipsBar != null) {
			if (bFlag) {
				mNetTipsBar.setVisibility(View.GONE);
			} else {
				mNetTipsBar.setVisibility(View.VISIBLE);
			}
		}
	}

	@Override
	public void onHttpRecvOK(HttpTag tag, Object result) {
		if (tag.equals(HttpTag.HOT_APP_LIST)) {
			Message msg = Message.obtain();
			msg.obj = result;
			msg.what = GET_ALL_DATA_OK;
			mHandler.sendMessage(msg);
		}
	}

	@Override
	public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {
		if (tag.equals(HttpTag.HOT_APP_LIST)) {
			Log.i("HOT_APP_LIST::::", "ERROR**********************");
			mFramelayout.showState(Constants.ERROR);
			TipsToast.getInstance().showTipsError("网络异常");
		}
	}

	@Override
	public void onHttpRecvCancelled(HttpTag tag) {

	}

	@Override
	public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm, String path) {
		if (bm != null) {
			mBannerImage.setImageBitmap(bm);
		}
	}

	@Override
	public void onImageRecvError(ImageType imageType, Object tag, int retCode) {

	}

	@Override
	public void updateSetting(SettingInfo setting) {

	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
			quitActivity();
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_MENU) {
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public void applyTheme() {
		if (mAdapter != null) {
			mAdapter.notifyDataSetChanged();
		}
		if (mFramelayout != null) {
			mFramelayout.applyFrameLayoutTheme();
		}
		if (mHeadView != null) {
			mHeadView.applyImageHeadTheme();
		}

		mTitleBar.applyTitleBarTheme(this);
		themeSettingsHelper.setViewBackgroudColor(this, this.mListView, R.color.timeline_home_bg_color);
		themeSettingsHelper.setListViewSelector(this, this.mListView, R.drawable.list_selector);
		themeSettingsHelper.setListViewDivider(this, mListView, R.drawable.list_divider_line);

		themeSettingsHelper.setViewBackgroudColor(this, mMask, R.color.mask_page_color);
	}

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}
}
