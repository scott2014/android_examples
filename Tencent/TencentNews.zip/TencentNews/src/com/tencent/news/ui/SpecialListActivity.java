package com.tencent.news.ui;

import android.content.Intent;
import android.os.Bundle;

import com.tencent.news.config.Constants;
import com.tencent.news.model.pojo.Item;
import com.tencent.omg.webdev.WebDev;

/**
 * 腾讯专题
 * 
 * @author jackiecheng
 * 
 */
public class SpecialListActivity extends AbsSpecialListActivity {

	@Override
	protected void loading() {
		// TODO Auto-generated method stub

	}

	@Override
	protected void getDataIntent(Intent intent) {
		if (intent != null) {
			Bundle bundle = intent.getExtras();
			mItem = (Item) bundle.getSerializable(Constants.NEWS_DETAIL_KEY);
			mSpecialNewsIds = mItem.getId();
			mChannel = bundle.getString(Constants.NEWS_CHANNEL_CHLID_KEY);
			mClickPosition = bundle.getString(Constants.NEWS_CLICK_ITEM_POSITION);
			isOffline = bundle.getBoolean(Constants.NEWS_DETAIL_FROM_OFFLINE_KEY);
			// mTitleText = bundle.getString(Constants.NEWS_DETAIL_TITLE_KEY);
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		if (mSpecialNewsIds != null && mChannel != null) {
			getSpecialNewsList(mSpecialNewsIds, mChannel);
		}
	}

	@Override
	protected void quit() {
		// TODO Auto-generated method stub
		quitActivity();
	}

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}
}
