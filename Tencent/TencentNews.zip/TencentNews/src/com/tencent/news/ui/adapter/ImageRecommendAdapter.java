package com.tencent.news.ui.adapter;

import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.command.GetImageRequest;
import com.tencent.news.command.GetImageResponse;
import com.tencent.news.model.pojo.ImageResult;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.task.TaskManager;
import com.tencent.news.utils.DefaulImageUtil;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.ThemeSettingsHelper;

public class ImageRecommendAdapter extends BaseAdapter implements GetImageResponse {
	List<Item> picDataList;
	Context mContext;
	GridView gridView;
	protected ThemeSettingsHelper themeSettingsHelper = null;
	
	public void setPicDataList(List<Item> picDataList) {
		this.picDataList = picDataList;
	}

	public ImageRecommendAdapter(Context mContext,GridView gridView) {
		this.mContext = mContext;
		this.gridView = gridView;
	}
	
	@Override
	public int getCount(){
		return picDataList==null ? 0:picDataList.size();
	}
	
	@Override
	public Object getItem(int position){
		return picDataList==null ? null:picDataList.get(position);
	}
	
	@Override
	public long getItemId(int position){
		return position;
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder = null;
		if(convertView==null){
			holder = new ViewHolder();
			convertView = LayoutInflater.from(mContext).inflate(R.layout.image_recommend_view_item, null);
			
			holder.img_view = (ImageView) convertView.findViewById(R.id.image_recommend_view_item_img);
			holder.img_title = (TextView) convertView.findViewById(R.id.image_recommend_view_item_title);
			
			convertView.setTag(holder);
		}else{
			holder = (ViewHolder) convertView.getTag();
		}
		
		Item picItem= picDataList==null? null:picDataList.get(position);
		if(picItem!=null){
			doDiffirence(picItem, holder);
		}
		return convertView;
	}

	@Override
	public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm, String path) {
		SLog.i("onImageRecvOK","-------------------------path:"+path);
		// TODO Auto-generated method stub
		switch (imageType) {
		case SMALL_IMAGE:
			int countImage = gridView.getChildCount();
			for (int i = 0; i < countImage; i++) {
				ViewHolder viewHolder = (ViewHolder) gridView.getChildAt(i).getTag();
				if (viewHolder != null) {
					if (((String) tag).equals(viewHolder.id)) {
						setPhotoListImage(viewHolder.img_view, bm);
						break;
					}
				}
			}
			break;
		default:
			break;
		}
	}

	@Override
	public void onImageRecvError(ImageType imageType, Object tag, int retCode) {
		// TODO Auto-generated method stub

	}

	private void doDiffirence(Item picItem, ViewHolder holder) {
		//holder.img_view.setBackgroundResource(picItem.getThumbnails());
		holder.img_title.setText(picItem.getTitle());
		holder.id=picItem.getId();
		
		String url=(picItem.getThumbnails_qqnews()!=null && picItem.getThumbnails_qqnews().length>0)?picItem.getThumbnails_qqnews()[0]:"";
		SLog.i("onImageRecvOK","-------------------------url:"+url);
		SLog.i("onImageRecvOK","-------------------------id:"+holder.id);
		GetImageRequest request = new GetImageRequest();
		request.setUrl(url);
		request.setTag(picItem.getId());
		//ImageResult result = TaskManager.getLocalIconImage(request, this);
		ImageResult result = TaskManager.startSmallImageTask(request, this);
		if(result.isResultOK() && result.getRetBitmap() != null){
			setPhotoListImage(holder.img_view, result.getRetBitmap());
		}else{
			//setPhotoListImage(holder.img_view,DefaulImageUtil.getDefaultListHeadImage());
			themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(this.mContext);
			if(themeSettingsHelper.isDefaultTheme()){
				setPhotoListImage(holder.img_view, DefaulImageUtil.getDefaultListHeadImage());
			} else {
				setPhotoListImage(holder.img_view, DefaulImageUtil.getNightDefaultListHeadImage());
			}		
		}
	}
	
	public void setPhotoListImage(ImageView srcImage,Bitmap bm){
		srcImage.setImageBitmap(bm);
	}

	public static class ViewHolder {
		String id;
		ImageView img_view;
		TextView img_title;
	}
}
