package com.tencent.news.ui.view;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.AttributeSet;

import com.tencent.news.config.Constants;
import com.tencent.news.model.pojo.ChannelList;
import com.tencent.news.model.pojo.ListMapData;
import com.tencent.news.system.Application;
import com.tencent.news.ui.MenuSettingActivity;
import com.tencent.news.utils.InfoConfigUtil;
import com.tencent.news.utils.TempManager;

public class ChannelBarNew extends ChannelBarBase {
	private String TAG = "ChannelBarBase";
	
	public ChannelBarNew(Context context){
		super(context,true);
	}
	
	public ChannelBarNew(Context context, AttributeSet attrs){
		super(context,attrs,true);
	}
	
	public ListMapData getListMapData(){
		ListMapData channel = Application.getInstance().getChannelList();
		if(channel == null) {
			channel = InfoConfigUtil.ReadSubChannel();
			if(channel == null){
				ChannelList channelTemp = TempManager.getManager().getChannelListInfo(mContext);
				if(channelTemp!=null && channelTemp.getChannelList()!=null && channelTemp.getChannelList().size()>0){
					channel=InfoConfigUtil.translate(channelTemp,true);//只初始化时使用true，其它时候用false
					channel.setVersion(channelTemp.getVersion());
				}
			}
			Application.getInstance().setChannelList(channel);
		}
		return channel;
	}
	
	@Override
	public ChannelList getChannelList(){
		ListMapData channelMapData = getListMapData();
		ChannelList channel = InfoConfigUtil.translate(channelMapData, true);
		return channel;
	}
	
	public void onClickSetUp(){
		Bundle bundle = new Bundle();
		ListMapData allChannels = getListMapData();
		
		bundle.putSerializable(Constants.SUB_CHANNEL, allChannels);
		
		Intent intent = new Intent(mContext, MenuSettingActivity.class);
		intent.putExtras(bundle);
		((Activity)mContext).startActivityForResult(intent,Constants.REQUEST_CODE_SET_CHANNEL);
	}

	@Override
	public Object getChannelData() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
