package com.tencent.news.ui;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.boss.EventId;
import com.tencent.news.cache.RssChannelSyncHelper;
import com.tencent.news.cache.UserDBHelper;
import com.tencent.news.config.Constants;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.model.pojo.SinaAccountsInfo;
import com.tencent.news.model.pojo.UserInfo;
import com.tencent.news.model.pojo.WXUserInfo;
import com.tencent.news.shareprefrence.SpConfig;
import com.tencent.news.shareprefrence.SpSetting;
import com.tencent.news.system.Application;
import com.tencent.news.system.WeiXinAuthBroadcastReceiver;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.system.observer.SettingObserver;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.ThemeSettingsHelper;
import com.tencent.news.wxapi.WXEntryActivity;
import com.tencent.omg.webdev.WebDev;

//import com.tencent.news.utils.StringUtil;

public class MyAccountActivity extends BaseActivity implements OnClickListener, SettingObserver {

	private final static int T_NEWS_SURE_LOGOUT = 1029;
	private final static int T_SINA_WEIBO_LOGOUT = 1030;
	private final static int T_WEIXIN_LOGOUT = 1031;
	private final static int USERNAME_LEN = 28;// 由8改为28，可视为不对用户名做截断
	// private boolean weixnlogin=false;
	private WeiXinAuthBroadcastReceiver receiver;

	RelativeLayout myAccountTitle = null;
	LinearLayout tencentNewsAccount = null;
	LinearLayout sinaWeiboAccount = null;
	LinearLayout weixinAccount = null;

	TextView txtView_account_title;

	TextView tencent_news_username = null;
	TextView weixin_username = null;
	// TextView tencent_weibo_username = null;
	TextView sina_weibo_username = null;
	TextView login_tencent_text = null;
	TextView login_sina_weibo_text = null;
	TextView login_weixin_text = null;

	TextView login_tencent_state = null;
	TextView login_weixin_state = null;
	TextView login_sina_weibo_state = null;
	String logged_state_color = "#999999";
	String login_state_color = "#2E65A8";

	ImageView icon_tencent_news_login = null;
	// ImageView icon_tencent_news_logout = null;
	ImageView icon_sina_weibo_login = null;
	// ImageView icon_sina_weibo_logout = null;
	ImageView icon_weixin_login = null;
	// ImageView icon_weixin_logout = null;

	View account_divider1 = null;
	View account_divider2 = null;

	Button settingTitle_btn_back = null;

	private SettingObservable settingObv;
	private SettingInfo settingData;

	private UserInfo tencentNewsUserInfo;

	RelativeLayout account_page = null;
	protected ThemeSettingsHelper themeSettingsHelper = null;

	private View mMask;
	private SinaWeiBoReceiver Srec = null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_my_account);

		settingObv = SettingObservable.getInstance();
		settingObv.registerObserver(this);

		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(this);

		initViews();
		initListener();
		receiver = new WeiXinAuthBroadcastReceiver(this, login_weixin_state, icon_weixin_login, login_weixin_text, weixin_username, login_state_color, logged_state_color);
		registerReceiver(receiver, new IntentFilter(Constants.WX_AUTH_SUCCESS_ACTION));
		IntentFilter filterS = new IntentFilter();
        filterS.addAction("SinaBack");
        Srec = new SinaWeiBoReceiver();
        this.registerReceiver(Srec, filterS);
	}

	private void initViews() {
		mMask = (View) findViewById(R.id.mask_view);

		txtView_account_title = (TextView) findViewById(R.id.txtView_account_title);

		myAccountTitle = (RelativeLayout) findViewById(R.id.myAccountTitle);
		account_page = (RelativeLayout) findViewById(R.id.account_page);

		tencentNewsAccount = (LinearLayout) findViewById(R.id.tencentNewsAccount);
		sinaWeiboAccount = (LinearLayout) findViewById(R.id.sinaWeiboAccount);

		tencent_news_username = (TextView) findViewById(R.id.tencent_news_username);
		// weixin_username = (TextView)findViewById(R.id.weixin_username);
		// tencent_weibo_username =
		// (TextView)findViewById(R.id.tencent_weibo_username);
		sina_weibo_username = (TextView) findViewById(R.id.sina_weibo_username);
		login_tencent_text = (TextView) findViewById(R.id.login_tencent_text);
		login_sina_weibo_text = (TextView) findViewById(R.id.login_sina_weibo_text);

		icon_tencent_news_login = (ImageView) findViewById(R.id.icon_tencent_news_login);
		// icon_tencent_news_logout =
		// (ImageView)findViewById(R.id.icon_tencent_news_logout);
		icon_sina_weibo_login = (ImageView) findViewById(R.id.icon_sina_weibo_login);
		// icon_sina_weibo_logout =
		// (ImageView)findViewById(R.id.icon_sina_weibo_logout);

		settingTitle_btn_back = (Button) findViewById(R.id.settingTitle_btn_back);

		weixinAccount = (LinearLayout) findViewById(R.id.weixinAccount);
		weixin_username = (TextView) findViewById(R.id.weixin_username);
		login_weixin_text = (TextView) findViewById(R.id.login_weixin_text);
		icon_weixin_login = (ImageView) findViewById(R.id.icon_weixin_login);
		// icon_weixin_logout =
		// (ImageView)findViewById(R.id.icon_weixin_logout);

		login_tencent_state = (TextView) findViewById(R.id.login_tencent_state);
		login_weixin_state = (TextView) findViewById(R.id.login_weixin_state);
		login_sina_weibo_state = (TextView) findViewById(R.id.login_sina_weibo_state);

		account_divider1 = (View) findViewById(R.id.account_divider1);
		account_divider2 = (View) findViewById(R.id.account_divider2);

		weixinAccount.setVisibility(View.GONE);// 屏蔽微信帐号设置

		initViewsByMode();
		initViewsBySetting();
	}

	private void mySetBackground(View view, int id) {
		int bottom = view.getPaddingBottom();
		int top = view.getPaddingTop();
		int left = view.getPaddingLeft();
		int right = view.getPaddingRight();

		view.setBackgroundDrawable(getResources().getDrawable(id));

		view.setPadding(left, top, right, bottom);
	}

	private void initViewsByMode() {
		themeSettingsHelper.setViewBackgroudColor(this, account_page, R.color.page_setting_bg_color);
		// themeSettingsHelper.setViewBackgroudColor(this, tencentNewsAccount,
		// R.color.page_setting_bg_color);
		// themeSettingsHelper.setViewBackgroudColor(this, weixinAccount,
		// R.color.page_setting_bg_color);
		// themeSettingsHelper.setViewBackgroudColor(this, sinaWeiboAccount,
		// R.color.page_setting_bg_color);

		// themeSettingsHelper.setViewBackgroud(this, tencentNewsAccount,
		// R.drawable.setting_selector);
		// themeSettingsHelper.setViewBackgroud(this, weixinAccount,
		// R.drawable.setting_selector);
		// themeSettingsHelper.setViewBackgroud(this, sinaWeiboAccount,
		// R.drawable.setting_selector);

		if (themeSettingsHelper.isNightTheme()) {
			mySetBackground(tencentNewsAccount, R.drawable.night_setting_selector);
			mySetBackground(weixinAccount, R.drawable.night_setting_selector);
			mySetBackground(sinaWeiboAccount, R.drawable.night_setting_selector);
		} else {
			mySetBackground(tencentNewsAccount, R.drawable.setting_selector);
			mySetBackground(weixinAccount, R.drawable.setting_selector);
			mySetBackground(sinaWeiboAccount, R.drawable.setting_selector);
		}

		themeSettingsHelper.setViewBackgroud(this, myAccountTitle, R.drawable.title_bar_bg);
		themeSettingsHelper.setViewBackgroud(this, settingTitle_btn_back, R.drawable.title_back_btn);

		if (themeSettingsHelper.isNightTheme()) {
			settingTitle_btn_back.setTextColor(Color.parseColor("#f0f4f8"));
			txtView_account_title.setTextColor(Color.parseColor("#f0f4f8"));
		} else {
			settingTitle_btn_back.setTextColor(Color.parseColor("#ffffff"));
			txtView_account_title.setTextColor(Color.parseColor("#ffffff"));
		}

		themeSettingsHelper.setImageViewSrc(this, icon_tencent_news_login, R.drawable.icon_setting_account);
		themeSettingsHelper.setImageViewSrc(this, icon_weixin_login, R.drawable.icon_setting_weixin);
		themeSettingsHelper.setImageViewSrc(this, icon_sina_weibo_login, R.drawable.icon_setting_sina_weibo);

		themeSettingsHelper.setViewBackgroud(this, account_divider1, R.drawable.setting_bar_bg);
		themeSettingsHelper.setViewBackgroud(this, account_divider2, R.drawable.setting_bar_bg);

		themeSettingsHelper.setTextViewColor(this, login_tencent_text, R.color.list_setting_title_color);
		themeSettingsHelper.setTextViewColor(this, tencent_news_username, R.color.list_setting_title_color);
		themeSettingsHelper.setTextViewColor(this, login_tencent_state, R.color.list_setting_title_color);

		themeSettingsHelper.setTextViewColor(this, login_weixin_text, R.color.list_setting_title_color);
		themeSettingsHelper.setTextViewColor(this, weixin_username, R.color.list_setting_title_color);
		themeSettingsHelper.setTextViewColor(this, login_weixin_state, R.color.list_setting_title_color);

		themeSettingsHelper.setTextViewColor(this, login_sina_weibo_text, R.color.list_setting_title_color);
		themeSettingsHelper.setTextViewColor(this, sina_weibo_username, R.color.list_setting_title_color);
		themeSettingsHelper.setTextViewColor(this, login_sina_weibo_state, R.color.list_setting_title_color);

		themeSettingsHelper.setViewBackgroudColor(this, mMask, R.color.mask_page_color);
	}

	private void initListener() {
		tencentNewsAccount.setOnClickListener(this);
		sinaWeiboAccount.setOnClickListener(this);
		settingTitle_btn_back.setOnClickListener(this);

		weixinAccount.setOnClickListener(this);
	}

	private void initViewsBySetting() {
		settingData = settingObv.getData();
		if (UserDBHelper.getInstance().getUserInfo() != null) {
			settingData.setUserInfo(UserDBHelper.getInstance().getUserInfo());
		}

		// 腾讯帐号
		if (settingData.getUserInfo() != null) {
			// icon_tencent_news_login.setVisibility(View.GONE);
			// icon_tencent_news_logout.setVisibility(View.VISIBLE);
			icon_tencent_news_login.setImageResource(R.drawable.set_zhanghao_login_icon);
			login_tencent_text.setText(this.getResources().getString(R.string.logout_tencent_news));

			String name = settingData.getUserInfo().getNick();// 微博昵称
			if (!TextUtils.isEmpty(name) && name.trim().length() > 0) {
				// tencent_news_username.setText(name);
			} else {
				name = settingData.getUserInfo().getQqnick();// QQ昵称
				if (!TextUtils.isEmpty(name) && name.trim().length() > 0) {
					// tencent_news_username.setText(name);
				} else {
					name = settingData.getUserInfo().getAccount();// QQ号
					if (!TextUtils.isEmpty(name) && name.trim().length() > 0) {
						// tencent_news_username.setText(name);
					} else {
						name = this.getResources().getString(R.string.default_user);
						// tencent_news_username.setText(this.getResources().getString(R.string.default_user));//
						// 默认值
					}
				}
			}
			// name = StringUtil.subString(name, USERNAME_LEN);
			tencent_news_username.setText(name);
			login_tencent_state.setText(this.getResources().getString(R.string.logged));
			login_tencent_state.setTextColor(Color.parseColor(logged_state_color));
		} else {
			// icon_tencent_news_login.setVisibility(View.VISIBLE);
			// icon_tencent_news_logout.setVisibility(View.GONE);
			icon_tencent_news_login.setImageResource(R.drawable.icon_setting_account);
			login_tencent_text.setText(this.getResources().getString(R.string.login_tencent_news));

			tencent_news_username.setText("");// 未登录用户名处显示信息
			login_tencent_state.setText(this.getResources().getString(R.string.not_login));
			login_tencent_state.setTextColor(Color.parseColor(login_state_color));
		}

		// 微信帐号
		// boolean weixnlogin=false;
		String weixinUser = "登录用户";
		WXUserInfo weixinInfo = SpConfig.loadWXSendAuthResp();
		if (weixinInfo != null) {
			weixinUser = weixinInfo.getUserName();
			// if(weixnlogin==true){
			// icon_weixin_login.setVisibility(View.GONE);
			// icon_weixin_logout.setVisibility(View.VISIBLE);
			icon_weixin_login.setImageResource(R.drawable.set_weixin_login_icon);
			login_weixin_text.setText(this.getResources().getString(R.string.logout_weixin));
			// weixinUser = StringUtil.subString(weixinUser, USERNAME_LEN);
			weixin_username.setText(weixinUser);
			login_weixin_state.setText(this.getResources().getString(R.string.logged));
			login_weixin_state.setTextColor(Color.parseColor(logged_state_color));
		} else {
			// icon_weixin_login.setVisibility(View.VISIBLE);
			// icon_weixin_logout.setVisibility(View.GONE);
			icon_weixin_login.setImageResource(R.drawable.icon_setting_weixin);
			login_weixin_text.setText(this.getResources().getString(R.string.login_weixin));
			weixin_username.setText("");// 未登录用户名处显示信息
			login_weixin_state.setText(this.getResources().getString(R.string.not_login));
			login_weixin_state.setTextColor(Color.parseColor(login_state_color));
		}

		// 新浪微博帐号
		SinaAccountsInfo info = SpConfig.getSinaAccountInfo();
		long time = System.currentTimeMillis() / 1000;
		if (info != null && info.getExpires() > time) {
			// icon_sina_weibo_login.setVisibility(View.GONE);
			// icon_sina_weibo_logout.setVisibility(View.VISIBLE);
			icon_sina_weibo_login.setImageResource(R.drawable.set_sina_login_icon);
			login_sina_weibo_text.setText(this.getResources().getString(R.string.logout_sina_weibo));
			// String sinaUserName = StringUtil.subString(info.getSina_name(),
			// USERNAME_LEN);
			String sinaUserName = info.getSina_name();
			sina_weibo_username.setText(sinaUserName);
			login_sina_weibo_state.setText(this.getResources().getString(R.string.logged));
			login_sina_weibo_state.setTextColor(Color.parseColor(logged_state_color));
		} else {
			// icon_sina_weibo_login.setVisibility(View.VISIBLE);
			// icon_sina_weibo_logout.setVisibility(View.GONE);
			icon_sina_weibo_login.setImageResource(R.drawable.icon_setting_sina_weibo);
			login_sina_weibo_text.setText(this.getResources().getString(R.string.login_sina_weibo));
			sina_weibo_username.setText("");// 未登录用户名处显示信息
			login_sina_weibo_state.setText(this.getResources().getString(R.string.not_login));
			login_sina_weibo_state.setTextColor(Color.parseColor(login_state_color));
		}

	}

	@Override
	public void onClick(View v) {

		switch (v.getId()) {
		case R.id.settingTitle_btn_back:

			quitActivity();

			break;
		case R.id.tencentNewsAccount:

			if (settingData.getUserInfo() != null) {
				showDialog(T_NEWS_SURE_LOGOUT);
			} else {
				Intent loginIntent = new Intent();
				loginIntent.setClass(this, LoginActivity.class);
				loginIntent.putExtra(Constants.LOGIN_FROM, Constants.LOGIN_FROM_SETTING);
				this.startActivityForResult(loginIntent, Constants.REQUEST_CODE_LOGIN);
			}

			break;
		case R.id.sinaWeiboAccount:

			SinaAccountsInfo sinaAccountsInfo = SpConfig.getSinaAccountInfo();
			// long sinaTokenVlidity = SpConfig.getSinaTokenVlidity();
			long time = System.currentTimeMillis() / 1000;
			if (sinaAccountsInfo != null && sinaAccountsInfo.getExpires() > time) {
				showDialog(T_SINA_WEIBO_LOGOUT);
			} else {
				Intent loginSinaIntent = new Intent();
				loginSinaIntent.setClass(this, SinaOuthActivity.class);
				loginSinaIntent.putExtra(Constants.SINA_LOGIN_FROM, SinaOuthActivity.SETTING_ACCOUNTS);
				this.startActivityForResult(loginSinaIntent, Constants.REQUEST_CODE_LOGIN_SINA);
			}

			break;
		case R.id.weixinAccount:

			// 微信帐号
			// boolean weixnlogin=false;
			String weixinUser = "登录用户";
			WXUserInfo weixinInfo = SpConfig.loadWXSendAuthResp();
			if (weixinInfo != null) {
				// weixinUser=weixinInfo.getUserName();
				// if(weixnlogin==true){
				showDialog(T_WEIXIN_LOGOUT);
			} else {
				Intent loginWeixinIntent = new Intent();
				// loginWeixinIntent.setClass(this, WeixinOuthActivity.class);
				// loginWeixinIntent.putExtra(Constants.WEIXIN_LOGIN_FROM,
				// WeixinOuthActivity.SETTING_ACCOUNTS);
				// this.startActivityForResult(loginWeixinIntent,
				// Constants.REQUEST_CODE_LOGIN_WEIXIN);
				// 测试用
				loginWeixinIntent.setClass(this, WXEntryActivity.class);
				loginWeixinIntent.putExtra(Constants.LOGIN_FROM, Constants.LOGIN_FROM_SETTING);
				// //loginWeixinIntent.putExtra(Constants.NEWS_SHARE_WEIXIN_OR_FIRENDS,
				// WXEntryActivity.FRIENDS);
				// this.startActivityForResult(loginWeixinIntent,
				// Constants.REQUEST_CODE_LOGIN_WEIXIN);
				this.startActivity(loginWeixinIntent);
			}

			break;
		default:
			break;
		}
	}

	@Override
	public void updateSetting(SettingInfo setting) {
		if (UserDBHelper.getInstance().getUserInfo() != null) {
			setting.setUserInfo(UserDBHelper.getInstance().getUserInfo());
		}
		SpSetting.saveSetting(setting);
		// 先存再读取
		initViewsBySetting();
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		Dialog dialog = null;
		switch (id) {
		case T_NEWS_SURE_LOGOUT:

			final AlertDialog logoutDialog = new AlertDialog.Builder(this)//
					.setTitle(MyAccountActivity.this.getResources().getString(R.string.account_management))//
					.setMessage(MyAccountActivity.this.getResources().getString(R.string.are_you_sure_logout_tencent_news))//
					.setPositiveButton(MyAccountActivity.this.getResources().getString(R.string.dialog_ok),//
							new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface dialog, int which) {

									if (Application.getInstance().helper != null) {
										Application.getInstance().helper.ClearUserLoginData(settingData.getUserInfo().getAccount());
									}

									UserDBHelper.getInstance().logoutUserInfo();

									settingData.setUserInfo(null);
									// login.setVisibility(View.VISIBLE);
									// logout.setVisibility(View.GONE);
									settingObv.setData(settingData);
				                    RssChannelSyncHelper.getInstance().onLogout();
	                                SpConfig.setRssLoginAlert(false);
									TipsToast.getInstance().showTipsSuccess(MyAccountActivity.this.getResources().getString(R.string.dialog_logout_success));
									//FavorItemCache.getInstance().clearCache(); //2013/07/03 用例评审 确认保留缓存

								}
							})//
					.setNegativeButton(MyAccountActivity.this.getResources().getString(R.string.dialog_cancel), //
							new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface dialog, int which) {

								}
							}).create();
			dialog = logoutDialog;
			break;
		case T_SINA_WEIBO_LOGOUT:

			final AlertDialog logoutSinaDialog = new AlertDialog.Builder(this)//
					.setTitle(MyAccountActivity.this.getResources().getString(R.string.account_management))//
					.setMessage(MyAccountActivity.this.getResources().getString(R.string.are_you_sure_logout_sina_weibo))//
					.setPositiveButton(MyAccountActivity.this.getResources().getString(R.string.dialog_ok),//
							new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface dialog, int which) {

									SpConfig.delSinaAccountsInfo();
									TipsToast.getInstance().showTipsSuccess(MyAccountActivity.this.getResources().getString(R.string.dialog_logout_success));
									initViewsBySetting();

								}
							})//
					.setNegativeButton(MyAccountActivity.this.getResources().getString(R.string.dialog_cancel), //
							new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface dialog, int which) {

								}
							}).create();
			dialog = logoutSinaDialog;
			break;
		case T_WEIXIN_LOGOUT:

			final AlertDialog logoutWeiboDialog = new AlertDialog.Builder(this)//
					.setTitle(MyAccountActivity.this.getResources().getString(R.string.account_management))//
					.setMessage(MyAccountActivity.this.getResources().getString(R.string.are_you_sure_logout_weixin))//
					.setPositiveButton(MyAccountActivity.this.getResources().getString(R.string.dialog_ok),//
							new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface dialog, int which) {

									// 注销操作
									SpConfig.delWXSendAuthResp();
									TipsToast.getInstance().showTipsSuccess(MyAccountActivity.this.getResources().getString(R.string.dialog_logout_success));
									// TipsToast.getInstance().showTipsSuccess("注销测试");
									initViewsBySetting();

								}
							})//
					.setNegativeButton(MyAccountActivity.this.getResources().getString(R.string.dialog_cancel), //
							new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface dialog, int which) {

								}
							}).create();
			dialog = logoutWeiboDialog;
			break;
		}
		return dialog;
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == RESULT_OK) {
			if (requestCode == Constants.REQUEST_CODE_LOGIN) {
				if (data != null && data.hasExtra(Constants.LOGIN_SUCCESS_BACK_USER_KEY)) {
					tencentNewsUserInfo = (UserInfo) data.getSerializableExtra(Constants.LOGIN_SUCCESS_BACK_USER_KEY);
					if (tencentNewsUserInfo != null && tencentNewsUserInfo.getAccount() != null) {

						// icon_tencent_news_login.setVisibility(View.GONE);
						// icon_tencent_news_logout.setVisibility(View.VISIBLE);
						icon_tencent_news_login.setImageResource(R.drawable.set_zhanghao_login_icon);
						login_tencent_text.setText(this.getResources().getString(R.string.logout_tencent_news));

						String name = tencentNewsUserInfo.getNick();// 微博昵称
						if (!TextUtils.isEmpty(name) && name.trim().length() > 0) {
							tencent_news_username.setText(name);
						} else {
							name = tencentNewsUserInfo.getQqnick();// QQ昵称
							if (!TextUtils.isEmpty(name) && name.trim().length() > 0) {
								tencent_news_username.setText(name);
							} else {
								name = tencentNewsUserInfo.getAccount();// QQ号
								if (!TextUtils.isEmpty(name) && name.trim().length() > 0) {
									tencent_news_username.setText(name);
								} else {
									name = this.getResources().getString(R.string.default_user);
									tencent_news_username.setText(this.getResources().getString(R.string.default_user));// 默认值
								}
							}
						}
						// name = StringUtil.subString(name, USERNAME_LEN);
						tencent_news_username.setText(name);
						login_tencent_state.setText(this.getResources().getString(R.string.logged));
						login_tencent_state.setTextColor(Color.parseColor(logged_state_color));

						settingData.setUserInfo(tencentNewsUserInfo);
						settingObv.setData(settingData);

						// Statistics.getInstance().saveStatistics(Statistics.REPORTED_DATA_SETTING,
						// StatisticsUtil.generateCustomField(new String[] {
						// Statistics.REPORTED_DATA_KEY_LOGIN_FROM_WHERE, "0",
						// "", "", "", "", "" }));

						WebDev.trackCustomEvent(this, EventId.BOSS_SETTING_LOGINFROM_MYACC_QQNEWS);

					} else {
						reLogin();
					}
				} else {
					reLogin();
				}
			}
			// 微信帐号
			if (requestCode == Constants.REQUEST_CODE_LOGIN_WEIXIN) {

				String weixinUser = "登录用户";
				WXUserInfo weixinInfo = SpConfig.loadWXSendAuthResp();
				if (weixinInfo != null) {
					weixinUser = weixinInfo.getUserName();
					// if(weixnlogin==true){
					// icon_weixin_login.setVisibility(View.GONE);
					// icon_weixin_logout.setVisibility(View.VISIBLE);
					icon_weixin_login.setImageResource(R.drawable.set_weixin_login_icon);
					login_weixin_text.setText(this.getResources().getString(R.string.logout_weixin));
					// weixinUser = StringUtil.subString(weixinUser,
					// USERNAME_LEN);
					weixin_username.setText(weixinUser);
					login_weixin_state.setText(this.getResources().getString(R.string.logged));
					login_weixin_state.setTextColor(Color.parseColor(logged_state_color));
				} else {
					// icon_weixin_login.setVisibility(View.VISIBLE);
					// icon_weixin_logout.setVisibility(View.GONE);
					icon_weixin_login.setImageResource(R.drawable.icon_setting_weixin);
					login_weixin_text.setText(this.getResources().getString(R.string.login_weixin));
					weixin_username.setText("");// 未登录用户名处显示信息
					login_weixin_state.setText(this.getResources().getString(R.string.not_login));
					login_weixin_state.setTextColor(Color.parseColor(login_state_color));
				}
			}
			// 新浪微博帐号
			if (requestCode == Constants.REQUEST_CODE_LOGIN_SINA) {
			    CheckSinaLoginState();
			}
		} else if (resultCode == RESULT_CANCELED) {
			if (requestCode == Constants.REQUEST_CODE_LOGIN) {
				reLogin();
			}
			// 微信
			if (requestCode == Constants.REQUEST_CODE_LOGIN_WEIXIN) {
				// icon_weixin_login.setVisibility(View.VISIBLE);
				// icon_weixin_logout.setVisibility(View.GONE);
				icon_weixin_login.setImageResource(R.drawable.icon_setting_weixin);
				weixin_username.setText("");// 未登录用户名处显示信息
				login_weixin_state.setText(this.getResources().getString(R.string.not_login));
				login_weixin_state.setTextColor(Color.parseColor(login_state_color));
			}
			// 新浪微博
			if (requestCode == Constants.REQUEST_CODE_LOGIN_SINA) {
				// icon_sina_weibo_login.setVisibility(View.VISIBLE);
				// icon_sina_weibo_logout.setVisibility(View.GONE);
				icon_sina_weibo_login.setImageResource(R.drawable.icon_setting_sina_weibo);
				sina_weibo_username.setText("");// 未登录用户名处显示信息
				login_sina_weibo_state.setText(this.getResources().getString(R.string.not_login));
				login_sina_weibo_state.setTextColor(Color.parseColor(login_state_color));
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	private void reLogin() {
		// icon_tencent_news_login.setVisibility(View.VISIBLE);
		// icon_tencent_news_logout.setVisibility(View.GONE);
		icon_tencent_news_login.setImageResource(R.drawable.icon_setting_account);
		login_tencent_text.setText(this.getResources().getString(R.string.login_tencent_news));
		settingData.setUserInfo(null);
		settingObv.setData(settingData);
		tencent_news_username.setText("");// 未登录用户名处显示信息
		login_tencent_state.setText(this.getResources().getString(R.string.not_login));
		login_tencent_state.setTextColor(Color.parseColor(login_state_color));
	}

	@Override
	protected void onDestroy() {
		if (receiver != null) {
			try {
				unregisterReceiver(receiver);
			} catch (Exception e) {
				
			}
		}
		if (Srec != null) {
            try {
                unregisterReceiver(Srec);
            } catch (Exception e) {
                SLog.e(e.toString());
            }
		}
		settingObv.removeObserver(this);
		super.onDestroy();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
			quitActivity();
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_MENU) {
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}
	public class SinaWeiBoReceiver extends BroadcastReceiver {
	    @Override
        public void onReceive(Context arg0, Intent intent) {
            // TODO Auto-generated method stub
            SLog.v("lvxn","recbroadcast");
            String action = intent.getAction();
            if(action.equals("SinaBack")){
                CheckSinaLoginState();
                SLog.v("lvxn","refresh");
            }
        }

    }
    private void CheckSinaLoginState(){
        SinaAccountsInfo info = SpConfig.getSinaAccountInfo();

        long time = System.currentTimeMillis()/1000;
        if(info!=null && info.getExpires()>time){
            //icon_sina_weibo_login.setVisibility(View.GONE);
            //icon_sina_weibo_logout.setVisibility(View.VISIBLE);
            icon_sina_weibo_login.setImageResource(R.drawable.set_sina_login_icon);
            login_sina_weibo_text.setText(this.getResources().getString(R.string.logout_sina_weibo));
            //String sinaUserName = StringUtil.subString(info.getSina_name(), USERNAME_LEN);
            String sinaUserName = info.getSina_name();
            sina_weibo_username.setText(sinaUserName);
            login_sina_weibo_state.setText(this.getResources().getString(R.string.logged));
            login_sina_weibo_state.setTextColor(Color.parseColor(logged_state_color));
        }else{
            //icon_sina_weibo_login.setVisibility(View.VISIBLE);
            //icon_sina_weibo_logout.setVisibility(View.GONE);
            icon_sina_weibo_login.setImageResource(R.drawable.icon_setting_sina_weibo);
            login_sina_weibo_text.setText(this.getResources().getString(R.string.login_sina_weibo));
            sina_weibo_username.setText("");//未登录用户名处显示信息
            login_sina_weibo_state.setText(this.getResources().getString(R.string.not_login));
            login_sina_weibo_state.setTextColor(Color.parseColor(login_state_color));
        }
    }
}
