package com.tencent.news.ui;

import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.ExpandableListView.OnGroupClickListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TextView.BufferType;

import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.command.GetImageRequest;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.model.pojo.ExtendedChannels;
import com.tencent.news.model.pojo.ImageResult;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.model.pojo.SpecialReport;
import com.tencent.news.model.pojo.SpecialReportImage;
import com.tencent.news.shareprefrence.SpConfig;
import com.tencent.news.system.SpecialNewsHadReadReceiver;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.adapter.SpecialReportAdapter;
import com.tencent.news.ui.view.NavigationBar;
import com.tencent.news.ui.view.PullRefreshIphoneTreeView;
import com.tencent.news.ui.view.ShareDialog;
import com.tencent.news.utils.DefaulImageUtil;
import com.tencent.news.utils.DispatchClassUtil;
import com.tencent.news.utils.FileUtil;
import com.tencent.news.utils.InfoConfigUtil;
import com.tencent.news.utils.IntentUtil;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.StringUtil;
import com.tencent.news.utils.ThemeSettingsHelper.ThemeCallback;

/**
 * 腾讯专题
 * 
 * @author jackiecheng
 * 
 */
public abstract class AbsSpecialListActivity extends NavActivity implements OnClickListener, ThemeCallback {
	protected static final int ENTER_GOT_DATA_FROM_LOCAL = 0x04;
	protected static final int ENTER_GOT_DATA_FROM_NET = 0x01;
	protected static final int GET_HEADER_IMAGE_DATA = 0x02;
	protected static final int GET_DATA_ERROR = 0x03;

	protected static final int LOADING = 0x01;
	protected static final int ERROR = 0x02;
	private static final int LIST = 0x03;

	static SpannableStringBuilder builder = new SpannableStringBuilder();
	protected PullRefreshIphoneTreeView specialReportListView;
	protected SpecialReport mSpecialReport;
	protected SpecialReportAdapter mSpecialReportAdapter;
	protected ImageView specailListHeadImage;
	protected TextView specailListHeadText;

	protected TextView introText;
	protected RelativeLayout introRelativeLayout;
	protected View news_detail_loading;
	protected View load_news_failed;
	protected Button mBackBtn;
	protected ImageButton btnShare;
	//protected NetTipsBar mNetTipsBar;
	//NetTipsReceiver mNetTipsReceiver;
	protected String mSpecialNewsIds;
	protected String mChannel;
	// protected String mTitleText;
	protected boolean isTextMode;
	protected boolean isOffline;
	protected String mClickPosition;
	protected Item mItem;
	protected String origtitle;
	protected String intro;
	protected boolean loadItemError = false;
	protected SpecialNewsHadReadReceiver mReceiver;
	private float downX;
	private float downY;
	private float upX;
	private float upY;

	// protected ThemeSettingsHelper themeSettingsHelper = null;
	protected RelativeLayout special_report = null, view_special_intro_1 = null;
	protected ImageView news_detail_loading_imgaview = null, load_news_failed_imageview = null;
	private View mMask;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		getDataIntent(getIntent());

		SettingInfo settingInfo = SettingObservable.getInstance().getData();
		isTextMode = settingInfo.isIfTextMode();
		
		if (isOffline) {
			setContentView(R.layout.activity_offline_special_report);
		} else {
			setContentView(R.layout.activity_special_report);
		}
		initView();
		initListener();
		//initNetTips();
		registerBroadcastReceiver();
		if (mItem == null) {
			loading();
		}
	}

	@Override
	protected void onDestroy() {
		if (null != mReceiver) {
			try {
				unregisterReceiver(mReceiver);
				mReceiver = null;
			} catch (Exception e) {
				SLog.e(e.toString());
			}
		}
		/*if (null != mNetTipsReceiver) {
			try {
				unregisterReceiver(mNetTipsReceiver);
				mNetTipsReceiver = null;
			} catch (Exception e) {
				SLog.e(e.toString());
			}
		}*/
		if (themeSettingsHelper != null) {
			themeSettingsHelper.unRegisterThemeCallback(this);
		}
		super.onDestroy();
	}

	protected void registerBroadcastReceiver() {
		mReceiver = new SpecialNewsHadReadReceiver(mChannel, mSpecialReportAdapter);
		IntentFilter filter = new IntentFilter(Constants.NEWS_HAD_READ_SPECIAL_ACTION + mChannel);
		registerReceiver(mReceiver, filter);

		/*if (!isOffline) {
			IntentFilter filter2 = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
			mNetTipsReceiver = new NetTipsReceiver(mNetTipsBar);
			this.registerReceiver(mNetTipsReceiver, filter2);
		}*/
	}

	private void initListener() {

		specialReportListView.setOnRefreshListener(new PullRefreshIphoneTreeView.OnRefreshListener() {

			@Override
			public void onRefresh() {
				getSpecialNewsListFromNet(mSpecialNewsIds, mChannel, null);
			}
		});

		specialReportListView.setOnGroupClickListener(new OnGroupClickListener() {
			@Override
			public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
				return true;
			}
		});
		specialReportListView.setOnChildClickListener(new OnChildClickListener() {
			@Override
			public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
				startNextActivity(groupPosition, childPosition);
				return true;
			}
		});
		btnShare.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				ShareDialog.getInstance().setSpecialReportParams(origtitle, intro, mItem, mChannel);
				ShareDialog.getInstance().showShareList(AbsSpecialListActivity.this, ShareDialog.SHARE_NORMAL_DETAIL, btnShare);
			}
		});
		load_news_failed.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (loadItemError) {
					// 微信进来拉取item出错
					loading();
				} else {
					// 根据item拉取专题列表出错
					getSpecialNewsList(mSpecialNewsIds, mChannel);
				}
			}
		});
	}

	private void startNextActivity(int groupPosition, int childPosition) {
		if (mSpecialReport == null || mSpecialReport.getIdlist() == null || mSpecialReport.getIdlist().length <= 0) {
			return;
		}
		Item item = mSpecialReport.getIdlist()[groupPosition].getNewslist()[childPosition];
		Log.i("TEST", item.toString());
		if (item != null && DispatchClassUtil.getClassName(item.getArticletype()) != null) {
			Intent intent = new Intent();
			Bundle bundle = new Bundle();
			bundle.putSerializable(Constants.NEWS_DETAIL_KEY, item);
			bundle.putString(Constants.NEWS_CHANNEL_CHLID_KEY, mChannel);
			bundle.putString(Constants.NEWS_DETAIL_TITLE_KEY, getChlidTitle(item));
			bundle.putBoolean(Constants.NEWS_DETAIL_FROM_OFFLINE_KEY, isOffline);
			bundle.putString(Constants.NEWS_CLICK_ITEM_POSITION, "" + computClickPosition(groupPosition, childPosition));
			bundle.putBoolean(Constants.IS_SPECIAL_KEY, true);
			intent.putExtras(bundle);
			intent.setClass(AbsSpecialListActivity.this, DispatchClassUtil.getClassName(item.getArticletype()));
			startActivity(intent);
		}
	}

	/**
	 * 计算点击位置
	 * 
	 * @param groupPosition
	 * @param childPosition
	 * @return
	 */
	private int computClickPosition(int groupPosition, int childPosition) {
		int nClickPosition = 0;
		if (groupPosition <= 0) {
			nClickPosition = childPosition;
		} else {
			for (int i = 0; i < groupPosition; i++) {
				nClickPosition += mSpecialReport.getIdlist()[i].getNewslist().length;
			}
			nClickPosition += childPosition;
		}

		Log.i("TEST", "click position-->" + (nClickPosition + 2));

		return nClickPosition + 2;
	}

	/**
	 * 需要重构
	 * 
	 * @param item
	 * @return
	 */
	private String getChlidTitle(Item item) {
		// if (item != null) {
		// if (item.getArticletype().equals("1")) {
		// return "精选图片";
		// } else if (item.getArticletype().equals("100")) {
		// return "腾讯专题";
		// }
		// }
		return "腾讯新闻";
	}

	private void initView() {
		// /
		special_report = (RelativeLayout) findViewById(R.id.special_report_title);
		view_special_intro_1 = (RelativeLayout) findViewById(R.id.view_special_intro_1);
		news_detail_loading_imgaview = (ImageView) findViewById(R.id.news_detail_loading_imgaview);
		load_news_failed_imageview = (ImageView) findViewById(R.id.load_news_failed_imageview);
		mMask = (View) findViewById(R.id.mask_view);
		// /

		mBackBtn = (Button) findViewById(R.id.special_report_title_btn_back);
		btnShare = (ImageButton) findViewById(R.id.title_btn_share);
		news_detail_loading = findViewById(R.id.news_detail_loading);
		load_news_failed = findViewById(R.id.load_news_failed);
		specialReportListView = (PullRefreshIphoneTreeView) findViewById(R.id.special_report_listview);
		specialReportListView.setFloat(false);
		specialReportListView.setPullTimeTag(mSpecialNewsIds);
		btnShare.setVisibility(View.VISIBLE);
		btnShare.setEnabled(false);

		/*if (!isOffline) {
			mNetTipsBar = (NetTipsBar) findViewById(R.id.news_nettips_bar);
		}*/

		setTitleBackName();
		// 标题图片/文字
		if(isTextMode || isOffline){
			setHeadTextView();
		}else{
			setHeadImageView();
		}

		// 导语
		if (themeSettingsHelper.isDefaultTheme()) {
			introRelativeLayout = (RelativeLayout) LayoutInflater.from(this).inflate(R.layout.view_special_intro, null, true);
		} else {
			introRelativeLayout = (RelativeLayout) LayoutInflater.from(this).inflate(R.layout.night_view_special_intro, null, true);
		}
		introText = (TextView) introRelativeLayout.findViewById(R.id.view_intro);
		specialReportListView.addHeaderView(introRelativeLayout);

		specialReportListView.setGroupIndicator(getResources().getDrawable(R.drawable.transparent_pic));
		mSpecialReportAdapter = new SpecialReportAdapter(this, specialReportListView, mSpecialReport, isOffline);
		specialReportListView.setAdapter(mSpecialReportAdapter);
	}

	private void setHeadImageView(){
			specailListHeadImage = new ImageView(this);
			specailListHeadImage.setScaleType(ScaleType.CENTER_INSIDE);
			// specailListHeadImage.setScaleType(ScaleType.FIT_XY);
			specailListHeadImage.setBackgroundColor(getResources().getColor(R.color.specaillistheadimage_color));//Color.parseColor("#DEDEDE"));
			specialReportListView.addHeaderView(specailListHeadImage, 0);
	}
	
	private void setHeadTextView(){
		specailListHeadText = new TextView(this);
		specailListHeadText.setSingleLine(true);
		specailListHeadText.setEllipsize(TextUtils.TruncateAt.valueOf("END"));
		specailListHeadText.setGravity(Gravity.CENTER);
		specailListHeadText.setBackgroundColor(getResources().getColor(R.color.specaillistheadimage_color));
		specailListHeadText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
		specailListHeadText.setTextColor(getResources().getColor(R.color.specailListHeadText_color));
		specialReportListView.addHeaderView(specailListHeadText, 0);
		
	}
	private void setTitleBackName() {
		if (isRelateNews) {
			mBackBtn.setText("返回");
			return;
		}
		ExtendedChannels channel = InfoConfigUtil.ReadExtendedChannels();
		if (channel != null && channel.getChlname() != null && NavigationBar.getSelected() == 4) {
			mBackBtn.setText(channel.getChlname());
		} else {
			if (this.isOffline)
				mBackBtn.setText(SpConfig.getChannelNameById(mChannel));
			else
				mBackBtn.setText("新闻");
		}
	}

	protected void getSpecialNewsList(final String specialNewsId, final String channel) {
		showState(LOADING);
		TaskManager.startRunnableRequest(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				SpecialReport sReportFromLocal = getSpecialNewsListFromLocal(specialNewsId);
				if (sReportFromLocal != null) {
					Message msg = Message.obtain();
					msg.what = ENTER_GOT_DATA_FROM_LOCAL;
					msg.obj = sReportFromLocal;
					mHandler.sendMessage(msg);

				} else {
				}
				if (!isOffline) {
					getSpecialNewsListFromNet(specialNewsId, channel, null);
				}
			}
		});
	}

	private SpecialReport getSpecialNewsListFromLocal(String specialNewsId) {
		SpecialReport sr = null;
		if (isOffline) {// 离线专题只能从离线专题里取数据
			sr = (SpecialReport) FileUtil.readSerObjectFromFile(Constants.CACHE_SPECIAL_REPORT_OFFLINE_PATH + specialNewsId);
		} else {
			sr = (SpecialReport) FileUtil.readSerObjectFromFile(Constants.CACHE_SPECIAL_REPORT_PATH + specialNewsId);
			if (sr == null) {
				sr = (SpecialReport) FileUtil.readSerObjectFromFile(Constants.CACHE_SPECIAL_REPORT_OFFLINE_PATH + specialNewsId);
			}
		}
		return sr;
	}

	private void getSpecialNewsListFromNet(String specialNewsId, String channel, String localIds) {
		HttpDataRequest request = TencentNews.getInstance().getQQNewsSpecialListItems(specialNewsId, channel, localIds);
		TaskManager.startHttpDataRequset(request, this);
	}

	private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if (msg != null) {
				SpecialReport specialReport = null;
				if (msg.obj != null) {
					specialReport = (SpecialReport) msg.obj;
				}
				switch (msg.what) {
				case ENTER_GOT_DATA_FROM_LOCAL:
					enterGetDataFromLocal(msg);
					if (specialReport != null) {
						shareSpecialReport(specialReport.getOrigtitle(), specialReport.getIntro());
					}
					break;
				case ENTER_GOT_DATA_FROM_NET:
					if (specialReport != null) {
						shareSpecialReport(specialReport.getOrigtitle(), specialReport.getIntro());
					}
					enterGetData(msg);
					break;
				case GET_HEADER_IMAGE_DATA:
					break;
				case GET_DATA_ERROR:
					if (specialReportListView != null && specialReportListView.getAdapter() != null && specialReportListView.getAdapter().getCount() > specialReportListView.getHeaderViewsCount()) {
						showState(LIST);
					} else {
						showState(ERROR);
					}
					break;
				default:
					break;
				}

			}
		}

	};

	private void shareSpecialReport(String title, String intro) {
		btnShare.setEnabled(true);
		this.origtitle = title;
		this.intro = intro;
	}

	protected void showState(int state) {
		if (news_detail_loading == null || load_news_failed == null || load_news_failed == null) {
			return;
		}
		switch (state) {
		case LOADING:
			news_detail_loading.setVisibility(View.VISIBLE);
			load_news_failed.setVisibility(View.GONE);
			specialReportListView.setVisibility(View.GONE);
			break;
		case ERROR:
			news_detail_loading.setVisibility(View.GONE);
			load_news_failed.setVisibility(View.VISIBLE);
			specialReportListView.setVisibility(View.GONE);
			break;
		case LIST:
			news_detail_loading.setVisibility(View.GONE);
			load_news_failed.setVisibility(View.GONE);
			specialReportListView.setVisibility(View.VISIBLE);
			break;
		default:
			news_detail_loading.setVisibility(View.GONE);
			load_news_failed.setVisibility(View.VISIBLE);
			specialReportListView.setVisibility(View.GONE);
			break;
		}
	}

	private void enterGetDataFromLocal(Message msg) {
		if (msg != null && msg.obj != null && msg.obj instanceof SpecialReport) {
			mSpecialReport = (SpecialReport) msg.obj;
			if (mSpecialReport != null) {
				for (int i = 0; i < mSpecialReport.getIdlist().length; i++) {
					specialReportListView.expandGroup(i);
					// sReportFromLocal.getIdlist()[i].putCommentNumIntoItem();
				}
				enterGetHeadImageOrText(mSpecialReport.getThumbnails(), mSpecialReport.getOrigtitle());

				highlightIntroText(mSpecialReport.getIntro());

				showState(LIST);
				mSpecialReportAdapter.setSpecialReport(mSpecialReport);
				mSpecialReportAdapter.notifyDataSetChanged();

			} else {
				getSpecialNewsListFromNet(mSpecialNewsIds, mChannel, null);
				showState(LOADING);
			}
		} else {
			showState(ERROR);
		}
	}

	private void highlightIntroText(String strIntro) {
		if (strIntro != null && strIntro.trim().length() > 0) {
			strIntro = StringUtil.StringFilter(StringUtil.replaceBlank(strIntro));
			builder.clear();
			builder.clearSpans();
			builder.append("【导语】");
			builder.append(strIntro);
			// ImageSpan span = new
			// ImageSpan(DefaulImageUtil.getDefaultIntroImage(),
			// ImageSpan.ALIGN_BASELINE);
			if (themeSettingsHelper.isDefaultTheme()) {
				builder.setSpan(new ForegroundColorSpan(Color.parseColor("#2385c6")), 0, "【导语】".length(), 0);
			} else {
				builder.setSpan(new ForegroundColorSpan(Color.parseColor("#5fabf1")), 0, "【导语】".length(), 0);
			}
			introText.getPaint().setAntiAlias(true);
			introText.setText(builder, BufferType.SPANNABLE);
			introText.setVisibility(View.VISIBLE);
			introRelativeLayout.setVisibility(View.VISIBLE);
		} else {
			introRelativeLayout.setPadding(introRelativeLayout.getPaddingLeft(), -MobileUtil.getScreenHeightIntPx(), introRelativeLayout.getPaddingRight(), introRelativeLayout.getPaddingBottom());
		}
	}

	private void enterGetData(Message msg) {
		if (msg != null && msg.obj != null && msg.obj instanceof SpecialReport) {
			mSpecialReport = (SpecialReport) msg.obj;
			if (mSpecialReport != null) {
				for (int i = 0; i < mSpecialReport.getIdlist().length; i++) {
					specialReportListView.expandGroup(i);
					mSpecialReport.getIdlist()[i].putCommentNumIntoItem();
				}
				enterGetHeadImageOrText(mSpecialReport.getThumbnails(), mSpecialReport.getOrigtitle());

				highlightIntroText(mSpecialReport.getIntro());

				showState(LIST);
				specialReportListView.onRefreshComplete(true);
				mSpecialReportAdapter.setSpecialReport(mSpecialReport);
				mSpecialReportAdapter.notifyDataSetChanged();
				// mergeOldAndNew(mSpecialReport);

				sendBroadCastforRead();

				TaskManager.startRunnableRequest(new Runnable() {

					@Override
					public void run() {
						FileUtil.saveSerObjectToFile(mSpecialReport, Constants.CACHE_SPECIAL_REPORT_PATH + mSpecialNewsIds);
					}
				});

			} else {
				showState(ERROR);
			}
		} else {
			showState(ERROR);
		}
	}

	/**
	 * 合并旧数据到新数据里去
	 * 
	 * @param sReportFromNet
	 */
	@Deprecated
	private void mergeOldAndNew(SpecialReport sReportFromNet) {
		// if (sReportFromLocal != null && sReportFromNet != null &&
		// sReportFromNet.getIdlist() != null &&
		// sReportFromNet.getIdlist().length > 0) {
		// for (int sectionIndex = 0, sectionTotal =
		// sReportFromNet.getIdlist().length; sectionIndex < sectionTotal;
		// sectionIndex++) {
		// Id[] ids = sReportFromNet.getIdlist()[sectionIndex].getIds();
		// if(ids!=null && ids.length>0) {
		// for(int i=0,j=ids.length;i<j;i++) {
		// String id = ids[i].getId();
		// Item item = new Item(id);
		// //TODO:根据item去旧的对象里去循环找吧
		// }
		// }
		// }
		// }
	}

	private void enterGetHeadImageOrText(SpecialReportImage headImg, String Origtitle) {
		
			if (headImg != null && headImg.getUrl() != null && headImg.getUrl().length() > 0) {
				AbsListView.LayoutParams al = null;
				try {
					al = new AbsListView.LayoutParams(AbsListView.LayoutParams.FILL_PARENT, resizeWH(Integer.parseInt(headImg.getWidth()), Integer.parseInt(headImg.getHeight())));
				} catch (Exception e) {
					al = new AbsListView.LayoutParams(MobileUtil.getScreenWidthIntPx(), 130);
				}
				
				if(isTextMode || isOffline){
					al = new AbsListView.LayoutParams(MobileUtil.getScreenWidthIntPx(), resizeWH(Integer.parseInt(headImg.getWidth()), 130));
					specailListHeadText.setLayoutParams(al);
					specailListHeadText.setText(Origtitle);
				}else{
					GetImageRequest request = new GetImageRequest();
					request.setGzip(false);
					request.setUrl(headImg.getUrl());
					

					specailListHeadImage.setLayoutParams(al);
					
					ImageResult result = TaskManager.startPngImageTask(request, this);
					if (result.isResultOK() && result.getRetBitmap() != null) {
						specailListHeadImage.setScaleType(ScaleType.FIT_XY);
						specailListHeadImage.setImageBitmap(result.getRetBitmap());
					} else {
						// 夜间模式
						if (themeSettingsHelper.isDefaultTheme()) {
							specailListHeadImage.setImageBitmap(DefaulImageUtil.getDefaultListHeadImage());
						} else {
							specailListHeadImage.setImageBitmap(DefaulImageUtil.getNightDefaultListHeadImage());
						}
						//
					}
				}
			} else {
				showState(ERROR);
			}
	}

	private int resizeWH(int w, int h) {
		return (int) (MobileUtil.getScreenWidthIntPx() * (1.0f * h / w));
	}

	@Override
	public void onHttpRecvOK(HttpTag tag, Object result) {
		if (tag.equals(HttpTag.SPECIAL_NEWS_LIST)) {
			Message msg = Message.obtain();
			msg.obj = result;
			msg.what = ENTER_GOT_DATA_FROM_NET;
			mHandler.sendMessage(msg);

		}
	}

	@Override
	public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {
		if (tag.equals(HttpTag.SPECIAL_NEWS_LIST)) {
			specialReportListView.onRefreshComplete(true);
			loadItemError = false;
			Message message = Message.obtain();
			message.what = GET_DATA_ERROR;
			mHandler.sendMessage(message);
		}
	}

	@Override
	public void onHttpRecvCancelled(HttpTag tag) {
		specialReportListView.onRefreshComplete(true);
	}

	@Override
	public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm, String path) {
		if (bm != null && specailListHeadImage != null) {
			specailListHeadImage.setScaleType(ScaleType.FIT_XY);
			specailListHeadImage.setImageBitmap(bm);
		}
	}

	@Override
	public void onImageRecvError(ImageType imageType, Object tag, int retCode) {
		// if(mIsLoadHeadImage){
		// mIsLoadHeadImage = false;
		// getHeadData();
		// }
	}

	@Override
	public void onClick(View v) {

		switch (v.getId()) {

		case R.id.special_report_title_btn_back:
			quit();
			break;

		default:
			break;
		}

	}

	@Override
	public boolean dispatchTouchEvent(MotionEvent ev) {
		final float x = ev.getX();
		final float y = ev.getY();
		if (ev.getAction() == MotionEvent.ACTION_DOWN) {
			downX = x;
			downY = y;
		} else if (ev.getAction() == MotionEvent.ACTION_UP) {
			upX = x;
			upY = y;
			if (upX > downX && Math.abs(upX - downX) > MobileUtil.dpToPx(100) && Math.abs(upY - downY) / Math.abs(upX - downX) < 0.4) {
				quit();
				return true;
			}
		}
		return super.dispatchTouchEvent(ev);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
			quit();
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_MENU) {
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	private void sendBroadCastforRead() {
		Intent intent = new Intent();
		Bundle bundle = new Bundle();

        String action = IntentUtil.getReadBroadcastAction(getIntent());
        if (action != null) {
            intent.setAction(action);
        } else {
            intent.setAction(Constants.NEWS_HAD_READ_ACTION + mChannel);
        }

		bundle.putSerializable(Constants.NEWS_ID_KEY, mItem);
		bundle.putString(Constants.NEWS_CLICK_ITEM_POSITION, mClickPosition);
		intent.putExtras(bundle);
		sendBroadcast(intent);

		Intent intent2 = new Intent();
		intent2.setAction(Constants.NEWS_HAD_READ_FOR_OFFLINE_ACTION);
		intent2.putExtras(bundle);
		sendBroadcast(intent2);
	}

/*	private void initNetTips() {
		if (!isOffline && NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_INAVAILABLE) {
			setLayout(false);
		} else {
			setLayout(true);
		}
	}

	protected void setLayout(boolean bFlag) {
		if (mNetTipsBar != null) {
			if (bFlag) {
				mNetTipsBar.setVisibility(View.GONE);
			} else {
				mNetTipsBar.setVisibility(View.VISIBLE);
			}
		}
	}*/

	@Override
	public void applyTheme() {
		// TODO Auto-generated method stub specialReportListView
		// themeSettingsHelper =
		// ThemeSettingsHelper.getThemeSettingsHelper(this);
		themeSettingsHelper.setViewBackgroud(this, this.special_report, R.drawable.title_bar_bg);
		themeSettingsHelper.setViewBackgroud(this, this.mBackBtn, R.drawable.title_back_btn);
		// themeSettingsHelper.setTextViewColor(this, this.mBackBtn,
		// getResources().getColor(R.color.special_report_title_btn_back_color));
		themeSettingsHelper.setImageButtonSrc(this, this.btnShare, R.drawable.title_share_btn);
		themeSettingsHelper.setViewBackgroudColor(this, this.news_detail_loading, R.color.news_detail_loading_color);
		themeSettingsHelper.setImageViewSrc(this, this.news_detail_loading_imgaview, R.drawable.news_loading_icon);
		themeSettingsHelper.setViewBackgroudColor(this, this.load_news_failed, R.color.load_news_failed_color);
		themeSettingsHelper.setImageViewSrc(this, this.load_news_failed_imageview, R.drawable.load_list_error_icon);

		/*if (mNetTipsBar != null) {
			mNetTipsBar.applyNetTipsBarTheme(this);
		}*/
		themeSettingsHelper.setViewBackgroudColor(this, this.specialReportListView, R.color.timeline_home_bg_color);
		themeSettingsHelper.setListViewSelector(this, this.specialReportListView, R.drawable.list_selector);
		specialReportListView.applyIphoneTreeView(this);
		// 导航背景图
		// themeSettingsHelper.setViewBackgroud(this, this.view_special_intro_1,
		// R.drawable.video_item_normal_bg);//?
		// 导航条文本颜色
		// themeSettingsHelper.setTextViewColor(this, this.introText,
		// R.color.view_intro_color);
		themeSettingsHelper.setViewBackgroudColor(this, mMask, R.color.mask_page_color);

		themeSettingsHelper.setViewBackgroudColor(this, this.specailListHeadImage, R.color.specaillistheadimage_color);
		
		//离线和问题模式下，头图夜间模式配色 specailListHeadText
		themeSettingsHelper.setViewBackgroudColor(this, this.specailListHeadText, R.color.specaillistheadimage_color);
		themeSettingsHelper.setTextViewColor(this, this.specailListHeadText, R.color.specailListHeadText_color);

	}

	abstract protected void loading();

	abstract protected void quit();

	abstract protected void getDataIntent(Intent intent);
}
