package com.tencent.news.ui.view;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.model.pojo.Channel;
import com.tencent.news.model.pojo.ChannelList;
import com.tencent.news.model.pojo.ListMapData;
import com.tencent.news.system.Application;
import com.tencent.news.utils.InfoConfigUtil;
import com.tencent.news.utils.MobileUtil;

public class ChannelBar extends LinearLayout implements OnClickListener{
	private Context mContext;
	private ViewPager mViewPager;
	private ImageButton mBtnLeft;
	private ImageButton mBtnRight;
	private List<View> mViews = new ArrayList<View>();
	private View viewSelected = null;
	private ChannelBarClickListener mListener;
	private int nCurrentPage = 0;
	private int nTotalPage;
	
	public ChannelBar(Context context) {
		super(context);
		Init(context);
	}
	
	public ChannelBar(Context context, AttributeSet attrs) {
		super(context, attrs);
		Init(context);
	}
	
	private void Init(Context context){
		this.mContext = context;
		LayoutInflater.from(mContext).inflate(R.layout.channel_bar_layout, this, true);
		mViewPager = (ViewPager)findViewById(R.id.channel_viewpager_Layout);
		mBtnLeft = (ImageButton)findViewById(R.id.channel_btn_left);
		mBtnRight = (ImageButton)findViewById(R.id.channel_btn_right);
		mBtnLeft.setOnClickListener(this);
		mBtnRight.setOnClickListener(this);
		InitViewPager();
	}
	
	private void InitViewPager(){
		ChannelList ChannelList = null;
		ListMapData channelMapData = Application.getInstance().getChannelList();
		if(channelMapData == null){
			channelMapData = InfoConfigUtil.ReadSubChannel();
		}
		if(channelMapData != null){
			ChannelList = InfoConfigUtil.translate(channelMapData, true);
			List<Channel> Channels = ChannelList.getChannelList();
			if(Channels != null && Channels.size()>0){
				nTotalPage = Channels.size()/5;
				int nSize = Channels.size()%5;
				if(nSize != 0){
					nTotalPage++;
				}
				for(int i = 0; i < nTotalPage; i++){
					LinearLayout  mLinearLayout = new LinearLayout(mContext);
					mLinearLayout.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, MobileUtil.dpToPx(36)));
					mLinearLayout.setOrientation(LinearLayout.HORIZONTAL);
					mLinearLayout.setGravity(Gravity.CENTER);
					mLinearLayout.setBackgroundResource(R.drawable.channel_bar_bg);
					/*mLinearLayout.setPadding(MobileUtil.dpToPx(10), 0, MobileUtil.dpToPx(2), 0);*/
					if(i == 0){
						for(int j = 0; j < 5; j++){
							int nIndex = j + i*5;
							Channel channel = Channels.get(nIndex);
							FrameLayout view = (FrameLayout)LayoutInflater.from(mContext).inflate(R.layout.channel_bar_item, null);
							view.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT,1));
							((TextView)view.getChildAt(0)).setText(channel.getChlname());
							view.setTag(j);
							view.setOnClickListener(this);
							if(j == 0){
								viewSelected = view;
								viewSelected.setSelected(true);
							}
							
							mLinearLayout.addView(view);
						}
					}else{
						for(int j = 0; j < 5; j++){
							int nIndex = j + i*5;
							if(nIndex < Channels.size()){
								Channel channel = Channels.get(nIndex);
								FrameLayout view = (FrameLayout)LayoutInflater.from(mContext).inflate(R.layout.channel_bar_item, null);
								view.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT, 1));
								((TextView)view.getChildAt(0)).setText(channel.getChlname());
								view.setTag(nIndex);
								view.setOnClickListener(this);
								mLinearLayout.addView(view);
							}else{
								View v = new View(mContext);
								v.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT, 1));
								mLinearLayout.addView(v);
							}
						}
					}
					mViews.add(mLinearLayout);
				}
			}
		}
		if(nTotalPage > 0 && nTotalPage <= 1){
			mBtnLeft.setEnabled(false);
			mBtnRight.setEnabled(false);
		}
		mViewPager.setAdapter(new MyPagerAdapter(mViews));
		mViewPager.setCurrentItem(0);
		mBtnLeft.setEnabled(false);
		mViewPager.setOnPageChangeListener(new MyOnPageChangeListener());
	}
	
	public class MyOnPageChangeListener implements OnPageChangeListener {

		@Override
		public void onPageScrollStateChanged(int arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onPageSelected(int arg0) {
			// TODO Auto-generated method stub
			
			if(nCurrentPage < arg0){
				if(arg0 < nTotalPage-1){
					mBtnLeft.setEnabled(true);
					mBtnRight.setEnabled(true);
				}else{
					mBtnLeft.setEnabled(true);
					mBtnRight.setEnabled(false);
				}
			}else{
				if(arg0 > 0){
					mBtnLeft.setEnabled(true);
					mBtnRight.setEnabled(true);
				}else{
					mBtnLeft.setEnabled(false);
					mBtnRight.setEnabled(true);
				}
			}
			nCurrentPage = arg0;
		}
		
	}
	
	public class MyPagerAdapter extends PagerAdapter {

        public List<View> mListViews;

        public MyPagerAdapter(List<View> mListViews) {
            this.mListViews = mListViews;
        }

        @Override
        public void destroyItem(View arg0, int arg1, Object arg2) {
            ((ViewPager) arg0).removeView(mListViews.get(arg1));
        }

        @Override
        public void finishUpdate(View arg0) {

        }

        @Override
        public int getCount() {
            return mListViews.size();
        }

        @Override
        public Object instantiateItem(View arg0, int arg1) {
            ((ViewPager) arg0).addView(mListViews.get(arg1), 0);
            return mListViews.get(arg1);
        }

        @Override
        public boolean isViewFromObject(View arg0, Object arg1) {
            return arg0 == (arg1);
        }

        @Override
        public void restoreState(Parcelable arg0, ClassLoader arg1) {

        }

        @Override
        public Parcelable saveState() {
            return null;
        }

        @Override
        public void startUpdate(View arg0) {

        }

    }

	@Override
	public void onClick(View v) {
		if(v.getId() == R.id.channel_btn_left){
			mViewPager.setCurrentItem(nCurrentPage-1);
		}else if(v.getId() == R.id.channel_btn_right){
			mViewPager.setCurrentItem(nCurrentPage+1);
		}else{
			if(viewSelected.equals(v)){
				return;
			}
			viewSelected.setSelected(false);
			v.setSelected(true);
			viewSelected = v;
			if(this.mListener != null){
				int nIndex = (Integer)viewSelected.getTag();
				mListener.onSelected(nIndex);
			}
		}
	}
	
	public void setActive(int nIndex){
		int nPage = nIndex/5;
		LinearLayout  mLinearLayout;
		if(nIndex%5 != 0){
			nPage++;
		}
		if(nPage == 0 && nPage < mViews.size()){
			mLinearLayout = (LinearLayout)mViews.get(nPage);
		}else{
			mLinearLayout = (LinearLayout)mViews.get(nPage-1);
		}
		View v = mLinearLayout.getChildAt(nIndex%5);
		viewSelected.setSelected(false);
		v.setSelected(true);
		viewSelected = v;
	}
	
	public void setOnChannelBarClickListener(ChannelBarClickListener mListener){
		this.mListener = mListener;
	}
	
	public interface ChannelBarClickListener{
		public void onSelected(int nIndex);
	}
}
