package com.tencent.news.ui;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.cache.UserDBHelper;
import com.tencent.news.config.Constants;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.model.pojo.UserInfo;
import com.tencent.news.system.AddCommentBroadcastReceiver;
import com.tencent.news.system.RefreshCommentNumBroadcastReceiver;
import com.tencent.news.ui.adapter.ViewPagerAdapter;
import com.tencent.news.ui.view.CommentView;
import com.tencent.news.ui.view.ShareDialog;
import com.tencent.news.ui.view.TitleBar;
import com.tencent.news.ui.view.ViewPagerEx;
import com.tencent.news.ui.view.WebDetailView;
import com.tencent.news.ui.view.WritingCommentView;
import com.tencent.news.ui.view.WritingCommentView.OnChangeClick;
import com.tencent.news.utils.IntentUtil;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.SLog;
import com.tencent.omg.webdev.WebDev;

public class WebDetailActivity extends NavActivity {
	private TitleBar mTitleBar;
	private WebView mWebView;
	private View mMask;
	private Item mItem;
	private String mClickPosition;
	private String mChlid;
	private boolean isSpecial;
	private List<View> mViews = new ArrayList<View>();
	private WritingCommentView mWritingCommentView;
	private WebDetailView mWebDetailView;
	private ViewPagerEx mViewPager;
	private CommentView mCommentView;

	private int nCurrentPage;
	private float downX;
	private float upX;
	private float downY;
	private float upY;
	private AddCommentBroadcastReceiver receiver;
	private RefreshCommentNumBroadcastReceiver mRefreshCommentReceiver;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.web_detail_layout);
		getIntentData();
		initView();
		initListener();
		registerBroadReceiver();
	}

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}

	private void registerBroadReceiver() {
		// Auto-generated method stub
		receiver = new AddCommentBroadcastReceiver(mCommentView, mItem.getId());
		registerReceiver(receiver, new IntentFilter(Constants.WRITE_SUCCESS_ACTION));

		mRefreshCommentReceiver = new RefreshCommentNumBroadcastReceiver(mItem.getId(), null, mWebView, mWritingCommentView);
		registerReceiver(mRefreshCommentReceiver, new IntentFilter(Constants.REFRESH_COMMENT_NUMBER_ACTION));
	}

	private void getIntentData() {
		Intent intent = getIntent();
		if (intent != null) {
			Bundle bundle = intent.getExtras();
			if (bundle != null) {
				mChlid = bundle.getString(Constants.NEWS_CHANNEL_CHLID_KEY);
				mClickPosition = bundle.getString(Constants.NEWS_CLICK_ITEM_POSITION);
				isSpecial = bundle.getBoolean(Constants.IS_SPECIAL_KEY);
				mItem = (Item) bundle.getSerializable(Constants.NEWS_DETAIL_KEY);
			}
		}
	}

	@SuppressLint("SetJavaScriptEnabled")
	private void initView() {
		mTitleBar = (TitleBar) findViewById(R.id.web_detail_title_bar);
		mWebView = (WebView) findViewById(R.id.web_detail_webview);
		mViewPager = (ViewPagerEx) findViewById(R.id.web_detail_viewpager);
		mWritingCommentView = (WritingCommentView) findViewById(R.id.web_detail_WritingCommentView);
		mMask = (View) findViewById(R.id.web_detail_mask_view);
		mWebDetailView = new WebDetailView(this);
		mWebView = mWebDetailView.getWebView();
		mCommentView = new CommentView(this);
		mViews.add(mWebDetailView);
		mViews.add(mCommentView);
		mViewPager.setAdapter(new ViewPagerAdapter(mViews));
		mViewPager.setOffscreenPageLimit(1);
		mViewPager.setCurrentItem(0);
		mViewPager.setPageMargin(2);
		mViewPager.setOnPageChangeListener(new MyOnPageChangeListener());

		mWebView.getSettings().setSavePassword(false);
		mWebView.getSettings().setDomStorageEnabled(true);
		mWebView.getSettings().setJavaScriptEnabled(true);
		mWebView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
		mTitleBar.ShowNewsBar("腾讯新闻");
		setTitleBackName();
		mWritingCommentView.setItem(mChlid, mItem);
		mWritingCommentView.canWrite(false);
		mCommentView.init(mChlid, mItem);
		mCommentView.setWritingCommentView(mWritingCommentView);
		mWebView.loadUrl(makeUrl());
		mWebDetailView.Loading();
	}

	private void setTitleBackName() {
		if (isSpecial) {
			mTitleBar.setBackName("专题");
		} else {
			mTitleBar.setBackName("新闻");
		}
	}

	private String makeUrl() {
		StringBuilder sb = new StringBuilder();
		if (mItem != null && mItem.getArticletype() != null && mItem.getArticletype().equals("5")) {
		    // 拉在线网页的接口不变，只是改域名
			sb.append(TencentNews.READ_BASE_URL + "getQQNewsSimpleHtmlContent?");
			sb.append("id=" + mItem.getId());
			sb.append("&appver=" + URLEncoder.encode(MobileUtil.getSystemSdk() + "_android_" + MobileUtil.getVersionName()));
			sb.append("&devid=" + URLEncoder.encode(MobileUtil.getImei()));
			sb.append("&mac=" + URLEncoder.encode(MobileUtil.getLocalMacAddress()));
			sb.append("&apptype=" + URLEncoder.encode("android"));
			sb.append("&store=" + URLEncoder.encode(MobileUtil.getFrom()));
			sb.append("&hw=" + URLEncoder.encode(MobileUtil.getManufacturer() + "_" + MobileUtil.getProductType()));
			sb.append("&sceneid=" + URLEncoder.encode(MobileUtil.getSceneId()));
			if (UserDBHelper.getInstance().getUserInfo() != null) {
				UserInfo userInfo = UserDBHelper.getInstance().getUserInfo();
				sb.append("&uin=" + userInfo.getUin());
				sb.append("&skey=" + userInfo.getSkey());
				sb.append("&luin=" + userInfo.getLuin());
				sb.append("&lskey=" + userInfo.getLskey());
			}
		}
		return sb.toString();
	}

	private void initListener() {
		mWritingCommentView.setDetailCommentChangeClick(new OnChangeClick() {
			@Override
			public void change() {
				if (nCurrentPage == 0) {
					mViewPager.setCurrentItem(1);
				} else {
					mViewPager.setCurrentItem(0);
				}
			}
		});

		mTitleBar.setShareClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				ShareDialog.getInstance().showShareList(WebDetailActivity.this, ShareDialog.SHARE_NORMAL_DETAIL, mTitleBar.getShareBtn());
			}
		});

		mTitleBar.setBackClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				quitActivity();
			}
		});

		mTitleBar.setTopClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (nCurrentPage == 1) {
					mCommentView.upToTop();
				}
			}
		});

		mWebView.setWebChromeClient(new WebChromeClient() {
			public void onProgressChanged(WebView view, int progress) {
				if (progress >= 100) {
					mWebDetailView.loadComplete();
					shareNewsData();
					mCommentView.enterPageThenGetComments(isRelateNews);
					mWritingCommentView.canWrite(true);
					mWritingCommentView.setVid("");
					ShareDialog.getInstance().setVid("");
					setCommentViewImgVid();
					sendBroadCastforRead();
				}
			}
		});

		mWebView.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView view, String url, Bitmap favicon) {
				super.onPageStarted(view, url, favicon);
			}

			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				System.out.println("url------>" + url);
				view.loadUrl(url);
				return true;
			}

			@Override
			public void onPageFinished(WebView view, String url) {
				super.onPageFinished(view, url);
			}

			@Override
			public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
				super.onReceivedError(view, errorCode, description, failingUrl);
				if (mWebView != null) {
					mWebView.loadUrl(Constants.WEB_ERROR);
				}
			}

		});
	}

	private void shareNewsData() {
		mTitleBar.getShareBtn().setEnabled(true);
		ShareDialog.getInstance().setParams("", "", null, mItem, mChlid);
	}

	private void setCommentViewImgVid() {
		if (mItem.getThumbnails() != null && mItem.getThumbnails().length > 0) {
			mWritingCommentView.setImg(mItem.getThumbnails()[0]);
			ShareDialog.getInstance().setImageUrl(mItem.getThumbnails()[0]);
		} else {
			mWritingCommentView.setImg("");
			ShareDialog.getInstance().setImageUrl("");
		}
	}

	public class MyOnPageChangeListener implements OnPageChangeListener {

		@Override
		public void onPageScrollStateChanged(int arg0) {

		}

		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {

		}

		@Override
		public void onPageSelected(int arg0) {
			nCurrentPage = arg0;
			mWritingCommentView.setDCPage(nCurrentPage);
			mWritingCommentView.refreshUI();
		}

	}

	private void sendBroadCastforRead() {
		Intent intent = new Intent();
		Bundle bundle = new Bundle();
		bundle.putSerializable(Constants.NEWS_ID_KEY, mItem);
		bundle.putString(Constants.NEWS_CLICK_ITEM_POSITION, mClickPosition);
		intent.putExtras(bundle);

        String action = IntentUtil.getReadBroadcastAction(getIntent());
        if (action != null) {
            intent.setAction(action);
        } else if (isSpecial) {
			intent.setAction(Constants.NEWS_HAD_READ_SPECIAL_ACTION + mChlid);
		} else {
			intent.setAction(Constants.NEWS_HAD_READ_ACTION + mChlid);
		}
		sendBroadcast(intent);

		Intent intent2 = new Intent();
		intent2.setAction(Constants.NEWS_HAD_READ_FOR_OFFLINE_ACTION);
		intent2.putExtras(bundle);
		sendBroadcast(intent2);
	}

	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if ((keyCode == KeyEvent.KEYCODE_BACK)) {
			if (mWebView.canGoBack()) {
				if (Constants.WEB_ERROR.equals(mWebView.getUrl())) {
					quitActivity();
				} else {
					mWebView.goBack();
				}
				return true;
			}
			quitActivity();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public boolean dispatchTouchEvent(MotionEvent ev) {
		// TODO Auto-generated method stub
		final float x = ev.getX();
		final float y = ev.getY();
		if (ev.getAction() == MotionEvent.ACTION_DOWN) {
			downX = x;
			downY = y;
		} else if (ev.getAction() == MotionEvent.ACTION_UP) {
			upX = x;
			upY = y;
			if (nCurrentPage == 0 && upX > downX && Math.abs(upX - downX) > MobileUtil.dpToPx(100) && Math.abs(upX - downX) > Math.abs(upY - downY)) {
				quitActivity();
			}
		}
		return super.dispatchTouchEvent(ev);
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		if (receiver != null) {
			try {
				unregisterReceiver(receiver);
			} catch (Exception e) {
				SLog.e(e.toString());
			}
		}
		if (mRefreshCommentReceiver != null) {
			try {
				unregisterReceiver(mRefreshCommentReceiver);
			} catch (Exception e) {
				SLog.e(e.toString());
			}
		}

		if (mViews != null) {
			mViews.clear();
			mViews = null;
		}
		if (mWebView != null) {
			mWebDetailView.getNewsDetailLayout().removeView(mWebView);
			mWebView.removeAllViews();
			mWebView.destroy();
			mWebView = null;
		}
		ShareDialog.getInstance().dismiss();
		super.onDestroy();
	}

	@Override
	public void applyTheme() {
		if (mTitleBar != null) {
			mTitleBar.applyTitleBarTheme(this);
		}
		themeSettingsHelper.setViewBackgroudColor(this, mMask, R.color.mask_page_color);
	}

}
