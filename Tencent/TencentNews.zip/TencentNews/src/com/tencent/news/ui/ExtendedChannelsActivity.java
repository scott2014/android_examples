package com.tencent.news.ui;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.app.ActivityGroup;
import android.app.LocalActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.FrameLayout;

import com.tencent.news.R;
import com.tencent.news.config.Constants;
import com.tencent.news.model.pojo.ActivityViewInfo;
import com.tencent.news.model.pojo.DynamicChannel;
import com.tencent.news.model.pojo.ExtendedChannels;
import com.tencent.news.system.NetStatusReceiver;
import com.tencent.news.system.NetTipsReceiver;
import com.tencent.news.ui.view.ChannelBarBase.ChannelBarClickListener;
import com.tencent.news.ui.view.ChannelBarExtended;
import com.tencent.news.ui.view.NetTipsBar;
import com.tencent.news.ui.view.TitleBar;
import com.tencent.news.ui.view.ViewPagerEx;
import com.tencent.news.utils.InfoConfigUtil;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.ThemeSettingsHelper;
import com.tencent.news.utils.ThemeSettingsHelper.ThemeCallback;
import com.tencent.omg.webdev.WebDev;

public class ExtendedChannelsActivity extends ActivityGroup implements ThemeCallback {
	private TitleBar mTitleBar;
	private LocalActivityManager localManager;
	private ViewPagerEx mChannelViewPager;
	private DynamicChannel[] mChannelList;
	private List<ActivityViewInfo> mViews = null;
	private ChannelBarExtended mExtendedBar;
	private NetTipsBar mNetTipsBar;
	private int mCurrChannel = 0;
	private NetTipsReceiver mNetTipsReceiver;
	private int nCount;
	private int mWebCurrScreen = -1;
	private int nIndex = 0;
	protected ThemeSettingsHelper themeSettingsHelper = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.extended_channel_layout);
		initView();
		getIntentData(getIntent());
		initListener();
		initViewPager();
		registerNetTipsReceiver();
		if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_INAVAILABLE) {
			setLayout(false);
		} else {
			setLayout(true);
		}
		// 为夜间模式添加以下代码
		themeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(this);
		themeSettingsHelper.registerThemeCallback(this);
		themeSettingsHelper.loadDefaultTheme(this);
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		if (mNetTipsReceiver != null) {
			unregisterReceiver(mNetTipsReceiver);
		}
		if (localManager != null) {
			localManager.removeAllActivities();
			localManager = null;
		}

		if (themeSettingsHelper != null) {
			themeSettingsHelper.unRegisterThemeCallback(this);
		}
	}

	private void getIntentData(Intent intent) {
		if (intent != null) {
			String str = intent.getStringExtra(Constants.WEIXIN_CHANNEL);
			if (str != null && mChannelList != null) {
				for (int i = 0; i < mChannelList.length; i++) {
					DynamicChannel channel = mChannelList[i];
					if (str.equals(channel.getChlid())) {
						nIndex = i;
						break;
					}
				}
			}

		}
	}

	private void initView() {
		ExtendedChannels mExtendedChannel = InfoConfigUtil.ReadExtendedChannels();
		mChannelList = mExtendedChannel.getChannellist();
		localManager = getLocalActivityManager();
		mTitleBar = (TitleBar) findViewById(R.id.extended_channel_title);
		mChannelViewPager = (ViewPagerEx) findViewById(R.id.extended_view_pager);
		mExtendedBar = (ChannelBarExtended) findViewById(R.id.extended_channel_bar);
		mNetTipsBar = (NetTipsBar) findViewById(R.id.extended_nettips_bar);
		mTitleBar.setTitleText(mExtendedChannel.getChlname());
	}

	private void registerNetTipsReceiver() {
		IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
		mNetTipsReceiver = new NetTipsReceiver(mHandler);
		this.registerReceiver(mNetTipsReceiver, filter);
	}

	private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if (msg != null && msg.obj != null) {
				Boolean isTips = (Boolean) msg.obj;
				setLayout(isTips.booleanValue());
			}
		}
	};

	private void setLayout(boolean bFlag) {
		if (nCount > 1) {
			mExtendedBar.setVisibility(View.VISIBLE);
			if (bFlag) {
				mNetTipsBar.setVisibility(View.GONE);
				FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) mChannelViewPager.getLayoutParams();
				lp.topMargin = MobileUtil.dpToPx(79);
				mChannelViewPager.setLayoutParams(lp);
			} else {
				mNetTipsBar.setVisibility(View.VISIBLE);
				FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) mChannelViewPager.getLayoutParams();
				lp.topMargin = MobileUtil.dpToPx(121);
				mChannelViewPager.setLayoutParams(lp);
			}
		} else {
			mExtendedBar.setVisibility(View.GONE);
			if (bFlag) {
				mNetTipsBar.setVisibility(View.GONE);
				FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) mChannelViewPager.getLayoutParams();
				lp.topMargin = MobileUtil.dpToPx(44);
				mChannelViewPager.setLayoutParams(lp);
			} else {
				mNetTipsBar.setVisibility(View.VISIBLE);
				FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) mChannelViewPager.getLayoutParams();
				lp.topMargin = MobileUtil.dpToPx(79);
				mChannelViewPager.setLayoutParams(lp);

				FrameLayout.LayoutParams lp1 = (FrameLayout.LayoutParams) mNetTipsBar.getLayoutParams();
				lp1.topMargin = MobileUtil.dpToPx(44);
				mNetTipsBar.setLayoutParams(lp1);
			}
		}
	}

	public void setRefreshData() {
		if (mCurrChannel < 0 || mCurrChannel >= mChannelList.length) {
			return;
		}
		DynamicChannel channel = mChannelList[mCurrChannel];
		Activity activity = (Activity) localManager.getActivity(channel.getChlid());
		if (activity != null && activity instanceof AbsChannelActivityNew) {
			((AbsChannelActivityNew) activity).getNewData();
		} else if (activity != null && activity instanceof WebSearchActivity) {
			((WebSearchActivity) activity).getNewData();
		}
	}

	private void initListener() {
		mTitleBar.setTopClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (mCurrChannel < 0 || mCurrChannel >= mChannelList.length) {
					return;
				}
				DynamicChannel channel = mChannelList[mCurrChannel];
				Activity activity = (Activity) localManager.getActivity(channel.getChlid());
				if (activity != null && activity instanceof AbsChannelActivityNew) {
					((AbsChannelActivityNew) activity).setSelection();
				}/*
				 * else if(activity != null && activity instanceof
				 * WebSearchActivity){
				 * ((WebSearchActivity)activity).setSeletionTop(); }
				 */
			}

		});

		mExtendedBar.setOnChannelBarClickListener(new ChannelBarClickListener() {
			@Override
			public void onSelected(int nIndex) {
				mCurrChannel = nIndex;
				mChannelViewPager.setCurrentItem(nIndex, false);
			}
		});
	}

	@Override
	public void applyTheme() {
		// Auto-generated method stub
		mTitleBar.applyTitleBarTheme(this);
		mExtendedBar.applyChannelBarTheme(this);
		mNetTipsBar.applyNetTipsBarTheme(this);
		themeSettingsHelper.setViewBackgroudColor(this, mChannelViewPager, R.color.viewpage_bg_color);

	}

	private Class<? extends Object> getClassName(DynamicChannel channel) {
		if (channel != null && channel.getType() != null) {
			if (channel.getType().equals("1")) {
				return ImportantNewsActivity.class;
			} else if (channel.getType().equals("2")) {
				return PhotoActivity.class;
			} else if (channel.getType().equals("3")) {
				return VideoActivity.class;
			} else if (channel.getType().equals("4")) {
				return ImportantNewsActivity.class;
			} else if (channel.getType().equals("5")) {
				return WebSearchActivity.class;
			}
		}
		return null;
	}

	public int getCurrExtendedChannel() {
		return this.mCurrChannel;
	}

	public void setActive(int nIndex) {
		mCurrChannel = nIndex;
		mExtendedBar.setActive(nIndex);
		mChannelViewPager.setCurrentItem(nIndex, false);
	}

	private void initViewPager() {
		mViews = new ArrayList<ActivityViewInfo>();
		if (null == mChannelList || mChannelList.length == 0) {
			return;
		}
		nCount = mChannelList.length;
		for (int i = 0; i < nCount; i++) {
			if (i < 2) {
				DynamicChannel channel = mChannelList[i];
				Intent intent = new Intent();
				intent.setClass(this, getClassName(channel));
				intent.putExtra(Constants.NEWS_CHLIDE_CHANNEL, channel.getChlid());
				intent.putExtra(Constants.IS_FROM_VIEWPAGER, true);
				intent.putExtra("url", channel.getUrl());
				intent.putExtra(Constants.IS_START_CHANNEL, i == 0 ? true : false);
				intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				Window mWindow = localManager.startActivity(channel.getChlid(), intent);
				ActivityViewInfo avInfo = new ActivityViewInfo(channel.getChlid(), mWindow.getDecorView());
				mViews.add(avInfo);
			} else {
				mViews.add(new ActivityViewInfo(null, null));
			}
		}
		mChannelViewPager.setOffscreenPageLimit(1);
		mChannelViewPager.setAdapter(new ExtendedChannelPagerAdapter(this, mViews));
		setActive(nIndex);
		mChannelViewPager.setOnPageChangeListener(new ExtendedOnPageChangeListener());
		mChannelViewPager.setPageMargin(2);
	}

	public class ExtendedChannelPagerAdapter extends PagerAdapter {

		private List<ActivityViewInfo> mListActivityViewInfos;
		private Context mContext;

		public ExtendedChannelPagerAdapter(Context mContext, List<ActivityViewInfo> mListActivityViews) {
			this.mContext = mContext;
			this.mListActivityViewInfos = mListActivityViews;
		}

		@Override
		public void destroyItem(View arg0, int arg1, Object arg2) {
			ActivityViewInfo avInfo = mViews.get(arg1);
			if (avInfo.mView != null) {
				localManager.destroyActivity(avInfo.mActivityId, true);
				((ViewPager) arg0).removeView(avInfo.mView);
				avInfo.mView = null;
				avInfo.mActivityId = null;
			}
		}

		@Override
		public void finishUpdate(View arg0) {

		}

		@Override
		public int getCount() {
			return mListActivityViewInfos.size();
		}

		@Override
		public Object instantiateItem(View arg0, int arg1) {
			ActivityViewInfo avinfo = mListActivityViewInfos.get(arg1);
			if (avinfo.mView == null) {
				DynamicChannel channel = mChannelList[arg1];
				if (channel == null) {
					return null;
				}
				Intent intent = new Intent();
				intent.setClass(mContext, getClassName(channel));
				intent.putExtra(Constants.NEWS_CHLIDE_CHANNEL, channel.getChlid());
				intent.putExtra(Constants.IS_FROM_VIEWPAGER, true);
				intent.putExtra("url", channel.getUrl());
				intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				if (channel.getChlid() != null && channel.getChlid() != "") {
					Window mWindow = localManager.startActivity(channel.getChlid(), intent);
					avinfo.mActivityId = channel.getChlid();
					avinfo.mView = mWindow.getDecorView();
				} else {
					avinfo.mActivityId = null;
					avinfo.mView = null;
				}
			}

			((ViewPager) arg0).addView(avinfo.mView, 0);
			return avinfo.mView;
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == (arg1);
		}

		@Override
		public void restoreState(Parcelable arg0, ClassLoader arg1) {
		}

		@Override
		public Parcelable saveState() {
			return null;
		}

		@Override
		public void startUpdate(View arg0) {
		}

		public int getItemPosition(Object object) {
			return POSITION_NONE;
		}
	}

	private class ExtendedOnPageChangeListener implements OnPageChangeListener {

		@Override
		public void onPageScrollStateChanged(int arg0) {
			// Auto-generated method stub

		}

		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {
			// Auto-generated method stub
			mExtendedBar.scrollBySlide(arg0, arg1);
		}

		@Override
		public void onPageSelected(int arg0) {
			// Auto-generated method stub
			mCurrChannel = arg0;
			// mExtendedBar.setActive(arg0);
			mExtendedBar.setFocusByImageViewBg(arg0);
			if (NetStatusReceiver.netStatus != NetStatusReceiver.NETSTATUS_INAVAILABLE) {
				Activity absChannel = (Activity) localManager.getActivity(mChannelList[arg0].getChlid());
				if (absChannel != null && absChannel instanceof AbsChannelActivityNew) {
					((AbsChannelActivityNew) absChannel).getNewDataSilent(false);
				} else if (absChannel != null && absChannel instanceof WebSearchActivity) {
					((WebSearchActivity) absChannel).getNewData();
					mWebCurrScreen = arg0;
				}
				if (mWebCurrScreen != -1) {
					Activity web = (Activity) localManager.getActivity(mChannelList[mWebCurrScreen].getChlid());
					if (web != null) {
						((WebSearchActivity) web).hideSoftKeyBoard();
					}
				}
			}
			mExtendedBar.setSelectedState(arg0);
		}

	}

	@Override
	protected void onResume() {
		super.onResume();
		WebDev.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		WebDev.onPause(this);
	}
}
