package com.tencent.news.download;

public interface AppPackageListener {
	
	void packageStateChanged(String packageName);
}
