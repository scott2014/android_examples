package com.tencent.news.download;

public class MobileAPKInfo {
	
	
	private String pagekageName;
	private int apkVersion;
	
	public String getPagekageName() {
		return pagekageName;
	}
	public void setPagekageName(String pagekageName) {
		this.pagekageName = pagekageName;
	}
	public int getApkVersion() {
		return apkVersion;
	}
	public void setApkVersion(int apkVersion) {
		this.apkVersion = apkVersion;
	}
	
	
}
