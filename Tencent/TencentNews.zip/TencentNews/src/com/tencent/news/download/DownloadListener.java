package com.tencent.news.download;

import java.util.List;

/**
 * 下载监听器
 * @author vincesun
 */
public interface DownloadListener {
	void onDownloadGetSizeFinish(Downloader downloader);
	void onDownloadInitFileError(Downloader downloader);
	void onDownloadBegin(Downloader downloader);
	void onDownloadPause(Downloader downloader,int n_progress);
	void onDownloadWait(Downloader downloader);
	void onDownloadUpdate(Downloader downloader,String progress,int n_progress);
	void onDownloadUpdate(List<Downloader> downloaders);
	void onDownloadError(Downloader downloader,int n_progress);
	void onDownloadFinish(Downloader downloader);
	void onDownloadDelete(Downloader downloader);
	void downloadUrlChangeError(Downloader downloader); 
	void installError(Downloader downloader);
	void installSucceed(String appid, String packageName,Downloader downloader);
	void uninstallSucceed(String appid, String packageName);
}
