package com.tencent.news.download;

/**
 * 下载任务
 * @author vincesun 
 */

public class DownloadTaskInfo {
	private Downloader downloader;
	private DownloadListener listener;
	
	public DownloadTaskInfo(Downloader downloader, DownloadListener listener) {
		this.downloader = downloader;
		this.listener = listener;
	}
	
	public Downloader getDownloader() {
		return downloader;
	}
	public void setDownloader(Downloader downloader) {
		this.downloader = downloader;
	}
	public DownloadListener getListener() {
		return listener;
	}
	public void setListener(DownloadListener listener) {
		this.listener = listener;
	}
	
	
}
