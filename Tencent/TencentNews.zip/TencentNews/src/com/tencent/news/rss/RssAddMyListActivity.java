package com.tencent.news.rss;

import java.util.List;

import com.tencent.news.R;
import com.tencent.news.cache.RssChannelSyncHelper;
import com.tencent.news.cache.UserDBHelper;
import com.tencent.news.command.HttpDataResponse;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.pojo.RssCatListCat;
import com.tencent.news.model.pojo.RssCatListItem;
import com.tencent.news.model.pojo.UserInfo;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.PullRefreshListView.OnRefreshListener;

import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;

public class RssAddMyListActivity extends RssAddBaseActivity {

    public static final String RSS_CAT_LIST      = "rss_cat_list";
    public static final String RSS_CHANNEL_INDEX = "index";
    public static final int    CAT_RSS           = 1;
    public static final int    My_RSS            = 1;

    @Override
    protected void initViews() {
        super.initViews();
        searchHeader.setVisibility(View.GONE);
        lv.setHasHeader(true);
        UserInfo uf = UserDBHelper.getInstance().getUserInfo();
        if (uf != null) {
            String name = RssAddBaseActivity.getUserName(uf, this);
            mTitleBar.ShowNewsBar(name);
        } else {
            mTitleBar.ShowNewsBar(this.getResources().getString(R.string.add_rss_channel));
        }
        mTitleBar.setHideShare();
        mTitleBar.setBackName("返回");
        formatData();
        showListView();
        refreshData();
    }

    /**
     * 创建我的列表
     */
    @Override
    protected void formatData() {
        super.formatData();
        List<RssCatListCat> mCatListCats = mCatList.getCats();
        int n = mCatListCats.size();
        for (int i = 0; i < n; i++) {
            RssCatListCat rssCatListCat = mCatListCats.get(i);
            List<RssCatListItem> channels = rssCatListCat.getChannels();
            int m = channels.size();
            for (int j = 0; j < m; j++) {
                RssCatListItem rssCatListItem = channels.get(j);
                String chlid = rssCatListItem.getChlid();
                Boolean isOrder = RssAddBaseActivity.getIsOrder(chlid);
                createSearchIndex(rssCatListItem);
                if (isOrder) {
                    RssAddListItem tmpRssAddListItem = new RssAddListItem(rssCatListItem, this, lv);
                    rssItems.add(tmpRssAddListItem);
                }
            }
        }
    }


    @Override
    protected void initListener() {
        super.initListener();
        mTitleBar.setBackClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                manageBackHandler();
            }

        });

        mListRootLayout.setRetryButtonClickedListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                mListRootLayout.showState(Constants.LOADING);
                TaskManager.startRunnableRequestInPool(new Runnable() {
                    @Override
                    public void run() {
                        refreshData();
                    }
                });
            }
        });

        lv.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh() {
                TaskManager.startRunnableRequestInPool(new Runnable() {
                    @Override
                    public void run() {
                        refreshData();
                    }
                });
            }
        });
    }

    /**
     * 刷新数据
     */
    private void refreshData() {
        RssChannelSyncHelper.getInstance().doSync(new HttpDataResponse() {

            @Override
            public void onHttpRecvOK(HttpTag tag, Object result) {
                Message msg = new Message();
                msg.what = REFRESH_LIST_ITEM;
                mHandler.sendMessage(msg);
                lv.onRefreshComplete(true);
            }

            @Override
            public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {
                lv.onRefreshComplete(true);
            }

            @Override
            public void onHttpRecvCancelled(HttpTag tag) {
                lv.onRefreshComplete(true);
            }

        });
    }

    /**
     * 返回事件处理函数
     */
    private void manageBackHandler() {
        Intent i = new Intent();
        Bundle bundle = new Bundle();
        bundle.putBoolean(RssAddMyListActivity.IS_REFRESH, true);
        i.putExtras(bundle);
        setResult(RESULT_OK, i);
        quitActivity();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            manageBackHandler();
        }
        return super.dispatchKeyEvent(event);
    }

}
