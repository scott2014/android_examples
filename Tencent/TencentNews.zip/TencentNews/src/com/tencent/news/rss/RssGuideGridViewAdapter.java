package com.tencent.news.rss;

import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.command.GetImageRequest;
import com.tencent.news.command.GetImageResponse;
import com.tencent.news.model.pojo.ImageResult;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.model.pojo.RssCatListItem;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.news.utils.ImageUtil;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.ThemeSettingsHelper;

public class RssGuideGridViewAdapter extends BaseAdapter implements GetImageResponse, OnItemClickListener {
    // private List<Boolean> isSelected;
    private Context mCtx;
    private GridView mGridView;
    private List<RssCatListItem> mData;
    private int mStart = 0;
    private int mSize = 0;
    private final static int IMAGE_SIZE_DP = 67-1;
    private int mImageSize;
    ThemeSettingsHelper mThemeSettingsHelper;

    public RssGuideGridViewAdapter(Context context, GridView gridview, List<RssCatListItem> data,
            int nStartIndex, int size) {
        mCtx = context;
        mGridView = gridview;
        mData = data;
        mStart = nStartIndex;
        mSize = size;
        mThemeSettingsHelper = ThemeSettingsHelper.getThemeSettingsHelper(mCtx);
        mImageSize = MobileUtil.dpToPx(IMAGE_SIZE_DP);
    }

    @Override
    public int getCount() {
        return mSize;
    }

    @Override
    public Object getItem(int arg0) {
        // TODO Auto-generated method stub
        return mData.get(mStart + arg0);
    }

    @Override
    public long getItemId(int arg0) {
        return arg0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        convertView = setViewValues(convertView, position, holder);
        return convertView;
    }

    @Override
    public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm, String path) {
        switch (imageType) {
            case PNG_IMAGE:
                Tag lTag = (Tag) tag;
                ViewHolder holder = (ViewHolder) mGridView.getChildAt(lTag.position).getTag();
                if (holder != null) {
                    Bitmap newbitmap = ImageUtil.resizeBitmapSmooth(bm, mImageSize, mImageSize);
                    ImageUtil.recycleBitmap(bm);
                    holder.rssImage.setImageBitmap(newbitmap);
                }
                break;
            default:
                break;
        }

    }

    @Override
    public void onImageRecvError(ImageType imageType, Object tag, int retCode) {
        // TODO Auto-generated method stub

    }

    public static class ViewHolder {
        String id;
        int positon;
        TextView rssTitle;
        ImageView rssImage;
        ImageView rssCheck;
        ImageView rssMask;
    }

    protected static class Tag {
        String id;
        int position;
    }

    private View setViewValues(View convertView, int position, ViewHolder holder) {
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = LayoutInflater.from(mCtx).inflate(R.layout.rss_guide_gridview_item, null);
            holder.rssImage = (ImageView) convertView.findViewById(R.id.rss_img);
            holder.rssTitle = (TextView) convertView.findViewById(R.id.rss_name);
            holder.rssCheck = (ImageView) convertView.findViewById(R.id.rss_check);
            holder.rssMask = (ImageView) convertView.findViewById(R.id.rss_mask);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        applyThemeInItem(holder);

        holder.positon = position;
        RssCatListItem item = mData.get(position + mStart);
        if (item == null || item.getChlid() == null) {
            return convertView;
        }
        holder.id = item.getChlid();

        // set text
        holder.rssTitle.setText(item.getChlname());
        // set check
        setCheck(holder, item);
        // set image
        setSingleImage(item, holder);
        return convertView;
    }

    // 夜间模式的处理
    private void applyThemeInItem(ViewHolder holder) {
        if (holder == null) {
            return;
        }

        mThemeSettingsHelper.setTextViewColor(mCtx, holder.rssTitle, R.color.list_title_color);
        mThemeSettingsHelper.setImageViewSrc(mCtx, holder.rssCheck, R.drawable.rss_selected);
        mThemeSettingsHelper.setImageViewSrc(mCtx, holder.rssMask, R.drawable.rss_guide_griditem_mask);
    }

    private void setCheck(ViewHolder holder, RssCatListItem item) {
        int visible = item.getRecommend().equalsIgnoreCase("1") ? View.VISIBLE : View.GONE;
        holder.rssCheck.setVisibility(visible);
    }

    private void setSingleImage(RssCatListItem item, ViewHolder holder) {

        if (item == null || holder == null || holder.id == null) {
            return;
        }

        String url = "";
        Bitmap bitmap = null;

        Tag tag = new Tag();
        tag.id = holder.id;
        tag.position = holder.positon;

        url = item.getIcon();

        if (!TextUtils.isEmpty(url)) {

            bitmap = getBitMapImage(item, tag, url);
            if (bitmap != null && holder.rssImage != null) {
                Bitmap newbitmap = ImageUtil.resizeBitmapSmooth(bitmap, mImageSize, mImageSize);
                ImageUtil.recycleBitmap(bitmap);
                holder.rssImage.setImageBitmap(newbitmap);
            }
        }
    }

    protected Bitmap getBitMapImage(RssCatListItem item, Tag tag, String url) {

        if (url == null || url == "") {
            return null;
        }

        Bitmap retBitmap = null;
        ImageResult result = null;
        GetImageRequest request = new GetImageRequest();

        request.setGzip(false);
        request.setTag(tag);
        request.setUrl(url);

        result = TaskManager.startPngImageTask(request, this);
        if (result.isResultOK() && result.getRetBitmap() != null) {
            retBitmap = result.getRetBitmap();
        } else {

            // TODO retBitmap = getDefaultBitmap(type);
        }
        return retBitmap;
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        RssCatListItem item = mData.get(position + mStart);

        if (item.getRecommend().equalsIgnoreCase("1")) {
            if (checkAtLeastOne()) {
                // pop up warning message
                TipsToast.getInstance().showTipsError(
                        mCtx.getResources().getString(R.string.add_rss_last_tips));
                return;
            }
            item.setRecommend("0");
        } else {
            item.setRecommend("1");
        }

        ViewHolder holder = (ViewHolder) view.getTag();
        setCheck(holder, item);
    }

    private boolean checkAtLeastOne() {

        int count = 0;
        RssCatListItem item;
        for (int i = 0; i < mData.size(); i++) {
            item = mData.get(i);
            if (item.getRecommend().equalsIgnoreCase("1")) {
                count++;
            }

        }

        return (count < 2);
    }
}
