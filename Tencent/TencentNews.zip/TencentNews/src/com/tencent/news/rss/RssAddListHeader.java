package com.tencent.news.rss;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.rss.RssAddListAdapter.RowType;

public class RssAddListHeader implements RssAddLvItem {
    private final String name;
    private final Boolean isSelected;
    private Context mContext;

    public RssAddListHeader(String name, Boolean isSelected, Context context) {
        mContext = context;
        this.name = name;
        this.isSelected = isSelected;
    }

    @Override
    public int getViewType() {
        return RowType.HEADER_ITEM.ordinal();
    }

    @Override
    public View getView(LayoutInflater inflater, View convertView) {
        View view;
        if (convertView == null) {
            if(RssAddBaseActivity.IS_NIGHT_THEME) {
                view = (View) inflater.inflate(R.layout.night_rss_add_list_header, null);
            } else {
                view = (View) inflater.inflate(R.layout.rss_add_list_header, null);                
            }
        } else {
            view = convertView;
        }
        TextView text = (TextView) view.findViewById(R.id.SeparatorTitle);
        if(isSelected) {
            Drawable img;
            if(RssAddBaseActivity.IS_NIGHT_THEME) {
                img = mContext.getResources().getDrawable(R.drawable.night_rss_hotnews_icon);
            } else {
                img = mContext.getResources().getDrawable(R.drawable.rss_hotnews_icon);                
            }
            img.setBounds(0, 0, 20, 24);
            text.setCompoundDrawables(img, null, null, null );
            text.setCompoundDrawablePadding(5);
        } else {
            text.setCompoundDrawables(null, null, null, null );
            text.setCompoundDrawablePadding(0);         
        }
        text.setText(name);
        return view;
    }
}