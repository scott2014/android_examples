package com.tencent.news.rss;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

public class RssAddListAdapter extends ArrayAdapter<RssAddLvItem> {
    
    private LayoutInflater mInflater;

    public enum RowType {
        LIST_ITEM, HEADER_ITEM, MORE_ITEM, MY_RSS
    }

    private List<RssAddLvItem> items;

    public RssAddListAdapter(Context context, List<RssAddLvItem> items) {
        super(context, 0, items);
        this.items = items;
        mInflater = LayoutInflater.from(context);
    }
    
    /**
     * 设置数据
     * @param items
     */
    public void setData(List<RssAddLvItem> items) {
        this.items = items;        
    }

    @Override
    public int getViewTypeCount() {
        return RowType.values().length;

    }

    @Override
    public int getItemViewType(int position) {
        return items.get(position).getViewType();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return items.get(position).getView(mInflater, convertView);
    }
}