package com.tencent.news.rss;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.View.OnTouchListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.Animation.AnimationListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;

import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.cache.RssCatListCache;
import com.tencent.news.cache.RssChannelSyncHelper;
import com.tencent.news.cache.RssChannelSyncHelper.IRssChannelChanged;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.pojo.RssCatList;
import com.tencent.news.model.pojo.RssCatListItem;
import com.tencent.news.model.pojo.RssCatListItemSearch;
import com.tencent.news.model.pojo.UserInfo;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.BaseActivity;
import com.tencent.news.ui.view.PullRefreshListView;
import com.tencent.news.ui.view.PullToRefreshFrameLayout;
import com.tencent.news.ui.view.TipsToast;
import com.tencent.news.ui.view.TitleBar;
import com.tencent.news.utils.SLog;

public class RssAddBaseActivity extends BaseActivity implements TextWatcher, IRssChannelChanged {
    protected static final int                   RENDER_LIST_VIEW  = 0;
    protected static final int                   UPDATE_LIST_VIEW  = 1;
    protected static final int                   REFRESH_LIST_ITEM = 2;
    protected static final int                   TARGET_MEDIA      = 3;
    public static final String                   IS_REFRESH        = "isRefresh";
    public static Boolean                        IS_NIGHT_THEME    = false;
    protected static final int                   LIST_MAX_NUM      = 3;
    protected Context                            mContext;
    protected static HashMap<String, Object>     myRssIds          = new HashMap<String, Object>();
    protected TitleBar                           mTitleBar;
    protected PullToRefreshFrameLayout           mListRootLayout;
    protected PullRefreshListView                lv;
    protected ListView                           searchListView;
    protected EditText                           inputSearch;
    protected Button                             searchBtnCancel;
    protected ImageView                          successTip;
    protected View                               rssAddMaskView;
    protected RelativeLayout                     searchHeader;
    protected RelativeLayout                     reLayout;
    protected RssCatList                         mCatList          = null;
    protected ArrayList<HashMap<String, String>> searchIndex       = new ArrayList<HashMap<String, String>>();
    protected HashMap<String, Object>            listItem          = new HashMap<String, Object>();
    protected List<RssAddLvItem>                 rssItems          = new ArrayList<RssAddLvItem>();
    protected RssCatListCache                    rssCatListCache;
    protected RssAddListAdapter                  adapter;
    protected int                                listPosition      = 3;
    protected RssHandler                         mHandler;
    private Animation                            fadeupAnim;
    private final String                         RSS_MANAGE_TAG    = "rss_manage";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        if (themeSettingsHelper.isDefaultTheme()) {
            IS_NIGHT_THEME = false;
            setContentView(R.layout.rss_add_layout);
        } else {
            IS_NIGHT_THEME = true;
            setContentView(R.layout.night_rss_add_layout);
        }
        initData();
        initViews();
        initListener();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        RssChannelSyncHelper.getInstance().unregChangeListener(this);
    }

    /**
     * 初始化
     */
    protected void initViews() {
        mHandler = new RssHandler(this);
        mTitleBar = (TitleBar) findViewById(R.id.rss_title_bar);
        mTitleBar.ShowElseBar(R.string.rss_manage_title);
        rssAddMaskView = (View) findViewById(R.id.rss_add_mask_view);
        mListRootLayout = (PullToRefreshFrameLayout) findViewById(R.id.list_content);
        lv = mListRootLayout.getPullToRefreshListView();
        lv.setPullTimeTag(RSS_MANAGE_TAG);
        lv.setHasHeader(false);
        inputSearch = (EditText) findViewById(R.id.inputSearch);
        searchBtnCancel = (Button) findViewById(R.id.search_btn_cancel);
        searchListView = (ListView) findViewById(R.id.rss_search_list_view);
        successTip = (ImageView) findViewById(R.id.success_tip);
        searchHeader = (RelativeLayout) findViewById(R.id.SearchHeader);
        reLayout = (RelativeLayout) findViewById(R.id.reLayout);
    }

    /**
     * 显示成功的提示
     */
    public void showSuccessTip(final View clickedView) {
        fadeupAnim = AnimationUtils.loadAnimation(this, R.anim.plus_up);
        LayoutParams lp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        Rect rect = new Rect();
        clickedView.getGlobalVisibleRect(rect);
        lp.setMargins(rect.left, rect.top - clickedView.getHeight(), 0, 0);
        successTip.setLayoutParams(lp);
        successTip.setVisibility(View.VISIBLE);
        successTip.startAnimation(fadeupAnim);
        fadeupAnim.setAnimationListener(new AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                successTip.setVisibility(View.GONE);
            }
        });
    }

    /**
     * 刷新当前的Active, 订阅数，登录状态等
     */
    public void refreshActivity() {
        Log.i("refreshActivity:", "start");
        initData();
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
    }

    /**
     * 创建搜索索引
     */
    protected void createSearchIndex(RssCatListItem rssCatListItem) {
        if (rssCatListItem.getAlias() != null) {
            String chlid = rssCatListItem.getChlid();
            RssCatListItemSearch[] alias = rssCatListItem.getAlias();
            int n = alias.length;
            for (int i = 0; i < n; i++) {
                RssCatListItemSearch tmpSearch = alias[i];
                String token = tmpSearch.getToken().toLowerCase(Locale.getDefault());
                if ("0".equals(tmpSearch.getFlag())) {
                    createSearchSubIndex(token, chlid);
                } else {
                    token = token.replace(";", "");
                    HashMap<String, String> tmpItem = new HashMap<String, String>();
                    tmpItem.put("token", token);
                    tmpItem.put("chlid", chlid);
                    searchIndex.add(tmpItem);
                }
            }
            if (null != rssCatListItem.getChlname()) {
                HashMap<String, String> tItem = new HashMap<String, String>();
                tItem.put("token", rssCatListItem.getChlname());
                tItem.put("chlid", chlid);
                searchIndex.add(tItem);
            }
            listItem.put(chlid, rssCatListItem);
        }
    }

    /**
     * 创建索引
     * 
     * @param k
     * @return
     */
    protected void createSearchSubIndex(String k, String chlid) {
        String[] s = k.split(",");
        int n = s.length;
        for (int i = 0; i < n; i++) {
            String query = s[i];
            if (null != query) {
                HashMap<String, String> tItem = new HashMap<String, String>();
                tItem.put("token", query);
                tItem.put("chlid", chlid);
                searchIndex.add(tItem);
            }
        }
    }

    /**
     * 初始化数据
     */
    protected void initData() {
        getMyRssIds();
        rssCatListCache = new RssCatListCache("rssCatList");
        mCatList = rssCatListCache.getCacheData();
    }

    /**
     * 获取元素列表转换成hashMap
     */
    public static void getMyRssIds() {
        myRssIds = new HashMap<String, Object>();
        List<String> myRssIdsList = RssChannelSyncHelper.getInstance().getRssChannelIds();
        Log.i("isOrder", "getOrder:" + myRssIdsList);
        int n = myRssIdsList.size();
        for (int i = 0; i < n; i++) {
            String ids = myRssIdsList.get(i);
            if (ids != null) {
                myRssIds.put(ids, true);
            }
        }
    }

    /**
     * 判断是否订阅
     */
    public static Boolean getIsOrder(String child) {
        return (Boolean) myRssIds.get(child) != null ? true : false;
    }

    /**
     * 删除订阅频道
     * 
     * @param child
     * @return
     */
    public static void delChannnel(String child) {
        if (myRssIds.get(child) != null) {
            myRssIds.remove(child);
        }
    }

    /**
     * 删除订阅频道
     * 
     * @param child
     * @return
     */
    public static void addChannnel(String child) {
        myRssIds.put(child, true);
    }

    /**
     * 获取用户名称
     */
    public static String getUserName(UserInfo userInfo, Context context) {
        String name = userInfo.getNick();
        if (TextUtils.isEmpty(name) && name.trim().length() < 1) {
            name = userInfo.getQqnick();
            if (TextUtils.isEmpty(name) && name.trim().length() < 1) {
                name = userInfo.getAccount();
                if (TextUtils.isEmpty(name) && name.trim().length() < 1) {
                    name = context.getResources().getString(R.string.default_user);
                }
            }
        }
        return name;
    }

    /**
     * 我的订阅至少保留1个，并给予提示
     * 
     * @param child
     * @param context
     * @return
     */
    public static Boolean isLastMyRss(String child, Context context) {
        getMyRssIds();
        if (myRssIds.size() <= 1) {
            TipsToast.getInstance().showTipsError(context.getResources().getString(R.string.add_rss_last_tips));
            return true;
        }
        return false;
    }

    /**
     * 从loading过渡到listView的显示
     */
    protected void loadingToListView() {
        mListRootLayout.showState(Constants.LIST);
    }

    /**
     * 搜索内容
     */
    protected List<RssAddLvItem> filterSearchDataByChar(CharSequence cs) {
        List<RssAddLvItem> tmpRssItems = new ArrayList<RssAddLvItem>();
        String s = String.valueOf(cs).toLowerCase(Locale.getDefault());
        HashMap<String, Object> tmpSearch = new HashMap<String, Object>();
        int n = searchIndex.size();
        for (int i = 0; i < n; i++) {
            HashMap<String, String> valHashMap = searchIndex.get(i);
            String key = valHashMap.get("token");
            String val = valHashMap.get("chlid");
            Boolean isSearch = (Boolean) tmpSearch.get(val);
            if (key.indexOf(s) == 0 && isSearch == null) {
                RssCatListItem rssCatListItem = (RssCatListItem) listItem.get(val);
                RssAddListItem tmpRssAddListItem = new RssAddListItem(rssCatListItem, this, lv);
                tmpRssItems.add(tmpRssAddListItem);
                tmpSearch.put(val, true);
            }
        }
        return tmpRssItems;
    }

    /**
     * 创建ui线程消息接受，防止内存泄漏
     * 
     * @author zhishouwang
     * 
     */
    protected static class RssHandler extends Handler {
        protected WeakReference<RssAddBaseActivity> mOuterClass;

        RssHandler(RssAddBaseActivity rssAddBaseActivity) {
            mOuterClass = new WeakReference<RssAddBaseActivity>(rssAddBaseActivity);
        }

        @Override
        public void handleMessage(android.os.Message msg) {
            super.handleMessage(msg);
            RssAddBaseActivity mTheClass = mOuterClass.get();
            if (msg != null) {
                switch (msg.what) {
                    case RENDER_LIST_VIEW:
                        mTheClass.formatData();
                        mTheClass.showListView();
                        break;
                    case UPDATE_LIST_VIEW:
                        mTheClass.initData();
                        mTheClass.formatData();
                        mTheClass.updateListItem();
                        break;
                    case REFRESH_LIST_ITEM:
                        mTheClass.initData();
                        mTheClass.formatData();
                        mTheClass.updateListItem();
                        break;
                    default:
                        break;
                }
            }
        }
    }

    /**
     * 获取所有订阅媒体和分类 先判断是否有缓存，然后获取新闻内容
     */
    protected void getCatListData() {
        TaskManager.startRunnableRequest(new Runnable() {
            @Override
            public void run() {
                HttpDataRequest request = TencentNews.getInstance().getCatList();
                Map<String, String> urlParams = new HashMap<String, String>();
                if (mCatList != null && mCatList.getVersion() != null) {
                    Message msg = new Message();
                    msg.what = RENDER_LIST_VIEW;
                    mHandler.sendMessage(msg);
                    urlParams.put("version", mCatList.getVersion());
                } else {
                    urlParams.put("version", "0");
                }
                request.setUrlParams(urlParams);
                TaskManager.startHttpDataRequset(request, RssAddBaseActivity.this);
            }
        });
    }

    protected void formatData() {
        rssItems = new ArrayList<RssAddLvItem>();
        searchIndex = new ArrayList<HashMap<String, String>>();
        listItem = new HashMap<String, Object>();
    }

    /**
     * 显示listView
     */
    protected void showListView() {
        loadingToListView();
        setAdapter(rssItems);
    }

    /**
     * 刷新listItem
     */
    private void updateListItem() {
        if (adapter != null) {
            setAdapter(rssItems);
        }
    }

    /**
     * 更新ListView
     */
    protected void updateListView() {
        if (adapter != null) {
            adapter.setData(rssItems);
            adapter.notifyDataSetChanged();
        }
    }

    /**
     * 显示错误提示
     */
    protected void showErrorView() {
        mListRootLayout.showState(Constants.ERROR);
    }

    /**
     * 显示loading页面
     */
    protected void showLoadingView() {
        mListRootLayout.showState(Constants.LOADING);
    }

    /**
     * 设置内容适配
     */
    protected void setAdapter(List<RssAddLvItem> rssItems2) {
        adapter = new RssAddListAdapter(this, rssItems2);
        lv.setAdapter(adapter);
    }

    /**
     * 重置初始化状态
     */
    protected void resetInitState() {
        searchListView.setVisibility(View.GONE);
    }

    /**
     * 搜索部分UI样式切换
     * 
     * @param hasFocus
     */
    protected void searchUISwitch(boolean hasFocus) {
        if (hasFocus) {
            searchBtnCancel.setVisibility(View.VISIBLE);
            mTitleBar.setVisibility(View.GONE);
            rssAddMaskView.setVisibility(View.VISIBLE);
        } else {
            searchBtnCancel.setVisibility(View.GONE);
            mTitleBar.setVisibility(View.VISIBLE);
            rssAddMaskView.setVisibility(View.GONE);
        }
    }

    /**
     * 关闭搜索功能UI
     */
    protected void disableSearchBar() {
        inputSearch.setText("");
        inputSearch.clearFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(inputSearch.getWindowToken(), 0);
        refreshActivity();
    }

    /**
     * 给布局文件中的view设置事件监听
     */
    protected void initListener() {

        inputSearch.addTextChangedListener(this);
        inputSearch.setOnFocusChangeListener(new OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                searchUISwitch(hasFocus);
            }
        });

        searchBtnCancel.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                disableSearchBar();
            }
        });

        rssAddMaskView.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                disableSearchBar();
                return true;
            }
        });

        lv.setOnScrollListener(new OnScrollListener() {
            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
            }

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                listPosition = lv.getFirstVisiblePosition();
            }
        });

        mTitleBar.setTopClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                lv.smoothScrollToPosition(0);
            }
        });

        RssChannelSyncHelper.getInstance().regChangeListener(this);
    }

    @Override
    public void afterTextChanged(Editable s) {

    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        if (s == null || String.valueOf(s).equals("")) {
            resetInitState();
            return;
        }
        List<RssAddLvItem> p = filterSearchDataByChar(s);
        if (p != null && p.size() > 0) {
            RssAddListAdapter adapter = new RssAddListAdapter(this, p);
            searchListView.setAdapter(adapter);
            searchListView.setVisibility(View.VISIBLE);
        } else {
            searchListView.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        refreshActivity();
    }

    @Override
    public void applyTheme() {
        super.applyTheme();
        mTitleBar.applyTitleBarTheme(this);
        if (mListRootLayout != null) {
            mListRootLayout.applyFrameLayoutTheme();
        }
        if(lv != null) {
            themeSettingsHelper.setViewBackgroudColor(this, this.lv, R.color.view_bg_color);            
        }
    }

    @Override
    public void onChannelChange() {
        refreshActivity();
    }

    @Override
    public void onHttpRecvOK(HttpTag tag, Object result) {
        if (tag.equals(HttpTag.GET_RSS_CAT_LIST)) {
            lv.setPullTimeTag(RSS_MANAGE_TAG);
            RssCatList tmpCatList = (RssCatList) result;
            if (tmpCatList.getRet().equals("0")) {
                if (mCatList != null && mCatList.getVersion() != null) {
                    rssCatListCache.updateCacheData(tmpCatList);
                    mCatList = rssCatListCache.getCacheData();
                    Message msg = new Message();
                    msg.what = UPDATE_LIST_VIEW;
                    mHandler.sendMessage(msg);
                } else {
                    rssCatListCache.setCacheData(tmpCatList);
                    mCatList = rssCatListCache.getCacheData();
                    Message msg = new Message();
                    msg.what = RENDER_LIST_VIEW;
                    mHandler.sendMessage(msg);
                }
            }
        }
    }

    @Override
    public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {
        lv.setPullTimeTag(RSS_MANAGE_TAG);
        if (mCatList != null && mCatList.getVersion() != null) {

        } else {
            showErrorView();
        }
    }

    @Override
    public void onHttpRecvCancelled(HttpTag tag) {
        lv.setPullTimeTag(RSS_MANAGE_TAG);
        SLog.v("加载失败!");
        if (mCatList != null && mCatList.getVersion() != null) {

        } else {
            showErrorView();
        }

    }
}
