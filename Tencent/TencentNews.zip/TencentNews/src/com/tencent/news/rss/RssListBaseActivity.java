
package com.tencent.news.rss;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.cache.RssChannelSyncHelper;
import com.tencent.news.cache.RssItemsCacheManager;
import com.tencent.news.cache.RssItemsCacheManager.StatusListener;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.SettingInfo;
import com.tencent.news.model.pojo.Item;
import com.tencent.news.model.pojo.RssItemsByLoadMore;
import com.tencent.news.model.pojo.RssItemsByRefresh;
import com.tencent.news.system.NetStatusReceiver;
import com.tencent.news.system.NetTipsReceiver;
import com.tencent.news.system.NewsHadReadReceiver;
import com.tencent.news.system.observable.SettingObservable;
import com.tencent.news.system.observer.SettingObserver;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.AbsNewsActivity;
import com.tencent.news.ui.BaseActivity;
import com.tencent.news.ui.ImageDetailActivity;
import com.tencent.news.ui.ImgTxtLiveActivity;
import com.tencent.news.ui.NewsDetailActivity;
import com.tencent.news.ui.SpecialListActivity;
import com.tencent.news.ui.WebDetailActivity;
import com.tencent.news.ui.adapter.RssNewsListAdapter;
import com.tencent.news.ui.view.NetTipsBar;
import com.tencent.news.ui.view.PullRefreshListView;
import com.tencent.news.ui.view.TitleBar;
import com.tencent.news.ui.view.PullRefreshListView.OnClickFootViewListener;
import com.tencent.news.ui.view.PullRefreshListView.OnRefreshListener;
import com.tencent.news.ui.view.PullToRefreshFrameLayout;
import com.tencent.news.utils.SLog;
import com.tencent.news.utils.StringUtil;

import java.util.List;

public abstract class RssListBaseActivity extends BaseActivity implements StatusListener,
        SettingObserver {

    /**
     * 用于： 1. 下拉刷新的tag 2. 接收已读新闻的广播intent （Constants.NEWS_HAD_READ_ACTION +
     * getRssContentTag()） 3. 缓存的保存文件名 "rss_" + value 4. 刷新是的频道id参数
     * 
     * @return 一般可以返回该rss频道对应的id。聚合页除外
     */
    protected abstract String getRssContentTag();
    protected abstract void doRefresh();
    protected abstract String getSubClassName();

    private RssItemsCacheManager mCache;
    private PullToRefreshFrameLayout mListRootLayout;
    private PullRefreshListView mListView;
    private RssNewsListAdapter mAdapter;
    private boolean refreshed = false;
    private boolean mIsStyleMode;
    private NewsHadReadReceiver mNewsReadReceiver;

    protected TitleBar mTitleBar = null;
    protected NetTipsBar mNetTipsBar = null;
    protected NetTipsReceiver mNetTipsReceiver;

    private final int HANDLE_UPDATE = 100;
    private long mLastRefreshTime = 0;
    private boolean isBusy = false;

    private Handler mHandler = new Handler() {
        @SuppressWarnings("unchecked")
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case HANDLE_UPDATE:
                    updateData(msg.arg1, (List<Item>) msg.obj);
                    break;

                default:
                    super.handleMessage(msg);
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    
    // 之类初始化完后调用
    protected void init() {
        initViews();
        initListener();
        initNetTips();
        mListRootLayout.showState(Constants.LOADING);
        initData();
        registerBroadcastReceiver();
        SettingObservable.getInstance().registerObserver(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        SettingObservable.getInstance().removeObserver(this);
        if (mNewsReadReceiver != null) {
            try {
                unregisterReceiver(mNewsReadReceiver);
            } catch (Exception e) {
                SLog.e(e.toString());
            }
        }
        if (mNetTipsReceiver != null) {
            unregisterReceiver(mNetTipsReceiver);
            mNetTipsReceiver = null;
        }
    }

    private void initViews() {
        mTitleBar = (TitleBar) findViewById(R.id.rss_title_bar);
        mNetTipsBar = (NetTipsBar) findViewById(R.id.rss_nettips_bar);
        mListRootLayout = (PullToRefreshFrameLayout) findViewById(R.id.list_content);
        mListView = mListRootLayout.getPullToRefreshListView();
        mListView.setPullTimeTag(getRssContentTag());
        mAdapter = new RssNewsListAdapter(this, mListView);
        mListView.setAdapter(mAdapter);
    }

    private void initListener() {
        mListRootLayout.setRetryButtonClickedListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                mListRootLayout.showState(Constants.LOADING);
                TaskManager.startRunnableRequestInPool(new Runnable() {
                    @Override
                    public void run() {
                        mCache.getData(0);
                    }
                });
            }
        });

        mTitleBar.setTopClickListener(new OnClickListener(){
            @Override
            public void onClick(View v) {
                if (mListView != null) {
                    mListView.setSelection(0);
                }
            }
        });
        
        mListView.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh() {
                onPullToRefresh();
            }
        });

        mListView.setOnClickFootViewListener(new OnClickFootViewListener() {

            @Override
            public void onClickFootView() {
                TaskManager.startRunnableRequestInPool(new Runnable() {
                    @Override
                    public void run() {
                        getMoreData();
                    }
                });
            }
        });

        mListView.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                startNextActivity(position);
            }
        });
    }
    
    protected void onPullToRefresh() {
        TaskManager.startRunnableRequestInPool(new Runnable() {
            @Override
            public void run() {
                refreshData(true);
            }
        });
    }

    protected void setLayout(boolean bFlag) {
        if (mNetTipsBar != null) {
            if (bFlag) {
                mNetTipsBar.setVisibility(View.GONE);
            } else {
                mNetTipsBar.setVisibility(View.VISIBLE);
            }
        }
    }

    private void initNetTips() {
        if (NetStatusReceiver.netStatus == NetStatusReceiver.NETSTATUS_INAVAILABLE) {
            setLayout(false);
        } else {
            setLayout(true);
        }
    }

    private void registerBroadcastReceiver() {
        IntentFilter filter1 = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        mNetTipsReceiver = new NetTipsReceiver(mNetTipsBar);
        this.registerReceiver(mNetTipsReceiver, filter1);

        mNewsReadReceiver = new NewsHadReadReceiver(getRssContentTag(), mAdapter, null);
        IntentFilter filter2 = new IntentFilter(Constants.NEWS_HAD_READ_ACTION + getRssContentTag());
        registerReceiver(mNewsReadReceiver, filter2);
    }

    private void initData() {
        SettingInfo settingInfo = SettingObservable.getInstance().getData();
        mIsStyleMode = settingInfo.isIfTextMode();

        mCache = new RssItemsCacheManager(getRssContentTag(), this);
        if (!mCache.getData(0)) {
            refreshData(false);
        }
    }

    /**
     * 
     * @param force true: 忽略上次刷新时间，立即刷新
     */
    protected void refreshData(boolean force) {
        if (isBusy) {
            return;
        }
        if(force || (System.currentTimeMillis() - mLastRefreshTime > 600 * 1000)) {
            isBusy = true;
            doRefresh();
        }
    }
    
    private void getMoreData() {
        mCache.getData(mAdapter.getCount());
    }

    @Override
    public void onHttpRecvOK(HttpTag tag, Object result) {
        if (tag.equals(HttpTag.RSS_INDEX_ANDITEMS) ||
                tag.equals(HttpTag.RSS_INDEX_ANDITEMS_MULTI)) {
            isBusy = false;
            mLastRefreshTime = java.lang.System.currentTimeMillis();
            boolean refresh = tag.equals(HttpTag.RSS_INDEX_ANDITEMS_MULTI);
            refreshed = true;
            RssItemsByRefresh rssItemList = (RssItemsByRefresh) result;
            rssItemList.setDataIsRss();
            if (rssItemList.getRet().equals("0")) {
                mCache.updateByRefresh(rssItemList.getIds(), rssItemList.getNewslist());
                RssChannelSyncHelper.getInstance().syncRssChannel(rssItemList.getVersion(), rssItemList.getUserSubList(), false);
            }
            mListView.onRefreshComplete(true);
            mCache.getData(refresh ? 0 : mAdapter.getCount());
        } else if (tag.equals(HttpTag.RSS_LIST_ITEMS)) {
            isBusy = false;
            RssItemsByLoadMore rssItemList = (RssItemsByLoadMore) result;
            rssItemList.setDataIsRss();
            if (rssItemList.getRet().equals("0") || 
                    rssItemList.getRet().equals("1")) {
                mCache.updateByLoadMore(mAdapter.getCount(), rssItemList.getNewslist());
            }
            mCache.getData(mAdapter.getCount());
        }
    }

    @Override
    public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {
        if (tag.equals(HttpTag.RSS_INDEX_ANDITEMS) ||
                tag.equals(HttpTag.RSS_INDEX_ANDITEMS_MULTI)) {
            isBusy = false;
            refreshed = true;
            if (mAdapter.getCount() > 0) {
                mListRootLayout.showState(Constants.LIST);
                mListView.onRefreshComplete(false);
                mListView.setFootViewAddMore(false, true, true);
            } else {
                // 通过用户取消的防止出现错误界面
                mListRootLayout.showState(Constants.ERROR);
            }
        } else if (tag.equals(HttpTag.RSS_LIST_ITEMS)) {
            isBusy = false;
            if (mAdapter == null || mAdapter.getCount() == 0) {
                mListRootLayout.showState(Constants.EMPTY);
            }
            mListView.setFootViewAddMore(true, true, true);
        }
    }

    @Override
    public void onHttpRecvCancelled(HttpTag tag) {
        if (tag.equals(HttpTag.RSS_INDEX_ANDITEMS) ||
                tag.equals(HttpTag.RSS_INDEX_ANDITEMS_MULTI)) {
            isBusy = false;
            refreshed = true;
            if (mAdapter.getCount() > 0) {
                mListRootLayout.showState(Constants.LIST);
                mListView.onRefreshComplete(false);
            }
        } else if (tag.equals(HttpTag.RSS_LIST_ITEMS)) {
            isBusy = false;
            if (mListView != null) {
                mListView.setFootViewAddMore(true, true, true);
            }
        }
    }

    @Override
    public void onLoadStart() {
    }

    @Override
    public void onNeedMore(List<String> needIds) {
        if (!isBusy && refreshed) {
            String ids = StringUtil.List2String(needIds);
            HttpDataRequest request = TencentNews.getInstance().getSubNewsListItems(ids);
            TaskManager.startHttpDataRequset(request, this);
        }
    }

    @Override
    public void onNeedRefresh() {
        refreshData(true);
    }

    @Override
    public void onCacheLoadFinish(int startIndex, List<Item> newItemsList) {
        mHandler.sendMessage(mHandler.obtainMessage(HANDLE_UPDATE, startIndex, 0, newItemsList));
    }

    private void updateData(int startIndex, List<Item> newItemsList) {
        if (startIndex == 0) {
            mAdapter.clearAdapterListData();
        }
        
        if (newItemsList != null) {
            if (!(mAdapter.getCount() == 0 && newItemsList.size() == 0)) {
                mAdapter.addMoreDataList(newItemsList);
                mListRootLayout.showState(Constants.LIST);
            }
            mListView.setFootViewAddMore(true,
                    mCache.hasMoreData(mAdapter == null ? 0 : mAdapter.getCount()), false);
        } else {
            mListRootLayout.showState(Constants.LIST);
            mListView.setFootViewAddMore(true,
                    mCache.hasMoreData(mAdapter == null ? 0 : mAdapter.getCount()), false);
        }
        mAdapter.notifyDataSetChanged();
    }

    private Class<? extends Object> getClassName(Item item) {
        if (item != null) {
            if (item.getArticletype().equals("1")) {
                return ImageDetailActivity.class;
            } else if (item.getArticletype().equals("5")) {
                return WebDetailActivity.class;
            } else if (item.getArticletype().equals("100")) {
                return SpecialListActivity.class;
            } else if (item.getArticletype().equals("7")) {
                return ImgTxtLiveActivity.class;
            }
        }
        return NewsDetailActivity.class;
    }

    private void startNextActivity(int position) {
        Intent intent = new Intent();

        int nClickPosition = position - mListView.getHeaderViewsCount();
        if (mAdapter != null && nClickPosition >= 0) {
            Item item = mAdapter.getObjectItem(nClickPosition);
            SLog.i("AbsChannelActivityNew", getClassName(item).toString());
            if (item != null && getClassName(item) != null) {
                Bundle bundle = new Bundle();
                bundle.putSerializable(Constants.NEWS_DETAIL_KEY, item);
                bundle.putString(Constants.NEWS_CHANNEL_CHLID_KEY, item.getChlid());
                bundle.putString(Constants.NEWS_DETAIL_TITLE_KEY, item.getChlname());
                bundle.putString(Constants.NEWS_CLICK_ITEM_POSITION, "" + nClickPosition);
                bundle.putString(Constants.NEWS_ITEM_READ_BROADCAST, 
                        Constants.NEWS_HAD_READ_ACTION + getRssContentTag());
                bundle.putString(AbsNewsActivity.ACTIVITY_OPEN_FROM, getSubClassName());
                
                intent.putExtras(bundle);
                intent.setClass(this, getClassName(item));
                startActivity(intent);
            }
        }
    }

    @SuppressLint("ResourceAsColor")
    @Override
    public void applyTheme() {
        mNetTipsBar.applyNetTipsBarTheme(this);

        if (mAdapter != null) {
            mAdapter.notifyDataSetChanged();
        }
        if (mListRootLayout != null) {
            mListRootLayout.applyFrameLayoutTheme();
        }

        themeSettingsHelper.setViewBackgroudColor(this, this.mListView, R.color.timeline_home_bg_color);
        themeSettingsHelper.setListViewSelector(this, this.mListView, R.drawable.none_selector);
    }

    synchronized public void onRefreshClick() {
        if (mListView != null) {
            mListView.startUpdateImmediate();
        }
    }
    
    @Override
    public void updateSetting(SettingInfo setting) {
        if (mListView != null && setting != null) {
            mListView.setAutoLoading(setting.isIfAutoLoadMore());
        }
        if (mAdapter != null && mListView != null && mIsStyleMode != setting.isIfTextMode()) {
            mIsStyleMode = setting.isIfTextMode();
            if (setting.isIfTextMode()) {
                mAdapter.changeStyleMode(Constants.TYPE_ITEM_TEXT);
            } else {
                mAdapter.changeStyleMode(Constants.TYPE_ITEM_IMAGE);
            }
        }
    }
}
