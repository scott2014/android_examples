
package com.tencent.news.rss;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.LinearLayout.LayoutParams;

import com.tencent.news.R;
import com.tencent.news.api.TencentNews;
import com.tencent.news.cache.RssChannelSyncHelper;
import com.tencent.news.cache.RssChannelSyncHelper.IRssChannelChanged;
import com.tencent.news.cache.UserDBHelper;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.config.Constants;
import com.tencent.news.shareprefrence.SpConfig;
import com.tencent.news.shareprefrence.SpUserHelp;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.LoginActivity;
import com.tencent.news.ui.view.TitleBar;

public class RssActivity extends RssListBaseActivity implements IRssChannelChanged {
    public static final String RSS_MULTI_REFRESH_FINISH = "rss_multi_refresh_finish";

    private FrameLayout mActivityRootLayout;
    private AlertDialog mDialog;

    private final String RSS_PAGE_TAG = "rss_main";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rss_layout);
        initViews();
        checkShowHelp();
        initListener();
        super.init();
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        refreshData(SpConfig.getHasNewRSS());
        SpConfig.setHasNewRSS(false);
        SpConfig.setRSSRefreshTime(System.currentTimeMillis());
    }
    
    @Override
    protected String getRssContentTag() {
        return RSS_PAGE_TAG;
    }
    
    @Override
    protected void onPause() {
        super.onPause();
        if (mDialog != null) {
            mDialog.dismiss();
            mDialog = null;
        }
    }

    private void initViews() {
        mActivityRootLayout = (FrameLayout) findViewById(R.id.rss_activity_root);
        mTitleBar = (TitleBar) findViewById(R.id.rss_title_bar);
        mTitleBar.showAddRssChannelBtn(R.string.add_rss_channel);
    }

    private void initListener() {
        RssChannelSyncHelper.getInstance().regChangeListener(this);
        mTitleBar.setAddRssClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                onAddRssChannelBtnClick();
            }
        });
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        RssChannelSyncHelper.getInstance().unregChangeListener(this);
    }

    @Override
    public void applyTheme() {
        super.applyTheme();
         mTitleBar.applyTitleBarTheme(this);
    }
    
    private void checkShowHelp() {
        if (SpUserHelp.getRssListHelp()) {
            View v = new View(this);
            v.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT));
            v.setBackgroundResource(R.drawable.rss_list_help);
            mActivityRootLayout.addView(v);
            v.setOnClickListener(new OnClickListener() {

                @Override
                public void onClick(View v) {
                    mActivityRootLayout.removeView(v);
                    SpUserHelp.setRssListHelp(false);
                }
            });
        }
    }

    private void onAddRssChannelBtnClick() {
        if (UserDBHelper.getInstance().getUserInfo() == null && !SpConfig.getRssLoginAlert()) {
            mDialog = new AlertDialog.Builder(this).setTitle("登录选项")
                    .setMessage("登录后可实现云同步，数据永不丢失")
                    // .setIcon(android.R.drawable.ic_dialog_info)
                    // .setView(layout)
                    .setCancelable(false)
                    .setNegativeButton("不了，谢谢", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            showRssChannelListActivity();
                            SpConfig.setRssLoginAlert(true);
                        }
                    }).setPositiveButton("立即登陆", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent loginIntent = new Intent();
                            loginIntent.setClass(RssActivity.this, LoginActivity.class);
                            loginIntent.putExtra(Constants.LOGIN_FROM,
                                    Constants.LOGIN_FROM_RSS_ADD);
                            startActivityForResult(loginIntent, Constants.REQUEST_CODE_LOGIN);
                            SpConfig.setRssLoginAlert(true);
                        }
                    }).setOnKeyListener(new OnKeyListener() {
                        @Override
                        public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                            if (keyCode == KeyEvent.KEYCODE_BACK) {
                                if (mDialog != null) {
                                    mDialog.dismiss();
                                    mDialog = null;
                                    SpConfig.setRssLoginAlert(true);
                                }
                                return true;
                            }
                            return false;
                        }
                    }).create();
            mDialog.show();
        } else {
            showRssChannelListActivity();
        }
    }

    private void showRssChannelListActivity() {
        Intent intent = new Intent();
        Bundle bundle = new Bundle();
        bundle.putSerializable("params", "1");
        intent.putExtras(bundle);
        intent.setClass(RssActivity.this, RssAddActivity.class);
        startActivityForResult(intent, Constants.REQUEST_CODE_SET_RSS_CHANNEL);
    }

    @Override
    protected void doRefresh() {
        HttpDataRequest request = TencentNews.getInstance().getSubNewsIndexMulti();
        TaskManager.startHttpDataRequset(request, this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == Constants.REQUEST_CODE_LOGIN) {
            if (resultCode == RESULT_OK) {
                showRssChannelListActivity();
            } else if (resultCode == RESULT_CANCELED) {
            }
        } else if (requestCode == Constants.REQUEST_CODE_SET_RSS_CHANNEL) {
            if (resultCode == RESULT_OK) {
                boolean refresh = data.getBooleanExtra(RssAddActivity.IS_REFRESH, false);
                if (refresh) {
                    refreshData(true);
                }
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onChannelChange() {
        refreshData(true);
    }

    @Override
    protected String getSubClassName() {
        return null;
    }
    
    @Override
    protected void onPullToRefresh() {
        super.onPullToRefresh();
        this.sendBroadcast(new Intent(RSS_MULTI_REFRESH_FINISH));
    }
}
