package com.tencent.news.rss;

import java.util.Properties;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.boss.EventId;
import com.tencent.news.cache.UserDBHelper;
import com.tencent.news.command.GetImageRequest;
import com.tencent.news.command.GetImageResponse;
import com.tencent.news.config.Constants;
import com.tencent.news.model.pojo.ImageResult;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.model.pojo.UserInfo;
import com.tencent.news.rss.RssAddListAdapter.RowType;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.LoginActivity;
import com.tencent.omg.webdev.WebDev;

public class RssAddMyRss implements RssAddLvItem, GetImageResponse, OnClickListener {

    private Context        mContext;
    private UserInfo       userInfo;
    private Boolean        isLogin = false;
    private TextView       loginBtn;
    private TextView       myRssInfo;
    private TextView       myRssTips;
    private ImageView      myRssIcon;
    private String         myTag   = "LoadHeadTag";
    private RelativeLayout my_rss_list;
    private ListView       lv;

    public RssAddMyRss(Context context, ListView l) {
        this.mContext = context;
        this.lv = l;
        updateLoginState();
    }

    private void updateLoginState() {
        UserInfo uf = UserDBHelper.getInstance().getUserInfo();
        if (uf != null) {
            isLogin = true;
            userInfo = uf;
        } else {
            isLogin = false;
            userInfo = null;
        }
    }
    


    @Override
    public void onClick(View arg0) {
        switch (arg0.getId()) {
            case R.id.login_icon:
                Intent intent = new Intent(mContext, LoginActivity.class);
                ((FragmentActivity) mContext).startActivityForResult(intent, Constants.REQUEST_CODE_LOGIN);
                break;
            case R.id.my_rss_list:
                Intent i = new Intent();
                Bundle bundle = new Bundle();
                bundle.putSerializable(RssAddSubActivity.RSS_CHANNEL_INDEX, -1);
                i.putExtras(bundle);
                UserInfo uf = UserDBHelper.getInstance().getUserInfo();
                if (uf != null) {
                    i.setClass(mContext, RssAddMyListActivity.class);
                    ((FragmentActivity) mContext).startActivityForResult(i, RssAddMyListActivity.CAT_RSS);
                } else {
                    i.setClass(mContext, RssAddSubActivity.class);
                    ((FragmentActivity) mContext).startActivityForResult(i, RssAddSubActivity.CAT_RSS);
                }
                String isLogin = uf != null ? "1" : "0";
                Properties pts = new Properties();
                pts.setProperty(EventId.BOSS_RSS_IS_LOGIN, isLogin);
                WebDev.trackCustomEvent(mContext, EventId.BOSS_RSS_CLICK_MENU, pts);
                break;
            default:
        }
    }

    @Override
    public int getViewType() {
        return RowType.MY_RSS.ordinal();
    }

    @Override
    public View getView(LayoutInflater inflater, View convertView) {
        View view;
        ViewHolder holder = new ViewHolder();
        updateLoginState();
        if (convertView == null) {
            if(RssAddBaseActivity.IS_NIGHT_THEME) {
                holder.loginView = (View) inflater.inflate(R.layout.night_rss_add_my_list_logined, null);
                holder.UnLoginView = (View) inflater.inflate(R.layout.night_rss_add_my_list, null); 
            } else {
                holder.loginView = (View) inflater.inflate(R.layout.rss_add_my_list_logined, null);
                holder.UnLoginView = (View) inflater.inflate(R.layout.rss_add_my_list, null);               
            }
            if (isLogin) {
                view = holder.loginView;
            } else {
                view = holder.UnLoginView;
            }
            view.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
            if(holder != null) {
                if (isLogin) {
                    view = holder.loginView;
                } else {
                    view = holder.UnLoginView;
                }
            } else {
                view = convertView;
            }
        }
        if(holder != null) {
            holder.name = myTag;
        }
        myRssInfo = (TextView) view.findViewById(R.id.my_rss_info);
        myRssTips = (TextView) view.findViewById(R.id.my_rss_tips);
        myRssIcon = (ImageView) view.findViewById(R.id.rss_icon);
        my_rss_list = (RelativeLayout) view.findViewById(R.id.my_rss_list);
        if (isLogin && userInfo != null) {
            String name = RssAddBaseActivity.getUserName(userInfo, mContext);
            myRssInfo.setText(name);
            myRssTips.setText(RssAddActivity.myRssIds.size() + "个订阅");
            myRssIcon.setTag(myTag);
            getImageData(userInfo.getHeadurl(), myTag);
        } else {
            loginBtn = (TextView) view.findViewById(R.id.login_icon);
            myRssInfo.setText(RssAddActivity.myRssIds.size() + "个订阅");
            myRssIcon.setImageResource(R.drawable.rss_placeholder_header);
        }
        initListener();
        return view;
    }
    
    public static class ViewHolder {
        public View loginView;
        public View UnLoginView;
        public String name;
    }

    /**
     * 获取图片数据
     */
    private void getImageData(String iconUrl, String chlid) {
        if (iconUrl != null && iconUrl.length() > 0) {
            GetImageRequest request = new GetImageRequest();
            request.setUrl(iconUrl);
            request.setTag(chlid);
            ImageResult result = TaskManager.startPngImageTask(request, this);
            if (result.isResultOK() && result.getRetBitmap() != null) {
                myRssIcon.setImageBitmap(result.getRetBitmap());
            } else {
                myRssIcon.setImageResource(R.drawable.rss_placeholder_header);
            }
        }
    }

    /**
     * 监听事件处理
     */
    private void initListener() {
        if (loginBtn != null) {
            loginBtn.setOnClickListener(this);
        }
        if (my_rss_list != null) {
            my_rss_list.setOnClickListener(this);
        }
    }

    @Override
    public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm, String path) {
        switch (imageType) {
            case PNG_IMAGE:
                View view = lv.findViewWithTag(tag);
                if (view != null) {
                    if (myRssIcon != null) {
                        myRssIcon.setImageBitmap(bm);
                    }
                }
                break;
            default:
                break;
        }
    }

    @Override
    public void onImageRecvError(ImageType imageType, Object tag, int retCode) {
        if (myRssIcon != null) {
            myRssIcon.setImageResource(R.drawable.rss_placeholder_header);
        }
    }
}
