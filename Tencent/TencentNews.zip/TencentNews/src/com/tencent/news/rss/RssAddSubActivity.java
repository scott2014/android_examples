package com.tencent.news.rss;

import java.util.List;

import com.tencent.news.R;
import com.tencent.news.cache.UserDBHelper;
import com.tencent.news.model.pojo.RssCatListCat;
import com.tencent.news.model.pojo.RssCatListItem;
import com.tencent.news.model.pojo.UserInfo;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;

public class RssAddSubActivity extends RssAddBaseActivity {

    public static final String RSS_CAT_LIST      = "rss_cat_list";
    public static final String RSS_CHANNEL_INDEX = "index";
    public static final int    CAT_RSS           = 1;
    public static final int    My_RSS            = 1;
    private int                index             = 0;

    @Override
    protected void initViews() {
        super.initViews();
        searchHeader.setVisibility(View.GONE);
        getIntentData(getIntent());
        if (mCatList != null && index >= 0) {
            mTitleBar.ShowNewsBar(mCatList.getCats().get(index).getCatName());
        }
        if (index == -1) {
            UserInfo uf = UserDBHelper.getInstance().getUserInfo();
            if (uf != null) {
                String name = RssAddBaseActivity.getUserName(uf, this);
                mTitleBar.ShowNewsBar(name);
            } else {
                mTitleBar.ShowNewsBar(this.getResources().getString(R.string.add_rss_channel));
            }
        }
        mTitleBar.setHideShare();
        mTitleBar.setBackName("返回");
    }

    private void renderListView() {
        if (index >= 0) {
            createCatList();
        } else {
            renderMyRssList();
        }
    }

    /**
     * 创建我的列表
     */
    private void renderMyRssList() {
        List<RssCatListCat> mCatListCats = mCatList.getCats();
        int n = mCatListCats.size();
        for (int i = 0; i < n; i++) {
            RssCatListCat rssCatListCat = mCatListCats.get(i);
            List<RssCatListItem> channels = rssCatListCat.getChannels();
            int m = channels.size();
            for (int j = 0; j < m; j++) {
                RssCatListItem rssCatListItem = channels.get(j);
                String chlid = rssCatListItem.getChlid();
                Boolean isOrder = RssAddBaseActivity.getIsOrder(chlid);
                createSearchIndex(rssCatListItem);
                if (isOrder) {
                    RssAddListItem tmpRssAddListItem = new RssAddListItem(rssCatListItem, this, lv);
                    rssItems.add(tmpRssAddListItem);
                }
            }
        }
        showListView();
    }

    /**
     * 创建分类的列表
     */
    private void createCatList() {
        List<RssCatListCat> mCatListCats = mCatList.getCats();
        int n = mCatListCats.size();
        if (n > index) {
            RssCatListCat rssCatListCat = mCatListCats.get(index);
            List<RssCatListItem> channels = rssCatListCat.getChannels();
            int m = channels.size();
            int hNum = 0;
            for (int j = 0; j < m; j++) {
                RssCatListItem rssCatListItem = channels.get(j);
                String recommend = rssCatListItem.getRecommend();
                if (recommend.equals("1")) {
                    if (hNum == 0) {
                        rssItems.add(new RssAddListHeader("热门", true, this));
                        hNum++;
                    }
                    RssAddListItem tmpRssAddListItem = new RssAddListItem(rssCatListItem, this, lv);
                    rssItems.add(tmpRssAddListItem);
                }
            }
        } 
        renderCatList();
    }

    /**
     * 设置和整理数据格式，空间换速度
     * 
     * @param list
     */
    private void renderCatList() {
        if (index >= 0) {
            List<RssCatListCat> mCatListCats = mCatList.getCats();
            int n = mCatListCats.size();
            if (n > index) {
                RssCatListCat rssCatListCat = mCatListCats.get(index);
                List<RssCatListItem> channels = rssCatListCat.getChannels();
                int m = channels.size();
                if (m > 0) {
                    rssItems.add(new RssAddListHeader("更多内容", false, this));
                    for (int j = 0; j < m; j++) {
                        RssCatListItem rssCatListItem = channels.get(j);
                        String recommend = rssCatListItem.getRecommend();
                        if (!recommend.equals("1")) {
                            createSearchIndex(rssCatListItem);
                            RssAddListItem tmpRssAddListItem = new RssAddListItem(rssCatListItem, this, lv);
                            rssItems.add(tmpRssAddListItem);
                        }
                    }
                }
            }
            showListView();
        }
    }

    private void getIntentData(Intent intent) {
        if (intent != null) {
            Bundle bundle = intent.getExtras();
            index = (int) bundle.getInt(RSS_CHANNEL_INDEX);
            renderListView();
        }
    }

    @Override
    protected void initListener() {
        super.initListener();
        mTitleBar.setBackClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                manageBackHandler();
            }

        });
    }

    /**
     * 返回事件处理函数
     */
    private void manageBackHandler() {
        Intent i = new Intent();
        setResult(RESULT_OK, i);
        quitActivity();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
            manageBackHandler();
        }
        return super.dispatchKeyEvent(event);
    }

}
