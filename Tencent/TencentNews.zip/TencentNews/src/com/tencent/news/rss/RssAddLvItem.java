package com.tencent.news.rss;

import android.view.LayoutInflater;
import android.view.View;

public interface RssAddLvItem {
    public int getViewType();

    public View getView(LayoutInflater inflater, View convertView);
}