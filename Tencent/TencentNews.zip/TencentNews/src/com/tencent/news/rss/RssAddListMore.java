package com.tencent.news.rss;

import java.util.Properties;

import com.tencent.news.R;
import com.tencent.news.boss.EventId;
import com.tencent.news.rss.RssAddListAdapter.RowType;
import com.tencent.omg.webdev.WebDev;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.RelativeLayout;

public class RssAddListMore implements RssAddLvItem, OnClickListener {

    private Context        mContext;
    private int            index;
    private RelativeLayout moreButton;

    public RssAddListMore(int channelId, Context context) {
        this.mContext = context;
        this.index = channelId;
    }

    @Override
    public void onClick(View arg0) {
        switch (arg0.getId()) {
            case R.id.rss_more_button:
                Intent i = new Intent();
                i.setClass(mContext, RssAddSubActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable(RssAddSubActivity.RSS_CHANNEL_INDEX, index);
                i.putExtras(bundle);
                ((FragmentActivity) mContext).startActivityForResult(i, RssAddSubActivity.CAT_RSS);

                Properties pts = new Properties();
                pts.setProperty(EventId.BOSS_RSS_CAT_ID, index + "");
                WebDev.trackCustomEvent(mContext, EventId.BOSS_RSS_CLICK_READ_MORE_BTN, pts);
                break;
            default:
        }

    }

    @Override
    public int getViewType() {
        return RowType.MORE_ITEM.ordinal();
    }

    @Override
    public View getView(LayoutInflater inflater, View convertView) {
        View view;
        if (convertView == null) {
            if(RssAddBaseActivity.IS_NIGHT_THEME) {
                view = (View) inflater.inflate(R.layout.night_rss_add_list_more, null);
            } else {
                view = (View) inflater.inflate(R.layout.rss_add_list_more, null);                
            }
        } else {
            view = convertView;
        }
        moreButton = (RelativeLayout) view.findViewById(R.id.rss_more_button);
        moreButton.setOnClickListener(this);
        return view;
    }

}
