package com.tencent.news.rss;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.Animation.AnimationListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.tencent.news.R;
import com.tencent.news.cache.RssChannelSyncHelper;
import com.tencent.news.command.GetImageRequest;
import com.tencent.news.command.GetImageResponse;
import com.tencent.news.model.pojo.ImageResult;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.model.pojo.RssCatListItem;
import com.tencent.news.rss.RssAddListAdapter.RowType;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.RssMediaActivity;
import com.tencent.news.ui.view.PullRefreshListView;
import com.tencent.news.ui.view.PullRefreshListView.startListener;

public class RssAddListItem implements RssAddLvItem, GetImageResponse, OnClickListener, startListener {
    private static int          FADEIN_ANIMATION_DURATION  = 300;
    private static int          FADEOUT_ANIMATION_DURATION = 200;
    private String              rss_name;
    private String              rss_subCount;
    private String              iconUrl;
    private String              child;
    private RssCatListItem      rssChannelListItem;
    private Boolean             isOrder;
    private Context             mContext;

    private ImageView           icon_view;
    private TextView            rss_name_view;
    private TextView            rss_subCount_view;
    private ImageView           rss_arrow_icon_btn_view;
    private PullRefreshListView lv;
    private RelativeLayout      clickArea;

    public RssAddListItem(RssCatListItem rssCatListItem, Context context, PullRefreshListView l) {
        mContext = context;
        this.rss_name = rssCatListItem.getChlname();
        this.rss_subCount = rssCatListItem.getSubCount();
        this.iconUrl = rssCatListItem.getIcon();
        this.child = rssCatListItem.getChlid();
        this.rssChannelListItem = rssCatListItem;
        this.lv = l;
    }

    /**
     * 转化成以万为单位的数字
     * 
     * @param s
     * @return
     */
    private String getFormatSize(String s) {
        String str = "";
        long size = Long.parseLong(s);
        size = size <= 0 ? 0 : size;
        double m = size / 10000;
        if (m < 1) {
            str = s + "订阅";
        } else {
            str = Math.round(m) + "万订阅";
        }
        return str;
    }

    @Override
    public int getViewType() {
        return RowType.LIST_ITEM.ordinal();
    }

    @Override
    public View getView(LayoutInflater inflater, View convertView) {
        View view;
        if (convertView == null) {
            if (RssAddBaseActivity.IS_NIGHT_THEME) {
                view = (View) inflater.inflate(R.layout.night_rss_add_list_item, null);
            } else {
                view = (View) inflater.inflate(R.layout.rss_add_list_item, null);
            }
        } else {
            view = convertView;
        }
        rss_name_view = (TextView) view.findViewById(R.id.rss_name);
        rss_subCount_view = (TextView) view.findViewById(R.id.rss_info);
        icon_view = (ImageView) view.findViewById(R.id.rss_icon);
        rss_arrow_icon_btn_view = (ImageView) view.findViewById(R.id.rss_arrow_icon_btn);
        clickArea = (RelativeLayout) view.findViewById(R.id.click_area);
        isOrder = RssAddBaseActivity.getIsOrder(child);
        if (isOrder) {
            setCancelButton();
        } else {
            setAddButton();
        }
        if (RssAddBaseActivity.IS_NIGHT_THEME) {
            icon_view.setImageResource(R.drawable.night_rss_placeholder);
        } else {
            icon_view.setImageResource(R.drawable.rss_placeholder);
        }
        rss_name_view.setText(rss_name);
        rss_subCount_view.setText(getFormatSize(rss_subCount));
        view.setTag(child);
        if(!lv.isBusy()) {
            getImageData(iconUrl, child);
        }
        initListener();
        return view;
    }

    /**
     * 更新订阅数
     */
    private void updateSubCount(Boolean isAdd) {
        long num = Long.parseLong(rss_subCount);
        if (isAdd) {
            num = num + 1;
        } else {
            num = num - 1;
        }
        rss_subCount = (num >= 0) ? num + "" : "0";
        rss_subCount_view.setText(getFormatSize(rss_subCount));
    }

    /**
     * 设置取消订阅按钮样式
     */
    private void setCancelButton() {
        if (RssAddBaseActivity.IS_NIGHT_THEME) {
            rss_arrow_icon_btn_view.setImageDrawable(mContext.getResources().getDrawable(R.drawable.night_rss_cancel_button_selector));
        } else {
            rss_arrow_icon_btn_view.setImageDrawable(mContext.getResources().getDrawable(R.drawable.rss_cancel_button_selector));
        }
    }

    /**
     * 设置添加订阅按钮样式
     */
    private void setAddButton() {
        if (RssAddBaseActivity.IS_NIGHT_THEME) {
            rss_arrow_icon_btn_view.setImageDrawable(mContext.getResources().getDrawable(R.drawable.night_rss_add_button_selector));
        } else {
            rss_arrow_icon_btn_view.setImageDrawable(mContext.getResources().getDrawable(R.drawable.rss_add_button_selector));
        }
    }

    /**
     * 监听事件处理
     */
    private void initListener() {
        rss_arrow_icon_btn_view.setOnClickListener(this);
        clickArea.setOnClickListener(this);
        lv.setSartListener(this);
    }

    /**
     * 获取图片数据
     */
    private void getImageData(String iconUrl, String chlid) {
        if (iconUrl != null && iconUrl.length() > 0) {
            GetImageRequest request = new GetImageRequest();
            request.setUrl(iconUrl);
            request.setTag(chlid);
            ImageResult result = TaskManager.startPngImageTask(request, this);
            if (result.isResultOK() && result.getRetBitmap() != null) {
                icon_view.setImageBitmap(result.getRetBitmap());
            }
        }
    }

    @Override
    public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm, String path) {
        switch (imageType) {
            case PNG_IMAGE:
                View view = lv.findViewWithTag(tag);
                if (view != null) {
                    ImageView iconView = (ImageView) view.findViewById(R.id.rss_icon);
                    if (iconView != null) {
                        iconView.setImageBitmap(bm);
                    }
                }
                break;
            default:
                break;
        }
    }

    @Override
    public void onImageRecvError(ImageType imageType, Object tag, int retCode) {

    }

    /**
     * 添加和删除订阅
     */
    private void toggleMyRssItem() {
        if (isOrder) {
            if (!RssAddBaseActivity.isLastMyRss(child, mContext)) {
                RssChannelSyncHelper.getInstance().delChannel(child, false);
                RssAddBaseActivity.delChannnel(child);
                updateSubCount(false);
                fadeOut(rss_arrow_icon_btn_view, new AnimationListener() {
                    @Override
                    public void onAnimationStart(Animation animation) {
                    }

                    @Override
                    public void onAnimationRepeat(Animation animation) {
                    }

                    @Override
                    public void onAnimationEnd(Animation animation) {
                        setAddButton();
                        fadeIn(rss_arrow_icon_btn_view, null, FADEIN_ANIMATION_DURATION);
                    }
                }, FADEOUT_ANIMATION_DURATION);
                isOrder = false;
            }
        } else {
            RssChannelSyncHelper.getInstance().addChannel(child, false);
            RssAddBaseActivity.addChannnel(child);
            updateSubCount(true);
            fadeOut(rss_arrow_icon_btn_view, new AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {
                }

                @Override
                public void onAnimationRepeat(Animation animation) {
                }

                @Override
                public void onAnimationEnd(Animation animation) {
                    setCancelButton();
                    fadeIn(rss_arrow_icon_btn_view, null, FADEIN_ANIMATION_DURATION);
                    ((RssAddBaseActivity) mContext).showSuccessTip(rss_arrow_icon_btn_view);
                }
            }, FADEOUT_ANIMATION_DURATION);
            isOrder = true;
        }
        ((RssAddBaseActivity) mContext).refreshActivity();
    }

    /**
     * 设置某个view渐现
     * 
     * @param targetView
     */
    private void fadeIn(View targetView, AnimationListener animListener, int fadeInDuration) {
        AnimationSet animationSet = new AnimationSet(true);
        AlphaAnimation alphaAnimation = new AlphaAnimation(0.0f, 1.0f);
        alphaAnimation.setDuration(fadeInDuration);
        animationSet.setFillEnabled(true);
        animationSet.setFillAfter(true);
        animationSet.addAnimation(alphaAnimation);
        if (animListener != null) {
            animationSet.setAnimationListener(animListener);
        }
        targetView.startAnimation(animationSet);
    }

    /**
     * 设置某个view渐隐
     */
    private void fadeOut(View targetView, AnimationListener animListener, int fadeOutDuration) {
        AnimationSet animationSet = new AnimationSet(true);
        AlphaAnimation alphaAnimation = new AlphaAnimation(1.0f, 0.0f);
        alphaAnimation.setDuration(fadeOutDuration);
        animationSet.setFillEnabled(true);
        animationSet.setFillAfter(true);
        animationSet.addAnimation(alphaAnimation);
        if (animListener != null) {
            animationSet.setAnimationListener(animListener);
        }
        targetView.startAnimation(animationSet);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.rss_arrow_icon_btn:
                toggleMyRssItem();
                break;
            case R.id.click_area:
                Log.i("onTouchText", "onTouchText");
                Intent i = new Intent();
                i.setClass(mContext, RssMediaActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable(RssMediaActivity.RSS_MEDIA_ITEM, rssChannelListItem);
                i.putExtras(bundle);
                ((FragmentActivity) mContext).startActivityForResult(i, RssAddBaseActivity.TARGET_MEDIA);
                break;
            default:
        }
    }

    @Override
    public void serListViewBusy(int currPosition, int tag) {
        View view = lv.findViewWithTag(tag);
        if (view != null && currPosition >= 0) {
            getImageData(iconUrl, child);
        }
    }

}
