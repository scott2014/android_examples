package com.tencent.news.rss;

import java.util.ArrayList;
import java.util.List;

import com.tencent.news.R;

import com.tencent.news.api.TencentNews;
import com.tencent.news.cache.RssChannelSyncHelper;
import com.tencent.news.cache.UserDBHelper;
import com.tencent.news.command.HttpDataRequest;
import com.tencent.news.command.HttpTagDispatch.HttpTag;
import com.tencent.news.config.Constants;
import com.tencent.news.http.HttpEngine.HttpCode;
import com.tencent.news.model.pojo.ImageType;
import com.tencent.news.model.pojo.RssCatListItem;
import com.tencent.news.model.pojo.RssFirstSubscriptionList;
import com.tencent.news.shareprefrence.SpConfig;
import com.tencent.news.system.NetTipsReceiver;
import com.tencent.news.task.TaskManager;
import com.tencent.news.ui.BaseActivity;
import com.tencent.news.ui.view.NetTipsBar;
import com.tencent.news.ui.view.TitleBar;
import com.tencent.news.ui.view.ViewPagerEx;
import com.tencent.news.ui.view.ViewPagerIndicators;
import com.tencent.news.utils.ApnUtil;
import com.tencent.news.utils.MobileUtil;
import com.tencent.news.utils.SLog;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.os.Bundle;

import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AbsListView.LayoutParams;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager.OnPageChangeListener;

public class RssGuideFragmentActivity extends BaseActivity {

    private final static String TAG = "RssGuideFragmentActivity";
    private TitleBar mTitleBar;
    private ViewPagerEx mViewPager;
    private MyPagerAdapter mPagerAdapter;
    private List<View> mPagerViews;
    private ViewPagerIndicators mPagerIndicators;
    private Button mStartButton;
    private View mMask;
    private View mParentView;
    private ImageView mLoadingImg;
    protected int nCurrChannel = 0;
    List<RssCatListItem> mRssList = null;
    List<GridView> mGridViews = null;

    // login status
    private boolean mIsLogined = false;

    protected NetTipsBar mNetTipsBar = null;
    protected NetTipsReceiver mNetTipsReceiver;
    private NetWorkReceiver mNetWorkReceiver;
    private boolean mNetworkAvailable = false;

    // Gridview information
    private int mItemsNumPerPager = 0;
    private int mColumnNum = 0;
    private int mHorizontalSpace = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rss_guide_layout);
        calculateGridPolicy();
        initView();
        mIsLogined = (UserDBHelper.getInstance().getUserInfo() != null);
        getData();
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean login = (UserDBHelper.getInstance().getUserInfo() != null);
        if (mIsLogined != login) {
            mIsLogined = login;
            getData();
        }
    }

    void calculateGridPolicy() {
        final int X_CUT_DP = 68; // right+left spacing
        final int Y_CUT_DP = 214; // top: 45+15, bottom 20+20+20+40+6, naviba =
                                  // 48
        final int ITEM_W_DP = 67;
        final int ITEM_H_DP = 91;
        final int VERTICAL_SPACE_DP = 20;
        final int MIN_HORIZONTAL_SPACE_DP = 20;

        int screenW = MobileUtil.getScreenWidthIntPx();
        int screenH = MobileUtil.getScreenHeightIntPx();

        int gridW = screenW - MobileUtil.dpToPx(X_CUT_DP);
        int gridH = screenH - MobileUtil.dpToPx(Y_CUT_DP);

        int itemW = MobileUtil.dpToPx(ITEM_W_DP);
        int itemH = MobileUtil.dpToPx(ITEM_H_DP);

        int minHorizontalSpace = MobileUtil.dpToPx(MIN_HORIZONTAL_SPACE_DP);
        int verticalSpace = MobileUtil.dpToPx(VERTICAL_SPACE_DP);

        mColumnNum = (gridW + minHorizontalSpace) / (itemW + minHorizontalSpace);
        mHorizontalSpace = (gridW - mColumnNum * itemW) / (mColumnNum - 1);
        mItemsNumPerPager = mColumnNum * (gridH / (verticalSpace + itemH));
    }

    private void initView() {

        mNetTipsBar = (NetTipsBar) findViewById(R.id.rss_guide_nettips_bar);
        mViewPager = (ViewPagerEx) findViewById(R.id.rss_guide_view_pager);
        mTitleBar = (TitleBar) findViewById(R.id.rss_guide_title_bar);
        mPagerIndicators = (ViewPagerIndicators) findViewById(R.id.rss_indicators);
        mParentView = findViewById(R.id.rss_guide_parent);
        mMask = findViewById(R.id.mask_view);
        mLoadingImg = (ImageView)findViewById(R.id.loading_img);

        mTitleBar.ShowElseBar(R.string.rss_guide_title);
        mPagerViews = new ArrayList<View>();

        // ////
        mPagerAdapter = new MyPagerAdapter(mPagerViews);
        mViewPager.setAdapter(mPagerAdapter);

        mViewPager.setOnPageChangeListener(new OnPageChangeListener() {
            @Override
            public void onPageScrollStateChanged(int arg0) {
            }

            @Override
            public void onPageScrolled(int arg0, float arg1, int arg2) {
            }

            @Override
            public void onPageSelected(int index) {
                mPagerIndicators.setFocusIndicator(index);

            }
        });

        mStartButton = (Button) findViewById(R.id.btn_start_read);
        mStartButton.setClickable(false);
        mStartButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                if (mRssList != null) {
                    int listSize = mRssList.size();
                    RssCatListItem item;
                    String command = "add=";
                    for (int i = 0; i < listSize; i++) {
                        item = mRssList.get(i);
                        if (item.getRecommend().equalsIgnoreCase("1")) {
                            command = command + item.getChlid() + ",";
                        }
                    }
                    RssChannelSyncHelper.getInstance().reload(command);
                    quitFromHere();
                }

            }
        });

        IntentFilter filter1 = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        mNetTipsReceiver = new NetTipsReceiver(mNetTipsBar);
        mNetWorkReceiver = new NetWorkReceiver();
        mNetworkAvailable = ApnUtil.isActivityApnConnected(this);
        this.registerReceiver(mNetTipsReceiver, filter1);
        this.registerReceiver(mNetWorkReceiver, filter1);

    }

    private void quitFromHere() {
        SLog.d(TAG, "Quit from RssGuideFragmentActivity");
        SpConfig.setRSSGuideAlreadyRun(true);
        Intent intent = new Intent(Constants.RSS_GUIDE_FINISHED_ACTION);
        this.sendBroadcast(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mNetTipsReceiver != null) {
            unregisterReceiver(mNetTipsReceiver);
            mNetTipsReceiver = null;
        }
        if (mNetWorkReceiver != null) {
            unregisterReceiver(mNetWorkReceiver);
            mNetWorkReceiver = null;
        }
    }

    public void getData() {
        HttpDataRequest request = TencentNews.getInstance().getFirstRssChannelList();
        TaskManager.startHttpDataRequset(request, this);
    }

    @Override
    public void onHttpRecvOK(HttpTag tag, Object result) {

        if (tag.equals(HttpTag.RSS_FIRST_SUB)) {
            RssFirstSubscriptionList sublist = (RssFirstSubscriptionList) result;
            if (sublist.getIsRecomm().equalsIgnoreCase("0")) {
                quitFromHere();
                return;
            }

            mRssList = sublist.getUserSubList();

            // set pager view visible
            mViewPager.setVisibility(View.VISIBLE);
            View loadingView = this.findViewById(R.id.loading_container);
            loadingView.setVisibility(View.GONE);
            if (mGridViews == null) {
                mGridViews = new ArrayList<GridView>();
            } else {
                mGridViews.clear();
            }

            if (mRssList != null) {
                int listSize = mRssList.size();
                for (int i = 0; i < listSize; i = i + mItemsNumPerPager) {
                    View page = this.getLayoutInflater().inflate(R.layout.rss_guide_page, null);
                    GridView gridview = (GridView) page.findViewById(R.id.rss_guild_page_gridview);
                    // set grid view property
                    gridview.setNumColumns(mColumnNum);
                    gridview.setHorizontalSpacing(mHorizontalSpace);

                    int size = (listSize - i) > mItemsNumPerPager ? mItemsNumPerPager : (listSize - i);
                    RssGuideGridViewAdapter adapter = new RssGuideGridViewAdapter(this, gridview, mRssList,
                            i, size);
                    gridview.setAdapter(adapter);
                    gridview.setOnItemClickListener(adapter);
                    mGridViews.add(gridview);
                    mPagerViews.add(page);
                }

                mPagerAdapter.notifyDataSetChanged();
                if (mPagerViews.size() > 1) {
                    mPagerIndicators.setIndicatorNum(mPagerViews.size());
                } else {
                    mPagerIndicators.setVisibility(View.GONE);
                }
            }

            // now, you can click
            mStartButton.setClickable(true);

            SLog.d(TAG, "size is " + mRssList.size());

        }
    }

    @Override
    public void onHttpRecvError(HttpTag tag, HttpCode retCode, String msg) {
    }

    @Override
    public void onHttpRecvCancelled(HttpTag tag) {
    }

    @Override
    public void onImageRecvOK(ImageType imageType, Object tag, Bitmap bm, String path) {
    }

    @Override
    public void onImageRecvError(ImageType imageType, Object tag, int retCode) {
    }

    public static class MyPagerAdapter extends PagerAdapter {
        private List<View> mListViews;

        public MyPagerAdapter(List<View> list) {
            mListViews = list;
        }

        @Override
        public int getCount() {
            return mListViews.size();
        }

        @Override
        public boolean isViewFromObject(View arg0, Object arg1) {
            return arg0 == arg1;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView(mListViews.get(position));
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            container.addView(mListViews.get(position), 0);
            return mListViews.get(position);
        }

    }

    @Override
    public void applyTheme() {
        super.applyTheme();
        mNetTipsBar.applyNetTipsBarTheme(this);
        mTitleBar.applyTitleBarTheme(this);
        themeSettingsHelper.setViewBackgroudColor(this, mMask, R.color.mask_page_color);
        themeSettingsHelper.setViewBackgroudColor(this, mParentView, R.color.view_bg_color);
        themeSettingsHelper.setImageViewSrc(this, mLoadingImg, R.drawable.news_loading_icon);
        if (mGridViews != null) {
            for (int i = 0; i < mGridViews.size(); i++) {
                RssGuideGridViewAdapter adapter = (RssGuideGridViewAdapter) mGridViews.get(i).getAdapter();
                adapter.notifyDataSetChanged();
            }
        }
        mPagerIndicators.applyTheme();
    }

    public class NetWorkReceiver extends BroadcastReceiver {
        public NetWorkReceiver() {
        }

        @Override
        public void onReceive(Context context, Intent intent) {
            SLog.d(TAG, "Network changed");
            if (ApnUtil.isActivityApnConnected(context)) {
                if (!mNetworkAvailable) {
                    getData();
                }

            }
            mNetworkAvailable = ApnUtil.isActivityApnConnected(context);
        }
    }
}
