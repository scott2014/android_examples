package com.tencent.news.rss;

import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;

import com.tencent.news.R;
import com.tencent.news.cache.RssChannelSyncHelper;
import com.tencent.news.model.pojo.RssCatListCat;
import com.tencent.news.model.pojo.RssCatListItem;

public class RssAddActivity extends RssAddBaseActivity {

    @Override
    protected void initViews() {
        super.initViews();
        mTitleBar.showmCompleteBtn(R.string.add_rss_channel_complete);
        getCatListData();
    }

    /**
     * 设置和整理数据格式，空间换速度
     * 
     * @param list
     */
    @Override
    protected void formatData() {
        super.formatData();
        RssAddMyRss rssAddMyRss = new RssAddMyRss(this, lv);
        rssItems.add(rssAddMyRss);
        List<RssCatListCat> mCatListCats = mCatList.getCats();
        List<RssCatListItem> selectedChannels = mCatList.getSelected();
        int ln = selectedChannels.size();
        if (selectedChannels != null && ln > 0) {
            rssItems.add(new RssAddListHeader(getResources().getString(R.string.add_rss_channel_recommend), true, this));
            for (int j = 0; j < ln; j++) {
                RssCatListItem rssCatListItem = selectedChannels.get(j);
                RssAddListItem tmpRssAddListItem = new RssAddListItem(rssCatListItem, this, lv);
                rssItems.add(tmpRssAddListItem);
            }
        }
        int n = mCatListCats.size();
        for (int i = 0; i < n; i++) {
            RssCatListCat rssCatListCat = mCatListCats.get(i);
            List<RssCatListItem> channels = rssCatListCat.getChannels();
            int m = channels.size();
            if (m > 0) {
                rssItems.add(new RssAddListHeader(rssCatListCat.getCatName(), false, this));
                for (int j = 0; j < m; j++) {
                    RssCatListItem rssCatListItem = channels.get(j);
                    createSearchIndex(rssCatListItem);
                    if (j < LIST_MAX_NUM) {
                        RssAddListItem tmpRssAddListItem = new RssAddListItem(rssCatListItem, this, lv);
                        rssItems.add(tmpRssAddListItem);
                    }
                }
                if(m > LIST_MAX_NUM) {
                    RssAddListMore rssAddListMore = new RssAddListMore(i, this);
                    rssItems.add(rssAddListMore);
                }
            }
        }
    }

    /**
     * 订阅管理完成事件处理函数
     */
    private void manageCompleteHandler() {
        RssChannelSyncHelper.getInstance().doSync(null);
        Intent i = new Intent();
        Bundle bundle = new Bundle();
        bundle.putBoolean(RssAddActivity.IS_REFRESH, true);
        i.putExtras(bundle);
        setResult(RESULT_OK, i);
        quitActivity();
    }
    
    
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
            Log.i("keyBack", "keyBack:" + event.getKeyCode());
            manageCompleteHandler();
            quitActivity();
        }
        return super.dispatchKeyEvent(event);
    }
    

    /**
     * 给布局文件中的view设置事件监听
     */
    @Override
    protected void initListener() {
        super.initListener();
        mTitleBar.setCompleteClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                manageCompleteHandler();
            }
        });
    }
}
