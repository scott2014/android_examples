/** Automatically generated file. DO NOT MODIFY */
package com.example.app_wg;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}