package com.tencent.weigou.guide;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.Log;
import android.view.*;
import android.view.animation.*;
import android.widget.ImageView;
import android.widget.TextView;
import com.tencent.weigou.R;
import com.tencent.weigou.base.activity.BaseActivity;
import com.tencent.weigou.common.ui.ListGuide;
import com.tencent.weigou.shopping.activity.ShoppingIndexActivity;
import com.tencent.weigou.util.StringUtils;

/**
 * 引导页面
 *
 * @author ethonchan
 */
public class GuideActivity extends BaseActivity implements OnPageChangeListener, View.OnClickListener {

    //  按钮上的文案
    public final static String BUTTON_TEXT = "button_text";

    //  引导页面adpter
    private GuidePagerAdapter mAdapter;

    //  图片下的小圆点
    private ListGuide guide;

    //  引导页面
    private ViewPager myViewPager;

    //  登录View
    private View mLoginLayout;

    //  back是否回首页
    private boolean mBackToHome = true;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //  设置按钮文字
        String btnText = "";
        Intent intent = getIntent();
        if (intent != null) {
            btnText = intent.getStringExtra(BUTTON_TEXT);
            if (StringUtils.isNotBlank(btnText)) {
                mBackToHome = false;
            }
        }

        if (mBackToHome) {
            // 隐藏任务栏
            requestWindowFeature(Window.FEATURE_NO_TITLE);
            int flag = WindowManager.LayoutParams.FLAG_FULLSCREEN;
            Window myWindow = this.getWindow();
            WindowManager.LayoutParams wl = myWindow.getAttributes();
            wl.flags = WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
            myWindow.setAttributes(wl);
            myWindow.setFlags(flag, flag);
        }

        setContentView(R.layout.main_guide_layout);

        myViewPager = (ViewPager) findViewById(R.id.viewpagerLayout);
        guide = (ListGuide) findViewById(R.id.list_guide);
        mLoginLayout = findViewById(R.id.login_layout);


        //  设置图片
        mAdapter = new GuidePagerAdapter();
        myViewPager.setAdapter(mAdapter);

        guide.setDrawables(R.drawable.guide_selected, R.drawable.guide_unselected);
        guide.setItemMargin(16, 8, 16, 8);
        guide.setListSize(mAdapter.getCount());
        guide.setVisibility(View.VISIBLE);

        if (StringUtils.isNotBlank(btnText)) {
            TextView btn = (TextView) mLoginLayout.findViewById(R.id.login_wx);
            btn.setCompoundDrawables(null, null, null, null);
            btn.setText(btnText);
            mBackToHome = false;
        }

        myViewPager.setOnPageChangeListener(this);

        //  更新SP
        GuideUtils.updateShowGuidePreference(this, false);

        mLoginLayout.setOnClickListener(this);
    }

    @Override
    public void onPageScrolled(int i, float v, int i2) {
        ;
    }

    @Override
    public void onBackPressed() {
        if (!isLogin() && mBackToHome) {
            Log.d("TAG", "onBackPressed, backToHome = true");
            Intent intent = new Intent(this, ShoppingIndexActivity.class);
            startActivity(intent);
        } else {
            Log.d("TAG", "onBackPressed, backToHome = " + mBackToHome + ", isLogin=" + isLogin());
        }
        super.onBackPressed();
    }

    @Override
    public void onPageSelected(int position) {
        guide.setSelectItem(position);

        int count = mAdapter.getCount();
        if (position + 1 == count && mLoginLayout.getVisibility() != View.VISIBLE)
        //  第一次滑到最后一页，展示登录按钮
        {
            Animation anim = initShowAnimation();
            mLoginLayout.startAnimation(anim);
        }
    }

    /**
     * 登录按钮第一次展示时的动画
     *
     * @return
     */
    private Animation initShowAnimation() {
        AnimationSet animationSet = new AnimationSet(true);
        TranslateAnimation trans = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0, Animation.RELATIVE_TO_SELF, 0, Animation.RELATIVE_TO_SELF, 1, Animation.RELATIVE_TO_SELF, 0);
        animationSet.addAnimation(trans);
        AlphaAnimation alpha = new AlphaAnimation(0, 1);
        animationSet.addAnimation(alpha);

        animationSet.setInterpolator(new AccelerateDecelerateInterpolator());
        animationSet.setFillAfter(true);
        animationSet.setDuration(500);

        animationSet.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                mLoginLayout.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                ;
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
                ;
            }
        });

        return animationSet;
    }

    @Override
    public void onPageScrollStateChanged(int i) {
        ;
    }

    @Override
    public void onClick(View v) {
        if (mBackToHome) {
            Intent intent = new Intent(this, ShoppingIndexActivity.class);
            startActivity(intent);
        }

        finish();
    }

    /**
     * 引导页内容
     */
    class GuidePagerAdapter extends PagerAdapter {

        private View[] mViews;

        //  提示语
        private String[] tips;

        private int[] images;

        GuidePagerAdapter() {
            images = new int[]{R.drawable.guide_1, R.drawable.guide_2, R.drawable.guide_3};
            tips = new String[]{"优惠上新早知道", "在家也能逛商场", "逛街省时又方便"};
            mViews = new View[3];
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            View view = mViews == null ? null : mViews[position];

            if (view == null) {
                Context context = GuideActivity.this;
                LayoutInflater inflater = LayoutInflater.from(context);
                view = inflater.inflate(R.layout.main_guide_page_layout, null);

                ImageView image = (ImageView) view.findViewById(R.id.guide_image);
                image.setImageResource(images[position]);
                TextView textView = (TextView) view.findViewById(R.id.guide_tips);
                textView.setText(tips[position]);

                container.addView(view);
            }

            return view;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            mViews[position] = (View) object;
        }

        @Override
        public int getCount() {
            return images == null ? 0 : images.length;
        }

        @Override
        public boolean isViewFromObject(View view, Object o) {
            if (view == null || o == null) {
                return false;
            } else {
                return view == o;
            }
        }
    }
}
