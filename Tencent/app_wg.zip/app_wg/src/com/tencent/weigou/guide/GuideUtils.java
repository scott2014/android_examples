package com.tencent.weigou.guide;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 引导页工具类
 * User: ethonchan
 * Date: 13-11-13
 * Time: 下午2:18
 */
public class GuideUtils {
    //  微购引导页相关的SP名
    public final static String SP_GUIDE_NAME = "weigou_guide";

    //  SP中的字段名（是否显示引导页）
    public final static String SHOW_GUIDE = "show_guide";

    /**
     * 是否需要显示引导页
     *
     * @param context
     * @return true需要，false不需要
     */
    public static boolean needShowGuide(Context context) {
        boolean showGuide = true;
        if (context != null) {
            SharedPreferences sp = context.getSharedPreferences(SP_GUIDE_NAME, Context.MODE_PRIVATE);
            try {
                if (sp != null) {
                    showGuide = sp.getBoolean(SHOW_GUIDE, true);
                }
            } catch (Exception e) {
                SharedPreferences.Editor editor = sp.edit();
                editor.remove(SHOW_GUIDE);
                editor.commit();
                showGuide = true;
            }
        }

        return showGuide;
    }

    /**
     * 更新SP中显示引导页的设置
     *
     * @param context
     * @param needShow
     */
    public static void updateShowGuidePreference(Context context, boolean needShow) {
        if (context != null) {
            SharedPreferences sp = context.getSharedPreferences(SP_GUIDE_NAME, Context.MODE_PRIVATE);
            if (sp != null) {
                SharedPreferences.Editor editor = sp.edit();
                editor.putBoolean(SHOW_GUIDE, needShow);
                editor.commit();
            }
        }
    }
}
