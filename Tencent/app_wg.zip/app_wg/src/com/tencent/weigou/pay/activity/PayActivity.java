package com.tencent.weigou.pay.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import com.tencent.mm.sdk.constants.Build;
import com.tencent.mm.sdk.modelpay.PayReq;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.WXAPIFactory;
import com.tencent.weigou.R;
import com.tencent.weigou.base.activity.BaseActivity;
import com.tencent.weigou.base.model.vo.CommonVo;
import com.tencent.weigou.pay.activity.model.PayModel;
import com.tencent.weigou.pay.activity.model.vo.PayVo;
import com.tencent.weigou.util.Constants;
import com.tencent.weigou.util.ConstantsActivity;
import com.tencent.weigou.util.ConstantsUrl;
import com.tencent.weigou.util.PageIds.OprIndex;
import com.tencent.weigou.util.StringUtils;
import com.tencent.weigou.wxapi.WXUtils;

public class PayActivity extends BaseActivity {

	private IWXAPI api;
	private PayModel payModel = new PayModel();
	private String cardId = "";
	private String dealId = "";
	private String mappId = "";
	private Handler handler = new Handler();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.pay_loading);
		payModel.addObserver(this);
		TAG = "PayActivity";
		// 1、获取参数
		Intent intent = this.getIntent();
		String url = "";
		// 2、判断参数是否合法
		cardId = intent.getStringExtra(ConstantsActivity.INTENT_TICKET_DETAIL);
		dealId = intent.getStringExtra(ConstantsActivity.INTENT_DEAL_ID);
		mappId = intent.getStringExtra(ConstantsActivity.INTENT_TICKET_MAPPID);
		api = WXAPIFactory.createWXAPI(this, WXUtils.WX_APP_ID);
		// 3、判断是否支持微信支付
		if (api.getWXAppSupportAPI() < Build.PAY_SUPPORTED_SDK_INT) {
			Toast.makeText(PayActivity.this,
					getString(R.string.not_support_weixin_pay),
					Constants.TOAST_NORMAL_LONG).show();
			handler.postDelayed(new Runnable() {

				@Override
				public void run() {
					finish();

				}
			}, 2500);
		}
		//
		setNeedAddDebugFlag(false);
		if (!StringUtils.isBlank(cardId)) {
			url = this.appendPageInfo(app.getEnv().getServerUrl()
					+ ConstantsUrl.CARD_PAY, OprIndex.PV_OPR)
					+ "&mappId=" + mappId + "&cardId=" + cardId + "&buyNum=1";
			//url = url.replaceAll("&debug=true", "");
			Log.d(TAG, "pay_url:" + url);
			payModel.handleMessage(0, url, null);
		} else if (!StringUtils.isBlank(dealId)) {
			url = this.appendPageInfo(app.getEnv().getServerUrl()
					+ ConstantsUrl.DEAL_PAY, OprIndex.PV_OPR)
					+ "&dealId=" + dealId;
			//url = url.replaceAll("&debug=true", "");
			payModel.handleMessage(0, url, null);
			Log.d(TAG, "pay_url:" + url);
		} else {
			finish();
		}
		// 支付

		// url =
		// "http://test.pp.gamma.xpay.buy.qq.com/app/template.xhtml?tid=pay_test";

		// api = WXAPIFactory.createWXAPI(this, WXUtils.WX_APP_ID);
		// PayVo vo = new PayVo();
		// vo.setAppId("wx2e9f8471bee03412");
		// vo.setNonceStr("a4939072217b46203c4f5764cb4dac40");
		// vo.setPackageValue("Sign=wxpay");
		// vo.setPartnerId("1216545901");
		// vo.setPrepayId("1k124a36d4c7962a6b27");
		// vo.setSign("ac7a9b180a52ecf9e7e4d31e01567c397f7e1b28");
		// vo.setTimeStamp("1388135578");
		// update(vo);
	}

	@Override
	public void update(CommonVo vo) {
		if (vo instanceof PayVo) {
			PayReq req = new PayReq();
			PayVo payVo = (PayVo) vo;
			req.appId = payVo.getAppId();
			req.partnerId = payVo.getPartnerId();
			req.prepayId = payVo.getPrepayId();
			req.nonceStr = payVo.getNonceStr();
			req.timeStamp = payVo.getTimeStamp();
			req.packageValue = payVo.getPackageValue();
			req.sign = payVo.getSign();
			req.extData = dealId + ";" + payVo.getDealId();
			api.sendReq(req);
			finish();
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		payModel.close();
	}

}
