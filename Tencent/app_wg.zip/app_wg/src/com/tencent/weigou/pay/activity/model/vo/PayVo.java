package com.tencent.weigou.pay.activity.model.vo;

import org.json.JSONObject;

import com.tencent.weigou.base.model.vo.CommonVo;
import com.tencent.weigou.util.NotificationIds;
import com.tencent.weigou.wxapi.WXUtils;

/**
 * @ClassName: PayVo
 * @Description: 微信支付
 * @author wendyhu
 * @date 2013-11-28 下午4:11:30
 */

public class PayVo extends CommonVo {

	public PayVo() {
		setNotificationId(NotificationIds.PAY_BY_WEIXIN);
	}

	// 商家在微信开放平台申请的应用id
	private String appId = WXUtils.WX_APP_ID;
	// 商家向财付通申请的商家id
	private String partnerId = "";
	// 预支付订单
	private String prepayId = "";
	// 32位内的随机串，防重发
	private String nonceStr = "";
	// 时间戳，为1970年1月1日00:00到请求发起时间的秒数
	private String timeStamp = "";
	// 商家根据财付通文档填写的数据和签名
	private String packageValue = "";
	// 商家根据微信开放平台文档对数据做的签名
	private String sign = "";
	private String dealId = "";

	/**
	 * @return the appId
	 */
	public String getAppId() {
		return appId;
	}

	public String getDealId() {
		return dealId;
	}

	public void setDealId(String dealId) {
		this.dealId = dealId;
	}

	/**
	 * @param appId
	 *            the appId to set
	 */
	public void setAppId(String appId) {
		this.appId = appId;
	}

	/**
	 * @return the partnerId
	 */
	public String getPartnerId() {
		return partnerId;
	}

	/**
	 * @param partnerId
	 *            the partnerId to set
	 */
	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	/**
	 * @return the prepayId
	 */
	public String getPrepayId() {
		return prepayId;
	}

	/**
	 * @param prepayId
	 *            the prepayId to set
	 */
	public void setPrepayId(String prepayId) {
		this.prepayId = prepayId;
	}

	/**
	 * @return the nonceStr
	 */
	public String getNonceStr() {
		return nonceStr;
	}

	/**
	 * @param nonceStr
	 *            the nonceStr to set
	 */
	public void setNonceStr(String nonceStr) {
		this.nonceStr = nonceStr;
	}

	/**
	 * @return the timeStamp
	 */
	public String getTimeStamp() {
		return timeStamp;
	}

	/**
	 * @param timeStamp
	 *            the timeStamp to set
	 */
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	/**
	 * @return the packageValue
	 */
	public String getPackageValue() {
		return packageValue;
	}

	/**
	 * @param packageValue
	 *            the packageValue to set
	 */
	public void setPackageValue(String packageValue) {
		this.packageValue = packageValue;
	}

	/**
	 * @return the sign
	 */
	public String getSign() {
		return sign;
	}

	/**
	 * @param sign
	 *            the sign to set
	 */
	public void setSign(String sign) {
		this.sign = sign;
	}

	public boolean parse(JSONObject o) {
		if (o != null) {
			this.appId = o.optString("appId", WXUtils.WX_APP_ID);
			this.partnerId = o.optString("partnerId", "");
			this.prepayId = o.optString("prepayId", "");
			this.nonceStr = o.optString("nonceStr", "");
			this.timeStamp = o.optString("timeStamp", "");
			this.packageValue = o.optString("packageValue", "");
			this.dealId = o.optString("dealId", "");
			this.sign = o.optString("sign", "");
			return true;
		}
		return false;
	}
}
