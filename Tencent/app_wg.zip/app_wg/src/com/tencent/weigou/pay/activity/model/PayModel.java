package com.tencent.weigou.pay.activity.model;

import com.tencent.weigou.base.model.Model;
import com.tencent.weigou.pay.activity.model.vo.PayVo;

/**
 * @ClassName: PayModel
 * @Description: 支付model
 * @author wendyhu
 * @date 2013-11-28 下午4:09:37
 */

public class PayModel extends Model {
	private GetNetWorkDataTask payTask = null;

	public PayModel() {
		setPushType(true);
	}

	public boolean handleMessage(int what, String url, Object data) {
        if (payTask != null)
            cancel(payTask);
        PayVo vo = new PayVo();
        payTask = new GetNetWorkDataTask(url, vo, vo.getNotificationId());
        payTask.execute();
        return true;
    }

    public void close() {
        super.close();
        cancel(payTask);
    }
}
