package com.tencent.weigou.cache;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import org.json.JSONObject;

/**
 * 本地缓存内容 User: ethonchan Date: 13-10-17 Time: 下午5:39
 */
public class CacheInfo {
	// Http属性：Last-Modified
	private long lastModified;

	// Http属性：Expires, 如果同时存在maxAge也会被转换为Expires。当客户端在此时间之前发起请求时，直接使用缓存
	private long expires;

	// 资源在本地缓存中的key
	private String key;

	// 资源数据
	private byte[] value;

	private CacheInfo() {
	}

	public CacheInfo(long lastModified, long expires, String key, byte[] value) {
		this.lastModified = lastModified;
		this.expires = expires;
		this.key = key;
		this.value = value;
	}

	public long getLastModified() {
		return lastModified;
	}

	public void setLastModified(long lastModified) {
		this.lastModified = lastModified;
	}

	public long getExpires() {
		return expires;
	}

	public String getKey() {
		return key;
	}

	public byte[] getValue() {
		return value;
	}

	public void setValue(byte[] value) {
		this.value = value;
	}

	/**
	 * 缓存是否有效
	 * 
	 * @return true有效，false无效
	 */
	public boolean isValid() {
		return value != null && value.length > 0;
	}

	/**
	 * 缓存是否过期
	 * 
	 * @return true过期，false未过期
	 */
	public boolean isExpires() {
		return System.currentTimeMillis() >= expires;
	}

	/**
	 * 缓存转成JSONObject对象
	 * 
	 * @return 缓存中存储的JSONObject对象。如果转换发生异常则返回Null
	 */
	public JSONObject toJSONObject() {
		JSONObject json = null;
		try {
			String str = new String(value);
			json = new JSONObject(str);
		} catch (Exception e) {
			;
		}
		return json;
	}

	/**
	 * 将缓存转成bitmap对象
	 * 
	 * @return 缓存中存储的bitmap对象。如果转换发生异常则返回Null
	 */
	public Bitmap toBitmap() {
		Bitmap bitmap = null;
		try {
			bitmap = BitmapFactory.decodeByteArray(value, 0, value.length);
		} catch (OutOfMemoryError ex) {
			;
		} catch (Exception e) {
			;
		}
		return bitmap;
	}

}
