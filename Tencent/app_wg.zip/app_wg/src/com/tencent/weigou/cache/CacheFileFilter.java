package com.tencent.weigou.cache;

import com.tencent.weigou.jni.CFileApi;

import java.io.File;
import java.io.FileFilter;

/**
 * 缓存文件过滤器
 * User: ethonchan
 * Date: 13-11-14
 * Time: 下午2:17
 */
public class CacheFileFilter implements FileFilter {
    //  最后访问时间
    private long mLastVistedTime;

    public CacheFileFilter(long lastVistedTime) {
        this.mLastVistedTime = lastVistedTime;
    }

    @Override
    public boolean accept(File file) {
        if (file != null) {
            long lastVisited = CFileApi.getLastAccessTime(file.getPath());
            lastVisited *= 1000;
            if (file != null && file.isFile() && lastVisited < mLastVistedTime) {
                return true;
            }
        }
        return false;
    }
}
