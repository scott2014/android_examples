package com.tencent.weigou.cache;

import com.tencent.weigou.util.*;

import java.io.File;
import java.io.FileFilter;
import java.io.FileOutputStream;
import java.net.URI;
import java.util.ArrayList;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 缓存工具，负责缓存的读取和写入工作 User: ethonchan Date: 13-10-18 Time: 下午12:06
 */
public class CacheUtils {

    //  缓存SP文件
    private final static String SP_CACHE_FILE = "cache_info";

    //  缓存大小
    private final static String SP_EXPIRE_TIME = "expire_time";

    //  默认过期时间
    private final static long DEFAULT_EXPIRE_TIME = 60 * 60 * 24 * 7;

    private final static String MAGIC_NUM = "123~@*_#&%";

    // 默认的缓存目录
    private final static String DEFAULT_CACHE_PATH = "cache";

    // 附在文件头部的盐粒数量
    private final static int SALT_NUM_HEAD = 3;

    // 附在文件尾部的盐粒数量
    private final static int SALT_NUM_TAIL = 2;

    // 加入到文件中的盐粒的byte长度
    private final static int BYTE_LENGTH_OF_SALT = 8;

    // 缓存被读取过多少次
    private static AtomicInteger getTimes = new AtomicInteger(0);

    // 缓存被成功读取过多少次
    private static AtomicInteger successGetTimes = new AtomicInteger(0);

    static {
//        App app = App.getInstance();
        //  这里可以考虑动态调整缓存过期时间的大小
//        SharedPreferences sp = app.getSharedPreferences(SP_CACHE_FILE, Context.MODE_PRIVATE);
//        try {
//            if (sp != null) {
//                mExpireTime = sp.getLong(SP_EXPIRE_TIME, DEFAULT_EXPIRE_TIME);
//            }
//        } catch (Exception e) {
//            SharedPreferences.Editor editor = sp.edit();
//            editor.remove(SP_EXPIRE_TIME);
//            editor.commit();
//            mExpireTime = DEFAULT_EXPIRE_TIME;
//        }
    }

    /**
     * 从缓存中获取某个资源url对应的缓存信息
     *
     * @param urlStr 资源url
     * @return 资源对应的缓存信息，或者NULL
     */
    public static CacheInfo getFromCache(String urlStr) {
        synchronized (CacheUtils.class) {
            getTimes.incrementAndGet();
        }

        CacheInfo cache = null;
        // 根据url计算出路径和文件名
        String fpath = getFilePath(urlStr);
        if (StringUtils.isBlank(fpath)) {
            return cache;
        }

        try {
            // 从文件中读取字节数组
            byte[] data = IOUtils.readFile(fpath);

            // 取出之前添加在文件中的盐分
            long[] salts = getSalt(data);
            // 取出文件内容
            int contentOffset = SALT_NUM_HEAD * BYTE_LENGTH_OF_SALT;
            int contentLen = data.length - (SALT_NUM_HEAD + SALT_NUM_TAIL)
                    * BYTE_LENGTH_OF_SALT;
            if (contentLen < 0) {
                throw new IndexOutOfBoundsException();
            }
            byte[] content = new byte[contentLen];
            System.arraycopy(data, contentOffset, content, 0, contentLen);

            // 校验缓存有效性
            CacheInfo candCache = new CacheInfo(salts[1], salts[2], urlStr,
                    content);
            if (validateCache(candCache, salts))
            // 缓存有效
            {
                cache = candCache;
            } else
            // 缓存无效，清除缓存
            {
                clearCache(urlStr);
            }
        } catch (Exception e) {
            // 清除对应的缓存
            clearCache(urlStr);
        }

        // 统计成功次数
        int successTimes = -1;
        synchronized (CacheUtils.class) {
            if (cache != null) {
                successGetTimes.incrementAndGet();
            }
            if (getTimes.intValue() >= 100) {
                successTimes = successGetTimes.intValue();
                // 统计清零
                successGetTimes.set(0);
                getTimes.set(0);
            }

        }

        if (successTimes > -1) {
            Properties props = new Properties();
            props.put(MTAConstants.KEY_VALUE, successTimes);
            MTAUtils.reportMTAEvent(MTAConstants.ID_CACHE_MATCH, props);
        }

        // 若两者都匹配则认为有效，否则认为失败
        return cache;
    }

    /**
     * 从文件数据中取出写入时添加的盐分
     *
     * @param fileData 文件数据
     * @return 添加的盐分
     * @throws IndexOutOfBoundsException 数组越界
     * @throws NullPointerException      数组为空
     */
    private static long[] getSalt(byte[] fileData)
            throws IndexOutOfBoundsException, NullPointerException {
        // 得到每个盐分信息的偏移值
        int[] offsets = new int[SALT_NUM_HEAD + SALT_NUM_TAIL];
        for (int i = 0; i < SALT_NUM_HEAD; i++) {
            offsets[i] = i * BYTE_LENGTH_OF_SALT;
        }
        int endOffset = fileData.length - SALT_NUM_TAIL * BYTE_LENGTH_OF_SALT;
        if (endOffset < 0) {
            throw new IndexOutOfBoundsException();
        }
        for (int i = 0; i < SALT_NUM_TAIL; i++) {
            offsets[SALT_NUM_HEAD + i] = endOffset + i * BYTE_LENGTH_OF_SALT;
        }

        // 读取每个盐分的具体取值
        final int saltNum = SALT_NUM_HEAD + SALT_NUM_TAIL;
        long[] salts = new long[saltNum];
        for (int i = 0; i < saltNum; i++) {
            byte[] bytes = new byte[BYTE_LENGTH_OF_SALT];
            System.arraycopy(fileData, offsets[i], bytes, 0,
                    BYTE_LENGTH_OF_SALT);
            long salt = NumberUtils.parseByte(bytes);
            salts[i] = salt;
        }

        return salts;
    }

    /**
     * 校验缓存的有效性
     *
     * @param cache 缓存信息
     * @param salts 之前与缓存文件内容一起附加在文件中的盐分，可用于校验缓存信息的有效性
     * @return true缓存有效，false缓存无效
     * @throws NullPointerException
     * @throws IndexOutOfBoundsException
     */
    private static boolean validateCache(CacheInfo cache, long[] salts)
            throws NullPointerException, IndexOutOfBoundsException {
        if (cache != null) {
            if (salts == null) {
                throw new NullPointerException();
            }

            // 校验盐分本身的有效性
            long saltE = getSaltE(salts[0], salts[1], salts[2], salts[3]);
            if (saltE != salts[4]) {
                return false;
            }

            // 校验urlStr盐分的有效性
            long saltD = SysUtils.getADLER(cache.getKey(), 0L);
            if (saltD != salts[3]) {
                return false;
            }

            // 校验content的有效性
            long saltA = SysUtils.getADLER(cache.getValue(), 0L);
            if (saltA != salts[0]) {
                return false;
            }

            return true;
        }
        return false;
    }

    /**
     * 生成盐粒E
     *
     * @param saltA 盐分A
     * @param saltB 盐分B
     * @param saltC 盐分C
     * @param saltD 盐分D
     * @return 盐分E
     */
    private static long getSaltE(long saltA, long saltB, long saltC, long saltD) {
        StringBuilder sb = new StringBuilder();
        sb.append(Long.toHexString(saltA)).append(MAGIC_NUM);
        sb.append(Long.toHexString(saltB)).append(MAGIC_NUM);
        sb.append(Long.toHexString(saltC)).append(MAGIC_NUM);
        sb.append(Long.toHexString(saltD)).append(MAGIC_NUM);
        String sourceE = sb.toString();
        long saltE = SysUtils.getADLER(sourceE, 0L);
        return saltE;
    }

    /**
     * 将下载到的内容保存到缓存中去
     *
     * @param urlStr       内容url
     * @param lastModified 内容的lastModified属性值
     * @param expires      内容的expires属性值
     * @param bytes        内容本身
     */
    public static void saveToCache(String urlStr, long lastModified,
                                   long expires, byte[] bytes) {
        if (bytes == null) {
            return;
        }

        // 根据url计算出路径和文件名
        String filePath = getFilePath(urlStr);
        if (StringUtils.isBlank(filePath)) {
            return;
        }

        // 计算出bytes的adler32值A
        long saltA = SysUtils.getADLER(bytes, 0L);

        // lastModified为值B
        long saltB = lastModified;

        // expires为值C
        long saltC = expires;

        // 计算出urlStr的adler32值D
        long saltD = SysUtils.getADLER(urlStr, 0L);

        // 计算出A + B + C + MAGIC_NUM的adler32值E
        long saltE = getSaltE(saltA, saltB, saltC, saltD);

        // 打开文件流
        FileOutputStream outs = null;
        try {
            ArrayList<byte[]> salts = new ArrayList<byte[]>(SALT_NUM_HEAD
                    + SALT_NUM_TAIL);
            salts.add(NumberUtils.parseLong(saltA));
            salts.add(NumberUtils.parseLong(saltB));
            salts.add(NumberUtils.parseLong(saltC));
            salts.add(NumberUtils.parseLong(saltD));
            salts.add(NumberUtils.parseLong(saltE));

            File outFile = new File(filePath);
            outs = new FileOutputStream(outFile);
            for (int i = 0; i < SALT_NUM_HEAD; i++) {
                byte[] salt = salts.get(i);
                if (salt != null) {
                    outs.write(salt);
                }
            }

            outs.write(bytes);

            for (int i = 0; i < SALT_NUM_TAIL; i++) {
                byte[] salt = salts.get(i + SALT_NUM_HEAD);
                if (salt != null) {
                    outs.write(salt);
                }
            }
            outs.flush();
            outs.close();
        } catch (Exception e) {
            // ignore
            clearCache(urlStr);
            //  每次异常发生的时候都尝试着去释放一下空间
            clearCache(false);
        } finally {
            IOUtils.closeQuietly(outs);
        }
    }

    /**
     * 清除某个urlStr对应的缓存内容
     *
     * @param urlStr 要清除的urlStr
     */
    public static void clearCache(String urlStr) {
        // 根据urlStr计算出路径和文件名
        String filePath = getFilePath(urlStr);
        if (StringUtils.isNotBlank(filePath)) {
            File file = new File(filePath);
            if (file.exists() && file.canWrite()) {
                file.delete();
            }
        }
    }

    /**
     * 清除缓存
     *
     * @param deleteAll 是否清除所有缓存
     */
    public static void clearCache(boolean deleteAll) {
        File cacheDir = SysUtils.getDirInSdcard(DEFAULT_CACHE_PATH);

        if(deleteAll)
        //  全部清除则完全删除
        {
            clearDir(null, cacheDir);
        }else
        //  否则按照使用时间来清除
        {
            long lastUsedTime = System.currentTimeMillis() - DEFAULT_EXPIRE_TIME;
            CacheFileFilter fileFilter = new CacheFileFilter(lastUsedTime);
            clearDir(fileFilter, cacheDir);
        }
    }

    /**
     * 删除目录
     * @param filter    给定的过滤器
     * @param dir   要删除的目录
     */
    protected static void clearDir(FileFilter filter, File dir) {
        if (dir == null || !dir.isDirectory()) {
            return;
        }

        //  删除该目录下的所有符合的文件
        File[] files = dir.listFiles(filter);
        if (files != null) {
            for (File file : files) {
                file.delete();
            }
        }

        //  循环删除该目录下的子目录
        File[] childDirs = dir.listFiles(new DirFilter());
        if (childDirs != null && childDirs.length > 0) {
            for (File childDir : childDirs) {
                clearDir(filter, childDir);
            }
        }

        //  检查该目录是否为空
        if (isEmpty(dir)) {
            dir.delete();
        }
    }

    /**
     * 某个dir是否为空
     *
     * @param dir
     * @return
     */
    protected static boolean isEmpty(File dir) {
        if (dir != null && dir.isDirectory()) {
            File[] files = dir.listFiles();
            if (files == null || files.length == 0) {
                return true;
            }
        }
        return false;
    }

    /**
     * 根据url计算出换成目录中对应的文件名
     *
     * @param urlStr url
     * @return 正常情况下返回文件完整路径。异常情况下返回null
     */
    protected static String getFilePath(String urlStr) {
        if (StringUtils.isBlank(urlStr)) {
            return null;
        }

        String filePath = null;
        try {
            // 缓存目录按HOST来进行划分
            URI url = new URI(urlStr);
            String host = url.getHost();
            String dirStr = DEFAULT_CACHE_PATH;
            if (StringUtils.isNotBlank(host)) {
                String subDir = SysUtils.getMD5(host, DEFAULT_CACHE_PATH);
                dirStr = dirStr + File.separator + subDir;
            }
            File dir = SysUtils.getDirInSdcard(dirStr);
            if (dir != null) {
                String fname = SysUtils.getMD5(urlStr, null);
                if (StringUtils.isNotBlank(fname)) {
                    filePath = dir.getPath() + File.separator + fname;
                }
            }
        } catch (Exception e) {
            // ignore
            filePath = null;
        }
        return filePath;
    }
}
