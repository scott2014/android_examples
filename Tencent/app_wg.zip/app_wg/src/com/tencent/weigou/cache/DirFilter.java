package com.tencent.weigou.cache;

import java.io.File;
import java.io.FileFilter;

/**
 * 目录过滤器
 * User: ethonchan
 * Date: 13-11-14
 * Time: 下午2:25
 */
public class DirFilter implements FileFilter {
    @Override
    public boolean accept(File pathname) {
        if(pathname != null && pathname.isDirectory()){
            return true;
        }
        return false;
    }
}
