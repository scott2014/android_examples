/**   
 * @Title: CFileApi.java 
 * @Package com.qq.buy.jni 
 * @author Wendyhu wendyhu@tencent.com  
 * @date 2012-6-14 上午10:36:36 
 * @version V1.0   
 */
package com.tencent.weigou.jni;

/**
 * @ClassName: CFileApi
 * @author wendyhu wendyhu@tencent.com
 * @date 2012-6-14 上午10:36:36
 * 
 */
public class CFileApi {

	static {
		try {
			System.loadLibrary("cfileapi");
		} catch (UnsatisfiedLinkError e) {
			/**
			 * catch UnsatisfiedLinkError
			 * mobile phone can't load cfileapi.so in rare condition
			 */
		}
		
	}

	/**
	 * 
	 * @Title: getLastAccessTime
	 * 
	 * @Description: 返回文件最后一次访问时间（单位s）
	 * 
	 * @param filePath
	 * @return long 返回类型(单位s)
	 * 
	 * @throws
	 */
	public native static long getLastAccessTime(String filePath);

	/**
	 * 
	 * @Title: hash算法加密算法
	 * 
	 * @Description: 
	 *               对于给定的一个魔术值magicNum(一个24进制的long转成String)和一个字符串url(请求Url,这里建议加上一个时间戳
	 *               )，进行hash得到另一个值 result = Function((hashCode =
	 *               hash(magic,srcStr)) + token); result格式为："u_"+
	 *               20进制的(hashCode) + "_" + 28进制的(token) + "@qq.com"
	 * 
	 * @param magicNum
	 *            魔术字
	 * @param source
	 *            源串
	 * 
	 * @return String 得到的结果
	 * 
	 */
	public native static String sign(String magicNum, String source);

}
