package com.tencent.weigou.feeds.model;

import com.tencent.weigou.base.model.vo.CommonVo;
import org.json.JSONObject;

/**
 * 未读FeedVo
 * User: ethonchan
 * Date: 13-11-28
 * Time: 下午5:14
 */
public class UnreadFeedVo extends CommonVo{

    //  未读数量
    private int unreadCount = 0;

    @Override
    public boolean parse(JSONObject jo) {
        if(jo != null){
            unreadCount = jo.optInt("unreadCount", 0);
        }
        return true;
    }

    /**
     * 是否有未读的Feeds
     * @return
     */
    public boolean hasUnreadFeeds(){
        return unreadCount > 0;
    }
}
