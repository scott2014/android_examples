package com.tencent.weigou.feeds.model;

import android.util.Log;
import com.tencent.weigou.base.model.Model;
import com.tencent.weigou.util.StringUtils;

/**
 * 动态Model
 * User: ethonchan
 * Date: 13-11-26
 * Time: 下午4:40
 */
public class FeedModel extends Model {
    //  初始化Feed列表--完成
    public static final int FEED_LIST_INIT_DONE = 0;

    //  更新Feed列表的头部--完成
    public static final int FEED_LIST_REFRESH_HEADER_DONE = 20;

    //  更新Feed列表的尾部--完成
    public static final int FEED_LIST_REFRESH_FOOTER_DONE = 30;

    private FeedListVo headerFeeds;

    private FeedListVo footerFeeds;

    @Override
    public void initData(String url) {
        super.initData(url);

        headerFeeds = new FeedListVo();
        if (StringUtils.isNotBlank(url)) {
            //  发起网络请求
            GetNetWorkDataTask task = new GetNetWorkDataTask(true, url, headerFeeds, FEED_LIST_INIT_DONE);
            task.execute();
            addList(task);
        } else {
            notify(FEED_LIST_INIT_DONE);
        }
    }

    /**
     * 获取最新的动态信息
     */
    public void refreshHeader(String url) {
        Log.d("TAG", "refreshHeader : "+url);
        headerFeeds = new FeedListVo();
        if (StringUtils.isNotBlank(url)) {
            //  发起网络请求
            GetNetWorkDataTask task = new GetNetWorkDataTask(false, url, headerFeeds, FEED_LIST_REFRESH_HEADER_DONE);
            task.execute();
            addList(task);
        } else {
            notify(FEED_LIST_REFRESH_HEADER_DONE);
        }
    }

    /**
     * 获取较旧的动态信息
     * 还没有成功请求过Feed的不让刷新Footer
     */
    public void refreshFooter(String url) {
        Log.d("TAG", "refreshFooter : "+url);
        footerFeeds = new FeedListVo();
        if (StringUtils.isNotBlank(url)) {
            //  发起网络请求
            GetNetWorkDataTask task = new GetNetWorkDataTask(false, url, footerFeeds, FEED_LIST_REFRESH_FOOTER_DONE);
            task.execute();
            addList(task);
        } else {
            notify(FEED_LIST_REFRESH_FOOTER_DONE);
        }
    }

    public FeedListVo getHeaderFeeds() {
        return headerFeeds;
    }

    public FeedListVo getFooterFeeds() {
        return footerFeeds;
    }
}
