package com.tencent.weigou.feeds.model;

import java.io.Serializable;

/**
 * Feed发送者
 * User: ethonchan
 * Date: 13-11-26
 * Time: 下午3:31
 */
public class Feeder implements Serializable {
    //  发送者ID
    public int id;

    //  是否为自动推荐的Feeder
    public boolean isRecom;

    //  Feeder名称
    public String name;

    //  logo
    public String logo;

    //  Feeder与用户的距离
    public String distance;

    //  发送者ID
    public String feederId;

    //  发送者类型
    public Type feederType;

    @Override
    public boolean equals(Object o) {
        if (o != null && o instanceof Feeder) {
            Feeder another = (Feeder) o;
            return another.id == id;
        }
        return false;
    }

    public static Feeder getMock(boolean isRecom) {
        Feeder mock = new Feeder();
        mock.isRecom = isRecom;
        mock.name = "海岸城";
        mock.logo = "http://3gimg.qq.com/weigou/hac_logo.png";
        mock.distance = "5km";
        return mock;
    }

    /**
     * Feeder类型
     * User: ethonchan
     * Date: 13-11-14
     * Time: 上午10:37
     */
    public enum Type implements Serializable{
        BRAND(1), MALL(2), SHOP(3);

        private int value;

        Type(int value) {
            this.value = value;
        }

        public static Type getFeederType(int type) {
            if (type == 1) {
                return BRAND;
            } else if (type == 2) {
                return MALL;
            } else {
                return SHOP;
            }
        }
    }
}
