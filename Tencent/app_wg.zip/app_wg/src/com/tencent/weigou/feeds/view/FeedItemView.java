package com.tencent.weigou.feeds.view;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import com.tencent.weigou.R;
import com.tencent.weigou.common.ui.AdaptiveImageView;
import com.tencent.weigou.feeds.model.Feed;
import com.tencent.weigou.feeds.model.Feeder;
import com.tencent.weigou.util.AsyncImageLoader;
import com.tencent.weigou.util.IImageLoadedCallBack;
import com.tencent.weigou.util.StringUtils;

/**
 * 动态列表中的单个元素
 * User: ethonchan
 * Date: 13-11-11
 * Time: 上午10:57
 */
public class FeedItemView extends FrameLayout implements IImageLoadedCallBack {

    //  新品数量的颜色
    public final static int NEW_ARRIVAL_COLOR = Color.rgb(63, 164, 242);

    //  每个feed左上方的那个猥琐的一段线条
//    private View mTopLine;

    //  Feeder的LOGO
    private AdaptiveImageView mLogoView;

    //  Feeder名称
    private TextView mNameView;

    //  提示语
    private TextView mTipsView;

    //  时间
    private TextView mTimeView;

    //  图片内容
    private FeedImage mImagesView;

    public FeedItemView(Context context) {
        super(context);
        init(context);
    }

    public FeedItemView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public FeedItemView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(context);
    }

    protected void init(Context context) {
        LayoutInflater inflater = LayoutInflater.from(context);
        inflater.inflate(R.layout.feed_item_layout, this);
        setBackgroundColor(Color.TRANSPARENT);

        //  发送者信息
        mLogoView = (AdaptiveImageView) findViewById(R.id.logo);
        mNameView = (TextView) findViewById(R.id.name);
        mTimeView = (TextView) findViewById(R.id.feed_time);

        //  图片
        mImagesView = (FeedImage) findViewById(R.id.feed_image);

        //  tips
        mTipsView = (TextView) findViewById(R.id.feed_desc);
    }

    /**
     * 设置Feed信息
     *
     * @param data
     * @param imgLoader
     */
    public void setData(Feed data, boolean isFirst, AsyncImageLoader imgLoader) {
        if (data == null) {
            return;
        }

        if(data.feeder != null && data.feeder.feederType == Feeder.Type.MALL)
        //  商场logo是方形
        {
            mLogoView.setDrawRectBorder(true);
        }else{
            mLogoView.setDrawCircleBorder(true);
        }

        //  展示发送者信息
        displayFeeder(data, imgLoader);

        //  展示图片
        mImagesView.setData(data, imgLoader);

        //  展示文字内容
        displayTips(data);
    }

    /**
     * 展示发送者信息
     *
     * @param data
     * @param imageLoader
     */
    private void displayFeeder(Feed data, AsyncImageLoader imageLoader) {
        if (data.feeder != null) {
            Feeder feeder = data.feeder;
            mNameView.setText(feeder.name);
            //  商场的图标是方的，其他都是圆的
            boolean needCornor = feeder.feederType != Feeder.Type.MALL;
            loadImage(mLogoView, needCornor, feeder.logo, imageLoader);
        }
    }

    /**
     * 展示文字内容
     *
     * @param data
     */
    private void displayTips(Feed data) {
        if (data == null) {
            return;
        }

        if (data.content != null) {
            mTipsView.setText(data.content.text);
            mTipsView.setVisibility(View.VISIBLE);
        } else if (data.newContent != null) {
            mTipsView.setText(data.newContent.title);
            mTipsView.setVisibility(View.VISIBLE);
        } else {
            mTipsView.setText("");
            mTipsView.setVisibility(View.GONE);
        }

        if(StringUtils.isNotBlank(data.timeStr)){
            mTimeView.setVisibility(View.VISIBLE);
            mTimeView.setText(data.timeStr);
        }else{
            mTimeView.setVisibility(View.GONE);
        }
    }

    /**
     * 加载图片
     *
     * @param view
     * @param url
     * @param needCornor 是否需要圆角
     * @param imageLoader
     */
    protected void loadImage(ImageView view, boolean needCornor, String url, AsyncImageLoader imageLoader) {
        if (view == null || imageLoader == null) {
            return;
        }

        view.setTag(url);
        Bitmap bitmap = imageLoader.loadDrawable(url, view, needCornor, this);
        if (bitmap != null) {
            view.setTag(null);
            view.setImageBitmap(bitmap);
        } else {
            ;
        }
    }

    @Override
    public void imageLoaded(final ImageView imageView, final Bitmap bitmap, final String imageUrl) {
        if (imageView == null) {
            return;
        }

        Object tag = imageView.getTag();
        if (tag != null && tag.equals(imageUrl)) {
            imageView.setImageBitmap(bitmap);
            imageView.setTag(null);
        }
    }

}
