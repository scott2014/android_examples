package com.tencent.weigou.feeds.model;

import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import com.tencent.weigou.feeds.view.FeedItemView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 单个Feed的结构信息
 * User: ethonchan
 * Date: 13-11-26
 * Time: 下午3:30
 */
public class Feed implements Comparable<Feed>, Serializable {
    //  Feed ID
    public int id;

    //  发送者
    public Feeder feeder = null;

    //  发送时间
    public String timeStr = "";

    //  Feed类型
    public Type type;

    //  Feed内容
    public Content content;

    //  (新品)Feed内容
    public NewContent newContent;

    @Override
    public int compareTo(Feed another) {
        if (another != null) {
            return another.id - id;
        } else {
            return -1;
        }
    }

    /**
     * 是否为推荐
     *
     * @return true是推荐，false不是推荐
     */
    public boolean isRecom() {
        if (feeder != null) {
            return feeder.isRecom;
        } else {
            return false;
        }
    }

    public static Feed getMock(int type, boolean isRecom) {
        Feed mock = new Feed();
        mock.feeder = Feeder.getMock(isRecom);
        mock.type = Type.getFeedType(type);
        if (mock.type != Type.NEW) {
            mock.content = Content.getMock();
        } else {
            mock.newContent = NewContent.getMock();
        }

        return mock;
    }

    /**
     * Feed内容（活动、推荐、折扣）
     */
    public static class Content implements Serializable{
        //  活动内容
        public String text;

        //  活动标题
        public String title;

        //  活动开始时间
        public String beginTime;

        //  活动结束时间
        public String endTime;

        //  活动图片
        public String picUrl;

        //  关联的门店名称
        public String related;

        //  跳转链接
        public String jumpUrl;

        public String getTimeStr() {
            return beginTime + "-" + endTime;
        }

        public static Content getMock() {
            Content mock = new Content();
            mock.text = "裤装包邮免费试穿活动火热实施中如果你还能够看见这里的文字只能说明你的屏幕真的好宽好宽";
            mock.title = mock.text;
            mock.beginTime = "10/21";
            mock.endTime = "11/3";
            mock.picUrl = "http://3gimg.qq.com/weigou/haiancheng.png";
            mock.related = "宝能店";
            return mock;
        }
    }

    /**
     * Feed内容（新品）
     */
    public static class NewContent implements Serializable{

        public NewContent(String ownerName) {
            this.owner = ownerName;
        }

        //  所有者的名字
        private String owner;

        //  标题
        public String title;

        //  新品图片
        public List<String> picUrls;

        //  上新数量
        public int newArrivalNum;

        //  店铺url
        public String shopPicUrl;

        //  店铺名称
        public String shopName;

        //  跳转链接
        public String jumpUrl;

        //  发送时间
        public String timeStr;

        public static NewContent getMock() {
            NewContent mock = new NewContent("海岸城店");
            mock.newArrivalNum = 20;
            mock.picUrls = new ArrayList<String>();
            int num = (int) (Math.random() * 6) - 1;
            for (int i = 0; i < num; i++) {
                mock.picUrls.add("http://3gimg.qq.com/weigou/haiancheng.png");
            }
            mock.shopPicUrl = "http://3gimg.qq.com/weigou/haiancheng.png";
            mock.shopName = "海岸城店";
            return mock;
        }

        public CharSequence getArrivalString() {
            SpannableStringBuilder builder = new SpannableStringBuilder();
            if (newArrivalNum > 0) {
                int start = 0;
//                if (StringUtils.isNotBlank(owner)) {
//                    builder.append(owner);
//                    start = owner.length();
//                }
                builder.append("上新");
                start += 2;

                builder.append(" " + newArrivalNum + " ");

                builder.append("件");
                ForegroundColorSpan colorSpan = new ForegroundColorSpan(FeedItemView.NEW_ARRIVAL_COLOR);
                builder.setSpan(colorSpan, start, builder.length() - 1, Spannable.SPAN_INCLUSIVE_INCLUSIVE);
            }

            return builder;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (o != null && o instanceof Feed) {
            Feed another = (Feed) o;
            return another.id == id;
        }
        return false;
    }

    @Override
    public int hashCode() {
        return id;
    }

    /**
     * Feed类型
     * User: ethonchan
     * Date: 13-10-31
     * Time: 下午7:22
     */
    public enum Type implements Serializable {
        ACTIVITY("活动"),
        NEW("新品"),
        RECOMMENDATION("推荐"),
        DISCOUNT("折扣");

        //  描述
        private String desc;

        Type(String str) {
            this.desc = str;
        }

        public String getDesc() {
            return desc;
        }

        /**
         * 根据类型取值判断出对应的Feed类型
         *
         * @param type 服务端返回的类型字段取值
         * @return 客户端识别的Feed类型
         */
        public static Type getFeedType(int type) {
            if (type == 1) {
                return ACTIVITY;
            } else if (type == 2) {
                return DISCOUNT;
            } else if (type == 3) {
                return NEW;
            } else {
                return ACTIVITY;
            }
        }
    }
}
