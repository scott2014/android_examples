package com.tencent.weigou.feeds.activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;

import com.tencent.weigou.R;
import com.tencent.weigou.base.App;
import com.tencent.weigou.base.activity.BottomBarActivity;
import com.tencent.weigou.cache.CacheInfo;
import com.tencent.weigou.cache.CacheUtils;
import com.tencent.weigou.common.ui.BottomBar;
import com.tencent.weigou.common.ui.draggable.OnRefreshListener;
import com.tencent.weigou.common.ui.draggable.OverScrollView;
import com.tencent.weigou.feeds.model.Feed;
import com.tencent.weigou.feeds.model.FeedListVo;
import com.tencent.weigou.feeds.model.FeedModel;
import com.tencent.weigou.feeds.model.Feeder;
import com.tencent.weigou.feeds.ui.FeedUI;
import com.tencent.weigou.feeds.view.FeedItemView;
import com.tencent.weigou.recom.activity.RecomActivity;
import com.tencent.weigou.shopping.model.ShoppingModel;
import com.tencent.weigou.util.*;
import com.tencent.weigou.util.lbs.LBSUtils;
import com.tencent.weigou.util.lbs.Location;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * 动态列表activity User: ethonchan Date: 13-11-26 Time: 下午4:24
 */
public class FeedListActivity extends BottomBarActivity implements
		OnRefreshListener, AdapterView.OnItemClickListener, OnClickListener {

	private FeedUI mFeedUI;

	private FeedModel mFeedModel;

	private MyListAdapter mAdapter;

	// 图片加载控制器
	private AsyncImageLoader mImageLoader = new AsyncImageLoader(true);

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		mFeedUI = new FeedUI();
		mFeedModel = new FeedModel();
		initMVC(mFeedModel, mFeedUI, R.layout.feed_list_layout);

		setTitle(R.string.bottom_dynamic_title);
		selectBottomBar(1, true);

		// 获取从app外部传入的参数
		Intent intent = getIntent();
		if (intent != null) {
			String jumpStr = intent.getDataString();
			if (StringUtils.isNotBlank(jumpStr)) {
				CommonJumpUtils.go(this, jumpStr);
			}
		}

		mImageLoader.setNeedCorner(false);

		mAdapter = new MyListAdapter();
		mFeedUI.setAdapter(mAdapter);

		mFeedUI.setOnRefreshListener(this);
		mFeedUI.setFeedClickListener(this);

		mFeedUI.setAddFeedListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// 跳去推荐关注
				Intent intent = new Intent(FeedListActivity.this,
						RecomActivity.class);
				intent.putExtra(ConstantsActivity.INTENT_SOURCE_ACTIVITY,
						FeedListActivity.class.getSimpleName());
				startActivity(intent);
				finish();
			}
		});
		init();
	}

	private void init() {
		if (!isLogin()) {
			toLogin();
		} else {
			// // 利用本地缓存初始化
			// initListWithCache();
			//
			// if (mAdapter.getCount() != 0) {
			// mFeedUI.hideEmptyView();
			// }

			// 构造请求更新动态
			String url = getFeedsUrl(Integer.MAX_VALUE, true);
			mFeedModel.initData(url);
		}
	}

	@Override
	protected void onResume() {
		super.onResume();
		if (mAdapter.getCount() == 0) {
			init();
			// mFeedUI.hideNetworkUnavailable();
		}
	}

	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		// 获取从app外部传入的参数
		if (intent != null) {
			String jumpStr = intent.getDataString();
			if (StringUtils.isNotBlank(jumpStr)) {
				CommonJumpUtils.go(this, jumpStr);
			}
		}
	}

	/**
	 * 利用本地缓存来初始化列表
	 */
	protected void initListWithCache() {
		CacheInfo cacheInfo = CacheUtils.getFromCache(getCacheUrl());
		if (cacheInfo != null && cacheInfo.isValid()) {
			ObjectInputStream oins = null;
			try {
				ByteArrayInputStream bins = new ByteArrayInputStream(
						cacheInfo.getValue());
				oins = new ObjectInputStream(bins);
				Object obj = oins.readObject();
				oins.close();
				List<Feed> feedList = (List<Feed>) obj;
				mAdapter.appendFeeds(feedList);
				Log.d(TAG, "Success initFeedsWithCache");
			} catch (Exception e) {
				Log.e(TAG, "Exception in initFeedWithCache", e);
				CacheUtils.clearCache(getCacheUrl());
				if (oins != null) {
					IOUtils.closeQuietly(oins);
				}
			}
		} else {
			Log.d(TAG, "no Data to initFeedsWithCache");
		}
	}

	/**
	 * 拼接当前请求Feeds的url
	 * 
	 * @param maxId
	 * @return
	 */
	private String getFeedsUrl(int maxId, boolean pv) {
		Location loc = LBSUtils.getLocation();
		String url = app.getEnv().getServerUrl() + ConstantsUrl.GET_FEEDS;
		url += "?longitude=" + loc.longitude;
		url += "&latitude=" + loc.latitude;
		if (maxId > 0) {
			url += "&maxId=" + maxId;
		}

		if (pv) {
			url = appendPageInfo(url, PageIds.OprIndex.PV_OPR);
		} else {
			url = appendPageInfo(url, PageIds.OprIndex.NON_PV_OPR);
		}

		return url;
	}

	/**
	 * 得到本地缓存的url
	 * 
	 * @return
	 */
	private String getCacheUrl() {
		String url = ConstantsUrl.GET_CACHE_FEEDS;
		if (isLogin()) {
			url += "?wid=" + app.getUser().wId;
		}
		return url;
	}

	@Override
	public void update(int notificationId) {
		super.update(notificationId);
		if (notificationId == FeedModel.FEED_LIST_INIT_DONE)
		// 初始化完成
		{
			FeedListVo feeds = mFeedModel.getHeaderFeeds();
			if (feeds == null) {
				mFeedUI.resetHeader(false);
				mFeedUI.showEmptyView();
			} else if (feeds.feedList == null || feeds.feedList.size() == 0) {
				mFeedUI.resetHeader(true);
				onNewFeedsReaded();
				mFeedUI.showEmptyView();
			} else
			// 获取到了新数据
			{
				mFeedUI.resetHeader(true);
				onNewFeedsReaded();

				// 清除旧的缓存数据
				// 展示新动态
				mAdapter.prependFeeds(feeds.feedList, true);
				if (feeds.feedList.size() > 0) {
					mFeedUI.hideEmptyView();
				}
				// 更新缓存
				updateCache(mAdapter.feedList);
			}
			mFeedUI.hideNetworkUnavailable();
		} else if (notificationId == FeedModel.FEED_LIST_REFRESH_FOOTER_DONE)
		// 刷新页尾
		{
			FeedListVo feeds = mFeedModel.getFooterFeeds();
			if (feeds != null && feeds.feedList != null) {
				mFeedUI.resetFooter(true);
				mAdapter.appendFeeds(feeds.feedList);
			} else {
				mFeedUI.resetFooter(false);
			}
		} else if (notificationId == FeedModel.FEED_LIST_REFRESH_HEADER_DONE)
		// 刷新页头
		{
			FeedListVo feeds = mFeedModel.getHeaderFeeds();
			if (feeds != null && feeds.feedList != null) {
				mFeedUI.resetHeader(true);
				mAdapter.prependFeeds(feeds.feedList, false);
				if (feeds.feedList.size() > 0) {
					mFeedUI.hideEmptyView();
				}
			} else {
				mFeedUI.resetHeader(false);
			}
		}
	}

	@Override
	protected void onNetworkUnavailable(int notificationId) {
		switch (notificationId) {
		case FeedModel.FEED_LIST_INIT_DONE:
			mFeedUI.showNetworkUnavailable();
			break;
		default:
			showNetworkUnavailableToast(Constants.TOAST_NORMAL_LONG);
			mFeedUI.resetHeader(false);
			mFeedUI.resetFooter(false);
			break;
		}
	}

	/**
	 * 更新缓存
	 * 
	 * @param feeds
	 */
	protected void updateCache(final ArrayList<Feed> feeds) {
		App.sWorker.post(new Runnable() {
			@Override
			public void run() {
				if (feeds != null) {
					ArrayList<Feed> copy = new ArrayList<Feed>();
					copy.addAll(feeds);
					ObjectOutputStream outs = null;
					try {
						ByteArrayOutputStream bouts = new ByteArrayOutputStream();
						outs = new ObjectOutputStream(bouts);
						outs.writeObject(copy);
						byte[] data = bouts.toByteArray();
						outs.close();
						CacheUtils.saveToCache(getCacheUrl(),
								System.currentTimeMillis(), Long.MAX_VALUE,
								data);
						Log.d("TAG", "Success saveFeeds2Cache");
					} catch (Exception e) {
						Log.e("TAG", "Exception when saveFeeds2Cache", e);
						CacheUtils.clearCache(getCacheUrl());
						if (outs != null) {
							IOUtils.closeQuietly(outs);
						}
					}
				}
			}
		});
	}

	/**
	 * 新动态已读
	 */
	protected void onNewFeedsReaded() {
		View v = findViewById(R.id.bottom_bar);
		if (v != null) {
			BottomBar bar = (BottomBar) v;
			bar.onNoNewFeeds();
		}
		app.setHasNewFeeds(false);
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		Object tag = view.getTag();
		if (tag != null && tag instanceof Feed) {
			Feed feed = (Feed) tag;
			// 整理详情页面所需数据
			FeedDetailActivity.Data data = new FeedDetailActivity.Data();
			// 获取发送者ID, NAME
			if (feed.feeder != null) {
				data.targetId = "" + feed.feeder.feederId;
				data.targetName = feed.feeder.name;
				data.targetType = feed.feeder.feederType;
			} else {
				data.targetId = "0";
				data.targetName = "";
				data.targetType = Feeder.Type.SHOP;
			}
			// 获取Feed类型

			if (feed.content != null) {
				Feed.Content content = feed.content;
				data.url = content.jumpUrl;
				data.shareDesc = content.text;
				data.shareImageUrl = content.picUrl;
			} else if (feed.newContent != null) {
				Feed.NewContent content = feed.newContent;
				data.url = content.jumpUrl;
				data.shareDesc = content.getArrivalString().toString();
				if (StringUtils.isNotBlank(content.shopPicUrl)) {
					data.shareImageUrl = content.shopPicUrl;
				} else if (content.picUrls != null
						&& content.picUrls.size() > 0) {
					data.shareImageUrl = content.picUrls.get(0);
				}
			}

			if (StringUtils.isNotBlank(data.url)) {
				Intent intent = new Intent(this, FeedDetailActivity.class);
				intent.putExtra(FeedDetailActivity.INTENT_DATA, data);
				startActivity(intent);
			}
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (mImageLoader != null) {
			mImageLoader.destroy();
		}
	}

	@Override
	public void onRefreshing(OverScrollView view, Object obj) {
		if (view == null) {
			return;
		}

		if (view.isHeader()) {
			String url = getFeedsUrl(0, false);
			mFeedModel.refreshHeader(url);
		} else {
			String url = getFeedsUrl(mAdapter.lastFeedId, false);
			mFeedModel.refreshFooter(url);
		}
	}

	class MyListAdapter extends BaseAdapter {
		private ArrayList<Feed> feedList = new ArrayList<Feed>();

		// 第一个元素是否Label在左边
		private boolean first2Left = true;

		private Lock mLock = new ReentrantLock();

		protected int lastFeedId = Integer.MAX_VALUE;

		@Override
		public int getCount() {
			return feedList == null ? 0 : feedList.size();
		}

		@Override
		public Object getItem(int position) {
			return feedList.get(position);
		}

		public void prependFeeds(List<Feed> newFeeds, boolean clearOldFeeds) {
			if (newFeeds != null) {
				mLock.lock();

				try {
					if (clearOldFeeds) {
						feedList.clear();
					}

					List<Feed> newCopy = new ArrayList<Feed>();
					for (Feed feed : newFeeds) {
						if (!feedList.contains(feed)) {
							newCopy.add(feed);
						}
					}
					feedList.addAll(0, newCopy);

					updateLastFeedId();
				} finally {
					mLock.unlock();
				}

				notifyDataSetChanged();
			} else if (clearOldFeeds) {
				mLock.lock();
				try {
					feedList.clear();
				} finally {
					mLock.unlock();
				}
			}
		}

		public void appendFeeds(List<Feed> newFeeds) {
			if (newFeeds != null) {
				mLock.lock();
				try {
					for (Feed feed : newFeeds) {
						if (!feedList.contains(feed)) {
							feedList.add(feed);
						}
					}

					updateLastFeedId();
				} finally {
					mLock.unlock();
				}

				notifyDataSetChanged();
			}
		}

		/**
		 * 更新已展示的最后一个Feed的Id
		 */
		private void updateLastFeedId() {
			final int len = feedList.size();
			if (len > 0) {
				lastFeedId = feedList.get(len - 1).id;
			}
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View view, ViewGroup parent) {
			if (view == null) {
				view = new FeedItemView(FeedListActivity.this);
			}

			FeedItemView feedView = (FeedItemView) view;
			Feed feed = feedList.get(position);
			feedView.setData(feed, position == 0, mImageLoader);
			view.setTag(feed);

			return view;
		}
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.refreshBtn:
			mFeedUI.hideNetworkUnavailable();
			init();
			break;
		}
	}
}
