package com.tencent.weigou.feeds.model;

import com.tencent.weigou.base.model.vo.CommonVo;
import com.tencent.weigou.util.StringUtils;
import com.tencent.weigou.util.Util;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.*;

/**
 * Feed列表的结果vo
 * User: ethonchan
 * Date: 13-11-26
 * Time: 下午3:29
 */
public class FeedListVo extends CommonVo {

    //  获取到的Feed列表
    public List<Feed> feedList;

    //  还有新的未读消息
    public boolean hasNew = false;

    @Override
    public boolean parse(JSONObject data) {
        feedList = null;

        if (data != null) {
            hasNew = data.optBoolean("hasMore", true);
            //  解析Feeder
            JSONArray feederJson = data.optJSONArray("feederList");
            Map<Integer, Feeder> feederMap = jsonToFeederMap(feederJson);

            //  解析Feed
            JSONArray feedObj = data.optJSONArray("feedsList");
            feedList = jsonToFeedList(feedObj, feederMap);
        }
        return super.parse(data);
    }

    /**
     * 将JSON解析为对应的Feeder信息
     *
     * @param array JSON信息
     * @return
     */
    protected Map<Integer, Feeder> jsonToFeederMap(JSONArray array) {
        if (array == null) {
            return null;
        }

        final int len = array.length();
        Map<Integer, Feeder> map = new HashMap<Integer, Feeder>(len);
        for (int i = 0; i < len; i++) {
            JSONObject json = array.optJSONObject(i);
            if (json == null) {
                continue;
            }

            Feeder feeder = new Feeder();
            feeder.id = json.optInt("feederId", 0);
            //  source=2表示为自动推荐的
            int source = json.optInt("source", 1);
            feeder.isRecom = source == 2;

            feeder.name = json.optString("name", "");
            feeder.logo = json.optString("logoUrl", "");
            int dist = json.optInt("distance", 0);
            feeder.distance = Util.getKMstr(dist);
            feeder.feederId = json.optString("providerId", "0");
            int type = json.optInt("providerType", 0);
            feeder.feederType = Feeder.Type.getFeederType(type);

            map.put(feeder.id, feeder);
        }

        return map;
    }

    /**
     * 将JSON解析为对应的Feed信息
     *
     * @param array     包含Feed的json对象
     * @param feederMap Feeder信息，用于根据id查找对应的feeder
     * @return
     */
    protected List<Feed> jsonToFeedList(JSONArray array, Map<Integer, Feeder> feederMap) {
        if (array == null || feederMap == null) {
            return null;
        }

        final int len = array.length();
        List<Feed> feeds = new ArrayList<Feed>(len);
        for (int i = 0; i < len; i++) {
            JSONObject feedObj = array.optJSONObject(i);
            if (feedObj == null) {
                continue;
            }

            Feed feed = new Feed();
            feed.id = feedObj.optInt("feedsId", 0);
            feed.timeStr = feedObj.optString("feedTime", "");

            int feederId = feedObj.optInt("feederId", 0);
            String feederName = "";
            if (feederMap != null) {
                Feeder feeder = feederMap.get(feederId);

                feed.feeder = feeder;
                feederName = feeder.name;
            }
            //  解析类型，默认为1（活动）
            int feedsType = feedObj.optInt("type", 1);
            feed.type = Feed.Type.getFeedType(feedsType);

            JSONObject conObj = feedObj.optJSONObject("content");
            if (conObj != null) {
                if (feed.type == Feed.Type.NEW) {
                    feed.newContent = jsonToNewContent(conObj, feederName);
                    feed.timeStr = feed.newContent.timeStr;
                } else {
                    feed.content = jsonToContent(conObj);
                    feed.timeStr = feed.content.beginTime;
                }
            }

            feeds.add(feed);
        }
        Collections.sort(feeds);
        return feeds;
    }

    /**
     * JSON解析为Content
     *
     * @param json 要解析的JSON对象
     * @return
     */
    protected Feed.Content jsonToContent(JSONObject json) {
        Feed.Content content = new Feed.Content();
        content.text = json.optString("content", "");
        content.title = json.optString("title", "");
        content.beginTime = json.optString("beginTime", "");
        content.endTime = json.optString("endTime", "");
        content.picUrl = json.optString("picUrl", "");
        content.related = json.optString("raleShop", "");
        content.jumpUrl = json.optString("jumpUrl", "");
        return content;
    }

    /**
     * JSON解析为NewContent
     *
     * @param json 要解析的JSON对象
     * @return
     */
    protected Feed.NewContent jsonToNewContent(JSONObject json, String feeder) {
        Feed.NewContent content = new Feed.NewContent(feeder);
        JSONArray urls = json.optJSONArray("itemPicUrls");
        if (urls != null) {
            final int len = urls.length();
            ArrayList<String> picUrls = new ArrayList<String>(len);
            for (int i = 0; i < len; i++) {
                String url = urls.optString(i);
                if (StringUtils.isNotBlank(url)) {
                    picUrls.add(url);
                }
            }
            content.picUrls = picUrls;
        }
        content.title = json.optString("title", "");
        content.newArrivalNum = json.optInt("newItemCount", 0);
        content.shopPicUrl = json.optString("shopPicUrl", "");
        content.shopName = json.optString("shopName", "");
        content.jumpUrl = json.optString("jumpUrl", "");
        content.timeStr = json.optString("beginTime", "");
        return content;
    }
}
