package com.tencent.weigou.feeds.ui;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.tencent.weigou.R;
import com.tencent.weigou.base.view.UI;
import com.tencent.weigou.common.ui.draggable.DraggableListView;
import com.tencent.weigou.common.ui.draggable.OnRefreshListener;
import com.tencent.weigou.feeds.activity.FeedListActivity;
import com.tencent.weigou.shopping.activity.ShoppingIndexActivity;

/**
 * User: ethonchan Date: 13-11-1 Time: 下午3:11
 */
public class FeedUI extends UI {
	// 无消息时显示的view
	private View mEmptyView;

	// 添加Feeds的按钮
	// private View mAddFeedsBtn;

	private DraggableListView mList;
	RelativeLayout networkRL;

	@Override
	public void initView(View outterView) {
		super.initView(outterView);
		networkRL = (RelativeLayout) findViewById(R.id.network_un);
		mList = (DraggableListView) outterView.findViewById(R.id.list);
		mEmptyView = outterView.findViewById(R.id.feed_empty_view);
		// 初始化EmptyViewHolder
		EmptyViewHolder emptyViewHolder = new EmptyViewHolder();
		emptyViewHolder.addFeedBtn = mEmptyView.findViewById(R.id.add_feeds);
		emptyViewHolder.tipsView = (TextView) mEmptyView
				.findViewById(R.id.tips_tv);
		emptyViewHolder.tipsDescView = (TextView) mEmptyView
				.findViewById(R.id.tips_desc_tv);
		mEmptyView.setTag(emptyViewHolder);
		// mAddFeedsBtn = mEmptyView.findViewById(R.id.add_feeds);
	}

	/**
	 * 空白view对应的holder
	 */
	static class EmptyViewHolder {
		// 提示语
		public TextView tipsView;
		// 第二层提示语
		public TextView tipsDescView;
		// 添加关注按钮
		public View addFeedBtn;
	}

	/**
	 * 隐藏无消息view
	 */
	public void hideEmptyView() {
		mEmptyView.setVisibility(View.GONE);
		mList.setVisibility(View.VISIBLE);
	}

	/**
	 * 网络不可用
	 */
	public void onNetworkUnavailable() {
		mList.resetFoot(false);
		mList.resetHead(false);
//		showEmptyView();
		Object tagObj = mEmptyView.getTag();
		if (tagObj != null) {
			EmptyViewHolder holder = (EmptyViewHolder) tagObj;
			holder.addFeedBtn.setVisibility(View.INVISIBLE);
			holder.tipsView.setText(context
					.getString(R.string.network_unavailable_tips_v2));
			holder.tipsDescView.setText(context
					.getString(R.string.please_check_network_v2));
		}
	}

	/**
	 * 显示无消息view
	 */
	public void showEmptyView() {
		mEmptyView.setVisibility(View.VISIBLE);
		mList.setVisibility(View.GONE);
	}

	/**
	 * 添加关注按钮监听器
	 * 
	 * @param listener
	 */
	public void setAddFeedListener(View.OnClickListener listener) {
		if (mEmptyView != null && mEmptyView.getTag() != null) {
			EmptyViewHolder holder = (EmptyViewHolder) mEmptyView.getTag();
			holder.addFeedBtn.setOnClickListener(listener);
		}
		// mAddFeedsBtn.setOnClickListener(listener);
	}

	public void setAdapter(ListAdapter adapter) {
		if (mList != null) {
			mList.setAdapter(adapter);
		}
	}

	public void resetFooter(boolean updateTime) {
		mList.resetFoot(updateTime);
	}

	public void resetHeader(boolean updateTime) {
		mList.resetHead(updateTime);
	}

	/**
	 * 设置刷新事件监听器
	 * 
	 * @param listener
	 */
	public void setOnRefreshListener(OnRefreshListener listener) {
		mList.setRefreshListener(listener);
	}

	/**
	 * 设置Feed点击监听器
	 * 
	 * @param listener
	 */
	public void setFeedClickListener(AdapterView.OnItemClickListener listener) {
		mList.setOnItemClickListener(listener);
	}

	public void hideNetworkUnavailable() {
		networkRL.setVisibility(View.GONE);
	}

	public void showNetworkUnavailable() {
		networkRL.setVisibility(View.VISIBLE);
		networkRL.setOnClickListener(null);
		networkRL.findViewById(R.id.refreshBtn).setOnClickListener(
				(FeedListActivity) context);

	}
}
