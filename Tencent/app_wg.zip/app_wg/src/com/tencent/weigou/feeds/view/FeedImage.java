package com.tencent.weigou.feeds.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import com.tencent.weigou.R;
import com.tencent.weigou.feeds.model.Feed;
import com.tencent.weigou.util.AsyncImageLoader;
import com.tencent.weigou.util.IImageLoadedCallBack;
import com.tencent.weigou.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Feed图片
 * User: ethonchan
 * Date: 13-11-11
 * Time: 上午11:48
 */
public class FeedImage extends FrameLayout implements IImageLoadedCallBack {

    //  活动的背景颜色
    protected final static int ACTIVITY_COLOR = Color.rgb(37, 211, 169);

    //  折扣颜色
    protected final static int DISCOUNT_COLOR = Color.rgb(229, 58, 27);

    //  新品的颜色
    protected final static int NEW_COLOR = Color.rgb(63, 164, 242);

    protected final static double HEIGHT_WIDTH_RATIO = 0.49D;

    protected final static double HEIGHT_WIDTH_RATIO_FOR_NEW = 0.51D;

    private ImageView[] mImages = new ImageView[5];

    //  空白时展示的view
    private TextView mTextView;

    //  新品TAG
    private TextView mTagView;

    //  需要加载的图片url
    private List<String> urls = null;

    //  Feed类型
    private Feed.Type mType = Feed.Type.ACTIVITY;

    protected final static int IMAGE_GAP = 2;

    public FeedImage(Context context) {
        super(context);
        init(context);
    }

    public FeedImage(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public FeedImage(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(context);
    }

    private void init(Context context) {
        LayoutInflater inflater = LayoutInflater.from(context);
        inflater.inflate(R.layout.feed_image, this);

        mImages[0] = (ImageView) findViewById(R.id.imageA);
        mImages[1] = (ImageView) findViewById(R.id.imageB);
        mImages[2] = (ImageView) findViewById(R.id.imageC);
        mImages[3] = (ImageView) findViewById(R.id.imageD);
        mImages[4] = (ImageView) findViewById(R.id.imageE);
        mTextView = (TextView) findViewById(R.id.title);
        mTagView = (TextView) findViewById(R.id.tag);
        mTagView.setBackgroundColor(NEW_COLOR);
    }

    /**
     * 设置要展示的图片数据
     *
     * @param data
     * @param imageLoader
     */
    public void setData(Feed data, AsyncImageLoader imageLoader) {
        //  清除旧的图片数据
        for(ImageView imageView : mImages){
            imageView.setImageResource(0);
        }

        //  保存图片的链接数据
        if (data != null) {
            if (data.content != null) {
                urls = new ArrayList<String>(1);
                if (StringUtils.isNotBlank(data.content.picUrl)) {
                    urls.add(data.content.picUrl);
                }
            } else if (data.newContent != null) {
                if (data.newContent.picUrls == null || data.newContent.picUrls.size() < 1) {
                    urls = new ArrayList<String>(1);
                    if (StringUtils.isNotBlank(data.newContent.shopPicUrl)) {
                        urls.add(data.newContent.shopPicUrl);
                    }
                } else {
                    urls = new ArrayList<String>();
                    urls.addAll(data.newContent.picUrls);
                }
            } else {
                urls = null;
            }
            mType = data.type;
        } else {
            urls = null;
            mType = Feed.Type.ACTIVITY;
        }

        if (data.content != null) {
            mTextView.setText(data.content.title);
        } else if (data.newContent != null) {
            mTextView.setText(data.newContent.title);
        } else if (data.feeder != null) {
            mTextView.setText(data.feeder.name);
        }

        //  加载对应的图片数据
        if (urls != null) {
            final int len = urls.size();
            int index = 0;
            while (index < 5 && index < len) {
                if (index < len) {
                    mImages[index].setVisibility(View.VISIBLE);
                    loadImage(mImages[index], urls.get(index), imageLoader);
                } else {
                    mImages[index].setVisibility(View.GONE);
                }
                index++;
            }
        }
    }

    /**
     * 加载图片
     *
     * @param view
     * @param url
     * @param imageLoader
     */
    protected void loadImage(ImageView view, String url, AsyncImageLoader imageLoader) {
        if (view == null || imageLoader == null) {
            return;
        }

        view.setTag(url);
        Bitmap bitmap = imageLoader.loadDrawable(url, view, this);
        if (bitmap != null) {
            view.setImageBitmap(bitmap);
            view.setTag(null);
        }
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int height = (int) (width * getRatioByType(mType));
        setMeasuredDimension(width, height);

        int newHeightSpec = MeasureSpec.makeMeasureSpec(height, MeasureSpec.EXACTLY);
        super.onMeasure(widthMeasureSpec, newHeightSpec);
    }

    private int getBackgroundColorByType(Feed.Type type) {
        int bgColor;
        if (type == Feed.Type.NEW) {
            bgColor = NEW_COLOR;
        } else if (type == Feed.Type.DISCOUNT) {
            bgColor = DISCOUNT_COLOR;
        } else if (type == Feed.Type.ACTIVITY) {
            bgColor = ACTIVITY_COLOR;
        } else {
            bgColor = Color.WHITE;
        }
        return bgColor;
    }

    private double getRatioByType(Feed.Type type) {
//        double ratio;
//        if (type == Feed.Type.NEW) {
//            ratio = HEIGHT_WIDTH_RATIO_FOR_NEW;
//        } else if (type == Feed.Type.DISCOUNT) {
//            ratio = HEIGHT_WIDTH_RATIO;
//        } else if (type == Feed.Type.ACTIVITY) {
//            ratio = HEIGHT_WIDTH_RATIO;
//        } else {
//            ratio = HEIGHT_WIDTH_RATIO;
//        }
//        return ratio;
        return HEIGHT_WIDTH_RATIO_FOR_NEW;
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        int width = right - left;
        int height = bottom - top;

        final int imageNum = urls == null ? 0 : urls.size();
        if (imageNum == 0)
        //      无图片
        {
            setBackgroundColor(getBackgroundColorByType(mType));
            mTextView.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED);
            int textWidth = mTextView.getMeasuredWidth();
            int textHeight = mTextView.getMeasuredHeight();
            int textLeft = (width - textWidth) / 2;
            int textTop = (height - textHeight) / 2;
            int textRight = (width + textWidth) / 2;
            int textBottom = (height + textHeight) / 2;
            mTextView.layout(textLeft, textTop, textRight, textBottom);

            for (View view : mImages) {
                layoutView(view, new LayoutCoord(0, 0, 0, 0));
            }
        } else {
            setBackgroundColor(0);
            mTextView.layout(0, 0, 0, 0);

            LayoutCoord[] views = getViewsByNumber(imageNum, width, height);
            if (views != null) {
                for (int i = 0, len = views.length; i < len; i++) {
                    LayoutCoord coord = views[i];
                    if (coord == null) {
                        layoutView(mImages[i], new LayoutCoord(0, 0, 0, 0));
                    } else {
                        layoutView(mImages[i], coord);
                    }
                }
            }
        }


        //  如果是新品展示新品的tag
        if (mType == Feed.Type.NEW) {
            mTagView.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED);
            int tagWidth = mTagView.getMeasuredWidth();
            int tagHeight = mTagView.getMeasuredHeight();
            int tagTop = height > tagHeight ? height - tagHeight : 0;
            LayoutCoord coord = new LayoutCoord(0, tagTop, tagWidth, tagHeight);
            layoutView(mTagView, coord);
        } else {
            mTagView.layout(0, 0, 0, 0);
        }
    }

    /**
     * 根据数字拿到对应的myView信息
     *
     * @param imageNum
     * @return
     */
    protected LayoutCoord[] getViewsByNumber(int imageNum, int viewWidth, int viewHeight) {
        LayoutCoord[] views = new LayoutCoord[5];

        if (imageNum > 4)
        //  大于等于5张图片
        {
            int widthA = viewWidth / 2;
            int widthBD = viewWidth / 4;
            int widthCE = viewWidth - widthA - widthBD - 2 * IMAGE_GAP;

            int heightBC = viewHeight / 2;
            int topDE = heightBC + IMAGE_GAP;
            int heightDE = viewHeight - topDE;
            int leftBD = widthA + IMAGE_GAP;
            int leftCE = leftBD + widthBD + IMAGE_GAP;
            views[0] = new LayoutCoord(0, 0, widthA, viewHeight);
            views[1] = new LayoutCoord(leftBD, 0, widthBD, heightBC);
            views[2] = new LayoutCoord(leftCE, 0, widthCE, heightBC);
            views[3] = new LayoutCoord(leftBD, topDE, widthBD, heightDE);
            views[4] = new LayoutCoord(leftCE, topDE, widthCE, heightDE);
        } else if (imageNum == 4) {
            int widthA = (int) (viewWidth * 210 / 560D);
            int leftB = widthA + IMAGE_GAP;
            int leftCD = leftB + widthA + IMAGE_GAP;
            int widthCD = viewWidth - leftCD;
            int heightC = viewHeight / 2;
            int topD = heightC + IMAGE_GAP;
            int heightD = viewHeight - topD;
            views[0] = new LayoutCoord(0, 0, widthA, viewHeight);
            views[1] = new LayoutCoord(leftB, 0, widthA, viewHeight);
            views[2] = new LayoutCoord(leftCD, 0, widthCD, heightC);
            views[3] = new LayoutCoord(leftCD, topD, widthCD, heightD);
        } else if (imageNum == 3) {
            int widthA = (int) ((viewWidth * 420) / 560D);
            int leftBC = widthA + IMAGE_GAP;
            int widthBC = viewWidth - leftBC;
            int heightB = viewHeight / 2;
            int topC = heightB + IMAGE_GAP;
            int heightC = viewHeight - topC;
            views[0] = new LayoutCoord(0, 0, widthA, viewHeight);
            views[1] = new LayoutCoord(leftBC, 0, widthBC, heightB);
            views[2] = new LayoutCoord(leftBC, topC, widthBC, heightC);
        } else if (imageNum == 2) {
            int widthA = viewWidth / 2;
            int leftB = widthA + IMAGE_GAP;
            int widthB = viewWidth - leftB;
            views[0] = new LayoutCoord(0, 0, widthA, viewHeight);
            views[1] = new LayoutCoord(leftB, 0, widthB, viewHeight);
        } else if (imageNum == 1) {
            views[0] = new LayoutCoord(0, 0, viewWidth, viewHeight);
        }

        return views;
    }

    protected void layoutView(View view, LayoutCoord coord) {
        if (view != null && coord != null) {
            int widthMeasureSpec = MeasureSpec.makeMeasureSpec(coord.width, MeasureSpec.EXACTLY);
            int heightMeasureSpec = MeasureSpec.makeMeasureSpec(coord.height, MeasureSpec.EXACTLY);
            view.measure(widthMeasureSpec, heightMeasureSpec);

            view.layout(coord.left, coord.top, coord.left + coord.width, coord.top + coord.height);
        }
    }

    @Override
    public void imageLoaded(final ImageView imageView, final Bitmap bitmap, final String imageUrl) {
        if (imageView != null) {
            Object tag = imageView.getTag();
            if (tag != null && tag.equals(imageUrl)) {
                imageView.setImageBitmap(bitmap);
                imageView.setTag(null);
            }
        }
    }

    static class LayoutCoord {
        int left = 0;

        int top = 0;

        int width = 0;

        int height = 0;

        LayoutCoord(int left, int top, int width, int height) {
            this.left = left;
            this.top = top;
            this.width = width;
            this.height = height;
        }
    }
}
