package com.tencent.weigou.feeds.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.DownloadListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.TextView;
import android.widget.Toast;
import com.tencent.weigou.R;
import com.tencent.weigou.base.activity.TitleBarActivity;
import com.tencent.weigou.exception.activity.NetworkUnavailableActivity;
import com.tencent.weigou.feeds.model.Feeder;
import com.tencent.weigou.shopping.activity.MallDetailActivity;
import com.tencent.weigou.shopping.activity.ShopPagerActivity;
import com.tencent.weigou.util.*;
import com.tencent.weigou.web.CustomWebChromeClient;
import com.tencent.weigou.web.CustomWebView;
import com.tencent.weigou.web.CustomWebViewClient;
import com.tencent.weigou.web.OnPageLoadingListener;
import com.tencent.weigou.wxapi.WXUtils;

import java.io.Serializable;

/**
 * 动态详情页面 User: ethonchan Date: 13-11-9 Time: 下午2:40
 */
public class FeedDetailActivity extends TitleBarActivity implements
		View.OnClickListener, DownloadListener {

	// 页面内容
	public final static String INTENT_DATA = "intent_data";

	// 页面展示的内容
	protected Data mData;

	// 浏览器
	protected CustomWebView mBrowser;

	// 页面下方导航栏layout
	protected View mTargetLayout;

	// 页面下方的导航栏
	protected TextView mTarget;

	// 启动本页面的Intent
	protected Intent mIntent;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.feed_detail_layout);

		initBackBtn();

		mBrowser = new CustomWebView(this);
		View bottomBar = findViewById(R.id.feed_detail_bottom);
		ViewGroup viewGroup = (ViewGroup) bottomBar.getParent();
		viewGroup.addView(mBrowser, 0);

		View shareBtn = findViewById(R.id.share_btn);
		shareBtn.setOnClickListener(this);
		mTargetLayout = findViewById(R.id.feed_detail_guang_layout);
		mTarget = (TextView) findViewById(R.id.feed_detail_guang);
		mTarget.setOnClickListener(this);

		// 初始化webview
		initBrowser(mBrowser);

		Intent intent = getIntent();
		mIntent = intent;
		mData = parseFeedFromIntent(intent);

		initPage(mData);
	}

	private void initBrowser(WebView browser) {
		CustomWebViewClient webClient = new CustomWebViewClient();
		webClient.addOnPageLoadingListener(new PageLoadingListener());
		browser.setWebViewClient(webClient);
		browser.setWebChromeClient(new CustomWebChromeClient());

		WebSettings settings = browser.getSettings();
		settings.setJavaScriptEnabled(true);
		settings.setDatabaseEnabled(true);
		settings.setDomStorageEnabled(true);

		// 设置webview的storage
		String databasePath = settings.getDatabasePath();
		if (databasePath == null) {
			databasePath = getDir("database", Context.MODE_PRIVATE).getPath();
			settings.setDatabasePath(databasePath);
		}

		// 允许缩放
		settings.setSupportZoom(false);
		settings.setBuiltInZoomControls(false);

		// 设置滚动条样式
		// mBrowser.setScrollbarFadingEnabled(false);
		// mBrowser.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);
		mBrowser.setDownloadListener(this);
	}

	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		mIntent = intent;
		mData = parseFeedFromIntent(intent);
		initPage(mData);
	}

	/**
	 * 从页面中解析出页面所需的数据信息
	 * 
	 * @param intent
	 * @return
	 */
	protected Data parseFeedFromIntent(Intent intent) {
		Data contentData = null;
		if (intent != null) {
			Serializable data = intent.getSerializableExtra(INTENT_DATA);
			if (data != null && data instanceof Data) {
				contentData = (Data) data;
			}
		}
		return contentData;
	}

	/**
	 * 初始化页面
	 * 
	 * @param data
	 */
	protected void initPage(Data data) {
		if (data == null) {
			return;
		}

		// 如果是品牌的话就没有去逛逛
		if (mData == null || mData.targetType == Feeder.Type.BRAND) {
			mTargetLayout.setVisibility(View.GONE);
		} else if (StringUtils.isNotBlank(data.targetName)) {
			mTargetLayout.setVisibility(View.VISIBLE);
			// 设置下方导航文字
			mTarget.setText("去逛逛");
		} else {
			mTargetLayout.setVisibility(View.GONE);
		}
		// 加载内容
		mBrowser.loadUrl(data.url);
	}

	@Override
	protected void onShare2WechatFriends() {
		Bitmap bitmap = ImageUtils.getBitmapFromLocal(mData.shareImageUrl);
		if (bitmap == null)
		// 如果没有图片的话就用APP图标来替代
		{
			bitmap = BitmapFactory.decodeResource(getResources(),
					R.drawable.ic_launcher);
		}
		String title = mData.targetName;
		String desc = mData.shareDesc;
		String shareUrl = mData.url + "_share";
		boolean shareSuccess = WXUtils.shareWebpageToFriends(this, title, desc,
				bitmap, shareUrl);
		// "http://act.m.buy.qq.com/t/showAct.xhtml?tid=share_back_test");
		if (!shareSuccess) {
			Toast.makeText(this, "分享失败", Constants.TOAST_NORMAL_LONG).show();
		}
	}

	@Override
	protected void onShare2WechatTimeline() {
		Bitmap bitmap = ImageUtils.getBitmapFromLocal(mData.shareImageUrl);
		if (bitmap == null)
		// 如果没有图片的话就用APP图标来替代
		{
			bitmap = BitmapFactory.decodeResource(getResources(),
					R.drawable.ic_launcher);
		}
		String title = mData.targetName;
		String desc = mData.shareDesc;
		String shareUrl = mData.url + "_share";
		boolean shareSuccess = WXUtils.shareWebpageToTimeline(this, title,
				desc, bitmap, shareUrl);
		// "http://act.m.buy.qq.com/t/showAct.xhtml?tid=share_back_test");
		if (!shareSuccess) {
			Toast.makeText(this, "分享失败", Constants.TOAST_NORMAL_LONG).show();
		}
	}

	@Override
	public void onClick(View v) {
		if (v.getId() == R.id.share_btn) {
			if (mData != null) {
				shareToWX();

			}
			return;
		} else if (mData == null || mData.targetType == null) {
			return;
		}

		if (mData.targetType == Feeder.Type.MALL)
		// 去商场
		{
			Intent intent = new Intent(this, MallDetailActivity.class);
			intent.putExtra(ConstantsActivity.INTENT_MALL_DETAIL_ID,
					mData.targetId);
			intent.putExtra(ConstantsActivity.INTENT_MALL_DETAIL_NAME,
					mData.targetName);
			startActivity(intent);
		} else if (mData.targetType == Feeder.Type.SHOP)
		// 去门店
		{
			Intent intent = new Intent(this, ShopPagerActivity.class);
			intent.putExtra(ConstantsActivity.INTENT_SHOP_ID, mData.targetId);
			intent.putExtra(ConstantsActivity.INTENT_SHOP_NAME,
					mData.targetName);
			intent.putExtra(ConstantsActivity.INTENT_SINGLE_CARD, "true");
			startActivity(intent);
		} else if (mData.targetType == Feeder.Type.BRAND)
		// 去品牌
		{
			// Intent intent = new Intent(this, BrandPageActivity.class);
			// intent.putExtra(ConstantsActivity.INTENT_PAGE_BRAND_ID,
			// mData.targetId);
			// startActivity(intent);
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (mBrowser != null) {
			mBrowser.removeAllViews();
			mBrowser.destroy();
			mBrowser = null;
		}
	}

	@Override
	public void onDownloadStart(String url, String userAgent,
			String contentDisposition, String mimetype, long contentLength) {

		Uri uri = Uri.parse(url);
		Intent intent = new Intent(Intent.ACTION_VIEW, uri);
		try {
			startActivity(intent);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 监听页面加载状态，展示“请稍候”对话框
	 * 
	 * @author ethonchan
	 */
	class PageLoadingListener implements OnPageLoadingListener,
			DialogInterface.OnCancelListener {

		@Override
		public void onCancel(DialogInterface dialog) {
			Log.d(TAG, "Cancelled by User");
			mBrowser.stopLoading();
		}

		@Override
		public void onLoadingStarted(String url) {
			Log.d(TAG, "START downloading page - " + url);

			// 只有在需要发起请求时才需要网络。 无网络连接时跳转到刷新页面
			if (!SysUtils.isNetworkAvaliable()) {
				Log.d(TAG, "no network, CANCEL downloading ! - " + url);
				// Intent intent = new Intent(FeedDetailActivity.this,
				// NetworkUnavailableActivity.class);
				// intent.putExtra(ConstantsActivity.NET_ERR_INTENT, mIntent);
				onNetworkUnavailable(0);
				finish();
				// startActivity(intent);
			} else {
				showProgressDialog(this, true);
			}
		}

		@Override
		public void onLoadingSuccess(String url) {
			Log.d(TAG, "FINISH downloaded page - " + url);
			String title = mBrowser.getTitle();
			setTitle(title);

			try {
				dismissDialog(Constants.DIALOG_PROGRESS);
			} catch (Exception e) {
				Log.e(TAG, e.getMessage(), e);
			}
		}

		@Override
		public void onLoadingFailed(String url, String description,
				int errorCode) {
			Log.d(TAG, "[errCode = " + errorCode + " ] " + description + " - "
					+ url);

			String title = "微购物";
			if (mData != null) {
				title = mData.targetName;
			}
			setTitle(title);

			try {
				dismissDialog(Constants.DIALOG_PROGRESS);
			} catch (Exception e) {
				Log.e(TAG, e.getMessage(), e);
			}
			finish();
			// Intent intent = new Intent(FeedDetailActivity.this,
			// NetworkUnavailableActivity.class);
			// intent.putExtra(ConstantsActivity.NET_ERR_INTENT, mIntent);
			// startActivity(intent);
		}
	}

	/**
	 * 页面所需的数据
	 */
	public static class Data implements Serializable {
		// 页面url
		public String url;

		// 去逛逛后面的目的地名
		public String targetName;

		// 跳转目的地类型（商场、品牌、门店）
		public Feeder.Type targetType;

		// 跳转目的地ID
		public String targetId;

		// 分享描述
		public String shareDesc;

		// 分享的图片url
		public String shareImageUrl;
	}
}
