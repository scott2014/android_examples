package com.tencent.weigou.user;

import com.tencent.weigou.base.json.JsonResult;
import com.tencent.weigou.util.StringUtils;
import org.json.JSONObject;

import java.io.Serializable;

/**
 * 用户个人信息
 * User: ethonchan
 * Date: 13-11-4
 * Time: 上午11:28
 */
public class UserVo implements Comparable<UserVo>, Serializable {
    //  用户的唯一标识
    public final String wId;

    //  用户的登录态
    public final String xToken;

    //  微信用户专用的commId
    public final String commId;

    //  用户是否为首次登录
    public final boolean isNewUser;

    //  本条个人信息的创建时间
    public final long createTime;

    //  xToken的本地有效时间（服务端为14天）
    public final static long TOKEN_VALIDATE_TIME = 13 * 24 * 60 * 60 * 1000;

    public UserVo() {
        this("", "", "", 0L);
    }

    public UserVo(String wId, String xToken, String commId, int state) {
        this.wId = wId;
        this.xToken = xToken;
        this.commId = commId;
        this.isNewUser = state == 1;
        //  保留个人信息的创建时间
        createTime = System.currentTimeMillis();
    }

    public UserVo(String wId, String xToken, String commId, long createTime) {
        this.wId = wId;
        this.xToken = xToken;
        this.commId = commId;
        this.isNewUser = false;
        this.createTime = createTime;
    }

    public static UserVo getMock() {
        return new UserVo("4140062282", "9E6AA6A27D10481910E5B1D76BB1C27Bwx2e9f8471bee03412", "", 0);
    }

    @Override
    public int compareTo(UserVo another) {
        if (another != null) {
            return (int) (another.createTime - createTime);
        } else {
            return 1;
        }
    }

    /**
     * 登录态是否为空
     *
     * @return true为空，false不为空
     */
    public boolean isTokenEmpty() {
        boolean empty = StringUtils.isBlank(wId) || StringUtils.isBlank(xToken);
        return empty;
    }

    /**
     * 登录态是否过期
     *
     * @return true过期，false不过期
     */
    public boolean isExpired() {
        boolean expired = (System.currentTimeMillis() - createTime) > TOKEN_VALIDATE_TIME;
        return expired;
    }

    @Override
    public String toString() {
        return "[" + wId + ", " + xToken + "]";
    }

    public static UserVo parseJson(JsonResult json) {
        UserVo user = null;
        if (json != null && json.isSuccess()) {
            JSONObject data = json.getData();
            if (data != null) {
                String wid = data.optString("wid", "");
                String xtoken = data.optString("xtoken", "");
                String commId = data.optString("commId", "");
                int state = data.optInt("state", 0);

                user = new UserVo(wid, xtoken, commId, state);
            }
        }
        return user;
    }
}
