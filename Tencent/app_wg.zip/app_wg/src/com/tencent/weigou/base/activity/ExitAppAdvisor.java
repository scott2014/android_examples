package com.tencent.weigou.base.activity;

import android.content.Context;
import android.widget.Toast;
import com.tencent.weigou.util.Constants;

/**
 * 点击back退出APP事件的咨询者
 *
 * @author ethonchan
 * @created 2014-01-23
 */
public class ExitAppAdvisor {
    int backTimes = 0;

    long tapTime = 0;

    /**
     * 处理点击back按钮事件
     *
     * @return
     */
    public Advice askAdviceWhenBackPressed() {
        backTimes += 1;
        if (backTimes == 1) {
            tapTime = System.currentTimeMillis();
            return Advice.ONE_MORE_CLICK;
        } else {
            if ((System.currentTimeMillis() - tapTime) < 2000) {
                return Advice.EXIT_APP;
            } else {
                resetTapTimes();
                return Advice.DO_NOTHING;
            }
        }
    }

    /**
     * 清零点击back的次数
     */
    public void resetTapTimes() {
        backTimes = 0;
    }

    /**
     * 退出事件处理建议
     */
    public enum Advice {
        //  采用默认行为即可，handler不提供建议
        DEFAULT,
        //  还需要再点击一次
        ONE_MORE_CLICK,
        //  退出APP
        EXIT_APP,
        //  无需进一步处理
        DO_NOTHING;
    }
}
