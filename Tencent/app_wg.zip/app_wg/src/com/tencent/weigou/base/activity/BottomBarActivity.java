package com.tencent.weigou.base.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import com.tencent.weigou.R;
import com.tencent.weigou.common.ui.BottomBar;
import com.tencent.weigou.util.Constants;

public class BottomBarActivity extends TitleBarActivity {
    BottomBar bar;

    protected ExitAppAdvisor mExitAppAdvisor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mExitAppAdvisor = new ExitAppAdvisor();
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (app != null && app.isHasNewFeeds()) {
            bar.onHasNewFeeds();
        } else {
            bar.onNoNewFeeds();
        }
    }

    /**
     * 设置底部的选中Button
     *
     * @param index Button的序号,从0开始
     */
    protected void selectBottomBar(int index, boolean exit) {
        View v = findViewById(R.id.bottom_bar);
        if (v != null) {
            bar = (BottomBar) v;
            bar.setSelect(index);
        }
        mExitAppAdvisor.resetTapTimes();
    }

    @Override
    public void onBackPressed() {
        ExitAppAdvisor.Advice advice = mExitAppAdvisor.askAdviceWhenBackPressed();
        if (advice == ExitAppAdvisor.Advice.DO_NOTHING) {
            ;
        } else if (advice == ExitAppAdvisor.Advice.EXIT_APP) {
            exitAll();
            finish();
        } else if (advice == ExitAppAdvisor.Advice.ONE_MORE_CLICK) {
            Toast.makeText(this, "再按一次返回键退出",
                    Constants.TOAST_NORMAL_LONG).show();
        } else if (advice == ExitAppAdvisor.Advice.DEFAULT) {
            super.onBackPressed();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        overridePendingTransition(android.R.anim.fade_in,
                android.R.anim.fade_out);
    }

}
