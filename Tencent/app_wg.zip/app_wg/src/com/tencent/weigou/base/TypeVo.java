package com.tencent.weigou.base;

/**
 * 品牌和mall的关注对象
 * 
 * @author jonathanqi
 * 
 */
public class TypeVo {
	public String id;
	public boolean sub;
	
	public TypeVo() {
		
	}
	
	public TypeVo(String id, boolean sub) {
		this.id = id;
		this.sub = sub;
	}
}
