package com.tencent.weigou.base;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.annotation.TargetApi;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.StrictMode;

import com.nostra13.universalimageloader.cache.disc.impl.UnlimitedDiscCache;
import com.nostra13.universalimageloader.cache.disc.naming.Md5FileNameGenerator;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;
import com.tencent.map.lbsapi.api.SOSOMapLBSApi;
import com.tencent.weigou.login.LoginUtils;
import com.tencent.weigou.setting.activity.persistence.SettingStorage;
import com.tencent.weigou.setting.info.SettingInfo;
import com.tencent.weigou.user.UserVo;
import com.tencent.weigou.util.Constants;
import com.tencent.weigou.util.Env;
import com.tencent.weigou.util.SysUtils;
import com.tencent.weigou.util.VersionType;
import com.tencent.weigou.util.lbs.LBSCallback;
import com.tencent.weigou.util.lbs.LBSUtils;

/**
 * User: ethonchan Date: 13-10-21 Time: 上午10:23
 */
public class App extends Application {
	private Bundle shareData;
	private static App instance;
	/**
	 * 环境
	 */
	private Env env = null;

	/**
	 * 机器信息
	 */
	private String QUA = null;

	/**
	 * 唯一性
	 */
	private String mk = null;

	/**
	 * 渠道信息
	 */
	private String channelId = "";

	// 版本类型
	private VersionType mVersionType;

	/**
	 * 关注信息的map
	 */
	private Map<String, List<TypeVo>> subMap = new HashMap<String, List<TypeVo>>();

	// MTA是否统计PV
	private boolean mtaReportPV = true;

	// 用户个人信息，未登录为空
	private UserVo user = null;

	// 是否有新动态
	private boolean hasNewFeeds = false;

	public static final HandlerThread sWorkerThread = new HandlerThread(
			"App sWorkerThread");
	static {
		sWorkerThread.start();
	}
	public static final Handler sWorker = new Handler(sWorkerThread.getLooper());

	public String getMk() {
		return mk;
	}

	public void setMk(String mk) {
		this.mk = mk;
	}

	public Bundle getShareData() {
		return shareData;
	}

	@TargetApi(Build.VERSION_CODES.GINGERBREAD)
	@Override
	public void onCreate() {
		super.onCreate();
		shareData = new Bundle();
		instance = this;
		if (android.os.Build.VERSION.SDK_INT > 9) {
			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
					.permitAll().build();
			StrictMode.setThreadPolicy(policy);
		}
		// if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD) {
		// StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
		// .detectAll().penaltyDialog().build());
		// StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
		// .detectAll().penaltyDeath().build());
		// }
		initImageLoader(getApplicationContext());
		mVersionType = SysUtils.getVersionType(this);
		init();
	}

	public void onTerminate() {
		super.onTerminate();
		if (sWorkerThread != null)
			sWorkerThread.quit();
	}

	public static App getInstance() {
		return instance;
	}

	/**
	 * 获取App当前的版本类型信息
	 * 
	 * @return
	 */
	public VersionType getVersionType() {
		return mVersionType;
	}

	/**
	 * 
	 * @Title: init
	 * @Description: 初使化基本信息
	 * 
	 *               void 返回类型
	 * @throws
	 */
	private void init() {
		if (subMap != null) {
			subMap.clear();
			List<TypeVo> mallSubList = new ArrayList<TypeVo>();
			List<TypeVo> brandSubList = new ArrayList<TypeVo>();
			subMap.put(Constants.MALL, mallSubList);
			subMap.put(Constants.BRAND, brandSubList);
		}
		// 耗时的初使化
		sWorker.post(new Runnable() {

			@Override
			public void run() {
				initEnv();
				initLBS();
				registWX();
			}

		});
		// UI相关的初使化

	}

	public void initEnv() {
		env = Env.getIdc();
		if (mVersionType != VersionType.RELEASE) {
			// 调试版可连接IDC或者GAMMA环境，视SharedPreferences中的配置
			SettingInfo si = SettingStorage.read(App.this);
			if (si != null) {
				env = Env.getEnv(si.env);
			} else {
				env = Env.getGamma();
			}
		}
	}

	private void initLBS() {
		// LBS定位
		SOSOMapLBSApi lbs = LBSUtils.getLBSInstance();
		if (lbs != null) {
			lbs.requestLocationUpdate(this, new LBSCallback());
		}
	}

	/**
	 * 将本APP注册到微信
	 */
	private void registWX() {
		VersionType type = SysUtils.getVersionType(this);
		if (type == VersionType.GAMMA || type == VersionType.RELEASE) {
			// WXUtils.registerApp(this);
		}
	}

	/**
	 * 
	 * @Title: updateEnv
	 * @Description: 更新环境变量
	 * @param type
	 *            设定文件
	 * 
	 *            void 返回类型
	 * @throws
	 */
	public void updateEnv(int type) {
		if (mVersionType == VersionType.RELEASE) {
			// 非调试版连接IDC环境
			env = Env.getIdc();
			return;
		} else {
			env = Env.getEnv(type);
		}
	}

	public Env getEnv() {
		// TODO test return env;
		return Env.getGamma();
	}

	public UserVo getUser() {
		return user;
	}

	public void updateUser(final UserVo user) {
		this.user = user;
		// 更新本地缓存的用户信息
		sWorker.post(new Runnable() {
			@Override
			public void run() {
				LoginUtils.updateLocalUserVo(getBaseContext(), user);
			}
		});
	}

	public boolean isMtaReportPV() {
		return mtaReportPV;
	}

	public void setMtaReportPV(boolean mtaReportPV) {
		this.mtaReportPV = mtaReportPV;
	}

	public boolean isHasNewFeeds() {
		return hasNewFeeds;
	}

	public void setHasNewFeeds(boolean hasNewFeeds) {
		this.hasNewFeeds = hasNewFeeds;
	}

	public static void initImageLoader(Context context) {
		// This configuration tuning is custom. You can tune every option, you
		// may tune some of them,
		// or you can create default configuration by
		// ImageLoaderConfiguration.createDefault(this);
		// method.
		File dir = SysUtils.getDirInSdcard("cache/uil");
		ImageLoaderConfiguration config;
		if (dir != null && dir.exists()) {
			config = new ImageLoaderConfiguration.Builder(context)
					.threadPriority(Thread.NORM_PRIORITY - 2)
					.denyCacheImageMultipleSizesInMemory()
					.discCacheFileNameGenerator(new Md5FileNameGenerator())
					.tasksProcessingOrder(QueueProcessingType.LIFO)
					.writeDebugLogs().discCache(new UnlimitedDiscCache(dir))
					.build();
		} else {
			config = new ImageLoaderConfiguration.Builder(context)
					.threadPriority(Thread.NORM_PRIORITY - 2)
					.denyCacheImageMultipleSizesInMemory()
					.discCacheFileNameGenerator(new Md5FileNameGenerator())
					.tasksProcessingOrder(QueueProcessingType.LIFO)
					.writeDebugLogs().build();
		}
		// Initialize ImageLoader with configuration.
		ImageLoader.getInstance().init(config);
	}

	public void putMallSubInfo(TypeVo tv) {
		List<TypeVo> ltv = subMap.get(Constants.MALL);
		for (int i = 0; i < ltv.size(); i++) {
			if (tv.id == ltv.get(i).id) {
				ltv.get(i).sub = tv.sub;
				return;
			}
		}
		ltv.add(tv);
	}

	public void putBrandSubInfo(TypeVo tv) {
		List<TypeVo> ltv = subMap.get(Constants.BRAND);
		for (int i = 0; i < ltv.size(); i++) {
			if (tv.id == ltv.get(i).id) {
				ltv.get(i).sub = tv.sub;
				return;
			}
		}
		ltv.add(tv);
	}

	public List<TypeVo> getMallSubInfo() {
		return subMap.get(Constants.MALL);
	}

	public List<TypeVo> getBrandSubInfo() {
		return subMap.get(Constants.BRAND);
	}
}
