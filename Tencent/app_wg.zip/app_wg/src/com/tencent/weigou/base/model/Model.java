package com.tencent.weigou.base.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Observable;

import android.os.AsyncTask;
import android.os.Bundle;

import com.tencent.weigou.base.json.JsonResult;
import com.tencent.weigou.base.model.vo.CommonVo;
import com.tencent.weigou.util.NotificationIds;
import com.tencent.weigou.util.SysUtils;
import com.tencent.weigou.util.http.JSONGetter;

/**
 * 所有的model都继承此类
 * 
 * @author jonathanqi
 * 
 */
public class Model extends Observable {
	// 统一管理task，方便关闭
	private List<GetNetWorkDataTask> taskList = new ArrayList<GetNetWorkDataTask>();
	// 主动推送数据还是自己去拉数据
	private boolean isPushType = false;

	// 数据管理map，key为Vo的notificationId，value为Vo,方便子类获取数据
	// private SparseArray<CommonVo> dataMap = new SparseArray<CommonVo>();

	/**
	 * 新建异步线程，获取数据，json解析vo，通知view更新
	 * 
	 * @param url
	 * @param commonVo
	 * @return
	 */
	public void createNetWorkTask(String url, CommonVo commonVo,
			int notificationId) {
		GetNetWorkDataTask task = new GetNetWorkDataTask(url, commonVo,
				notificationId);
		task.execute();
		taskList.add(task);
	}

	/**
	 * @return the isPushType
	 */
	public boolean isPushType() {
		return isPushType;
	}

	/**
	 * @param isPushType
	 *            the isPushType to set
	 */
	public void setPushType(boolean isPushType) {
		this.isPushType = isPushType;
	}

	/**
	 * 
	 * @Title: createNetWorkTask
	 * 
	 * @Description: 新建异步线程，获取数据，json解析vo，通知view更新
	 * @param @param isShowProgressBar 是否需要加载圈圈
	 * @param @param url
	 * @param @param commonVo 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	public void createNetWorkTask(boolean isShowProgressBar, String url,
			CommonVo commonVo, int notificationId) {
		GetNetWorkDataTask task = new GetNetWorkDataTask(isShowProgressBar,
				url, commonVo, notificationId);
		task.execute();
		taskList.add(task);
	}

	/**
	 * 
	 * @Title: addList
	 * @Description: subclass can override and create its own worktask
	 * @param @param workTask 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	public void addList(GetNetWorkDataTask workTask) {
		taskList.add(workTask);
	}

	/**
	 * 
	 * @Title: cancel
	 * @Description: 关闭task
	 * @param workTask
	 * @return 设定文件
	 * 
	 *         boolean 返回类型
	 * @throws
	 */
	public boolean cancel(GetNetWorkDataTask workTask) {
		boolean ret = false;
		if (workTask != null
				&& workTask.getStatus() != AsyncTask.Status.FINISHED) {
			ret = workTask.cancel(true);
			workTask.httpCancel();
		}
		return ret;
	}

	public void close() {
		if (taskList.size() > 0) {
			Iterator<GetNetWorkDataTask> it = taskList.iterator();
			while (it.hasNext()) {
				cancel(it.next());
			}
		}
	}

	public class GetNetWorkDataTask extends AsyncTask<Object, Object, CommonVo> {
		protected JSONGetter getter;
		protected boolean isShowProgressBar = true;
		protected String url;

		protected CommonVo cv;
		protected int notificationId;

		public GetNetWorkDataTask(String url, CommonVo cv, int notificationId) {
			this.url = url;
			this.cv = cv;
			isShowProgressBar = true;
			this.notificationId = notificationId;
		}

		public GetNetWorkDataTask(boolean isShowProgressBar, String url,
				CommonVo cv, int notificationId) {
			this.url = url;
			this.cv = cv;
			this.isShowProgressBar = isShowProgressBar;
			this.notificationId = notificationId;
		}

		@Override
		protected void onPreExecute() {

			// 检查网络状况
			if (!SysUtils.isNetworkAvaliable()) {
				Model.this.notify(NotificationIds.TOAST_NETWORK_NOT_WORK_ID,
						this.notificationId);
				cancel(true);
				httpCancel();
			} else {
				if (isShowProgressBar) {
					Model.this.notify(NotificationIds.SHOW_PROGRESS_DIALOG);
				}
				super.onPreExecute();
			}
		}

		@Override
		protected CommonVo doInBackground(Object... arg0) {
			try {
				getter = new JSONGetter(false);
				JsonResult jr = getter.doGet(url);
				if (jr != null) {
					if (jr.isAuthNeeded())
					// 需要登录
					{
						Model.this.notify(NotificationIds.NEED_AUTH_ID);
					} else if (jr.isSuccess() && cv.parse(jr.getData())) {
						return cv;
					} else {
						cv.setErrorCode(jr.getErrCode());
						cv.setErrorMsg(jr.getErrMsg());
						return cv;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}

		@Override
		public void onPostExecute(CommonVo vo) {
			if (vo != null) {
				if (!isPushType) {
					Model.this.notify(notificationId);
				} else {
					Model.this.notify(vo);
				}
			} else {
				Model.this.notify(NotificationIds.TOAST_NETWORK_NOT_WORK_ID,
						this.notificationId);
			}
			if (isShowProgressBar) {
				Model.this.notify(NotificationIds.DISMISS_PROGRESS_DIALOG);
			}
		}

		@Override
		protected void onCancelled() {
			if (isShowProgressBar) {
				Model.this.notify(NotificationIds.DISMISS_PROGRESS_DIALOG);
			}
			super.onCancelled();
		}

		/**
		 * 
		 * @Title: httpCancel
		 * @Description: httpCancel() will always be invoked with
		 *               cancel(boolean)
		 * @param 设定文件
		 * @return void 返回类型
		 * @throws
		 */
		public void httpCancel() {
			if (getter != null) {
				getter.cancel();
			}
		}

	}

	/**
	 * 
	 * @Title: handleMessage
	 * 
	 * @Description: 处理业务逻辑用的。
	 * 
	 * @param what
	 *            消息类型
	 * @param data
	 *            附带参数
	 * @return 设定文件
	 * 
	 *         boolean 返回类型
	 * @throws
	 */
	public boolean handleMessage(int what, String str, Object data) {
		return false;
	}

	public void notify(int toastNetworkNotWorkId, int notificationId) {
		setChanged();
		CommonVo vo = new CommonVo();
		vo.setNotificationId(notificationId);
		vo.setExNotificationId(toastNetworkNotWorkId);
		notifyObservers(vo);
	}

	/**
	 * 通知view更新数据，数据通过cv传递
	 * 
	 * @param cv
	 */
	public void notify(int notificationId) {
		setChanged();
		notifyObservers(notificationId);
	}

	/**
	 * 通知view更新数据，数据通过cv传递
	 * 
	 * @param cv
	 */
	public void notify(CommonVo vo) {
		setChanged();
		notifyObservers(vo);
	}

	/**
	 * 通知view更新数据，数据通过cv传递
	 * 
	 * @param cv
	 */
	public void notify(Bundle bundle) {
		setChanged();
		notifyObservers(bundle);
	}

	public void initData(String url) {
	}
}