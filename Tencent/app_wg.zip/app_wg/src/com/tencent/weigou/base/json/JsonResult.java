package com.tencent.weigou.base.json;

import org.json.JSONObject;

/**
 * Json接口调用结果基类
 * User: ethonchan
 * Date: 13-10-17
 * Time: 上午11:06
 */
public class JsonResult {
    //  传入的JSON是否已经解析
    private boolean parsed = false;

    //  传入的JSON
    private JSONObject json = null;

    //  JSON中返回的内容
    private JSONObject data = null;

    //  JSON返回的错误码
    private int errCode = -1;

    //  JSON返回的错误信息
    private String errMsg = "";

    //  需要登录
    private boolean authNeeded = false;

    /**
     * 设置要解析的JSON
     *
     * @param json 要解析的JSON
     */
    public void setJson(JSONObject json) {
        this.json = json;
        parsed = false;
    }

    /**
     * 解析JSON返回包中的公共部分
     */
    protected void parseCommon() {
        if (!parsed) {
            if (json != null) {
                errCode = json.optInt("errCode", -1);
                errMsg = json.optString("msg", "");
                data = json.optJSONObject("data");
            } else {
                errCode = -1;
                errMsg = "";
                data = null;
            }
            parsed = true;
        }
    }

    /**
     * 请求调用是否成功
     *
     * @return true成功，false不成功
     */
    public boolean isSuccess() {
        parseCommon();
        return errCode == 0;
    }

    public JSONObject getData() {
        return data;
    }

    public int getErrCode() {
        return errCode;
    }

    public String getErrMsg() {
        return errMsg;
    }

    public boolean isAuthNeeded() {
        return authNeeded || errCode == 402;
    }

    public void setAuthNeeded(boolean authNeeded) {
        this.authNeeded = authNeeded;
    }
}
