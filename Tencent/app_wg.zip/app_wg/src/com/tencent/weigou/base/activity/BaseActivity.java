package com.tencent.weigou.base.activity;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.*;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;
import com.tencent.stat.StatService;
import com.tencent.weigou.R;
import com.tencent.weigou.base.App;
import com.tencent.weigou.base.model.Model;
import com.tencent.weigou.base.model.vo.CommonVo;
import com.tencent.weigou.base.view.UI;
import com.tencent.weigou.common.ui.CustomAlertDialog;
import com.tencent.weigou.common.ui.CustomProgressDialog;
import com.tencent.weigou.user.UserVo;
import com.tencent.weigou.util.*;
import com.tencent.weigou.util.PageIds.OprIndex;
import com.tencent.weigou.wxapi.NeedAuthActivity;
import com.tencent.weigou.wxapi.WXUtils;

import java.io.Serializable;
import java.util.List;
import java.util.Observable;
import java.util.Observer;
import java.util.Properties;

/**
 * APP内所有页面的基础页面，完成pageId、登录态传递等基础功能
 */
public class BaseActivity extends FragmentActivity implements OnCancelListener,
		Observer {

	private String EXIT_PERMISSION = "com.weigou.exitPermission";
	protected App app;

	private Model model;

	private UI ui;

	// 当前页面ID
	protected int pageId;

	// 前一页的页面ID
	protected int prePageId = 0;

	// 源头的页面ID
	protected int sourcePageId = 0;

	// 日志TAG
	public String TAG = "";

	protected ProgressDialog progressDialog;

	// 对话框的基本属性
	private DialogHolder mDialogParam = new DialogHolder();

	// 分享的弹出框
	protected PopupWindow mSharePopup = null;

	/**
	 * 增加debug参数
	 */
	private boolean isNeedAddDebugFlag = true;

	/**
	 * @return the isNeedAddDebugFlag
	 */
	public boolean isNeedAddDebugFlag() {
		return isNeedAddDebugFlag;
	}

	/**
	 * @param isNeedAddDebugFlag
	 *            the isNeedAddDebugFlag to set
	 */
	public void setNeedAddDebugFlag(boolean isNeedAddDebugFlag) {
		this.isNeedAddDebugFlag = isNeedAddDebugFlag;
	}

	protected void initMVC(Model model, UI ui, int layoutId) {
		this.model = model;
		this.ui = ui;
		setContentView(layoutId);
		ui.initView(findViewById(R.id.outter_view));
		model.addObserver(this);
	}

	@Override
	protected void onResume() {
		super.onResume();
		if (app == null) {
			app = (App) this.getApplication();
		}

		if (MTAUtils.isRunning() && app.isMtaReportPV()) {
			StatService.onResume(this);
		}
	}

	@Override
	protected void onPause() {
		super.onPause();
		if (MTAUtils.isRunning() && app.isMtaReportPV()) {
			StatService.onPause(this);
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		String className = getClass().getSimpleName();
		if (StringUtils.isEmpty(TAG)) {
			TAG = className;
		}
		Integer tmp = PageIds.getPageId(className);
		pageId = tmp == null ? 0 : tmp;
		sourcePageId = pageId;

		if (app == null)
			app = (App) this.getApplication();
		Intent intent = getIntent();
		initPageId(intent);
		IntentFilter filter = new IntentFilter();
		filter.addAction("finish");
		registerReceiver(mFinishReceiver, filter, EXIT_PERMISSION, null);
		progressDialog = new ProgressDialog(this) {
			private int useCount = 0;

			@Override
			protected void onCreate(Bundle savedInstanceState) {
				super.onCreate(savedInstanceState);
				setContentView(R.layout.progress_layout);
			}

			@Override
			public void onBackPressed() {
				cancel();
			}

			@Override
			public void dismiss() {
				useCount -= 1;
				if (useCount == 0) {
					try {
						super.dismiss();
					} catch (Exception e) {
					}
				}
			}

			@Override
			public void show() {
				useCount += 1;
				if (useCount == 1) {
					try {
						super.show();
					} catch (Exception e) {
					}
				}
			}

		};
		progressDialog.setOnCancelListener(this);
		progressDialog.setCancelable(false);
		progressDialog.setCanceledOnTouchOutside(false);

		handleIfFromAuth(intent);
	}

	// TODO is it safe?
    /**
     * Add comment by bran, 20140214
     * permission issue
     * bran adds a signature level in exitPermission ,thus other apps have different signature
     * can't send exit broadcast and whereas receive the one.
     */
	private BroadcastReceiver mFinishReceiver = new BroadcastReceiver() {

		@Override
		public void onReceive(Context context, Intent intent) {

			if ("finish".equals(intent.getAction())) {

				Log.d("#########", "I am " + getLocalClassName()

				+ ",now finishing myself...");

				finish();

			}

		}

	};

	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		initPageId(intent);
		if (app == null) {
			app = (App) this.getApplication();
		}
	}

	/**
	 * 处理来自登录的Intent
	 * 
	 * @param intent
	 */
	protected void handleIfFromAuth(Intent intent) {
		if (intent != null) {
			String source = intent
					.getStringExtra(NeedAuthActivity.SOURCE_ACTIVITY);
			if (NeedAuthActivity.class.getName().equals(source))
			// 来自登录页面
			{
				Serializable userObj = intent
						.getSerializableExtra(NeedAuthActivity.INTENT_USER);
				if (userObj != null && userObj instanceof UserVo)
				// 从NeedAuth回跳而来
				{
					UserVo userVo = (UserVo) userObj;
					onLogin(true, userVo);
				} else
				// 取消登录
				{
					onLogin(false, null);
				}
			}
		}
	}

	/**
	 * 初始化页面的pageId用于统计
	 * 
	 * @param intent
	 */
	private void initPageId(Intent intent) {
		if (intent != null) {
			prePageId = intent
					.getIntExtra(PageIds.INTENT_PRE_PAGEID, prePageId);
			sourcePageId = intent.getIntExtra(PageIds.INTENT_SOURCE_PAGEID,
					sourcePageId);
		}
	}

	/**
	 * 将当前页面作为pageId统计的起点
	 */
	protected void markAsSourcePage() {
		sourcePageId = pageId;
	}

	@Override
	public boolean startActivityIfNeeded(Intent intent, int requestCode) {
		if (intent != null) {
			intent.putExtra(PageIds.INTENT_PRE_PAGEID, pageId);
			intent.putExtra(PageIds.INTENT_SOURCE_PAGEID, sourcePageId);
		}
		return super.startActivityIfNeeded(intent, requestCode);
	}

	@Override
	public void startActivity(Intent intent) {
		if (intent != null) {
			intent.putExtra(PageIds.INTENT_PRE_PAGEID, pageId);
			intent.putExtra(PageIds.INTENT_SOURCE_PAGEID, sourcePageId);
		}
		super.startActivity(intent);
	}

	@Override
	public void startActivityForResult(Intent intent, int requestCode) {
		if (intent != null) {
			intent.putExtra(PageIds.INTENT_PRE_PAGEID, pageId);
			intent.putExtra(PageIds.INTENT_SOURCE_PAGEID, sourcePageId);
		}
		super.startActivityForResult(intent, requestCode);
	}

	/**
	 * 上报自定义事件。当发生某种关键时间，比如下单，支付等时可以上报到MTA方便运营自行分析。当发生某种关键时间，比如下单，
	 * 支付等时可以上报到MTA方便运营自行分析
	 * 
	 * @param eventId
	 *            事件ID
	 * @param params
	 *            事件相关参数
	 */
	protected void reportMTAEvent(String eventId, Properties params) {
		StatService.trackCustomKVEvent(this, eventId, params);
	}

	/**
	 * 用户是否已经登陆
	 * 
	 * @return
	 */
	public boolean isLogin() {
		UserVo userVo = app.getUser();
		boolean hasLogin = userVo != null && !userVo.isTokenEmpty()
				&& !userVo.isExpired();
		return hasLogin;
	}

	/**
	 * 去登录
	 */
	public void toLogin() {
		if (!isFinishing()) {
			Intent intent = new Intent(this, NeedAuthActivity.class);
			intent.putExtra(NeedAuthActivity.SOURCE_ACTIVITY, getClass()
					.getName());
			startActivity(intent);
			finish();
		}
	}

	/**
	 * 处理登录回跳
	 * 
	 * @param success
	 *            登陆是否成功
	 * @param newUserVo
	 *            新的用户信息
	 */
	protected void onLogin(boolean success, UserVo newUserVo) {
		Log.d("TAG", "onLogin@" + TAG + ", success=" + success);
		if (!success) {
			finish();
		}
	}

	/**
	 * 获取MK
	 * 
	 * @return
	 */
	protected String getMk() {
		return app.getMk();
	}

	/**
	 * 获取WID
	 * 
	 * @return
	 */
	protected String getWid() {
		if (app != null && app.getUser() != null)
			return app.getUser().wId;
		else
			return "";
	}

	/**
	 * @return 设定文件
	 *         <p/>
	 *         String 返回类型
	 * @throws
	 * @Title: getXtk
	 * @Description: 获取微信登陆态
	 */
	protected String getXtk() {
		if (app != null && app.getUser() != null)
			return app.getUser().xToken;
		else
			return "";
	}

	/**
	 * 在给定的url之后附加上uk,pgid和ptag信息
	 * 
	 * @param urlWithoutPageInfo
	 * @param ptagIndex
	 *            见OprIndex类注释
	 * @return 附加了pgid和ptag之后的url
	 */
	public String appendPageInfo(String urlWithoutPageInfo, OprIndex ptagIndex) {
		StringBuilder url = new StringBuilder();
		url.append(urlWithoutPageInfo);
		if (!urlWithoutPageInfo.contains("?")) {
			url.append("?");
			url.append("wid=").append(getWid());
		} else {
			url.append("&wid=").append(getWid());
		}
		url.append("&xtk=").append(getXtk());
		url.append("&mk=").append(getMk());
		url.append("&pgid=").append(pageId);
		String ptag = PageIds.getPtag(sourcePageId, prePageId, pageId,
				ptagIndex);
		url.append("&ptag=").append(ptag);

		VersionType versionType = app.getVersionType();
		if (isNeedAddDebugFlag
				&& (versionType == null || versionType == VersionType.DEBUG)) {
			url.append("&debug=true");
		}
		return url.toString();
	}

	@Override
	public void onCancel(DialogInterface dialog) {
		if (dialog instanceof ProgressDialog) {
			if (model != null) {
				model.close();
			}
		}

	}

	@Override
	protected void onDestroy() {
		if (model != null) {
			model.close();
		}
		if (ui != null) {
			ui.onDestroy();

		}
		unregisterReceiver(mFinishReceiver);
		super.onDestroy();
	}

	/**
	 * 退出整个应用（先对话框提示是否退出）
	 * 
	 * @param act
	 *            当前activity
	 */
	public void exitAllWithConfirm(Activity act) {
		OnClickListener clk = new ClickExitListener();
		Resources res = getResources();
		String title = res.getString(R.string.exit_title);
		String msg = res.getString(R.string.exit_confirm);
		String cfmText = res.getString(R.string.ok);
		String cancelText = res.getString(R.string.cancel);
		showYesNoDialog(title, msg, cfmText, cancelText, true, clk, null);
	}

	public void exitAll() {
		getApplicationContext().sendBroadcast(new Intent("finish"),
				EXIT_PERMISSION);
	}

	static class DialogHolder {
		protected String dlgTitle = "";

		protected String dlgMsg = "";

		protected String yesButton = "";

		protected String noButton = "";

		protected OnClickListener clickListener;

		protected OnCancelListener cancelListener;

		protected Boolean cancelable = true;
	}

	/**
	 * 点击退出按钮
	 * 
	 * @author ethonchan
	 */
	class ClickExitListener implements DialogInterface.OnClickListener {
		@Override
		public void onClick(DialogInterface dialog, int which) {
			if (DialogInterface.BUTTON_POSITIVE == which)
			// 点击确定按钮将会退出整个应用
			{
				// // 关闭更新包下载线程
				// UpdateChecker.destroyApkDownloadThread();
				//
				// if (App.sWorker != null) {
				// App.sWorker.post(new Runnable() {
				//
				// @Override
				// public void run() {
				// // 校验闪屏有效性, 清除失效的闪屏
				// SplashUtil
				// .validateStoredSplashes(BaseActivity.this);
				// }
				// });
				// }
				//
				// // 取消定时上报的计时器
				// // if (!isDebuggable()) {
				// // Reporter.getErrorReporter().stopScheduleReport();
				// // }
				//
				// Intent intent = new Intent(LoginConstants.ACTION_EXIT);
				// sendBroadcast(intent,
				// LoginConstants.PERMISSION_LOGIN_BROADCAST);
			}
		}
	}

	/**
	 * 显示一个带有“请稍候...”字样的进度框
	 * 
	 * @param listener
	 *            取消进度框的监听器
	 */
	public void showProgressDialog(OnCancelListener listener, boolean cancelable) {
		mDialogParam.cancelListener = listener;
		mDialogParam.cancelable = cancelable;
		showDialog(Constants.DIALOG_PROGRESS);
	}

	/**
	 * 显示一个带有一个确定按钮的对话框
	 * 
	 * @param title
	 *            对话框的名称
	 * @param msg
	 *            对话框的信息
	 * @param canListener
	 *            对话框的监听器，可以为null
	 */
	public void showAlertDialog(String title, String msg, String ok,
			boolean cancellable, OnClickListener clkListener,
			OnCancelListener canListener) {
		mDialogParam.dlgTitle = title;
		mDialogParam.dlgMsg = msg;
		mDialogParam.yesButton = ok;
		mDialogParam.cancelable = cancellable;
		mDialogParam.clickListener = clkListener;
		mDialogParam.cancelListener = canListener;
		showDialog(Constants.DIALOG_INFO);
	}

	/**
	 * 显示一个带有一个确定、一个取消按钮的对话框
	 * 
	 * @param title
	 *            对话框的名称
	 * @param msg
	 *            对话框的消息
	 * @param canListener
	 *            对话框的监听器，可以为null
	 */
	public void showYesNoDialog(String title, String msg, String yes,
			String no, boolean cancellable, OnClickListener clkListener,
			OnCancelListener canListener) {
		mDialogParam.dlgTitle = title;
		mDialogParam.dlgMsg = msg;
		mDialogParam.yesButton = yes;
		mDialogParam.noButton = no;
		mDialogParam.cancelable = cancellable;
		mDialogParam.clickListener = clkListener;
		mDialogParam.cancelListener = canListener;

		showDialog(Constants.DIALOG_YESNO);
	}

	/**
	 * 网络无法连接时弹出一个自定义的Toast
	 * 
	 * @param duration
	 *            显示时长
	 */
	public void showNetworkUnavailableToast(int duration) {
		View toastView = getLayoutInflater().inflate(
				R.layout.network_unavailable_toast, null);
		toastView.setBackgroundColor(Color.rgb(241, 241, 241));
		toastView.setPadding(20, 20, 20, 20);
		Toast toast = new Toast(this);
		toast.setGravity(Gravity.CENTER, 0, 0);
		toast.setDuration(duration);
		toast.setView(toastView);
		toast.show();
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case Constants.DIALOG_PROGRESS:
			CustomProgressDialog progressDialog = new CustomProgressDialog(this);
			progressDialog.setCancelable(mDialogParam.cancelable);
			if (mDialogParam.cancelListener != null) {
				progressDialog.setOnCancelListener(mDialogParam.cancelListener);
			}
			return progressDialog;
		case Constants.DIALOG_INFO:
			CustomAlertDialog infoDialog = new CustomAlertDialog(this);
			infoDialog.setTitle(mDialogParam.dlgTitle);
			infoDialog.setMessage(mDialogParam.dlgMsg);
			infoDialog.setCancellable(mDialogParam.cancelable);
			infoDialog.setOnCancelListener(mDialogParam.cancelListener);
			infoDialog.setButton(CustomAlertDialog.BUTTON_POSITIVE,
					mDialogParam.yesButton, mDialogParam.clickListener);
			return infoDialog;
		case Constants.DIALOG_YESNO:
			CustomAlertDialog yesNoDialog = new CustomAlertDialog(this);
			yesNoDialog.setTitle(mDialogParam.dlgTitle);
			yesNoDialog.setMessage(mDialogParam.dlgMsg);
			yesNoDialog.setCancellable(mDialogParam.cancelable);
			yesNoDialog.setOnCancelListener(mDialogParam.cancelListener);
			yesNoDialog.setButton(CustomAlertDialog.BUTTON_POSITIVE,
					mDialogParam.yesButton, mDialogParam.clickListener);
			yesNoDialog.setButton(CustomAlertDialog.BUTTON_NEGATIVE,
					mDialogParam.noButton, mDialogParam.clickListener);
			return yesNoDialog;
		}

		return super.onCreateDialog(id);
	}

	/**
	 * 安全地关闭某个对话框
	 * 
	 * @param dialogId
	 */
	public void dismissDialogSafely(int dialogId) {
		try {
			dismissDialog(dialogId);
		} catch (Exception e) {
			Log.e(TAG, "FAIL to Dismiss Dialog[" + dialogId + "]!");
		}
	}

	/**
	 * 获取model发来的通知公共方法
	 */
	@Override
	public void update(Observable obserable, Object data) {
		try {
			if (data instanceof Integer) {
				switch ((Integer) data) {
				case NotificationIds.SHOW_PROGRESS_DIALOG:
					String waiting = getResources().getString(R.string.waiting);
					progressDialog.setMessage(waiting);
					progressDialog
							.setProgressStyle(ProgressDialog.STYLE_SPINNER);
					progressDialog.setCancelable(true);
					progressDialog.show();
					break;
				case NotificationIds.DISMISS_PROGRESS_DIALOG:
					progressDialog.dismiss();
					break;
				case NotificationIds.NEED_AUTH_ID:
					// 需要登录
					toLogin();
					break;
				}
				update((Integer) data);
			} else if (data instanceof CommonVo) {
				CommonVo vo = (CommonVo) data;
				int exNo = vo.getExNotificationId();
				if (exNo == NotificationIds.TOAST_NETWORK_NOT_WORK_ID) {
					onNetworkUnavailable(((CommonVo) data).getNotificationId());
				} else {
					update((CommonVo) data);
				}
			} else if (data instanceof Bundle) {
				update((Bundle) data);
			}
		} catch (Exception e) {
		}
	}

	public void update(int notificationId) {
	}

	public void update(CommonVo vo) {
	}

	public void update(Bundle bundle) {
	}

	/**
	 * 网络不可用
	 */
	protected void onNetworkUnavailable(int noti) {
		showNetworkUnavailableToast(Constants.TOAST_NORMAL_LONG);
		if (noti == 0) {
			finish();
		}
	}

	protected boolean supportShare2WX() {
		return true;
	}

	/**
	 * 分享到微信
	 */
	public void shareToWX() {
		if (supportShare2WX()) {
			if (mSharePopup == null) {
				LayoutInflater inflater = LayoutInflater.from(this);
				View shareLayout = inflater.inflate(R.layout.share_to_wechat,
						null);
				mSharePopup = new PopupWindow(shareLayout, -1, -1, true);
				mSharePopup.setTouchable(true);
				mSharePopup.setOutsideTouchable(true);
				mSharePopup.setFocusable(true);
				mSharePopup.setBackgroundDrawable(new ColorDrawable(
						Color.TRANSPARENT));

				PopupListener listener = new PopupListener(mSharePopup);
				View toFriends = shareLayout
						.findViewById(R.id.share_to_friends);
				View toTimeline = shareLayout
						.findViewById(R.id.share_to_timeline);
				shareLayout.setOnClickListener(listener);

				toFriends.setOnClickListener(listener);
				toTimeline.setOnClickListener(listener);
			}

			View parent = getWindow().findViewById(Window.ID_ANDROID_CONTENT);
			if (parent != null) {
				mSharePopup.showAtLocation(parent, Gravity.BOTTOM, 0, 0);
			}
		}
	}

	protected void onShare2WechatTimeline() {
		;
	}

	protected void onShare2WechatFriends() {
		;
	}

	/**
	 * 未安装微信
	 */
	protected void onWechatNotInstalled() {
		Toast.makeText(this, R.string.wechat_not_installed,
				Constants.TOAST_NORMAL_LONG).show();
		// 打开下载页面
		WXUtils.openAppSite(this);
	}

	/**
	 * 微信需要更新
	 */
	protected void onWechatNeedUpdate() {
		Toast.makeText(this, R.string.wechat_need_update,
				Constants.TOAST_NORMAL_LONG).show();
		// 打开下载页面
		WXUtils.openAppSite(this);
	}

	/**
	 * 分享对话框监听器
	 */
	class PopupListener implements View.OnClickListener {

		PopupWindow popupWindow;

		PopupListener(PopupWindow popupWindow) {
			this.popupWindow = popupWindow;
		}

		@Override
		public void onClick(View v) {
			if (v.getId() == R.id.share_to_timeline) {
				if (!WXUtils.isWXInstalled(BaseActivity.this))
				// 未安装微信
				{
					onWechatNotInstalled();
				} else if (!WXUtils.supportTimeLine(BaseActivity.this))
				// 不支持朋友圈
				{
					onWechatNeedUpdate();
				} else {
					onShare2WechatTimeline();
				}
			} else if (v.getId() == R.id.share_to_friends) {
				if (!WXUtils.isWXInstalled(BaseActivity.this))
				// 未安装微信
				{
					onWechatNotInstalled();
				} else if (!WXUtils.supportSDK(BaseActivity.this))
				// 不支持SDK
				{
					onWechatNeedUpdate();
				} else {
					onShare2WechatFriends();
				}
			}
			popupWindow.dismiss();
		}
	}

	/**
	 * 
	 * @Title: showToast
	 * 
	 * @Description: 关注成功/失败Toast
	 * @param @param text
	 * @param @param resId 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	public void showToast(String text, int resId) {
		TextView tv = new TextView(this);
		tv.setBackgroundResource(R.drawable.text_corner_round_normal);
		int padding = Util.dip2px(this, 20);
		tv.setPadding(padding, padding, padding, padding);
		tv.setText(text);
		tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
		tv.setTextColor(Color.parseColor("#5c2582"));
		tv.setCompoundDrawablesWithIntrinsicBounds(0, resId, 0, 0);
		tv.setGravity(Gravity.CENTER);
		Toast toast = new Toast(this);
		toast.setGravity(Gravity.CENTER, 0, 0);
		toast.setDuration(Toast.LENGTH_SHORT);
		toast.setView(tv);
		toast.show();
	}

	/**
	 * 查询是否有该Intent的Activity
	 * 
	 * @param intent
	 * @return
	 */
	protected boolean checkHasApplication4Intent(Intent intent) {
		if (intent == null) {
			return false;
		}
		PackageManager packageManager = getPackageManager();
		List<ResolveInfo> activities = packageManager.queryIntentActivities(
				intent, 0);
		return activities != null && activities.size() > 0 ? true : false;
	}
}
