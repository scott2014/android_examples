package com.tencent.weigou.base.model.vo;

import org.json.JSONObject;

/**
 * 所有的vo都继承commonVo
 * 
 * @author jonathanqi
 * 
 */
public class CommonVo {

	/**
	 * model和view绑定时，通知view更新时的识别id
	 */
	protected int notificationId;

	public int getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(int notificationId) {
		this.notificationId = notificationId;
	}

	protected int exNotificationId;

	public int getExNotificationId() {
		return exNotificationId;
	}

	public void setExNotificationId(int exNotificationId) {
		this.exNotificationId = exNotificationId;
	}

	public int errorCode;
	public String errorMsg;

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	/**
	 * json解析到vo方法
	 * 
	 * @param data
	 * @return true解析成功，false解析失败
	 */
	public boolean parse(JSONObject data) {
		return true;
	}

}
