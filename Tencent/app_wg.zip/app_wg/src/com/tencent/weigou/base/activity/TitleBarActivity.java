package com.tencent.weigou.base.activity;

import android.os.Bundle;
import android.util.Log;
import android.view.*;
import android.widget.TextView;
import com.tencent.weigou.R;
import com.tencent.weigou.common.ui.TopToolBar;

/**
 * 此类页面在其上方都会有一个标题栏 User: ethonchan Date: 13-10-14 Time: 下午4:55
 */
public class TitleBarActivity extends BaseActivity {
	int MENU_ITEM_COUNTER = 11;

	// 标题
	protected TextView titleTv;

	// 内容content
	protected View content;

	protected TopToolBar topbar;

	protected int rotateType = 0;// 0：正常；1：透明 ，修改依赖关系

	protected void setRotateType(int rotateType) {
		this.rotateType = rotateType;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		super.setContentView(R.layout.base_activity_with_titlebar);
		getWindow().setBackgroundDrawable(null);
	}

	@Override
	public void setContentView(int layoutResID) {
		if (content instanceof ViewStub)
		// 默认认为是使用我们的UI结构
		{
			ViewStub stub = (ViewStub) content;
			stub.setLayoutResource(layoutResID);
			content = stub.inflate();
		} else {
			super.setContentView(R.layout.base_activity_with_titlebar);
			content = findViewById(R.id.content);
			ViewStub stub = (ViewStub) content;
			stub.setLayoutResource(layoutResID);
			content = stub.inflate();
			Log.e(TAG, "setContentView reinvoke layoutResId=" + layoutResID);
		}
		content = findViewById(R.id.content);
		titleTv = (TextView) findViewById(R.id.top_bar_title);
		topbar = (TopToolBar) findViewById(R.id.top_bar);
	}

	/**
	 * 初始化返回按钮。展示“返回”二字，并且添加事件监听器
	 */
	public void initBackBtn() {
		topbar.initBackBtn(R.drawable.top_bar_back, new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				onBackPressed();
			}
		});
	}

	/**
	 * 初始化返回按钮。
	 * 
	 * @param strId
	 *            返回按钮上要展示的文字ID
	 * @param listener
	 *            绑定在返回按钮上的事件监听器
	 */
	public void initBackBtn(int strId, View.OnClickListener listener) {
		topbar.initBackBtn(strId, listener);
	}

	/**
	 * 设置标题
	 * 
	 * @param title
	 *            标题
	 */
	public void setTitle(String title) {
		topbar.initTitle(title);
	}

	/**
	 * 设置标题
	 * 
	 * @param strId
	 *            标题ID
	 */
	public void setTitle(int strId) {
		topbar.initTitle(strId);
	}

	public void setTitle(CharSequence title) {
		topbar.initTitle(title);
	}

}
