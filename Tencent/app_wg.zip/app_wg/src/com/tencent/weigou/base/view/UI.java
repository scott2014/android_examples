package com.tencent.weigou.base.view;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.View;
import android.widget.ImageView;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.ImageLoadingListener;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.assist.SimpleImageLoadingListener;
import com.nostra13.universalimageloader.core.display.FadeInBitmapDisplayer;
import com.tencent.weigou.R;
import com.tencent.weigou.base.model.vo.CommonVo;

/**
 * MVC框架的view层父类
 * 
 * @author jonathanqi
 * 
 */
public class UI {
	protected ImageLoadingListener animateFirstListener = new AnimateFirstDisplayListener();
	protected ImageLoader imageLoader = ImageLoader.getInstance();
	protected View outterView;
	protected Context context;
	protected DisplayImageOptions options;

	public void initView(View outterView) {
		this.outterView = outterView;
		context = outterView.getContext();
		options = new DisplayImageOptions.Builder()
				.showImageOnLoading(R.drawable.loading_big)
				.showImageForEmptyUri(R.drawable.loading_big)
				.showImageOnFail(R.drawable.loading_big).cacheInMemory(true)
				.cacheOnDisc(true).considerExifParams(true)
				.imageScaleType(ImageScaleType.IN_SAMPLE_INT)
				.bitmapConfig(Bitmap.Config.RGB_565).build();
	}

	protected View findViewById(int cId) {
		return outterView.findViewById(cId);
	}

	public void updateContent(CommonVo rv) {

	}

	/**
	 * 
	 * @Title: onDestroy
	 * @Description: 销毁
	 * 
	 *               void 返回类型
	 * @throws
	 */
	public void onDestroy() {
		imageLoader.clearMemoryCache();
		imageLoader.stop();
		AnimateFirstDisplayListener.displayedImages.clear();
	}

	// /**
	// * 异步加载图片
	// *
	// * @param imgView
	// * @param url
	// */
	// protected void asyncLoadImage(final ImageView imgView, final String url,
	// int reqWidth, int reqHeight, int defaultImageRid,
	// boolean diskCache, boolean cut) {
	// AsyncImageLoader asyncImageLoader;
	// if (diskCache) {
	// asyncImageLoader = new AsyncImageLoader(true);
	// } else {
	// asyncImageLoader = new AsyncImageLoader(false);
	// }
	// final Bitmap drawable = asyncImageLoader.loadDrawable(url, imgView,
	// reqWidth, reqHeight, cut, new IImageLoadedCallBack() {
	//
	// @Override
	// public void imageLoaded(final ImageView imageView,
	// final Bitmap bitmap, final String imageUrl) {
	// if (imageView != null && bitmap != null) {
	// imageView.setImageBitmap(bitmap);
	// }
	// }
	//
	// });
	// if (drawable != null) {
	// if (imgView != null) {
	// Object tag = imgView.getTag();
	// if (tag != null && tag.equals(url)) {
	// imgView.setImageBitmap(drawable);
	// imgView.setTag(null);
	// }
	// }
	// } else {
	// if (defaultImageRid == 0) {
	// imgView.setImageResource(R.drawable.loading120);
	// } else {
	// imgView.setImageResource(defaultImageRid);
	// }
	//
	// }
	// }

	public static class AnimateFirstDisplayListener extends
			SimpleImageLoadingListener {

		static final List<String> displayedImages = Collections
				.synchronizedList(new LinkedList<String>());

		@Override
		public void onLoadingComplete(String imageUri, View view,
				Bitmap loadedImage) {
			if (loadedImage != null) {
				ImageView imageView = (ImageView) view;
				boolean firstDisplay = !displayedImages.contains(imageUri);
				if (firstDisplay) {
					FadeInBitmapDisplayer.animate(imageView, 500);
					displayedImages.add(imageUri);
				}
			}
		}
	}
}
