package com.tencent.weigou;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import com.tencent.weigou.base.activity.BaseActivity;
import com.tencent.weigou.base.json.JsonResult;
import com.tencent.weigou.feeds.model.UnreadFeedVo;
import com.tencent.weigou.login.LoginUtils;
import com.tencent.weigou.util.MTAUtils;
import com.tencent.weigou.shopping.activity.ShoppingIndexActivity;
import com.tencent.weigou.user.UserVo;
import com.tencent.weigou.util.*;
import com.tencent.weigou.util.http.JSONGetter;
import com.tencent.weigou.util.lbs.LBSUtils;
import com.tencent.weigou.util.lbs.Location;

/**
 * 闪屏
 *
 * @author ethonchan
 */
public class EntryActivity extends BaseActivity implements Handler.Callback {

    private final int MSG_START_HOME = 123;

    private final String USER_INFO = "user_info";

    private final String MACHINE_KEY = "machine_key";

    // 等待时间
    private final int WAITING_TIME = 2000;

    private Handler mHandler;


    //  检查未读Feed的task
    private CheckFeedsAsyncTask mFeedTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 隐藏任务栏
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        int flag = WindowManager.LayoutParams.FLAG_FULLSCREEN;
        Window myWindow = this.getWindow();
        myWindow.setFlags(flag, flag);

        setContentView(R.layout.splash_layout);

        try {
            VersionType versionType = app.getVersionType();
            if (versionType == null || versionType == VersionType.DEBUG) {
                ;
            } else if (versionType == VersionType.GAMMA) {
                MTAUtils.startMTA(app, true, SysUtils.getChannelId(this));
            } else {
                MTAUtils.startMTA(app, false, SysUtils.getChannelId(this));
            }
        } catch (Exception e) {
            Log.e(TAG, "Unable to start MTA", e);
        }
        doMk();
        mHandler = new Handler(this);

        // 读取本地的登录信息
        UserVo user = LoginUtils.getLocalUserVo(this);
        //  本地简单校验登陆台的有效期
        if (user != null && user.isExpired()) {
            //  登录态过期，则清除登录态信息
            user = new UserVo();
        }
        //  更新登录信息
        app.updateUser(user);
        // 如果本地没有登录信息，或者登录信息完全过期的话去登录页面
        if (user != null && !user.isTokenEmpty()) {
            mFeedTask = new CheckFeedsAsyncTask();
            mFeedTask.execute();
        }
        mHandler.sendEmptyMessageDelayed(MSG_START_HOME, WAITING_TIME);
    }

    /**
     * 跳转到动态列表
     */
    protected void toFeeds() {
        Intent it = new Intent(this, ShoppingIndexActivity.class);

        it.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(it);
    }

    @Override
    public boolean handleMessage(Message msg) {
        if (msg.what == MSG_START_HOME) {
            toFeeds();
            finish();
        }
        return true;
    }

    private void doMk() {
        String mk = "";
        SharedPreferences mallPref = getSharedPreferences(USER_INFO, 0);
        if (StringUtils.isBlank(mallPref.getString(MACHINE_KEY, ""))) {
            SharedPreferences.Editor editor = mallPref.edit();
            mk = SysUtils.generateMkey(this);
            editor.putString(MACHINE_KEY, mk);
            editor.commit();
        } else {
            mk = mallPref.getString(MACHINE_KEY, "");
        }

        app.setMk(mk);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mFeedTask != null) {
            mFeedTask.cancel(true);
        }
        
        if (mHandler != null) {
        	mHandler.removeMessages(MSG_START_HOME);
        }
    }

    /**
     * 检查是否有新动态的异步线程
     */
    class CheckFeedsAsyncTask extends AsyncTask<Void, Void, Boolean> {

        @Override
        protected void onPreExecute() {
            // 检查网络状况
            if (!SysUtils.isNetworkAvaliable()) {
                cancel(true);
            } else {
                super.onPreExecute();
            }
        }

        @Override
        protected Boolean doInBackground(Void... params) {
            JSONGetter getter = new JSONGetter(false);
            String url = app.getEnv().getServerUrl() + ConstantsUrl.GET_UNREADED_FEEDS;
            Location loc = LBSUtils.getLocation();
            if (loc != null) {
                url += "?longitude=" + loc.longitude;
                url += "&latitude=" + loc.latitude;
            }

            url = appendPageInfo(url, PageIds.OprIndex.PV_OPR);
            boolean hasUnreadFeeds = false;
            try {
                JsonResult json = getter.doGet(url);
                if (json.isSuccess()) {
                    UnreadFeedVo feedVo = new UnreadFeedVo();
                    feedVo.parse(json.getData());
                    hasUnreadFeeds = feedVo.hasUnreadFeeds();
                }
            } catch (Exception e) {
                Log.d(TAG, "UnknownException", e);
            }

            return hasUnreadFeeds;
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            super.onPostExecute(aBoolean);

            app.setHasNewFeeds(aBoolean);
        }
    }
}
