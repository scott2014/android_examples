package com.tencent.weigou.web;

import com.tencent.weigou.util.StringUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * url白名单
 * User: ethonchan
 * Date: 13-12-23
 * Time: 下午3:21
 */
public class URLWhiteList {

    //  信任的域名列表
    private final static String[] mTrustDomains = new String[]{
            "qq.com",
            "paipai.com",
            "51buy.com",
            "icson.com",
            "tenpay.com",
            "paipaiimg.com",
            "wanggou.com"
    };

    private final static Pattern pattern = Pattern.compile("(?<=http://|\\.)[^.]*?\\.(com)", Pattern.CASE_INSENSITIVE);

    /**
     * 检查给定的URL能否通过白名单检查
     *
     * @param url
     * @return true校验通过，false校验不通过
     */
    public static boolean isFromTrustDomain(String url) {
        if (StringUtils.isNotBlank(url)) {
            Matcher matcher = pattern.matcher(url);
            try {
                matcher.find();
                String domain = matcher.group();
                for (String d : mTrustDomains) {
                    if (d.equals(domain)) {
                        return true;
                    }
                }
            } catch (Exception e) {
                ;
            }
        }
        return false;
    }
}
