package com.tencent.weigou.web;

//import android.annotation.SuppressLint;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.*;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.tencent.weigou.R;
import com.tencent.weigou.common.IDestroy;

/**
 * 带有back/forward的浏览器组件。
 * 
 * @author ethonchan
 * 
 */
public class CustomBrowser extends RelativeLayout implements OnClickListener,
		IDestroy, DownloadListener {
	public final static String TAG = "CustomBrowser";

	// 浏览器本身
	protected CustomWebView mBrowser;
	// 后退、前进、刷新、打开
	private View mBackBtn, mForwardBtn, mRefreshBtn, mOpenWith;
	// 当前页面展示的URL
	protected String mCurUrl;
	// 操作栏是否显示，具体包括“前进/后退/刷新/外部打开”这四个按钮
	private boolean mShowActionBar = true;
	// “外部打开”按钮是否显示
	private boolean mShowOpenWith = true;

	public CustomBrowser(Context context) {
		this(context, null);
	}

	public CustomBrowser(Context context, AttributeSet attrs) {
		super(context, attrs);
		LayoutInflater inflater = LayoutInflater.from(context);
		inflater.inflate(R.layout.webview_custom_layout, this);

		mBackBtn = findViewById(R.id.back_btn);
		mForwardBtn = findViewById(R.id.forward_btn);
		mRefreshBtn = findViewById(R.id.refresh_btn);
		mOpenWith = findViewById(R.id.out_btn);

		initInnerBrowser(context);

		mBackBtn.setOnClickListener(this);
		mForwardBtn.setOnClickListener(this);
		mRefreshBtn.setOnClickListener(this);
		mOpenWith.setOnClickListener(this);
	}

	// @SuppressLint("SetJavaScriptEnabled")
	@SuppressLint("NewApi")
	private void initInnerBrowser(Context context) {
		mBrowser = new CustomWebView(context);
		RelativeLayout.LayoutParams params = new LayoutParams(
				LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
		params.addRule(RelativeLayout.ABOVE, R.id.web_navigator);
		addView(mBrowser);

		WebSettings settings = mBrowser.getSettings();
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
			mBrowser.removeJavascriptInterface("searchBoxJavaBridge_");
		}
		settings.setJavaScriptEnabled(true);
		settings.setDatabaseEnabled(true);
		settings.setDomStorageEnabled(true);
		settings.setPluginState(WebSettings.PluginState.OFF);

		// 设置webview的storage
		String databasePath = settings.getDatabasePath();
		if (databasePath == null) {
			databasePath = context.getDir("database", Context.MODE_PRIVATE)
					.getPath();
			settings.setDatabasePath(databasePath);
		}

		// 允许缩放
		settings.setSupportZoom(false);
		settings.setBuiltInZoomControls(false);

		// 设置滚动条样式
		// mBrowser.setScrollbarFadingEnabled(false);
		// mBrowser.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);
		mBrowser.setDownloadListener(this);
	}

	/**
	 * 添加JavaScript接口
	 * 
	 * @param connector
	 *            绑定的Java对象
	 * @param interfaceName
	 *            接口名称
	 */
	public void addJavascriptInterface(Object connector, String interfaceName) {
		mBrowser.addJavascriptInterface(connector, interfaceName);
	}

	/**
	 * 设置操作栏的可见性
	 * 
	 * @param showActionBar
	 *            true可见，false不可见
	 */
	public void setActionBarVisibility(boolean showActionBar) {
		if (mShowActionBar ^ showActionBar) {
			View actionBar = (View) mBackBtn.getParent();
			actionBar.setVisibility(showActionBar ? View.VISIBLE : View.GONE);

			mShowActionBar = showActionBar;
		}
	}

	/**
	 * 设置“外部打开”按钮的可见性
	 * 
	 * @param showOpenWith
	 *            true可见，false不可见
	 */
	public void setOpenWithVisibility(boolean showOpenWith) {
		if (mShowOpenWith ^ showOpenWith) {
			mOpenWith.setVisibility(showOpenWith ? View.VISIBLE : View.GONE);

			mShowOpenWith = showOpenWith;
		}
	}

	/**
	 * 设置Webview所使用的内核。仅第一次设置有效
	 * 
	 * @param browserClient
	 *            控制页面的请求和加载
	 * @param jsClient
	 *            控制js脚本交互
	 */
	public void setWebViewClient(WebViewClient browserClient,
			WebChromeClient jsClient) {
		if (browserClient != null) {
			mBrowser.setWebViewClient(browserClient);
		}

		if (jsClient != null) {
			mBrowser.setWebChromeClient(jsClient);
		}
	}

	/**
	 * 开始开始加载url，同webview.loadData
	 * 
	 * @param data
	 * @param mimeType
	 * @param encoding
	 */
	public void loadData(String data, String mimeType, String encoding) {
		mBrowser.loadData(data, mimeType, encoding);
	}

	/**
	 * 加载指定的URL。还需要有更多种加载方式
	 * 
	 * @param url
	 */
	public void loadUrl(String url) {
		try {
			mBrowser.loadUrl(url);
			mCurUrl = url;
		} catch (Exception e) {
			Toast.makeText(getContext(), R.string.url_load_error,
					Toast.LENGTH_LONG).show();
			Log.e(TAG, e.getMessage(), e);
		}
	}

	/**
	 * 停止加载当前页面
	 */
	public void stopLoading() {
		mBrowser.stopLoading();
	}

	public boolean canGoBack() {
		return mBrowser.canGoBack();
	}

	public boolean canGoForward() {
		return mBrowser.canGoForward();
	}

	public void setBackButtonEnable(boolean enabled) {
		if (mBackBtn != null && mBackBtn.getVisibility() == View.VISIBLE) {
			mBackBtn.setEnabled(enabled);
		}
	}

	public void setForwardButtonEnable(boolean enabled) {
		if (mForwardBtn != null && mForwardBtn.getVisibility() == View.VISIBLE) {
			mForwardBtn.setEnabled(enabled);
		}
	}

	public void setRefreshButtonEnable(boolean enabled) {
		if (mRefreshBtn != null && mRefreshBtn.getVisibility() == View.VISIBLE) {
			mRefreshBtn.setEnabled(enabled);
		}
	}

	public void setOpenWithButtonEnable(boolean enabled) {
		if (mOpenWith != null && mOpenWith.getVisibility() == View.VISIBLE) {
			mOpenWith.setEnabled(enabled);
		}
	}

	@Override
	public void onClick(View view) {
		switch (view.getId()) {
		case R.id.back_btn:
			if (mBrowser.canGoBack())
				mBrowser.goBack();
			break;
		case R.id.forward_btn:
			if (mBrowser.canGoForward())
				mBrowser.goForward();
			break;
		case R.id.refresh_btn:
			mBrowser.reload();
			break;
		case R.id.out_btn:
			if (mCurUrl != null && URLUtil.isValidUrl(mCurUrl)) {
				Intent intent = new Intent(Intent.ACTION_VIEW,
						Uri.parse(mCurUrl));
				getContext().startActivity(intent);
			}
			break;
		}
	}

	@Override
	public void destroy() {
		if (mBrowser != null) {
			mBrowser.setVisibility(View.GONE);
			mBrowser.removeAllViews();
			removeView(mBrowser);
			mBrowser.destroy();
			mBrowser = null;
		}
	}

	@Override
	public void onDownloadStart(String url, String userAgent,
			String contentDisposition, String mimetype, long contentLength) {
		Uri uri = Uri.parse(url);
		Intent intent = new Intent(Intent.ACTION_VIEW, uri);
		try {
			getContext().startActivity(intent);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
