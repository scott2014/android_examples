package com.tencent.weigou.web;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.TextView;

import com.tencent.weigou.R;


/**
 * 自定义的WebChromeClient。负责JS事件
 * 
 * @author ethonchan
 * 
 */
public class CustomWebChromeClient extends WebChromeClient {
	public final static String TAG = "CustomWebChromeClient";

    //  标题读取监听器
    private OnReceivedTitle mTitleReceivedListener;

	@Override
	public void onConsoleMessage(String message, int lineNumber, String sourceID) {
		super.onConsoleMessage(message, lineNumber, sourceID);
		Log.d(TAG, "Msg = " + message);
		Log.d(TAG, "Line " + lineNumber + " @ " + sourceID);
	}

	@Override
	public boolean onJsAlert(WebView view, String url, String message,
			final JsResult result) {
		Context context = view.getContext();
		String title = context.getText(R.string.info_dialog_title).toString();
		String okBtn = context.getText(R.string.ok).toString();
		showCustomDialog(context, title, message, okBtn, null, result);

		return true;
	}

    /**
     * 设置标题读取监听器
     * @param listener
     */
    public void setTitleReceivedListener(OnReceivedTitle listener){
        mTitleReceivedListener = listener;
    }

    @Override
    public void onReceivedTitle(WebView view, String title) {
        super.onReceivedTitle(view, title);
        if(mTitleReceivedListener != null){
            mTitleReceivedListener.onReceivedTitle(title);
        }
    }

    @Override
	public boolean onJsConfirm(WebView view, String url, String message,
			JsResult result) {
		Context context = view.getContext();
		String title = context.getText(R.string.please_confirm).toString();
		String okBtn = context.getText(R.string.ok).toString();
		String cancelBtn = context.getText(R.string.cancel).toString();
		showCustomDialog(context, title, message, okBtn, cancelBtn, result);

		return true;
	}

	/**
	 * 弹出一个带有确定按钮的对话框，取消等按钮可选
	 * 
	 * @param ctx
	 * @param title
	 * @param message
	 * @param okBtn
	 * @param cancelBtn
	 *            若为null，则不展示取消按钮
	 * @param result
	 */
	private void showCustomDialog(Context ctx, String title,
			String message, String okBtn, String cancelBtn,
			final JsResult result) {
		AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
		builder.setTitle(title);
		builder.setMessage(message);
		builder.setCancelable(true);

		AlertDialog.OnClickListener clickListener = new AlertDialog.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				if (which == AlertDialog.BUTTON_POSITIVE) {
					dialog.dismiss();
					if(result != null) {
						result.confirm();
					}
				} else if (which == AlertDialog.BUTTON_NEGATIVE) {
					dialog.cancel();
					if(result != null) {
						result.cancel();
					}
				}
			}
		};

		AlertDialog dialog = builder.create();
		dialog.setButton(AlertDialog.BUTTON_POSITIVE, okBtn, clickListener);
		if (cancelBtn != null) {
			dialog.setButton(AlertDialog.BUTTON_NEGATIVE, cancelBtn,
					clickListener);
		}
		dialog.setOnCancelListener(new OnCancelListener() {
			@Override
			public void onCancel(DialogInterface dialog) {
				dialog.cancel();
				if(result != null) {
					result.cancel();
				}
				
			}
		});

		dialog.show();
	}

	@Override
	public boolean onJsPrompt(WebView view, String url, String message,
			String defaultValue, JsPromptResult result) {
		Context context = view.getContext();
		showPromptDialog(context, defaultValue, message, result);

		return true;
	}

	/**
	 * 弹出一个带有输入框、确定、取消的对话框
	 * 
	 * @param context
	 * @param defaultValue
	 *            输入框的默认值
	 * @param message
	 * @param result
	 */
	private void showPromptDialog(Context context, String defaultValue,
			String message, final JsPromptResult result) {
		String title = context.getString(R.string.please_confirm).toString();
		String okBtn = context.getString(R.string.ok).toString();
		String cancelBtn = context.getString(R.string.cancel).toString();

		LayoutInflater inflater = LayoutInflater.from(context);
		View view = inflater.inflate(R.layout.webkit_prompt_layout, null);
		final TextView msgView = (TextView) view
				.findViewById(R.id.webkit_prompt_msg);
		final EditText inputView = (EditText) view
				.findViewById(R.id.webkit_prompt_default_value);

		AlertDialog.OnClickListener clickListener = new AlertDialog.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				if (which == AlertDialog.BUTTON_POSITIVE) {
					dialog.dismiss();
					String text = inputView.getText().toString();
					if(result != null) {
						result.confirm(text);
					}					
				} else if (which == AlertDialog.BUTTON_NEGATIVE) {
					dialog.cancel();
					if(result != null) {
						result.cancel();
					}
				}
			}
		};

		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setTitle(title);
		msgView.setText(message);
		inputView.setText(defaultValue);
		builder.setCancelable(true);
		builder.setView(view);

		AlertDialog dialog = builder.create();
		dialog.setButton(AlertDialog.BUTTON_POSITIVE, okBtn, clickListener);
		dialog.setButton(AlertDialog.BUTTON_NEGATIVE, cancelBtn, clickListener);
		dialog.setOnCancelListener(new OnCancelListener() {
			@Override
			public void onCancel(DialogInterface dialog) {
				dialog.cancel();
				if(result != null) {
					result.cancel();
				}
			}
		});

		dialog.show();
	}
}