package com.tencent.weigou.web;

import android.graphics.Bitmap;
import android.net.http.SslError;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import com.tencent.weigou.R;
import com.tencent.weigou.util.CommonJumpUtils;
import com.tencent.weigou.util.Constants;

/**
 * 自定义的WebViewClient。负责处理url的拦截、异常的处理等页面相关的各种问题
 *
 * @author ethonchan
 *
 */
public class CustomWebViewClient extends WebViewClient {
	// 当前加载的URL，用于辅助判断是否页面是否加载完成
	protected String curUrl;
	// 加载状态监听器
	protected OnPageLoadingListener mLoadingListener;

	/**
	 * 这个是为了解决在2.3.X的Android系统中，H5页面中点击链接不一定每次都会调用 shouldOverrideUrlLoading方法，
	 * 但是不调用shouldOverrideUrlLoading方法会去调onPageStarted，
	 * 所以在不影响用curUrl判断load另一个h5链接的情况下，用这个变量来判断
	 * 是否执行了shouldOverrideUrlLoading方法中跳转本地页面的两个if判断，
	 * 如果执行过了，onPageStarted就不再执行，否则执行
	 *
	 * 这个改动不影响其他Android版本正常的逻辑
	 */
	private boolean shouldIsExecuted = false;

	/**
	 * 添加一个加载状态监听器，监听页面加载的各个状态（开始加载、加载完成、加载失败）
	 *
	 * @param listener
	 */
	public void addOnPageLoadingListener(OnPageLoadingListener listener) {
		this.mLoadingListener = listener;
	}

    @Override
	public void onPageStarted(WebView view, String url, Bitmap favicon) {
		super.onPageStarted(view, url, favicon);

		if (curUrl == null && mLoadingListener != null) {
			curUrl = url;

			mLoadingListener.onLoadingStarted(url);

		}

		if (!shouldIsExecuted
				&& (url.startsWith(WebkitConstants.JUMP_PREFIX_OLD) || url
						.startsWith(WebkitConstants.JUMP_PREFIX))) {
			view.stopLoading();
			shouldOverrideUrlLoading(view, url);
		}
	}

	@Override
	public void onReceivedSslError(WebView view, SslErrorHandler handler,
			SslError error) {
		// 忽略HTTPS不信任的情况
		handler.proceed();
	}

	@Override
	public void onPageFinished(WebView view, String url) {
		super.onPageFinished(view, url);

		if (curUrl != null && mLoadingListener != null) {
			curUrl = null;

			mLoadingListener.onLoadingSuccess(url);
			view.loadUrl("javascript:window.wgOrder_src=2;");//ios:1,andriod:2
        }
	}

	@Override
	public void onReceivedError(WebView view, int errorCode,
			String description, String failingUrl) {
		super.onReceivedError(view, errorCode, description, failingUrl);
		if (curUrl != null && mLoadingListener != null) {
			mLoadingListener
					.onLoadingFailed(failingUrl, description, errorCode);
		}
	}

	public boolean shouldOverrideUrlLoading(WebView view, String url) {
		if (url == null) {
			;
			// } else if (url.startsWith(WebkitConstants.JUMP_PREFIX_OLD))
			// // 兼容老的跳转规则
			// {
			// shouldIsExecuted = true;
			// int index = url.indexOf("?");
			// if (index > -1) {
			// String paramStr = url.substring(index + 1);
			// Map<String, String> paramMap = Util.getParam(paramStr);
			// parseParams(view.getContext(), paramMap);
			// }
		} else if (url.startsWith(WebkitConstants.JUMP_PREFIX))
		// 客户端中认可的跳转链接
		{
			shouldIsExecuted = true;
			String jumpStr = url.replaceFirst(WebkitConstants.JUMP_PREFIX, "");
			CommonJumpUtils.go(view.getContext(), jumpStr);
		} else if (URLUtil.isValidUrl(url) && URLWhiteList.isFromTrustDomain(url)) {
			if (curUrl == null && mLoadingListener != null) {
				curUrl = url;

				mLoadingListener.onLoadingStarted(url);
			}
			view.loadUrl(url);
		} else {
			Toast.makeText(view.getContext(), R.string.invalid_url,
					Constants.TOAST_NORMAL_LONG).show();
		}

		return true;
	}

	// /**
	// * 兼容老的跳转方式
	// *
	// * @param dest
	// */
	// private void parseParams(Context context, Map<String, String> paramMap) {
	// if (paramMap == null) {
	// return;
	// }
	//
	// String dest = paramMap.get("dest");
	// Class<?> targetClass = null;
	// // if ("home.recharge".equals(dest))
	// // // 充值中心
	// // {
	// // targetClass = SubChargeActivity.class;
	// // } else if ("my.coupon".equals(dest))
	// // // 我的优惠券
	// // {
	// // targetClass = MyCouponActivity.class;
	// // } else if ("home.login".equals(dest))
	// // // 登录
	// // {
	// // targetClass = LoginActivity.class;
	// // } else if ("search".equals(dest))
	// // // 搜索
	// // {
	// // StringBuilder searchParam = new StringBuilder();
	// // String path = paramMap.get("path");
	// // if (!StringUtils.isBlank(path)) {
	// // searchParam.append("path=").append(path).append("&");
	// // }
	// //
	// // String keywords = paramMap.get("keywords");
	// // if (!StringUtils.isBlank(keywords)) {
	// // searchParam.append("keywords=").append(keywords).append("&");
	// // }
	// //
	// // String classId = paramMap.get("classId");
	// // if (!StringUtils.isBlank(classId)) {
	// // searchParam.append("classId=").append(classId).append("&");
	// // }
	// //
	// // CommonClickEventUtil.goActivity(context, "4",
	// // searchParam.toString());
	// // } else if (CommonClickEventUtil.isActivity(dest))
	// // // 跳转任意的activity
	// // {
	// // CommonClickEventUtil.startActivity(context, dest, paramMap);
	// // } else
	// // // 默认跳回首页
	// // {
	// // Intent intent = new Intent(context, MainHomeActivity.class);
	// // intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
	// // context.startActivity(intent);
	// // }
	//
	// // if (targetClass != null) {
	// // Intent intent = new Intent(context, targetClass);
	// // context.startActivity(intent);
	// // }
	// }
}