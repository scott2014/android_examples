package com.tencent.weigou.web;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.webkit.WebView;

/**
 * @author: ethonchan
 * @date: 14-1-13 下午3:40
 */
public class CustomWebView extends WebView{
    public CustomWebView(Context context) {
        super(context);
    }

    public CustomWebView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CustomWebView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(event.getAction() == MotionEvent.ACTION_DOWN){
            int tempY = getScrollY();
            scrollTo(getScrollX(), tempY + 1);
            scrollTo(getScrollX(), tempY);
        }
        return super.onTouchEvent(event);
    }
}
