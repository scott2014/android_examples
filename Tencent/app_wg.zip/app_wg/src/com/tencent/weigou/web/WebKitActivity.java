package com.tencent.weigou.web;

import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Message;
import android.util.Log;
import android.webkit.URLUtil;
import android.widget.Toast;
import com.tencent.weigou.R;
import com.tencent.weigou.base.activity.TitleBarActivity;
import com.tencent.weigou.exception.activity.NetworkUnavailableActivity;
import com.tencent.weigou.util.*;

import java.io.File;

/**
 * 
 * @ClassName: WebKitActivity
 * @Description: 本页面支持H5相关的页面
 * @author wendyhu wendyhu@tencent.com
 * @date 2013-1-30 上午14:39:11
 * 
 */
public class WebKitActivity extends TitleBarActivity implements Callback,
		OnReceivedTitle {
	public static final String TAG = "WebKitActivity";

	// 浏览器
	protected CustomBrowser mBrowser;
	// 页面加载监听器
	protected PageLoadingListener mLoadingListener;
	// 负责javascript中需要在UI线程中进行的操作
	protected Handler mUiHandler;
	// javascript的返回值
	protected String mJavascriptReturnValue;

	/******************************** 业务参数 ****************************/
	// 是否需要附加uk,mk,qqNum,pkg,chid,version,uuid等信息
	protected boolean mAppendAppInfo = true;
	// 是否需要强制登录
	protected boolean mNeedLogin = false;
	protected String mInitedUrl = null;
	private Intent mIntent = null;
	protected String mLoginSuccessCallback = null;
	protected String mLoginFailCallback = null;

	protected File tmpFile = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mUiHandler = new Handler(this);
		mIntent = getIntent();
		boolean inited = initByIntent(mIntent);
		initBackBtn();
		if (!inited) {
			finish();
		} else {
			loadPage();
		}
	}

	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		mIntent = intent;
		boolean inited = initByIntent(intent);

		if (!inited) {
			finish();
		} else {
			loadPage();
		}
	}

	/**
	 * 根据Intent初始化界面
	 * 
	 * @param intent
	 * @return 是否成功初始化
	 */
	protected boolean initByIntent(Intent intent) {
		// INTENT_URL为必填
		if (intent == null
				|| intent.getStringExtra(WebkitConstants.INTENT_URL) == null) {
			return false;
		}

		String intentUrl = intent.getStringExtra(WebkitConstants.INTENT_URL);
		if (!URLUtil.isValidUrl(intentUrl)) {
			return false;
		}
		mInitedUrl = intentUrl;

		// 是否需要带上登录信息
		String appendUser = intent
				.getStringExtra(WebkitConstants.INTENT_APPEND_APP_PARAMS);
		if ("false".equals(appendUser)) {
			mAppendAppInfo = false;
		}

		// 是否需要强制登录
		String needLogin = intent
				.getStringExtra(WebkitConstants.INTENT_NEED_LOGIN);
		if ("true".equals(needLogin)) {
			mNeedLogin = true;
		}

		// 是否要充值sourcePageId
		String pageId = intent
				.getStringExtra(WebkitConstants.INTENT_SOURCE_PAGEID);
		if (!StringUtils.isBlank(pageId)) {
			sourcePageId = Util.parseNum(pageId);
		}

		setContentView(R.layout.custom_webkit);
		mBrowser = (CustomBrowser) findViewById(R.id.webview);

		String title = intent.getStringExtra(WebkitConstants.INTENT_TITLE);
		initTitle(title);

		// 是否展示页面下方的ActionBar
		String showActionBarStr = intent
				.getStringExtra(WebkitConstants.INTENT_SHOW_ACTION_BAR);
		boolean showActionBar = false;
		if (showActionBarStr != null && showActionBarStr.equals("true")) {
			showActionBar = true;
		}
		mBrowser.setActionBarVisibility(showActionBar);
		// 是否展示打开外部浏览器的按钮，默认不展示
		String showOpenWithStr = intent
				.getStringExtra(WebkitConstants.INTENT_SHOW_OPEN_WITH);
		boolean showOpenWith = false;
		if (showOpenWithStr != null && showOpenWithStr.equals("true")) {
			showOpenWith = true;
		}
		mBrowser.setOpenWithVisibility(showOpenWith);

		// 初始化webview
		CustomWebViewClient webViewClient = new CustomWebViewClient();
		mLoadingListener = new PageLoadingListener();
		webViewClient.addOnPageLoadingListener(mLoadingListener);
		CustomWebChromeClient chromeClient = new CustomWebChromeClient();
		mBrowser.setWebViewClient(webViewClient, chromeClient);
		chromeClient.setTitleReceivedListener(this);

		// android各版本的setCookie有bug，还是不要用的好
		// 判断Url是否要写用户wid的cookie
		return true;
	}

	private void loadPage() {
		if (!StringUtils.isBlank(mInitedUrl)) {
			// StringBuilder sb = new StringBuilder();
			// String url = mInitedUrl;
			//
			// // 判断是否有锚点
			// String anchor = "";
			// int anchorIndex = url.indexOf("#");
			// if (anchorIndex > 0) {
			// anchor = url.substring(anchorIndex);
			// url = url.substring(0, anchorIndex - 1);
			// }
			// sb.append(url);
			// boolean hasParam = true;
			// if (!url.contains("?")) {
			// hasParam = false;
			// sb.append("?");
			// }

			// if (mNeedLogin && !isLogin())
			// // 必须登录而又还未登录
			// {
			// Intent intent = new Intent();
			// intent.setClass(getApplicationContext(), LoginActivity.class);
			// startActivityForResult(intent,
			// WebkitConstants.REQ_CODE_LOGIN_ON_CREATE);
			// } else {
			// if (mAppendAppInfo) {
			// if (hasParam)
			// sb.append("&uk=").append(getUk());
			// else
			// sb.append("uk=").append(getUk());
			// sb.append("&mk=").append(getMk());
			// sb.append("&qqNum=").append(getQQNum());
			// sb.append("&pkg=").append(SysUtil.getPackName(this));
			// sb.append("&chid=").append(SysUtil.getChannelId(this));
			// sb.append("&version=").append(SysUtil.getVersion(this));
			// sb.append("&uuid=").append(SysUtil.UUID);
			//
			// // 添加锚点
			// sb.append(anchor);
			// }

			mBrowser.loadUrl(mInitedUrl);
			// }
		}
	}

	private void initTitle(String title) {
		setTitle(title);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == WebkitConstants.REQ_CODE_LOGIN_ON_CREATE)
			// 首次进入就需要登录
			// {
			// if (isLogin()) {
			// loadPage();
			// } else
			// // 未登录
			// {
			// finish();
			// }
			// } else if (requestCode == WebkitConstants.REQ_CODE_LOGIN)
			// // 在页面中操作时需要登录
			// {
			// if (isLogin())
			// // 登录成功
			// {
			// if (mLoginSuccessCallback != null) {
			// mBrowser.loadUrl("javascript:" + mLoginSuccessCallback
			// + "('" + getUk() + "')");
			// }
			// } else
			// // 未登录
			// {
			// if (mLoginFailCallback != null) {
			// mBrowser.loadUrl("javascript:" + mLoginFailCallback + "()");
			// }
			// }
			// } else {
			super.onActivityResult(requestCode, resultCode, data);
		// }
	}

	@Override
	protected void onDestroy() {
		if (mBrowser != null) {
			mBrowser.destroy();
		}
		if (tmpFile != null) {
			tmpFile.delete();
		}
		super.onDestroy();
	}

	@Override
	public boolean handleMessage(Message msg) {
		switch (msg.what) {
		case WebkitConstants.MSG_DOM_LOADED:
			if (mLoadingListener != null) {
				String fakeURL = "this is not the real URL. used when DOM loaded";
				mLoadingListener.onLoadingSuccess(fakeURL);
			}
			break;
		case WebkitConstants.MSG_SHARE_SCREEN:
			if (tmpFile != null) {
				boolean success = tmpFile.delete();
				if (success) {
					tmpFile = null;
				}
			}

			Bundle data = msg.getData();
			if (data != null) {
				String desc = data
						.getString(WebkitConstants.BUNDLE_SHARE_DESCRIPTION);
				String fname = data
						.getString(WebkitConstants.BUNDLE_SHARE_IMAGE_NAME);

				File imgFile = SysUtils.shareViewCache(mBrowser, fname, desc);
				if (imgFile == null) {
					showToast(R.string.share_fail);
				} else {
					tmpFile = imgFile;
				}
			}
			break;
		case WebkitConstants.MSG_BACK:
			finish();
			break;
		}
		return false;
	}

	@Override
	public void onReceivedTitle(String title) {
		if (StringUtils.isNotBlank(title)) {
			setTitle(title);
		}
	}

	/**
	 * 监听页面加载状态，展示“请稍候”对话框
	 * 
	 * @author ethonchan
	 * 
	 */
	class PageLoadingListener implements OnPageLoadingListener,
			OnCancelListener {

		@Override
		public void onCancel(DialogInterface dialog) {
			Log.d(TAG, "Cancelled by User");
			mBrowser.stopLoading();
		}

		@Override
		public void onLoadingStarted(String url) {
			Log.d(TAG, "START downloading page - " + url);

			// 只有在需要发起请求时才需要网络。 无网络连接时跳转到刷新页面
			if (!SysUtils.isNetworkAvaliable()) {
				Log.d(TAG, "no network, CANCEL downloading ! - " + url);
				// Intent intent = new Intent(WebKitActivity.this,
				// NetworkUnavailableActivity.class);
				// intent.putExtra(ConstantsActivity.NET_ERR_INTENT, mIntent);
//				onNetworkUnavailable(0);
				finish();
				// startActivity(intent);
			} else {
				mBrowser.setBackButtonEnable(false);
				mBrowser.setForwardButtonEnable(false);

				showProgressDialog(this, true);
			}
		}

		@Override
		public void onLoadingSuccess(String url) {
			Log.d(TAG, "FINISH downloaded page - " + url);
			mBrowser.setBackButtonEnable(mBrowser.canGoBack());
			mBrowser.setForwardButtonEnable(mBrowser.canGoForward());

			try {
				dismissDialog(Constants.DIALOG_PROGRESS);
			} catch (Exception e) {
				Log.e(TAG, e.getMessage(), e);
			}
		}

		@Override
		public void onLoadingFailed(String url, String description,
				int errorCode) {
			Log.d(TAG, "[errCode = " + errorCode + " ] " + description + " - "
					+ url);
			mBrowser.setBackButtonEnable(mBrowser.canGoBack());
			mBrowser.setForwardButtonEnable(mBrowser.canGoForward());

			try {
				dismissDialog(Constants.DIALOG_PROGRESS);
			} catch (Exception e) {
				Log.e(TAG, e.getMessage(), e);
			}
			finish();
			// Intent intent = new Intent(WebKitActivity.this,
			// NetworkUnavailableActivity.class);
			// intent.putExtra(ConstantsActivity.NET_ERR_INTENT, mIntent);
			// startActivity(intent);
		}
	}

	protected void showToast(int resId) {
		Toast.makeText(this, resId, Constants.TOAST_NORMAL_LONG).show();
	}
}