package com.tencent.weigou.web;

/**
 * Webkit使用的一些常量
 * 
 * @author ethonchan
 * 
 */
public class WebkitConstants {
	/**
	 * 页面访问url参数名，必填
	 */
	public static final String INTENT_URL = "url";

	/**
	 * 页面title参数名，非必填，若不填将不会展示标题栏
	 */
	public static final String INTENT_TITLE = "title";

	/**
	 * 左上角返回标签名称
	 */
	public static final String INTENT_BACK_TITLE = "back_title";

	/**
	 * 是否显示ActionBar，非必填，默认不显示ActionBar
	 */
	public static final String INTENT_SHOW_ACTION_BAR = "show_action_bar";

	/**
	 * url请求时是否附带上用户信息，默认带上。true/false
	 */
	public static final String INTENT_APPEND_APP_PARAMS = "webkit_append_url";

	/**
	 * 是否必须登录，默认不需要。true/false
	 */
	public static final String INTENT_NEED_LOGIN = "login";
	
	/**
	 * 是否显示actionBar上方的openwith
	 */
	public static final String INTENT_SHOW_OPEN_WITH = "show_open_with";

	/**
	 * webkit展示的网页的pageId 这个pageId会被设置为sourcePageId，用于统计
	 */
	public static final String INTENT_SOURCE_PAGEID = "page_id";

	/**
	 * 首次进去就需要去登录
	 */
	public final static int REQ_CODE_LOGIN_ON_CREATE = 1234;

	/**
	 * webkit中跳转到登录
	 */
	public final static int REQ_CODE_LOGIN = 1235;

	/**
	 * 暴露给Javascript的方法前缀
	 */
	public final static String JAVASCRIPT_PREFIX = "weigou";

	/**
	 * webkit中使用的跳转链接。使用方式：mwg://jump信息。其中jump信息与统一跳转中的jump字段相同
	 * 如：mwg://detail?type=XXX&commodityId=1000000187EA00234C01000000019178
	 * 表示跳转到给定ID的普通商品详情，非抢购，type来区分网购还是拍拍
	 */
	public final static String JUMP_PREFIX = "weigou://";

	/**
	 * 旧版的跳转规则
	 */
	public final static String JUMP_PREFIX_OLD = "http://app/open.xhtml";

	/**
	 * 分享使用的文字描述字段
	 */
	public final static String BUNDLE_SHARE_DESCRIPTION = "share_description";

	/**
	 * 分享使用的图片文件名
	 */
	public final static String BUNDLE_SHARE_IMAGE_NAME = "share_image_name";

	/**
	 * 网页的DOM加载完成
	 */
	public final static int MSG_DOM_LOADED = 1110;

	/**
	 * 截屏并分享
	 */
	public final static int MSG_SHARE_SCREEN = 1111;

	/**
	 * BACK
	 */
	public final static int MSG_BACK = 1112;
}
