package com.tencent.weigou.web;

import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.util.Log;
import android.webkit.WebView;

import com.tencent.weigou.base.activity.BaseActivity;
import com.tencent.weigou.util.Constants;
import com.tencent.weigou.util.SysUtils;


/**
 * 一个简单的webviewClient，作用是实现基本的UI交互、日志记录和网络异常处理功能
 * 
 * @author ethonchan
 * 
 */
public class SimpleWebViewClient extends CustomWebViewClient implements
		OnPageLoadingListener, OnCancelListener {
	private BaseActivity owner;
	private WebView mBrowser;
	private static String TAG = null;

	public SimpleWebViewClient(BaseActivity ownerActivity, WebView browser) {
		this.owner = ownerActivity;
		mBrowser = browser;
		addOnPageLoadingListener(this);
		TAG = ownerActivity.getClass().getSimpleName();
	}

	@Override
	public void onCancel(DialogInterface dialog) {
		Log.d(TAG, "Cancelled by User");
		if (mBrowser != null) {
			mBrowser.stopLoading();
		}
	}

	@Override
	public void onLoadingStarted(String url) {
		Log.d(TAG, "START downloading page - " + url);

		// 只有在需要发起请求时才需要网络。 无网络连接时跳转到刷新页面
		if (!SysUtils.isNetworkAvaliable()) {
			Log.d(TAG, "no network, CANCEL downloading ! - " + url);
			onNetworkUnavailable();
			return;
		}

		if (owner != null) {
			owner.showProgressDialog(this, true);
		}
	}

	/**
	 * 无网络的回调
	 */
	public void onNetworkUnavailable() {
		;
	}

	@Override
	public void onLoadingSuccess(String url) {
		Log.d(TAG, "FINISH downloaded page - " + url);
		try {
			owner.dismissDialog(Constants.DIALOG_PROGRESS);
		} catch (Exception e) {
			Log.e(TAG, e.getMessage(), e);
		}
	}

	@Override
	public void onLoadingFailed(String url, String description, int errorCode) {
		Log.d(TAG, "[errCode = " + errorCode + " ] " + description + " - "
				+ url);
		try {
			owner.dismissDialog(Constants.DIALOG_PROGRESS);
		} catch (Exception e) {
			Log.e(TAG, e.getMessage(), e);
		}
	}

}
