package com.tencent.weigou.web;

import android.webkit.WebViewClient;

/**
 * 页面加载情况监听器
 * 
 * @author ethonchan
 * 
 */
public interface OnPageLoadingListener {
	/**
	 * 页面开始加载
	 * 
	 * @param url
	 */
	public void onLoadingStarted(final String url);

	/**
	 * 页面加载成功
	 * 
	 * @param url
	 */
	public void onLoadingSuccess(final String url);

	/**
	 * 页面加载失败
	 * 
	 * @param url
	 * @param description
	 *            失败原因描述
	 * @param errorCode
	 *            错误码。参见{@link WebViewClient - onReivedError}
	 */
	public void onLoadingFailed(final String url, final String description,
			final int errorCode);

}
