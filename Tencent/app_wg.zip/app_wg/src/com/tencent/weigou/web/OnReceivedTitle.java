package com.tencent.weigou.web;

/**
 * 读取到webview的标题时的回调
 * @author: ethonchan
 * @date: 14-1-10 下午3:24
 */
public interface OnReceivedTitle {

    /**
     * 读取到webview的标题
     * @param title
     */
    public void onReceivedTitle(String title);
}
