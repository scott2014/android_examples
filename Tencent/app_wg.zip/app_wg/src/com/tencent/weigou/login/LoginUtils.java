package com.tencent.weigou.login;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.provider.BaseColumns;
import android.util.Log;
import com.tencent.weigou.login.db.LoginDatabaseHelper;
import com.tencent.weigou.user.UserVo;
import com.tencent.weigou.util.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

/**
 * 登录工具类
 * User: ethonchan
 * Date: 13-11-5
 * Time: 下午2:07
 */
public class LoginUtils {

    public final static String TAG = "LoginUtils";

    /**
     * 获取本地的用户信息
     *
     * @param context
     * @return
     */
    public static UserVo getLocalUserVo(Context context) {
        UserVo user = null;
        LoginDatabaseHelper helper = new LoginDatabaseHelper(context);
        SQLiteDatabase db = helper.getReadableDatabase();
        if (db == null) {
            return user;
        }

        try {
            String[] columns = new String[]{Schema._ID, Schema.TOKEN_A, Schema.TOKEN_B, Schema.COMM_ID, Schema.LAST_MODIFIED};
            Cursor cursor = db.query(Schema.TABLE_NAME, columns, null, null, null, null, null);
            if (cursor != null) {
                if (cursor.moveToFirst()) {
                    final int idIndex = cursor.getColumnIndex(Schema._ID);
                    final int commIndex = cursor.getColumnIndex(Schema.COMM_ID);
                    final int tokenAIndex = cursor.getColumnIndex(Schema.TOKEN_A);
                    final int tokenBIndex = cursor.getColumnIndex(Schema.TOKEN_B);
                    final int modIndex = cursor.getColumnIndex(Schema.LAST_MODIFIED);
                    List<UserVo> userList = new ArrayList<UserVo>();
                    do {
                        String wId = cursor.getString(idIndex);
                        byte[] tokenA = cursor.getBlob(tokenAIndex);
                        byte[] tokenB = cursor.getBlob(tokenBIndex);
                        //  解密token
                        String tokenStr = decrypt(tokenA, tokenB);
                        String lastMod = cursor.getString(modIndex);
                        String commId = cursor.getString(commIndex);
                        long lastModified = Util.getLong(lastMod, 0);
                        UserVo vo = new UserVo(wId, tokenStr, commId, lastModified);
                        userList.add(vo);
                    } while (cursor.moveToNext());
                    cursor.close();
                    cursor = null;
                    db.close();
                    db = null;

                    if (userList.size() > 0) {
                        Collections.sort(userList);
                        user = userList.get(0);
                    }
                } else {
                    if (!cursor.isClosed()) {
                        cursor.close();
                        cursor = null;
                    }
                    db.close();
                    db = null;
                }
            } else if (db.isOpen()) {
                db.close();
                db = null;
            }
        } catch (Exception e) {
            Properties params = new Properties();
            params.put(MTAConstants.KEY_MSG, e.getMessage());
            MTAUtils.reportMTAEvent(MTAConstants.ID_READ_USER_DB, params);
            Log.e(TAG, "Exception when readUserDB", e);
        } finally {
            if (db != null && db.isOpen()) {
                db.close();
            }
            db = null;
        }
        return user;
    }

    /**
     * 将用户信息保持到本地
     *
     * @param context
     * @param user
     */
    public static void updateLocalUserVo(Context context, UserVo user) {
        if (user != null) {
            byte[][] bytes = encrypt(user.xToken);
            LoginDatabaseHelper mHelper = new LoginDatabaseHelper(context);
            SQLiteDatabase db = mHelper.getWritableDatabase();
            if (db != null) {
                if (bytes != null && bytes.length == 2) {
                    ContentValues values = new ContentValues();
                    values.put(Schema._ID, user.wId);
                    values.put(Schema.COMM_ID, user.commId);
                    values.put(Schema.TOKEN_A, bytes[0]);
                    values.put(Schema.TOKEN_B, bytes[1]);
                    values.put(Schema.LAST_MODIFIED, "" + System.currentTimeMillis());
                    db.insertWithOnConflict(Schema.TABLE_NAME, null, values, SQLiteDatabase.CONFLICT_REPLACE);
                }
                db.close();
            }
        }
    }

    /**
     * 加密登录态
     *
     * @param token 登录态
     * @return 加密后的两段byte数组，或者NULL
     */
    protected static byte[][] encrypt(String token) {
        try {
            final int lenA = token.length() / 2;
            final String partA = token.substring(0, lenA);
            final String partB = token.substring(lenA);
            String cipherA = CryptHelper.encrypt(partA);
            String cipherB = CryptHelper.encrypt(partB);
            byte[] byteA = cipherA.getBytes(Constants.ENCODE_CHARSET);
            byte[] byteB = cipherB.getBytes(Constants.ENCODE_CHARSET);
            return new byte[][]{byteA, byteB};
        } catch (Exception e) {
            Log.e(TAG, "Error when encrypt.", e);
        }
        return null;
    }

    /**
     * 将加密后的两段byte数组弄到一起进行解密，得到登录态
     *
     * @param partA 密文A
     * @param partB 密文B
     * @return 解密后的登录态
     */
    protected static String decrypt(byte[] partA, byte[] partB) {
        String source = "";
        try{
            String strA = new String(partA);
            String sourceA = CryptHelper.decrypt(strA);
            if(StringUtils.isNotBlank(sourceA)){
                source += sourceA;
            }
            String strB = new String(partB);
            String sourceB = CryptHelper.decrypt(strB);
            if(StringUtils.isNotBlank(sourceB)){
                source += sourceB;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error when decrypt.", e);
        }

        return source;
    }

    /**
     * 用户登录信息的表结构
     */
    public static class Schema implements BaseColumns {
        //  表名
        public final static String TABLE_NAME = "wg_tk";

        //  ID
        public final static String _ID = "wid";

        //  commId
        public final static String COMM_ID = "cid";

        //  用户登录态A
        public final static String TOKEN_A = "tk_file";

        //  用户登录态B
        public final static String TOKEN_B = "wtk";

        //  上次修改时间
        public final static String LAST_MODIFIED = "last_modified";
    }
}
