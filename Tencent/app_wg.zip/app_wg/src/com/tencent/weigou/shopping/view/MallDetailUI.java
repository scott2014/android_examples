package com.tencent.weigou.shopping.view;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.annotation.TargetApi;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Build;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.RelativeSizeSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AlphaAnimation;
import android.view.animation.LinearInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.tencent.weigou.R;
import com.tencent.weigou.base.view.UI;
import com.tencent.weigou.shopping.model.vo.MallDetailVo;
import com.tencent.weigou.shopping.utils.IProgressImgLoaderEvent;
import com.tencent.weigou.shopping.utils.ProgressImgLoader;
import com.tencent.weigou.util.StringUtils;
import com.tencent.weigou.util.Util;

public class MallDetailUI extends UI {

	private static int CAT_MAX_NUM = 8;

	private ProgressImgLoader asyncImageLoader;

	private View outterView;
	private ImageView bgImgView;
	private ImageView subBgImgView;
	private View contentContainer;
	private TextView mallNameView;
    private LinearLayout promotionViewLayout;
	private PromotionSwitcher mallPromotionView;
	private TextView[] catViews = new TextView[CAT_MAX_NUM];
	private TextView subImgView;

	@Override
	public void initView(View outterView) {
		super.initView(outterView);
        if(asyncImageLoader == null) {
            asyncImageLoader = new ProgressImgLoader();
        }

		this.outterView = outterView;
		bgImgView = (ImageView) outterView.findViewById(R.id.bg_img);
		subBgImgView = (ImageView) outterView.findViewById(R.id.sub_bg_img);
		contentContainer = outterView.findViewById(R.id.content_container);
		mallNameView = (TextView) outterView.findViewById(R.id.mall_name);
        promotionViewLayout = (LinearLayout) outterView.findViewById(R.id.mall_promotion_layout);
		mallPromotionView = (PromotionSwitcher) outterView
				.findViewById(R.id.mall_promotion);
		catViews[0] = (TextView) outterView.findViewById(R.id.mall_cat_1_1);
        catViews[1] = (TextView) outterView.findViewById(R.id.mall_cat_1_2);
		catViews[2] = (TextView) outterView.findViewById(R.id.mall_cat_2_1);
		catViews[3] = (TextView) outterView.findViewById(R.id.mall_cat_2_2);
		catViews[4] = (TextView) outterView.findViewById(R.id.mall_cat_3_1);
		catViews[5] = (TextView) outterView.findViewById(R.id.mall_cat_3_2);
		catViews[6] = (TextView) outterView.findViewById(R.id.mall_cat_4_1);
		catViews[7] = (TextView) outterView.findViewById(R.id.mall_cat_4_2);
		subImgView = (TextView) outterView.findViewById(R.id.mall_event_sub);
	}

	public void initClickListener(final OnClickListener l) {
		outterView.findViewById(R.id.mall_back).setOnClickListener(l);
        promotionViewLayout.setOnClickListener(l);
		outterView.findViewById(R.id.mall_new_container).setOnClickListener(l);
		outterView.findViewById(R.id.mall_sale_container).setOnClickListener(l);
		subImgView.setOnClickListener(l);
        outterView.findViewById(R.id.mall_all_brand).setOnClickListener(l);
//		outterView.findViewById(R.id.mall_event_share).setOnClickListener(l);
		outterView.findViewById(R.id.mall_event_page).setOnClickListener(l);
		for (int i = 0; i < CAT_MAX_NUM; i++) {
			catViews[i].setOnClickListener(l);
		}
	}

	/**
	 * delete bg img animation
	 */
	// @TargetApi(Build.VERSION_CODES.HONEYCOMB)
	// public void setOriginalImgView(Bitmap bitmap,
	// AnimatorListener animatorListener) {
	// bgImgView.setImageBitmap(bitmap);
	// subBgImgView.setImageResource(R.drawable.shop_card_sub_bg);
	// if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
	// ObjectAnimator anim1 = ObjectAnimator.ofFloat(bgImgView, "alpha", 0f,
	// 1f);
	// ObjectAnimator anim2 = ObjectAnimator.ofFloat(subBgImgView, "alpha", 0f,
	// 1f);
	// AnimatorSet animation = new AnimatorSet();
	// animation.playTogether(anim1, anim2);
	// animation.setDuration(1000);
	// animation.setInterpolator(new LinearInterpolator());
	// animation.addListener(animatorListener);
	// animation.start();
	// }
	// }
	//
	// public void setOriginalImgView(Bitmap bitmap,
	// AnimationListener animationListener) {
	// bgImgView.setImageBitmap(bitmap);
	// subBgImgView.setImageResource(R.drawable.shop_card_sub_bg);
	// AlphaAnimation anim = new AlphaAnimation(0f, 1f);
	// anim.setDuration(1000);
	// anim.setInterpolator(new LinearInterpolator());
	// anim.setFillAfter(true);
	// anim.setAnimationListener(animationListener);
	// bgImgView.setAnimation(anim);
	// subBgImgView.setAnimation(anim);
	// anim.start();
	// }

	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	public void setOriginalImgView(Bitmap bitmap) {
		bgImgView.setImageBitmap(bitmap);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
			ObjectAnimator anim1 = ObjectAnimator.ofFloat(bgImgView, "alpha",
					0f, 1f);
			ObjectAnimator anim2 = ObjectAnimator.ofFloat(subBgImgView,
					"alpha", 0f, 1f);
			AnimatorSet animation = new AnimatorSet();
			animation.playTogether(anim1, anim2);
			animation.setDuration(1000);
			animation.setInterpolator(new LinearInterpolator());
			animation.start();
		} else {
			AlphaAnimation anim = new AlphaAnimation(0f, 1f);
			anim.setDuration(1000);
			anim.setInterpolator(new LinearInterpolator());
			anim.setFillAfter(true);
			bgImgView.setAnimation(anim);
			subBgImgView.setAnimation(anim);
			anim.start();
		}
	}

	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	public void updateContent(MallDetailVo mallDetailVo) {

		if (mallDetailVo == null) {
			return;
		}

		/**
		 * delete bg img animation
		 */
		final Bitmap drawable = asyncImageLoader.loadDrawable(
				mallDetailVo.bgUrl, bgImgView, new IProgressImgLoaderEvent() {

					@Override
					public void imageLoaded(ImageView imageView, Bitmap bitmap,
							String imageUrl) {
						if (imageView != null && bitmap != null) {
							setOriginalImgView(bitmap);
						}

					}

					@Override
					public void imageLoadedStart(ImageView imageView) {

					}

					@Override
					public void imageLoading(ImageView imageView, float progress) {

					}

					@Override
					public void imageLoadedFailed(ImageView imageView) {

					}
				});
		if (drawable != null) {
			setOriginalImgView(drawable);
		}
		subBgImgView.setImageResource(R.drawable.shop_card_sub_bg);

		// fill data
		mallNameView.setText(mallDetailVo.mallName);
		if (mallDetailVo.promotionList != null
				&& mallDetailVo.promotionList.size() > 0) {
            int length = mallDetailVo.promotionList.size();
            String[] proStrs = new String[length];
            for(int i = 0; i < length; i++) {
                proStrs[i] = mallDetailVo.promotionList.get(i).title;
            }
			updatePromotion(proStrs);
		} else {
            promotionViewLayout.setVisibility(View.GONE);
		}

		if (mallDetailVo.catList != null && mallDetailVo.catList.size() > 0) {
			int length = mallDetailVo.catList.size();
			if (length > CAT_MAX_NUM) {
				length = CAT_MAX_NUM;
			}
			for (int i = 0; i < length; i++) {
				updateCat(mallDetailVo.catList.get(i).catName,
						mallDetailVo.catList.get(i).catId,
						mallDetailVo.catList.get(i).catName, i);
			}
			if (length < CAT_MAX_NUM) {
				for (int i = length; i < CAT_MAX_NUM; i++) {
					catViews[i].setVisibility(View.GONE);
					// test
					// updateCat("测试专用", "", i);
				}
			}
		} else {
			for (int i = 0; i < CAT_MAX_NUM; i++) {
				catViews[i].setVisibility(View.GONE);
			}
		}

		if (mallDetailVo.isSubs) {
            subImgView.setCompoundDrawablesWithIntrinsicBounds(
                    R.drawable.mall_detail_sub, 0, 0, 0);
		} else {
            subImgView.setCompoundDrawablesWithIntrinsicBounds(
                    R.drawable.mall_detail_not_sub, 0, 0, 0);
		}
		subImgView.setTag(mallDetailVo.isSubs);

		contentContainer.setVisibility(View.VISIBLE);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
			ObjectAnimator xAnim = ObjectAnimator.ofFloat(contentContainer,
					"x", contentContainer.getX() + contentContainer.getWidth(),
					contentContainer.getX()).setDuration(500);
			xAnim.setInterpolator(new LinearInterpolator());
			xAnim.start();
		} else {
			TranslateAnimation anim = new TranslateAnimation(600, 0, 0, 0);
			anim.setDuration(500);
			anim.setInterpolator(new LinearInterpolator());
			anim.setFillAfter(true);
			contentContainer.setAnimation(anim);
			anim.start();
		}
	}

	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	public void animateOutterView(final Runnable runnable) {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
			final float y = outterView.getY();
			ObjectAnimator anim1 = ObjectAnimator.ofFloat(outterView, "y", y,
					y - 100);
			ObjectAnimator anim2 = ObjectAnimator.ofFloat(outterView, "alpha",
					1f, 0.5f);
			AnimatorSet animation = new AnimatorSet();
			animation.playTogether(anim1, anim2);
			animation.setTarget(outterView);
			animation.setDuration(500);
			animation.setInterpolator(new LinearInterpolator());
			animation.addListener(new AnimatorListener() {

				@Override
				public void onAnimationStart(Animator animation) {
				}

				@Override
				public void onAnimationRepeat(Animator animation) {
				}

				@Override
				public void onAnimationEnd(Animator animation) {
					ObjectAnimator anim1 = ObjectAnimator.ofFloat(outterView,
							"y", outterView.getY(), outterView.getY() - 50);
					ObjectAnimator anim2 = ObjectAnimator.ofFloat(outterView,
							"alpha", 0.5f, 0.3f);
					AnimatorSet animation2 = new AnimatorSet();
					animation2.playTogether(anim1, anim2);
					animation2.setTarget(outterView);
					animation2.setDuration(200);
					animation2.setInterpolator(new LinearInterpolator());
					animation2.addListener(new AnimatorListener() {

						@Override
						public void onAnimationStart(Animator animation) {
						}

						@Override
						public void onAnimationRepeat(Animator animation) {
						}

						@Override
						public void onAnimationEnd(Animator animation) {
							outterView.setY(y);
							outterView.setAlpha(1f);
						}

						@Override
						public void onAnimationCancel(Animator animation) {
						}
					});
					animation2.start();
					runnable.run();
				}

				@Override
				public void onAnimationCancel(Animator animation) {
				}
			});
			animation.start();
		}
	}

	private void updatePromotion(String[] proStrs) {
		if (proStrs == null || proStrs.length == 0) {
            promotionViewLayout.setVisibility(View.GONE);
		} else {
//            int length = proStrs.length;
//            String[] proStrs = new String[length];
//            for(int i = 0; i < length; i++) {
//                proStrs[i] = mallDetailVo.promotionList.get(i).title;
//            }
//			Spannable textSpan = new SpannableString("活动  |  " + str);
//			textSpan.setSpan(new RelativeSizeSpan(32f / 26f), 0, 7,
//					Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
//			mallPromotionView.setText(textSpan);
            mallPromotionView.setTexts(proStrs);
		}
	}

	private void updateCat(String str, String id, String name, int num) {
		if (StringUtils.isBlank(str) && StringUtils.isBlank(id)) {
			catViews[num].setVisibility(View.GONE);
		} else {
			// Spannable textSpan = new SpannableString((num + 1) + "  " + str);
			// textSpan.setSpan(new RelativeSizeSpan(36f / 26f), 0, 3,
			// Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
			catViews[num].setText((num + 1) + " " + str);
			if (!StringUtils.isBlank(id)) {
				catViews[num].setTag(R.id.tag_cat_id, id);
				catViews[num].setTag(R.id.tag_cat_name, name);
			}
		}
	}

	public void startSub() {
		Object tag = subImgView.getTag();
		if (tag != null && tag instanceof Boolean) {
			boolean tmpIsSub = !(Boolean) tag;
			if (tmpIsSub) {
                subImgView.setCompoundDrawablesWithIntrinsicBounds(
                        R.drawable.mall_detail_sub, 0, 0, 0);
			} else {
				subImgView.setCompoundDrawablesWithIntrinsicBounds(
                        R.drawable.mall_detail_not_sub, 0, 0, 0);
			}
		}
	}

	public void doneSub() {
		Object tag = subImgView.getTag();
		if (tag != null && tag instanceof Boolean) {
			boolean newIsSub = !(Boolean) tag;
			subImgView.setTag(newIsSub);
			// if(NewIsSub) {
			// showToast("关注成功", R.drawable.mall_detail_sub_success);
			// }
			// else {
			// showToast("取消关注成功", R.drawable.mall_detail_sub_fail);
			// }
		}
	}

	public void failSub() {
		Object tag = subImgView.getTag();
		if (tag != null && tag instanceof Boolean) {
			boolean isSub = (Boolean) tag;
			if (isSub) {
                subImgView.setCompoundDrawablesWithIntrinsicBounds(
                        R.drawable.mall_detail_sub, 0, 0, 0);
				showToast("取消关注失败", R.drawable.mall_detail_sub_fail);
			} else {
                subImgView.setCompoundDrawablesWithIntrinsicBounds(
                        R.drawable.mall_detail_not_sub, 0, 0, 0);
				showToast("关注失败", R.drawable.mall_detail_sub_fail);
			}
		}
	}

    public void reQuerySub(boolean isSub) {
        Object tag = subImgView.getTag();
        if (tag != null && tag instanceof Boolean && (Boolean)tag != isSub) {
            subImgView.setTag(isSub);
            if (isSub) {
                subImgView.setCompoundDrawablesWithIntrinsicBounds(
                        R.drawable.mall_detail_sub, 0, 0, 0);
            } else {
                subImgView.setCompoundDrawablesWithIntrinsicBounds(
                        R.drawable.mall_detail_not_sub, 0, 0, 0);
            }
        }
    }

	private void showToast(String text, int resId) {
		TextView tv = new TextView(context);
		tv.setBackgroundResource(R.drawable.text_corner_round_normal);
		int padding = Util.dip2px(subImgView.getContext(), 20);
		tv.setPadding(padding, padding, padding, padding);
		tv.setText(text);
		tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
		tv.setTextColor(Color.parseColor("#5c2582"));
		tv.setCompoundDrawablesWithIntrinsicBounds(0, resId, 0, 0);
		tv.setGravity(Gravity.CENTER);
		Toast toast = new Toast(context);
		toast.setGravity(Gravity.CENTER, 0, 0);
		toast.setDuration(Toast.LENGTH_SHORT);
		toast.setView(tv);
		toast.show();
	}

    public ProgressImgLoader getProgressImgLoader() {
        if(asyncImageLoader == null) {
            asyncImageLoader = new ProgressImgLoader();
        }
        return asyncImageLoader;
    }

}