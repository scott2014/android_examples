package com.tencent.weigou.shopping.model;

import com.tencent.weigou.base.model.Model;
import com.tencent.weigou.shopping.model.vo.MallDiscountsVo;

/**
 * 获取折扣品牌数据
 * User: ethonchan
 * Date: 13-12-4
 * Time: 上午11:30
 */
public class MallDiscountsModel extends Model{

    public final static int GET_MALL_DISCOUNTS = 0;

    private MallDiscountsVo discountsVo;

    @Override
    public void initData(String url) {
        //  获取数据
        discountsVo = new MallDiscountsVo();
        createNetWorkTask(url, discountsVo, GET_MALL_DISCOUNTS);
    }

    public MallDiscountsVo getDiscountsVo() {
        return discountsVo;
    }
}
