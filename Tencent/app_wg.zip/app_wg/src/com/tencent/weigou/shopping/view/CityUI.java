package com.tencent.weigou.shopping.view;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.tencent.weigou.R;
import com.tencent.weigou.base.model.vo.CommonVo;
import com.tencent.weigou.base.view.UI;
import com.tencent.weigou.shopping.activity.CityActivity;
import com.tencent.weigou.shopping.model.vo.CityVo;
import com.tencent.weigou.shopping.model.vo.CityVo.CityItemVo;

public class CityUI extends UI {

	public void updateContent(CommonVo rv) {
		LinearLayout shoppingCity = (LinearLayout) outterView
				.findViewById(R.id.shopping_city_ll);
		CityVo cv = (CityVo) rv;
		List<CityItemVo> civs = cv.list;

		for (CityItemVo civ : civs) {
			RelativeLayout item = null;
			item = (RelativeLayout) LayoutInflater.from(context).inflate(
					R.layout.shopping_city_item_pa, null);
			item.setOnClickListener((CityActivity) context);
			item.setTag(civ);
			((TextView) item.findViewById(R.id.shopping_city_name))
					.setText(civ.name);
			if (civ.selected) {
				item.findViewById(R.id.shopping_city_mask).setVisibility(
						View.GONE);
			} else {
				item.findViewById(R.id.shopping_city_mask).setVisibility(
						View.VISIBLE);
			}
			if (!civ.enable) {
				// item.findViewById(R.id.shopping_city_location).setVisibility(
				// View.GONE);
				((TextView) item.findViewById(R.id.shopping_city_desc))
						.setText("即将开启");
			} else {
				// item.findViewById(R.id.shopping_city_location).setVisibility(
				// View.VISIBLE);
				((TextView) item.findViewById(R.id.shopping_city_desc))
						.setText("推荐城市");
			}
			ImageView cityImg = (ImageView) item
					.findViewById(R.id.shopping_city_img);
			setImage(civ.url, cityImg);
			shoppingCity.addView(item);
		}
	}

	private void setImage(String url, ImageView imageView) {
		if (url.startsWith("http")) {
			// loadImage(url, imageView);
		} else {
			Bitmap bitmap = null;
			InputStream is = null;
			try {
				is = context.getAssets().open(url);
				bitmap = BitmapFactory.decodeStream(is);
				imageView.setImageBitmap(bitmap);
			} catch (OutOfMemoryError e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				if (is != null) {
					try {
						is.close();
					} catch (IOException e) {
						is = null;
					}
				}
				if (bitmap != null && bitmap.isRecycled()) {
					bitmap.recycle();
				}
			}
		}
	}

}
