package com.tencent.weigou.shopping.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextSwitcher;
import android.widget.Toast;
import android.widget.ViewSwitcher;

import com.tencent.weigou.R;
import com.tencent.weigou.base.App;
import com.tencent.weigou.base.TypeVo;
import com.tencent.weigou.base.activity.BaseActivity;
import com.tencent.weigou.page.activity.MallPageActivity;
import com.tencent.weigou.shopping.fragment.BrandWallFragment;
import com.tencent.weigou.shopping.fragment.PromotionFragment;
import com.tencent.weigou.shopping.fragment.PromotionFragment.FragmentBridge;
import com.tencent.weigou.shopping.model.MallDetailModel;
import com.tencent.weigou.shopping.model.vo.BrandWallVo;
import com.tencent.weigou.shopping.utils.ProgressImgLoader;
import com.tencent.weigou.shopping.view.MallDetailUI;
import com.tencent.weigou.util.Constants;
import com.tencent.weigou.util.ConstantsActivity;
import com.tencent.weigou.util.ConstantsUrl;
import com.tencent.weigou.util.ImageUtils;
import com.tencent.weigou.util.PageIds.OprIndex;
import com.tencent.weigou.util.StringUtils;
import com.tencent.weigou.wxapi.WXUtils;

public class MallDetailActivity extends BaseActivity implements OnClickListener,
		PromotionFragment.FragmentBridge, BrandWallFragment.FragmentBridge {

	private MallDetailModel model;
	private MallDetailUI ui;

	private String mallId = "";

	/**
	 * delete bg img animation
	 */
	// private Handler handler = new Handler(new Handler.Callback() {
	//
	// @TargetApi(Build.VERSION_CODES.HONEYCOMB)
	// @Override
	// public boolean handleMessage(Message msg) {
	// switch (msg.what) {
	// case 0:
	// if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
	// ui.setOriginalImgView((Bitmap)msg.obj, new AnimatorListener() {
	//
	// @Override
	// public void onAnimationStart(Animator animation) {
	// }
	//
	// @Override
	// public void onAnimationRepeat(Animator animation) {
	// }
	//
	// @Override
	// public void onAnimationEnd(Animator animation) {
	// model.countDown();
	// }
	//
	// @Override
	// public void onAnimationCancel(Animator animation) {
	// }
	// });
	// }
	// else {
	// ui.setOriginalImgView((Bitmap)msg.obj, new AnimationListener() {
	//
	// @Override
	// public void onAnimationStart(Animation animation) {
	// }
	//
	// @Override
	// public void onAnimationEnd(Animation animation) {
	// model.countDown();
	// }
	//
	// @Override
	// public void onAnimationRepeat(Animation animation) {
	// }
	//
	// });
	// }
	//
	// break;
	// default:
	// break;
	// }
	// return false;
	// }
	// });

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		ui = new MallDetailUI();
		model = new MallDetailModel();
		super.onCreate(savedInstanceState);

		initMVC(model, ui, R.layout.mall_detail_layout);
		init();
	}

	private void init() {
		Intent intent = getIntent();
		mallId = intent.getStringExtra(ConstantsActivity.INTENT_MALL_DETAIL_ID);
		// test
		// mallId = "6";


		ui.initClickListener(this);

		String userUrl = App.getInstance().getEnv().getServerUrl()
				+ ConstantsUrl.URL_MALL_DETAIL_MALL;
		StringBuilder sb = new StringBuilder(appendPageInfo(userUrl,
				OprIndex.PV_OPR));
		sb = sb.append("&mid=").append(mallId);
		String url = sb.toString();

		/**
		 * delete bg img animation handler = null
		 */
		model.initContext(this, null);
		model.initData(url);

	}

    private void querySub() {
        String userUrl = App.getInstance().getEnv().getServerUrl() + ConstantsUrl.URL_QUERY_SUB;
        StringBuilder sb = new StringBuilder(appendPageInfo(userUrl, OprIndex.NON_PV_OPR));
        sb = sb.append("&tp=2&pid=").append(mallId);
        String url = sb.toString();

        model.querySub(url);
    }

	@Override
	public void update(int notificationId) {
		super.update(notificationId);
		switch (notificationId) {
		case MallDetailModel.MALL_DETAIL_PAGE_START:
			break;
		case MallDetailModel.MALL_DETAIL_PAGE_DONE:
			ui.updateContent(model.getMallDetailVo());
			break;
		case MallDetailModel.MALL_DETAIL_PAGE_FAILURE:
			break;
		case MallDetailModel.MALL_DETAIL_SUBSCRIBE_START:
			ui.startSub();
			break;
		case MallDetailModel.MALL_DETAIL_SUBSCRIBE_DONE:
            ui.doneSub();
			break;
		case MallDetailModel.MALL_DETAIL_SUBSCRIBE_FAILURE:
			ui.failSub();
			break;
        case MallDetailModel.MALL_DETAIL_BRAND_DONE:
            BrandWallFragment f = (BrandWallFragment) getSupportFragmentManager().findFragmentByTag("BrandWallFragment");
            if(f != null) {
                f.setBrandWallVo(model.getBrandWallVo());
            }
            break;
        case MallDetailModel.MALL_DETAIL_BRAND_FAILURE:
            break;
		}
	}

    @Override
    public void update(Bundle bundle) {
        super.update(bundle);
        int notificationId = bundle.getInt("notificationId");
        switch (notificationId) {
        case MallDetailModel.MALL_DETAIL_QUERY_SUB_DONE:
            boolean isSub = bundle.getBoolean("isSub");
            ui.reQuerySub(isSub);
            break;
        }
    }

	@Override
	public void onClick(View view) {
		switch (view.getId()) {
		case R.id.mall_back:
			onBackPressed();
			break;
		case R.id.mall_promotion_layout:
        {
			PromotionFragment fragment = new PromotionFragment();
			fragment.setPromotionList(model.getMallDetailVo().promotionList);

			// Add the fragment to the activity, pushing this transaction
			// on to the back stack.
			FragmentTransaction ft = getSupportFragmentManager()
					.beginTransaction();
			ft.add(R.id.outter_view, fragment);
			ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
			ft.addToBackStack(null);
			ft.commit();
        }
			break;
		case R.id.mall_new_container:
			Intent intentNew = new Intent();
			intentNew.setClass(this, MallNewActivity.class);
			intentNew.putExtra(ConstantsActivity.INTENT_MALL_DETAIL_ID, mallId);
			startActivity(intentNew);
			break;
		case R.id.mall_sale_container:
			Intent intentSale = new Intent();
			intentSale.setClass(this, MallDiscountsActivity.class);
			intentSale
					.putExtra(ConstantsActivity.INTENT_MALL_DETAIL_ID, mallId);
			startActivity(intentSale);
			break;
		case R.id.mall_cat_1_1:
		case R.id.mall_cat_1_2:
		case R.id.mall_cat_2_1:
		case R.id.mall_cat_2_2:
		case R.id.mall_cat_3_1:
		case R.id.mall_cat_3_2:
		case R.id.mall_cat_4_1:
		case R.id.mall_cat_4_2:
			Object catTag = view.getTag(R.id.tag_cat_id);
			if (catTag != null && catTag instanceof String) {
				String catId = (String) catTag;
				final Intent intentShop = new Intent();
				intentShop.setClass(this, ShopPagerActivity.class);
				intentShop.putExtra(ConstantsActivity.INTENT_MALL_DETAIL_ID,
						mallId);
				intentShop
						.putExtra(ConstantsActivity.INTENT_MALL_CAT_ID, catId);
				intentShop.putExtra(ConstantsActivity.INTENT_MALL_CAT_NAME,
						(String) view.getTag(R.id.tag_cat_name));

				// ui.animateOutterView(new Runnable() {
				//
				// @Override
				// public void run() {
				//
				// startActivity(intentShop);
				// }
				//
				// });
				startActivity(intentShop);

			}
			break;
        case R.id.mall_all_brand:
        {
                BrandWallFragment fragment = new BrandWallFragment();

                // Add the fragment to the activity, pushing this transaction
                // on to the back stack.
                FragmentTransaction ft = getSupportFragmentManager()
                        .beginTransaction();
                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
                ft.setCustomAnimations(R.anim.in_from_down, R.anim.out_to_down, R.anim.in_from_down, R.anim.out_to_down);
                ft.add(R.id.outter_view, fragment, "BrandWallFragment");
                ft.addToBackStack(null);
                ft.commit();
        }
                break;
		case R.id.mall_event_sub:
			Object subTag = view.getTag();
			if (subTag != null && subTag instanceof Boolean) {
				boolean isSub = (Boolean) subTag;
				String userUrl = App.getInstance().getEnv().getServerUrl()
						+ (isSub ? ConstantsUrl.URL_REMOVE_SUBSCRIBE
								: ConstantsUrl.URL_ADD_SUBSCRIBE);
				StringBuilder sb = new StringBuilder(appendPageInfo(userUrl,
						OprIndex.USER_OPR));
				sb = sb.append("&tp=2&pid=").append(mallId);
				String url = sb.toString();
				model.changeSubscribeRel(url);
			}
			break;
//		case R.id.mall_event_share:
//			if (model.getMallDetailVo() != null) {
//				shareToWX();
//			}
//			break;
		case R.id.mall_event_page:
			Intent intentPage = new Intent();
			intentPage.setClass(this, MallPageActivity.class);
			intentPage.putExtra(ConstantsActivity.INTENT_MALL_ID, mallId);
			startActivityForResult(intentPage, ConstantsActivity.MALL_DETAIL_REQ_SUB);
			break;
		}

	}

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode == RESULT_OK) {
            switch (requestCode) {
                case ConstantsActivity.MALL_DETAIL_REQ_SUB:
                    querySub();
                    break;
                default:
                    break;
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

//	@Override
//	protected void onShare2WechatFriends() {
//		Bitmap bitmap = ImageUtils
//				.getBitmapFromLocal(model.getMallDetailVo().bgUrl);
//		if (bitmap == null)
//		// 如果没有图片的话就用APP图标来替代
//		{
//			bitmap = BitmapFactory.decodeResource(getResources(),
//					R.drawable.ic_launcher);
//		}
//		String title = model.getMallDetailVo().mallName + "挺不错的，一起去逛逛吧。";
//		String desc = "优惠促销活动中";
//		boolean shareSuccess = WXUtils.shareWebpageToFriends(this, title, desc,
//				bitmap,
//				"http://act.m.buy.qq.com/t/showAct.xhtml?tid=share_back_test");
//		if (!shareSuccess) {
//			Toast.makeText(this, "分享失败", Constants.TOAST_NORMAL_LONG).show();
//		}
//	}
//
//	@Override
//	protected void onShare2WechatTimeline() {
//		Bitmap bitmap = ImageUtils
//				.getBitmapFromLocal(model.getMallDetailVo().bgUrl);
//		if (bitmap == null)
//		// 如果没有图片的话就用APP图标来替代
//		{
//			bitmap = BitmapFactory.decodeResource(getResources(),
//					R.drawable.ic_launcher);
//		}
//		String title = model.getMallDetailVo().mallName + "挺不错的，一起去逛逛吧。";
//		String desc = "优惠促销活动中";
//		boolean shareSuccess = WXUtils.shareWebpageToTimeline(this, title,
//				desc, bitmap,
//				"http://act.m.buy.qq.com/t/showAct.xhtml?tid=share_back_test");
//		if (!shareSuccess) {
//			Toast.makeText(this, "分享失败", Constants.TOAST_NORMAL_LONG).show();
//		}
//	}

	@Override
	public void closeFragment() {
		onBackPressed();

	}

    @Override
    public BrandWallVo getBrandWallData(){
        return model.getBrandWallVo();
    }

    @Override
    public void startLoadingWall(Object lock, BrandWallFragment.IsAnimEnd isAnimEndObj){
        String userUrl = App.getInstance().getEnv().getServerUrl() + ConstantsUrl.URL_MALL_BRAND_WALL;
        StringBuilder sb = new StringBuilder(appendPageInfo(userUrl, OprIndex.USER_OPR));
        sb = sb.append("&mid=").append(mallId);
        String url = sb.toString();

        model.loadBrandWall(url, lock, isAnimEndObj);
    }

    @Override
    public ProgressImgLoader getProgressImgLoader(){
        return ui.getProgressImgLoader();
    }

    @Override
    public void startNextActivity(Intent intent){
        startActivity(intent);
    }

}
