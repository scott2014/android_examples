package com.tencent.weigou.shopping.activity;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

import com.tencent.weigou.R;
import com.tencent.weigou.base.App;
import com.tencent.weigou.base.activity.TitleBarActivity;
import com.tencent.weigou.shopping.model.CmdyModel;
import com.tencent.weigou.shopping.view.CmdyUI;
import com.tencent.weigou.util.ConstantsActivity;
import com.tencent.weigou.util.ConstantsUrl;
import com.tencent.weigou.util.PageIds.OprIndex;
import com.tencent.weigou.util.StringUtils;

public class ShoppingCmdyActivity extends TitleBarActivity {

	private CmdyModel model = new CmdyModel();
	private CmdyUI ui = new CmdyUI();

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// 初始化mvc框架
		initMVC(model, ui, R.layout.shopping_cmdy);
		initTopBar();
		init();
	}

	private void initTopBar() {
		topbar.setVisibility(View.GONE);
		findViewById(R.id.back_btn_new).setOnClickListener(
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						onBackPressed();
					}
				});

	}

	private void init() {
		StringBuffer sb = new StringBuffer(App.getInstance().getEnv()
				.getServerUrl());

		String itId = getIntent().getStringExtra(
				ConstantsActivity.INTENT_CMDY_ID);
		if (StringUtils.isBlank(itId)) {
			itId = "1";
		}

		// if ((ConstantsActivity.MALL_DETAIL_TYPE_MALL + "").equals(type)) {
		// sb.append(ConstantsUrl.SHOPPING_MALL_NAV + "?mid=").append(id);
		// }
		sb.append(ConstantsUrl.SHOPPING_CMD_DETAIL).append("?itId=")
				.append(itId);
		String url = sb.toString();
		url = appendPageInfo(url, OprIndex.PV_OPR);
		model.initData(url);
	}

	@Override
	public void update(int notificationId) {
		super.update(notificationId);
		switch (notificationId) {
		case CmdyModel.INIT_DATA:
			ui.updateContent(model.cmdyVo);
			break;
		}
	}

}
