package com.tencent.weigou.shopping.model.vo;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.tencent.weigou.base.model.vo.CommonVo;

public class NavVo extends CommonVo {
	public List<NavItemVo> list = new ArrayList<NavItemVo>();

	public boolean parse(JSONObject jo) {

		try {
			JSONArray jsonArray = jo.getJSONArray("list");
			for (int i = 0; i < jsonArray.length(); i++) {
				NavItemVo niv = new NavItemVo();
				niv.name = jsonArray.getJSONObject(i).optString("brandName");
				niv.logo = jsonArray.getJSONObject(i).optString("brandLogo");
				niv.brandId = jsonArray.getJSONObject(i).optString("brandId");
				niv.bg = jsonArray.getJSONObject(i).optString("landscapePic");
				niv.id = jsonArray.getJSONObject(i).optString("id");
				list.add(niv);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return true;
	}

	public class NavItemVo {
		public String id;
		public String name;
		public String bg;
		public String logo;
		public String catId;
		public String brandId;
	}
}
