package com.tencent.weigou.shopping.view;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import com.tencent.weigou.R;
import com.tencent.weigou.base.view.UI;

/**
 * 逛-商场-折扣品牌对应的UI
 * User: ethonchan
 * Date: 13-12-4
 * Time: 上午11:31
 */
public class MallDiscountsUI extends UI{

    private ListView mListView;

    @Override
    public void initView(View outterView) {
        super.initView(outterView);

        mListView = (ListView) outterView.findViewById(R.id.listview);
    }

    /**
     * 添加列表展示内容
     * @param adapter
     */
    public void setListAdapter(ListAdapter adapter){
        if(mListView != null){
            mListView.setAdapter(adapter);
        }
    }

    /**
     * 添加点击事件监听器
     * @param listener
     */
    public void setOnItemClickListener(AdapterView.OnItemClickListener listener){
        if(mListView != null){
            mListView.setOnItemClickListener(listener);
        }
    }
}
