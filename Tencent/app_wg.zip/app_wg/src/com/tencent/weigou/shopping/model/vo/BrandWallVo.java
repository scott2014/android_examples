package com.tencent.weigou.shopping.model.vo;

import com.tencent.weigou.base.model.vo.CommonVo;
import com.tencent.weigou.util.StringUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by branjing on 14-1-6.
 */
public class BrandWallVo extends CommonVo {

    public List<BrandRow> brandwall;

    /**
     * called by bg Thread
     */
    @Override
    public boolean parse(JSONObject jo) {
        if(jo != null) {
            JSONArray catArray = jo.optJSONArray("list");
            if(catArray == null || catArray.length() == 0) {
                return false;
            }
            brandwall = new ArrayList<BrandRow>();
            int length = catArray.length();
            for(int i = 0; i < length; i++) {
                JSONObject catTotalObj = catArray.optJSONObject(i);
                if(catTotalObj == null) {
                    return false;
                }

                //cat
                JSONObject catObj = catTotalObj.optJSONObject("category");
                if(catObj == null) {
                    continue;
                }
                String catId = catObj.optString("id", "").trim();
                String catName = catObj.optString("name", "").trim();
                if(StringUtils.isEmpty(catId)) {
                    continue;
                }
                else {
                    BrandRow brandRow = new BrandRow();
                    brandRow.catName = catName;
                    brandwall.add(brandRow);
                }

                //3 brands
                JSONArray shopArray = catTotalObj.optJSONArray("shops");
                if(shopArray == null || shopArray.length() == 0) {
                    continue;
                }
                int shopLength = shopArray.length();
                int shopRowLength = shopLength / 3 + (shopLength % 3 > 0 ? 1 : 0);
                for(int j = 0; j < shopRowLength; j++) {
                    BrandRow brandRow = new BrandRow();
                    brandRow.brandRowList = new ArrayList<BrandItem>(3);
                    if(j * 3 < shopLength ) {
                        JSONObject shopObj = shopArray.optJSONObject(j * 3);
                        BrandItem brandItem = new BrandItem();
                        brandItem.catId = catId;
                        brandItem.brandId = shopObj.optString("brandId", "").trim();
                        brandItem.brandName = shopObj.optString("brandName", "").trim();
                        brandItem.brandUrl = shopObj.optString("brandLogo", "").trim();
                        brandItem.shopId = shopObj.optString("id", "").trim();
                        brandItem.shopName = shopObj.optString("name", "").trim();
                        brandRow.brandRowList.add(brandItem);
                    }
                    if(j * 3 + 1 < shopLength) {
                        JSONObject shopObj = shopArray.optJSONObject(j * 3 + 1);
                        BrandItem brandItem = new BrandItem();
                        brandItem.catId = catId;
                        brandItem.brandId = shopObj.optString("brandId", "").trim();
                        brandItem.brandName = shopObj.optString("brandName", "").trim();
                        brandItem.brandUrl = shopObj.optString("brandLogo", "").trim();
                        brandItem.shopId = shopObj.optString("id", "").trim();
                        brandItem.shopName = shopObj.optString("name", "").trim();
                        brandRow.brandRowList.add(brandItem);
                    }
                    if(j * 3 + 2 < shopLength) {
                        JSONObject shopObj = shopArray.optJSONObject(j * 3 + 2);
                        BrandItem brandItem = new BrandItem();
                        brandItem.catId = catId;
                        brandItem.brandId = shopObj.optString("brandId", "").trim();
                        brandItem.brandName = shopObj.optString("brandName", "").trim();
                        brandItem.brandUrl = shopObj.optString("brandLogo", "").trim();
                        brandItem.shopId = shopObj.optString("id", "").trim();
                        brandItem.shopName = shopObj.optString("name", "").trim();
                        brandRow.brandRowList.add(brandItem);
                    }
                    brandwall.add(brandRow);
                }
            }
            return true;
        }

        return false;
    }

    public static class BrandRow {
        public List<BrandItem> brandRowList;
        public String catName;
    }

    public static class BrandItem {
        public String brandUrl;
        public String catId;
        public String brandId;
        public String brandName;
        public String shopId;
        public String shopName;
    }
}
