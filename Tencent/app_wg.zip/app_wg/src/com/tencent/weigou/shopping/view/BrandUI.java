package com.tencent.weigou.shopping.view;

import java.util.ArrayList;
import java.util.List;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import com.tencent.weigou.R;
import com.tencent.weigou.base.model.vo.CommonVo;
import com.tencent.weigou.base.view.UI;
import com.tencent.weigou.common.ui.AdaptiveImageView;
import com.tencent.weigou.shopping.activity.BrandListActivity;
import com.tencent.weigou.shopping.model.vo.BrandListVo;
import com.tencent.weigou.shopping.model.vo.BrandListVo.BrandVo;

public class BrandUI extends UI {
	GridView navGv;
	NavGridAdapter adapter;

	@Override
	public void initView(View outterView) {
		super.initView(outterView);
		navGv = (GridView) findViewById(R.id.nav_grid_view);
		adapter = new NavGridAdapter();
		navGv.setAdapter(adapter);
		navGv.setOnItemClickListener((BrandListActivity) context);
		navGv.setSelector(new ColorDrawable(Color.TRANSPARENT));
	}

	public void updateContent(CommonVo rv) {
		if (rv instanceof BrandListVo) {
			adapter.setData(((BrandListVo) rv).list);
			adapter.notifyDataSetChanged();
		}
	}

	public class NavGridAdapter extends BaseAdapter {
		private List<BrandVo> items = new ArrayList<BrandVo>();

		public void setData(List<BrandVo> items) {
			this.items = items;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return items.size();
		}

		@Override
		public Object getItem(int position) {
			return items.get(position);
		}

		@Override
		public long getItemId(int position) {
			return 0;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			BrandViewHolder holder;
			if (convertView == null) {
				convertView = LayoutInflater.from(context).inflate(
						R.layout.shopping_nav_shop_item, null);
				holder = new BrandViewHolder();
				holder.bgIV = (AdaptiveImageView) convertView
						.findViewById(R.id.shopping_nav_item_bg);
				holder.logoIV = (ImageView) convertView
						.findViewById(R.id.shopping_nav_item_logo);
				holder.nameTV = (TextView) convertView
						.findViewById(R.id.shopping_nav_item_name);
				convertView.setTag(holder);
			} else {
				holder = (BrandViewHolder) convertView.getTag();
			}
			BrandVo niVo = items.get(position);
			imageLoader.displayImage(niVo.bg,holder.bgIV , options,
					animateFirstListener);
			imageLoader.displayImage(niVo.logo,holder.logoIV , options,
					animateFirstListener);
//			asyncLoadImage(holder.bgIV, niVo.bg, 0, 0, R.drawable.loading_big,
//					true, false);
			// asyncLoadImage(holder.logoIV, niVo.logo, 0, 0,
			// R.drawable.loading_big, true, false);
			holder.nameTV.setText(niVo.name);
			return convertView;
		}
	}

	static class BrandViewHolder {
		ImageView logoIV;
		AdaptiveImageView bgIV;
		TextView nameTV;
	}
}
