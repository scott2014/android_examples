package com.tencent.weigou.shopping.activity;

import java.util.Observable;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

import com.tencent.weigou.R;
import com.tencent.weigou.base.activity.TitleBarActivity;
import com.tencent.weigou.shopping.model.CityModel;
import com.tencent.weigou.shopping.model.vo.CityVo;
import com.tencent.weigou.shopping.model.vo.CityVo.CityItemVo;
import com.tencent.weigou.shopping.view.CityUI;
import com.tencent.weigou.util.Constants;
import com.tencent.weigou.util.ConstantsActivity;

public class CityActivity extends TitleBarActivity implements OnClickListener {
	// 返回的CITY_ID, String类型
	public final static String RESULT_CITY_ID = "result_city_id_as_string";

	// 返回的CITY_NAME, String类型
	public final static String RESULT_CITY_NAME = "result_city_name";

	private String intentSource = "";
	CityUI ui = new CityUI();
	CityModel model = new CityModel();

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		init();

		String cityName = getIntent().getExtras().getString(
				ConstantsActivity.REGION_CITY_NAME);
		model.initData(cityName);
	}

	private void init() {
		initMVC(model, ui, R.layout.shopping_city_pa);
		topbar.setVisibility(View.GONE);
		findViewById(R.id.back_btn_new).setOnClickListener(
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						onBackPressed();
					}
				});
	}

	@Override
	public void update(Observable obserable, Object data) {
		super.update(obserable, data);
		if (data instanceof CityVo) {
			CityVo cv = (CityVo) data;
			ui.updateContent(cv);

		}
	}

	@Override
	public void onClick(View v) {
		CityItemVo civ = (CityItemVo) v.getTag();
		if (!civ.enable) {
			Toast.makeText(this, "即将开启,敬请期待", Constants.TOAST_NORMAL_LONG)
					.show();
		} else {
			finish();

		}

	}

	@Override
	public void finish() {
		super.finish();
		overridePendingTransition(0, R.anim.out_to_down);
	}

}
