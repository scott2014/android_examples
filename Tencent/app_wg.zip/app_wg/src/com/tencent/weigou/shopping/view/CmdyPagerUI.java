package com.tencent.weigou.shopping.view;

import java.lang.ref.SoftReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.ObjectAnimator;
import android.annotation.TargetApi;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.text.Html;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.view.animation.BounceInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.process.BitmapProcessor;
import com.tencent.weigou.R;
import com.tencent.weigou.base.model.vo.CommonVo;
import com.tencent.weigou.base.view.UI;
import com.tencent.weigou.common.ui.TopToolBar;
import com.tencent.weigou.common.ui.zoom.HackyViewPager;
import com.tencent.weigou.common.ui.zoom.PhotoView;
import com.tencent.weigou.common.ui.zoom.PhotoViewAttacher.OnPhotoTapListener;
import com.tencent.weigou.shopping.activity.ShoppingCmdyPagerActivity;
import com.tencent.weigou.shopping.model.vo.CmdyVo;
import com.tencent.weigou.shopping.model.vo.CmdyVo.CmdyItemVo;
import com.tencent.weigou.util.ConstantsActivity;
import com.tencent.weigou.util.ImageScaleUtils;
import com.tencent.weigou.util.Util;
import com.tencent.weigou.wxapi.WXUtils;

public class CmdyPagerUI extends UI implements OnPhotoTapListener,
		OnTouchListener {
	HackyViewPager viewPage;
	TopToolBar topBar;
	RelativeLayout operatorBar;
	LinearLayout operatorRightBar;
	TextView titleTv;
	TextView priceTv;
	CmdyPagerAdapter adapter;
	private int picWidth;
	private int picHeight;
	private boolean show = true;
	TextView addCartTv;
	TextView titlePop;
	TextView arrow;
	TextView subTitlePop;
	OnPageListener onPageListener;
	CmdyVo cv;
	boolean catPop = false;
	LinearLayout catListLL;
	List<TextView> catList = new ArrayList<TextView>();
	// PhotoView photoView;
	TextView morePicBtn;
	TextView moreBtn;
	TextView onLineBtn;
	PopupWindow morePopup = null;
	PopupWindow onlinePopup = null;
	LinearLayout cmdyTel;
	LinearLayout cmdyQQ;
	LinearLayout cmdyShareCircle;
	LinearLayout cmdyShareFriend;
	CmdyItemVo currItemVo;
	TextView onlineBuy;
	ImageView arrowView;

	@Override
	public void initView(View outterView) {

		super.initView(outterView);
		viewPage = (HackyViewPager) findViewById(R.id.shopping_cmdy_pic_viewpager);
		adapter = new CmdyPagerAdapter();
		viewPage.setAdapter(adapter);
		topBar = (TopToolBar) findViewById(R.id.top_bar);
		operatorBar = (RelativeLayout) findViewById(R.id.shopping_cmdy_operator);
		operatorRightBar = (LinearLayout) findViewById(R.id.shopping_cmdy_operator_right);
		titleTv = (TextView) findViewById(R.id.shopping_cmdy_title);
		priceTv = (TextView) findViewById(R.id.shopping_cmdy_price);
		picWidth = Util.getScreenWidth(((Activity) context).getWindowManager());
		picHeight = Util.getScreenContentHeight(context);
		addCartTv = (TextView) findViewById(R.id.cmdy_buy_tv);
		onLineBtn = (TextView) findViewById(R.id.cmdy_online_tv);
		titlePop = (TextView) topBar.findViewById(R.id.top_bar_title);
		subTitlePop = (TextView) topBar.findViewById(R.id.top_bar_subtitle);
		addCartTv.setOnClickListener((ShoppingCmdyPagerActivity) context);
		morePicBtn = (TextView) findViewById(R.id.cmdy_more_pic_tv);
		morePicBtn.setOnClickListener((ShoppingCmdyPagerActivity) context);
		moreBtn = (TextView) findViewById(R.id.cmdy_more_tv);
		moreBtn.setOnClickListener((ShoppingCmdyPagerActivity) context);
		arrowView = (ImageView) outterView.findViewById(R.id.arrow_right);
		// findViewById(R.id.cmdy_talk_tv).setOnClickListener(
		// (ShoppingCmdyPagerActivity) context);
		setPageListener((ShoppingCmdyPagerActivity) context);
		onLineBtn.setOnClickListener((ShoppingCmdyPagerActivity) context);
		viewPage.setOnPageChangeListener(new OnPageChangeListener() {

			@Override
			public void onPageSelected(int position) {
				CmdyItemVo civ = adapter.getCmdyList().get(position);
				addCartTv.setTag(civ);
				titleTv.setText(civ.name);
				titleTv.setTag(civ.id);
				priceTv.setText(civ.price);
				morePicBtn.setTag(civ);
				currItemVo = civ;
				// imageLoader.displayImage(civ.bg, cmdyIv, options,
				// animateFirstListener);
				if (civ.userFavorited == 0) {
					buy(0);
					// findViewById(R.id.cmdy_buy_tv).setBackgroundResource(
					// R.drawable.cmdy_cart_selector);
				} else {
					buy(1);
					// findViewById(R.id.cmdy_buy_tv).setBackgroundResource(
					// R.drawable.cmdy_cart_added_selector);
				}
				if (civ.canBuy) {
					onLineBtn.setVisibility(View.VISIBLE);
				} else {
					onLineBtn.setVisibility(View.GONE);
				}
				if (adapter.cmdyList.size() > 1) {
					topBar.initSubTitle((position + 1) + "/" + cv.total, null);
				}
			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {

			}

			@Override
			public void onPageScrollStateChanged(int arg0) {

			}
		});
		options = new DisplayImageOptions.Builder()
				.showImageOnLoading(R.color.translucent)
				.showImageForEmptyUri(R.drawable.loading_big)
				.preProcessor(new BitmapProcessor() {

					@Override
					public Bitmap process(Bitmap bm) {
						Bitmap desBm = ImageScaleUtils
								.createHeightScaledBitmap(picWidth, picHeight,
										bm);
						return desBm;

					}
				}).showImageOnFail(R.drawable.loading_big).cacheInMemory(true)
				.cacheOnDisc(true).considerExifParams(true)
				.bitmapConfig(Bitmap.Config.RGB_565)
				.imageScaleType(ImageScaleType.IN_SAMPLE_POWER_OF_2).build();
		initCatList();
	}

	public void selectCatList(String catStr) {
		for (TextView catTv : catList) {
			if (catTv.getText().equals(catStr + " ")) {
				Drawable drawable = context.getResources().getDrawable(
						R.drawable.right);
				drawable.setBounds(0, 0, Util.dip2px(context, 13),
						Util.dip2px(context, 11));
				catTv.setCompoundDrawables(null, null, drawable, null);
			} else {
				catTv.setCompoundDrawables(null, null, null, null);
			}
		}
		topBar.initTitle(catStr.trim());
		hideCatList();
	}

	private void initCatList() {
		catListLL = (LinearLayout) findViewById(R.id.shopping_cmdy_cat_list);
		String[] catIdStrs = ((Activity) context).getIntent().getExtras()
				.getStringArray(ConstantsActivity.INTENT_SHOP_ALL_CAT_ID);
		String[] catNameStrs = ((Activity) context).getIntent().getExtras()
				.getStringArray(ConstantsActivity.INTENT_SHOP_ALL_CAT_NAME);
		arrow = (TextView) findViewById(R.id.top_bar_arrow);
		if (catNameStrs == null) {
			arrow.setVisibility(View.GONE);
			return;
		} else {
			arrow.setVisibility(View.VISIBLE);
		}
		subTitlePop.setOnTouchListener(this);
		titlePop.setOnTouchListener(this);
		arrow.setOnTouchListener(this);
		String title = ((Activity) context).getIntent().getExtras()
				.getString(ConstantsActivity.INTENT_SHOP_CAT_NAME);
		LayoutParams lp = new LayoutParams(LayoutParams.WRAP_CONTENT,
				Util.dip2px(context, 60));
		LayoutParams llp = new LayoutParams(LayoutParams.MATCH_PARENT,
				Util.dip2px(context, 60));
		LayoutParams lineLp = new LayoutParams(LayoutParams.MATCH_PARENT,
				Util.dip2px(context, 1));
		for (int i = 0; i < catNameStrs.length; i++) {
			if (i == catNameStrs.length - 1) {
			}
			LinearLayout ll = new LinearLayout(context);
			ll.setGravity(Gravity.CENTER);
			TextView catListItem = new TextView(context);
			catListItem.setText(catNameStrs[i] + " ");
			catListItem.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
			catListItem.setTextColor(context.getResources().getColor(
					R.color.white));
			catListItem.setGravity(Gravity.CENTER);
			ll.setId(R.id.shopping_cmdy_cat);
			ll.setBackgroundResource(R.drawable.cmdy_cat_list_selector);
			ll.setTag(catNameStrs[i] + ":" + catIdStrs[i]);
			ll.setOnClickListener((ShoppingCmdyPagerActivity) context);

			if (title.equals(catNameStrs[i])) {
				Drawable drawable = context.getResources().getDrawable(
						R.drawable.right);
				drawable.setBounds(0, 0, Util.dip2px(context, 13),
						Util.dip2px(context, 11));
				((ShoppingCmdyPagerActivity) context).catName = catNameStrs[i]
						+ ":" + catIdStrs[i];
				catListItem.setCompoundDrawables(null, null, drawable, null);
			}

			TextView line = new TextView(context);
			line.setBackgroundColor(context.getResources().getColor(
					R.color.cmdy_line_bg));
			ll.addView(catListItem, lp);
			catList.add(catListItem);
			catListLL.addView(ll, llp);
			catListLL.addView(line, lineLp);
		}
		catListLL.setVisibility(View.GONE);
	}

	private void setPageListener(OnPageListener onPageListener) {
		this.onPageListener = onPageListener;
	}

	@Override
	public void updateContent(CommonVo rv) {
		super.updateContent(rv);

		if (rv instanceof CmdyVo) {
			cv = ((CmdyVo) rv);
			List<CmdyItemVo> cmdyList = ((CmdyVo) rv).list;
			if (cmdyList.size() > 0) {
				titleTv.setTag(cmdyList.get(0).id);
				titleTv.setText(cmdyList.get(0).name);
				priceTv.setText(cmdyList.get(0).price);
				if (cmdyList.get(0).userFavorited == 0) {
					buy(0);
				} else {
					buy(1);
				}
				adapter.setCmdyList(cmdyList);
				// adapter.notifyDataSetChanged();
				viewPage.setAdapter(adapter);
				if (adapter.cmdyList.size() > 1) {
					topBar.initSubTitle(1 + "/" + cv.total, null);
				}
				addCartTv.setTag(cmdyList.get(0));
				morePicBtn.setTag(cmdyList.get(0));
				currItemVo = cmdyList.get(0);
				if (currItemVo.canBuy) {
					onLineBtn.setVisibility(View.VISIBLE);
				} else {
					onLineBtn.setVisibility(View.GONE);
				}
			}
		}

	}

	public void select(int index) {
		viewPage.setCurrentItem(index);
	}

	public void select(String itemId) {
		int index = 0;
		List<CmdyItemVo> cmdyList = adapter.cmdyList;
		for (int i = 0; i < cmdyList.size(); i++) {
			if (cmdyList.get(i).id.equals(itemId)) {
				index = i;
				break;
			}
		}
		if (index == cmdyList.size() - 1) {
			onPageListener.onPage(index);
		}
		select(index);
	}

	public void refresh(List<CmdyItemVo> cmdyList) {
		adapter.setCmdyList(cmdyList);
		adapter.notifyDataSetChanged();
	}

	public void refreshItem() {
		if (currItemVo.userFavorited == 0) {
			buy(0);
		} else {
			buy(1);
		}
	}

	class CmdyPagerAdapter extends PagerAdapter {
		private List<CmdyItemVo> cmdyList = new ArrayList<CmdyItemVo>();
		private Map<Integer, SoftReference<Bitmap>> map = new HashMap<Integer, SoftReference<Bitmap>>();

		public void setCmdyList(List<CmdyItemVo> cmdyList) {
			this.cmdyList = cmdyList;
		}

		public List<CmdyItemVo> getCmdyList() {
			return cmdyList;
		}

		@Override
		public int getCount() {
			return cmdyList.size();
		}

		public int getItemPosition(Object object) {
			return POSITION_NONE;
		}

		@Override
		public View instantiateItem(ViewGroup container, final int position) {
			View v = LayoutInflater.from(context).inflate(
					R.layout.shopping_cmdy_pager_item, null);
			PhotoView photoView = (PhotoView) v
					.findViewById(R.id.shopping_cmdy_pic);
			photoView.setScaleType(ScaleType.CENTER_CROP);
			photoView.setOnPhotoTapListener(CmdyPagerUI.this);
			imageLoader.displayImage(cmdyList.get(position).bg, photoView,
					options, animateFirstListener);
			container.addView(v, LayoutParams.MATCH_PARENT,
					LayoutParams.MATCH_PARENT);
			if (position == cmdyList.size() - 1) {
				onPageListener.onPage(position);
			}
			// if (cmdyList.get(position).userFavorited == 0) {
			// Log.d("instantia", position + ":"
			// + cmdyList.get(position).userFavorited + "");
			// buy(0);
			// } else {
			// Log.d("instantia", position + ":"
			// + cmdyList.get(position).userFavorited + "");
			// buy(1);
			// }
			return v;
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			if (null != map.get(position)) {
				final Bitmap bitmap = map.get(position).get();
				if (null != bitmap && !bitmap.isRecycled()) {
					bitmap.recycle();
				}
			}
			container.removeView((View) object);
		}

		@Override
		public boolean isViewFromObject(View view, Object object) {
			return view == object;
		}

	}

	@Override
	public void onPhotoTap(View view, float x, float y) {
		showOrHide();
	}

	public void showOrHide() {
		if (show) {
			hide();
		} else {
			show();
		}
	}

	public void show() {
		Animation ifuAnimation = AnimationUtils.loadAnimation(context,
				R.anim.in_from_up);
		ifuAnimation.setAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {

			}

			@Override
			public void onAnimationRepeat(Animation animation) {

			}

			@Override
			public void onAnimationEnd(Animation animation) {
				topBar.setVisibility(View.VISIBLE);
				operatorBar.setVisibility(View.VISIBLE);
				operatorRightBar.setVisibility(View.VISIBLE);
			}
		});
		topBar.startAnimation(ifuAnimation);

		Animation ifdAnimation = AnimationUtils.loadAnimation(context,
				R.anim.in_from_down);
		operatorBar.startAnimation(ifdAnimation);
		Animation ifrAnimation = AnimationUtils.loadAnimation(context,
				R.anim.in_from_right);
		operatorRightBar.startAnimation(ifrAnimation);
		show = true;

	}

	public String getTitle() {
		return titleTv.getText().toString();
	}

	public String getItemCode() {
		return titleTv.getTag().toString();
	}

	public Bitmap getImage() {
		viewPage.setDrawingCacheEnabled(true);
		viewPage.buildDrawingCache();
		Bitmap bm = viewPage.getDrawingCache();
		Bitmap desBm = ImageScaleUtils.createHeightScaledBitmap(
				Util.dip2px(context, 200), Util.dip2px(context, 200), bm);
		viewPage.setDrawingCacheEnabled(false);
		return desBm;
	}

	public void hide() {
		Animation otuAnimation = AnimationUtils.loadAnimation(context,
				R.anim.out_to_up);

		otuAnimation.setAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {

			}

			@Override
			public void onAnimationRepeat(Animation animation) {

			}

			@Override
			public void onAnimationEnd(Animation animation) {
				outterView.findViewById(R.id.top_bar).setVisibility(View.GONE);
				operatorBar.setVisibility(View.GONE);
				operatorRightBar.setVisibility(View.GONE);
			}
		});
		topBar.startAnimation(otuAnimation);

		Animation otdAnimation = AnimationUtils.loadAnimation(context,
				R.anim.out_to_down);

		operatorBar.startAnimation(otdAnimation);

		Animation otrAnimation = AnimationUtils.loadAnimation(context,
				R.anim.out_to_right);
		operatorRightBar.startAnimation(otrAnimation);
		show = false;
		hideCatList();
	}

	public void buy(int fav) {
		if (fav == 1) {
			addCartTv
					.setBackgroundResource(R.drawable.cmdy_cart_added_selector);
			addCartTv.setText("已加");
		} else {
			addCartTv.setBackgroundResource(R.drawable.cmdy_cart_selector);
			addCartTv.setText("添加");
		}
	}

	public interface OnPageListener {
		public void onPage(int position);
	}

	private void showCatList() {
		catListLL.setVisibility(View.VISIBLE);
		findViewById(R.id.top_bar_arrow).setBackgroundResource(
				R.drawable.arrow_up);
		catPop = true;
	}

	private void hideCatList() {
		catListLL.setVisibility(View.GONE);
		findViewById(R.id.top_bar_arrow).setBackgroundResource(
				R.drawable.arrow_down);
		catPop = false;
	}

	public void showMore() {
		if (morePopup == null) {
			LayoutInflater inflater = LayoutInflater.from(context);
			View moreLayout = inflater.inflate(R.layout.cmdy_more_pop, null);
			morePopup = new PopupWindow(moreLayout, -1, -1, true);
			morePopup.setBackgroundDrawable(new BitmapDrawable());
			morePopup.setTouchable(true);
			morePopup.setOutsideTouchable(true);
			morePopup.setFocusable(true);
			// morePopup
			// .setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

			moreLayout.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					morePopup.dismiss();
				}
			});
		}

		cmdyTel = (LinearLayout) morePopup.getContentView().findViewById(
				R.id.cmdy_tel);
		cmdyQQ = (LinearLayout) morePopup.getContentView().findViewById(
				R.id.cmdy_qq);
		cmdyShareCircle = (LinearLayout) morePopup.getContentView()
				.findViewById(R.id.cmdy_circle);
		cmdyShareFriend = (LinearLayout) morePopup.getContentView()
				.findViewById(R.id.cmdy_friend);

		cmdyShareFriend.setOnClickListener((ShoppingCmdyPagerActivity) context);
		cmdyShareCircle.setOnClickListener((ShoppingCmdyPagerActivity) context);
		cmdyQQ.setOnClickListener((ShoppingCmdyPagerActivity) context);
		cmdyTel.setOnClickListener((ShoppingCmdyPagerActivity) context);
		cmdyTel.setTag(currItemVo);
		cmdyQQ.setTag(currItemVo);
		cmdyShareCircle.setTag(currItemVo);
		cmdyShareFriend.setTag(currItemVo);
		View parent = ((Activity) context).getWindow().findViewById(
				Window.ID_ANDROID_CONTENT);
		if (parent != null) {
			morePopup.showAtLocation(parent, Gravity.BOTTOM, 0, 0);
		}

	}

	public void showOnline() {
		if (onlinePopup == null) {
			LayoutInflater inflater = LayoutInflater.from(context);
			View onlineLayout = inflater
					.inflate(R.layout.cmdy_online_pop, null);
			onlinePopup = new PopupWindow(onlineLayout, -1, -1, true);
			onlinePopup.setBackgroundDrawable(new BitmapDrawable());
			onlinePopup.setTouchable(true);
			onlinePopup.setOutsideTouchable(true);
			onlinePopup.setFocusable(true);
			onlineBuy = ((TextView) onlineLayout.findViewById(R.id.online_buy));
			onlineBuy.setOnClickListener((ShoppingCmdyPagerActivity) context);

			onlineLayout.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					onlinePopup.dismiss();
				}
			});
		}
		onlineBuy.setTag(currItemVo);
		((TextView) onlinePopup.getContentView()
				.findViewById(R.id.online_title)).setText(currItemVo.name);
		((TextView) onlinePopup.getContentView().findViewById(
				R.id.online_detail)).setText(Html.fromHtml(currItemVo.detail));
		((TextView) onlinePopup.getContentView()
				.findViewById(R.id.online_price)).setText(currItemVo.price);
		if (!WXUtils.supportWXPay(context)) {
			((TextView) onlinePopup.getContentView().findViewById(
					R.id.online_buy_hint))
					.setText("您的微信版本过低，无法使用微信支付，将为您跳转到财付通支付");
		}

		View parent = ((Activity) context).getWindow().findViewById(
				Window.ID_ANDROID_CONTENT);
		if (parent != null) {
			onlinePopup.showAtLocation(parent, Gravity.BOTTOM, 0, 0);
		}

	}

	public void hidePop() {
		if (onlinePopup != null && onlinePopup.isShowing()) {
			onlinePopup.dismiss();
		}
		if (morePopup != null && morePopup.isShowing()) {
			morePopup.dismiss();
		}
	}

	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	public void setArrow(int i) {
		arrowView.setVisibility(View.VISIBLE);

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
			ObjectAnimator xAnim = ObjectAnimator.ofFloat(
					arrowView,
					"x",
					arrowView.getX() + arrowView.getWidth()
							+ Util.dip2px(arrowView.getContext(), 10),
					arrowView.getX()).setDuration(1000);
			xAnim.setStartDelay(0);
			xAnim.setRepeatCount(0);
			xAnim.setInterpolator(new BounceInterpolator());
			xAnim.addListener(new AnimatorListener() {

				@Override
				public void onAnimationStart(Animator animation) {
				}

				@Override
				public void onAnimationEnd(Animator animation) {
					arrowView.postDelayed(new Runnable() {
						@Override
						public void run() {
							arrowView.setVisibility(View.GONE);
						}
					}, 2000);
				}

				@Override
				public void onAnimationCancel(Animator animation) {
				}

				@Override
				public void onAnimationRepeat(Animator animation) {
				}
			});
			xAnim.start();
		}
	}

	public void setArrow(String s) {
		arrowView.setVisibility(View.VISIBLE);

		TranslateAnimation anim = new TranslateAnimation(arrowView.getWidth()
				+ Util.dip2px(arrowView.getContext(), 10), 0, 0, 0);
		anim.setDuration(1000);
		anim.setInterpolator(new BounceInterpolator());
		anim.setAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {
			}

			@Override
			public void onAnimationEnd(Animation animation) {
				arrowView.postDelayed(new Runnable() {
					@Override
					public void run() {
						arrowView.setVisibility(View.GONE);
					}
				}, 2000);
			}

			@Override
			public void onAnimationRepeat(Animation animation) {
			}
		});
		arrowView.setAnimation(anim);
		anim.start();
	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		if (event.getAction() == MotionEvent.ACTION_UP) {
			if (!catPop) {
				showCatList();
			} else {
				hideCatList();
			}
		}
		return false;
	}

}
