package com.tencent.weigou.shopping.model.vo;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.tencent.weigou.base.model.vo.CommonVo;
import com.tencent.weigou.shopping.model.vo.MallDetailVo.PromotionItem;

public class ShopCardVo extends CommonVo {
	
	public String shopBgUrl;
	public String shopLogo;
	public String shopName;
	public int totalItemCount;
	public boolean isSub;
    public String tel;
	
	public List<CatItem> catList;
	public List<PromotionItem> promotionList;
	public List<ShowCaseItem> showCaseList;

	/**
	 * called by bg Thread
	 */
	@Override
	public boolean parse(JSONObject jo) {
		
		try {
			JSONObject shopObj = jo.optJSONObject("shop");
			if(shopObj != null) {
				shopBgUrl = shopObj.optString("backgroundImage", "").trim();
				shopLogo = shopObj.optString("brandLogo", "").trim();
				shopName = shopObj.optString("name", "").trim();
				totalItemCount = shopObj.optInt("itemCount", 0);
				int isSubInt = shopObj.optInt("userSubscribled", 0);
				if(isSubInt > 0) {
					isSub = true;
				}
				else {
					isSub = false;
				}
                tel = shopObj.optString("tel", "").trim();
				
				JSONArray catArray = shopObj.optJSONArray("category");
				if(catArray != null && catArray.length() > 0) {
					int length = catArray.length();
					catList = new ArrayList<CatItem>(length + 1);
					for(int i = 0; i < length; i++) {
						JSONObject catObj = catArray.getJSONObject(i);
						CatItem catItem = new CatItem();
						catItem.catId = catObj.optString("id", "").trim();
						catItem.catName = catObj.optString("name", "").trim();
						catItem.itemCount = catObj.optInt("itemCount", 0);
						catList.add(catItem);
					}
                    if(totalItemCount > 0) {
                        CatItem catItem = new CatItem();
                        catItem.catId = "";
                        catItem.catName = "全部商品";
                        catItem.itemCount = totalItemCount;
                        catList.add(catItem);
                    }
				}
				else {
                    if(totalItemCount > 0) {
                        catList = new ArrayList<CatItem>(1);
                        CatItem catItem = new CatItem();
                        catItem.catId = "";
                        catItem.catName = "全部商品";
                        catItem.itemCount = totalItemCount;
                        catList.add(catItem);
                    }
				}
				
				JSONArray promotionArray = shopObj.optJSONArray("promotion");
				if(promotionArray != null && promotionArray.length() > 0) {
					int length = promotionArray.length();
					promotionList = new ArrayList<PromotionItem>(length);
					for(int i = 0; i < length; i++) {
						JSONObject promotionObj = promotionArray.getJSONObject(i);
						PromotionItem promotionItem = new PromotionItem();
						promotionItem.activityUrl = promotionObj.optString("activityUrl", "").trim();
						promotionItem.beginTime = promotionObj.optLong("beginTime", 0);
						promotionItem.desc = promotionObj.optString("desc", "").trim();
						promotionItem.endTime = promotionObj.optLong("endTime", 0);
						promotionItem.imageUrl = promotionObj.optString("imageUrl", "").trim();
						promotionItem.title = promotionObj.optString("title", "").trim();
						promotionItem.activityId = promotionObj.optInt("activityId", 0);
						promotionItem.sponsorId = promotionObj.optInt("sponsorId", 0);
						promotionItem.sponsorType = promotionObj.optInt("sponsorType", 0);
						promotionItem.type = promotionObj.optInt("type", 0);
						promotionList.add(promotionItem);
					}
				}	
				
				JSONArray showCaseArray = shopObj.optJSONArray("showcase");
				if(showCaseArray != null && showCaseArray.length() > 0) {
					int length = showCaseArray.length();
					showCaseList = new ArrayList<ShowCaseItem>(length);
					for(int i = 0; i < length; i++) {
						JSONObject showCaseObj = showCaseArray.getJSONObject(i);
						ShowCaseItem showCaseItem = new ShowCaseItem();
						showCaseItem.itemId = showCaseObj.optString("itemId", "").trim();
						showCaseItem.itemImgUrl = showCaseObj.optString("itemPic", "").trim();
						showCaseList.add(showCaseItem);
					}
				}
			}
		}
		catch(JSONException e) {
			shopBgUrl = null;
			shopLogo = null;
			shopName = null;
			totalItemCount = 0;
			
			catList = null;
			promotionList = null;
			showCaseList = null;
		}
		return true;
	}
	
	public static class CatItem {
		public String catId;
		public String catName;
		public int itemCount;
	}
	
	/**
	 * reuse MallDetailVo$PromotionItem
	 */
//	public static class PromotionItem {
//		public int activityId;
//		public String activityUrl;
//		public long beginTime;
//		public String desc;
//		public long endTime;
//		public String imageUrl;
//		public int sponsorId;
//		public int sponsorType;
//		public String title;
//		public int type;		
//	}
	
	public static class ShowCaseItem {
		public String itemId;
		public String itemImgUrl;
	}
}
