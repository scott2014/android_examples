package com.tencent.weigou.shopping.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

import com.tencent.weigou.R;
import com.tencent.weigou.base.activity.TitleBarActivity;
import com.tencent.weigou.shopping.model.ShopListModel;
import com.tencent.weigou.shopping.view.ShopListUI;
import com.tencent.weigou.util.ConstantsActivity;
import com.tencent.weigou.util.ConstantsUrl;
import com.tencent.weigou.util.StringUtils;
import com.tencent.weigou.util.PageIds.OprIndex;
import com.tencent.weigou.util.lbs.LBSUtils;
import com.tencent.weigou.util.lbs.Location;
import com.tencent.weigou.util.region.RegionManager;

/**
 * 
 * @ClassName： ShopListActivity
 *
 * @Description： 品牌下门店列表页面
 * @author wamiwen
 * @date 2013-12-5 上午11:29:41
 *
 */
public class ShopListActivity extends TitleBarActivity implements OnItemClickListener {

	private ShopListModel model = new ShopListModel();

	private ShopListUI ui = new ShopListUI();

	private String brandId = "";
	private String brandName = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		initMVC(model, ui, R.layout.shop_list_layout);
		initBackBtn();
		init();
	}

	private void init() {
		Intent intent = getIntent();
		if (!initIntent(intent)) {
			finish();
			return;
		} 

		if (StringUtils.isNotBlank(brandName)) {
			setTitle(brandName + "所有门店");
		}

		Location loc = LBSUtils.getLocation();
		double longitude = loc.longitude;
		double latitude = loc.latitude;
		String cityName = loc.adminInfo.city;
		String cityId = RegionManager.getInstance(app).getCityId(cityName);

		StringBuffer sb = new StringBuffer(app.getEnv().getServerUrl());
		sb.append(ConstantsUrl.URL_LIST_SHOP_BY_BRAND + "?bid=")
				.append(brandId).append("&cid=").append(cityId)
				.append("&longitude=").append(longitude).append("&latitude=")
				.append(latitude);
		String url = sb.toString();
		url = appendPageInfo(url, OprIndex.PV_OPR);
		model.initData(url);
	}

	private boolean initIntent(Intent intent) {
		if (intent != null) {
			brandId = intent.getStringExtra(ConstantsActivity.INTENT_BRAND_ID);
			brandName = intent
					.getStringExtra(ConstantsActivity.INTENT_BRAND_NAME);
			if (StringUtils.isNotBlank(brandId)) {
				return true;
			}
		}
		return false;
	}
	
	@Override
	public void update(int notificationId) {
		super.update(notificationId);
		switch (notificationId) {
		case ShopListModel.GET_SHOP_LIST:
			ui.updateContent(model.getShopListVo());
			break;

		default:
			break;
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		String shopId = (String) view.getTag(R.id.tag_shop_id);
		String shopName = (String) view.getTag(R.id.tag_shop_name);
		Intent intent = new Intent(this, ShopPagerActivity.class);
		intent.putExtra(ConstantsActivity.INTENT_SHOP_ID, shopId);
		intent.putExtra(ConstantsActivity.INTENT_SHOP_NAME, shopName);
		intent.putExtra(ConstantsActivity.INTENT_SINGLE_CARD, "true");
		
		startActivity(intent);
	}

}
