package com.tencent.weigou.shopping.fragment;

import java.util.List;

import com.tencent.weigou.R;
import com.tencent.weigou.shopping.model.vo.MallDetailVo.PromotionItem;
import com.tencent.weigou.util.Util;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

public class PromotionFragment extends Fragment {
	
	private List<PromotionItem> promotionList;

	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
    	Log.d("Bran", "PromotionFragment onCreateView");
        View v = inflater.inflate(R.layout.mall_promotion_layout, container, false);
        
        v.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // consume click event but do nothing, maybe do closing this fragment
                FragmentBridge fragmentBridge = (FragmentBridge)PromotionFragment.this.getActivity();
                fragmentBridge.closeFragment();
            }
        });
        
        LinearLayout contentGroup = (LinearLayout)v.findViewById(R.id.content_container);
        
        contentGroup.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// consume click event but do nothing, maybe do closing this fragment
				FragmentBridge fragmentBridge = (FragmentBridge)PromotionFragment.this.getActivity();
				fragmentBridge.closeFragment();
			}
		});        
        
        
        if(promotionList != null && promotionList.size() > 0) {
        	int length = promotionList.size();
        	for(int i = 0; i < length; i++) {
        		PromotionItem promotionItem = promotionList.get(i);
        		if(promotionItem != null) {
        			View content = inflater.inflate(R.layout.mall_promotion_item_layout, null);
            		TextView titleView = (TextView) content.findViewById(R.id.promotion_item_title);
            		TextView timeView = (TextView) content.findViewById(R.id.promotion_item_time);
            		TextView descView = (TextView) content.findViewById(R.id.promotion_item_desc);
            		titleView.setText(promotionItem.title);
            		timeView.setText(Util.getDateShortStr(promotionItem.beginTime) 
            				+ "-" + Util.getDateShortStr(promotionItem.endTime));
            		descView.setText(promotionItem.desc);
            		
            		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            				LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            		if(i > 0) {
            			params.topMargin = Util.dip2px(getActivity(), 10);
            		}
            		contentGroup.addView(content, params);
        		}
        		
        	}
        }
        
        return v;
    }
    
    public void setPromotionList(List<PromotionItem> promotionList) {
    	this.promotionList = promotionList;
    }
    
    public interface FragmentBridge {
    	public void closeFragment();
    }
}
