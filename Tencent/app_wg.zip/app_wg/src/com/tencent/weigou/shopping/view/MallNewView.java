package com.tencent.weigou.shopping.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.tencent.weigou.R;
import com.tencent.weigou.common.ui.AdaptiveImageView;
import com.tencent.weigou.shopping.model.vo.MallNewVo;
import com.tencent.weigou.util.AsyncImageLoader;
import com.tencent.weigou.util.IImageLoadedCallBack;
import com.tencent.weigou.util.Util;

import java.util.List;

/**
 * 逛-商场-上新
 * User: ethonchan
 * Date: 13-12-4
 * Time: 下午4:19
 */
public class MallNewView extends LinearLayout implements IImageLoadedCallBack {
    //  标题Layout
    private View mTitleLayout;

    //  店铺LOGO
    private AdaptiveImageView mLogo;

    //  店铺名称
    private TextView mName;

    //  商品信息
    private ViewGroup mItemsLayout;

    //  图片加载控制器
    private AsyncImageLoader mImageLoader;

    public MallNewView(Context context) {
        super(context);
        init(context);
    }

    public MallNewView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context) {
        LayoutInflater inflater = LayoutInflater.from(context);
        inflater.inflate(R.layout.shopping_mall_new, this);
        setOrientation(VERTICAL);

        mTitleLayout = findViewById(R.id.title_layout);
        mLogo = (AdaptiveImageView) findViewById(R.id.logo);
        mLogo.setDrawCircleBorder(true);
        mName = (TextView) findViewById(R.id.name);
        mItemsLayout = (ViewGroup) findViewById(R.id.items);

        //  init holder
        for (int i = 0, len = mItemsLayout.getChildCount(); i < len; i++) {
            View view = mItemsLayout.getChildAt(i);
            if(view == null){
                continue;
            }

            ItemViewHolder holder = new ItemViewHolder();
            holder.imageView = (MallNewImage) view.findViewById(R.id.image);
            holder.priceView = (TextView) view.findViewById(R.id.price);
            holder.nameView = (TextView) view.findViewById(R.id.cmdy_name);
            view.setTag(holder);
        }
    }

    /**
     * 设置图片加载控制器
     *
     * @param imageLoader
     */
    public void setImageLoader(AsyncImageLoader imageLoader) {
        this.mImageLoader = imageLoader;
    }

    /**
     * 展示店铺信息
     *
     * @param shopInfo
     */
    public void setData(MallNewVo.Shop shopInfo) {
        if (shopInfo == null) {
            return;
        }

        for (int i = 0, len = mItemsLayout.getChildCount(); i < len; i++) {
            View view = mItemsLayout.getChildAt(i);
            if(view == null){
                continue;
            }

            ItemViewHolder holder = (ItemViewHolder) view.getTag();
            holder.imageView.setImageResource(R.drawable.loading_big);
        }

        //  展示名称、LOGO等信息
        mName.setText(shopInfo.name);
        loadDrawable(mLogo, shopInfo.logoUrl);
        //  绑定店铺信息
        mTitleLayout.setTag(shopInfo);

        //  展示商品信息
        List<MallNewVo.Item> items = shopInfo.itemList;
        if (items == null || items.size() == 0) {
            mItemsLayout.setVisibility(View.GONE);
        } else {
            mItemsLayout.setVisibility(View.VISIBLE);
            displayItems(mItemsLayout, items);
        }
    }

    /**
     * 点击事件监听器
     *
     * @param listener
     */
    public void setOnClickListener(OnClickListener listener) {
        mTitleLayout.setOnClickListener(listener);

        for (int i = 0, len = mItemsLayout.getChildCount(); i < len; i++) {
            View view = mItemsLayout.getChildAt(i);
            if(view == null){
                continue;
            }

            view.setOnClickListener(listener);
        }
    }

    /**
     * 显示商品信息
     *
     * @param groupView 用于显示商品的一组商品，groupView的每一个child显示一个商品
     * @param items     要显示的商品列表
     */
    public void displayItems(ViewGroup groupView, List<MallNewVo.Item> items) {
        if (groupView == null || items == null) {
            return;
        }

        final int viewSize = groupView.getChildCount();
        final int itemSize = items.size();
        for (int index = 0; index < viewSize; index++) {
            View view = groupView.getChildAt(index);
            if(view == null){
                continue;
            }

            if (index >= itemSize)
            //  隐藏
            {
                view.setVisibility(View.INVISIBLE);
            } else {
                view.setVisibility(View.VISIBLE);

                //  更新holder
                ItemViewHolder holder = (ItemViewHolder) view.getTag();
                MallNewVo.Item item = items.get(index);
                holder.ids = item.listIds;
                holder.index = index;
                holder.shopName = item.shopName;

                if (index == 5 && itemSize > 6)
                //  显示更多商品数量
                {
                    holder.nameView.setText("");
                    holder.priceView.setText("");
                    holder.imageView.showNewCount("" + (itemSize - 5));
                } else
                //  显示商品信息
                {
                    holder.nameView.setText(item.name);
                    String priceStr = Util.getCurrency(item.price);
                    holder.priceView.setText(priceStr);
                    holder.imageView.showImage();
                    loadDrawable(holder.imageView, item.picUrl);
                }

                view.setTag(holder);
            }
        }
    }

    /**
     * 异步加载图片
     *
     * @param imageView
     * @param url
     */
    protected void loadDrawable(ImageView imageView, String url) {
        if (imageView != null && mImageLoader != null) {
            imageView.setTag(url);
            int width = imageView.getWidth();
            int height = imageView.getHeight();
            Bitmap bitmap = mImageLoader.loadDrawable(url, imageView, width, height, this);

//            Bitmap bitmap = mImageLoader.loadDrawable(url, imageView, this);
            if (bitmap != null) {
                imageView.setImageBitmap(bitmap);
                imageView.setTag(null);
            }
        }
    }

    @Override
    public void imageLoaded(ImageView imageView, Bitmap bitmap, String imageUrl) {
        if (imageView != null) {
            Object tag = imageView.getTag();
            if (tag != null && tag instanceof String) {
                String originUrl = (String) tag;
                if (originUrl.equals(imageUrl)) {
                    imageView.setImageBitmap(bitmap);
                    imageView.setTag(null);
                }
            }
        }
    }

    public static class ItemViewHolder {
        public MallNewImage imageView;

        public TextView nameView;

        public TextView priceView;

        //  列表中所有的商品ID集合
        public String ids;

        //  本商品在列表中的偏移量
        public int index = 0;

        public String shopName = "";
    }
}
