package com.tencent.weigou.shopping.view;

import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ListAdapter;
import android.widget.ListView;
import com.tencent.weigou.R;
import com.tencent.weigou.base.view.UI;

/**
 * 逛-商场-上新专区
 * User: ethonchan
 * Date: 13-12-4
 * Time: 下午3:38
 */
public class MallNewUI extends UI{

    private ListView mListView;

    @Override
    public void initView(View outterView) {
        super.initView(outterView);
        mListView = (ListView) outterView.findViewById(R.id.listview);
        // 去掉滑动时的黑色背景
        mListView.setCacheColorHint(Color.TRANSPARENT);
        // 去掉selector
        mListView.setSelector(new ColorDrawable(Color.TRANSPARENT));

        Resources res = outterView.getResources();
        Drawable divider = res.getDrawable(R.drawable.list_divider);
        mListView.setDivider(divider);
    }

    /**
     * 设置列表展示内容
     * @param adapter
     */
    public void setListAdapter(ListAdapter adapter){
        if(mListView != null){
            mListView.setAdapter(adapter);
        }
    }
}
