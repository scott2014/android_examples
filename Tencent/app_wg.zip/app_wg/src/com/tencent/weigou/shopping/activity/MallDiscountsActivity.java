package com.tencent.weigou.shopping.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import com.tencent.weigou.R;
import com.tencent.weigou.base.activity.TitleBarActivity;
import com.tencent.weigou.common.ui.AdaptiveImageView;
import com.tencent.weigou.shopping.model.MallDiscountsModel;
import com.tencent.weigou.shopping.model.vo.MallDiscountsVo;
import com.tencent.weigou.shopping.view.MallDiscountsUI;
import com.tencent.weigou.util.*;

import java.util.List;

/**
 * 逛-商场-折扣列表
 * User: ethonchan
 * Date: 13-12-4
 * Time: 上午11:19
 */
public class MallDiscountsActivity extends TitleBarActivity implements IImageLoadedCallBack, AdapterView.OnItemClickListener {

    private MallDiscountsUI mDiscountsUI;

    private MallDiscountsModel mDiscountsModel;

    private MyListAdapter mListAdapter;

    //  图片加载工具
    private AsyncImageLoader mImageLoader;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mDiscountsModel = new MallDiscountsModel();
        mDiscountsUI = new MallDiscountsUI();
        initMVC(mDiscountsModel, mDiscountsUI, R.layout.listview_layout);

        setTitle(R.string.shopping_mall_discounts);
        initBackBtn();

        mImageLoader = new AsyncImageLoader();
        mListAdapter = new MyListAdapter();
        mDiscountsUI.setListAdapter(mListAdapter);
        mDiscountsUI.setOnItemClickListener(this);

        Intent intent = getIntent();
        if (intent != null) {
            String mallId = intent.getStringExtra(ConstantsActivity.INTENT_MALL_DETAIL_ID);
            String url = getInitUrl(mallId);
            mDiscountsModel.initData(url);
        } else {
            finish();
        }
    }

    /**
     * 得到本页面初始化所需的url
     *
     * @param mallId
     * @return
     */
    public String getInitUrl(String mallId) {
        String url = app.getEnv().getServerUrl() + ConstantsUrl.GET_MALL_DISCOUNTS;
        url += "?mid=" + mallId;
        url = appendPageInfo(url, PageIds.OprIndex.PV_OPR);
        return url;
    }

    @Override
    public void update(int notificationId) {
        super.update(notificationId);

        if (notificationId == MallDiscountsModel.GET_MALL_DISCOUNTS)
        //  成功获取数据
        {
            MallDiscountsVo discountVo = mDiscountsModel.getDiscountsVo();
            if (discountVo != null)
            //  更新列表
            {
                mListAdapter.setDiscounts(discountVo.getDiscountList());
            }
        }
    }

    /**
     * 异步加载图片
     *
     * @param imageView
     * @param url       对应的图片url
     */
    protected void loadImage(ImageView imageView, String url) {
        if (imageView != null) {
            imageView.setTag(url);
            Bitmap bitmap = mImageLoader.loadDrawable(url, imageView, this);
            if (bitmap != null) {
                imageView.setImageBitmap(bitmap);
                imageView.setTag(null);
            }
        }
    }

    @Override
    public void imageLoaded(ImageView imageView, Bitmap bitmap, String imageUrl) {
        if (imageView != null) {
            Object tag = imageView.getTag();
            if (tag != null && tag instanceof String) {
                String orgUrl = (String) tag;
                if (orgUrl.equals(imageUrl)) {
                    imageView.setImageBitmap(bitmap);
                    imageView.setTag(null);
                }
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mImageLoader != null) {
            mImageLoader.destroy();
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Object tag = view.getTag();
        if(tag != null && tag instanceof  MallDiscountHolder){
            MallDiscountHolder holder = (MallDiscountHolder) tag;
            Intent intent = new Intent(this, ShopPagerActivity.class);
            intent.putExtra(ConstantsActivity.INTENT_SHOP_ID, holder.shopId);
            intent.putExtra(ConstantsActivity.INTENT_SHOP_NAME, holder.name.getText());
            intent.putExtra(ConstantsActivity.INTENT_SINGLE_CARD, "true");

            startActivity(intent);
        }
    }

    class MyListAdapter extends BaseAdapter {
        private List<MallDiscountsVo.Discount> discountList;

        /**
         * 添加品牌折扣
         *
         * @param discountList
         */
        public void setDiscounts(List<MallDiscountsVo.Discount> discountList) {
            if (discountList != null) {
                this.discountList = discountList;
                notifyDataSetChanged();
            }
        }

        @Override
        public int getCount() {
            return discountList == null ? 0 : discountList.size();
        }

        @Override
        public Object getItem(int position) {
            if (position > -1 && position < getCount()) {
                return discountList.get(position);
            }
            return null;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View view, ViewGroup parent) {
            if (view == null) {
                LayoutInflater inflater = LayoutInflater.from(MallDiscountsActivity.this);
                view = inflater.inflate(R.layout.shopping_mall_discount, null);

                MallDiscountHolder holder = new MallDiscountHolder();
                holder.logo = (AdaptiveImageView) view.findViewById(R.id.logo);
                holder.logo.setDrawCircleBorder(true);
                holder.name = (TextView) view.findViewById(R.id.name);
                holder.desc = (TextView) view.findViewById(R.id.desc);

                view.setTag(holder);
            }

            MallDiscountsVo.Discount item = null;
            if (position > -1 && position < getCount()) {
                item = discountList.get(position);
            }

            Object tag = view.getTag();
            if (tag != null && item != null) {
                MallDiscountHolder holder = (MallDiscountHolder) tag;
                holder.name.setText(item.name);
                holder.desc.setText(item.desc);
                holder.shopId = "" + item.id;
                loadImage(holder.logo, item.logoUrl);
            }
            return view;
        }
    }

    static class MallDiscountHolder {
        AdaptiveImageView logo;

        TextView name, desc;

        String shopId;
    }
}
