package com.tencent.weigou.shopping.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

import com.tencent.weigou.R;
import com.tencent.weigou.base.App;
import com.tencent.weigou.base.activity.TitleBarActivity;
import com.tencent.weigou.shopping.model.BrandModel;
import com.tencent.weigou.shopping.model.vo.BrandListVo.BrandVo;
import com.tencent.weigou.shopping.view.BrandUI;
import com.tencent.weigou.util.ConstantsActivity;
import com.tencent.weigou.util.ConstantsUrl;
import com.tencent.weigou.util.PageIds.OprIndex;
import com.tencent.weigou.util.lbs.LBSUtils;
import com.tencent.weigou.util.region.RegionManager;

public class BrandListActivity extends TitleBarActivity implements
		OnItemClickListener, OnClickListener {
	BrandUI ui = new BrandUI();
	BrandModel model = new BrandModel();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		initMVC(model, ui, R.layout.shopping_nav);
		setTitle("品牌");
		initBackBtn();
		init();
		topbar.initRightBtnA(R.drawable.top_bar_arrow, "", this);
	}

	private void init() {
		String cityName = LBSUtils.getLocation().adminInfo.city;
		String cityId = RegionManager.getInstance(App.getInstance()).getCityId(
				cityName);
		StringBuffer sb = new StringBuffer(App.getInstance().getEnv()
				.getServerUrl());
		sb.append(ConstantsUrl.SHOPPING_INDEX_BRAND + "?cid=").append(cityId)
				.append("&nd=").append("1").append("&pn=").append("1")
				.append("&ps=").append("100");
		String url = sb.toString();
		url = appendPageInfo(url, OprIndex.PV_OPR);
		model.initData(url);
	}

	@Override
	public void update(int notificationId) {
		super.update(notificationId);
		switch (notificationId) {
		case BrandModel.INIT_DATA:
			ui.updateContent(model.brandListVo);
			break;
		}
	}

	@Override
	public void finish() {
		super.finish();
		overridePendingTransition(R.anim.in_from_up, R.anim.out_to_up);
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		Intent it = new Intent();
		if (parent != null) {
			Object brandVoo = parent.getItemAtPosition(position);
			if (brandVoo != null && brandVoo instanceof BrandVo) {
				BrandVo brandVo = (BrandVo) brandVoo;
				if (brandVo != null) {
					it.putExtra(ConstantsActivity.INTENT_BRAND_ID, brandVo.id);
					it.putExtra(ConstantsActivity.INTENT_BRAND_NAME,
							brandVo.name);
					it.setClass(this, ShopListActivity.class);
					startActivity(it);
				}
			}

		}

	}

	@Override
	public void onClick(View v) {
		finish();
	}
}
