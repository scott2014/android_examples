package com.tencent.weigou.shopping.model.vo;

import java.util.Map;

public class ShoppingVo {
	int type = 0;// 0:商场，1：商圈。2：品牌
	String logoUrl;
	String name;
	String bgUrl;
	String distance;
	boolean faved;
	Map<String, String> prom;
	Map<String, String> brands;
}
