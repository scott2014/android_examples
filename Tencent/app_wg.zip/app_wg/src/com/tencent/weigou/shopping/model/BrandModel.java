package com.tencent.weigou.shopping.model;

import com.tencent.weigou.base.model.Model;
import com.tencent.weigou.shopping.model.vo.BrandListVo;

public class BrandModel extends Model {
	public final static int INIT_DATA = 0;
	public BrandListVo brandListVo;

	@Override
	public void initData(String url) {
		brandListVo = new BrandListVo();
		createNetWorkTask(url, brandListVo, INIT_DATA);
	}
}
