package com.tencent.weigou.shopping.fragment;


import java.util.List;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.RelativeSizeSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.tencent.weigou.R;
import com.tencent.weigou.page.activity.ShopPageActivity;
import com.tencent.weigou.shopping.activity.ShoppingCmdyPagerActivity;
import com.tencent.weigou.shopping.model.vo.MallDetailVo.PromotionItem;
import com.tencent.weigou.shopping.model.vo.ShopCardVo;
import com.tencent.weigou.shopping.utils.IProgressImgLoaderEvent;
import com.tencent.weigou.shopping.utils.ProgressImgLoader;
import com.tencent.weigou.shopping.view.ProgressImageView;
import com.tencent.weigou.shopping.view.PromotionSwitcher;
import com.tencent.weigou.util.ConstantsActivity;
import com.tencent.weigou.util.StringUtils;

public class ShopFragment extends Fragment implements OnClickListener {
	
	private static final int CAT_MAX_NUM = 4;

	private int pos;
	private String shopId;
	private ShopCardVo shopCardVo;
	
	private FragmentBridge fragmentBridge;
	private ProgressImgLoader asyncImageLoader;
	
	private ImageView shopBgImgView;
	private View contentContainer;
	private TextView nameView;
	private ImageView logoView;
    private LinearLayout promotionViewLayout;
    private PromotionSwitcher promotionView;
	private TextView[] catViews = new TextView[4];
	private ProgressImageView  showCaseLeftView;
	private ProgressImageView  showCaseRightView;
	private TextView subImgView;
	private ProgressBar loadingBar;
	private TextView loadingFailView;

    public static ShopFragment newInstance(int pos, String shopId) {
    	
    	ShopFragment f = new ShopFragment();

        Bundle args = new Bundle();
        args.putInt("pos", pos);
        args.putString("shopId", shopId);
        f.setArguments(args);
        
        return f;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);        
        pos = getArguments() != null ? getArguments().getInt("pos") : -1;
        Log.d("Bran", "ShopFragment onCreate pos = " + pos);
        shopId = getArguments() != null ? getArguments().getString("shopId") : "";
        fragmentBridge = (FragmentBridge)getActivity();
        asyncImageLoader = fragmentBridge.getProgressImgLoader();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
    	Log.d("Bran", "onCreateView");
        View v = inflater.inflate(R.layout.shop_pager_item_layout, container, false);
        
        shopBgImgView = (ImageView) v.findViewById(R.id.pager_item_bg_img);
        contentContainer = v.findViewById(R.id.content_container);
        nameView = (TextView) v.findViewById(R.id.shop_name);
        logoView = (ImageView) v.findViewById(R.id.shop_card_logo);
        promotionViewLayout = (LinearLayout) v.findViewById(R.id.shop_promotion_layout);
        promotionView = (PromotionSwitcher) v.findViewById(R.id.shop_promotion);
        catViews[0] = (TextView) v.findViewById(R.id.shop_cat_1_1);
		catViews[1] = (TextView) v.findViewById(R.id.shop_cat_1_2);
		catViews[2] = (TextView) v.findViewById(R.id.shop_cat_2_1);
		catViews[3] = (TextView) v.findViewById(R.id.shop_cat_2_2);
		showCaseLeftView = (ProgressImageView ) v.findViewById(R.id.shop_card_item_img_1);
		showCaseRightView = (ProgressImageView ) v.findViewById(R.id.shop_card_item_img_2);
		subImgView = (TextView) v.findViewById(R.id.shop_event_sub);
//		v.findViewById(R.id.shop_event_share).setOnClickListener(this);
		v.findViewById(R.id.shop_event_page).setOnClickListener(this);
		
		loadingBar = (ProgressBar) v.findViewById(R.id.loading_bar);
		loadingFailView = (TextView) v.findViewById(R.id.loading_fail);
        
		ShopCardVo shopCardVo = fragmentBridge.getCardData(pos);
		if(shopCardVo != null) {
			setShopCardVo(shopCardVo);
		}
		else {
			contentContainer.setVisibility(View.GONE);
			loadingBar.setVisibility(View.VISIBLE);
			loadingFailView.setVisibility(View.GONE);
			fragmentBridge.startLoadingCard(pos, shopId);
		}
        
        return v;
    }
    
    public void setShopCardVo(final ShopCardVo shopCardVo) {
    	if(shopCardVo != null) {
    		this.shopCardVo = shopCardVo;
    		
    		contentContainer.setVisibility(View.VISIBLE);
    		loadingBar.setVisibility(View.GONE);
    		loadingFailView.setVisibility(View.GONE);
			
			shopBgImgView.setTag(shopCardVo.shopBgUrl);
			ProgressImgLoader.asyncLoadImage(asyncImageLoader, shopBgImgView, shopCardVo.shopBgUrl, 0);
    		nameView.setText(shopCardVo.shopName);
    		logoView.setTag(shopCardVo.shopLogo);
    		ProgressImgLoader.asyncLoadImage(asyncImageLoader, logoView, shopCardVo.shopLogo, 0);


            if (shopCardVo.promotionList != null
                    && shopCardVo.promotionList.size() > 0) {
                int length = shopCardVo.promotionList.size();
                String[] proStrs = new String[length];
                for(int i = 0; i < length; i++) {
                    proStrs[i] = shopCardVo.promotionList.get(i).title;
                }
                updatePromotion(proStrs);
            } else {
                promotionViewLayout.setVisibility(View.GONE);
            }
    		
    		if(shopCardVo.catList != null && shopCardVo.catList.size() > 0) {
    			int length = shopCardVo.catList.size();
    			if(length > CAT_MAX_NUM) {
                    for(int i = 0; i < CAT_MAX_NUM - 1; i++) {
                        updateCat(shopCardVo.catList.get(i).catName,
                                shopCardVo.catList.get(i).catId,
                                shopCardVo.catList.get(i).itemCount,
                                i);
                    }
                    if(shopCardVo.totalItemCount > 0) {
                        updateCat(shopCardVo.catList.get(length - 1).catName,
                                shopCardVo.catList.get(length - 1).catId,
                                shopCardVo.catList.get(length - 1).itemCount,
                                CAT_MAX_NUM - 1);
                    }
                    else {
                        updateCat(shopCardVo.catList.get(CAT_MAX_NUM - 1).catName,
                                shopCardVo.catList.get(CAT_MAX_NUM - 1).catId,
                                shopCardVo.catList.get(CAT_MAX_NUM - 1).itemCount,
                                CAT_MAX_NUM - 1);
                    }
    			}
                else {
                    for(int i = 0; i < length; i++) {
                        updateCat(shopCardVo.catList.get(i).catName,
                                shopCardVo.catList.get(i).catId,
                                shopCardVo.catList.get(i).itemCount,
                                i);
                    }
                    if(length < CAT_MAX_NUM) {
                        for(int i = length; i < CAT_MAX_NUM; i++) {
                            catViews[i].setVisibility(View.GONE);
                        }
                    }
                }

    		}
    		else {
    			for(int i = 0; i < CAT_MAX_NUM; i++) {
    				catViews[i].setVisibility(View.GONE);
    			}
    		}
    		
    		setSubState(shopCardVo.isSub);
    		subImgView.setOnClickListener(this);
    		
    		if(shopCardVo.showCaseList != null && shopCardVo.showCaseList.size() > 0
                    && shopCardVo.showCaseList.get(0) != null
                    && StringUtils.isNotEmpty(shopCardVo.showCaseList.get(0).itemImgUrl)) {
    			showCaseLeftView.setDoubleOnClickListener(this, new OnClickListener() {
    				
    				@Override
    				public void onClick(View v) {
    					asyncImageLoader.loadDrawable(
    							shopCardVo.showCaseList.get(0).itemImgUrl, showCaseLeftView, 0, 0, false, false, event);
    					
    				}
    			});
        		showCaseLeftView.setTag(shopCardVo.showCaseList.get(0).itemId);
        		loadProgressImg(shopCardVo.showCaseList.get(0).itemImgUrl, showCaseLeftView);
    		}
            else {
                showCaseLeftView.setVisibility(View.GONE);
            }
    		
    		if(shopCardVo.showCaseList != null && shopCardVo.showCaseList.size() > 1
                    && shopCardVo.showCaseList.get(1) != null
                    && StringUtils.isNotEmpty(shopCardVo.showCaseList.get(1).itemImgUrl)) {
    			showCaseRightView.setDoubleOnClickListener(this, new OnClickListener() {
    				
    				@Override
    				public void onClick(View v) {
    					asyncImageLoader.loadDrawable(
    							shopCardVo.showCaseList.get(1).itemImgUrl, showCaseRightView, 0, 0, false, false, event);
    					
    				}
    			});
        		showCaseRightView.setTag(shopCardVo.showCaseList.get(1).itemId);
        		loadProgressImg(shopCardVo.showCaseList.get(1).itemImgUrl, showCaseRightView);
    		}
            else {
                showCaseRightView.setVisibility(View.GONE);
            }

    	}
    	else {
    		contentContainer.setVisibility(View.GONE);
    		loadingBar.setVisibility(View.GONE);
    		loadingFailView.setVisibility(View.VISIBLE);
    	}
    }
    
    private IProgressImgLoaderEvent event = new IProgressImgLoaderEvent() {
		
		@Override
		public void imageLoaded(ImageView imageView, Bitmap bitmap, String imageUrl) {
			if(bitmap != null && imageView instanceof ProgressImageView) {
				ProgressImageView progressImageView = (ProgressImageView)imageView;
				progressImageView.setDrawableDone(true);
				if(progressImageView.isShown()) {									
					progressImageView.setImageDrawable(
							new BitmapDrawable(ShopFragment.this.getResources(), bitmap));
				}
			}
		}

		@Override
		public void imageLoadedStart(ImageView imageView) {
			((ProgressImageView) imageView).setDrawableDone(false);
		}

		@Override
		public void imageLoading(ImageView imageView,
				float progress) {
			((ProgressImageView) imageView).setProgress(progress);
		}

		@Override
		public void imageLoadedFailed(ImageView imageView) {
			((ProgressImageView) imageView).setDrawableFailed(true);
			
		}

	};
    
    private void loadProgressImg(String url, ProgressImageView progressImgView) {
    	Bitmap bitmap = asyncImageLoader.loadDrawable(url, progressImgView, event);
		if(bitmap != null) {
			progressImgView.setDrawableDone(true);
			progressImgView.setImageDrawable(
					new BitmapDrawable(getResources(), bitmap));
		}
    }

    private void updatePromotion(String[] proStrs) {
        if (proStrs == null || proStrs.length == 0) {
            promotionViewLayout.setVisibility(View.GONE);
        } else {
            promotionViewLayout.setOnClickListener(this);
            promotionView.setTexts(proStrs);
        }
    }
	
	private void updateCat(String name, String id, int num, int index) {
		if(StringUtils.isBlank(name) && StringUtils.isBlank(id)) {
			catViews[index].setVisibility(View.GONE);
		}
		else {
			catViews[index].setText(name + "  " + num);
			catViews[index].setTag(R.id.tag_cat_id, id);
			catViews[index].setTag(R.id.tag_cat_name, name);
			catViews[index].setOnClickListener(this);
		}
	}

	public void setSubState(boolean isSub) {
		if(isSub) {
            subImgView.setCompoundDrawablesWithIntrinsicBounds(
                    R.drawable.mall_detail_sub, 0, 0, 0);
		}
		else {
            subImgView.setCompoundDrawablesWithIntrinsicBounds(
                    R.drawable.mall_detail_not_sub, 0, 0, 0);
		}
	}
	
	public void setSubClickable(boolean clickable) {
		subImgView.setClickable(clickable);
	}

	@Override
	public void onClick(View view) {
		switch (view.getId()) {
		case R.id.shop_promotion_layout:
			fragmentBridge.showAllPromotion(shopCardVo.promotionList);
			break;
		case R.id.shop_cat_1_1:
		case R.id.shop_cat_1_2:
		case R.id.shop_cat_2_1:
		case R.id.shop_cat_2_2: {
				Intent intent = new Intent();
				intent.putExtra(ConstantsActivity.INTENT_SHOP_DETAIL_ID, shopId);
				intent.putExtra(ConstantsActivity.INTENT_SHOP_CAT_ID, (String)view.getTag(R.id.tag_cat_id));
				intent.putExtra(ConstantsActivity.INTENT_SHOP_CAT_NAME, (String)view.getTag(R.id.tag_cat_name));
                int length = shopCardVo.catList.size();
                String[] catIdStrs = new String[length];
                String[] catNameStrs = new String[length];
                for(int i = 0; i < length; i++) {
                    catIdStrs[i] = shopCardVo.catList.get(i).catId;
                    catNameStrs[i] = shopCardVo.catList.get(i).catName;
                }
                intent.putExtra(ConstantsActivity.INTENT_SHOP_ALL_CAT_ID, catIdStrs);
                intent.putExtra(ConstantsActivity.INTENT_SHOP_ALL_CAT_NAME, catNameStrs);
                intent.putExtra(ConstantsActivity.INTENT_SHOP_TEL, shopCardVo.tel);
				intent.setClass(getActivity(), ShoppingCmdyPagerActivity.class);
				fragmentBridge.startNextActivity(intent);
			}
			break;
		case R.id.shop_card_item_img_1:
		case R.id.shop_card_item_img_2:  {
				Intent intent = new Intent();
				intent.putExtra(ConstantsActivity.INTENT_SHOP_DETAIL_ID, shopId);
				intent.putExtra(ConstantsActivity.INTENT_SHOP_ITEM_ID, (String)view.getTag());
				intent.putExtra(ConstantsActivity.INTENT_SHOP_CAT_NAME, "全部商品");
                int length = shopCardVo.catList.size();
                String[] catIdStrs = new String[length];
                String[] catNameStrs = new String[length];
                for(int i = 0; i < length; i++) {
                    catIdStrs[i] = shopCardVo.catList.get(i).catId;
                    catNameStrs[i] = shopCardVo.catList.get(i).catName;
                }
                intent.putExtra(ConstantsActivity.INTENT_SHOP_ALL_CAT_ID, catIdStrs);
                intent.putExtra(ConstantsActivity.INTENT_SHOP_ALL_CAT_NAME, catNameStrs);
                intent.putExtra(ConstantsActivity.INTENT_SHOP_TEL, shopCardVo.tel);
                intent.setClass(getActivity(), ShoppingCmdyPagerActivity.class);
				fragmentBridge.startNextActivity(intent);
			}			
			break;
		case R.id.shop_event_sub:
			fragmentBridge.changeShopSub(pos, shopId);
			break;		
//		case R.id.shop_event_share:
//			fragmentBridge.shareToWX(pos);
//			break;
		case R.id.shop_event_page:
			Intent intentPage = new Intent();
			intentPage.setClass(getActivity(), ShopPageActivity.class);
            intentPage.putExtra(ConstantsActivity.INTENT_SHOP_INDEX, pos);
			intentPage.putExtra(ConstantsActivity.INTENT_SHOP_ID, shopId);
			fragmentBridge.startNextActivity(intentPage, ConstantsActivity.MALL_DETAIL_REQ_SUB);
			break;
		}
	}
    
    public static interface FragmentBridge {
    	public ShopCardVo getCardData(int index);
    	public void startLoadingCard(int index, String shopId);
    	public ProgressImgLoader getProgressImgLoader();
    	
    	public void showAllPromotion(List<PromotionItem> promotionList);
    	public void changeShopSub(int index, String shopId);
    	public void startNextActivity(Intent intent);
        public void startNextActivity(Intent intent, int reqCode);
    	public void shareToWX(int index);

    }
}
