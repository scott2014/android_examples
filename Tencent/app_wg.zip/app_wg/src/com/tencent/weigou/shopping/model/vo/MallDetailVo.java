package com.tencent.weigou.shopping.model.vo;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.tencent.weigou.base.model.vo.CommonVo;

public class MallDetailVo extends CommonVo {
	
	public String bgUrl;
	public String mallId;
	public String mallName;
	public boolean isSubs;
	
	public List<PromotionItem> promotionList;
	public List<CatItem> catList;
	
	
	/**
	 * called by bg Thread
	 */
	@Override
	public boolean parse(JSONObject jo) {
		if(jo != null) {
			
			/**
			 * 处理Json填充itemList
			 */
			try {				
				bgUrl = jo.optString("backGroudUrl", "").trim();
				mallId = jo.optString("mallId", "").trim();
				mallName = jo.optString("mallName", "").trim();
				int isSubsInt = jo.optInt("userSubscribled", 0);
				if(isSubsInt > 0) {
					isSubs = true;
				}
				else {
					isSubs = false;
				}
				
				JSONArray catArray = jo.optJSONArray("categories");
				if(catArray != null && catArray.length() > 0) {
					int length = catArray.length();
					catList = new ArrayList<CatItem>(length);
					for(int i = 0; i < length; i++) {
						JSONObject catObj = catArray.getJSONObject(i);
						CatItem catItem = new CatItem();
						catItem.catId = catObj.optString("id", "").trim();
						catItem.catName = catObj.optString("name", "").trim();
						catList.add(catItem);
					}
				}
				
				JSONArray promotionArray = jo.optJSONArray("promotion");
				if(promotionArray != null && promotionArray.length() > 0) {
					int length = promotionArray.length();
					promotionList = new ArrayList<PromotionItem>(length);
					for(int i = 0; i < length; i++) {
						JSONObject promotionObj = promotionArray.getJSONObject(i);
						PromotionItem promotionItem = new PromotionItem();
						promotionItem.activityUrl = promotionObj.optString("activityUrl", "").trim();
						promotionItem.beginTime = promotionObj.optLong("beginTime", 0);
						promotionItem.desc = promotionObj.optString("desc", "").trim();
						promotionItem.endTime = promotionObj.optLong("endTime", 0);
						promotionItem.imageUrl = promotionObj.optString("imageUrl", "").trim();
						promotionItem.title = promotionObj.optString("title", "").trim();
						promotionItem.activityId = promotionObj.optInt("activityId", 0);
						promotionItem.sponsorId = promotionObj.optInt("sponsorId", 0);
						promotionItem.sponsorType = promotionObj.optInt("sponsorType", 0);
						promotionItem.type = promotionObj.optInt("type", 0);
						promotionList.add(promotionItem);
					}
				}				
			} catch (JSONException e) {
				return false;
			}
					
			return true;
		}
		return false;
	}
	

	public static class PromotionItem {
		public int activityId;
		public String activityUrl;
		public long beginTime;
		public String desc;
		public long endTime;
		public String imageUrl;
		public int sponsorId;
		public int sponsorType;
		public String title;
		public int type;		
	}
	
	public static class CatItem {
		public String catId;
		public String catName;
	}
	
}
