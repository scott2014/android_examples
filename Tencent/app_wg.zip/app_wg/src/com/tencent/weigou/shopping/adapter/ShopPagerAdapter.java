package com.tencent.weigou.shopping.adapter;

import com.tencent.weigou.shopping.fragment.ShopFragment;
import com.tencent.weigou.shopping.model.vo.ShopPagerVo;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.util.SparseArray;
import android.view.ViewGroup;

public class ShopPagerAdapter extends FragmentStatePagerAdapter {
	
	private ShopPagerVo shopPagerVo;
	SparseArray<Fragment> registeredFragments = new SparseArray<Fragment>();

	public ShopPagerAdapter(FragmentManager fm) {
		super(fm);
	}

	@Override
	public Fragment getItem(int position) {
		return ShopFragment.newInstance(position, shopPagerVo.shopList.get(position));
	}

	@Override
	public int getCount() {
		if(shopPagerVo == null ||
				shopPagerVo.shopList == null ||
				shopPagerVo.shopList.size() == 0) {
			return 0;
		}
		return shopPagerVo.shopList.size();
	}
	
	@Override
    public Object instantiateItem(ViewGroup container, int position) {
        Fragment fragment = (Fragment) super.instantiateItem(container, position);

        registeredFragments.put(position, fragment);
        return fragment;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        registeredFragments.remove(position);
        super.destroyItem(container, position, object);
    }

    public Fragment getRegisteredFragment(int position) {
        return registeredFragments.get(position);
    }

	public void setMallDetailVo(ShopPagerVo shopPagerVo) {
		this.shopPagerVo = shopPagerVo;
	}
	
	/**
	 * invoke when shopList increments and decrement
	 */
	public void updateVo() {
		notifyDataSetChanged();
	}

}
