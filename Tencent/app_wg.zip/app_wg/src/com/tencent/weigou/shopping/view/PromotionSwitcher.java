package com.tencent.weigou.shopping.view;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.RelativeSizeSpan;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextSwitcher;
import android.widget.TextView;
import android.widget.ViewAnimator;

import com.tencent.weigou.R;
import com.tencent.weigou.util.Util;

/**
 * Created by branjing on 13-12-31.
 */
public class PromotionSwitcher extends ViewAnimator {

    private Context mContext;
    private String[] mTexts;
    private Handler mHandler = new Handler();
    private boolean mCanSwitch = false;

    /**
     * Creates a new empty PromotionSwitcher.
     *
     * @param context the application's environment
     */
    public PromotionSwitcher(Context context) {
        super(context);
    }

    /**
     * Creates a new empty PromotionSwitcher for the given context and with the
     * specified set attributes.
     *
     * @param context the application environment
     * @param attrs a collection of attributes
     */
    public PromotionSwitcher(Context context, AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
    }

    public void setTexts(String[] texts) {
        if(mTexts != null) {
            mHandler.removeCallbacks(mCycleMove);
            removeAllViews();
        }
        mTexts = texts;
        if(mTexts != null) {
            int length = mTexts.length;
            int index = 0;
            for(int i = 0; i < length; i++) {
                if(mTexts[i] !=null && mTexts[i].length() > 0) {
                    final TextView child = new TextView(mContext);
                    child.setSingleLine();
                    child.setTextColor(getResources().getColor(R.color.white_gray_selector));
                    child.setDuplicateParentStateEnabled(true);
                    child.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
                    child.setText(mTexts[i]);
                    final FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
                    addView(child, index++, lp);
                }
            }
            if(getChildCount() > 1) {
                mCanSwitch = true;
                mHandler.postDelayed(mCycleMove, 3000);
            }
        }
    }

    private Runnable mCycleMove = new Runnable() {
        @Override
        public void run() {
            PromotionSwitcher.this.showNext();
        }
    };

    /**
     * Manually shows the next child.
     */
    @Override
    public void showNext() {
        super.showNext();
        mHandler.postDelayed(mCycleMove, 3000);
    }
}
