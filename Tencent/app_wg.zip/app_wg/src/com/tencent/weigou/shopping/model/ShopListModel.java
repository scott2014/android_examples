package com.tencent.weigou.shopping.model;

import com.tencent.weigou.base.model.Model;
import com.tencent.weigou.shopping.model.vo.ShopListVo;

/**
 * 
 * @ClassName： ShopListModel
 *
 * @Description： 品牌下门店列表Model
 * @author wamiwen
 * @date 2013-12-5 上午10:10:50
 *
 */
public class ShopListModel extends Model {
    // 获取品牌下门店列表
	public final static int GET_SHOP_LIST = 0;
	
	private ShopListVo shopListVo;
	
	@Override
	public void initData(String url) {
		super.initData(url);
		shopListVo = new ShopListVo();
		createNetWorkTask(url, shopListVo, GET_SHOP_LIST);
	}

	public ShopListVo getShopListVo() {
		return shopListVo;
	}
}
