package com.tencent.weigou.shopping.model;

import com.tencent.weigou.base.model.Model;
import com.tencent.weigou.shopping.model.vo.CityVo;

public class CityModel extends Model {
	CityVo vo;

	@Override
	public void initData(String cityName) {
		
		vo = new CityVo(cityName);
		notify(vo);
	}

}
