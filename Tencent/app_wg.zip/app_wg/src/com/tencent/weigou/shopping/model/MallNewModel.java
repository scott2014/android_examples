package com.tencent.weigou.shopping.model;

import com.tencent.weigou.base.model.Model;
import com.tencent.weigou.shopping.model.vo.MallNewVo;

/**
 * 逛-商场-上新model
 * User: ethonchan
 * Date: 13-12-4
 * Time: 下午3:37
 */
public class MallNewModel extends Model{
    //  获取上新信息
    public final static int GET_MALL_NEW  = 0;

    private MallNewVo mMallNewVo;

    @Override
    public void initData(String url) {
        mMallNewVo = new MallNewVo();
        createNetWorkTask(url, mMallNewVo, GET_MALL_NEW);
    }

    public MallNewVo getMallNewVo() {
        return mMallNewVo;
    }
}
