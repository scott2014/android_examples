package com.tencent.weigou.shopping.model.vo;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.tencent.weigou.base.model.vo.CommonVo;
import com.tencent.weigou.shopping.utils.ShoppingUtils;

public class RegionVo extends CommonVo {
	public List<RegionItemVo> malls = new ArrayList<RegionVo.RegionItemVo>();
	public List<RegionItemVo> circles = new ArrayList<RegionVo.RegionItemVo>();

	@Override
	public boolean parse(JSONObject jo) {
		try {
			JSONArray mallsJson = jo.optJSONObject("mallNearBy").optJSONArray(
					"mallList");
			for (int i = 0; i < mallsJson.length(); i++) {
				RegionItemVo riv = new RegionItemVo();

				riv.distance = ShoppingUtils.reguleDistance(mallsJson
						.getJSONObject(i).optString("distance"));
				riv.name = mallsJson.getJSONObject(i).optString("mallName");
				riv.url = mallsJson.getJSONObject(i).optString("landscapePic");
				riv.logo = mallsJson.getJSONObject(i).optString("logo");
				riv.id = mallsJson.getJSONObject(i).optString("mallId");
				malls.add(riv);

			}
			JSONArray circleJson = jo.optJSONArray("businessCircleList");
			for (int i = 0; i < circleJson.length(); i++) {
				RegionItemVo riv = new RegionItemVo();
				riv.name = circleJson.getJSONObject(i).optString(
						"businessCircleName");
				riv.id = circleJson.getJSONObject(i).optString(
						"businessCircleId");
				circles.add(riv);

			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public class RegionItemVo {

		public String name;
		public String distance;
		public String url;
		public String logo;
		public String id;
	}
}
