package com.tencent.weigou.shopping.utils;

public class ShoppingUtils {
	public static String reguleDistance(String dis) {
		int distance = 1000;
		try {
			distance = Integer.parseInt(dis);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (distance > 999) {
			return (distance / 1000) + "公里";
		}
		return distance + "米";
	}
	
	public static String reguleDistance(int dis) {
		if (dis > 999) {
			return (dis / 1000) + "公里";
		}
		return dis + "米";
	}
}
