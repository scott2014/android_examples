package com.tencent.weigou.shopping.view;

import com.tencent.weigou.util.StringUtils;
import com.tencent.weigou.util.Util;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Paint.FontMetrics;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.widget.ImageView;

public class ProgressImageView extends ImageView {

	public ProgressImageView(Context context, AttributeSet attrs) {
		super(context, attrs);
		this.context = context;
		progressHeight = Util.dip2px(context, 10);
		
		//set Paint to save time on Draw
		textPaint = new Paint();
		textPaint.setAntiAlias(true);
		textPaint.setColor(Color.WHITE); 
		textPaint.setTextSize(Util.dip2px(context, 16));		
		fontMetrics = textPaint.getFontMetrics();
		
		rectFPaint = new Paint();			            
		rectFPaint.setStyle(Paint.Style.FILL);
        rectFPaint.setAntiAlias(true);
        
        loadingTextHeight = Util.dip2px(context, 5);
	}

	private Context context;
	
	private int progressWidth;
	private int progressHeight;
	
	private float progress;
	private boolean drawableDone = true;
	private boolean drawableFailed = false;
	private String loadingTips = "";
	private int loadingTextHeight;
	
	private OnClickListener realOnClickListener;
	private OnClickListener reloadClickListener;
			
	private Paint textPaint;
	private FontMetrics fontMetrics;
	private Paint rectFPaint;
	private RectF rectF = new RectF();

	
	
	

	//reLoader.loadDrawable(url, ProgressImageView.this, 0, 0, false, false, event);

	public void setDoubleOnClickListener(OnClickListener realOnClickListener, OnClickListener reloadClickListener) {
		this.realOnClickListener = realOnClickListener;
		this.reloadClickListener = reloadClickListener;
	}
	
	@Override
	public void setOnClickListener(OnClickListener realOnClickListener) {
		this.realOnClickListener = realOnClickListener;
	}
	
	public void setReloadClickListener(OnClickListener reloadClickListener) {
		this.reloadClickListener = reloadClickListener;
	}
	
	public void setLoadingTips(String loadingTips) {
		this.loadingTips = loadingTips;
	}
    
    public void setProgress(float progress) {
    	this.progress = progress;
    	//Log.d("Bran", "progress = " + progress);
    	if(!drawableDone) {
    		invalidate();
    	}
    }
    
    
	public void setDrawableDone(boolean drawableDone) {
		boolean oldDrawableDone = this.drawableDone;
		this.drawableDone = drawableDone;
		drawableFailed = false;
		if(drawableDone) {
			if (realOnClickListener == null) {
				setClickable(false);
			} else {
				super.setOnClickListener(realOnClickListener);
			}
		}
		else {
			super.setOnClickListener(null);
		}
		if(oldDrawableDone != this.drawableDone) {
			invalidate();
		}
	}
	
	public void setDrawableFailed(boolean drawableFailed) {
		boolean oldDrawableFailed = this.drawableFailed;
		this.drawableFailed = drawableFailed;
		drawableDone = true;
		if(drawableFailed) {
			super.setOnClickListener(reloadClickListener);
		}
		if(oldDrawableFailed != this.drawableFailed) {
			invalidate();
		}
	}

	
	@Override 
    protected void onDraw(Canvas canvas) {
		int height = getHeight();
		int width = getWidth();
		
		if(drawableDone && !drawableFailed) {
			//Log.d("Bran", "draw drawable");
			super.onDraw(canvas);
			
		}
		else if(drawableFailed){
			//Log.d("Bran", "draw reload");
			
			float fontHeight = fontMetrics.bottom - fontMetrics.top;
			float textBaseY = height - (height - fontHeight) / 2 - fontMetrics.bottom;
			textPaint.setTextAlign(Align.CENTER);
			canvas.drawText("点击重新加载", width / 2, textBaseY, textPaint);
		}
		else {
			//Log.d("Bran", "draw progress bar " + progress);
			
			rectFPaint.setColor(Color.parseColor("#F5F5F5"));
            float left = (float) ((width - progressWidth) / 2.0);
            float right = left + progressWidth;
            float top = (float) ((height - progressHeight) / 2.0);
            float bottom = top + progressHeight;
            rectF.set(left, top, right, bottom);
            canvas.drawRoundRect(rectF, progressHeight / 2, progressHeight / 2, rectFPaint);
            
            rectFPaint.setColor(Color.parseColor("#E0D9EB"));
            float length = right - left - 2;
            left = left + 1;
            right = left + length * progress ;
            top = top + 1;
            bottom = bottom - 1;
            rectF.set(left, top, right, bottom);
            canvas.drawRoundRect(rectF, (bottom - top) / 2, (bottom - top) / 2, rectFPaint);
            
            if (StringUtils.isNotBlank(loadingTips)) {
            	float fontHeight = fontMetrics.bottom - fontMetrics.top;
    			float textBaseY = bottom + fontHeight + loadingTextHeight;
    			textPaint.setTextAlign(Align.CENTER);
    			textPaint.setColor(Color.parseColor("#333333"));
    			canvas.drawText(loadingTips, width / 2, textBaseY, textPaint);
			}
		}
	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		
		int width = getMeasuredWidth();
		if(width > Util.dip2px(context, 120)) {
			progressWidth = Util.dip2px(context, 100);
		}
		else if(width < Util.dip2px(context, 70)) {
			progressWidth = width - Util.dip2px(context, 50);
		}
		else {
			progressWidth = width - Util.dip2px(context, 20);
		}
		
	}
	
}
