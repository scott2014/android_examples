package com.tencent.weigou.shopping.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.tencent.weigou.R;
import com.tencent.weigou.base.App;
import com.tencent.weigou.base.activity.TitleBarActivity;
import com.tencent.weigou.mqqapi.MobileQQUtils;
import com.tencent.weigou.shopping.model.CmdyPagerModel;
import com.tencent.weigou.shopping.model.vo.CmdyVo;
import com.tencent.weigou.shopping.model.vo.CmdyVo.CmdyItemVo;
import com.tencent.weigou.shopping.view.CmdyPagerUI;
import com.tencent.weigou.shopping.view.CmdyPagerUI.OnPageListener;
import com.tencent.weigou.util.Constants;
import com.tencent.weigou.util.ConstantsActivity;
import com.tencent.weigou.util.ConstantsUrl;
import com.tencent.weigou.util.PageIds.OprIndex;
import com.tencent.weigou.util.StringUtils;
import com.tencent.weigou.util.Util;
import com.tencent.weigou.web.WebKitActivity;
import com.tencent.weigou.web.WebkitConstants;
import com.tencent.weigou.wxapi.WXUtils;

public class ShoppingCmdyPagerActivity extends TitleBarActivity implements
		OnClickListener, OnPageListener {

	private static final int PAGE_SIZE = 20;
	private CmdyPagerModel model = new CmdyPagerModel();
	private CmdyPagerUI ui = new CmdyPagerUI();
	int index = 0;
	String itemId = "";
	String url = "";
	int pn = 1;
	int pnStart = 0;
	int curr;
	String shopId = "";
	boolean noPage = false;
	String source = "";
	public String catName;
	String tel;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// 初始化mvc框架
		initMVC(model, ui, R.layout.shopping_cmdy_pager);
		initTopBar();
		topbar.initRightBtnB(R.drawable.top_bar_nav_selector, "", this);
		topbar.initRightBtnA(0, "列表", this);
		// topbar.findViewById(R.id.top_bar_arrow).setVisibility(View.VISIBLE);
		LayoutParams lp = topbar.getLayoutParams();
		lp.height = Util.dip2px(this, 60);
		init();

	}

	private void initTopBar() {
		RelativeLayout.LayoutParams rll = (RelativeLayout.LayoutParams) findViewById(
				R.id.content_inflated).getLayoutParams();
		rll.addRule(RelativeLayout.BELOW, -1);
		initBackBtn();
	}

	private void init() {
		StringBuffer sb = new StringBuffer(App.getInstance().getEnv()
				.getServerUrl());
		shopId = getIntent().getStringExtra(
				ConstantsActivity.INTENT_SHOP_DETAIL_ID);
		source = getIntent().getStringExtra(
				ConstantsActivity.INTENT_SOURCE_ACTIVITY);
		if (!StringUtils.isBlank(shopId)) {
			String catId = getIntent().getStringExtra(
					ConstantsActivity.INTENT_SHOP_CAT_ID);
			itemId = getIntent().getStringExtra(
					ConstantsActivity.INTENT_SHOP_ITEM_ID);
			String title = getIntent().getStringExtra(
					ConstantsActivity.INTENT_SHOP_CAT_NAME);
			tel = getIntent().getStringExtra(ConstantsActivity.INTENT_SHOP_TEL);
			if (StringUtils.isBlank(shopId)) {
				return;
			}

			if (StringUtils.isBlank(catId)) {
				sb.append(ConstantsUrl.SHOPPING_CMDY_BY_SHOP).append("?shId=")
						.append(shopId).append("&ps=").append(PAGE_SIZE)
						.append("&pn=").append(pn);
			} else {
				sb.append(ConstantsUrl.SHOPPING_CMDY_BY_CAT).append("?shId=")
						.append(shopId).append("&categoryId=").append(catId)
						.append("&ps=").append(PAGE_SIZE).append("&pn=")
						.append(pn);
			}
			setTitle(title);
		} else if ("FavActivity".equals(source)) {
			try {
				index = Integer.parseInt(getIntent().getStringExtra(
						ConstantsActivity.INTENT_CMDY_INDEX));
			} catch (Exception e) {
				index = 0;
			}
			String title = getIntent().getStringExtra(
					ConstantsActivity.INTENT_CMDY_LIST_TITLE);
			setTitle(title);
			topbar.findViewById(R.id.top_bar_right_1_tv).setVisibility(
					View.INVISIBLE);
			topbar.findViewById(R.id.top_bar_right_2_tv).setVisibility(
					View.INVISIBLE);
			Object cvo = getIntent().getSerializableExtra(
					ConstantsActivity.INTENT_CMDY_NAV_DATA);
			if (cvo != null && cvo instanceof CmdyVo) {
				CmdyVo cv = (CmdyVo) getIntent().getSerializableExtra(
						ConstantsActivity.INTENT_CMDY_NAV_DATA);
				model.cmdyVo = cv;
				ui.updateContent(cv);
				sb.append(ConstantsUrl.MY_FAV_LIST).append("?nd=1&ptp=2")
						.append("&ps=" + PAGE_SIZE).append("&pn=0");
				url = sb.toString();
				url = appendPageInfo(url, OprIndex.PV_OPR);
				if (StringUtils.isBlank(itemId)) {
					ui.select(index);
				}
			}
			return;
		} else {
			try {
				index = Integer.parseInt(getIntent().getStringExtra(
						ConstantsActivity.INTENT_CMDY_INDEX));
			} catch (Exception e) {
				index = 0;
			}

			itemId = getIntent().getStringExtra(
					ConstantsActivity.INTENT_SHOP_ITEM_ID);
			String ids = getIntent().getStringExtra(
					ConstantsActivity.INTENT_CMDY_IDS);
			String title = getIntent().getStringExtra(
					ConstantsActivity.INTENT_CMDY_LIST_TITLE);
			sb.append(ConstantsUrl.SHOPPING_CMDY_LIST_BY_IDS).append("?itIds=")
					.append(ids).append("&ns=1");
			setTitle(title);
			topbar.findViewById(R.id.top_bar_right_1_tv).setVisibility(
					View.INVISIBLE);
			topbar.findViewById(R.id.top_bar_right_2_tv).setVisibility(
					View.INVISIBLE);
			noPage = true;

		}

		url = sb.toString();
		url = appendPageInfo(url, OprIndex.PV_OPR);
		model.initData(url);
	}

	@Override
	public void update(int notificationId) {
		super.update(notificationId);
		if (!StringUtils.isBlank(tel)) {
			for (CmdyItemVo civ : model.cmdyVo.list) {
				civ.tel = tel;
			}
		}
		switch (notificationId) {
		case CmdyPagerModel.INIT_DATA:
		case CmdyPagerModel.INIT_FAV_LIST_DATA:
			model.cmdyVo.list.addAll(model.cmdyVo.tmpList);
			ui.updateContent(model.cmdyVo);
			if (StringUtils.isBlank(itemId)) {
				ui.select(index);
			} else {
				ui.select(itemId);
			}
			break;
		case CmdyPagerModel.RE_INIT_DATA:
			model.cmdyVo.list.addAll(model.cmdyVo.tmpList);
			ui.updateContent(model.cmdyVo);
			ui.selectCatList(catName);
			break;
		case CmdyPagerModel.NEXT_DATA:
			model.cmdyVo.list.addAll(model.cmdyVo.tmpList);
			ui.refresh(model.cmdyVo.list);
			break;
		case CmdyPagerModel.NEXT_FAV_LIST_DATA:
			model.cmdyVo.list.addAll(model.cmdyVo.tmpList);
			ui.refresh(model.cmdyVo.list);
			break;
		case CmdyPagerModel.SHOPPING_CMDY_ADD_FAV:
			if (model.cmdyVo.errorCode == 0) {
				ui.buy(1);
				// showToast("加入购物单成功");
			} else if (model.cmdyVo.errorCode == 18) {
				ui.buy(1);
				// showToast("加入购物单成功");
			} else {
				ui.buy(0);
				showToast("加入购物单失败");
			}

			break;
		case CmdyPagerModel.SHOPPING_CMDY_DEL_FAV:
			if (model.cmdyVo.errorCode == 0) {
				// showToast("从购物单中删除成功");
				ui.buy(0);
			} else {
				ui.buy(1);
				showToast("从购物单中删除失败");
			}
			break;
		}
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.cmdy_online_tv:
			ui.showOnline();
			break;
		case R.id.cmdy_more_pic_tv:
			if (v.getTag() != null && v.getTag() instanceof CmdyItemVo) {
				CmdyItemVo civ = (CmdyItemVo) v.getTag();
				if (civ != null) {
					Intent it = new Intent();
					it.putExtra(ConstantsActivity.INTENT_CMDY_ID, civ.id);
					it.setClass(this, ShoppingCmdyActivity.class);
					startActivity(it);
				}
			}
			break;
		case R.id.cmdy_more_tv:
			ui.showMore();
			break;
		case R.id.top_bar_right_1_tv:
		case R.id.top_bar_right_2_tv:
			Intent intent = new Intent();
			Bundle bundle = app.getShareData();
			bundle.putSerializable(ConstantsActivity.INTENT_CMDY_NAV_DATA,
					model.cmdyVo);
			bundle.putString(ConstantsActivity.INTENT_CMDY_NAV_URL, url);
			bundle.putInt(ConstantsActivity.INTENT_CMDY_PN, pn);
			intent.setClass(this, NavCmdyListActivity.class);
			startActivityForResult(intent, ConstantsActivity.CMDY_REQ_CODE_NAV);
			overridePendingTransition(R.anim.in_from_up, 0);
			break;
		case R.id.cmdy_buy_tv:
			if (v.getTag() != null && v.getTag() instanceof CmdyItemVo) {
				CmdyItemVo civ = (CmdyItemVo) v.getTag();
				doFav(civ.userFavorited);
			}
			break;
		// case R.id.cmdy_share_tv:
		// shareToWX();
		// break;
		// case R.id.cmdy_talk_tv:
		// showToast("咨询店员功能正在开发中。。。");
		// break;
		case R.id.shopping_cmdy_cat:
			if (v.getTag() != null && v.getTag() instanceof String) {
				String cat = v.getTag().toString();
				String[] cats = cat.split(":");
				// if (catName.equals(cats[0])) {
				// return;
				// }
				pn = 1;
				StringBuffer sb = new StringBuffer(App.getInstance().getEnv()
						.getServerUrl());

				if (cat.indexOf(":") > -1 && cats.length == 2) {
					catName = cats[0];
					String id = cats[1];

					sb.append(ConstantsUrl.SHOPPING_CMDY_BY_CAT)
							.append("?shId=").append(shopId)
							.append("&categoryId=").append(id).append("&ps=")
							.append(PAGE_SIZE).append("&pn=").append(pn);

				} else {
					catName = cats[0];
					sb.append(ConstantsUrl.SHOPPING_CMDY_BY_SHOP)
							.append("?shId=").append(shopId).append("&ps=")
							.append(PAGE_SIZE).append("&pn=").append(pn);
				}
				String url = sb.toString();
				url = appendPageInfo(url, OprIndex.PV_OPR);
				model.reInitData(url);
			}
			break;
		}

		if (v.getTag() != null && v.getTag() instanceof CmdyItemVo) {
			CmdyItemVo civ = (CmdyItemVo) v.getTag();
			switch (v.getId()) {
			case R.id.cmdy_tel:
				if (StringUtils.isNotBlank(civ.tel)) {
					// 用intent启动拨打电话
					Intent intent = new Intent(Intent.ACTION_DIAL,
							Uri.parse("tel:" + civ.tel));
					startActivity(intent);
				} else {
					Toast.makeText(this, R.string.no_seller_telephone,
							Constants.TOAST_NORMAL_LONG).show();
				}
				ui.hidePop();
				break;
			case R.id.cmdy_qq:
				if (StringUtils.isNotBlank(civ.sellerUin)
						&& !"0".equals(civ.sellerUin)) {
					MobileQQUtils.startQQTalk(this, civ.sellerUin);
				} else {
					Toast.makeText(this, R.string.no_seller_qq,
							Constants.TOAST_NORMAL_LONG).show();
				}
				ui.hidePop();
				break;
			case R.id.cmdy_circle:
				if (!WXUtils.isWXInstalled(this)) {
					onWechatNotInstalled();
				} else if (!WXUtils.supportTimeLine(this)) {
					onWechatNeedUpdate();
				} else {
					onShare2WechatTimeline();
				}
				ui.hidePop();
				break;
			case R.id.cmdy_friend:
				if (!WXUtils.isWXInstalled(this)) {
					onWechatNotInstalled();
				} else if (!WXUtils.supportSDK(this)) {
					onWechatNeedUpdate();
				} else {
					onShare2WechatFriends();
				}
				ui.hidePop();
				break;
			case R.id.online_buy:
				Intent it = new Intent();
				String url = "http://weigou.qq.com/prevwshop/wx/item/detail4app.shtml?ic="
						+ civ.ic
						+ "&wk2="
						+ getXtk()
						+ "&crmuin="
						+ getWid()
						+ "&commid=" + app.getUser().commId + "&wgclient=app_1";
				if (WXUtils.supportWXPay(ShoppingCmdyPagerActivity.this)) {
					url += "&app_wxpay=1";
				}
				it.putExtra(WebkitConstants.INTENT_URL, url);
				it.putExtra(WebkitConstants.INTENT_TITLE, civ.name);
				it.setClass(this, WebKitActivity.class);
				startActivity(it);
				ui.hidePop();
				break;
			}
		}

	}

	public void doFav(int faved) {

		StringBuffer sb = new StringBuffer(((App) getApplication()).getEnv()
				.getServerUrl());
		int noti = 0;
		if (faved == 0) {
			ui.buy(1);
			sb.append(ConstantsUrl.SHOPPING_CMD_FAV + "?fid=").append(
					ui.getItemCode());
			noti = CmdyPagerModel.SHOPPING_CMDY_ADD_FAV;
		} else {
			ui.buy(0);
			sb.append(ConstantsUrl.DEL_FAV_ITEM + "?fid=").append(
					ui.getItemCode());
			noti = CmdyPagerModel.SHOPPING_CMDY_DEL_FAV;
		}
		String url = sb.toString();
		url = appendPageInfo(url, OprIndex.USER_OPR);
		model.doFav(url, ui.getItemCode(), noti);

	}

	protected void onShare2WechatTimeline() {
		String shareUrl = "http://api.gamma.xpay.buy.qq.com/api/share/detail.xhtml?itId="
				+ ui.getItemCode();
		WXUtils.shareWebpageToTimeline(this, ui.getTitle(), "这个宝贝不错",
				ui.getImage(), shareUrl);

		// "http://act.m.buy.qq.com/t/showAct.xhtml?tid=share_back_test");

	}

	protected void onShare2WechatFriends() {
		String shareUrl = "http://api.gamma.xpay.buy.qq.com/api/share/detail.xhtml?itId="
				+ ui.getItemCode();
		WXUtils.shareWebpageToFriends(this, ui.getTitle(), "这个宝贝不错",
				ui.getImage(), shareUrl);
		// "http://act.m.buy.qq.com/t/showAct.xhtml?tid=share_back_test");
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		switch (requestCode) {
		case ConstantsActivity.CMDY_REQ_CODE_NAV:
			model.cmdyVo = (CmdyVo) app.getShareData().getSerializable(
					ConstantsActivity.INTENT_CMDY_NAV_DATA);
			pn = app.getShareData().getInt(ConstantsActivity.INTENT_CMDY_PN, 1);
			url = app.getShareData().getString(
					ConstantsActivity.INTENT_CMDY_NAV_URL);
			ui.refresh(model.cmdyVo.list);
			String itemId = data
					.getStringExtra(ConstantsActivity.INTENT_CMDY_ID);
			if (StringUtils.isNotEmpty(itemId)) {
				ui.select(itemId);
			}
			break;

		default:
			break;
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	private void showToast(String msg) {
		View toastRoot = getLayoutInflater().inflate(R.layout.common_toast,
				null);
		TextView message = (TextView) toastRoot.findViewById(R.id.message);
		message.setText(msg);

		Toast toastStart = new Toast(this);
		toastStart.setGravity(Gravity.CENTER, 0, 10);
		toastStart.setDuration(Toast.LENGTH_LONG);
		toastStart.setView(toastRoot);
		toastStart.show();
	}

	@Override
	public void onPage(int position) {
		try {
			if (position == curr || noPage) {
				return;
			}
			curr = position;
			if (!"FavActivity".equals(source)) {
				String tmpPn = "pn=" + pn;
				pn += 1;
				int pz = (int) Math.ceil((double) model.cmdyVo.total
						/ (double) PAGE_SIZE);
				if (pn > pz) {
					return;
				}
				String tmpNextPn = "pn=" + pn;
				url = url.replaceAll(tmpPn, tmpNextPn);
				model.nextData(url);
			} else {
				String tmpPn = "pn=" + pnStart;
				pnStart += model.cmdyVo.getFavList().size();
				String tmpNextPn = "pn=" + pnStart;
				url = url.replaceAll(tmpPn, tmpNextPn);
				model.nextFavData(url);
			}
		} catch (Exception e) {
			e.toString();
		}
		// model.nextData(url);
	}

	@Override
	protected void onDestroy() {
		app.getShareData().clear();
		super.onDestroy();
	}

	@Override
	protected void onNetworkUnavailable(int notificationId) {
		ui.refreshItem();
		super.onNetworkUnavailable(notificationId);
	}
}
