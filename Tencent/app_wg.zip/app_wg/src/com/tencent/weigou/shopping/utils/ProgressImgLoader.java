package com.tencent.weigou.shopping.utils;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v4.util.LruCache;
import android.util.Log;
import android.widget.ImageView;
import com.tencent.stat.StatAppMonitor;
import com.tencent.weigou.base.App;
import com.tencent.weigou.cache.CacheInfo;
import com.tencent.weigou.cache.CacheUtils;
import com.tencent.weigou.common.IDestroy;
import com.tencent.weigou.util.MTAUtils;
import com.tencent.weigou.util.Constants;
import com.tencent.weigou.util.DateUtils;
import com.tencent.weigou.util.StringUtils;
import com.tencent.weigou.util.SysUtils;
import com.tencent.weigou.util.http.base.HttpRequest;
import org.apache.http.HttpStatus;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.SoftReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 异步加载图片类
 * 
 * 这里用存储了一个url和图片的对应关系，当这个url的图片加载完之后，会回调调用者去重新渲染图片
 * 缓存策略是内存缓存（硬引用LruCache、软引用SoftReference<Bitmap>）+本地SD卡文件缓存
 * 
 * @author wendyhu
 * 
 */
public class ProgressImgLoader implements IDestroy {
	private static final String IF_MODIFIED_SINCE = "If-Modified-Since";
	private static final String LAST_MODIFIED = "Last-Modified";
	private static final String LOG_TAG = "AsyncImageLoader";
	
	private static final int START_LAODING_IMAGE_DATA = 0;
	private static final int LAODING_IMAGE_DATA = 1;
	private static final int DONE_LAODING_IMAGE_DATA = 2;
	private static final int FAIL_LAODING_IMAGE_DATA = 3;
	
    //  默认缓冲区大小=4k
    public final static int DEFAULT_BUFFER_SIZE = 1024 * 4;

	/**
	 * 图片需要check lastModifytime时间
	 */
	public static final long mustImageExipreCheckTime = 302400000;

	/**
	 * 硬引用LruCache
	 */
	private LruCache<String, Bitmap> sHardBitmapCache = null;
	/**
	 * 软引用Cache
	 */
	private Map<String, SoftReference<Bitmap>> sSoftBitmapCache = null;
	private ExecutorService executorService = null;

	private static final int MAX_MEMORY_SIZE = (int) (Runtime.getRuntime()
			.maxMemory() / 1024) / 5;
	private static final int MAX_CACHE_SIZE = 4 * 1024 * 1024;
	// 使用最大可用内存值的1/5作为硬缓存的大小
	private static final int HARD_CACHE_SIZE = MAX_MEMORY_SIZE < MAX_CACHE_SIZE ? MAX_MEMORY_SIZE
			: MAX_CACHE_SIZE;
	private static final int SOFT_CACHE_CAPACITY = 50;
	private static final int DEFAULTSIZE = (Runtime.getRuntime()
			.availableProcessors() + 1);


	public ProgressImgLoader() {
		this(DEFAULTSIZE);
	}


	/**
	 * 
	 * <p>
	 * Title: p>
	 * <p>
	 * Description: 初使化异步加载图片类
	 * </p>
	 * 
	 * @param threadCount
	 *            线程个数
	 * @param isNeedFileCache
	 *            是否需要保存到本地
	 */
	@SuppressWarnings("serial")
	public ProgressImgLoader(int threadCount) {

		sHardBitmapCache = new LruCache<String, Bitmap>(HARD_CACHE_SIZE) {

			@Override
			protected int sizeOf(String key, Bitmap value) {
				// 重写此方法来衡量每张图片的大小，默认返回图片数量。
				return value.getRowBytes() * value.getHeight() / 1024;
				
			}

			@Override
			protected void entryRemoved(boolean evicted, String key,
					Bitmap oldValue, Bitmap newValue) {
				Log.v(LOG_TAG, "hard cache is full, push to soft cache");
				// 硬引用缓存满，将一个最不经常使用的oldValue推入到软引用缓存区
				sSoftBitmapCache.put(key, new SoftReference<Bitmap>(oldValue));
			}

		};

		sSoftBitmapCache = new LinkedHashMap<String, SoftReference<Bitmap>>(
				SOFT_CACHE_CAPACITY, 0.75f, true) {

			@Override
			protected boolean removeEldestEntry(
					Entry<String, SoftReference<Bitmap>> eldest) {
				if (size() > SOFT_CACHE_CAPACITY) {
					Log.v(LOG_TAG, "soft reference limit, purge one");
					return true;
				}
				return false;
			}

			@Override
			public SoftReference<Bitmap> put(String key,
					SoftReference<Bitmap> value) {
				Log.v(LOG_TAG, "push to soft cache, key:" + key);
				return super.put(key, value);
			}

		};

		executorService = Executors.newFixedThreadPool(threadCount);
	}

	/**
	 * 
	 * @Title: putBitmapToCache
	 * 
	 * @Description: 缓存Bitmap
	 * @param @param key
	 * @param @param bitmap
	 * @param @return 设定文件
	 * @return boolean 返回类型
	 * @throws
	 */
	public boolean putBitmapToCache(String key, Bitmap bitmap) {
		if (null != bitmap) {
			synchronized (sHardBitmapCache) {
				sHardBitmapCache.put(key, bitmap);
			}
			return true;
		}
		return false;
	}

	/**
	 * 
	 * @Title: getBitmapFromCache
	 * 
	 * @Description: 从缓存中获取Bitmap
	 * @param @param key
	 * @param @return 设定文件
	 * @return Bitmap 返回类型
	 * @throws
	 */
	public Bitmap getBitmapFromCache(String key) {
		synchronized (sHardBitmapCache) {
			final Bitmap bitmap = sHardBitmapCache.get(key);
			if (null != bitmap) {
				return bitmap;
			}
		}
		// 硬引用缓存区间中读取失败，从软引用缓存区间读取
		synchronized (sSoftBitmapCache) {
			SoftReference<Bitmap> bitmapReference = sSoftBitmapCache.get(key);
			if (null != bitmapReference) {
				final Bitmap bitmap = bitmapReference.get();
				if (null != bitmap) {
					return bitmap;
				} else {
					Log.v(LOG_TAG, "soft reference already recycled");
					sSoftBitmapCache.remove(key);
				}
			}
		}
		return null;
	}

	/**
	 * 对发送的HTTP请求进行预处理
	 * 
	 * @param conn
	 * @return
	 */
	protected HttpURLConnection preProcessHttp(HttpURLConnection conn) {
		if (conn != null) {
			try {
				conn.setConnectTimeout(HttpRequest.CONNECT_TIME_OUT);
				conn.setReadTimeout(HttpRequest.READ_TIME_OUT);

				String network = SysUtils.getNetworkType();
				if (SysUtils.NETWORK_CMWAP.equals(network)) {
					String host = conn.getURL().getHost();
					conn.addRequestProperty(HttpRequest.NETWORK_CMWAP_HEADER,
							host);
				}
			} catch (Exception e) {
				// ignore
			}
		}
		return conn;
	}

	/**
	 * 
	 * @Title: downloadFromNet
	 * 
	 * @Description: 从网络中下载图片
	 * @param @param urlStr
	 * @param @param info
	 * @param @return 设定文件
	 * @return boolean 返回类型
	 * @throws
	 */
	private boolean downloadFromNet(String urlStr, CacheInfo cache, Handler handler) {
		boolean finished = false;
		if (null == cache) {
			return finished;
		}
		
		InputStream inputStream = null;
		HttpURLConnection conn = null;

		Log.v(LOG_TAG, "start GET url: " + urlStr);
		StatAppMonitor monitor = MTAUtils.getAppMonitorForImage(urlStr);
		final long start = System.nanoTime();
		
		try {
			// 保存请求包大小（只统计了url的，不准确）
			monitor.setReqSize(StringUtils.getByteLength(urlStr,
					Constants.DECODE_CHARSET));

			URL url = new URL(urlStr);
			// 首先进行预处理
			conn = (HttpURLConnection) url.openConnection();
			conn = preProcessHttp(conn);
			if (conn == null) {
				return false;
			}

			if (cache.getLastModified() > 0) {
				conn.addRequestProperty(IF_MODIFIED_SINCE,
						DateUtils.L2CST(cache.getLastModified()));
			}

			final int statusCode = conn.getResponseCode();
			// 保存接口返回码
			monitor.setReturnCode(statusCode);
			// 返回304,说明不用更新数据
			if (statusCode == HttpStatus.SC_NOT_MODIFIED) {
				finished = true;
			} else {
				if (statusCode != HttpStatus.SC_OK) {
					Log.e(LOG_TAG, "Error statusCode:" + statusCode
							+ ", while retrieving image from " + urlStr);
				} else if ((inputStream = conn.getInputStream()) != null) {
					final long curTime = System.currentTimeMillis();
					final long lastModified = conn.getHeaderFieldDate(
							LAST_MODIFIED, curTime);
					cache.setLastModified(lastModified);
					
					/**
					 * Add progress bar
					 */
					int totalLength = conn.getContentLength();
					
					cache.setValue(toByteArray(inputStream, totalLength, handler));
					
					// 记录返回包大小
					final int respSize = cache.getValue() == null ? 0 : cache
							.getValue().length;
					monitor.setRespSize(respSize);
					
					finished = true;
				}
			}
		} catch (IOException e) {
			Log.e(LOG_TAG, "I/O error while retrieving image from " + urlStr, e);
		} catch (Exception e) {
			Log.e(LOG_TAG, "Error while retrieving image from " + urlStr, e);
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					Log.e(LOG_TAG, "Error while closing inputStream " + urlStr,
							e);
				}
			}

			if (conn != null) {
				conn.disconnect();
			}
		}
		// 上报统计信息
        MTAUtils.report(App.getInstance(), start, monitor);
		return finished;
	}
	
	public byte[] toByteArray(InputStream ins, int totalLength, Handler handler) throws IOException {
        ByteArrayOutputStream outs = new ByteArrayOutputStream();
        byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
        int n = 0;
        Message message;
        int loadingCount = 0;
        int progressCount = 1;
        int dataPiece = totalLength / 10;
        while (-1 != (n = ins.read(buffer))) {
            outs.write(buffer, 0, n);
            loadingCount += n; 
            /**
             * totalLength is necessary response header
             * guarantee IamgeView progress to draw 11 times at most
             */
            if(totalLength > 0 && loadingCount >= progressCount * dataPiece) {
            	message = handler.obtainMessage(LAODING_IMAGE_DATA, (float)(0.1 * progressCount));
                handler.sendMessage(message);
                progressCount++;
            }
        }
        /**
         * handle the situation that totalLength is -1
         */
        message = handler.obtainMessage(LAODING_IMAGE_DATA, (float)(1.0));
        handler.sendMessage(message);
        
        byte[] result = null;
        result = outs.toByteArray();
        if (outs != null) {
            outs.close();
        }
        return result;
    }

	/**
	 * 
	 * @Title: loadDrawable
	 * 
	 * @Description: 加载图片，不指定需要加载的图片宽高
	 * @param @param imageUrl
	 * @param @param imageView
	 * @param @param imageCallback
	 * @param @return 设定文件
	 * @return Bitmap 返回类型
	 * @throws
	 */
	public Bitmap loadDrawable(final String imageUrl,
			final ImageView imageView, final IProgressImgLoaderEvent imageCallback) {
		return loadDrawable(imageUrl, imageView, 0, 0, imageCallback);
	}
	
	public Bitmap loadDrawable(final String imageUrl,
			final ImageView imageView, boolean useMemCache, final IProgressImgLoaderEvent imageCallback) {
		return loadDrawable(imageUrl, imageView, 0, 0, useMemCache, true, imageCallback);
	}
	
	public Bitmap loadDrawable(final String imageUrl,
			final ImageView imageView, final int reqWidth, final int reqHeight,
			final IProgressImgLoaderEvent imageCallback) {
		return loadDrawable(imageUrl, imageView, reqWidth, reqHeight, true, true, imageCallback);
	}

	/**
	 * 加载图片, 指定需要加载的图片宽高
	 * 
	 * @param imageUrl
	 *            ：图片url
	 * @param imageCallback
	 *            加载完成之后的回调接口
	 * @return
	 */
	@SuppressLint("HandlerLeak")
	public Bitmap loadDrawable(final String imageUrl,
			final ImageView imageView, final int reqWidth, final int reqHeight,
			boolean useMemCache, final boolean useSDCache, final IProgressImgLoaderEvent imageCallback) {
		if (StringUtils.isBlank(imageUrl)) {
			return null;
		}

		/**
		 * 0、处理消息
		 */
		final Handler handler = new Handler(Looper.getMainLooper()) {
			public void handleMessage(Message message) {
				if(message.what == START_LAODING_IMAGE_DATA) {
					imageCallback.imageLoadedStart(imageView);
				}
				else if(message.what == LAODING_IMAGE_DATA) {
					if (message.obj != null) {
						float progress = (Float) message.obj;
						imageCallback.imageLoading(imageView, progress);
					}
					
				}
				else if(message.what == DONE_LAODING_IMAGE_DATA) {
					if (message.obj == null) {
						imageCallback.imageLoaded(imageView, null, imageUrl.trim());
					} else {
						imageCallback.imageLoaded(imageView, (Bitmap) message.obj,
								imageUrl.trim());
					}
				}
				else if(message.what == FAIL_LAODING_IMAGE_DATA) {
					imageCallback.imageLoadedFailed(imageView);
				}
				
			}
		};

		/**
		 * 1、查询cache里面是否有图片
		 */
		if(useMemCache) {
			final Bitmap bitmap = getBitmapFromCache(imageUrl);
			if (null != bitmap) {
				return bitmap;
			}
		}

		try {
			if (executorService != null && !executorService.isTerminated()
					&& !executorService.isShutdown())
				executorService.submit(new Runnable() {
					@Override
					public void run() {
						try {
							final long startTime = System.currentTimeMillis();
							Bitmap bitmap = null;
							boolean isOk = false;
							CacheInfo cache = null;
							Message message;
							boolean ifFromNet = false;
							if (useSDCache) {
								/**
								 * 2.1、从本地SD卡读取
								 */
								cache = CacheUtils.getFromCache(imageUrl.trim());

								/**
								 * 2.2、从网络中下载图片
								 */
								if (null == cache || !cache.isValid()) {
									
									/**
									 * start load image data from net
									 */
									message = handler.obtainMessage(START_LAODING_IMAGE_DATA);
									handler.sendMessage(message);
									
									if (null == cache) {
										cache = new CacheInfo(0, startTime
												+ mustImageExipreCheckTime,
												imageUrl.trim(), null);
									} 
									
									isOk = downloadFromNet(imageUrl.trim(),
											cache, handler);
									ifFromNet = true;
									
								} else {
									isOk = true;
								}

							} else {
								/**
								 * start load image data from net
								 */
								message = handler.obtainMessage(START_LAODING_IMAGE_DATA);
								handler.sendMessage(message);
								cache = new CacheInfo(0, startTime
										+ mustImageExipreCheckTime, imageUrl
										.trim(), null);
								isOk = downloadFromNet(imageUrl.trim(), cache, handler);
								ifFromNet = true;
							}

							if (isOk && cache != null && cache.isValid()) {
								if (ifFromNet) {
									bitmap = decodeSampledBitmapFromByteArray(
											cache.getValue(), reqWidth, reqHeight);
								} else {
									// 本地的不需要再采样
									bitmap = decodeSampledBitmapFromByteArray(
											cache.getValue(), 0, 0);
								}
							}
							
							if (bitmap != null) {
								/**
								 * 2.4、保存到缓存
								 */
								putBitmapToCache(imageUrl.trim(), bitmap);
								message = handler.obtainMessage(DONE_LAODING_IMAGE_DATA, bitmap);
								handler.sendMessage(message);
								
								/**
								 * 2.3、保存到本地SD卡上
								 */
								if (ifFromNet && isOk && null != cache
										&& cache.isValid() && bitmap != null) {
									saveFile(imageUrl.trim(), bitmap,
											cache.getLastModified(),
											cache.getExpires());
								}
							} else {
								message = handler.obtainMessage(FAIL_LAODING_IMAGE_DATA, null);
								handler.sendMessage(message);
							}

						} catch (Exception e) {
							Log.e(LOG_TAG, e.getMessage(), e);
						}
					}
				});
		} catch (Exception e) {
			Log.e(LOG_TAG, e.getMessage(), e);
		}

		return null;
	}

	/**
	 * 
	 * @Title: decodeSampledBitmapFromByteArray
	 * 
	 * @Description: 解析得到Bitmap，如果设置了reqWidth， reqHeight,会进行压缩
	 * @param @param data
	 * @param @param reqWidth
	 * @param @param reqHeight
	 * @param @return 设定文件
	 * @return Bitmap 返回类型
	 * @throws
	 */
	private Bitmap decodeSampledBitmapFromByteArray(byte[] data, int reqWidth,
			int reqHeight) {
		if (null == data || data.length <= 0) {
			return null;
		}
		final BitmapFactory.Options options = new BitmapFactory.Options();
		if (reqWidth <= 0 || reqHeight <= 0) {
			// 不需要进行压缩
			options.inPurgeable = true;
			options.inJustDecodeBounds = false;
            return BitmapFactory.decodeByteArray(data, 0, data.length, options);
		} else {
			// 先将inJustDecodeBounds设置为true，获取图片大小，并不解析图片
			options.inJustDecodeBounds = true;
			BitmapFactory.decodeByteArray(data, 0, data.length, options);
			// 计算inSampleSize值
			options.inSampleSize = calculateInSampleSize(options, reqWidth,
					reqHeight);
			// 使用获取到的inSampleSize再次解析图片
			options.inPurgeable = true;
			options.inJustDecodeBounds = false;
			return BitmapFactory.decodeByteArray(data, 0, data.length, options);
		}
	}

	/**
	 * 
	 * @Title: calculateInSampleSize
	 * 
	 * @Description: 计算inSampleSize
	 * @param @param options
	 * @param @param reqWidth
	 * @param @param reqHeight
	 * @param @return 设定文件
	 * @return int 返回类型
	 * @throws
	 */
	private int calculateInSampleSize(BitmapFactory.Options options,
			int reqWidth, int reqHeight) {
		// 源图片的高度和宽度
		final int height = options.outHeight;
		final int width = options.outWidth;
		int inSampleSize = 1;
		if (height > reqHeight || width > reqWidth) {
			// 计算出实际宽高和目标宽高的比率
			final int heightRatio = Math.round((float) height
					/ (float) reqHeight);
			final int widthRatio = Math.round((float) width / (float) reqWidth);
			// 选择宽和高中最小的比率作为inSampleSize的值，这样可以保证最终图片的宽和高， 一定都会大于等于目标的宽和高
			inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;
		}
		return inSampleSize;
	}
	
	/**
	 * 
	 * @Title: bitmap2Bytes
	 *
	 * @Description: Bitmap转成bytes
	 * @param @param bitmap
	 * @param @return  设定文件
	 * @return byte[]  返回类型
	 * @throws
	 */
	private byte[] bitmap2Bytes(Bitmap bitmap) {
		if (null == bitmap) {
			return null;
		}
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		bitmap.compress(Bitmap.CompressFormat.PNG, 75, bos);
		return bos.toByteArray();
	}

	/**
	 * 
	 * @Title: asynSaveFile
	 * 
	 * @Description: 缓存图片到本地SD卡
	 * @param @param key
	 * @param @param content
	 * @param @param lastModifyTime 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	private void saveFile(final String key, final Bitmap bitmap,
			final long lastModifyTime, final long expires) {
//		if (App.getInstance().sWorker != null)
//			App.getInstance().sWorker.post(new Runnable() {
//
//				@Override
//				public void run() {
//					CacheUtils.saveToCache(key, lastModifyTime,
//							mustImageExipreCheckTime, content);
//				}
//			});
//		CacheUtils.clearCache(key);
		final byte[] bytes = bitmap2Bytes(bitmap);
		CacheUtils.saveToCache(key, lastModifyTime, expires, bytes);
	}

	/**
	 * 清除内存
	 */
	@Override
	public void destroy() {
		if (executorService != null && !executorService.isTerminated()) {
			executorService.shutdownNow();
			executorService = null;
		}

		if (sHardBitmapCache != null) {
			sHardBitmapCache.evictAll();
		}

		if (sSoftBitmapCache != null) {
			for (SoftReference<Bitmap> reference : sSoftBitmapCache.values()) {
				Bitmap bitmap = null;
				if (reference != null && (bitmap = reference.get()) != null
						&& !bitmap.isRecycled()) {
					bitmap.recycle();
					bitmap = null;
					reference.clear();
				}
			}
		}
	}

	/**
	 * 
	 * @Title: asyncLoadImage
	 * @Description: 异步加载图片
	 * @param asyncImageLoader
	 * @param imgView
	 * @param url
	 * @param resid
	 *            设定文件
	 * 
	 *            void 返回类型
	 * @throws
	 */
	public static void asyncLoadImage(ProgressImgLoader asyncImageLoader,
			final ImageView imgView, final String url, int resid) {
		final Bitmap drawable = asyncImageLoader.loadDrawable(url, imgView,
				new IProgressImgLoaderEvent() {

					@Override
					public void imageLoaded(ImageView imageView, Bitmap bitmap,
							String imageUrl) {
						if (imageView != null && bitmap != null && imageView.isShown()) {
							String tag = (String) imageView.getTag();
							if (tag != null && tag.equals(url)) {
								imageView.setImageBitmap(bitmap);
							}
						}

					}

					@Override
					public void imageLoadedStart(ImageView imageView) {

					}

					@Override
					public void imageLoading(ImageView imageView,
							float progress) {

					}

					@Override
					public void imageLoadedFailed(ImageView imageView) {

					}
				});
		if (drawable != null) {
			imgView.setImageBitmap(drawable);
		} else if (resid > 0) {
			imgView.setImageResource(resid);
		}
	}

}
