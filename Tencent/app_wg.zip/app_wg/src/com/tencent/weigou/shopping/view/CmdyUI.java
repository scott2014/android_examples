package com.tencent.weigou.shopping.view;

import java.lang.ref.SoftReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.graphics.Bitmap;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.Animation.AnimationListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.process.BitmapProcessor;
import com.tencent.weigou.R;
import com.tencent.weigou.base.model.vo.CommonVo;
import com.tencent.weigou.base.view.UI;
import com.tencent.weigou.common.ui.TopToolBar;
import com.tencent.weigou.common.ui.zoom.HackyViewPager;
import com.tencent.weigou.common.ui.zoom.PhotoView;
import com.tencent.weigou.common.ui.zoom.PhotoViewAttacher.OnPhotoTapListener;
import com.tencent.weigou.shopping.model.vo.CmdyDetailVo;
import com.tencent.weigou.util.ImageScaleUtils;
import com.tencent.weigou.util.Util;

public class CmdyUI extends UI implements OnPhotoTapListener {
	HackyViewPager viewPage;
	TopToolBar topBar;
	LinearLayout cmdyGrid;
	RelativeLayout cmdyGridOutter;
	private int picWidth;
	private int picHeight;
	ImageView redRec;
	CmdyPagerAdapter adapter;
	private boolean show = true;

	@Override
	public void initView(View outterView) {

		super.initView(outterView);
		viewPage = (HackyViewPager) findViewById(R.id.shopping_cmdy_pic_viewpager);
		cmdyGrid = (LinearLayout) findViewById(R.id.cmdy_grid_ll);
		cmdyGridOutter = (RelativeLayout) findViewById(R.id.cmdy_grid_ll_outter);
		adapter = new CmdyPagerAdapter();
		viewPage.setAdapter(adapter);

		topBar = (TopToolBar) findViewById(R.id.top_bar);
		picWidth = Util.getScreenWidth(((Activity) context).getWindowManager());
		picHeight = Util.getScreenContentHeight(context);
		options = new DisplayImageOptions.Builder()
				.showImageOnLoading(R.color.translucent)
				.showImageForEmptyUri(R.drawable.loading_big)
				.preProcessor(new BitmapProcessor() {

					@Override
					public Bitmap process(Bitmap bm) {
						Bitmap desBm = ImageScaleUtils
								.createHeightScaledBitmap(picWidth, picHeight,
										bm);
						return desBm;

					}
				}).showImageOnFail(R.drawable.loading_big).cacheInMemory(true)
				.cacheOnDisc(true).considerExifParams(true)
				.bitmapConfig(Bitmap.Config.RGB_565)
				.imageScaleType(ImageScaleType.IN_SAMPLE_POWER_OF_2).build();
		// options = new DisplayImageOptions.Builder()
		// .showImageOnLoading(R.color.translucent)
		// .showImageForEmptyUri(R.drawable.loading_big)
		// .showImageOnFail(R.drawable.loading_big).cacheInMemory(true)
		// .cacheOnDisc(true).considerExifParams(true)
		// .bitmapConfig(Bitmap.Config.RGB_565).build();
	}

	@Override
	public void updateContent(CommonVo rv) {
		super.updateContent(rv);
		if (rv instanceof CmdyDetailVo) {
			CmdyDetailVo cdv = ((CmdyDetailVo) rv);
			if (cdv.urls.size() > 0) {
				adapter.setUrls(cdv.urls);
				adapter.notifyDataSetChanged();
			}
		}

		final int snapWidth = (picWidth - Util.dip2px(context, 60)) / 5;
		for (int i = 0; i < adapter.getUrls().size(); i++) {
			ImageView iv = new ImageView(context);
			LayoutParams layoutParams = new LayoutParams(snapWidth, snapWidth);
			iv.setScaleType(ScaleType.CENTER_CROP);
			// layoutParams.weight = 1;
			iv.setTag(i);
			if (i == 0) {
				layoutParams.setMargins(0, 0, Util.dip2px(context, 5), 0);
			} else if (i == adapter.getUrls().size() - 1) {
				layoutParams.setMargins(Util.dip2px(context, 5), 0,
						Util.dip2px(context, 5), 0);
			} else {
				layoutParams.setMargins(Util.dip2px(context, 5), 0,
						Util.dip2px(context, 5), 0);
			}

			imageLoader.displayImage(adapter.getUrls().get(i), iv, options,
					animateFirstListener);
			// asyncLoadImage(iv, adapter.getUrls().get(i) + "?snap=1",
			// snapWidth,
			// snapWidth, R.drawable.loading_big, true, true);
			cmdyGrid.addView(iv, layoutParams);
			iv.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					int index = Integer.parseInt(v.getTag().toString());
					viewPage.setCurrentItem(index);
				}
			});
		}

		redRec = new ImageView(context);
		RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(
				snapWidth, snapWidth);
		redRec.setPadding(1, 1, 1, 1);
		redRec.setBackgroundResource(R.drawable.red_border);
		cmdyGridOutter.addView(redRec, layoutParams);
		viewPage.setOnPageChangeListener(new OnPageChangeListener() {

			@Override
			public void onPageSelected(int arg0) {

			}

			@Override
			public void onPageScrolled(int position, float positionOffset,
					int positionOffsetPixels) {
				Log.e("TAG", "position=" + position + ",positionOffset="
						+ positionOffset + ",positionOffsetPixels="
						+ positionOffsetPixels);
				RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) redRec
						.getLayoutParams();
				params.leftMargin = (snapWidth + Util.dip2px(context, 10))
						* position
						+ (int) ((snapWidth + Util.dip2px(context, 10)) * positionOffset);

				redRec.setLayoutParams(params);
			}

			@Override
			public void onPageScrollStateChanged(int arg0) {

			}
		});
	}

	class CmdyPagerAdapter extends PagerAdapter {
		private List<String> urls = new ArrayList<String>();
		private Map<Integer, SoftReference<Bitmap>> map = new HashMap<Integer, SoftReference<Bitmap>>();

		public void setUrls(List<String> urls) {
			this.urls = urls;
		}

		public List<String> getUrls() {
			return urls;
		}

		@Override
		public int getCount() {
			return urls.size();
		}

		@Override
		public View instantiateItem(ViewGroup container, final int position) {
			View v = LayoutInflater.from(context).inflate(
					R.layout.shopping_cmdy_pager_item, null);
			final PhotoView photoView = (PhotoView) v
					.findViewById(R.id.shopping_cmdy_pic);
			photoView.setOnPhotoTapListener(CmdyUI.this);
			photoView.setScaleType(ScaleType.CENTER_CROP);
			// asyncLoadImage(photoView, urls.get(position) + "?bg=1", picWidth,
			// picHeight, R.drawable.loading_big, true, true);
			imageLoader.displayImage(urls.get(position), photoView, options,
					animateFirstListener);

			container.addView(v, LayoutParams.MATCH_PARENT,
					LayoutParams.MATCH_PARENT);
			return v;
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			if (null != map.get(position)) {
				final Bitmap bitmap = map.get(position).get();
				if (null != bitmap && !bitmap.isRecycled()) {
					bitmap.recycle();
				}
			}
			container.removeView((View) object);
		}

		@Override
		public boolean isViewFromObject(View view, Object object) {
			return view == object;
		}

	}

	@Override
	public void onPhotoTap(View view, float x, float y) {
		showOrHide();
	}

	public void showOrHide() {
		if (show) {
			hide();
		} else {
			show();
		}
	}

	public void show() {
		Animation ifdAnimation = AnimationUtils.loadAnimation(context,
				R.anim.in_from_down);
		ifdAnimation.setAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onAnimationRepeat(Animation animation) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onAnimationEnd(Animation animation) {
				cmdyGridOutter.setVisibility(View.VISIBLE);

			}
		});
		cmdyGridOutter.startAnimation(ifdAnimation);
		show = true;

	}

	public void hide() {
		Animation otdAnimation = AnimationUtils.loadAnimation(context,
				R.anim.out_to_down);
		otdAnimation.setAnimationListener(new AnimationListener() {
			
			@Override
			public void onAnimationStart(Animation animation) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onAnimationRepeat(Animation animation) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onAnimationEnd(Animation animation) {
				cmdyGridOutter.setVisibility(View.GONE);
				
			}
		});
		cmdyGridOutter.startAnimation(otdAnimation);
		show = false;
	}
}
