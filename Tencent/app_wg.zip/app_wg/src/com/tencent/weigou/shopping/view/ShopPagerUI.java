package com.tencent.weigou.shopping.view;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.Animator.AnimatorListener;
import android.annotation.TargetApi;
import android.os.Build;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.RelativeSizeSpan;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.BounceInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.animation.TranslateAnimation;
import android.view.animation.Animation.AnimationListener;
import android.widget.ImageView;
import android.widget.TextView;

import com.tencent.weigou.R;
import com.tencent.weigou.base.view.UI;
import com.tencent.weigou.shopping.adapter.ShopPagerAdapter;
import com.tencent.weigou.shopping.model.vo.ShopPagerVo;
import com.tencent.weigou.shopping.utils.ProgressImgLoader;
import com.tencent.weigou.util.Util;

public class ShopPagerUI extends UI {

    private ProgressImgLoader asyncImageLoader;
	
	private ImageView backView;
	private TextView titleView;
	private TextView moreView;
	private ViewPager pagerView;
    private ImageView arrowView;
	
	private ShopPagerAdapter adapter;
	
	@Override
	public void initView(View outterView) {
		super.initView(outterView);		
		
		backView = (ImageView)outterView.findViewById(R.id.top_bar_back_tv);
		titleView = (TextView)outterView.findViewById(R.id.top_bar_title);
		moreView = (TextView)outterView.findViewById(R.id.top_bar_right_1_tv);
		pagerView = (ViewPager) outterView.findViewById(R.id.pager);
        arrowView = (ImageView)outterView.findViewById(R.id.arrow_right);
	}
	
	public void setImgLoader(ProgressImgLoader asyncImageLoader) {
		this.asyncImageLoader = asyncImageLoader;
	}
	
	public void initClickListener(OnClickListener l) {
		backView.setOnClickListener(l);
		moreView.setOnClickListener(l);
	}
	
	public void initViewPager(FragmentManager fm, OnPageChangeListener l) {
		adapter = new ShopPagerAdapter(fm);
		pagerView.setAdapter(adapter);		
		pagerView.setOnPageChangeListener(l);
		
	}

	public void setSingleCard() {
		moreView.setVisibility(View.GONE);
		moreView.setClickable(false);
	}
	
	public void setTitle(String title, String subTitle) {
		String str = title + "  " + subTitle;
		int length = subTitle.length();
		int totalLength = str.length();
		Spannable textSpan = new SpannableString(str);
		textSpan.setSpan(new RelativeSizeSpan(16f / 22f), totalLength - length, totalLength, Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
		titleView.setText(textSpan);
	}
	
	public void scrollTo(int index) {
		pagerView.setCurrentItem(index, true);
	}
	
	public Fragment getFragment(int index) {
		return adapter.getRegisteredFragment(index);
	}
	
	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	public void updateShopList(ShopPagerVo shopPagerVo,
			AnimatorListener animatorListener) {
		adapter.setMallDetailVo(shopPagerVo);
		adapter.updateVo();
		
		if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB ) {
			ObjectAnimator xAnim = ObjectAnimator.ofFloat(pagerView, "x",
					pagerView.getX() + pagerView.getWidth(), pagerView.getX()).setDuration(500);
	        xAnim.setStartDelay(0);
	        xAnim.setRepeatCount(0);
	        xAnim.setInterpolator(new LinearInterpolator());
	        xAnim.addListener(animatorListener);
	        xAnim.start();
		}
	}
	
	public void updateShopList(ShopPagerVo shopPagerVo,
			AnimationListener animationListener) {
		adapter.setMallDetailVo(shopPagerVo);
		adapter.updateVo();
		
		TranslateAnimation anim = new TranslateAnimation(pagerView.getWidth(), 0, 0, 0);
		anim.setDuration(500);
		anim.setInterpolator(new LinearInterpolator());
		anim.setFillAfter(true);
		anim.setAnimationListener(animationListener);
		pagerView.setAnimation(anim);
		anim.start();
	}

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public void setArrow(int i) {
        arrowView.setVisibility(View.VISIBLE);

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB ) {
            ObjectAnimator xAnim = ObjectAnimator.ofFloat(arrowView, "x",
                    arrowView.getX() + arrowView.getWidth() +
                            Util.dip2px(arrowView.getContext(), 10), arrowView.getX()).setDuration(1000);
            xAnim.setStartDelay(0);
            xAnim.setRepeatCount(0);
            xAnim.setInterpolator(new BounceInterpolator());
            xAnim.addListener(new AnimatorListener() {

                @Override
                public void onAnimationStart(Animator animation) {
                }

                @Override
                public void onAnimationEnd(Animator animation) {
                    arrowView.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            arrowView.setVisibility(View.GONE);
                        }
                    }, 2000);
                }

                @Override
                public void onAnimationCancel(Animator animation) {
                }

                @Override
                public void onAnimationRepeat(Animator animation) {
                }
            });
            xAnim.start();
        }
    }

    public void setArrow(String s) {
        arrowView.setVisibility(View.VISIBLE);

        TranslateAnimation anim = new TranslateAnimation(arrowView.getWidth() +
                Util.dip2px(arrowView.getContext(), 10), 0, 0, 0);
        anim.setDuration(1000);
        anim.setInterpolator(new BounceInterpolator());
        anim.setAnimationListener(new AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                arrowView.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        arrowView.setVisibility(View.GONE);
                    }
                }, 2000);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }
        });
        arrowView.setAnimation(anim);
        anim.start();
    }

}
