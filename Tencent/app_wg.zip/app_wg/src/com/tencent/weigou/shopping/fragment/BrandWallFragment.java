package com.tencent.weigou.shopping.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.tencent.weigou.R;
import com.tencent.weigou.common.ui.AdaptiveImageView;
import com.tencent.weigou.shopping.activity.ShopPagerActivity;
import com.tencent.weigou.shopping.model.vo.BrandWallVo;
import com.tencent.weigou.shopping.utils.ProgressImgLoader;
import com.tencent.weigou.util.ConstantsActivity;
import com.tencent.weigou.util.StringUtils;

/**
 * Created by branjing on 14-1-6.
 */
public class BrandWallFragment extends Fragment implements View.OnClickListener {

    private ImageView disappearView;
    private ListView listView;
    private ProgressBar loadingBar;
    private TextView loadingFailView;

    private BrandWallVo brandWallVo;

    private FragmentBridge fragmentBridge;
    private ProgressImgLoader asyncImageLoader;

    private final Object mPauseWorkLock = new Object();
    private IsAnimEnd isAnimEndObj = new IsAnimEnd();

    public static class IsAnimEnd {
        public boolean isAnimEnd = false;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        fragmentBridge = (FragmentBridge)getActivity();
        asyncImageLoader = fragmentBridge.getProgressImgLoader();

    }

    @Override
    public Animation onCreateAnimation(int transit, boolean enter, int nextAnim) {

        Log.d("Bran", "nextAnim = " + nextAnim);
        if(nextAnim > 0) {
            Animation anim = AnimationUtils.loadAnimation(getActivity(), nextAnim);

            anim.setAnimationListener(new Animation.AnimationListener() {

                public void onAnimationStart(Animation animation) {
                    //动画开始
                }

                public void onAnimationRepeat(Animation animation) {
                    //动画循环
                }

                public void onAnimationEnd(Animation animation) {
                    synchronized (mPauseWorkLock) {
                        isAnimEndObj.isAnimEnd = true;
                        mPauseWorkLock.notifyAll();
                        Log.d("Bran", "mPauseWorkLock.notifyAll();");
                    }
                }
            });

            return anim;
        }
        else {
            synchronized (mPauseWorkLock) {
                isAnimEndObj.isAnimEnd = true;
                mPauseWorkLock.notifyAll();
                Log.d("Bran", "mPauseWorkLock.notifyAll();");
            }
            return null;
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.mall_brand_wall_layout, container, false);
        disappearView = (ImageView)v.findViewById(R.id.brand_wall_disappear);
        disappearView.setOnClickListener(this);
        listView = (ListView)v.findViewById(R.id.listview);
        listView.setDividerHeight(0);
        loadingBar = (ProgressBar) v.findViewById(R.id.loading_bar);
        loadingFailView = (TextView) v.findViewById(R.id.loading_fail);

        BrandWallVo vo = fragmentBridge.getBrandWallData();
        if(vo != null) {
            setBrandWallVo(vo);
        }
        else {
            listView.setVisibility(View.GONE);
            loadingBar.setVisibility(View.VISIBLE);
            loadingFailView.setVisibility(View.GONE);
            fragmentBridge.startLoadingWall(mPauseWorkLock, isAnimEndObj);
        }

        return v;
    }

    public void setBrandWallVo(BrandWallVo vo) {

        if(vo == null) {
            listView.setVisibility(View.GONE);
            loadingBar.setVisibility(View.GONE);
            loadingFailView.setVisibility(View.VISIBLE);
            return;
        }

        brandWallVo = vo;
        BrandWallAdapter adaper = new BrandWallAdapter();
        listView.setAdapter(adaper);

        listView.setVisibility(View.VISIBLE);
        loadingBar.setVisibility(View.GONE);
        loadingFailView.setVisibility(View.GONE);

//        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//
//            }
//        });
    }

    @Override
    public void onClick(View v) {
        if(v.getId()== R.id.brand_wall_disappear) {
            fragmentBridge.closeFragment();
        }
        else {
            String shopId = (String) v.getTag(R.id.tag_shop_id);
            String shopName = (String) v.getTag(R.id.tag_shop_name);
            if(StringUtils.isNotEmpty(shopId)) {
                Intent intent = new Intent();
                intent.putExtra(ConstantsActivity.INTENT_SHOP_ID, shopId);
                intent.putExtra(ConstantsActivity.INTENT_SHOP_NAME, shopName);
                intent.setClass(getActivity(), ShopPagerActivity.class);
                fragmentBridge.startNextActivity(intent);
            }
        }
    }

    public class BrandWallAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            if(brandWallVo == null || brandWallVo.brandwall == null
                    || brandWallVo.brandwall.size() == 0) {
                return 0;
            }
            return brandWallVo.brandwall.size();
        }

        @Override
        public Object getItem(int position) {
            if(brandWallVo == null || brandWallVo.brandwall == null
                    || brandWallVo.brandwall.size() <= position) {
                return null;
            }
            return brandWallVo.brandwall.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if(convertView == null) {
                LayoutInflater inflater = LayoutInflater.from(BrandWallFragment.this.getActivity());
                if(getItemViewType(position) == 0) {
                    View v = inflater.inflate(R.layout.mall_brand_type_cat, null);
                    TextView catNameView = (TextView) v.findViewById(R.id.brand_cat_name);
                    Holder holder = new Holder();
                    holder.catNameView = catNameView;
                    v.setTag(holder);
                    convertView = v;
                }
                else if(getItemViewType(position) == 1) {
                    View v = inflater.inflate(R.layout.mall_brand_type_shop, null);
                    Holder holder = new Holder();

                    holder.views[0] = v.findViewById(R.id.brand_left);
                    holder.imgView[0] = (AdaptiveImageView)holder.views[0].findViewById(R.id.brand_img);
                    holder.imgView[0].setDrawCircleBorder(true);
                    holder.brandNameView[0] = (TextView) holder.views[0].findViewById(R.id.brand_name);

                    holder.views[1] = v.findViewById(R.id.brand_middle);
                    holder.imgView[1] = (AdaptiveImageView)holder.views[1].findViewById(R.id.brand_img);
                    holder.imgView[1].setDrawCircleBorder(true);
                    holder.brandNameView[1] = (TextView) holder.views[1].findViewById(R.id.brand_name);

                    holder.views[2] = v.findViewById(R.id.brand_right);
                    holder.imgView[2] = (AdaptiveImageView)holder.views[2].findViewById(R.id.brand_img);
                    holder.imgView[2].setDrawCircleBorder(true);
                    holder.brandNameView[2] = (TextView) holder.views[2].findViewById(R.id.brand_name);

                    v.setTag(holder);
                    convertView = v;
                }
            }

            Holder holder = (Holder) convertView.getTag();
            BrandWallVo.BrandRow brandRow = (BrandWallVo.BrandRow) getItem(position);

            if(brandRow == null) {
                return null;
            }

            if(getItemViewType(position) == 0) {
                holder.catNameView.setText(brandRow.catName);
            }
            else if(getItemViewType(position) == 1) {
                int size = brandRow.brandRowList.size();

                for(int i = 0; i < 3; i++) {
                    if(size > i) {
                        holder.views[i].setVisibility(View.VISIBLE);
                        holder.brandNameView[i].setText(brandRow.brandRowList.get(i).brandName);
                        holder.imgView[i].setTag(brandRow.brandRowList.get(i).brandUrl);
                        ProgressImgLoader.asyncLoadImage(asyncImageLoader, holder.imgView[i],
                                brandRow.brandRowList.get(i).brandUrl, 0);
                        holder.views[i].setTag(R.id.tag_shop_id, brandRow.brandRowList.get(i).shopId);
                        holder.views[i].setTag(R.id.tag_shop_name, brandRow.brandRowList.get(i).shopName);
                        holder.views[i].setOnClickListener(BrandWallFragment.this);
                    }
                    else {
                        holder.views[i].setVisibility(View.GONE);
                        holder.views[i].setOnClickListener(null);
                    }
                }
            }

            return convertView;
        }

        /**
         * type 0 is catName
         * type 1 is brands
         *
         * @param position
         * @return
         */
        public int getItemViewType(int position) {
            if(brandWallVo == null || brandWallVo.brandwall == null
                    || brandWallVo.brandwall.size() <= position) {
                return -1;
            }
            BrandWallVo.BrandRow brandRow = brandWallVo.brandwall.get(position);
            if(brandRow == null) {
                return -1;
            }
            if(brandRow.brandRowList == null && !StringUtils.isEmpty(brandRow.catName)) {
                return 0;
            }
            else if(brandRow.brandRowList != null && StringUtils.isEmpty(brandRow.catName)) {
                return 1;
            }
            else {
                return -1;
            }
        }

        /**
         * @return 2 types
         */
        public int getViewTypeCount() {
            return 2;
        }

        public class Holder {
            public TextView catNameView;

            public View[] views = new View[3];
            public AdaptiveImageView[] imgView = new AdaptiveImageView[3];
            public TextView[] brandNameView = new TextView[3];
        }

    }

    public static interface FragmentBridge {
        public BrandWallVo getBrandWallData();
        public void startLoadingWall(Object lock, IsAnimEnd isAnimEndObj);
        public ProgressImgLoader getProgressImgLoader();
        public void startNextActivity(Intent intent);
        public void closeFragment();
    }
}
