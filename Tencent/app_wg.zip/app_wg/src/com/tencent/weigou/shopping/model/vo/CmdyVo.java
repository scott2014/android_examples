package com.tencent.weigou.shopping.model.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import android.util.Log;

import com.tencent.weigou.base.model.vo.CommonVo;
import com.tencent.weigou.shopping.model.CmdyPagerModel;
import com.tencent.weigou.util.Util;

public class CmdyVo extends CommonVo implements Serializable {
	/**
	 * 
	 */
	public List<CmdyItemVo> list = new ArrayList<CmdyItemVo>();
	public List<CmdyItemVo> tmpList = new ArrayList<CmdyItemVo>();
	public int total;
	public String curId;

	public List<CmdyItemVo> getFavList() {
		List<CmdyItemVo> favList = new ArrayList<CmdyItemVo>();
		for (int i = 0; i < list.size(); i++) {
			CmdyItemVo civ = list.get(i);
			if (civ.userFavorited == 1) {
				favList.add(civ);
			}
		}
		return favList;
	}

	public boolean parse(JSONObject jo) {
		switch (notificationId) {
		case CmdyPagerModel.INIT_DATA:

		case CmdyPagerModel.NEXT_DATA:
			tmpList.clear();
			try {
				total = jo.getInt("totalCount");
				JSONArray jsonArray = jo.getJSONArray("itemList");
				for (int i = 0; i < jsonArray.length(); i++) {
					CmdyItemVo niv = new CmdyItemVo();
					niv.name = jsonArray.getJSONObject(i).optString("itemName");
					niv.price = Util.getCurrency(
							jsonArray.getJSONObject(i).optString("price"))
							.replace(".00", "");
					niv.bg = jsonArray.getJSONObject(i).getJSONObject("pic")
							.optString("url");
					niv.id = jsonArray.getJSONObject(i).optString("itemId");
					niv.userFavorited = jsonArray.getJSONObject(i).optInt(
							"userFavorited");
					niv.sellerUin = jsonArray.getJSONObject(i).optString(
							"sellerUin");
					niv.detail = jsonArray.getJSONObject(i).optString("detail");
					niv.canBuy = jsonArray.getJSONObject(i)
							.optBoolean("canBuy");
					JSONObject jsShop = jsonArray.getJSONObject(i)
							.optJSONObject("shop");
					if (jsShop != null) {
						niv.tel = jsShop.optString("tel", "");
					}
					// niv.tel =
					// jsonArray.getJSONObject(i).optString("shopTel");
					niv.ic = jsonArray.getJSONObject(i).optString("ic");
					if (CmdyPagerModel.INIT_DATA == notificationId) {
						list.add(niv);
					} else {
						tmpList.add(niv);
					}
				}
				Log.e("tag", "tag");
			} catch (Exception e) {
				e.printStackTrace();
			}

			break;
		case CmdyPagerModel.INIT_FAV_LIST_DATA:
		case CmdyPagerModel.NEXT_FAV_LIST_DATA:
			tmpList.clear();
			try {
				JSONArray jsonList = jo.getJSONArray("elements");
				for (int i = 0; i < jsonList.length(); i++) {
					JSONObject detailJson = jsonList.getJSONObject(i)
							.optJSONObject("detail");
					CmdyItemVo niv = new CmdyItemVo();
					niv.name = detailJson.optString("itemName");
					niv.price = Util.getCurrency(detailJson.optString("price"))
							.replace(".00", "");
					niv.bg = detailJson.getJSONObject("pic").optString("url");
					niv.id = detailJson.optString("itemId");
					niv.canBuy = detailJson.optBoolean("canBuy");
					niv.sellerUin = detailJson.optString("sellerUin");
					niv.tel = detailJson.optString("shopTel");
					niv.userFavorited = jsonList.getJSONObject(i).getInt(
							"favoriteType");
					if (CmdyPagerModel.INIT_FAV_LIST_DATA == notificationId) {
						list.add(niv);
					} else {
						tmpList.add(niv);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case CmdyPagerModel.SHOPPING_CMDY_ADD_FAV:
			for (int i = 0; i < list.size(); i++) {
				CmdyItemVo vo = list.get(i);
				if (vo.id.equals(curId)) {
					Log.d("cmdyVo", "CmdyPagerModel.SHOPPING_CMDY_ADD_FAV");
					vo.userFavorited = 1;
					break;
				}
			}
			break;
		case CmdyPagerModel.SHOPPING_CMDY_DEL_FAV:
			for (int i = 0; i < list.size(); i++) {
				CmdyItemVo vo = list.get(i);
				if (vo.id.equals(curId)) {
					Log.d("cmdyVo", "CmdyPagerModel.SHOPPING_CMDY_DEL_FAV");
					vo.userFavorited = 0;
					break;
				}
			}
			break;
		}

		return true;
	}

	public static class CmdyItemVo implements Serializable {
		/**
		 * 
		 */

		public String id;

		public CmdyItemVo() {
			super();
		};

		public CmdyItemVo(String id, String price, String name, String bg,
				int userFavorited, String detail, String sellerUin, String ic,
				boolean canBuy, String tel) {
			super();
			this.id = id;
			this.price = price;
			this.name = name;
			this.bg = bg;
			this.userFavorited = userFavorited;
			this.detail = detail;
			this.sellerUin = sellerUin;
			this.ic = ic;
			this.canBuy = canBuy;
			this.tel = tel;
		}

		// public CmdyItemVo(String id, String price, String name, String bg,
		// int userFavorited) {
		// super();
		// this.id = id;
		// this.price = price;
		// this.name = name;
		// this.bg = bg;
		// this.userFavorited = userFavorited;
		// }

		public String price;
		public String name;
		public String bg;
		public int userFavorited;
		public String detail;
		public String sellerUin;
		public String ic;
		public boolean canBuy;
		public String tel;

	}
}
