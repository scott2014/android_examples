package com.tencent.weigou.shopping.model;

import com.tencent.weigou.base.model.Model;
import com.tencent.weigou.shopping.model.vo.CmdyVo;

public class NavCmdyModel extends Model {
	public final static int INIT_DATA = 0;
	public final static int NEXT_DATA = 4;
	public CmdyVo navVo;

	@Override
	public void initData(String url) {
		// navVo = new CmdyVo();
		// createNetWorkTask(url, navVo, INIT_DATA);
	}

	public void nextData(String url) {
		navVo.setNotificationId(NEXT_DATA);
		createNetWorkTask(false, url, navVo, NEXT_DATA);
	}
}
