package com.tencent.weigou.shopping.utils;

import android.graphics.Bitmap;
import android.widget.ImageView;

public interface IProgressImgLoaderEvent {

    public void imageLoaded(ImageView imageView, Bitmap bitmap, String imageUrl);
	
	public void imageLoadedStart(ImageView imageView);
	
	public void imageLoading(ImageView imageView, float progress);
	
	public void imageLoadedFailed(ImageView imageView);
}
