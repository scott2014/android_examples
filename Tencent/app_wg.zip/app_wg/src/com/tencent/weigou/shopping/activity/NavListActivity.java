package com.tencent.weigou.shopping.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

import com.tencent.weigou.R;
import com.tencent.weigou.base.App;
import com.tencent.weigou.base.activity.TitleBarActivity;
import com.tencent.weigou.shopping.model.NavModel;
import com.tencent.weigou.shopping.model.vo.NavVo.NavItemVo;
import com.tencent.weigou.shopping.view.NavUI;
import com.tencent.weigou.util.ConstantsActivity;
import com.tencent.weigou.util.ConstantsUrl;
import com.tencent.weigou.util.StringUtils;
import com.tencent.weigou.util.PageIds.OprIndex;

public class NavListActivity extends TitleBarActivity implements
		OnItemClickListener, OnClickListener {
	NavUI ui = new NavUI();
	NavModel model = new NavModel();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		initMVC(model, ui, R.layout.shopping_nav);
		setTitle("快速导航");
		initBackBtn();
		init();
		topbar.findViewById(R.id.top_bar_back_tv).setVisibility(View.INVISIBLE);
		topbar.initRightBtnA(R.drawable.top_bar_arrow, "", this);
	}

	private void init() {

		String mallId = getIntent().getExtras().getString(
				ConstantsActivity.INTENT_MALL_DETAIL_ID);
		if (StringUtils.isBlank(mallId)) {
			mallId = "1";
		}
		String catId = getIntent().getExtras().getString(
				ConstantsActivity.INTENT_MALL_CAT_ID);
		StringBuffer sb = new StringBuffer(App.getInstance().getEnv()
				.getServerUrl());
		sb.append(ConstantsUrl.SHOPPING_MALL_NAV).append("?mid=")
				.append(mallId).append("&categoryId=").append(catId);
		String url = sb.toString();
		url = appendPageInfo(url, OprIndex.PV_OPR);
		model.initData(url);
	}

	@Override
	public void update(int notificationId) {
		super.update(notificationId);
		switch (notificationId) {
		case NavModel.INIT_DATA:
			ui.updateContent(model.navVo);
			break;
		}
	}

	@Override
	public void finish() {
		super.finish();
		overridePendingTransition(R.anim.in_from_up, R.anim.out_to_up);
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		Intent it = new Intent();
		if (parent != null) {
			Object nivo = parent.getItemAtPosition(position);
			if (nivo != null && nivo instanceof NavItemVo) {
				NavItemVo niv = (NavItemVo) nivo;
				if (niv != null) {
					it.putExtra(ConstantsActivity.INTENT_SHOP_DETAIL_ID, niv.id);
				}
			}
		}
		setResult(RESULT_OK, it);
		finish();

	}

	@Override
	public void onClick(View v) {
		finish();
	}
}
