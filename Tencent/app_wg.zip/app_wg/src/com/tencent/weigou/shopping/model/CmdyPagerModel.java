package com.tencent.weigou.shopping.model;

import com.tencent.weigou.base.model.Model;
import com.tencent.weigou.shopping.model.vo.CmdyVo;

public class CmdyPagerModel extends Model {
	public final static int INIT_DATA = 0;
	public final static int RE_INIT_DATA = 5;
	public final static int NEXT_DATA = 4;
	public final static int INIT_FAV_LIST_DATA = 3;
	public final static int NEXT_FAV_LIST_DATA = 6;
	public final static int SHOPPING_CMDY_ADD_FAV = 1;
	public final static int SHOPPING_CMDY_DEL_FAV = 2;
	public CmdyVo cmdyVo;

	@Override
	public void initData(String url) {
		cmdyVo = new CmdyVo();
		createNetWorkTask(url, cmdyVo, INIT_DATA);
	}

	public void initFavData(String url) {
		cmdyVo = new CmdyVo();
		cmdyVo.setNotificationId(INIT_FAV_LIST_DATA);
		createNetWorkTask(url, cmdyVo, INIT_FAV_LIST_DATA);
	}

	public void nextData(String url) {
		cmdyVo.setNotificationId(NEXT_DATA);
		createNetWorkTask(false, url, cmdyVo, NEXT_DATA);
	}

	public void nextFavData(String url) {
		cmdyVo.setNotificationId(NEXT_FAV_LIST_DATA);
		createNetWorkTask(false, url, cmdyVo, NEXT_FAV_LIST_DATA);
	}

	public void doFav(String url, String itemCode, int noti) {
		cmdyVo.setNotificationId(noti);
		cmdyVo.curId = itemCode;
		createNetWorkTask(false, url, cmdyVo, noti);
	}

	public void reInitData(String url) {
		cmdyVo = new CmdyVo();
		createNetWorkTask(url, cmdyVo, RE_INIT_DATA);
	}
}
