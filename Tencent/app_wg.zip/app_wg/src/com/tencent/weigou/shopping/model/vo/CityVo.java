package com.tencent.weigou.shopping.model.vo;

import java.util.ArrayList;
import java.util.List;

import com.tencent.weigou.base.model.vo.CommonVo;

public class CityVo extends CommonVo {
	public CityVo(String name) {
		CityItemVo civ0 = new CityItemVo();
		civ0.name = "深圳";
		civ0.selected = true;
		civ0.enable = true;
		civ0.gps = true;
		civ0.url = "city/shenzhen.jpg";
		list.add(civ0);

		CityItemVo civ1 = new CityItemVo();
		civ1.name = "北京";
		civ1.selected = false;
		civ1.enable = false;
		civ1.gps = false;
		civ1.url = "city/beijing.jpg";
		list.add(civ1);

		CityItemVo civ2 = new CityItemVo();
		civ2.name = "上海";
		civ2.selected = false;
		civ2.enable = false;
		civ2.gps = false;
		civ2.url = "city/shanghai.jpg";
		list.add(civ2);

		CityItemVo civ3 = new CityItemVo();
		civ3.name = "广州";
		civ3.selected = false;
		civ3.enable = false;
		civ3.gps = false;
		civ3.url = "city/guangzhou.jpg";
		list.add(civ3);

		CityItemVo civ4 = new CityItemVo();
		civ4.name = "成都";
		civ4.selected = false;
		civ4.enable = false;
		civ4.gps = false;
		civ4.url = "city/chengdu.jpg";
		list.add(civ4);

	}

	public List<CityItemVo> list = new ArrayList<CityItemVo>();

	public class CityItemVo {
		public String name;
		public String id;
		public boolean selected = false;
		public boolean enable = false;
		public boolean gps = false;
		public String url;

	}
}
