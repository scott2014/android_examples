package com.tencent.weigou.shopping.model.vo;

import com.tencent.weigou.base.model.vo.CommonVo;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 逛-商场-品牌折扣vo
 * User: ethonchan
 * Date: 13-12-4
 * Time: 上午11:54
 */
public class MallDiscountsVo extends CommonVo {

    //  折扣数量
    private int count;

    //  所属分类ID
    private int categoryId;

    //  具体折扣信息
    private List<Discount> discountList;

    @Override
    public boolean parse(JSONObject data) {
        if (data != null) {
            count = data.optInt("totalCount", 0);
            categoryId = data.optInt("currCategoryId", 0);

            JSONArray shopArray = data.optJSONArray("shopList");
            discountList = new ArrayList<Discount>();
            if (shopArray != null) {
                for (int i = 0, len = shopArray.length(); i < len; i++) {
                    JSONObject shopJson = shopArray.optJSONObject(i);
                    if (shopJson == null) {
                        continue;
                    }
                    Discount discount = parseDiscountJSON(shopJson);
                    discountList.add(discount);
                }
            }
            return true;
        }
        return false;
    }

    /**
     * 将一个JSON表示的Discount解析出来
     *
     * @param json
     * @return
     */
    private Discount parseDiscountJSON(JSONObject json) {
        Discount discount = new Discount();
        discount.id = json.optInt("id", 0);
        discount.name = json.optString("name", "");
        discount.brandId = json.optInt("brandId", 0);
        discount.logoUrl = json.optString("brandLogo", "");
        discount.desc = json.optString("promoteDesc", "");
        return discount;
    }

    public int getCount() {
        return count;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public List<Discount> getDiscountList() {
        return discountList;
    }

    public static class Discount {
        public int id;

        //  促销品牌名
        public String name;

        //  品牌ID
        public int brandId;

        //  品牌LOGO
        public String logoUrl;

        //  促销描述
        public String desc;

        public static Discount getMock(){
            Discount discount = new Discount();
            discount.name = "阿迪达斯";
            discount.desc = "发动反击阿萨德究竟是否哈继";
            return discount;
        }
    }
}
