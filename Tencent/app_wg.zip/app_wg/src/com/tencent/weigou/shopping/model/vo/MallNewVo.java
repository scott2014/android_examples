package com.tencent.weigou.shopping.model.vo;

import com.tencent.weigou.base.model.vo.CommonVo;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 逛-商场-上新专区vo
 * User: ethonchan
 * Date: 13-12-4
 * Time: 下午3:46
 */
public class MallNewVo extends CommonVo {
    //  上新专区中需要展示的店铺列表
    private List<Shop> shopList;

    @Override
    public boolean parse(JSONObject data) {
        if (data != null) {
            JSONArray shopArray = data.optJSONArray("shops");
            if (shopArray != null) {
                shopList = new ArrayList<Shop>();
                for (int i = 0, len = shopArray.length(); i < len; i++) {
                    JSONObject json = shopArray.optJSONObject(i);
                    if (json == null) {
                        continue;
                    }

                    Shop shop = parseShopJson(json);
                    shopList.add(shop);

                    List<Item> itemList = shop.itemList;
                    String ids = shop.getItemIds();
                    if (itemList != null) {
                        for (int ci = 0, cLen = itemList.size(); ci < cLen; ci++)
                        //  将每个店铺内所有的商品信息都记住
                        {
                            Item item = itemList.get(ci);
                            item.listIds = ids;
                            item.shopName = shop.name;
                            itemList.set(ci, item);
                        }
                    }
                }
            }
            return true;
        }
        return false;
    }

    /**
     * 将JSON格式表示的店铺信息解析出来
     *
     * @param json
     * @return
     */
    private Shop parseShopJson(JSONObject json) {
        if (json != null) {
            Shop shop = new Shop();
            shop.id = json.optInt("id", 0);
            shop.name = json.optString("name", "");
            shop.logoUrl = json.optString("brandLogo", "");
            shop.brandId = json.optInt("brandId", 0);
            shop.count = json.optInt("count", 0);
            JSONArray array = json.optJSONArray("itemList");
            if (array != null) {
                shop.itemList = new ArrayList<Item>();
                for (int i = 0, len = array.length(); i < len; i++) {
                    JSONObject itemJson = array.optJSONObject(i);
                    if (itemJson == null) {
                        continue;
                    }

                    Item item = parseItemJson(itemJson);
                    item.shopId = shop.id;
                    shop.itemList.add(item);
                }
            }
            return shop;
        }
        return null;
    }

    /**
     * 将JSON格式表示的商品信息解析出来
     *
     * @param json
     * @return
     */
    private Item parseItemJson(JSONObject json) {
        if (json != null) {
            Item item = new Item();
            item.id = json.optInt("itemId", 0);
            item.name = json.optString("itemName", "");
            item.price = json.optInt("price", 0);
            JSONObject picJson = json.optJSONObject("pic");
            if (picJson != null) {
                item.picUrl = picJson.optString("url", "");
                item.picDesc = picJson.optString("desc", "");
            }
            return item;
        }
        return null;
    }

    public List<Shop> getShopList() {
        return shopList;
    }

    /**
     * 上新专区-店铺信息
     */
    public static class Shop {
        //  店铺ID
        public int id;

        //  店铺名称
        public String name;

        //  logo
        public String logoUrl;

        //  品牌ID
        public int brandId;

        //  上新数量
        public int count;

        //  店铺中的商品列表
        public List<Item> itemList;

        public String getItemIds() {
            StringBuilder sb = new StringBuilder();
            final int size = itemList == null ? 0 : itemList.size();
            for (int i = 0; i < size; i++) {
                Item item = itemList.get(i);
                sb.append(item.id);

                if (i + 1 < size) {
                    sb.append(",");
                }
            }

            return sb.toString();
        }
    }

    /**
     * 上新专区-商品信息
     */
    public static class Item {
        //  商品ID
        public int id;

        //  所属的店铺ID
        public int shopId;

        //  所属的店铺名称
        public String shopName;

        //  商品名称
        public String name;

        //  商品价格
        public int price;

        //  商品图片说明
        public String picDesc;

        //  商品图片url
        public String picUrl;

        //  店铺所有的商品ID集合
        public String listIds;
    }
}
