package com.tencent.weigou.shopping.activity;

import java.util.List;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.annotation.TargetApi;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.widget.Toast;

import com.tencent.weigou.R;
import com.tencent.weigou.base.App;
import com.tencent.weigou.base.activity.BaseActivity;
import com.tencent.weigou.shopping.fragment.PromotionFragment;
import com.tencent.weigou.shopping.fragment.ShopFragment;
import com.tencent.weigou.shopping.fragment.ShopFragment.FragmentBridge;
import com.tencent.weigou.shopping.model.ShopPagerModel;
import com.tencent.weigou.shopping.model.vo.MallDetailVo.PromotionItem;
import com.tencent.weigou.shopping.model.vo.ShopCardVo;
import com.tencent.weigou.shopping.utils.ProgressImgLoader;
import com.tencent.weigou.shopping.view.ShopPagerUI;
import com.tencent.weigou.util.Constants;
import com.tencent.weigou.util.ConstantsActivity;
import com.tencent.weigou.util.ConstantsUrl;
import com.tencent.weigou.util.ImageUtils;
import com.tencent.weigou.util.StringUtils;
import com.tencent.weigou.util.PageIds.OprIndex;
import com.tencent.weigou.wxapi.WXUtils;

public class ShopPagerActivity extends BaseActivity implements OnClickListener,
		FragmentBridge, PromotionFragment.FragmentBridge {

	private ShopPagerModel model;
	private ShopPagerUI ui;

	private String mallId;
	private String catId;
	private String catName;

	private ProgressImgLoader asyncImageLoader;

	private boolean isSingleCard = false;

	private Handler handler = new Handler();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		model = new ShopPagerModel();
		ui = new ShopPagerUI();
		initMVC(model, ui, R.layout.shop_pager_layout);

		init();
	}

	private void init() {
		Intent intent = getIntent();
		if (intent.hasExtra(ConstantsActivity.INTENT_MALL_DETAIL_ID)
				&& intent.hasExtra(ConstantsActivity.INTENT_MALL_CAT_ID)) {
			isSingleCard = false;
			catName = intent
					.getStringExtra(ConstantsActivity.INTENT_MALL_CAT_NAME);
			mallId = intent
					.getStringExtra(ConstantsActivity.INTENT_MALL_DETAIL_ID);
			catId = intent.getStringExtra(ConstantsActivity.INTENT_MALL_CAT_ID);
			// mallId = "6";
			// catId = "1";
		}

		// single card
		if (!isSingleCard && intent.hasExtra(ConstantsActivity.INTENT_SHOP_ID)) {
			isSingleCard = true;
			catName = intent.getStringExtra(ConstantsActivity.INTENT_SHOP_NAME);
		}

		asyncImageLoader = new ProgressImgLoader();
		ui.setImgLoader(asyncImageLoader);
		ui.initViewPager(getSupportFragmentManager(),
				new OnPageChangeListener() {

					@Override
					public void onPageSelected(int position) {
						Log.d("Bran", "onPageSelected position = " + position);
						// single card
						if (isSingleCard) {
							ui.setTitle(catName, "");
						} else {
							int size = model.getCardSize();
							if (size > 0) {
								ui.setTitle(catName, (position + 1) + "/"
										+ size);
							}
						}

					}

					@Override
					public void onPageScrolled(int position,
							float positionOffset, int positionOffsetPixels) {
						// TODO Auto-generated method stub

					}

					@Override
					public void onPageScrollStateChanged(int state) {
						Log.d("Bran", "state = " + state);

					}
				});
		ui.setTitle(catName, "");
		ui.initClickListener(this);

		// single card
		if (isSingleCard) {
			ui.setSingleCard();
			model.initData(
					intent.getStringExtra(ConstantsActivity.INTENT_SHOP_ID), 0);
		} else {
			String userUrl = App.getInstance().getEnv().getServerUrl()
					+ ConstantsUrl.URL_SHOP_PAGER;
			StringBuilder sb = new StringBuilder(appendPageInfo(userUrl,
					OprIndex.PV_OPR));
			sb = sb.append("&mid=").append(mallId).append("&categoryId=")
					.append(catId);
			String url = sb.toString();

			model.initData(url);
		}

	}

	public Handler getHandler() {
		return handler;
	}

	@Override
	public void onClick(View view) {
		switch (view.getId()) {
		case R.id.top_bar_back_tv:
			onBackPressed();
			break;
		case R.id.top_bar_right_1_tv:
			Intent intent = new Intent();
			intent.putExtra(ConstantsActivity.INTENT_MALL_DETAIL_ID, mallId);
			intent.putExtra(ConstantsActivity.INTENT_MALL_CAT_ID, catId);
			intent.setClass(ShopPagerActivity.this, NavListActivity.class);
			ShopPagerActivity.this.startActivityForResult(intent,
					ConstantsActivity.MALL_DETAIL_REQ_CODE_NAV);
			overridePendingTransition(R.anim.in_from_up, 0);
			break;
		default:
			break;
		}
	}

	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	@Override
	public void update(int notificationId) {
		super.update(notificationId);
		switch (notificationId) {
		case ShopPagerModel.SHOP_PAGER_DONE:
			// single card
			if (isSingleCard) {
				ui.setTitle(catName, "");
			} else {
				int size = model.getCardSize();
				if (size > 0) {
					ui.setTitle(catName, "1/" + size);
				}
			}

			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
				ui.updateShopList(model.getShopPagerVo(),
						new AnimatorListener() {

							@Override
							public void onAnimationStart(Animator animation) {
							}

							@Override
							public void onAnimationRepeat(Animator animation) {
							}

							@Override
							public void onAnimationEnd(Animator animation) {
								model.countDown();
								if (model.getShopPagerVo() != null
										&& model.getShopPagerVo().shopList != null
										&& model.getShopPagerVo().shopList
												.size() > 1) {
									handler.postDelayed(new Runnable() {
										@Override
										public void run() {
											ui.setArrow(1);
										}
									}, 500);
								}
							}

							@Override
							public void onAnimationCancel(Animator animation) {
							}
						});
			} else {
				ui.updateShopList(model.getShopPagerVo(),
						new AnimationListener() {

							@Override
							public void onAnimationStart(Animation animation) {
							}

							@Override
							public void onAnimationEnd(Animation animation) {
								model.countDown();
								if (model.getShopPagerVo() != null
										&& model.getShopPagerVo().shopList != null
										&& model.getShopPagerVo().shopList
												.size() > 1) {
									handler.postDelayed(new Runnable() {
										@Override
										public void run() {
											ui.setArrow("1");
										}
									}, 1000);
								}
							}

							@Override
							public void onAnimationRepeat(Animation animation) {
							}

						});
			}
			break;
		}
	}

	@Override
	public void update(Bundle bundle) {
		super.update(bundle);
		int notificationId = bundle.getInt("notificationId");
		int index = bundle.getInt("index");
		ShopFragment f = (ShopFragment) ui.getFragment(index);
		switch (notificationId) {
		case ShopPagerModel.SHOP_CARD_DONE:
			if (f != null && getCardData(index) != null) {
				f.setShopCardVo(getCardData(index));
			}
			break;
		case ShopPagerModel.SHOP_CARD_FAILURE:
			if (f != null) {
				f.setShopCardVo(null);
			}
			break;
		case ShopPagerModel.SHOP_SUBSCRIBE_START:
			if (f != null) {
				f.setSubClickable(false);
				boolean isSub = bundle.getBoolean("isSub");
				f.setSubState(isSub);
			}
			break;
		case ShopPagerModel.SHOP_SUBSCRIBE_DONE: {
			boolean isSub = bundle.getBoolean("isSub");
			if (f != null) {
				f.setSubState(isSub);
				// if(isSub) {
				// showToast("关注成功", R.drawable.mall_detail_sub_success);
				// }
				// else {
				// showToast("取消关注成功", R.drawable.mall_detail_sub_fail);
				// }
			}
			ShopCardVo vo = getCardData(index);
			if (vo != null) {
				vo.isSub = isSub;
				if (f != null) {
					f.setSubClickable(true);
				}
			}
		}
			break;
		case ShopPagerModel.SHOP_SUBSCRIBE_FAILURE:
			if (f != null) {
				boolean isSub = bundle.getBoolean("isSub");
				f.setSubState(isSub);
				if (isSub) {
					showToast("取消关注失败", R.drawable.mall_detail_sub_fail);
				} else {
					showToast("关注失败", R.drawable.mall_detail_sub_fail);
				}
				f.setSubClickable(true);
			}
			break;

		case ShopPagerModel.SHOP_QUERY_SUB_DONE:
			if (f != null) {
				boolean isSub = bundle.getBoolean("isSub");
				f.setSubState(isSub);
				ShopCardVo vo = getCardData(index);
				if (vo != null) {
					vo.isSub = isSub;
				}
			}
			break;
		}

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == RESULT_OK) {
			switch (requestCode) {
			case ConstantsActivity.MALL_DETAIL_REQ_CODE_NAV: {
				String shopId = data
						.getStringExtra(ConstantsActivity.INTENT_SHOP_DETAIL_ID);
				if (StringUtils.isNotEmpty(shopId)) {
					int index = getShopIndex(shopId);
					if (index > -1) {
						ui.scrollTo(index);
					}
				}
			}
				break;
			case ConstantsActivity.MALL_DETAIL_REQ_SUB: {
				String shopId = data
						.getStringExtra(ConstantsActivity.INTENT_SHOP_ID);
				int index = data.getIntExtra(
						ConstantsActivity.INTENT_SHOP_INDEX, -1);
				if (index > -1 && StringUtils.isNotEmpty(shopId)) {
					querySub(index, shopId);
				}
			}
				break;
			default:
				break;
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	private void querySub(int index, String shopId) {
		String userUrl = App.getInstance().getEnv().getServerUrl()
				+ ConstantsUrl.URL_QUERY_SUB;
		StringBuilder sb = new StringBuilder(appendPageInfo(userUrl,
				OprIndex.NON_PV_OPR));
		sb = sb.append("&tp=3&pid=").append(shopId);
		String url = sb.toString();

		model.querySub(url, index);
	}

	private int getShopIndex(String shopId) {
		List<String> shopList = model.getShopPagerVo().shopList;
		if (shopList != null && shopList.size() > 0) {
			int length = shopList.size();
			for (int i = 0; i < length; i++) {
				if (shopId.equals(shopList.get(i))) {
					return i;
				}
			}
		}
		return -1;
	}

	@Override
	public ShopCardVo getCardData(int index) {

		return model.getShopCardVo(index);
	}

	@Override
	public void startLoadingCard(int index, String shopId) {

		String userUrl = App.getInstance().getEnv().getServerUrl()
				+ ConstantsUrl.URL_SHOP_CARD_DETAIL;
		StringBuilder sb = new StringBuilder(appendPageInfo(userUrl,
				OprIndex.NON_PV_OPR));
		sb = sb.append("&shid=").append(shopId);
		String url = sb.toString();

		model.loadShopCard(url, index);

	}

	@Override
	public ProgressImgLoader getProgressImgLoader() {
		return asyncImageLoader;
	}

	@Override
	public void showAllPromotion(List<PromotionItem> promotionList) {

		PromotionFragment fragment = new PromotionFragment();
		fragment.setPromotionList(promotionList);

		// Add the fragment to the activity, pushing this transaction
		// on to the back stack.
		FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
		ft.add(R.id.outter_view, fragment);
		ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
		ft.addToBackStack(null);
		ft.commit();
	}

	@Override
	public void changeShopSub(int index, String shopId) {
		ShopCardVo shopCardVo = model.getShopCardVo(index);
		if (shopCardVo != null) {
			boolean isSub = shopCardVo.isSub;
			String userUrl = App.getInstance().getEnv().getServerUrl()
					+ (isSub ? ConstantsUrl.URL_REMOVE_SUBSCRIBE
							: ConstantsUrl.URL_ADD_SUBSCRIBE);
			StringBuilder sb = new StringBuilder(appendPageInfo(userUrl,
					OprIndex.USER_OPR));
			sb = sb.append("&&tp=3&pid=").append(shopId);
			String url = sb.toString();
			model.changeSubscribeRel(url, index, isSub);
		}
	}

	@Override
	public void startNextActivity(Intent intent) {
		startActivity(intent);
	}

	@Override
	public void startNextActivity(Intent intent, int reqCode) {
		startActivityForResult(intent, reqCode);
	}

	private int sharedIndex = -1;

	@Override
	public void shareToWX(int index) {
		ShopCardVo shopCardVo = getCardData(index);
		if (shopCardVo != null) {
			sharedIndex = index;
			shareToWX();
		}
	}

	@Override
	protected void onShare2WechatFriends() {
		ShopCardVo shopCardVo = getCardData(sharedIndex);
		if (shopCardVo != null) {
			Bitmap bitmap = ImageUtils.getBitmapFromLocal(shopCardVo.shopLogo);
			if (bitmap == null)
			// 如果没有图片的话就用APP图标来替代
			{
				bitmap = BitmapFactory.decodeResource(getResources(),
						R.drawable.ic_launcher);
			}
			String title = shopCardVo.shopName + "挺不错的，一起去逛逛吧。";
			String desc = "优惠促销活动中";
			boolean shareSuccess = WXUtils
					.shareWebpageToFriends(this, title, desc, bitmap,
							"http://act.m.buy.qq.com/t/showAct.xhtml?tid=share_back_test");
			if (!shareSuccess) {
				Toast.makeText(this, "分享失败", Constants.TOAST_NORMAL_LONG)
						.show();
			}
		}

	}

	@Override
	protected void onShare2WechatTimeline() {
		ShopCardVo shopCardVo = getCardData(sharedIndex);
		if (shopCardVo != null) {
			Bitmap bitmap = ImageUtils.getBitmapFromLocal(shopCardVo.shopLogo);
			if (bitmap == null)
			// 如果没有图片的话就用APP图标来替代
			{
				bitmap = BitmapFactory.decodeResource(getResources(),
						R.drawable.ic_launcher);
			}
			String title = shopCardVo.shopName + "挺不错的，一起去逛逛吧。";
			String desc = "优惠促销活动中";
			boolean shareSuccess = WXUtils
					.shareWebpageToTimeline(this, title, desc, bitmap,
							"http://act.m.buy.qq.com/t/showAct.xhtml?tid=share_back_test");
			if (!shareSuccess) {
				Toast.makeText(this, "分享失败", Constants.TOAST_NORMAL_LONG)
						.show();
			}
		}

	}

	@Override
	public void closeFragment() {
		onBackPressed();

	}

}
