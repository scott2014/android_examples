package com.tencent.weigou.shopping.view;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.graphics.Bitmap;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.tencent.weigou.R;
import com.tencent.weigou.base.model.vo.CommonVo;
import com.tencent.weigou.base.view.UI;
import com.tencent.weigou.common.ui.AdaptiveImageView;
import com.tencent.weigou.common.ui.ScaleImageView;
import com.tencent.weigou.common.ui.TabTitle;
import com.tencent.weigou.common.ui.draggable.DraggableListView;
import com.tencent.weigou.feeds.activity.FeedListActivity;
import com.tencent.weigou.shopping.activity.ShoppingIndexActivity;
import com.tencent.weigou.shopping.model.vo.BrandListVo;
import com.tencent.weigou.shopping.model.vo.BrandListVo.BrandVo;
import com.tencent.weigou.shopping.model.vo.MallListVo;
import com.tencent.weigou.shopping.model.vo.MallListVo.MallVo;
import com.tencent.weigou.util.Util;

/**
 * 
 * @author jonathanqi
 * 
 */
public class ShoppingUI extends UI implements OnClickListener {

	private ViewPager viewPager;// 页卡内容
	private DraggableListView mallListView;
	private DraggableListView brandListView;
	private DraggableListView brandGridView;
	private BrandListAdapter brandListAdapter;
	private MallListAdapter mallListAdapter;
	private NavGridAdapter navGridAdapter;
	private TextView mallTabBtn;
	private TextView brandTabBtn;
	// private TextView titleTv;
	// private LinearLayout tabHostOutter;
	private List<View> views = new ArrayList<View>();// Tab页面列表
	private View mallView, brandView;// 各个页卡
	private float oldY = -1;
	int screenWidth;
	int screenHeight;
	private boolean animeing = false;
	private boolean touchUp = false;
	private int curr = 0;
	private TabTitle tabTitle;
	List<MallVo> mallList = new ArrayList<MallListVo.MallVo>();
	List<BrandVo> brandList = new ArrayList<BrandListVo.BrandVo>();
	TextView moreBtn;
	TextView moreBtnTxt;
	int imageWidth;
	RelativeLayout networkRL;

	@Override
	public void initView(View outterView) {
		super.initView(outterView);
		networkRL = (RelativeLayout) findViewById(R.id.network_un);
		viewPager = (ViewPager) findViewById(R.id.view_pager);
		// tabHostOutter = (LinearLayout) findViewById(R.id.tab_host_outter);
		// // tabTitle = (TabTitle) findViewById(R.id.tab_host);
		// titleTv = (TextView) findViewById(R.id.title_tv);
		mallTabBtn = (TextView) findViewById(R.id.mall_tab_btn);
		brandTabBtn = (TextView) findViewById(R.id.brand_tab_btn);
		TextView cityBtn = (TextView) findViewById(R.id.shopping_index_city);
		findViewById(R.id.shopping_index_city_arrow).setOnClickListener(
				(ShoppingIndexActivity) context);
		cityBtn.setOnClickListener((ShoppingIndexActivity) context);

		moreBtn = (TextView) findViewById(R.id.shopping_index_more);
		moreBtnTxt = (TextView) findViewById(R.id.shopping_index_more_txt);
		initTabs();
		initMallView();
		initBrandView();
		imageWidth = (Util.getScreenWidth(((Activity) context)
				.getWindowManager()) - Util.dip2px(context, 30)) / 2;
		options = new DisplayImageOptions.Builder()
				.showImageOnLoading(R.drawable.loading_big)
				.showImageForEmptyUri(R.drawable.loading_big)
				.showImageOnFail(R.drawable.loading_big).cacheInMemory(true)
				.cacheOnDisc(true).considerExifParams(true)
				.imageScaleType(ImageScaleType.IN_SAMPLE_INT)
				.bitmapConfig(Bitmap.Config.RGB_565).build();
	}

	public void initTabs() {
		// underline.setScaleType(ScaleType.MATRIX);
		// TextView tv = new TextView(context);
		//
		// screenWidth = Util.getScreenWidth(((Activity) context)
		// .getWindowManager());
		// screenHeight = Util.getScreenHeight(((Activity) context)
		// .getWindowManager());
		// tv.layout(0, 0, screenWidth / 9, Util.px2dip(context, 10));
		// tv.setBackgroundColor(context.getResources().getColor(R.color.black));
		// tv.setDrawingCacheEnabled(true);
		// tv.buildDrawingCache(true);
		// Bitmap bitmap = tv.getDrawingCache();
		// underline.setImageBitmap(bitmap);
		mallView = LayoutInflater.from(context).inflate(R.layout.shopping_mall,
				null);
		mallListView = (DraggableListView) mallView
				.findViewById(R.id.shopping_mall_listview);
		brandView = LayoutInflater.from(context).inflate(
				R.layout.shopping_brand, null);
		brandListView = (DraggableListView) brandView
				.findViewById(R.id.shopping_brand_listview);
		brandGridView = (DraggableListView) brandView
				.findViewById(R.id.shopping_brand_gridview);
		views.add(mallView);
		views.add(brandView);
		ViewPagerAdapter adpater = new ViewPagerAdapter();
		viewPager.setAdapter(adpater);
		viewPager
				.setOnPageChangeListener(new ViewPagerOnPagerChangerListener());
		mallTabBtn.setOnClickListener(this);
		brandTabBtn.setOnClickListener(this);
	}

	private void initMallView() {
		mallListAdapter = new MallListAdapter();
		mallListView.setAdapter(mallListAdapter);
		mallListView.setRefreshListener((ShoppingIndexActivity) context);
		mallListView.setDividerHeight(Util.dip2px(context, 15));
		// mallListView.setOnItemClickListener((ShoppingIndexActivity) context);
		mallListView.getFoot().setId(R.id.shopping_mall_listview_inner);
	}

	private void initBrandView() {
		brandListAdapter = new BrandListAdapter();
		brandListView.setAdapter(brandListAdapter);
		brandListView.setRefreshListener((ShoppingIndexActivity) context);
		brandListView.setDividerHeight(Util.dip2px(context, 15));
		// brandListView.setOnItemClickListener((ShoppingIndexActivity)
		// context);
		brandListView.getFoot().setId(R.id.shopping_brand_listview_inner);
		moreBtn.setOnClickListener((ShoppingIndexActivity) context);
		moreBtnTxt.setOnClickListener((ShoppingIndexActivity) context);
		navGridAdapter = new NavGridAdapter();
		brandGridView.setAdapter(navGridAdapter);
		brandGridView.setRefreshListener((ShoppingIndexActivity) context);
		brandGridView.getFoot().setId(R.id.shopping_brand_gridview_inner);
		// brandGridView.setOnItemClickListener((ShoppingIndexActivity)
		// context);
		// brandGridView.setSelector(new ColorDrawable(Color.TRANSPARENT));
		// LinearLayout gridViewLL = (LinearLayout) brandView
		// .findViewById(R.id.shopping_brand_gridview_ll);
		// gridViewLL.addView(brandGridView.getFoot());
		// brandListView.setOnScrollListener(this);
	}

	public void updateContent(CommonVo rv) {
		moreBtn.setVisibility(View.INVISIBLE);
		moreBtnTxt.setVisibility(View.INVISIBLE);
		this.mallList = ((MallListVo) rv).list;
		mallListAdapter.notifyDataSetChanged();
	}

	public void resetMallFooter(boolean updateTime) {
		mallListView.resetFoot(updateTime);
	}

	public void resetBrandFooter(boolean updateTime) {
		brandListView.resetFoot(updateTime);
		brandGridView.resetFoot(updateTime);
	}

	public void updateMallSub(int index) {
		int visiblePos = mallListView.getFirstVisiblePosition();
		int offset = index - visiblePos;

		if (offset < 0)
			return;

		View view = mallListView.getChildAt(offset);
		if (view == null) {
			return;
		}
		MallViewHolder holder = (MallViewHolder) view.getTag();
		if (mallList.get(index).userSubscribled == 1) {
			holder.subscribeTv.setBackgroundResource(R.drawable.heart_selected);
		} else {
			holder.subscribeTv.setBackgroundResource(R.drawable.heart_plus);
		}
	}

	public void updateBrandContent(CommonVo rv) {
		List<BrandVo> brandList = ((BrandListVo) rv).list;
		this.brandList = brandList;
		brandListAdapter.notifyDataSetChanged();
		navGridAdapter.notifyDataSetChanged();

	}

	public void updateBrandSub(int index) {
		int visiblePos = brandListView.getFirstVisiblePosition();
		int offset = index - visiblePos;

		if (offset < 0)
			return;

		View view = brandListView.getChildAt(offset);
		if (view == null) {
			return;
		}
	}

	class ViewPagerOnPagerChangerListener implements OnPageChangeListener {

		@Override
		public void onPageScrollStateChanged(int arg0) {
		}

		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {
			// Matrix matrix = new Matrix();
			// switch (arg0) {
			// case 0:
			// selectMallTab();
			// break;
			// case 1:
			// selectBrandTab();
			// break;
			// }
			// float t = screenWidth / 4.5f * arg1;
			// matrix.postTranslate(t, 0);
			// underline.setImageMatrix(matrix);
		}

		@Override
		public void onPageSelected(int arg0) {
			curr = arg0;
			// if (!StringUtils.isBlank(titleTv.getText().toString())) {
			// if (curr == 0) {
			// titleTv.setText("商场");
			// } else {
			// titleTv.setText("品牌");
			// }
			// }
			if (curr == 0) {
				selectMallTab();
				moreBtn.setVisibility(View.INVISIBLE);
				moreBtnTxt.setVisibility(View.INVISIBLE);
			} else {
				selectBrandTab();
				moreBtn.setVisibility(View.VISIBLE);
				moreBtnTxt.setVisibility(View.VISIBLE);
			}
		}
	}

	public class ViewPagerAdapter extends PagerAdapter {

		@Override
		public int getCount() {
			return views.size();
		}

		@Override
		public Object instantiateItem(ViewGroup container, int position) {
			((ViewPager) container).addView(views.get(position));
			return views.get(position);
		}

		@Override
		public boolean isViewFromObject(View view, Object object) {
			return view == object;
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			// TODO Auto-generated method stub
			((ViewPager) container).removeView(views.get(position));
		}
	}

	public class MallListAdapter extends BaseAdapter {

		@Override
		public int getCount() {
			return mallList.size();
		}

		@Override
		public Object getItem(int position) {
			return mallList.get(position);
		}

		@Override
		public long getItemId(int position) {
			return 0;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			MallViewHolder holder;
			MallVo mallVo = mallList.get(position);
			if (convertView == null) {
				convertView = LayoutInflater.from(context).inflate(
						R.layout.shopping_mall_item, null);
				holder = new MallViewHolder();
				holder.bgIV = (ScaleImageView) convertView
						.findViewById(R.id.shopping_mall_item_bg);
				holder.nameTV = (TextView) convertView
						.findViewById(R.id.shopping_mall_name);
				holder.logoIV = (ImageView) convertView
						.findViewById(R.id.mall_logo);
				holder.subscribeTv = (TextView) convertView
						.findViewById(R.id.mall_heart);
				holder.shop1IV = (AdaptiveImageView) convertView
						.findViewById(R.id.shop_logo_1);
				holder.shop1TV = (TextView) convertView
						.findViewById(R.id.shop_logo_txt_1);
				holder.shop2IV = (AdaptiveImageView) convertView
						.findViewById(R.id.shop_logo_2);
				holder.shop2TV = (TextView) convertView
						.findViewById(R.id.shop_logo_txt_2);
				holder.shop3IV = (AdaptiveImageView) convertView
						.findViewById(R.id.shop_logo_3);
				holder.shop3TV = (TextView) convertView
						.findViewById(R.id.shop_logo_txt_3);
				holder.actIV1 = (ScaleImageView) convertView
						.findViewById(R.id.shopping_act_logo_1);
				holder.actIV2 = (ScaleImageView) convertView
						.findViewById(R.id.shopping_act_logo_2);
				holder.shoppingLogoItem1TV = (LinearLayout) convertView
						.findViewById(R.id.shopping_logo_item_1);
				holder.shoppingLogoItem2TV = (LinearLayout) convertView
						.findViewById(R.id.shopping_logo_item_2);
				holder.shoppingLogoItem3TV = (LinearLayout) convertView
						.findViewById(R.id.shopping_logo_item_3);
				convertView.setTag(holder);
			} else {
				holder = (MallViewHolder) convertView.getTag();
			}
			holder.bgIV.setTag(mallVo);
			holder.nameTV.setTag(mallVo);
			holder.logoIV.setTag(mallVo);
			holder.bgIV.setScale(1.62f);
			holder.nameTV.setText(mallVo.name);
			imageLoader.displayImage(mallVo.bg, holder.bgIV, options,
					animateFirstListener);
			imageLoader.displayImage(mallVo.logo, holder.logoIV, options,
					animateFirstListener);

			if (mallVo.userSubscribled == 1) {
				holder.subscribeTv
						.setBackgroundResource(R.drawable.heart_selected);
			} else {
				holder.subscribeTv.setBackgroundResource(R.drawable.heart_plus);
			}
			holder.subscribeTv.setTag(mallVo);
			holder.subscribeTv
					.setOnClickListener((ShoppingIndexActivity) context);
			holder.bgIV.setOnClickListener((ShoppingIndexActivity) context);
			holder.nameTV.setOnClickListener((ShoppingIndexActivity) context);
			holder.logoIV.setOnClickListener((ShoppingIndexActivity) context);
			int size = 3;
			if (mallVo.brands.size() < 3) {
				size = mallVo.brands.size();
			}
			if (mallVo.brands.size() == 0) {
				convertView.findViewById(R.id.shopping_mall_item_logo_ll)
						.setVisibility(View.GONE);
			} else {
				convertView.findViewById(R.id.shopping_mall_item_logo_ll)
						.setVisibility(View.VISIBLE);
			}

			if (mallVo.acts.size() == 0) {
				convertView.findViewById(R.id.shopping_act_ll).setVisibility(
						View.GONE);

			} else {
				convertView.findViewById(R.id.shopping_act_ll).setVisibility(
						View.VISIBLE);
				View act1 = convertView.findViewById(R.id.shopping_act_item_1);
				View act2 = convertView.findViewById(R.id.shopping_act_item_2);
				if (mallVo.acts.size() == 1) {
					holder.actIV1.setScale(4.28f);
					act1.setTag(mallVo.acts.get(0));
					act1.setOnClickListener((ShoppingIndexActivity) context);
					imageLoader.displayImage(mallVo.acts.get(0).imageUrl,
							holder.actIV1, options, animateFirstListener);
					act2.setVisibility(View.GONE);
				}
				if (mallVo.acts.size() == 2) {
					act1.setVisibility(View.VISIBLE);
					act2.setVisibility(View.VISIBLE);
					for (int i = 0; i < mallVo.acts.size(); i++) {
						switch (i) {
						case 0:
							holder.actIV1.setScale(2.14f);
							act1.setTag(mallVo.acts.get(i));
							act1.setOnClickListener((ShoppingIndexActivity) context);
							imageLoader.displayImage(
									mallVo.acts.get(i).imageUrl, holder.actIV1,
									options, animateFirstListener);

							break;
						case 1:
							holder.actIV2.setScale(2.14f);
							act2.setTag(mallVo.acts.get(i));
							act2.setOnClickListener((ShoppingIndexActivity) context);
							imageLoader.displayImage(
									mallVo.acts.get(i).imageUrl, holder.actIV2,
									options, animateFirstListener);
							break;
						}
					}
				}

			}

			for (int i = 0; i < size; i++) {
				switch (i) {
				case 0:
					holder.shop1IV.setVisibility(View.VISIBLE);
					holder.shop1IV.setTag(mallVo.brands.get(i).logo + "&id="
							+ mallVo.brands.get(i).id + "&name="
							+ mallVo.brands.get(i).fullName);
					holder.shop1TV.setText(mallVo.brands.get(i).promote);
					holder.shoppingLogoItem1TV.setTag(mallVo.brands.get(i).logo
							+ "&id=" + mallVo.brands.get(i).id + "&name="
							+ mallVo.brands.get(i).fullName);
					holder.shop1IV.setDrawCircleBorder(true);
					imageLoader.displayImage(mallVo.brands.get(i).logo,
							holder.shop1IV, options, animateFirstListener);
					holder.shoppingLogoItem1TV
							.setOnClickListener((ShoppingIndexActivity) context);
					break;
				case 1:
					holder.shop2IV.setVisibility(View.VISIBLE);
					holder.shop2IV.setTag(mallVo.brands.get(i).logo + "&id="
							+ mallVo.brands.get(i).id + "&name="
							+ mallVo.brands.get(i).fullName);
					holder.shop2TV.setText(mallVo.brands.get(i).promote);
					holder.shoppingLogoItem2TV.setTag(mallVo.brands.get(i).logo
							+ "&id=" + mallVo.brands.get(i).id + "&name="
							+ mallVo.brands.get(i).fullName);
					holder.shop2IV.setDrawCircleBorder(true);
					imageLoader.displayImage(mallVo.brands.get(i).logo,
							holder.shop2IV, options, animateFirstListener);
					holder.shoppingLogoItem2TV
							.setOnClickListener((ShoppingIndexActivity) context);
					break;
				case 2:
					holder.shop3IV.setVisibility(View.VISIBLE);
					holder.shop3IV.setTag(mallVo.brands.get(i).logo + "&id="
							+ mallVo.brands.get(i).id + "&name="
							+ mallVo.brands.get(i).fullName);
					holder.shop3TV.setText(mallVo.brands.get(i).promote);
					holder.shoppingLogoItem3TV.setTag(mallVo.brands.get(i).logo
							+ "&id=" + mallVo.brands.get(i).id + "&name="
							+ mallVo.brands.get(i).fullName);
					holder.shop3IV.setDrawCircleBorder(true);
					imageLoader.displayImage(mallVo.brands.get(i).logo,
							holder.shop3IV, options, animateFirstListener);
					holder.shoppingLogoItem3TV
							.setOnClickListener((ShoppingIndexActivity) context);
					break;
				}

			}

			return convertView;
		}
	}

	public class BrandListAdapter extends BaseAdapter {

		@Override
		public int getCount() {
			return brandList.size();
		}

		@Override
		public Object getItem(int position) {
			return brandList.get(position);
		}

		@Override
		public long getItemId(int position) {
			return 0;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			BrandViewHolder holder;
			if (convertView == null) {
				convertView = LayoutInflater.from(context).inflate(
						R.layout.shopping_brand_item, null);
				holder = new BrandViewHolder();
				holder.bgIV = (ScaleImageView) convertView
						.findViewById(R.id.shopping_brand_item_bg);
//				holder.subscribeTv = (TextView) convertView
//						.findViewById(R.id.brand_heart);
				// holder.bgIV.setScale(scale)
				holder.logoIV = (ImageView) convertView
						.findViewById(R.id.brand_logo);
				holder.descTV = (TextView) convertView
						.findViewById(R.id.shopping_brand_desc);
				holder.shop1IV = (ImageView) convertView
						.findViewById(R.id.brand_shop_item1_iv);
				holder.shopName1TV = (TextView) convertView
						.findViewById(R.id.brand_shop_item1_tv);

				holder.shop2IV = (ImageView) convertView
						.findViewById(R.id.brand_shop_item2_iv);
				holder.shopName2TV = (TextView) convertView
						.findViewById(R.id.brand_shop_item2_tv);

				holder.shop3IV = (ImageView) convertView
						.findViewById(R.id.brand_shop_item3_iv);
				holder.shopName3TV = (TextView) convertView
						.findViewById(R.id.brand_shop_item3_tv);
				holder.shoppingItem1RL = (RelativeLayout) convertView
						.findViewById(R.id.brand_shop_item1_rl);
				holder.shoppingItem2RL = (RelativeLayout) convertView
						.findViewById(R.id.brand_shop_item2_rl);
				holder.shoppingItem3RL = (RelativeLayout) convertView
						.findViewById(R.id.brand_shop_item3_rl);
				convertView.setTag(holder);
			} else {
				holder = (BrandViewHolder) convertView.getTag();
			}
			holder.bgIV.setOnClickListener((ShoppingIndexActivity) context);
			holder.logoIV.setOnClickListener((ShoppingIndexActivity) context);
			holder.descTV.setOnClickListener((ShoppingIndexActivity) context);
			holder.bgIV.setScale(1.62f);
			BrandVo brandVo = brandList.get(position);
			holder.bgIV.setTag(brandVo);
			holder.logoIV.setTag(brandVo);
			holder.descTV.setTag(brandVo);
			imageLoader.displayImage(brandVo.bg, holder.bgIV, options,
					animateFirstListener);
			imageLoader.displayImage(brandVo.logo, holder.logoIV, options,
					animateFirstListener);
			// asyncLoadImage(holder.bgIV, brandVo.bg, 0, 0,
			// R.drawable.loading_big, true, false);
			// asyncLoadImage(holder.logoIV, brandVo.logo, 0, 0,
			// R.drawable.loading_big, true, false);
			holder.descTV.setText(brandVo.desc);
			holder.shop1IV.setVisibility(View.INVISIBLE);
			holder.shopName1TV.setVisibility(View.INVISIBLE);
			holder.shop2IV.setVisibility(View.INVISIBLE);
			holder.shopName2TV.setVisibility(View.INVISIBLE);
			holder.shop3IV.setVisibility(View.INVISIBLE);
			holder.shopName3TV.setVisibility(View.INVISIBLE);
			for (int i = 0; i < brandVo.shops.size(); i++) {
				switch (i) {
				case 0:
					holder.shop1IV.setVisibility(View.VISIBLE);
					holder.shop1IV.setTag(brandVo.shops.get(i).url + "&id="
							+ brandVo.shops.get(i).shopId + "&name="
							+ brandVo.shops.get(i).fullName);
					holder.shopName1TV.setVisibility(View.VISIBLE);
					holder.shopName1TV.setText(brandVo.shops.get(i).name);
					imageLoader.displayImage(brandVo.shops.get(i).url,
							holder.shop1IV, options, animateFirstListener);
					// asyncLoadImage(holder.shop1IV, brandVo.shops.get(i).url,
					// screenWidth / 4, screenWidth / 4,
					// R.drawable.loading_big, true, true);
					holder.shoppingItem1RL.setTag(brandVo.shops.get(i).url
							+ "&id=" + brandVo.shops.get(i).shopId + "&name="
							+ brandVo.shops.get(i).fullName);
					holder.shoppingItem1RL
							.setOnClickListener((ShoppingIndexActivity) context);
					break;
				case 1:
					holder.shop2IV.setVisibility(View.VISIBLE);
					holder.shop2IV.setTag(brandVo.shops.get(i).url + "&id="
							+ brandVo.shops.get(i).shopId + "&name="
							+ brandVo.shops.get(i).fullName);
					holder.shopName2TV.setText(brandVo.shops.get(i).name);
					holder.shopName2TV.setVisibility(View.VISIBLE);
					imageLoader.displayImage(brandVo.shops.get(i).url,
							holder.shop2IV, options, animateFirstListener);
					holder.shoppingItem2RL.setTag(brandVo.shops.get(i).url
							+ "&id=" + brandVo.shops.get(i).shopId + "&name="
							+ brandVo.shops.get(i).fullName);
					holder.shoppingItem2RL
							.setOnClickListener((ShoppingIndexActivity) context);
					break;
				case 2:
					holder.shop3IV.setVisibility(View.VISIBLE);
					holder.shop3IV.setTag(brandVo.shops.get(i).url + "&id="
							+ brandVo.shops.get(i).shopId + "&name="
							+ brandVo.shops.get(i).fullName);
					holder.shopName3TV.setVisibility(View.VISIBLE);
					holder.shopName3TV.setText(brandVo.shops.get(i).name);
					imageLoader.displayImage(brandVo.shops.get(i).url,
							holder.shop3IV, options, animateFirstListener);
					holder.shoppingItem3RL.setTag(brandVo.shops.get(i).url
							+ "&id=" + brandVo.shops.get(i).shopId + "&name="
							+ brandVo.shops.get(i).fullName);
					holder.shoppingItem3RL
							.setOnClickListener((ShoppingIndexActivity) context);
					break;
				}

			}

			return convertView;
		}
	}

	public class NavGridAdapter extends BaseAdapter {

		@Override
		public int getCount() {
			float f = brandList.size() / 2.0f;
			return (int) Math.ceil(f);
		}

		@Override
		public Object getItem(int position) {
			return null;
		}

		@Override
		public long getItemId(int position) {
			return 0;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			BrandGridViewHolder holder;
			if (convertView == null) {
				convertView = LayoutInflater.from(context).inflate(
						R.layout.shopping_nav_brand_item, null);
				holder = new BrandGridViewHolder();
				holder.bgIV1 = (ScaleImageView) convertView
						.findViewById(R.id.shopping_nav_item_bg1);
				holder.bgIV1.setScale(0.66f);
				holder.logoIV1 = (ImageView) convertView
						.findViewById(R.id.shopping_nav_item_logo1);
				holder.nameTV1 = (TextView) convertView
						.findViewById(R.id.shopping_nav_item_name1);

				holder.bgIV2 = (ScaleImageView) convertView
						.findViewById(R.id.shopping_nav_item_bg2);
				holder.bgIV2.setScale(0.66f);
				holder.logoIV2 = (ImageView) convertView
						.findViewById(R.id.shopping_nav_item_logo2);
				holder.nameTV2 = (TextView) convertView
						.findViewById(R.id.shopping_nav_item_name2);
				holder.rl1 = (RelativeLayout) convertView
						.findViewById(R.id.shopping_nav_item_rl1);
				holder.rl2 = (RelativeLayout) convertView
						.findViewById(R.id.shopping_nav_item_rl2);
				convertView.setTag(holder);
			} else {
				holder = (BrandGridViewHolder) convertView.getTag();
			}
			BrandVo niVo1 = null;
			BrandVo niVo2 = null;
			if (position * 2 < brandList.size()) {
				niVo1 = brandList.get(position * 2);
			}
			if (position * 2 + 1 < brandList.size()) {
				niVo2 = brandList.get(position * 2 + 1);
			}

			if (niVo1 != null) {
				imageLoader.displayImage(niVo1.bgH, holder.bgIV1, options,
						animateFirstListener);
				imageLoader.displayImage(niVo1.logo, holder.logoIV1, options,
						animateFirstListener);
				holder.nameTV1.setText(niVo1.name);
			}
			if (niVo2 != null) {
				imageLoader.displayImage(niVo2.bgH, holder.bgIV2, options,
						animateFirstListener);
				imageLoader.displayImage(niVo2.logo, holder.logoIV2, options,
						animateFirstListener);
				holder.nameTV2.setText(niVo2.name);
				holder.rl2.setVisibility(View.VISIBLE);
			} else {
				holder.rl2.setVisibility(View.INVISIBLE);
			}
			holder.rl1.setTag(niVo1);
			holder.rl1.setOnClickListener((ShoppingIndexActivity) context);
			holder.rl2.setTag(niVo2);
			holder.rl2.setOnClickListener((ShoppingIndexActivity) context);
			return convertView;
		}
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.mall_tab_btn:
			viewPager.setCurrentItem(0);
			selectMallTab();
			break;
		case R.id.brand_tab_btn:
			viewPager.setCurrentItem(1);
			selectBrandTab();
			break;
		}
	}

	private void selectMallTab() {
		mallTabBtn
				.setBackgroundResource(R.drawable.index_left_btn_round_pressed);
		mallTabBtn.setTextColor(context.getResources().getColor(R.color.white));
		brandTabBtn.setBackgroundResource(R.drawable.index_right_btn_round);
		brandTabBtn.setTextColor(context.getResources().getColor(
				R.color.index_tab_bg));
	}

	private void selectBrandTab() {
		brandTabBtn
				.setBackgroundResource(R.drawable.index_right_btn_round_pressed);
		brandTabBtn
				.setTextColor(context.getResources().getColor(R.color.white));

		mallTabBtn.setBackgroundResource(R.drawable.index_left_btn_round);
		mallTabBtn.setTextColor(context.getResources().getColor(
				R.color.index_tab_bg));
	}

	static class BrandViewHolder {
		ImageView logoIV;
		ScaleImageView bgIV;
		TextView descTV;
		ImageView shop1IV;
		TextView shopName1TV;
		ImageView shop2IV;
		TextView shopName2TV;
		ImageView shop3IV;
		TextView shopName3TV;
		RelativeLayout shoppingItem1RL;
		RelativeLayout shoppingItem2RL;
		RelativeLayout shoppingItem3RL;

	}

	static class BrandGridViewHolder {
		ImageView logoIV1;
		ScaleImageView bgIV1;
		TextView nameTV1;
		ImageView logoIV2;
		ScaleImageView bgIV2;
		TextView nameTV2;
		RelativeLayout rl1;
		RelativeLayout rl2;
	}

	static class MallViewHolder {
		TextView subscribeTv;
		ImageView logoIV;
		TextView nameTV;
		ScaleImageView bgIV;
		ScaleImageView actIV1;
		ScaleImageView actIV2;
		AdaptiveImageView shop1IV;
		TextView shop1TV;
		AdaptiveImageView shop2IV;
		TextView shop2TV;
		AdaptiveImageView shop3IV;
		TextView shop3TV;
		LinearLayout shoppingLogoItem1TV;
		LinearLayout shoppingLogoItem2TV;
		LinearLayout shoppingLogoItem3TV;
	}

	private int mode = 0;// 0为list，1为grid

	public void changeMode() {
		if (mode == 0) {
			brandListView.setVisibility(View.GONE);
			brandGridView.setVisibility(View.VISIBLE);
			moreBtn.setBackgroundResource(R.drawable.top_bar_switch_selector);
			moreBtnTxt.setText("大图");
			mode = 1;
		} else {
			brandListView.setVisibility(View.VISIBLE);
			brandGridView.setVisibility(View.GONE);
			moreBtn.setBackgroundResource(R.drawable.top_bar_more_selector);
			moreBtnTxt.setText("列表");
			mode = 0;
		}

	}

	public void hideNetworkUnavailable() {
		if (networkRL != null) {
			networkRL.setVisibility(View.GONE);
		}
	}

	public void showNetworkUnavailable() {
		networkRL.setVisibility(View.VISIBLE);
		networkRL.findViewById(R.id.refreshBtn).setOnClickListener(
				(ShoppingIndexActivity) context);

	}
}
