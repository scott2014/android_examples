package com.tencent.weigou.shopping.model.vo;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONArray;
import org.json.JSONObject;

import com.tencent.weigou.base.model.vo.CommonVo;
import com.tencent.weigou.shopping.model.ShoppingModel;
import com.tencent.weigou.util.StringUtils;

public class BrandListVo extends CommonVo {
	public List<BrandVo> list = new ArrayList<BrandVo>();
	public String currId;
	public int index;
	private final static Pattern pattern = Pattern.compile(".*\\((.*)\\).*");

	public class BrandVo {
		public String logo;
		public String id;
		public String desc;
		public String name;
		public String bg;
		public int userSubscribled;
		public String bgH;
		public List<ShopVo> shops = new ArrayList<ShopVo>();
	}

	public class ShopVo {
		public String url;
		public String mallId;
		public String shopId;
		public String name;
		public String fullName;
	}

	@Override
	public boolean parse(JSONObject jo) {
		if (super.parse(jo)) {
			if (notificationId == ShoppingModel.BRAND_DETAIL_SUBSCRIBE_ADD) {
				for (int i = 0; i < list.size(); i++) {
					BrandVo vo = list.get(i);
					if (vo.id.equals(currId)) {
						vo.userSubscribled = 1;
						index = i;
						break;
					}
				}
			} else if (notificationId == ShoppingModel.BRAND_DETAIL_SUBSCRIBE_DEL) {
				for (int i = 0; i < list.size(); i++) {
					BrandVo vo = list.get(i);
					if (vo.id.equals(currId)) {
						vo.userSubscribled = 0;
						index = i;
						break;
					}
				}
			} else {
				try {
					JSONArray brandListJA = jo.optJSONArray("elements");
					for (int i = 0; i < brandListJA.length(); i++) {
						JSONObject brandJo = brandListJA.getJSONObject(i);
						BrandVo brand = new BrandVo();
						brand.desc = brandJo.optString("desc", "0");
						brand.id = brandJo.optString("id", "");
						brand.logo = brandJo.optString("logo", "");
						brand.name = brandJo.optString("name", "");
						brand.bg = brandJo.optJSONArray("brandPics")
								.getJSONObject(0).getString("url");
						brand.bgH = brandJo.optJSONArray("brandPics")
								.getJSONObject(1).getString("url");
						brand.userSubscribled = brandJo.optInt("userSubscribe",
								0);
						JSONArray shopListJA = brandJo.optJSONArray("shops");
						for (int j = 0; j < shopListJA.length(); j++) {
							JSONObject shopJo = shopListJA.getJSONObject(j);
							ShopVo sv = new ShopVo();
							String name = shopJo.optString("name", "");
							sv.fullName = name;
							String subName = "";
							if (!StringUtils.isBlank(name)) {
								Matcher m = pattern.matcher(name);
								while (m.find()) {
									subName = m.group(1);
								}
							}
							sv.name = subName;
							String url = shopJo.optString("backgroudUrl");
							if (url.split(";").length > 0) {
								url = url.split(";")[0];
							}
							sv.url = url;
							sv.shopId = shopJo.optString("id");
							brand.shops.add(sv);
						}
						list.add(brand);
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return true;
	}
}
