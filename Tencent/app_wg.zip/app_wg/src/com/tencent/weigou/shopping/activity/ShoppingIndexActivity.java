package com.tencent.weigou.shopping.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import com.tencent.weigou.R;
import com.tencent.weigou.base.App;
import com.tencent.weigou.base.activity.BottomBarActivity;
import com.tencent.weigou.common.ui.draggable.OverScrollView;
import com.tencent.weigou.feeds.activity.FeedDetailActivity;
import com.tencent.weigou.feeds.activity.FeedDetailActivity.Data;
import com.tencent.weigou.feeds.model.Feeder;
import com.tencent.weigou.guide.GuideActivity;
import com.tencent.weigou.guide.GuideUtils;
import com.tencent.weigou.page.activity.BrandPageActivity;
import com.tencent.weigou.setting.update.CheckUpdateTask;
import com.tencent.weigou.shopping.fragment.PromotionFragment.FragmentBridge;
import com.tencent.weigou.shopping.model.ShoppingModel;
import com.tencent.weigou.shopping.model.vo.BrandListVo.BrandVo;
import com.tencent.weigou.shopping.model.vo.MallListVo.ActVo;
import com.tencent.weigou.shopping.model.vo.MallListVo.MallVo;
import com.tencent.weigou.shopping.view.ShoppingUI;
import com.tencent.weigou.user.UserVo;
import com.tencent.weigou.util.*;
import com.tencent.weigou.util.PageIds.OprIndex;
import com.tencent.weigou.util.lbs.LBSUtils;
import com.tencent.weigou.util.region.RegionManager;

public class ShoppingIndexActivity extends BottomBarActivity implements
		OnClickListener, FragmentBridge,
		com.tencent.weigou.common.ui.draggable.OnRefreshListener {
	ShoppingModel model = new ShoppingModel();
	ShoppingUI ui = new ShoppingUI();
	private int mallPn = 1;
	private int brandPn = 1;
	private String cityId;
	private static final int PAGE_SIZE = 6;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
//		getWindow().setBackgroundDrawable(null);
		if (GuideUtils.needShowGuide(this))
		// 检查是否需要展示引导页面
		{
			Intent intent = new Intent(this, GuideActivity.class);
			startActivity(intent);
			finish();
		} else {
			// 初始化mvc框架
			initMVC(model, ui, R.layout.shopping_index);
			// init();
			topbar.setVisibility(View.GONE);
			// topbar.initRightBtnA(R.color.translucent,
			// LBSUtils.getLocation().adminInfo.city.replace("市", ""), this);
			selectBottomBar(0, true);

            //  检查更新
            checkUpdate();
		}
	}

	@Override
	protected void onResume() {
		super.onResume();
		if (model.mallListVo.list.size() == 0) {
			init();
			// ui.hideNetworkUnavailable();
		}
	}

    protected void checkUpdate(){
        int ver = SysUtils.getAppVersion(getApplication());
        int env = Constants.CHECK_UPDATE_ENV_GAMMA;
        if(Env.getIdc().equals(app.getEnv())){
            env = Constants.CHECK_UPDATE_ENV_IDC;
        }
        String channel = SysUtils.getChannelId(this, "");
        int ch = Util.parseNum(channel);
        String mk = getMk();

        String url = app.getEnv().getServerUrl() + ConstantsUrl.CHECK_UPDATE;
        url += "?plat=1";
        url += "&mk="+mk;
        url += "&ver="+ver;
        url += "&env="+env;
        url += "&ch="+ch;
        url = appendPageInfo(url, PageIds.OprIndex.NON_PV_OPR);
        CheckUpdateTask task = new CheckUpdateTask(this, false);
        task.execute(url);
    }

	private void init() {
		UserVo userVo = app.getUser();
		if (userVo == null || userVo.isTokenEmpty() || userVo.isExpired()) {
			toLogin();
		} else {
			String cityName = LBSUtils.getLocation().adminInfo.city;
			cityId = RegionManager.getInstance(App.getInstance()).getCityId(
					cityName);
			double longitude = LBSUtils.getLocation().longitude;
			double latitude = LBSUtils.getLocation().latitude;

			StringBuffer sb = new StringBuffer(App.getInstance().getEnv()
					.getServerUrl());
			sb.append(ConstantsUrl.SHOPPING_INDEX + "?cid=").append(cityId)
					.append("&longitude=").append(longitude)
					.append("&latitude=").append(latitude).append("&pn=")
					.append(mallPn).append("&ps=").append(PAGE_SIZE);
			String url = sb.toString();
			url = appendPageInfo(url, OprIndex.PV_OPR);
			model.initData(url);

		}

	}

	@Override
	public void onLogin(boolean success, UserVo newUserVo) {
		super.onLogin(success, newUserVo);
		if (success) {
			init();
		} else {
			finish();
		}
	}

	@Override
	public void update(int notificationId) {
		super.update(notificationId);
		switch (notificationId) {
		case ShoppingModel.INIT_DATA:
			ui.updateContent(model.mallListVo);
			String url;
			StringBuffer sb1 = new StringBuffer(App.getInstance().getEnv()
					.getServerUrl());
			sb1.append(ConstantsUrl.SHOPPING_INDEX_BRAND + "?cid=")
					.append(cityId).append("&nd=").append("1").append("&pn=")
					.append(brandPn).append("&ps=").append(PAGE_SIZE);
			url = sb1.toString();
			url = appendPageInfo(url, OprIndex.PV_OPR);
			model.initBrandData(url);
			ui.hideNetworkUnavailable();
			break;
		case ShoppingModel.NEXT_DATA:
			ui.updateContent(model.mallListVo);
			ui.resetMallFooter(true);
			break;
		case ShoppingModel.INIT_BRAND_DATA:
			ui.updateBrandContent(model.brandListVo);
			ui.resetMallFooter(true);
			break;
		case ShoppingModel.NEXT_BRAND_DATA:
			ui.updateBrandContent(model.brandListVo);
			ui.resetBrandFooter(true);
			break;
		}
	}

	@Override
	protected void onNetworkUnavailable(int notificationId) {
		switch (notificationId) {
		case ShoppingModel.INIT_DATA:
		case ShoppingModel.INIT_BRAND_DATA:
			ui.showNetworkUnavailable();
			break;
		case ShoppingModel.NEXT_DATA:
			mallPn -= 1;
			ui.resetMallFooter(true);
			super.onNetworkUnavailable(notificationId);
			break;
		case ShoppingModel.NEXT_BRAND_DATA:
			brandPn -= 1;
			ui.resetBrandFooter(true);
			super.onNetworkUnavailable(notificationId);
			break;
		}
	}

	@Override
	public void update(Bundle bundle) {
		super.update(bundle);
	}

	@Override
	public void onClick(final View v) {
		if (v != null && v.getTag() != null && v.getTag() instanceof ActVo) {

			switch (v.getId()) {

			case R.id.shopping_act_item_1:
			case R.id.shopping_act_item_2:
				showActDetail(v);
				break;
			}
		}
		if (v != null && v.getTag() != null && v.getTag() instanceof String) {

			switch (v.getId()) {
			case R.id.shopping_logo_item_1:
			case R.id.shopping_logo_item_2:
			case R.id.shopping_logo_item_3:
			case R.id.brand_shop_item1_rl:
			case R.id.brand_shop_item2_rl:
			case R.id.brand_shop_item3_rl:
				String shopInfo = v.getTag().toString();
				String sh[] = shopInfo.split("&id=")[1].split("&name=");
				Intent intent = new Intent(this, ShopPagerActivity.class);
				intent.putExtra(ConstantsActivity.INTENT_SHOP_ID, sh[0]);
				intent.putExtra(ConstantsActivity.INTENT_SHOP_NAME, sh[1]);
				intent.putExtra(ConstantsActivity.INTENT_SINGLE_CARD, "true");
				startActivity(intent);
				break;
			}
		}
		if (v != null && v.getTag() != null && v.getTag() instanceof MallVo) {
			MallVo mallVo = (MallVo) v.getTag();
			if (mallVo == null) {
				return;
			}
			Intent it = new Intent();
			it.putExtra(ConstantsActivity.INTENT_MALL_DETAIL_ID, mallVo.id);
			it.setClass(this, MallDetailActivity.class);
			startActivity(it);
		}
		if (v != null && v.getTag() != null && v.getTag() instanceof BrandVo) {
			BrandVo brandVo = (BrandVo) v.getTag();
			if (brandVo == null) {
				return;
			}
			Intent it = new Intent();
			switch (v.getId()) {
			case R.id.shopping_nav_item_rl1:
			case R.id.shopping_nav_item_rl2:
			case R.id.shopping_brand_item_bg:
			case R.id.brand_logo:
			case R.id.shopping_brand_desc:
				it.putExtra(ConstantsActivity.INTENT_BRAND_ID, brandVo.id);
				it.putExtra(ConstantsActivity.INTENT_BRAND_NAME, brandVo.name);
				it.setClass(this, BrandPageActivity.class);
				startActivity(it);
				break;
			}
		}
		if (v != null) {
			switch (v.getId()) {
			case R.id.shopping_index_city_arrow:
			case R.id.shopping_index_city:
				Intent intent = new Intent(this, CityActivity.class);
				startActivity(intent);
				overridePendingTransition(R.anim.in_from_down, 0);
				break;
			case R.id.shopping_index_more_txt:
			case R.id.shopping_index_more:
				ui.changeMode();
				break;
			case R.id.refreshBtn:
				ui.hideNetworkUnavailable();
				init();
				break;
			}
		}

	}

	private void showActDetail(View v) {
		ActVo actVo = (ActVo) v.getTag();
		Data data = new Data();
		data.url = actVo.jumpUrl;
		data.shareDesc = actVo.desc;
		data.shareImageUrl = actVo.imageUrl;
		data.targetId = actVo.mallId;
		data.targetName = actVo.mallName;
		data.targetType = Feeder.Type.MALL;
		Intent intent = new Intent(this, FeedDetailActivity.class);
		intent.putExtra(FeedDetailActivity.INTENT_DATA, data);
		startActivity(intent);
	}

	@Override
	public void closeFragment() {
		onBackPressed();
	}

	@Override
	public void onRefreshing(OverScrollView view, Object obj) {
		StringBuffer sb = new StringBuffer(App.getInstance().getEnv()
				.getServerUrl());
		String url;
		switch (view.getId()) {
		case R.id.shopping_mall_listview_inner:
			mallPn += 1;
			sb.append(ConstantsUrl.SHOPPING_INDEX + "?cid=").append(cityId)
					.append("&nd=").append("1").append("&pn=").append(mallPn)
					.append("&ps=").append(PAGE_SIZE);
			url = sb.toString();
			url = appendPageInfo(url, OprIndex.PV_OPR);
			model.nextMall(url);
			break;
		case R.id.shopping_brand_listview_inner:
		case R.id.shopping_brand_gridview_inner:
			brandPn += 1;
			sb.append(ConstantsUrl.SHOPPING_INDEX_BRAND + "?cid=")
					.append(cityId).append("&nd=").append("1").append("&pn=")
					.append(brandPn).append("&ps=").append(PAGE_SIZE);
			url = sb.toString();
			url = appendPageInfo(url, OprIndex.PV_OPR);
			model.nextBrand(url);
			break;
		}

	}

}
