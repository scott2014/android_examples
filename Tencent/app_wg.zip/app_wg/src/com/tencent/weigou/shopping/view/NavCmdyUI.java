package com.tencent.weigou.shopping.view;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.process.BitmapProcessor;
import com.tencent.weigou.R;
import com.tencent.weigou.base.model.vo.CommonVo;
import com.tencent.weigou.base.view.UI;
import com.tencent.weigou.base.view.UI.AnimateFirstDisplayListener;
import com.tencent.weigou.common.ui.ScaleImageView;
import com.tencent.weigou.common.ui.draggable.DraggableListView;
import com.tencent.weigou.shopping.activity.NavCmdyListActivity;
import com.tencent.weigou.shopping.model.vo.CmdyVo;
import com.tencent.weigou.shopping.model.vo.CmdyVo.CmdyItemVo;
import com.tencent.weigou.util.ImageScaleUtils;
import com.tencent.weigou.util.Util;

public class NavCmdyUI extends UI {
	DraggableListView navGv;
	NavGridAdapter adapter;
	Handler hander = new Handler();
	private List<CmdyItemVo> items = new ArrayList<CmdyItemVo>();
	int imageWidth;

	public void resetFooter(boolean updateTime) {
		navGv.resetFoot(updateTime);
	}

	@Override
	public void initView(View outterView) {
		super.initView(outterView);
		navGv = (DraggableListView) findViewById(R.id.nav_grid_view);
		// navGv.setOnItemClickListener((NavCmdyListActivity) context);
		// navGv.setSelector(new ColorDrawable(Color.TRANSPARENT));
		imageWidth = (Util.getScreenWidth(((Activity) context)
				.getWindowManager()) - Util.dip2px(context, 30)) / 2;

		initGridView();
		options = new DisplayImageOptions.Builder()
				.showImageOnLoading(R.color.translucent)
				.showImageForEmptyUri(R.drawable.loading_big)
				.showImageOnFail(R.drawable.loading_big).cacheInMemory(true)
				.cacheOnDisc(true).considerExifParams(true)
				.bitmapConfig(Bitmap.Config.RGB_565)
				.imageScaleType(ImageScaleType.IN_SAMPLE_POWER_OF_2).build();
	}

	private void initGridView() {
		navGv.setRefreshListener((NavCmdyListActivity) context);
		navGv.setDividerHeight(Util.dip2px(context, 15));
		navGv.getFoot().setId(R.id.shopping_mall_listview_inner);

	}

	public void refresh() {
		adapter.notifyDataSetChanged();
	}

	public void resetMallFooter(boolean updateTime) {
		navGv.resetFoot(updateTime);
	}

	public void updateContent(final CommonVo rv) {
		if (rv instanceof CmdyVo) {
			hander.postDelayed(new Runnable() {

				@Override
				public void run() {
					items = ((CmdyVo) rv).list;
					adapter = new NavGridAdapter();
					navGv.setAdapter(adapter);

					// adapter.notifyDataSetChanged();
				}
			}, 50);

			// if (((CmdyVo) rv).list.size() < 6) {
			// items = ((CmdyVo) rv).list;
			// adapter.notifyDataSetChanged();
			// } else {
			// items = ((CmdyVo) rv).list.subList(0, 5);
			// adapter.notifyDataSetChanged();
			// hander.postAtTime(new Runnable() {
			//
			// @Override
			// public void run() {
			// items = ((CmdyVo) rv).list;
			// adapter.notifyDataSetChanged();
			// }
			// }, 500);
			// }

			//
		}
	}

	public class NavGridAdapter extends BaseAdapter {

		@Override
		public int getCount() {
			float f = items.size() / 2.0f;
			return (int) Math.ceil(f);
		}

		@Override
		public Object getItem(int position) {
			return items.get(position);
		}

		@Override
		public long getItemId(int position) {
			return 0;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			BrandViewHolder holder;
			if (convertView == null) {
				convertView = LayoutInflater.from(context).inflate(
						R.layout.shopping_nav_cmdy_double_item, null);
				holder = new BrandViewHolder();
				holder.bgIV1 = (ScaleImageView) convertView
						.findViewById(R.id.shopping_nav_item_bg1);
				holder.bgIV1.setScale(0.74f);
				holder.priceTV1 = (TextView) convertView
						.findViewById(R.id.shopping_nav_item_price1);
				holder.nameTV1 = (TextView) convertView
						.findViewById(R.id.shopping_nav_item_name1);

				holder.bgIV2 = (ScaleImageView) convertView
						.findViewById(R.id.shopping_nav_item_bg2);
				holder.bgIV2.setScale(0.74f);
				holder.priceTV2 = (TextView) convertView
						.findViewById(R.id.shopping_nav_item_price2);
				holder.nameTV2 = (TextView) convertView
						.findViewById(R.id.shopping_nav_item_name2);
				holder.rl1 = (RelativeLayout) convertView
						.findViewById(R.id.shopping_nav_item_rl1);
				holder.rl2 = (RelativeLayout) convertView
						.findViewById(R.id.shopping_nav_item_rl2);
				convertView.setTag(holder);
			} else {
				holder = (BrandViewHolder) convertView.getTag();
			}
			CmdyItemVo niVo1 = null;
			CmdyItemVo niVo2 = null;
			if (position * 2 < items.size()) {
				niVo1 = items.get(position * 2);
			}
			if (position * 2 + 1 < items.size()) {
				niVo2 = items.get(position * 2 + 1);
			}
			if (niVo1 != null) {
				imageLoader.displayImage(niVo1.bg, holder.bgIV1, options,
						animateFirstListener);
				holder.nameTV1.setText(niVo1.name);
				holder.priceTV1.setText(niVo1.price);
			}
			if (niVo2 != null) {
				imageLoader.displayImage(niVo2.bg, holder.bgIV2, options,
						animateFirstListener);
				holder.nameTV2.setText(niVo2.name);
				holder.priceTV2.setText(niVo2.price);
				holder.rl2.setVisibility(View.VISIBLE);
			} else {
				holder.rl2.setVisibility(View.INVISIBLE);
			}
			holder.rl1.setTag(niVo1);
			holder.rl1.setOnClickListener((NavCmdyListActivity) context);
			holder.rl2.setTag(niVo2);
			holder.rl2.setOnClickListener((NavCmdyListActivity) context);

			// holder.bgIV.setTag(niVo.bg);
			// imageLoader.displayImage(niVo.bg, holder.bgIV, options,
			// animateFirstListener);
			// // asyncLoadImage(holder.bgIV, niVo.bg, imageWidth,
			// // (int) (imageWidth / 0.66), R.drawable.loading_big, true,
			// // true);
			// holder.nameTV.setText(niVo.name);
			// holder.priceTV.setText(niVo.price);
			return convertView;
		}
	}

	public void onDestroy() {
	}

	static class BrandViewHolder {
		ScaleImageView bgIV1;
		TextView nameTV1;
		TextView priceTV1;
		ScaleImageView bgIV2;
		TextView nameTV2;
		TextView priceTV2;
		RelativeLayout rl1;
		RelativeLayout rl2;
	}
}
