package com.tencent.weigou.shopping.model;


import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.http.HttpStatus;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.tencent.weigou.base.json.JsonResult;
import com.tencent.weigou.base.model.Model;
import com.tencent.weigou.base.model.vo.CommonVo;
import com.tencent.weigou.cache.CacheInfo;
import com.tencent.weigou.shopping.fragment.BrandWallFragment;
import com.tencent.weigou.shopping.model.vo.BrandWallVo;
import com.tencent.weigou.shopping.model.vo.MallDetailVo;
import com.tencent.weigou.util.DateUtils;
import com.tencent.weigou.util.NotificationIds;
import com.tencent.weigou.util.StringUtils;
import com.tencent.weigou.util.SysUtils;
import com.tencent.weigou.util.http.JSONGetter;
import com.tencent.weigou.util.http.base.HttpRequest;

public class MallDetailModel extends Model {
	// t
	public static final int MALL_DETAIL_INVALID_ID = 0;
	
	public static final int MALL_DETAIL_PAGE_START = 1;
	public static final int MALL_DETAIL_PAGE_DONE = 2;
	public static final int MALL_DETAIL_PAGE_FAILURE = 3;
	
	public static final int MALL_DETAIL_SUBSCRIBE_START = 4;
	public static final int MALL_DETAIL_SUBSCRIBE_DONE = 5;
	public static final int MALL_DETAIL_SUBSCRIBE_FAILURE = 6;

    public static final int MALL_DETAIL_BRAND_DONE = 7;
    public static final int MALL_DETAIL_BRAND_FAILURE = 8;

    public static final int MALL_DETAIL_QUERY_SUB_DONE = 9;
	
	private Context context;
	private Handler handler;

	private MallDetailVo mallDetailVo;
    private BrandWallVo brandWallVo;

	private GetNetWorkDataTask workTask;
	private SubscribeAsyncTask subWorkTask;
    private BrandWallAsyncTask brandWallTask;
    private QuerySubAsyncTask querySubTask;

	public void initContext(Context context, Handler handler) {
	    this.context = context;
	    this.handler = handler;
	}
	
	@Override
	public void initData(String url) {
		mallDetailVo = new MallDetailVo();
		if (StringUtils.isNotBlank(url)) {
			loadPage(url);
		}
	}


	public void loadPage(String url) {
		
		/**
		 * createNetWorkTask
		 */
		workTask = null;
		workTask = new MyGetNetWorkDataTask(
				url,
				mallDetailVo,
				MALL_DETAIL_INVALID_ID);
		workTask.execute();
		addList(workTask);
	}
	
	public MallDetailVo getMallDetailVo() {
		return mallDetailVo;
	}

    public BrandWallVo getBrandWallVo() {
        return brandWallVo;
    }

	public void changeSubscribeRel(String url) {
		if(subWorkTask != null && subWorkTask.getStatus() != AsyncTask.Status.FINISHED) {
			return;
		}
		
		subWorkTask = new SubscribeAsyncTask(url, new CommonVo(), MALL_DETAIL_SUBSCRIBE_DONE);
		subWorkTask.execute();
		addList(subWorkTask);
	}

    public void loadBrandWall(String url, Object lock, BrandWallFragment.IsAnimEnd isAnimEndObj) {
        if(brandWallTask != null && brandWallTask.getStatus() != AsyncTask.Status.FINISHED) {
            return;
        }

        if(brandWallVo == null) {
            brandWallVo = new BrandWallVo();
            brandWallTask = new BrandWallAsyncTask(url, brandWallVo, MALL_DETAIL_BRAND_DONE, lock,
                    isAnimEndObj);
            brandWallTask.execute();
            addList(brandWallTask);
        }


    }

    public void querySub(String url) {
        if(querySubTask != null && querySubTask.getStatus() != AsyncTask.Status.FINISHED) {
            return;
        }

        querySubTask = new QuerySubAsyncTask(url, new CommonVo(), MALL_DETAIL_QUERY_SUB_DONE);
        querySubTask.execute();
        addList(querySubTask);
    }

    /**
     * delete bg img animation
     */
//	private CountDownLatch cdLatch;
//
//	public void countDown() {
//		if(cdLatch != null) {
//			cdLatch.countDown();
//		}
//	}
	
	public class MyGetNetWorkDataTask extends GetNetWorkDataTask {
		
		private static final String IF_MODIFIED_SINCE = "If-Modified-Since";
		private static final String LAST_MODIFIED = "Last-Modified";		
	    //  默认缓冲区大小=4k
	    public final static int DEFAULT_BUFFER_SIZE = 1024 * 4;
		
		public MyGetNetWorkDataTask(String url,
				MallDetailVo mallDetailVo, int notificationId) {
			super(true, url, mallDetailVo, notificationId);
			Log.d("Bran", "url = " + url);
		}

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			MallDetailModel.this.notify(MALL_DETAIL_PAGE_START);
		}
		
		@Override
		protected CommonVo doInBackground(Object... arg0) {
			
//			cdLatch = new CountDownLatch(1);
			
			// load drawable
//			final BitmapFactory.Options options = new BitmapFactory.Options();
//	        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
//			Bitmap originalBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.tmp_mall_detail_bg, options);
//			Message message = handler.obtainMessage(0, originalBitmap);				
//			handler.sendMessage(message);
			
			long start = System.currentTimeMillis();
			CommonVo vo = super.doInBackground(arg0);
			Log.d("Bran", "Download MallData time is " + (System.currentTimeMillis() - start));

            /**
             * delete bg img animation
             */
//			start = System.currentTimeMillis();
//			if(vo != null && StringUtils.isNotEmpty(mallDetailVo.bgUrl)) {
//				String bgUrl = mallDetailVo.bgUrl;
//
//				CacheInfo cache = CacheUtils.getFromCache(bgUrl.trim());
//				boolean isOk = false;
//				boolean ifFromNet = false;
//				Bitmap bitmap = null;
//
//				/**
//				 * 2.2、从网络中下载图片
//				 */
//				if (null == cache
//						|| !cache.isValid()
//						|| cache.isExpires()) {
//
//					/**
//					 * start load image data from net
//					 */
//					if (null == cache) {
//						final long startTime = System.currentTimeMillis();
//						long mustImageExipreCheckTime = 302400000;
//						cache = new CacheInfo(0, startTime
//								+ mustImageExipreCheckTime,
//								bgUrl.trim(), null);
//					}
//
//					isOk = downloadFromNet(bgUrl.trim(),
//							cache);
//					ifFromNet = true;
//					Log.d("Bran", "downloadFromNet");
//
//				} else {
//					isOk = true;
//					Log.d("Bran", "cache");
//				}
//
//				if (isOk && cache != null && cache.isValid()) {
//					final BitmapFactory.Options options = new BitmapFactory.Options();
//					options.inPurgeable = true;
//					options.inJustDecodeBounds = false;
//					bitmap = BitmapFactory.decodeByteArray(cache.getValue(), 0, cache.getValue().length, options);
//				}
//
//				Message message = handler.obtainMessage(0, bitmap);
//                handler.sendMessage(message);
//
//				/**
//				 * 2.3、保存到本地SD卡上
//				 */
//				if (ifFromNet && isOk && null != cache
//						&& cache.isValid() && bitmap != null) {
//					ByteArrayOutputStream bos = new ByteArrayOutputStream();
//					bitmap.compress(Bitmap.CompressFormat.PNG, 100, bos);
//					CacheUtils.saveToCache(bgUrl.trim(),
//							cache.getLastModified(),
//							cache.getExpires(),
//							bos.toByteArray());
//				}
//			}
//			else {
//				Message message = handler.obtainMessage(0, null);
//                handler.sendMessage(message);
//			}
//			Log.d("Bran", "Download Mall Bg Img time is " + (System.currentTimeMillis() - start));
//
//
//			if(cdLatch != null) {
//				try {
//					cdLatch.await();
//				} catch (InterruptedException e) {
//
//				}
//			}
//			cdLatch = null;
			
			return vo;
		}
		
		private boolean downloadFromNet(String urlStr, CacheInfo cache) {
			boolean finished = false;
			if (null == cache) {
				return finished;
			}
			
			InputStream inputStream = null;
			HttpURLConnection conn = null;

			final long start = System.nanoTime();
			
			try {

				URL url = new URL(urlStr);
				// 首先进行预处理
				conn = (HttpURLConnection) url.openConnection();
				conn = preProcessHttp(conn);

				if (cache.getLastModified() > 0) {
					conn.addRequestProperty(IF_MODIFIED_SINCE,
							DateUtils.L2CST(cache.getLastModified()));
				}

				final int statusCode = conn.getResponseCode();
				// 返回304,说明不用更新数据
				if (statusCode == HttpStatus.SC_NOT_MODIFIED) {
					finished = true;
				} else {
					if (statusCode != HttpStatus.SC_OK) {
					} else if ((inputStream = conn.getInputStream()) != null) {
						final long curTime = System.currentTimeMillis();
						final long lastModified = conn.getHeaderFieldDate(
								LAST_MODIFIED, curTime);
						cache.setLastModified(lastModified);
						
						/**
						 * Add progress bar
						 */
						int totalLength = conn.getContentLength();
						
						cache.setValue(toByteArray(inputStream, totalLength));
						
						
						finished = true;
					}
				}
			} catch (IOException e) {
			} catch (Exception e) {
			} finally {
				if (inputStream != null) {
					try {
						inputStream.close();
					} catch (IOException e) {
					}
				}

				if (conn != null) {
					conn.disconnect();
				}
			}
			return finished;
		}
		
		private HttpURLConnection preProcessHttp(HttpURLConnection conn) {
			if (conn != null) {
				try {
					conn.setConnectTimeout(HttpRequest.CONNECT_TIME_OUT);
					conn.setReadTimeout(HttpRequest.READ_TIME_OUT);

					String network = SysUtils.getNetworkType();
					if (SysUtils.NETWORK_CMWAP.equals(network)) {
						String host = conn.getURL().getHost();
						conn.addRequestProperty(HttpRequest.NETWORK_CMWAP_HEADER,
								host);
					}
				} catch (Exception e) {
					// ignore
				}
			}
			return conn;
		}
		
		private byte[] toByteArray(InputStream ins, int totalLength) throws IOException {
	        ByteArrayOutputStream outs = new ByteArrayOutputStream();
	        byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
	        int n = 0;
	        Message message;
	        int loadingCount = 0;
	        int progressCount = 1;
	        int dataPiece = totalLength / 10;
	        while (-1 != (n = ins.read(buffer))) {
	            outs.write(buffer, 0, n);
	        }
	        
	        byte[] result = null;
	        result = outs.toByteArray();
	        if (outs != null) {
	            outs.close();
	        }
	        return result;
	    }

				

		@Override
		public void onPostExecute(CommonVo vo) {
			MallDetailModel.this.notify(MALL_DETAIL_PAGE_DONE);
			super.onPostExecute(vo);
		}

		@Override
		protected void onCancelled() {
			super.onCancelled();
			MallDetailModel.this.notify(MALL_DETAIL_PAGE_FAILURE);

		}

	}

	
	
	public class SubscribeAsyncTask extends GetNetWorkDataTask {

		public SubscribeAsyncTask(String url, CommonVo cv, int notificationId) {
			super(false, url, cv, notificationId);
			Log.d("Bran", "url = " + url);
		}
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			MallDetailModel.this.notify(MALL_DETAIL_SUBSCRIBE_START);
		}
		
		@Override
		public void onPostExecute(CommonVo vo) {
			super.onPostExecute(vo);
			if(vo == null) {
				MallDetailModel.this.notify(MALL_DETAIL_SUBSCRIBE_FAILURE);
			}
		}

		@Override
		protected void onCancelled() {
			super.onCancelled();
			MallDetailModel.this.notify(MALL_DETAIL_SUBSCRIBE_FAILURE);

		}

	}

    public class QuerySubAsyncTask extends GetNetWorkDataTask {

        public QuerySubAsyncTask(String url, CommonVo cv, int notificationId) {
            super(false, url, cv, notificationId);
            Log.d("Bran", "url = " + url);
        }


        @Override
        public void onPostExecute(CommonVo vo) {
            super.onPostExecute(vo);
            if(vo != null) {
                int errCode = vo.getErrorCode();
                if(errCode == 0) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("notificationId", MALL_DETAIL_QUERY_SUB_DONE);
                    bundle.putBoolean("isSub", true);
                    MallDetailModel.this.notify(bundle);
                }
                else if(errCode == 0x0204) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("notificationId", MALL_DETAIL_QUERY_SUB_DONE);
                    bundle.putBoolean("isSub", false);
                    MallDetailModel.this.notify(bundle);
                }
            }
        }
    }

    public class BrandWallAsyncTask extends GetNetWorkDataTask {

        private final Object mPauseWorkLock;
        private BrandWallFragment.IsAnimEnd isAnimEndObj;

        public BrandWallAsyncTask(String url, CommonVo cv, int notificationId, Object lock,
                                  BrandWallFragment.IsAnimEnd isAnimEndObj) {
            super(false, url, cv, notificationId);
            mPauseWorkLock = lock;
            this.isAnimEndObj = isAnimEndObj;
            Log.d("Bran", "url = " + url);
        }

        @Override
        protected CommonVo doInBackground(Object... arg0) {

            CommonVo vo =  super.doInBackground(arg0);

            synchronized (mPauseWorkLock) {
                if(!isAnimEndObj.isAnimEnd) {
                    try {
                        Log.d("Bran", "mPauseWorkLock.wait();");
                        mPauseWorkLock.wait();
                    } catch (InterruptedException e) {
                    }
                }
                else {
                    Log.d("Bran", "isAnimEnd");
                }
            }

            return vo;

        }

        @Override
        public void onPostExecute(CommonVo vo) {
            super.onPostExecute(vo);
            if(vo == null) {
                MallDetailModel.this.notify(MALL_DETAIL_BRAND_FAILURE);
            }
        }

        @Override
        protected void onCancelled() {
            super.onCancelled();
            MallDetailModel.this.notify(MALL_DETAIL_BRAND_FAILURE);

        }
    }

}
