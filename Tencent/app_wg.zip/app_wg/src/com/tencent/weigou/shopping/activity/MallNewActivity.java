package com.tencent.weigou.shopping.activity;

import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.tencent.weigou.R;
import com.tencent.weigou.base.activity.TitleBarActivity;
import com.tencent.weigou.shopping.model.MallNewModel;
import com.tencent.weigou.shopping.model.vo.MallNewVo;
import com.tencent.weigou.shopping.view.MallNewUI;
import com.tencent.weigou.shopping.view.MallNewView;
import com.tencent.weigou.util.AsyncImageLoader;
import com.tencent.weigou.util.ConstantsActivity;
import com.tencent.weigou.util.ConstantsUrl;
import com.tencent.weigou.util.PageIds;
import com.tencent.weigou.util.StringUtils;

/**
 * 逛-商场-上新
 * User: ethonchan
 * Date: 13-12-4
 * Time: 下午3:36
 */
public class MallNewActivity extends TitleBarActivity implements View.OnClickListener {

    private MallNewModel mNewModel;

    private MallNewUI mNewUI;

    private MyListAdapter mListAdapter;

    //  图片加载工具
    private AsyncImageLoader mImageLoader;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mNewModel = new MallNewModel();
        mNewUI = new MallNewUI();
        initMVC(mNewModel, mNewUI, R.layout.listview_layout);

        initBackBtn();
        setTitle(R.string.shopping_mall_new);

        mListAdapter = new MyListAdapter();
        mNewUI.setListAdapter(mListAdapter);
        mImageLoader = new AsyncImageLoader();

        //  从Intent中解析出mallId
        String mallId = "";
        Intent intent = getIntent();
        if (intent != null) {
            mallId = intent.getStringExtra(ConstantsActivity.INTENT_MALL_DETAIL_ID);
        }

        if (StringUtils.isNotBlank(mallId)) {
            String url = getInitUrl(mallId);
            mNewModel.initData(url);
        } else {
            finish();
        }
    }

    /**
     * 得到页面初始化所需的url
     *
     * @param mallId
     * @return
     */
    private String getInitUrl(String mallId) {
        String url = app.getEnv().getServerUrl() + ConstantsUrl.GET_MALL_NEW;
        url += "?mid=" + mallId;
        url = appendPageInfo(url, PageIds.OprIndex.PV_OPR);
        return url;
    }

    @Override
    public void update(int notificationId) {
        super.update(notificationId);

        if (notificationId == MallNewModel.GET_MALL_NEW) {
            MallNewVo vo = mNewModel.getMallNewVo();
            if (vo != null)
            //  更新列表
            {
                mListAdapter.displayShops(vo.getShopList());
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mImageLoader != null) {
            mImageLoader.destroy();
        }
    }

    @Override
    public void onClick(View v) {
        if (v == null) {
            return;
        }

        Object tag = v.getTag();
        if (tag != null) {
            if (tag instanceof MallNewView.ItemViewHolder)
            //  去商品列表
            {
                MallNewView.ItemViewHolder holder = (MallNewView.ItemViewHolder) tag;
                Intent intent = new Intent(this, ShoppingCmdyPagerActivity.class);
                //  使用与发现相同的跳转方式，故这样模拟
                intent.putExtra(ConstantsActivity.INTENT_SOURCE_ACTIVITY, "DiscoveryActivity");
                intent.putExtra(ConstantsActivity.INTENT_CMDY_LIST_TITLE, "新品推荐<font color='blue'>New</href>");
                intent.putExtra(ConstantsActivity.INTENT_CMDY_IDS, holder.ids);
                intent.putExtra(ConstantsActivity.INTENT_CMDY_INDEX, ""+holder.index);

                startActivity(intent);
            } else if (tag instanceof MallNewVo.Shop)
            //  去门店首页
            {
                MallNewVo.Shop shop = (MallNewVo.Shop) tag;
                Intent intent = new Intent(this, ShopPagerActivity.class);
                intent.putExtra(ConstantsActivity.INTENT_SHOP_ID, "" + shop.id);
                intent.putExtra(ConstantsActivity.INTENT_SHOP_NAME, shop.name);
                intent.putExtra(ConstantsActivity.INTENT_SINGLE_CARD, "true");

                startActivity(intent);
            }

        }
    }

    /**
     * 上新数据
     */
    class MyListAdapter extends BaseAdapter {

        private List<MallNewVo.Shop> shopList;

        public void displayShops(List<MallNewVo.Shop> shopList) {
            if (shopList != null) {
                if (this.shopList == null) {
                    this.shopList = new ArrayList<MallNewVo.Shop>();
                }

                this.shopList.addAll(shopList);
                notifyDataSetChanged();
            }
        }

        @Override
        public int getCount() {
            return shopList == null ? 0 : shopList.size();
        }

        @Override
        public Object getItem(int position) {
            if (position > -1 && position < getCount()) {
                return shopList.get(position);
            }
            return null;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                MallNewView view = new MallNewView(MallNewActivity.this);
                view.setOnClickListener(MallNewActivity.this);
                convertView = view;
            }

            MallNewVo.Shop shop = null;
            if (position > -1 && position < getCount()) {
                shop = shopList.get(position);
            }
            MallNewView newView = (MallNewView) convertView;
            newView.setImageLoader(mImageLoader);
            newView.setData(shop);
            return newView;
        }
    }
}
