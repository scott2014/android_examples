package com.tencent.weigou.shopping.model.vo;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.tencent.weigou.base.model.vo.CommonVo;
import com.tencent.weigou.shopping.model.ShoppingModel;

public class MallListVo extends CommonVo {
	public List<MallVo> list = new ArrayList<MallVo>();
	public String currId;
	public int index;

	public class MallVo {
		public String logo;
		public String id;
		public String name;
		public String bg;
		public List<ActVo> acts = new ArrayList<ActVo>();;
		public List<ShopVo> brands = new ArrayList<ShopVo>();
		public int userSubscribled;
	}

	public class ActVo {
		public String actTitle;
		public String desc;
		public long beginTime;
		public long endTime;
		public int type;
		public String jumpUrl;
		public String imageUrl;
		public String mallName;
		public String mallId;
	}

	public class ShopVo {
		public String logo;
		public String name;
		public String fullName;
		public String id;
		public String promote;
	}

	@Override
	public boolean parse(JSONObject jo) {
		if (super.parse(jo)) {
			if (notificationId == ShoppingModel.MALL_DETAIL_SUBSCRIBE_ADD) {
				for (int i = 0; i < list.size(); i++) {
					MallVo vo = list.get(i);
					if (vo.id.equals(currId)) {
						vo.userSubscribled = 1;
						index = i;
						break;
					}
				}
			} else if (notificationId == ShoppingModel.MALL_DETAIL_SUBSCRIBE_DEL) {
				for (int i = 0; i < list.size(); i++) {
					MallVo vo = list.get(i);
					if (vo.id.equals(currId)) {
						vo.userSubscribled = 0;
						index = i;
						break;
					}
				}
			} else {
				try {
					JSONArray mallListJA = jo.optJSONArray("mallList");
					for (int i = 0; i < mallListJA.length(); i++) {
						JSONObject mallJo = mallListJA.getJSONObject(i);
						MallVo mall = new MallVo();
						mall.id = mallJo.optString("mallId", "0");
						mall.name = mallJo.optString("mallName", "");
						mall.logo = mallJo.optString("logo", "");
						mall.bg = mallJo.optString("landscapePic", "");
						mall.userSubscribled = mallJo.optInt("userSubscribled",
								0);
						JSONObject shopList = mallJo.optJSONObject("shopList");
						JSONArray shopListJA = null;
						if (shopList != null) {
							shopListJA = shopList.optJSONArray("shopList");
						}
						for (int j = 0; j < shopListJA.length(); j++) {
							JSONObject shopJo = shopListJA.getJSONObject(j);
							ShopVo sv = new ShopVo();
							sv.logo = shopJo.optString("brandLogo", "");
							sv.name = shopJo.optString("brandName", "");
							sv.fullName = shopJo.optString("name", "");
							sv.promote = shopJo.optString("promote", "");
							sv.id = shopJo.optString("id", "");
							mall.brands.add(sv);
						}

						JSONArray actJA = mallJo.optJSONArray("promotion");
						for (int j = 0; j < actJA.length(); j++) {
							JSONObject actJo = actJA.getJSONObject(j);
							ActVo av = new ActVo();
							av.actTitle = actJo.optString("title", "");
							av.desc = actJo.optString("desc", "");
							av.type = actJo.optInt("type", 1);
							av.beginTime = actJo.optLong("beginTime", 0);
							av.endTime = actJo.optLong("endTime", 0);
							av.imageUrl = actJo.optString("imageUrl", "");
							av.jumpUrl = actJo.optString("activityUrl", "");
							av.mallName = mall.name;
							av.mallId = mall.id;
							mall.acts.add(av);
						}
						list.add(mall);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return true;
	}
}
