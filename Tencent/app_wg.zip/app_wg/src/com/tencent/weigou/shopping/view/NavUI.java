package com.tencent.weigou.shopping.view;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import com.tencent.weigou.R;
import com.tencent.weigou.base.model.vo.CommonVo;
import com.tencent.weigou.base.view.UI;
import com.tencent.weigou.common.ui.ScaleImageView;
import com.tencent.weigou.shopping.activity.NavListActivity;
import com.tencent.weigou.shopping.model.vo.NavVo;
import com.tencent.weigou.shopping.model.vo.NavVo.NavItemVo;
import com.tencent.weigou.util.Util;

public class NavUI extends UI {
	GridView navGv;
	NavGridAdapter adapter;
	int imageWidth;

	@Override
	public void initView(View outterView) {
		super.initView(outterView);
		navGv = (GridView) findViewById(R.id.nav_grid_view);
		adapter = new NavGridAdapter();
		navGv.setAdapter(adapter);
		navGv.setOnItemClickListener((NavListActivity) context);
		navGv.setSelector(new ColorDrawable(Color.TRANSPARENT));
		imageWidth = (Util.getScreenWidth(((Activity) context)
				.getWindowManager()) - Util.dip2px(context, 30)) / 2;
	}

	public void updateContent(CommonVo rv) {
		if (rv instanceof NavVo) {
			adapter.setData(((NavVo) rv).list);
			adapter.notifyDataSetChanged();
		}
	}

	public class NavGridAdapter extends BaseAdapter {
		private List<NavItemVo> items = new ArrayList<NavVo.NavItemVo>();

		public void setData(List<NavItemVo> items) {
			this.items = items;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return items.size();
		}

		@Override
		public Object getItem(int position) {
			return items.get(position);
		}

		@Override
		public long getItemId(int position) {
			return 0;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			BrandViewHolder holder;
			if (convertView == null) {
				convertView = LayoutInflater.from(context).inflate(
						R.layout.shopping_nav_shop_item, null);
				holder = new BrandViewHolder();
				holder.bgIV = (ScaleImageView) convertView
						.findViewById(R.id.shopping_nav_item_bg);
				holder.bgIV.setScale(0.66f);
				holder.logoIV = (ImageView) convertView
						.findViewById(R.id.shopping_nav_item_logo);
				holder.nameTV = (TextView) convertView
						.findViewById(R.id.shopping_nav_item_name);
				convertView.setTag(holder);
			} else {
				holder = (BrandViewHolder) convertView.getTag();
			}
			NavItemVo niVo = items.get(position);
			holder.bgIV.setTag(niVo.bg);
			holder.logoIV.setTag(niVo.logo);
			imageLoader.displayImage(niVo.bg, holder.bgIV, options,
					animateFirstListener);
			imageLoader.displayImage(niVo.logo, holder.logoIV, options,
					animateFirstListener);
//			asyncLoadImage(holder.bgIV, niVo.bg, imageWidth,
//					(int) (imageWidth / 0.66), R.drawable.loading_big, true,
//					true);
//			asyncLoadImage(holder.logoIV, niVo.logo, 0, 0,
//					R.drawable.loading_big, true, false);
			holder.nameTV.setText(niVo.name);
			return convertView;
		}
	}

	static class BrandViewHolder {
		ImageView logoIV;
		ScaleImageView bgIV;
		TextView nameTV;
	}
}
