package com.tencent.weigou.shopping.view;


import com.tencent.weigou.util.Util;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class CatHLayout extends ViewGroup {

	// private final static int PAD_H = 12, PAD_V = 15; // Space between child
	// views.

	private int verticalSpace = Util.dip2px(getContext(), 7);
	private int horizontalSpace = Util.dip2px(getContext(), 7);
	private int mHeight;


	public CatHLayout(Context context) {
		super(context);
	}

	public CatHLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
	}
	
	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {

		Log.d("Bran", "MeasureSpec.getSize(widthMeasureSpec) = " + MeasureSpec.getSize(widthMeasureSpec));
		Log.d("Bran", "MeasureSpec.getMode(widthMeasureSpec) = " + MeasureSpec.getMode(widthMeasureSpec));
		Log.d("Bran", "MeasureSpec.getSize(heightMeasureSpec) = " + MeasureSpec.getSize(heightMeasureSpec));
		Log.d("Bran", "MeasureSpec.getMode(heightMeasureSpec) = " + MeasureSpec.getMode(heightMeasureSpec));
		
		int width = MeasureSpec.getSize(widthMeasureSpec);
		int heightAtMost = MeasureSpec.getSize(heightMeasureSpec);
		int x = 0;
		int y = 0;
		
		int childWidthMeasureSpec = MeasureSpec.makeMeasureSpec(width, MeasureSpec.AT_MOST);
		int childHeightMeasureSpec = MeasureSpec.makeMeasureSpec(heightAtMost, MeasureSpec.AT_MOST);
		
		/**
		 * every child's height are the same with each other
		 */
		int childRecordHeight = 0;
		final int count = getChildCount();
		int i = 0;
		if(count > 0) {
			int line = 1;
			for (i = 0; i < count; i++) {
				final View child = getChildAt(i);
				child.measure(childWidthMeasureSpec, childHeightMeasureSpec);
				int childWidth = child.getMeasuredWidth();
				int childHeight = child.getMeasuredHeight();
				
				if(childRecordHeight < childHeight) {
					childRecordHeight = childHeight;
				}
				
				
				
				/**
				 * First line
				 */
				if(i == 0) {
					y = childRecordHeight + verticalSpace;
					/**
					 * All children's height must be less than parent view's height
					 */
					if(y > heightAtMost) {
						break;
					}
				}
				
				if(x + horizontalSpace + childWidth > width) {
					line++;
					y = y + childRecordHeight + verticalSpace;
					/**
					 * All children's height must be less than parent view's height
					 */
					Log.d("Bran", "y > heightAtMost " + y + " ? " + heightAtMost);
					if(y > heightAtMost) {
						break;
					}
					x = childWidth;
				}
				else {
					x = x + horizontalSpace + childWidth;
				}
			}
			
			if(i == 0) {
				removeAllViewsInLayout();
			}
			else if(i < count) {
				removeViewsInLayout(i, 1);
				TextView lastView = (TextView) getChildAt(i - 1);
				lastView.setTag("more");
				lastView.setText("更多");
				int lastViewWidthMeasureSpec = MeasureSpec.makeMeasureSpec(lastView.getMeasuredWidth(), MeasureSpec.AT_MOST);
				int lastViewHeightMeasureSpec = MeasureSpec.makeMeasureSpec(lastView.getMeasuredHeight(), MeasureSpec.AT_MOST);
				lastView.measure(lastViewWidthMeasureSpec, lastViewHeightMeasureSpec);
			}
			
			setMeasuredDimension(width, y);
		}
		
	}

	protected void onLayout(boolean changed, int l, int t, int r, int b) {
		final int width = r - l;
		int x = 0;
		int y = 0;
		
		final int count = getChildCount();
		if(count > 0) {
			 int line = 1;
		
			for (int i = 0; i < count; i++) {
				final View child = getChildAt(i);
				int childWidth = child.getMeasuredWidth();
				int childHeight = child.getMeasuredHeight();
				
				child.layout(x, y, x + childWidth, y + childHeight);
				x = x + horizontalSpace + childWidth;
				if(x + horizontalSpace + childWidth > width) {
					line++;
					y = y + childHeight + verticalSpace;
					x = 0;
				}				
			}
		}

	}

	

	public int getVerticalSpace() {
		return verticalSpace;
	}

	public void setVerticalSpace(int verticalSpace) {
		this.verticalSpace = verticalSpace;
	}

	public int getHorizontalSpace() {
		return horizontalSpace;
	}

	public void setHorizontalSpace(int horizontalSpace) {
		this.horizontalSpace = horizontalSpace;
	}


}
