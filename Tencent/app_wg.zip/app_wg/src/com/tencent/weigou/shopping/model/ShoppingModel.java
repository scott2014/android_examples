package com.tencent.weigou.shopping.model;

import com.tencent.weigou.base.model.Model;
import com.tencent.weigou.shopping.model.vo.BrandListVo;
import com.tencent.weigou.shopping.model.vo.MallListVo;

public class ShoppingModel extends Model {
	public final static int INIT_DATA = 0;
	public final static int NEXT_DATA = 6;
	public final static int INIT_BRAND_DATA = 1;
	public final static int NEXT_BRAND_DATA = 7;
	public static final int MALL_DETAIL_SUBSCRIBE_ADD = 2;
	public static final int MALL_DETAIL_SUBSCRIBE_DEL = 3;
	public static final int BRAND_DETAIL_SUBSCRIBE_ADD = 4;
	public static final int BRAND_DETAIL_SUBSCRIBE_DEL = 5;
	public MallListVo mallListVo = new MallListVo();;
	public BrandListVo brandListVo;

	@Override
	public void initData(String url) {
		createNetWorkTask(url, mallListVo, INIT_DATA);
	}

	public void nextMall(String url) {
		createNetWorkTask(false, url, mallListVo, NEXT_DATA);
	}

	public void initBrandData(String url) {
		brandListVo = new BrandListVo();
		createNetWorkTask(false, url, brandListVo, INIT_BRAND_DATA);
	}

	public void nextBrand(String url) {
		createNetWorkTask(false, url, brandListVo, NEXT_BRAND_DATA);
	}

}
