package com.tencent.weigou.shopping.model.vo;

import java.util.LinkedList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.tencent.weigou.base.model.vo.CommonVo;
import com.tencent.weigou.page.model.vo.BrandPageVo.ShopItemVo;

/**
 * 
 * @ClassName： ShopListVo
 *
 * @Description： 品牌下门店列表
 * @author wamiwen
 * @date 2013-12-5 上午10:04:49
 *
 */
public class ShopListVo extends CommonVo {
	
	public static final String ALL_DESC = "我附近的";
	public static final String SUBSCRIBED_DESC = "我订阅的";
	
	public List<Object> shopItemList = new LinkedList<Object>();
	
	@Override
	public boolean parse(JSONObject data) {
		try {
			JSONArray subscribedList = data.optJSONArray("subscribedList");
			if (subscribedList != null && subscribedList.length() > 0) {
				shopItemList.add(SUBSCRIBED_DESC);
				for (int i = 0, len = subscribedList.length(); i < len; i++) {
					JSONObject shopItemObj = subscribedList.optJSONObject(i);
					ShopItemVo shopItemVo = ShopItemVo.parseJSONObj(shopItemObj);
					if (shopItemVo == null) {
						continue;
					}
					shopItemList.add(shopItemVo);
				}
			}
			JSONArray allList = data.optJSONArray("shopList");
			if (allList != null && allList.length() > 0) {
				shopItemList.add(ALL_DESC);
				for (int i = 0, len = allList.length(); i < len; i++) {
					JSONObject shopItemObj = allList.optJSONObject(i);
					ShopItemVo shopItemVo = ShopItemVo.parseJSONObj(shopItemObj);
					if (shopItemVo == null) {
						continue;
					}
					shopItemList.add(shopItemVo);
				}
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
}
