package com.tencent.weigou.shopping.model.vo;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.tencent.weigou.base.model.vo.CommonVo;

public class ShopPagerVo extends CommonVo {
	
	public List<String> shopList;

	/**
	 * called by bg Thread
	 */
	@Override
	public boolean parse(JSONObject jo) {
		
		try {
			JSONArray shopIdArray = jo.optJSONArray("shopIdList");
			if(shopIdArray != null && shopIdArray.length() > 0) {
				int length = shopIdArray.length();
				shopList = new ArrayList<String>(length);
				for(int i = 0; i < length; i++) {
					shopList.add(shopIdArray.getString(i));
				}
			}
			return true;
		}
		catch(JSONException e) {
			shopList = null;
		}
		
		return false;
	}
	
}
