package com.tencent.weigou.shopping.model;

import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseArray;

import com.tencent.weigou.base.json.JsonResult;
import com.tencent.weigou.base.model.Model;
import com.tencent.weigou.base.model.Model.GetNetWorkDataTask;
import com.tencent.weigou.base.model.vo.CommonVo;
import com.tencent.weigou.shopping.model.vo.ShopCardVo;
import com.tencent.weigou.shopping.model.vo.ShopPagerVo;
import com.tencent.weigou.util.NotificationIds;
import com.tencent.weigou.util.StringUtils;
import com.tencent.weigou.util.http.JSONGetter;

public class ShopPagerModel extends Model {
	// public static final int SHOP_PAGER_INVALID_ID = 0;
	public static final int SHOP_PAGER_INVALID_ID_MAIN = 0;
	public static final int SHOP_PAGER_INVALID_ID = 20;
	public static final int SHOP_PAGER_START = 1;
	public static final int SHOP_PAGER_DONE = 2;
	public static final int SHOP_PAGER_FAILURE = 3;

	public static final int SHOP_CARD_START = 4;
	public static final int SHOP_CARD_DONE = 5;
	public static final int SHOP_CARD_FAILURE = 6;

	public static final int SHOP_SUBSCRIBE_START = 7;
	public static final int SHOP_SUBSCRIBE_DONE = 8;
	public static final int SHOP_SUBSCRIBE_FAILURE = 9;

	public static final int SHOP_QUERY_SUB_DONE = 10;

	private ShopPagerVo shopPagerVo;
	private SparseArray<ShopCardVo> shopCardVoList;
	private SubscribeAsyncTask subWorkTask;
	private QuerySubAsyncTask querySubTask;
	private int cardSize = 0;

	private CountDownLatch cdLatch = new CountDownLatch(1);

	public void countDown() {
		if (cdLatch != null) {
			cdLatch.countDown();
			cdLatch = null;
		}
	}

	@Override
	public void initData(String url) {
		shopPagerVo = new ShopPagerVo();
		if (StringUtils.isNotBlank(url)) {
			loadShopList(url);
		}
	}

	// i is meaningless
	public void initData(String shopId, int i) {
		shopPagerVo = new ShopPagerVo();
		shopPagerVo.shopList = new ArrayList<String>(1);
		shopPagerVo.shopList.add(shopId);
		cardSize = 1;
		shopCardVoList = new SparseArray<ShopCardVo>(cardSize);
		notify(SHOP_PAGER_DONE);
	}

	public ShopPagerVo getShopPagerVo() {
		return shopPagerVo;
	}

	public ShopCardVo getShopCardVo(int index) {
		if (shopCardVoList == null || shopCardVoList.size() == 0) {
			return null;
		}
		return shopCardVoList.get(index);
	}

	public int getCardSize() {
		return cardSize;
	}

	public void loadShopList(String url) {

		GetShopListTask workTask = new GetShopListTask(url, shopPagerVo,
				SHOP_PAGER_INVALID_ID_MAIN);
		workTask.execute();
		addList(workTask);
	}

	public void loadShopCard(String url, int pos) {

		GetShopCardTask workTask = new GetShopCardTask(url, new ShopCardVo(),
				SHOP_PAGER_INVALID_ID, pos);
		workTask.execute();
		addList(workTask);
	}

	public void changeSubscribeRel(String url, int pos, boolean isSub) {
		if (subWorkTask != null
				&& subWorkTask.getStatus() != AsyncTask.Status.FINISHED) {
			return;
		}

		subWorkTask = new SubscribeAsyncTask(url, new CommonVo(),
				SHOP_PAGER_INVALID_ID, pos, isSub);
		subWorkTask.execute();
		addList(subWorkTask);
	}

	public void querySub(String url, int index) {
		if (querySubTask != null
				&& querySubTask.getStatus() != AsyncTask.Status.FINISHED) {
			return;
		}

		querySubTask = new QuerySubAsyncTask(url, new CommonVo(),
				SHOP_QUERY_SUB_DONE, index);
		querySubTask.execute();
		addList(querySubTask);
	}

	public class GetShopListTask extends GetNetWorkDataTask {

		public GetShopListTask(String url, CommonVo cv, int notificationId) {
			super(url, cv, notificationId);
			Log.d("Bran", "GetShopListTask url = " + url);
		}

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			ShopPagerModel.this.notify(SHOP_PAGER_START);
		}

		@Override
		protected CommonVo doInBackground(Object... arg0) {
			try {
				long start = System.currentTimeMillis();

				getter = new JSONGetter(false);
				JsonResult jr = getter.doGet(url);
				Log.d("Bran",
						"Download ShopList time is "
								+ (System.currentTimeMillis() - start));
				start = System.currentTimeMillis();
				if (jr != null) {
					if (jr.isAuthNeeded())
					// 需要登录
					{
						ShopPagerModel.this
								.notify(NotificationIds.NEED_AUTH_ID);
					} else if (jr.isSuccess() && cv.parse(jr.getData())) {
						Log.d("Bran",
								"parse ShopList time is "
										+ (System.currentTimeMillis() - start));
						return cv;
					} else {
						cv.setErrorCode(jr.getErrCode());
						cv.setErrorMsg(jr.getErrMsg());
						return cv;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}

		@Override
		public void onPostExecute(CommonVo vo) {
			if (vo != null) {
				if (shopPagerVo.shopList != null
						&& shopPagerVo.shopList.size() > 0) {
					cardSize = shopPagerVo.shopList.size();
					shopCardVoList = new SparseArray<ShopCardVo>(cardSize);
				}
				ShopPagerModel.this.notify(SHOP_PAGER_DONE);
			}
			super.onPostExecute(vo);
		}

		@Override
		protected void onCancelled() {
			super.onCancelled();
			ShopPagerModel.this.notify(SHOP_PAGER_FAILURE);

		}
	}

	public class GetShopCardTask extends GetNetWorkDataTask {

		private int pos;

		public GetShopCardTask(String url, CommonVo cv, int notificationId,
				int pos) {
			super(false, url, cv, notificationId);
			this.pos = pos;
			Log.d("Bran", "GetShopCardTask url = " + url);
		}

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			ShopPagerModel.this.notify(SHOP_CARD_START);
		}

		@Override
		protected CommonVo doInBackground(Object... arg0) {

			long start = System.currentTimeMillis();
			CommonVo vo = super.doInBackground(arg0);
			Log.d("Bran",
					"Download ShopList[" + pos + "] time is "
							+ (System.currentTimeMillis() - start));

			if (cdLatch != null) {
				try {
					cdLatch.await();
				} catch (InterruptedException e) {

				}
			}

			return vo;
		}

		@Override
		public void onPostExecute(CommonVo vo) {
			if (vo != null) {
				if (shopCardVoList != null) {
					shopCardVoList.put(pos, (ShopCardVo) vo);
				}
				Bundle bundle = new Bundle();
				bundle.putInt("notificationId", SHOP_CARD_DONE);
				bundle.putInt("index", pos);
				ShopPagerModel.this.notify(bundle);
			} else {
				Bundle bundle = new Bundle();
				bundle.putInt("notificationId", SHOP_CARD_FAILURE);
				bundle.putInt("index", pos);
				ShopPagerModel.this.notify(bundle);
			}
			super.onPostExecute(vo);
		}

		@Override
		protected void onCancelled() {
			super.onCancelled();
			Bundle bundle = new Bundle();
			bundle.putInt("notificationId", SHOP_CARD_FAILURE);
			bundle.putInt("index", pos);
			ShopPagerModel.this.notify(bundle);

		}
	}

	public class SubscribeAsyncTask extends GetNetWorkDataTask {

		private int pos;
		private boolean isSub;

		public SubscribeAsyncTask(String url, CommonVo cv, int notificationId,
				int pos, boolean isSub) {
			super(false, url, cv, notificationId);
			this.pos = pos;
			this.isSub = isSub;
			Log.d("Bran", "url = " + url);
		}

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			Bundle bundle = new Bundle();
			bundle.putInt("notificationId", SHOP_SUBSCRIBE_START);
			bundle.putInt("index", pos);
			bundle.putBoolean("isSub", isSub);
			ShopPagerModel.this.notify(bundle);
		}

		@Override
		public void onPostExecute(CommonVo vo) {
			super.onPostExecute(vo);
			if (vo == null) {
				Bundle bundle = new Bundle();
				bundle.putInt("notificationId", SHOP_SUBSCRIBE_FAILURE);
				bundle.putInt("index", pos);
				bundle.putBoolean("isSub", isSub);
				ShopPagerModel.this.notify(bundle);
			} else {
				Bundle bundle = new Bundle();
				bundle.putInt("notificationId", SHOP_SUBSCRIBE_DONE);
				bundle.putInt("index", pos);
				bundle.putBoolean("isSub", !isSub);
				ShopPagerModel.this.notify(bundle);
			}
		}

		@Override
		protected void onCancelled() {
			super.onCancelled();
			Bundle bundle = new Bundle();
			bundle.putInt("notificationId", SHOP_SUBSCRIBE_FAILURE);
			bundle.putInt("index", pos);
			bundle.putBoolean("isSub", isSub);
			ShopPagerModel.this.notify(bundle);

		}

	}

	public class QuerySubAsyncTask extends GetNetWorkDataTask {

		private int pos;

		public QuerySubAsyncTask(String url, CommonVo cv, int notificationId,
				int pos) {
			super(false, url, cv, notificationId);
			this.pos = pos;
			Log.d("Bran", "url = " + url);
		}

		@Override
		public void onPostExecute(CommonVo vo) {
			super.onPostExecute(vo);
			if (vo != null) {
				int errCode = vo.getErrorCode();
				if (errCode == 0) {
					Bundle bundle = new Bundle();
					bundle.putInt("notificationId", SHOP_QUERY_SUB_DONE);
					bundle.putInt("index", pos);
					bundle.putBoolean("isSub", true);
					ShopPagerModel.this.notify(bundle);
				} else if (errCode == 0x0204) {
					Bundle bundle = new Bundle();
					bundle.putInt("notificationId", SHOP_QUERY_SUB_DONE);
					bundle.putInt("index", pos);
					bundle.putBoolean("isSub", false);
					ShopPagerModel.this.notify(bundle);
				}
			}
		}
	}
}
