package com.tencent.weigou.shopping.model;

import com.tencent.weigou.base.model.Model;
import com.tencent.weigou.shopping.model.vo.CmdyDetailVo;

public class CmdyModel extends Model {
	public final static int INIT_DATA = 0;
	public CmdyDetailVo cmdyVo;

	@Override
	public void initData(String url) {
		cmdyVo = new CmdyDetailVo();
		createNetWorkTask(url, cmdyVo, INIT_DATA);
	}
}
