package com.tencent.weigou.shopping.activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;

import com.tencent.weigou.R;
import com.tencent.weigou.base.activity.TitleBarActivity;
import com.tencent.weigou.common.ui.draggable.OnRefreshListener;
import com.tencent.weigou.common.ui.draggable.OverScrollView;
import com.tencent.weigou.shopping.model.CmdyPagerModel;
import com.tencent.weigou.shopping.model.NavCmdyModel;
import com.tencent.weigou.shopping.model.vo.CmdyVo;
import com.tencent.weigou.shopping.model.vo.CmdyVo.CmdyItemVo;
import com.tencent.weigou.shopping.view.NavCmdyUI;
import com.tencent.weigou.util.ConstantsActivity;
import com.tencent.weigou.util.StringUtils;

public class NavCmdyListActivity extends TitleBarActivity implements
		OnClickListener, OnRefreshListener {
	NavCmdyUI ui = new NavCmdyUI();
	NavCmdyModel model = new NavCmdyModel();
	int pn = 1;
	String url = "";
	Intent backIt = new Intent();
	private static final int PAGE_SIZE = 20;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		init();
		initMVC(model, ui, R.layout.shopping_nav_cmdy);
		setTitle("快速导航");
		initBackBtn();
		topbar.findViewById(R.id.top_bar_back_tv).setVisibility(View.INVISIBLE);
		topbar.initRightBtnA(R.drawable.top_bar_arrow, "", this);
		ui.updateContent(model.navVo);
	}

	private void init() {
		pn = app.getShareData().getInt(ConstantsActivity.INTENT_CMDY_PN, 1);
		url = app.getShareData().getString(
				ConstantsActivity.INTENT_CMDY_NAV_URL);
		CmdyVo cv = (CmdyVo) app.getShareData().getSerializable(
				ConstantsActivity.INTENT_CMDY_NAV_DATA);
		model.navVo = cv;

	}

	@Override
	public void update(int notificationId) {
		super.update(notificationId);
		switch (notificationId) {
		case CmdyPagerModel.NEXT_DATA:
			ui.resetMallFooter(true);
			model.navVo.list.addAll(model.navVo.tmpList);
			ui.refresh();
			break;
		}

	}

	// @Override
	// public void onItemClick(AdapterView<?> parent, View view, int position,
	// long id) {
	// Intent it = new Intent();
	// CmdyItemVo civ = (CmdyItemVo) parent.getItemAtPosition(position);
	// it.putExtra(ConstantsActivity.INTENT_CMDY_ID, civ.id);
	// setResult(RESULT_OK, it);
	// finish();
	// overridePendingTransition(R.anim.in_from_up, R.anim.out_to_up);
	// }

	@Override
	public void finish() {
		app.getShareData().putSerializable(
				ConstantsActivity.INTENT_CMDY_NAV_DATA, model.navVo);
		setResult(RESULT_OK, backIt);
		super.finish();
		overridePendingTransition(R.anim.in_from_up, R.anim.out_to_up);
	}

	@Override
	public void onClick(View v) {
		if (v != null && v.getTag() != null && v.getTag() instanceof CmdyItemVo) {

			switch (v.getId()) {
			case R.id.shopping_nav_item_rl1:
			case R.id.shopping_nav_item_rl2:
				CmdyItemVo cmdyItemVo = (CmdyItemVo) v.getTag();
				backIt.putExtra(ConstantsActivity.INTENT_CMDY_ID, cmdyItemVo.id);
				app.getShareData().putInt(ConstantsActivity.INTENT_CMDY_PN, pn);
				app.getShareData().putString(
						ConstantsActivity.INTENT_CMDY_NAV_URL, url);
				finish();
				break;
			}
		} else {
			finish();
		}
	}

	@Override
	public void onRefreshing(OverScrollView view, Object obj) {
		try {
			String tmpPn = "pn=" + pn;
			pn += 1;
			int pz = (int) Math.ceil((double) model.navVo.total
					/ (double) PAGE_SIZE);
			if (pn > pz) {
				ui.resetFooter(true);
				return;
			}
			String tmpNextPn = "pn=" + pn;
			url = url.replaceAll(tmpPn, tmpNextPn);
			model.nextData(url);
		} catch (Exception e) {
			ui.resetFooter(true);
			e.printStackTrace();
		}
	}

}
