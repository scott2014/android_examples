package com.tencent.weigou.shopping.model;

import com.tencent.weigou.base.model.Model;
import com.tencent.weigou.shopping.model.vo.NavVo;

public class NavModel extends Model {
	public final static int INIT_DATA = 0;
	public NavVo navVo;

	@Override
	public void initData(String url) {
		navVo = new NavVo();
		createNetWorkTask(url, navVo, INIT_DATA);
	}
}
