package com.tencent.weigou.shopping.model.vo;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.tencent.weigou.base.model.vo.CommonVo;
import com.tencent.weigou.util.Util;

public class CmdyDetailVo extends CommonVo {
	public String id;
	public String price;
	public String name;
	public List<String> urls = new ArrayList<String>();

	public boolean parse(JSONObject jo) {
		try {
			id = jo.optString("itemId");
			name = jo.optString("itemName");
			price = Util.getCurrency(jo.optString("price")).replace(".00", "");
			JSONArray jsonArray = jo.getJSONArray("pics");
			for (int i = 0; i < jsonArray.length(); i++) {
				urls.add(jsonArray.getJSONObject(i).optString("url"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return true;
	}

}
