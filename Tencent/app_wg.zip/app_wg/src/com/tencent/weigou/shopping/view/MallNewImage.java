package com.tencent.weigou.shopping.view;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.widget.ImageView;
import com.tencent.weigou.util.StringUtils;
import com.tencent.weigou.util.Util;

/**
 * 上新图片，当不显示图片的时候，需要显示上新数量
 * User: ethonchan
 * Date: 13-12-5
 * Time: 下午4:01
 */
public class MallNewImage extends ImageView {

    //  显示新品数量
    private boolean showNewCount = false;

    //  文字颜色
    private final static int COLOR_LABEL = Color.rgb(51, 51, 51);

    //  数字颜色
    private final static int COLOR_RED = Color.rgb(215, 0, 0);

    //  图片背景颜色
    private final static int COLOR_BG = Color.rgb(231, 231, 231);

    private String stringA = "其他";

    private String stringB = "0";

    private String stringC = "件";

    private String stringD = "上新";

    public MallNewImage(Context context) {
        super(context);
    }

    public MallNewImage(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public MallNewImage(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    /**
     * 显示上新数量
     *
     * @param newCount
     */
    public void showNewCount(String newCount) {
        showNewCount = true;
        stringB = newCount;
    }

    public void showImage() {
        showNewCount = false;
        stringB = "0";
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (showNewCount)
        //    显示上新数量
        {
            int size5 = Util.dip2px(getContext(), 3);
            int size10 = size5 * 2;
            int size20 = size5 * 4;
            int size25 = size5 * 5;
            int size30 = size5 * 6;
            //设置背景
            canvas.drawColor(COLOR_BG);
            Paint paint = new Paint();
            paint.setAntiAlias(true);
            //paint.setTypeface(Typeface.MONOSPACE);
            //paint.setFlags(Paint.LINEAR_TEXT_FLAG);

            //  文字的大小
            paint.setTextSize(size25);
            Rect rectA = getStringRect(stringA, paint);
            Rect rectC = getStringRect(stringC, paint);
            Rect rectD = getStringRect(stringD, paint);

            //  数字的大小
            paint.setTextSize(size30);
            Rect rectB = getStringRect(stringB, paint);

            paint.setTextSize(size25);
            Paint.FontMetricsInt fontMetrics = paint.getFontMetricsInt();
            //  计算文字的起始位置
            int width = getWidth();
            int height = getHeight();
            //  X起始位置
            int topWidth = rectA.width() + rectB.width() + rectC.width() + size10;
            int originXA = (width - topWidth) / 2;
            int originXB = originXA + rectA.width() + size5;
            int originXC = originXB + rectB.width() + size5;

            //  descent为正值, leading为负值
            int originUpY = height / 2 - fontMetrics.descent;
            //  ascent为负值
            int originDownY = originUpY + fontMetrics.leading + 2 - fontMetrics.ascent;

            paint.setTextSize(size25);
            paint.setColor(COLOR_LABEL);
            canvas.drawText(stringA, originXA, originUpY, paint);

            paint.setTextSize(size30);
            paint.setColor(COLOR_RED);
            canvas.drawText(stringB, originXB, originUpY, paint);

            paint.setTextSize(size25);
            paint.setColor(COLOR_LABEL);
            canvas.drawText(stringC, originXC, originUpY, paint);

            canvas.drawText(stringD, originXA, originDownY, paint);

            int leftE = originXB;
            int rightE = originXB + size10;
            int topE = originDownY - size20;
            int bottomE = originDownY;
            int halfE = topE + size10;
            canvas.drawLine(leftE, topE, rightE, halfE, paint);
            canvas.drawLine(rightE, halfE, leftE, bottomE, paint);
            canvas.save();
        } else {
            super.onDraw(canvas);
        }
    }

    private Rect getStringRect(String str, Paint paint) {
        Rect rect = new Rect();
        if (StringUtils.isNotEmpty(str)) {
            paint.getTextBounds(str, 0, str.length(), rect);
        }
        return rect;
    }
}
