package com.tencent.weigou.recom.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

import com.tencent.weigou.R;
import com.tencent.weigou.base.activity.TitleBarActivity;
import com.tencent.weigou.feeds.activity.FeedListActivity;
import com.tencent.weigou.my.activity.MyFollowActivity;
import com.tencent.weigou.recom.RecomType;
import com.tencent.weigou.recom.model.RecomModel;
import com.tencent.weigou.recom.model.view.RecomUI;
import com.tencent.weigou.recom.model.vo.RecomVo;
import com.tencent.weigou.shopping.activity.ShoppingIndexActivity;
import com.tencent.weigou.util.ConstantsActivity;
import com.tencent.weigou.util.ConstantsUrl;
import com.tencent.weigou.util.StringUtils;
import com.tencent.weigou.util.PageIds.OprIndex;
import com.tencent.weigou.util.Util;

/**
 * 
 * @ClassName： RecomActivity
 * 
 * @Description： 推荐关注
 * @author wamiwen
 * @date 2013-12-10 下午4:02:56
 * 
 */
public class RecomActivity extends TitleBarActivity implements OnClickListener {

	// 推荐类型
	public final static String RECOM_TYPE = "recom_type";

	private RecomModel model = new RecomModel();

	private RecomUI ui = new RecomUI();

	private String sourceActivity = "";

	// 推荐类型
	private RecomType mRecomType = RecomType.DEFAULT;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		initMVC(model, ui, R.layout.recom_layout);
		initBackBtn();
		setTitle(R.string.recom_follow);

		init();
	}

	private void init() {

		initIntent(getIntent());

		StringBuffer sb = new StringBuffer(app.getEnv().getServerUrl());
		sb.append(ConstantsUrl.URL_RECOM_SUBSCRIBE);
		if (mRecomType != null) {
			sb.append("?sc=").append(mRecomType.getValue());
		}
		String url = sb.toString();
		url = appendPageInfo(url, OprIndex.PV_OPR);
		model.initData(url);
	}

	private void initIntent(Intent intent) {
		if (intent != null) {
			sourceActivity = intent
					.getStringExtra(ConstantsActivity.INTENT_SOURCE_ACTIVITY);
			String recomTypeValue = intent.getStringExtra(RECOM_TYPE);
			int typeValue = Util.getInt(recomTypeValue, 0);
			mRecomType = RecomType.parseRecomType(typeValue);
		}
	}

	@Override
	public void onBackPressed() {
		if (sourceActivity.equals(FeedListActivity.class.getSimpleName())) {
			startFeedListActivity();
		} else if (sourceActivity.equals(ShoppingIndexActivity.class
				.getSimpleName())) {
			startShoppingIndexActivity();
		} else if (sourceActivity
				.equals(MyFollowActivity.class.getSimpleName())) {
			startMyFollowActivity();
		}
		super.onBackPressed();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (ui != null) {
			ui.onDestroy();
		}
	}

	@Override
	protected void onNetworkUnavailable(int noti) {
		super.onNetworkUnavailable(noti);
		ui.onNetworkUnavailable();
	}

	@Override
	public void update(int notificationId) {
		super.update(notificationId);
		switch (notificationId) {
		case RecomModel.INIT_DATA:
			ui.updateContent(model.getRecomVo());
			break;
		case RecomModel.BATCH_SUBSCRIBE_SUCCESS:
			showToast("关注成功", R.drawable.mall_detail_sub_success);
			finish();
			if (sourceActivity.equals(FeedListActivity.class.getSimpleName())) {
				startFeedListActivity();
			} else if (sourceActivity.equals(ShoppingIndexActivity.class
					.getSimpleName())) {
				startShoppingIndexActivity();
			} else if (sourceActivity.equals(MyFollowActivity.class
					.getSimpleName())) {
				startMyFollowActivity();
			}
			break;
		case RecomModel.BATCH_SUBSCRIBE_FAILURE:
			showToast("关注失败", R.drawable.mall_detail_sub_fail);
			break;
		default:
			break;
		}
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.finish_btn:
			RecomVo recomVo = model.getRecomVo();
			if (recomVo == null) {
				break;
			}
			final String selectedBrandIds = recomVo.getSelectedBrandIds();
			final String selectedMallIds = recomVo.getSelectedMallIds();
			final String selectedShopIds = recomVo.getSelectedShopIds();
			if (StringUtils.isBlank(selectedBrandIds)
					&& StringUtils.isBlank(selectedMallIds)
					&& StringUtils.isBlank(selectedShopIds)) {
				if (StringUtils.isBlank(sourceActivity)) {
					;
				} else if (sourceActivity.equals(FeedListActivity.class
						.getSimpleName())) {
					startFeedListActivity();
				} else if (sourceActivity.equals(ShoppingIndexActivity.class
						.getSimpleName())) {
					startShoppingIndexActivity();
				}
				finish();
				break;
			}
			String sl = selectedBrandIds + ";" + selectedMallIds + ";"
					+ selectedShopIds;
			StringBuffer sb = new StringBuffer(app.getEnv().getServerUrl());
			sb.append(ConstantsUrl.URL_BATCH_SUBSCRIBE).append("?sl=")
					.append(sl).append("&ctp=1");
			String url = sb.toString();
			url = appendPageInfo(url, OprIndex.PV_OPR);
			model.submitFollows(url);
			break;

		default:
			break;
		}

	}

	private void startFeedListActivity() {
		Intent intent = new Intent(this, FeedListActivity.class);
		startActivity(intent);
	}

	private void startShoppingIndexActivity() {
		Intent intent = new Intent(this, ShoppingIndexActivity.class);
		startActivity(intent);
	}

	private void startMyFollowActivity() {
		Intent intent = new Intent(this, MyFollowActivity.class);
		String pagerIndex = "0";
		switch (mRecomType) {
		case MALL:
			pagerIndex = "0";
			break;
		case SHOP:
			pagerIndex = "1";
			break;
		case BRAND:
			pagerIndex = "2";
			break;
		default:
			break;
		}
		intent.putExtra(ConstantsActivity.INTENT_PAGER_INDEX, pagerIndex);
		startActivity(intent);
	}

}
