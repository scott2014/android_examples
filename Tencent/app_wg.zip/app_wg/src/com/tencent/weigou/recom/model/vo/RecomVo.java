package com.tencent.weigou.recom.model.vo;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.tencent.weigou.base.model.vo.CommonVo;
import com.tencent.weigou.util.StringUtils;

/**
 * 
 * @ClassName： RecomVo
 *
 * @Description： 推荐关注Vo
 * @author wamiwen
 * @date 2013-12-10 下午3:52:59
 *
 */
public class RecomVo extends CommonVo {

	/**
	 * 推荐关注品牌列表
	 */
	public List<RecomBrandVo> recomBrandList = new ArrayList<RecomVo.RecomBrandVo>();
	
	/**
	 * 推荐关注商场列表
	 */
	public List<RecomMallVo> recomMallList = new ArrayList<RecomVo.RecomMallVo>();

    /**
     * 推荐关注门店列表
     */
    public List<RecomShopVo> recomShopList = new ArrayList<RecomShopVo>();
	
	@Override
	public boolean parse(JSONObject data) {
		try {
			JSONArray recomBrand = data.optJSONArray("recomBrand");
			if (recomBrand != null && recomBrand.length() > 0) {
				for (int i = 0, len = recomBrand.length(); i < len; i++) {
					final JSONObject recomBrandObj = recomBrand.optJSONObject(i);
					final RecomBrandVo recomBrandVo = RecomBrandVo.parseJSONObj(recomBrandObj);
					if (recomBrandVo != null) {
						recomBrandList.add(recomBrandVo);
					}
				}
			}
			JSONArray recomMall = data.optJSONArray("recomMall");
			if (recomMall != null && recomMall.length() > 0) {
				for (int i = 0, len = recomMall.length(); i < len; i++) {
					final JSONObject recomMallObj = recomMall.optJSONObject(i);
					final RecomMallVo recomMallVo = RecomMallVo.parseJSONObj(recomMallObj);
					if (recomMallVo != null) {
						recomMallList.add(recomMallVo);
					}
				}
			}
			JSONArray recomShop = data.optJSONArray("recomShop");
			if (recomShop != null && recomShop.length() > 0) {
				for (int i = 0, len = recomShop.length(); i < len; i++) {
					final JSONObject recomShopObj = recomShop.optJSONObject(i);
					final RecomShopVo recomShopVo = RecomShopVo.parseJSONObj(recomShopObj);
					if (recomShopVo != null) {
						recomShopList.add(recomShopVo);
					}
				}
			}
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public String getSelectedBrandIds() {
		String ids = "";
		for (RecomBrandVo recomBrandVo : recomBrandList) {
			if (recomBrandVo == null || !recomBrandVo.selected) {
				continue;
			}
			ids += recomBrandVo.id + ",";
		}
		if (StringUtils.isNotBlank(ids)) {
			ids  = ids.substring(0, ids.length() - 1);
		}
		return ids;
	}
	
	public String getSelectedMallIds() {
		String ids = "";
		for (RecomMallVo recomMallVo : recomMallList) {
			if (recomMallVo == null || !recomMallVo.selected) {
				continue;
			}
			ids += recomMallVo.id + ",";
		}
		if (StringUtils.isNotBlank(ids)) {
			ids = ids.substring(0, ids.length() - 1);
		}
		return ids;
	}
	
	public String getSelectedShopIds() {
		String ids = "";
		for (RecomShopVo recomShopVo : recomShopList) {
			if (recomShopVo == null || !recomShopVo.selected) {
				continue;
			}
			ids += recomShopVo.id + ",";
		}
		if (StringUtils.isNotBlank(ids)) {
			ids = ids.substring(0, ids.length() - 1);
		}
		return ids;
	}
	
	/**
	 * 
	 * @ClassName： RecomBrandVo
	 *
	 * @Description：推荐关注品牌vo
	 * @author wamiwen
	 * @date 2013-12-10 下午5:02:00
	 *
	 */
	public static class RecomBrandVo {
		public String id = "";
		public String name = "";
		public String logoUrl = "";
		//  是否选中
        public boolean selected = false;
        
        private RecomBrandVo(String id, String name, String logoUrl) {
        	this.id = id;
        	this.name = name;
        	this.logoUrl = logoUrl;
        	this.selected = false;
        }
        
        public static RecomBrandVo parseJSONObj(JSONObject jsonObj) {
        	if (jsonObj == null) {
				return null;
			}
        	final String id = jsonObj.optString("id", "");
        	final String name = jsonObj.optString("name", "");
        	final String logoUrl = jsonObj.optString("logo", "");
        	
        	return new RecomBrandVo(id, name, logoUrl);
        }
	}
	
	/**
	 * 
	 * @ClassName： RecomMallVo
	 *
	 * @Description： 推荐关注商场vo
	 * @author wamiwen
	 * @date 2013-12-10 下午5:02:15
	 *
	 */
	public static class RecomMallVo {
		public String id = "";
		public String name = "";
		public String landscapePicUrl = "";
		public String promotion = "";
		//  是否选中
        public boolean selected = false;
        
        private RecomMallVo(String id, String name, String landscapePicUrl, String promotion) {
        	this.id = id;
        	this.name = name;
        	this.landscapePicUrl = landscapePicUrl;
        	this.promotion = promotion;
        	this.selected = false;
        }
        
        public static RecomMallVo parseJSONObj(JSONObject jsonObj) {
        	if (jsonObj == null) {
				return null;
			}
        	final String id = jsonObj.optString("mallId", "");
        	final String name = jsonObj.optString("mallName", "");
        	final String landscapePicUrl = jsonObj.optString("backgroudUrl", "");
        	String promotion = "";
        	JSONArray acts = jsonObj.optJSONArray("acts");
        	if (acts != null && acts.length() > 0) {
				JSONObject actObj = acts.optJSONObject(0);
				if (actObj != null) {
					promotion = actObj.optString("title", "");
				}
			}
        	
        	return new RecomMallVo(id, name, landscapePicUrl, promotion);
        }
	}

    /**
     * 推荐关注门店
     * @author ethonchan
     */
    public static class RecomShopVo {
        //  店铺ID
        public String id = "";
        //  店铺名称
        public String name = "";
        //  图片url
        public String picUrl = "";
        //  广告语
        public String promotion = "";
        //  是否选中
        public boolean selected = false;

        public RecomShopVo(String id, String name, String picUrl, String promotion) {
            this.id = id;
            this.name = name;
            this.picUrl = picUrl;
            this.promotion = promotion;
            this.selected = false;
        }
        
        public static RecomShopVo parseJSONObj(JSONObject jsonObj) {
        	if (jsonObj == null) {
				return null;
			}
        	final String id = jsonObj.optString("id", "");
        	final String name = jsonObj.optString("name", "");
        	final String picUrl = jsonObj.optString("backgroudUrl", "");
        	final String promotion = jsonObj.optString("promoteDesc", "");
        	
        	return new RecomShopVo(id, name, picUrl, promotion);
        }
    }

}