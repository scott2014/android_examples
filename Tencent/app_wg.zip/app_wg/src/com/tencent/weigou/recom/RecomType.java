package com.tencent.weigou.recom;

/**
 * 推荐类型
 *
 * @author: ethonchan
 * @date: 13-12-26 下午5:06
 */
public enum RecomType {
    DEFAULT(1), BRAND(2), MALL(3), SHOP(4);

    RecomType(int value) {
        this.value = value;
    }

    private int value;

    public int getValue() {
        return value;
    }

    public static RecomType parseRecomType(int typeValue) {
        if (typeValue == 2) {
            return BRAND;
        } else if (typeValue == 3) {
            return MALL;
        } else if (typeValue == 4) {
            return SHOP;
        } else {
            return DEFAULT;
        }
    }
}
