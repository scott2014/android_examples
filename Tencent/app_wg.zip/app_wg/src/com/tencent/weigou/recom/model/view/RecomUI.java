package com.tencent.weigou.recom.model.view;

import java.util.List;

import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;

import com.tencent.weigou.R;
import com.tencent.weigou.base.view.UI;
import com.tencent.weigou.common.ui.AdaptiveImageView;
import com.tencent.weigou.recom.activity.RecomActivity;
import com.tencent.weigou.recom.model.vo.RecomVo;
import com.tencent.weigou.recom.model.vo.RecomVo.RecomBrandVo;
import com.tencent.weigou.recom.model.vo.RecomVo.RecomMallVo;
import com.tencent.weigou.util.AsyncImageLoader;
import com.tencent.weigou.util.IImageLoadedCallBack;
import com.tencent.weigou.util.Util;

/**
 * 
 * @ClassName： RecomUI
 * 
 * @Description： 推荐关注UI
 * @author wamiwen
 * @date 2013-12-10 下午4:05:23
 * 
 */
public class RecomUI extends UI implements OnClickListener {

	private TextView mallTitleTv;

	private TextView brandTitleTv;

	/**
	 * 推荐关注商场容器
	 */
	private LinearLayout recomMallOutter;

	/**
	 * 推荐关注品牌容器
	 */
	private LinearLayout recomBrandOutter;

    //  推荐关注门店容器
    private ViewGroup mShopLayout;

    //  推荐关注门店标题
    private View mShopTitle;

	/**
	 * 完成按钮
	 */
	private Button finishBtn;
	
	private View contentView;
	
	private View emptyView;
	private TextView emptyTipsTv;
	private TextView emptyDescTv;

	/**
	 * 图片加载工具
	 */
	private AsyncImageLoader imageLoader = new AsyncImageLoader(true);

	@Override
	public void initView(View outterView) {
		super.initView(outterView);
		contentView = outterView.findViewById(R.id.content_view);
		mallTitleTv = (TextView) outterView.findViewById(R.id.recom_mall_title);
		brandTitleTv = (TextView) outterView.findViewById(R.id.recom_brand_title);
        mShopTitle = outterView.findViewById(R.id.recom_shop_title);

		recomMallOutter = (LinearLayout) outterView
				.findViewById(R.id.recom_mall_outter);
		recomBrandOutter = (LinearLayout) outterView
				.findViewById(R.id.recom_brand_outter);
        mShopLayout = (ViewGroup) outterView.findViewById(R.id.recom_shop_outter);
        
        emptyView = outterView.findViewById(R.id.empty_view);
        emptyTipsTv = (TextView) outterView.findViewById(R.id.tips_tv);
        emptyDescTv = (TextView) outterView.findViewById(R.id.tips_desc_tv);

		finishBtn = (Button) outterView.findViewById(R.id.finish_btn);
		finishBtn.setOnClickListener((RecomActivity) context);
	}
	
	/**
     * 网络不可用
     */
    public void onNetworkUnavailable(){
    	contentView.setVisibility(View.GONE);
        emptyView.setVisibility(View.VISIBLE);
        emptyTipsTv.setText(context.getString(R.string.network_unavailable_tips_recom));
        emptyDescTv.setText(context.getString(R.string.please_check_network_v2));
    }

	public void updateContent(RecomVo vo) {
		super.updateContent(vo);
		if (vo == null) {
			return;
		}
		if ((vo.recomMallList == null || vo.recomMallList.size() == 0)
				&& (vo.recomShopList == null || vo.recomShopList.size() == 0)
				&& (vo.recomBrandList == null || vo.recomBrandList.size() == 0)) {
			contentView.setVisibility(View.GONE);
			emptyView.setVisibility(View.VISIBLE);
		} else {
			emptyView.setVisibility(View.GONE);
			contentView.setVisibility(View.VISIBLE);
			initRecomMallView(vo.recomMallList);
	        displayShopList(vo.recomShopList);
			initRecomBrandView(vo.recomBrandList);
		}
	}

	/**
	 * 
	 * @Title: initRecomMallView
	 *
	 * @Description: 初始化推荐关注Mall
	 * @param @param recomMallList  设定文件
	 * @return void  返回类型
	 * @throws
	 */
	private void initRecomMallView(final List<RecomMallVo> recomMallList) {
		if (recomMallList == null || recomMallList.size() == 0) {
            mallTitleTv.setVisibility(View.GONE);
			recomMallOutter.setVisibility(View.GONE);
			return;
		}
		for (RecomMallVo recomMallVo : recomMallList) {
			final View recomMallItemView = createRecomMallItemView(recomMallVo);
			if (recomMallItemView != null) {
				recomMallOutter.addView(recomMallItemView);
			}
		}
	}

	/**
	 * 
	 * @Title: createRecomMallItemView
	 *
	 * @Description: 商场ItemView
	 * @param @param recomMallVo
	 * @param @return  设定文件
	 * @return View  返回类型
	 * @throws
	 */
	private View createRecomMallItemView(final RecomMallVo recomMallVo) {
		if (recomMallVo == null) {
			return null;
		}
		final View itemView = LayoutInflater.from(context).inflate(
				R.layout.recom_mall_item, null);
		final ImageView landscape = (ImageView) itemView
				.findViewById(R.id.landscape);
		final TextView mallNameTv = (TextView) itemView
				.findViewById(R.id.mall_name);
		final TextView mallPromTv = (TextView) itemView
				.findViewById(R.id.mall_promotion);

		landscape.setTag(recomMallVo.landscapePicUrl);
		asyncLoadImage(landscape, recomMallVo.landscapePicUrl, false);
		mallNameTv.setText(recomMallVo.name);
		mallPromTv.setText(recomMallVo.promotion);

		final LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
				LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
		params.setMargins(0, 0, 0, Util.dip2px(context, 15));
		itemView.setLayoutParams(params);

		itemView.setTag(recomMallVo);
		itemView.setOnClickListener(this);

		return itemView;
	}

    /**
     * 显示门店信息
     * @param shopList
     */
    public void displayShopList(final List<RecomVo.RecomShopVo> shopList){
        if(shopList == null || shopList.size() < 1){
            mShopLayout.setVisibility(View.GONE);
            mShopTitle.setVisibility(View.GONE);
            return;
        }

        mShopLayout.removeAllViews();
        for(RecomVo.RecomShopVo shopVo : shopList){
            View itemView = createRecomShopView(shopVo);
            if(itemView != null){
                mShopLayout.addView(itemView);
            }
        }
    }

    /**
     * 创建单个门店view
     * @param shopVo
     * @return
     */
    private View createRecomShopView(final RecomVo.RecomShopVo shopVo){
        if(shopVo == null){
            return null;
        }

        LayoutInflater inflater = LayoutInflater.from(context);
        View itemView = inflater.inflate(R.layout.recom_shop_item, null);

        final ImageView landscape = (ImageView) itemView
				.findViewById(R.id.landscape);
		final TextView mallNameTv = (TextView) itemView
				.findViewById(R.id.mall_name);
		final TextView mallPromTv = (TextView) itemView
				.findViewById(R.id.mall_promotion);

		landscape.setTag(shopVo.picUrl);
		asyncLoadImage(landscape, shopVo.picUrl, false);
		mallNameTv.setText(shopVo.name);
		mallPromTv.setText(shopVo.promotion);

		final LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
				LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
		params.setMargins(0, 0, 0, Util.dip2px(context, 15));
		itemView.setLayoutParams(params);

		itemView.setTag(shopVo);
		itemView.setOnClickListener(this);
        return itemView;
    }

	/**
	 * 
	 * @Title: initRecomBrandView
	 *
	 * @Description: 推荐关注品牌View
	 * @param @param recomBrandList  设定文件
	 * @return void  返回类型
	 * @throws
	 */
	private void initRecomBrandView(final List<RecomBrandVo> recomBrandList) {
		if (recomBrandList == null || recomBrandList.size() == 0) {
            brandTitleTv.setVisibility(View.GONE);
			recomBrandOutter.setVisibility(View.GONE);
			return;
		}
		final int listSize = recomBrandList.size();
		final int ROW_SIZE = 3;
		final int rowNum = listSize / ROW_SIZE;
		final int residue = listSize % ROW_SIZE;
		final LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
				LayoutParams.MATCH_PARENT,
				android.widget.FrameLayout.LayoutParams.WRAP_CONTENT);
		params.setMargins(0, 0, 0, Util.dip2px(context, 15));

		int i = 0;
		View rowView = null;
		for (; i < rowNum; i++) {
			rowView = createRecomBrandRowView(recomBrandList.subList(i
					* ROW_SIZE, (i + 1) * ROW_SIZE));
			if (rowView != null) {
				recomBrandOutter.addView(rowView, params);
			}
		}
		if (residue > 0) {
			rowView = createRecomBrandRowView(recomBrandList.subList(i
					* ROW_SIZE, listSize));
			if (rowView != null) {
				recomBrandOutter.addView(rowView, params);
			}
		}
	}

	/**
	 * 
	 * @Title: createRecomBrandRowView
	 *
	 * @Description: 推荐关注品牌行View
	 * @param @param recomBrandRowList
	 * @param @return  设定文件
	 * @return View  返回类型
	 * @throws
	 */
	private View createRecomBrandRowView(
			final List<RecomBrandVo> recomBrandRowList) {
		if (recomBrandRowList == null) {
			return null;
		}
		final int size = recomBrandRowList.size();
		final View rowView = LayoutInflater.from(context).inflate(
				R.layout.recom_brand_row, null);
		final View leftItemView = rowView.findViewById(R.id.brand_left);
		final View middleItemView = rowView.findViewById(R.id.brand_middle);
		final View rightItemView = rowView.findViewById(R.id.brand_right);
		if (size > 2) {
			initRecomBrandItemView(leftItemView, recomBrandRowList.get(0));
			initRecomBrandItemView(middleItemView, recomBrandRowList.get(1));
			initRecomBrandItemView(rightItemView, recomBrandRowList.get(2));
		} else if (size > 1) {
			initRecomBrandItemView(leftItemView, recomBrandRowList.get(0));
			initRecomBrandItemView(middleItemView, recomBrandRowList.get(1));
			rightItemView.setVisibility(View.INVISIBLE);
		} else if (size > 0) {
			initRecomBrandItemView(leftItemView, recomBrandRowList.get(0));
			middleItemView.setVisibility(View.INVISIBLE);
			rightItemView.setVisibility(View.INVISIBLE);
		} else {
			return null;
		}

		return rowView;
	}

	/**
	 * 
	 * @Title: initRecomBrandItemView
	 *
	 * @Description: 推荐关注品牌ItemView
	 * @param @param itemView
	 * @param @param recomBrandVo  设定文件
	 * @return void  返回类型
	 * @throws
	 */
	private void initRecomBrandItemView(final View itemView,
			final RecomBrandVo recomBrandVo) {
		if (itemView == null || recomBrandVo == null) {
			return;
		}
		final AdaptiveImageView logoImage = (AdaptiveImageView) itemView
				.findViewById(R.id.brand_logo);
		logoImage.setDrawCircleBorder(true);
		final TextView nameTv = (TextView) itemView
				.findViewById(R.id.brand_name);

		logoImage.setTag(recomBrandVo.logoUrl);
		asyncLoadImage(logoImage, recomBrandVo.logoUrl, true);
		nameTv.setText(recomBrandVo.name);

		itemView.setTag(recomBrandVo);
		itemView.setOnClickListener(this);
	}

	/**
	 * 
	 * @Title: setRecomSelection
	 *
	 * @Description: 设置选中
	 * @param @param recomView
	 * @param @param selected  设定文件
	 * @return void  返回类型
	 * @throws
	 */
	private void setRecomSelection(final View recomView, final boolean selected) {
		final ImageView mark = (ImageView) recomView
				.findViewById(R.id.recom_mark);
        if(mark != null){
		    if (selected) {
		    	mark.setImageResource(R.drawable.recom_selected);
		    } else {
		    	mark.setImageResource(R.drawable.recom_unselect);
	    	}
        }
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		if (imageLoader != null) {
			imageLoader.destroy();
		}
	}

	/**
	 * 
	 * @Title: asyncLoadImage
	 * 
	 * @Description: 异步加载图片
	 * @param @param asyncImageLoader
	 * @param @param imgView
	 * @param @param url 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	protected void asyncLoadImage(final ImageView imgView, final String url,
			final boolean needRoundCornor) {
		final Bitmap bitmap = imageLoader.loadDrawable(url, imgView,
				needRoundCornor, new IImageLoadedCallBack() {

					@Override
					public void imageLoaded(final ImageView imageView,
							final Bitmap bitmap, final String imageUrl) {
						if (imageView != null && bitmap != null) {
							String tag = (String) imageView.getTag();
							if (tag != null && tag.equals(url)) {
								imageView.setImageBitmap(bitmap);
							}
						}

					}

				});
		if (bitmap != null) {
			imgView.setImageBitmap(bitmap);
		} else {
			;
		}
	}

	@Override
	public void onClick(View v) {
		if (v == null) {
			return;
		}
		final Object tag = v.getTag();
		if (tag == null) {
			return;
		}

		if (tag instanceof RecomMallVo) {
			final RecomMallVo recomMallVo = (RecomMallVo) tag;
			recomMallVo.selected = !recomMallVo.selected;
			setRecomSelection(v, recomMallVo.selected);
		} else if (tag instanceof RecomBrandVo) {
			final RecomBrandVo recomBrandVo = (RecomBrandVo) tag;
			recomBrandVo.selected = !recomBrandVo.selected;
			setRecomSelection(v, recomBrandVo.selected);
		} else if(tag instanceof RecomVo.RecomShopVo){
            RecomVo.RecomShopVo shopVo = (RecomVo.RecomShopVo) tag;
            boolean selected = !shopVo.selected;
            shopVo.selected = selected;
            setRecomSelection(v, selected);
        }
	}

}
