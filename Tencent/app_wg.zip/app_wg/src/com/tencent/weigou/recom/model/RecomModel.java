package com.tencent.weigou.recom.model;

import android.os.AsyncTask;

import com.tencent.weigou.base.json.JsonResult;
import com.tencent.weigou.base.model.Model;
import com.tencent.weigou.base.model.vo.CommonVo;
import com.tencent.weigou.recom.model.vo.RecomVo;
import com.tencent.weigou.util.NotificationIds;
import com.tencent.weigou.util.http.JSONGetter;

/**
 * 
 * @ClassName： RecomModel
 *
 * @Description： 推荐关注Model
 * @author wamiwen
 * @date 2013-12-10 下午4:05:00
 *
 */
public class RecomModel extends Model {
	public static final int INIT_DATA = 0;
	public static final int BATCH_ADD_SUBSCRIBE = 112;
	
	public static final int BATCH_SUBSCRIBE_SUCCESS = 222;
	public static final int BATCH_SUBSCRIBE_FAILURE = 223;
	
	private RecomVo recomVo;
	
	private BatchSubscribeAsyncTask batchSubscribeAsyncTask;
	
	@Override
	public void initData(String url) {
		super.initData(url);
		recomVo = new RecomVo();
		
		createNetWorkTask(url, recomVo, INIT_DATA);
	}
	
	public RecomVo getRecomVo() {
		return recomVo;
	}
	
	public void submitFollows(final String url) {
		if (batchSubscribeAsyncTask != null && batchSubscribeAsyncTask.getStatus() != AsyncTask.Status.FINISHED) {
			return;
		}
		batchSubscribeAsyncTask = new BatchSubscribeAsyncTask(url, new CommonVo(), BATCH_ADD_SUBSCRIBE);
		batchSubscribeAsyncTask.execute();
		addList(batchSubscribeAsyncTask);
	}
	
	/**
	 * 
	 * @ClassName： BatchSubscribeAsyncTask
	 *
	 * @Description： 批量增加关注异步任务
	 * @author wamiwen
	 * @date 2013-12-12 下午4:39:37
	 *
	 */
	protected class BatchSubscribeAsyncTask extends GetNetWorkDataTask {

		public BatchSubscribeAsyncTask(String url, CommonVo cv,
				int notificationId) {
			super(url, cv, notificationId);
		}

		@Override
		protected CommonVo doInBackground(Object... arg0) {
			try {
				getter = new JSONGetter(false);
				JsonResult jr = getter.doGet(url);
				if (jr != null && jr.isSuccess()) {
					cv.setNotificationId(BATCH_SUBSCRIBE_SUCCESS);
				} else {
					cv.setNotificationId(BATCH_SUBSCRIBE_FAILURE);
				}
				return cv;
			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}

		@Override
		public void onPostExecute(CommonVo vo) {
			if (isShowProgressBar) {
				RecomModel.this.notify(NotificationIds.DISMISS_PROGRESS_DIALOG);
			}
			if (vo != null) {
				RecomModel.this.notify(vo.getNotificationId());
			}
		}
		
	}

}
