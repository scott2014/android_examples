package com.tencent.weigou.common.ui.draggable;

/**
 * OverScrollView的状态变更监听器
 * User: ethonchan
 * Date: 13-12-17
 * Time: 上午11:38
 */
public interface ScrollStateListener {
    /**
     * 对应的OverScrollView
     *
     * @param view
     * @param oldState 旧状态
     * @param newState 新状态
     */
    public void onStateChanged(OverScrollView view, OverScrollView.State oldState, OverScrollView.State newState);
}
