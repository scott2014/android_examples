package com.tencent.weigou.common.ui;

import com.tencent.weigou.util.Util;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.ImageView;

/**
 *
 * 按原始比例自适应缩放图片，以宽度为基准，缩放高度
 *
 * @author branjing
 *
 */
public class AdaptiveImageView extends ImageView {

	private boolean isWidthFirst = true;

	private boolean needCircleBorder = false;

    private boolean drawRectBorder = false;

	private int viewWidth = 0;
	private int viewHeight = 0;

	private Paint paint = new Paint();

	public AdaptiveImageView(Context context) {
		super(context);
	}

	public AdaptiveImageView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public AdaptiveImageView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	/**
	 *
	 * @Title: setWidthFirst
	 * @Description: isWidthFirst is true that is fixed width but variable height,
	 *          otherwise fixed height but variable width
	 * @param @param isWidthFirst    设定文件
	 * @return void    返回类型
	 * @throws
	 */
	public void setWidthFirst(boolean isWidthFirst) {
		this.isWidthFirst = isWidthFirst;
	}

	public void setDrawCircleBorder(boolean needCircleBorder) {
		this.needCircleBorder = needCircleBorder;
        this.drawRectBorder = false;
        invalidate();
	}

    public void setDrawRectBorder(boolean drawRectBorder){
        this.drawRectBorder = drawRectBorder;
        needCircleBorder = false;
        invalidate();
    }

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		Drawable drawable = getDrawable();

		if (drawable != null) {
			int width = drawable.getIntrinsicWidth();
			int height = drawable.getIntrinsicHeight();
			if (width > 0 && height > 0) {
				if(isWidthFirst) {
					viewWidth = MeasureSpec.getSize(widthMeasureSpec);
					viewHeight = viewWidth * height / width;
				}
				else {
					viewHeight = MeasureSpec.getSize(heightMeasureSpec);
					viewWidth = viewHeight * width / height;
				}
				setMeasuredDimension(viewWidth, viewHeight);
			} else {
				super.onMeasure(widthMeasureSpec, heightMeasureSpec);
			}
		} else {
			super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		}
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		if (viewHeight == viewWidth) {
			canvas.drawColor(Color.TRANSPARENT);
			paint.setAntiAlias(true);
			paint.setColor(Color.parseColor("#eaeaea"));
			paint.setStyle(Paint.Style.STROKE);
			paint.setStrokeWidth(Util.dip2px(getContext(), 1));
            if(needCircleBorder){
			    canvas.drawCircle((viewWidth - getPaddingLeft() - getPaddingRight() ) / 2 + getPaddingLeft(),
                        (viewHeight - getPaddingTop() - getPaddingBottom()) / 2 + getPaddingTop(), (viewWidth - getPaddingLeft() - getPaddingRight() ) / 2 - Util.dip2px(getContext(), 0.3f), paint);
            }else if(drawRectBorder){
                /**
                 * if rectangle is located in incorrect pos unexpectantly, try adding padding.
                 */
                canvas.drawRect(0, 0, viewWidth-1, viewHeight-1, paint);
            }
		}
	}

}