package com.tencent.weigou.common.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import com.tencent.weigou.util.Util;

/**
 * 高宽比固定、child等分的viewGroup(偶数个child分两行)
 * User: ethonchan
 * Date: 13-12-13
 * Time: 上午10:02
 */
public class TwoRowItemView extends FrameLayout {

    private int gapBetweenItem = Util.dip2px(getContext(), 3);

    public TwoRowItemView(Context context) {
        super(context);
    }

    public TwoRowItemView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        final int childCount = getChildCount();
        if (childCount < 2) {
            super.onLayout(changed, left, top, right, bottom);
        } else {
            int width = right - left - getPaddingLeft() - getPaddingRight();
            int height = bottom - top - getPaddingTop() - getPaddingBottom();
            final int rowChildCount = childCount / 2;

            int gapTotalWidth = gapBetweenItem * (rowChildCount - 1);

            //  单个元素的宽度
            final int itemWidth = (width - gapTotalWidth) / rowChildCount;
            //  单个元素的高度
            final int itemHeight = height / 2;
            final int widthSpec = MeasureSpec.makeMeasureSpec(itemWidth, MeasureSpec.EXACTLY);
            final int heightSpec = MeasureSpec.makeMeasureSpec(itemHeight, MeasureSpec.EXACTLY);

            for (int rowIndex = 0; rowIndex < 2; rowIndex++) {
                //  本行第一个商品的left
                int itemLeft = getPaddingLeft();
                //  本行第一个商品的index
                int rowFirst = rowIndex * rowChildCount;
                int rowTop = rowIndex * itemHeight;
                int rowBottom = rowTop + itemHeight;

                for (int columnIndex = 0; columnIndex < rowChildCount; columnIndex++) {
                    View view = getChildAt(rowFirst + columnIndex);
                    int itemRight = itemLeft + itemWidth;
                    view.measure(widthSpec, heightSpec);
                    view.layout(itemLeft, rowTop, itemRight, rowBottom);
                    itemLeft = itemRight + gapBetweenItem;
                }
            }
        }
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int height = (int) (width * 1.192);
        setMeasuredDimension(width, height);
    }
}
