package com.tencent.weigou.common.ui;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.tencent.weigou.R;
import com.tencent.weigou.discovery.activity.DiscoveryActivity;
import com.tencent.weigou.feeds.activity.FeedListActivity;
import com.tencent.weigou.my.activity.MyActivity;
import com.tencent.weigou.shopping.activity.ShoppingIndexActivity;

/**
 * 底部的Tab工具条, 用于选择首页,类目等
 * 
 * @author rickwang
 */
public class BottomBar extends LinearLayout implements OnClickListener {

	protected View[] btns = new View[4];

	public static String curr = "";

	// 是否有新Feeds
	private boolean hasNewFeeds = false;

	public BottomBar(Context context) {
		super(context);
		init(context, null);
	}

	public BottomBar(Context context, AttributeSet attrs) {
		super(context, attrs);
		init(context, attrs);
	}

	protected void init(Context context, AttributeSet attrs) {
		LayoutInflater.from(context).inflate(R.layout.bottombar_layout, this);
		setOrientation(HORIZONTAL);
		setBackgroundResource(R.drawable.bottom_bg);
		setPadding(0, 5, 0, 0);

		// 初始化按钮
		initButtons();
	}

	protected void switchMainActivity(int tabIndex) {
		Class<?> forward = null;
		if (tabIndex == 0) {
			forward = ShoppingIndexActivity.class;
		} else if (tabIndex == 1) {
			forward = FeedListActivity.class;
		} else if (tabIndex == 2) {
			forward = DiscoveryActivity.class;
		} else if (tabIndex == 3) {
			forward = MyActivity.class;
		}

		if (forward != null) {
			Context ctx = getContext();
			Intent intent = new Intent(ctx, forward);
			intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
			Activity activity = (Activity) ctx;
			ctx.startActivity(intent);
			activity.overridePendingTransition(android.R.anim.fade_in,
					android.R.anim.fade_out);
		}

	}

	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.bottom_bar_shopping:
			// setSelect(0);
			switchMainActivity(0);
			break;

		case R.id.bottom_bar_dynamic:
			// setSelect(1);
			switchMainActivity(1);
			break;

		case R.id.bottom_bar_discovery:
			// setSelect(2);
			switchMainActivity(2);
			break;
		case R.id.bottom_bar_my:
			// setSelect(3);
			switchMainActivity(3);
			break;
		}
	}

	protected void initButtons() {
		View shopping = findViewById(R.id.bottom_bar_shopping);
		btns[0] = shopping;

		View feed = findViewById(R.id.bottom_bar_dynamic);
		btns[1] = feed;

		View discovery = findViewById(R.id.bottom_bar_discovery);
		btns[2] = discovery;

		View my = findViewById(R.id.bottom_bar_my);
		btns[3] = my;

		for (View v : btns) {
			v.setOnClickListener(this);
		}

	}

	/**
	 * 设置选中的Button
	 * 
	 * @param index
	 *            选中的Button序号,从0开始
	 */
	public void setSelect(int index) {
		if (index >= 0 && index < btns.length) {
			for (int i = 0; i < btns.length; i++) {
				if (i != index) {
					btns[i].setSelected(false);
					int paddingTop = btns[i].getPaddingTop();
					int paddingLeft = btns[i].getPaddingLeft();
					int paddingBottom = btns[i].getPaddingBottom();
					int paddingRight = btns[i].getPaddingRight();
					btns[i].setBackgroundResource(0);
					btns[i].setPadding(paddingLeft, paddingTop, paddingRight,
							paddingBottom);
				} else {
					btns[i].setSelected(true);
					int paddingTop = btns[i].getPaddingTop();
					int paddingLeft = btns[i].getPaddingLeft();
					int paddingBottom = btns[i].getPaddingBottom();
					int paddingRight = btns[i].getPaddingRight();
					btns[i].setBackgroundResource(R.drawable.bottom_bg_active);
					btns[i].setPadding(paddingLeft, paddingTop, paddingRight,
							paddingBottom);
				}
			}
		}
	}

	/**
	 * 有新Feeds
	 */
	public void onHasNewFeeds() {
		if (!hasNewFeeds) {
			TextView feedView = (TextView) btns[1];
			Drawable newFeedsDrawable = getResources().getDrawable(
					R.drawable.feed_new_selector);
			feedView.setCompoundDrawablesWithIntrinsicBounds(null,
					newFeedsDrawable, null, null);
			hasNewFeeds = true;
		}
	}

	/**
	 * 无新Feeds
	 */
	public void onNoNewFeeds() {
		if (hasNewFeeds) {
			TextView feedView = (TextView) btns[1];
			Drawable noFeedsDrawable = getResources().getDrawable(
					R.drawable.feed_selector);
			feedView.setCompoundDrawablesWithIntrinsicBounds(null,
					noFeedsDrawable, null, null);
			hasNewFeeds = false;
		}
	}
}
