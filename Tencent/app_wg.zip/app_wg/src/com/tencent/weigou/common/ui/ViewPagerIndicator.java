package com.tencent.weigou.common.ui;

import com.tencent.weigou.R;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ImageView.ScaleType;

/**
 * 
 * @ClassName： ViewPagerIndicator
 *
 * @Description： 自定义的ViewPager 指示条
 * @author wamiwen
 * @date 2013-11-26 下午2:53:34
 *
 */
public class ViewPagerIndicator extends LinearLayout {
	
	/**
	 * 指示器条目数量
	 */
	private int indicatorSize;
	
	/**
	 * 选中态指示条显示图片资源
	 */
	private int select;
	
	/**
	 * 非选中态指示条显示图片资源
	 */
	private int unselect;
	
	/**
	 * 指示条View
	 */
	private ImageView indicatorView;
	
	/**
	 * 指示条宽度
	 */
	private int indicatorWidth;
	
	/**
	 * 指示条高度
	 */
	private int indicatorHeight;
	
	
	/**
	 * 构造一个ViewPaer 指示器
	 * 
	 * @param context
	 */
	public ViewPagerIndicator(Context context) {
		this(context, null);
	}
	
	/**
	 * 构造一个ViewPager 指示器 
	 * 
	 * @param context
	 * @param attrs
	 */
	public ViewPagerIndicator(Context context, AttributeSet attrs) {
		super(context, attrs);
		setOrientation(LinearLayout.HORIZONTAL);
		
		select = R.drawable.discovery_viewpager_select;
		unselect = R.drawable.discovery_viewpager_unselect;
	}
	
	/**
	 * 
	 * @Title: setIndicatorHeight
	 *
	 * @Description: 设置指示条的高度
	 * @param @param indicatorHeight  设定文件
	 * @return void  返回类型
	 * @throws
	 */
	public void setIndicatorHeight(int indicatorHeight) {
		this.indicatorHeight = indicatorHeight;
	}

	/**
	 * 
	 * @Title: setIndicatorSize
	 *
	 * @Description: 设置指示条的数目
	 * @param @param size  设定文件
	 * @return void  返回类型
	 * @throws
	 */
	public void setIndicatorSize(final int size) {
		if (size <= 0) {
			return;
		}
		indicatorSize = size;
		indicatorWidth = (int)Math.ceil((double)this.getWidth() / size);
		this.setBackgroundResource(unselect);
		
		indicatorView = new ImageView(getContext());
		
		LinearLayout.LayoutParams params;
		if (indicatorHeight == 0) {
			params = new LinearLayout.LayoutParams(indicatorWidth, LayoutParams.WRAP_CONTENT);
		} else {
			params = new LinearLayout.LayoutParams(indicatorWidth, indicatorHeight);
		}
		
		indicatorView.setLayoutParams(params);
		indicatorView.setScaleType(ScaleType.FIT_XY);
		indicatorView.setImageResource(select);
		
		addView(indicatorView);
	}
	
	/**
	 * 
	 * @Title: scrollToSelectIndicator
	 *
	 * @Description: 指示条跟着ViewPager滑动
	 * @param @param position
	 * @param @param offset  设定文件
	 * @return void  返回类型
	 * @throws
	 */
	public void scrollToSelectIndicator(final int position, final float offset) {
        if (position < 0 || position >= indicatorSize) {
			return;
		}
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams)indicatorView.getLayoutParams();
		params.leftMargin = indicatorWidth * position + (int)(indicatorWidth * offset);
		
		indicatorView.setLayoutParams(params);
	}

	/**
	 * 
	 * @Title: setIndicatorDrawables
	 *
	 * @Description: 设置指示器选中和非选中态的图片资源
	 * @param @param select 选中态图片资源
	 * @param @param unselect  非选中态图片资源
	 * @return void  返回类型
	 * @throws
	 */
	public void setIndicatorDrawables(int select, int unselect) {
		if (select > 0) {
			this.select = select;
		}
		if (unselect > 0) {
			this.unselect = unselect;
		}
	}
}
