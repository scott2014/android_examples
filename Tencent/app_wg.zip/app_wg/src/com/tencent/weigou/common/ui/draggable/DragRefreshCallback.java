package com.tencent.weigou.common.ui.draggable;

import android.view.View;

/**
 * User: ethonchan
 * Date: 13-10-30
 * Time: 下午3:02
 */
public abstract class DragRefreshCallback {
    /**
     * ListView拉出了足够的距离，松开就可以刷新了
     *
     * @param view 当前操作的view（ListView的footer或者header）
     */
    public void onReadyToRefresh(View view) {

    }

    /**
     * ListView从onReadyToRefresh状态扭转到了初始状态，刷新动作取消
     *
     * @param view 当前操作的view（ListView的footer或者header）
     */
    public void onCancelRefresh(View view) {

    }

    /**
     * ListView到达onReadyToRefresh状态后，松开刷新。触发刷新动作
     *
     * @param view 当前操作的view（ListView的footer或者header）
     */
    public void onRefresh(View view) {

    }
}
