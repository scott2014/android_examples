package com.tencent.weigou.common.ui.refresh;

/**
 * User: ethonchan
 * Date: 13-11-1
 * Time: 下午3:23
 */
public class RefreshMessage {
    public int what;
    public Object obj;
}
