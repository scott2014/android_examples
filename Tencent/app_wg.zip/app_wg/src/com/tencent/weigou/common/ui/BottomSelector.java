package com.tencent.weigou.common.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout;

public class BottomSelector extends LinearLayout {
	public BottomSelector(Context context) {
		super(context);
	}

	public BottomSelector(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

}
