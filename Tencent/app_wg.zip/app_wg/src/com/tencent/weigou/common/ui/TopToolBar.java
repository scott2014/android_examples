package com.tencent.weigou.common.ui;

import android.content.Context;
import android.text.Html;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.tencent.weigou.R;

/**
 * 标题栏，结构如下 ----------------------------------------------------------- backBtn
 * title rightBtnB rightBtnA
 * -----------------------------------------------------------
 * 
 * @author jonathanqi
 * @modified ethonchan
 */
public class TopToolBar extends RelativeLayout {

	// 标题
	private TextView titleView;

	// 副标题
	private TextView subTitleView;

	private TextView mBackView;

	private TextView mRightBtnA;

	private TextView mRightBtnB;

	// 默认标题栏颜色
	// public final static int DEFAULT_TOP_BAR_BG = Color.rgb(255, 255, 255);

	public TopToolBar(Context context, AttributeSet attrs) {
		super(context, attrs);
		init(context, attrs);
	}

	private void init(Context context, AttributeSet attrs) {
		LayoutInflater.from(context).inflate(R.layout.top_bar_layout, this);
		// setBackgroundColor(DEFAULT_TOP_BAR_BG);
		setBackgroundResource(R.drawable.top_bar_bg);

		titleView = (TextView) findViewById(R.id.top_bar_title);
		subTitleView = (TextView) findViewById(R.id.top_bar_subtitle);
		mBackView = (TextView) findViewById(R.id.top_bar_back_tv);

		mRightBtnA = (TextView) findViewById(R.id.top_bar_right_1_tv);
		mRightBtnB = (TextView) findViewById(R.id.top_bar_right_2_tv);
	}

	/**
	 * 初始化标题
	 * 
	 * @param title
	 *            标题文字
	 * @return 标题view
	 */
	public TextView initTitle(CharSequence title) {
		return initTitle(title, null);
	}

	/**
	 * 初始化标题
	 * 
	 * @param titleResId
	 *            标题文字
	 * @return 标题view
	 */
	public TextView initTitle(int titleResId) {
		return initTitle(titleResId, null);
	}

	/**
	 * 初始化标题
	 * 
	 * @param titleResId
	 * @param clickListener
	 *            标题点击事件
	 * @return
	 */
	public TextView initTitle(int titleResId, OnClickListener clickListener) {
		if (titleView != null) {
			titleView.setText(titleResId);
			titleView.setOnClickListener(clickListener);
		}
		return titleView;
	}

	/**
	 * 初始化标题
	 * 
	 * @param title
	 * @param clickListener
	 *            标题点击事件
	 * @return
	 */
	public TextView initTitle(CharSequence title, OnClickListener clickListener) {
		if (titleView != null) {
			if (title != null) {
				titleView.setText(Html.fromHtml((String) title));
			}
			titleView.setOnClickListener(clickListener);
		}
		return titleView;
	}

	/**
	 * 初始化副标题
	 * 
	 * @param subTitle
	 * @param clickListener
	 * @return
	 */
	public TextView initSubTitle(CharSequence subTitle,
			OnClickListener clickListener) {
		if (subTitleView != null) {
			subTitleView.setVisibility(View.VISIBLE);
			subTitleView.setText(subTitle);
			subTitleView.setOnClickListener(clickListener);
		}
		return subTitleView;
	}

	/**
	 * 初始化返回按钮
	 * 
	 * @param backImgId
	 *            返回按钮图片，无图片请设置为0
	 * @param listener
	 *            返回按钮点击监听器
	 * @return 返回view
	 */
	public TextView initBackBtn(int backImgId, OnClickListener listener) {
		if (mBackView != null) {
			mBackView.setVisibility(View.VISIBLE);
			if (backImgId > 0) {
				mBackView.setBackgroundResource(backImgId);
			}
			mBackView.setOnClickListener(listener);
		}
		return mBackView;
	}

	/**
	 * 初始化右侧按钮A（即从右侧数的第一个按钮）
	 * 
	 * @param bgId
	 *            按钮的背景图片ID
	 * @param text
	 *            按钮上显示的文字
	 * @param listener
	 *            按钮点击监听器
	 * @return 按钮对象
	 */
	public TextView initRightBtnA(int bgId, CharSequence text,
			OnClickListener listener) {
		if (mRightBtnA != null) {
			mRightBtnA.setVisibility(View.VISIBLE);
			if (bgId > 0) {
				mRightBtnA.setBackgroundResource(bgId);
			}
			mRightBtnA.setText(text);
			mRightBtnA.setOnClickListener(listener);
		}
		return mRightBtnA;
	}

	/**
	 * 初始化右侧按钮B（即从右侧数的第二个按钮）
	 * 
	 * @param bgId
	 *            按钮的背景图片ID
	 * @param text
	 *            按钮上显示的文字
	 * @param listener
	 *            按钮点击监听器
	 * @return 按钮对象
	 */
	public TextView initRightBtnB(int bgId, CharSequence text,
			OnClickListener listener) {
		if (mRightBtnB != null) {
			mRightBtnB.setVisibility(View.VISIBLE);
			if (bgId > 0) {
				mRightBtnB.setBackgroundResource(bgId);
			}
			mRightBtnB.setText(text);
			mRightBtnB.setOnClickListener(listener);
		}
		return mRightBtnB;
	}

}
