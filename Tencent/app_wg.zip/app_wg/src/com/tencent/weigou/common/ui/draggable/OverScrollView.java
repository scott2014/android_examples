package com.tencent.weigou.common.ui.draggable;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import com.tencent.weigou.R;

/**
 * OverScrollView，用于ScrollRefreshListView的header和footer位置，本身就有根据高度变更状态属性的能力
 * User: ethonchan
 * Date: 13-12-17
 * Time: 上午10:35
 */
public class OverScrollView extends FrameLayout {
    //  是否为header
    private boolean mIsHeader = false;

    //  内容的原始高度
    protected int mContentHeight = 0;

    //  内容的可见高度
    protected int mVisibleHeight = 0;

    //  内容view
    protected View mContentView = null;

    //  当前状态
    protected State mCurState = State.NORMAL;

    //  刷新监听器
    protected ScrollStateListener mListener = null;

    public OverScrollView(Context context, boolean isHeader) {
        super(context);
        initView(context, isHeader);
    }

    protected void initView(Context context, boolean isHeader) {
        LayoutInflater inflater = LayoutInflater.from(context);
        inflater.inflate(R.layout.list_loading, this);

        mIsHeader = isHeader;
        mContentView = findViewById(R.id.loading_layout);

        Holder holder = new Holder();
        holder.tipsView = (TextView) mContentView.findViewById(R.id.loading_tips);
        holder.arrowView = (ImageView) mContentView.findViewById(R.id.loading_arrow);
        holder.timeView = (TextView) mContentView.findViewById(R.id.loading_time);
        holder.progressView = mContentView.findViewById(R.id.loading_progress);
        setTag(holder);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        mContentView.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED);
        mContentHeight = mContentView.getMeasuredHeight();

        int width = MeasureSpec.getSize(widthMeasureSpec);
        setMeasuredDimension(width, mVisibleHeight);
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        int width = right - left;
        int height = bottom - top;

        top = mIsHeader ? height - mContentHeight : 0;
        int widthSpec = MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY);
        int heightSpec = MeasureSpec.makeMeasureSpec(mContentHeight, MeasureSpec.EXACTLY);
        mContentView.measure(widthSpec, heightSpec);

        mContentView.layout(0, top, width, height);
    }

    /**
     * 设置OverScrollView的可见高度。
     *
     * @param newHeight 新的可见高度
     */
    public void setVisibleHeight(int newHeight) {
        newHeight = newHeight > 0 ? newHeight : 0;

        if (mCurState == State.NORMAL) {
            mVisibleHeight = newHeight;
            if (newHeight >= mContentHeight)
            //  NORMAL -> READY_TO_REFRESH
            {
                mCurState = State.READY_TO_REFRESH;
                if (mListener != null) {
                    mListener.onStateChanged(this, State.NORMAL, State.READY_TO_REFRESH);
                }
            }
        } else if (mCurState == State.READY_TO_REFRESH) {
            mVisibleHeight = newHeight;
            if (newHeight < mContentHeight)
            //  READY_TO_REFRESH -> NORMAL
            {
                mCurState = State.NORMAL;
                if (mListener != null) {
                    mListener.onStateChanged(this, State.READY_TO_REFRESH, State.NORMAL);
                }
            }
        } else if (mCurState == State.REFRESHING) {
            mVisibleHeight = mContentHeight + newHeight;
        }

        requestLayout();
    }

    /**
     * 重置
     */
    public void reset() {
        if (mCurState == State.REFRESHING)
        //  REFRESHING -> NORMAL
        {
            if (mListener != null) {
                mListener.onStateChanged(this, State.REFRESHING, State.NORMAL);
            }
        } else if (mCurState == State.READY_TO_REFRESH)
        //  READY_TO_REFRESH -> NORMAL
        {
            if (mListener != null) {
                mListener.onStateChanged(this, State.READY_TO_REFRESH, State.NORMAL);
            }
        }

        mCurState = State.NORMAL;
        mVisibleHeight = 0;
    }

    /**
     * 手指松开
     */
    public void onFingerUp() {
        if (mCurState == State.READY_TO_REFRESH)
        //  READY_TO_REFRESH -> REFRESHING
        {
            mVisibleHeight = mContentHeight;
            mCurState = State.REFRESHING;

            if (mListener != null) {
                mListener.onStateChanged(this, State.READY_TO_REFRESH, State.REFRESHING);
            }
        } else if (mCurState == State.REFRESHING)
        //  REFRESHING -> REFRESHING
        {
            mVisibleHeight = mContentHeight;
        } else
        //  NORMAL -> NORMAL
        {
            mVisibleHeight = 0;
        }
        requestLayout();
    }

    /**
     * 设置刷新事件监听器
     *
     * @param listener
     */
    public void setScrollRefreshListener(ScrollStateListener listener) {
        this.mListener = listener;
    }

    /**
     * 是否为header
     *
     * @return
     */
    public boolean isHeader() {
        return mIsHeader;
    }

    /**
     * OverScrollView的四种状态
     */
    public enum State {
        NORMAL, READY_TO_REFRESH, REFRESHING
    }

    /**
     * 组成OverScrollView的部件集合
     */
    public static class Holder {
        //  提示语
        public TextView tipsView;

        //  刷新时间
        public TextView timeView;

        //  箭头
        public ImageView arrowView;

        //  菊花转
        public View progressView;
    }
}
