package com.tencent.weigou.common.ui;

import android.app.AlertDialog;
import android.content.Context;
import android.util.Log;
import com.tencent.weigou.R;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * 支持2种类型的AlertDialog：只有1个按钮的消息通知型，有2个按钮的选择型
 *
 * @author rickwang
 */
public class CustomAlertDialog extends AlertDialog {
    //  是否可取消
    protected boolean cancellable = true;

    public CustomAlertDialog(Context context) {
        super(context, R.style.WeigouAlertDialog);
    }

    public CustomAlertDialog(Context context, int theme) {
        super(context, theme);
    }

    public CustomAlertDialog(Context context, boolean cancelable,
                             OnCancelListener cancelListener) {
        super(context, cancelable, cancelListener);
    }

    @Override
    public void setTitle(CharSequence title) {
        // 改变对话框title时不希望修改window的title
        // 使用反射方法获取AlertDialog的AlertController对象
        if (title == null) {
            title = "";
        }
        try {
            Field field = AlertDialog.class.getDeclaredField("mAlert");
            field.setAccessible(true);
            Object mAlert = field.get(this);
            Method method = mAlert.getClass().getMethod("setTitle",
                    CharSequence.class);
            method.invoke(mAlert, title);
        } catch (Exception e) {
            Log.e("CustomAlertDialog", "setTitle exception", e);
            super.setTitle(title);
        }
    }

    @Override
    public void onBackPressed() {
        if (cancellable) {
            super.onBackPressed();
        }
    }

    /**
     * 设置对话框是否为可取消的对话框
     *
     * @param cancellable true可取消，false不可取消
     */
    public void setCancellable(boolean cancellable) {
        this.cancellable = cancellable;
        setCanceledOnTouchOutside(cancellable);
    }
}
