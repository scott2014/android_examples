package com.tencent.weigou.common.ui;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import com.tencent.weigou.R;

/**
 * 请稍候对话框
 * User: ethonchan
 * Date: 13-12-13
 * Time: 下午6:27
 */
public class CustomProgressDialog extends ProgressDialog {

    public CustomProgressDialog(Context context) {
        super(context);
    }

    public CustomProgressDialog(Context context, int theme) {
        super(context, theme);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.progress_layout);
    }
}
