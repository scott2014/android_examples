package com.tencent.weigou.common.ui;

/**
 * Refreshable对象的状态变更监听器
 * 
 * @author ethonchan
 * 
 */
public interface OnRefreshListener {

	/**
	 * 刷新中
	 * 
	 * @param curPageInfo
	 */
	public void onRefreshing(PageInfo curPageInfo);

}
