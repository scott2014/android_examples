package com.tencent.weigou.common.ui;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.ImageView;

/**
 * 
 * 按原始比例自适应缩放图片，以宽度为基准，缩放高度
 * 
 * @author branjing
 * 
 */
public class ScaleImageView extends ImageView {

	public ScaleImageView(Context context) {
		super(context);
	}

	public ScaleImageView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public ScaleImageView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	/**
	 * 
	 * @Title: setWidthFirst
	 * @Description: isWidthFirst is true that is fixed width but variable
	 *               height, otherwise fixed height but variable width
	 * @param @param isWidthFirst 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	private float scale = 1;

	public void setScale(float scale) {
		this.scale = scale;
	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		Drawable drawable = getDrawable();

		if (drawable != null) {
			int width = drawable.getIntrinsicWidth();
			int height = drawable.getIntrinsicHeight();
			if (width > 0 && height > 0) {
				int viewWidth = 0;
				int viewHeight = 0;
				viewWidth = MeasureSpec.getSize(widthMeasureSpec);
				viewHeight = Math.round(viewWidth / scale);
				setMeasuredDimension(viewWidth, viewHeight);
			} else {
				super.onMeasure(widthMeasureSpec, heightMeasureSpec);
			}
		} else {
			super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		}
	}

}