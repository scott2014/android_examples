package com.tencent.weigou.common.ui;

import android.app.Dialog;
import android.content.Context;
import com.tencent.weigou.R;

/**
 * User: ethonchan
 * Date: 13-12-9
 * Time: 下午2:52
 */
public class DialogBuilder {

    public final static int DIALOG_YES_NO = 1;

    public DialogBuilder(Context context, int dialogType) {
        this.context = context;
        this.dialogType = dialogType;
    }

    private Context context;

    private int dialogType = DIALOG_YES_NO;

    private int msgId;

    private int okId;

    private int cancelId;

    private int imageResId;

    public Dialog create() {
        Dialog dialog = new Dialog(context, R.style.WeigouAlertDialog);
        dialog.setContentView(R.layout.dialog_layout);
        return dialog;
    }

    public int getMsgId() {
        return msgId;
    }

    public void setMsgId(int msgId) {
        this.msgId = msgId;
    }

    public int getOkId() {
        return okId;
    }

    public void setOkId(int okId) {
        this.okId = okId;
    }

    public int getCancelId() {
        return cancelId;
    }

    public void setCancelId(int cancelId) {
        this.cancelId = cancelId;
    }

    public int getImageResId() {
        return imageResId;
    }

    public void setImageResId(int imageResId) {
        this.imageResId = imageResId;
    }
}
