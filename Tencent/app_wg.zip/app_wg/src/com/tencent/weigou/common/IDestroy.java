package com.tencent.weigou.common;

/**
 * 取消接口
 * 
 * @author wendyhu
 * 
 */
public interface IDestroy {

	/**
	 * 销毁操作
	 */
	public void destroy();
}
