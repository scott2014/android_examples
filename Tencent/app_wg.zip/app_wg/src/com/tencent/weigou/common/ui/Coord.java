package com.tencent.weigou.common.ui;

/**
 * 坐标
 * User: ethonchan
 * Date: 13-10-30
 * Time: 下午3:04
 */
public class Coord {
    //坐标X
    private double x = 0;

    //坐标Y
    private double y = 0;

    public Coord(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    @Override
    public String toString() {
        return "[" + x + "," + y + "]";
    }
}
