package com.tencent.weigou.common.ui;

public class MallItem {

}
