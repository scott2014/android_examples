package com.tencent.weigou.common.ui;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.ImageView;
import com.tencent.weigou.R;

/**
 * 宽高比固定的ImageView
 * User: ethonchan
 * Date: 13-12-4
 * Time: 下午5:32
 */
public class StableImageView extends ImageView {
    protected float heightWidthRatio = -1F;


    public StableImageView(Context context) {
        super(context);
    }

    public StableImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    public StableImageView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(context, attrs);
    }

    protected void init(Context context, AttributeSet attrs) {
        if (context != null) {
            TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.StableImageView);
            if (typedArray != null) {
                heightWidthRatio = typedArray.getFloat(R.styleable.StableImageView_widthHeightRatio, -1f);
                typedArray.recycle();
            }
        }
    }

    /**
     * 设置ImageView的高宽比
     * @param newHeightWidthRatio
     */
    public void setHeightWidthRatio(float newHeightWidthRatio) {
        this.heightWidthRatio = newHeightWidthRatio;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        if (heightWidthRatio > 0) {
            int width = MeasureSpec.getSize(widthMeasureSpec);
            int height = (int) (width * heightWidthRatio);
            setMeasuredDimension(width, height);
        }else{
            super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        }
    }
}
