package com.tencent.weigou.common.ui.draggable;

/**
 * 刷新事件监听器
 * User: ethonchan
 * Date: 13-11-1
 * Time: 下午3:31
 */
public interface OnRefreshListener {

    /**
     * 刷新动作的回调
     *
     * @param view 正在刷新的OverScrollView
     * @param obj  要传送的数据对象
     */
    public void onRefreshing(OverScrollView view, Object obj);
}
