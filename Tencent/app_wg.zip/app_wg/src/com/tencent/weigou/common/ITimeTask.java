/**   
 * @Title: ITimeTask.java 
 * @Package com.qq.buy.common.model 
 * @author Wendyhu wendyhu@tencent.com
 * @date 2012-3-2 下午01:47:48 
 * @version V1.0   
 */
package com.tencent.weigou.common;

/**
 * @ClassName: ITimeTask
 * @author wendyhu wendyhu@tencent.com
 * @date 2012-3-2 下午01:47:48
 * 
 */
public interface ITimeTask {
	
	/**
	 * 开始计时动作
	 */
	public void startTimer();

	/**
	 * 重新启动计时动作
	 */
	public void restartTimer();

	/**
	 * 停止计时动作（通过取消未执行的延时任务来实现）
	 */
	public void stopTimer();
}
