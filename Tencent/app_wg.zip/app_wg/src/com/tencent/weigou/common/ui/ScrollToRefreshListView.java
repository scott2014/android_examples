package com.tencent.weigou.common.ui;

import com.tencent.weigou.R;
import com.tencent.weigou.util.Util;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;

/**
 * 可以下拉刷新的一个包含有listview和默认空的view
 * 
 * @author ethonchan
 * 
 */
public class ScrollToRefreshListView extends RelativeLayout implements
		OnScrollListener, OnTouchListener {

	protected final static String TAG = "BaseListActivity";

	private ListView mListView;

	private View mFooter;

	private OnRefreshListener mListener;

	/**
	 * 上一次down事件的坐标，用于辅助判断方向
	 */
	private float mLastDownY;

	/**
	 * 是否朝下方在滑动
	 */
	private boolean isScrollingDown;

	/**
	 * 是否已经滑到了底部
	 */
	private boolean mScrollToEnd;

	/**
	 * 当前页面展示的最新一页的页面信息
	 */
	private PageInfo mLastPageInfo;

	public ScrollToRefreshListView(Context context) {
		this(context, null);
	}

	public ScrollToRefreshListView(Context context, AttributeSet attrs) {
		super(context, attrs);

		mLastPageInfo = new PageInfo();
		mLastDownY = -1;
		mScrollToEnd = false;
		isScrollingDown = false;

		LayoutInflater.from(context).inflate(R.layout.refreshable_list_view,
				this);

		mListView = (ListView) findViewById(R.id.listview_inner);
		mFooter = findViewById(R.id.listview_footer);
		mListView.setOnScrollListener(this);
		mListView.setOnTouchListener(this);
	}

	public void setId(int id) {
		if (mListView != null) {
			mListView.setId(id);
		}
	}

	/**
	 * 重置
	 */
	public void reset() {
		mLastPageInfo = new PageInfo();
		mLastDownY = -1;
		mScrollToEnd = false;
		isScrollingDown = false;
	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		switch (event.getAction()) {
		case MotionEvent.ACTION_DOWN:
			mLastDownY = event.getY();
			isScrollingDown = false;
			break;
		case MotionEvent.ACTION_MOVE:
			if (mLastDownY < 0) {
				mLastDownY = event.getY();
			} else {
				float curY = event.getY();
				isScrollingDown = (curY < mLastDownY);
			}

			break;
		case MotionEvent.ACTION_UP:
			mLastDownY = -1;
			break;
		}
		return false;
	}

	/**
	 * 
	 * @Title: setListDivider
	 * 
	 * @Description: 设置默认的divider
	 * @param @param divider 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	public void setListDivider() {
		if (mListView != null) {
			Resources res = getResources();
			mListView.setDivider(res.getDrawable(R.color.listview_divider));
			mListView.setDividerHeight(Util.dip2px(getContext(), 0.67f));
		}
	}

	/**
	 * 
	 * @Title: setListDivider
	 * 
	 * @Description: Sets the drawable that will be drawn between each item in
	 *               the list
	 * @param @param divider 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	public void setListDivider(Drawable divider) {
		if (mListView != null) {
			mListView.setDivider(divider);
		}
	}

	/**
	 * 
	 * @Title: setDividerHeight
	 * 
	 * @Description: Sets the height of the divider that will be drawn between
	 *               each item in the list
	 * @param @param height 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	public void setDividerHeight(int height) {
		if (mListView != null) {
			mListView.setDividerHeight(height);
		}
	}

	/**
	 * 
	 * @Title: setFooterDividersEnabled
	 * 
	 * @Description: Enables or disables the drawing of the divider for footer
	 *               views
	 * @param @param footerDividersEnabled 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	public void setFooterDividersEnabled(boolean footerDividersEnabled) {
		if (mListView != null) {
			mListView.setFooterDividersEnabled(footerDividersEnabled);
		}
	}

	/**
	 * 
	 * @Title: addHeaderView
	 * 
	 * @Description: Add a fixed view to appear at the top of the list
	 * @param @param v 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	public void addHeaderView(View v) {
		if (mListView != null) {
			mListView.addHeaderView(v);
		}
	}

	public void addFooterView(View v) {
		if (mListView != null) {
			mListView.addFooterView(v);
		}
	}

	public void removeFooterView(View v) {
		if (mListView != null) {
			mListView.removeFooterView(v);
		}
	}

	public ListView getListView() {
		return mListView;
	}

	/**
	 * 更新当前页面信息
	 * 
	 * @param curPageIndex
	 * @param maxPageNum
	 */
	public void updateCurPageInfo(int curPageIndex, int maxPageNum) {
		mLastPageInfo.setPageIndex(curPageIndex);
		mLastPageInfo.setHasNexPage(maxPageNum > curPageIndex);
	}

	/**
	 * 设置是否还有下一页
	 * 
	 * @param curPageIndex
	 *            当前页面index
	 * @param hasNextPage
	 *            true，有；false，没有
	 */
	public void setHasNextPage(int curPageIndex, boolean hasNextPage) {
		mLastPageInfo.setPageIndex(curPageIndex);
		mLastPageInfo.setHasNexPage(hasNextPage);
	}

	/**
	 * 得到当前页面信息
	 * 
	 * @return
	 */
	public PageInfo getLatestPageInfo() {
		return mLastPageInfo;
	}

	/**
	 * 等同于listview.setOnItemClickListener
	 * 
	 * @param listener
	 */
	public void setOnItemClickListener(OnItemClickListener listener) {
		mListView.setOnItemClickListener(listener);
	}

	/**
	 * 
	 * @Title: setOnItemLongClickListener
	 * 
	 * @Description: 等同于ListView.OnItemLongClickListener
	 * @param @param listener 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	public void setOnItemLongClickListener(OnItemLongClickListener listener) {
		mListView.setOnItemLongClickListener(listener);
	}

	/**
	 * 等同于listview.setAdapter
	 * 
	 * @param adapter
	 */
	public void setAdapter(ListAdapter adapter) {
		mListView.setAdapter(adapter);
	}

	/**
	 * 设置刷新监听器。在用户滚动列表触发刷新动作时调用
	 * 
	 * @param listener
	 */
	public void setOnRefreshListener(OnRefreshListener listener) {
		mListener = listener;
	}

	@Override
	public void onScrollStateChanged(AbsListView view, int scrollState) {
		if (scrollState == SCROLL_STATE_TOUCH_SCROLL) {
			if (mScrollToEnd && mLastPageInfo.isHasNexPage() && isScrollingDown)
			// 只在向下滑动时才显示progress
			{
				setFooterVisibility(true);
			}
		} else if (scrollState == SCROLL_STATE_IDLE) {
			if (mFooter.getVisibility() == View.VISIBLE) {
				if (mScrollToEnd && mLastPageInfo.isHasNexPage())
				// 有下一页，获取下一页的数据
				{
					if (mListener != null) {
						mLastPageInfo.setListViewId(this.getId());
						mListener.onRefreshing(mLastPageInfo);
					} else {
						setFooterVisibility(false);
					}
				} else {
					setFooterVisibility(false);
				}
			}
		}
	}

	@Override
	public void onScroll(AbsListView view, int firstVisibleItem,
			int visibleItemCount, int totalItemCount) {
		mScrollToEnd = (firstVisibleItem + visibleItemCount == totalItemCount);
	}

	/**
	 * 刷新动作结束时调用本方法隐藏footer
	 */
	public void onFinishUpdate() {
		setFooterVisibility(false);
	}

	public void finish() {
		onFinishUpdate();
		mListView.setOnScrollListener(null);
		mListView.setOnTouchListener(null);
		Log.e("listview", "finish");
	}

	/**
	 * 设置footer的可见性
	 * 
	 * @param showFooter
	 */
	private void setFooterVisibility(boolean showFooter) {
		if (showFooter)
		// 显示progress
		{
			if (mFooter.getVisibility() != View.VISIBLE) {
				mFooter.setVisibility(View.VISIBLE);
			}
		} else
		// 隐藏progress
		{
			if (mFooter.getVisibility() == View.VISIBLE) {
				mFooter.setVisibility(View.GONE);

			}
		}
	}
}
