package com.tencent.weigou.common.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.RelativeLayout;

import com.tencent.weigou.R;
import com.tencent.weigou.common.IDestroy;
import com.tencent.weigou.common.ITimeTask;
import com.tencent.weigou.util.AsyncImageLoader;
import com.tencent.weigou.util.IImageLoadedCallBack;

/**
 * 
 * @ClassName： AutoScrollViewPagerWithGuide
 * 
 * @Description： 自定义的左右滑动的展示图片的ViewPager 可自由设置是否循环滑动，是否自动轮播，是否带指示点点
 * @author wamiwen
 * @date 2013-10-24 上午10:47:47
 * 
 */
@SuppressLint("HandlerLeak")
public class AutoScrollViewPagerWithGuide extends RelativeLayout implements
		IDestroy, ITimeTask {

	/**
	 * 滚动时间间隔
	 */
	private int scrollIntervalSeconds = 4;

	/**
	 * 上下文
	 */
	private Context context;

	/**
	 * 当前滚动到的编号
	 */
	private int currentNum = 0;

	/**
	 * 是否可自动滚动，默认可以
	 */
	private boolean autoScrollable = true;

	/**
	 * 是否可以循环滑动
	 */
	private boolean circulated = true;

	/**
	 * 是否带指示的点点
	 */
	private boolean withGuide = true;

	/**
	 * ViewPager
	 */
	private ViewPager viewPager;

	/**
	 * 图片指示器
	 */
	private ListGuide guide;

	/**
	 * 图片URL列表
	 */
	private List<String> imageUrlList = new ArrayList<String>();

	/**
	 * 图片 PagerAdapter
	 */
	private ImageViewPagerAdapter adapter;

	/**
	 * 异步加载图片cache
	 */
	private AsyncImageLoader asyncImageLoader = new AsyncImageLoader(true);

	/**
	 * 默认图片
	 */
	private BitmapDrawable defaultDrawable = null;

	private ScheduledExecutorService scheduledExecutorService;

	public AutoScrollViewPagerWithGuide(Context context) {
		this(context, null, 0);
	}

	public AutoScrollViewPagerWithGuide(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public AutoScrollViewPagerWithGuide(Context context, AttributeSet attrs,
			int defStyle) {
		super(context, attrs, defStyle);
		this.context = context;
		init();
	}

	private void init() {
		View view = LayoutInflater.from(context).inflate(
				R.layout.autoscroll_viewpager_layout, this);
		viewPager = (ViewPager) view.findViewById(R.id.autoscroll_viewpager);
		guide = (ListGuide) view.findViewById(R.id.gallery_list_guide);

		initViews();

		setUpListeners();
	}

	/**
	 * 
	 * @Title: initViews
	 * 
	 * @Description: 初始化控件
	 * @param 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	private void initViews() {
		// 从网络加载图片前，先加载默认图片
		imageUrlList.add("");

		// 设置小点的样式，首页专用
		guide.setBackgroundColor(Color.argb(51, 0, 0, 0));
		guide.setGravity(Gravity.CENTER);
		guide.setVisibility(View.INVISIBLE);

		adapter = new ImageViewPagerAdapter();
		viewPager.setAdapter(adapter);
		viewPager.setCurrentItem(0);
	}

	/**
	 * 
	 * @Title: setUpListeners
	 * 
	 * @Description: 初始化空间监听器
	 * @param 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	private void setUpListeners() {
		viewPager.setOnPageChangeListener(new OnPageChangeListener() {

			@Override
			public void onPageSelected(int position) {

			}

			@Override
			public void onPageScrolled(int position, float positionOffset,
					int positionOffsetPixels) {
				if (currentNum != position) {
					currentNum = position;
					guide.setSelectItem(currentNum % imageUrlList.size());
				}

			}

			@Override
			public void onPageScrollStateChanged(int state) {

			}
		});

	}

	/**
	 * 
	 * @Title: setViewPagerOnClickListener
	 * 
	 * @Description: 设置ViewPager OnClick监听器
	 * @param @param l 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	public void setViewPagerOnClickListener(
			GestureDetector.SimpleOnGestureListener listener) {
		final GestureDetector tapGestureDetector = new GestureDetector(context,
				listener);
		viewPager.setOnTouchListener(new OnTouchListener() {
			public boolean onTouch(View v, MotionEvent event) {
				tapGestureDetector.onTouchEvent(event);
				return false;
			}
		});
	}

	/**
	 * 
	 * @Title: setImageUrlList
	 * 
	 * @Description: 设置图片下载链接
	 * @param @param imageUrls 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	public void setImageUrlList(List<String> imageUrls) {
		if (imageUrls != null && imageUrls.size() > 0) {
			/**
			 * reset PagerAdapter
			 */
			imageUrlList.clear();
			imageUrlList.addAll(imageUrls);
			adapter = new ImageViewPagerAdapter();
			viewPager.setAdapter(adapter);

			/**
			 * set List Guide
			 */
			if (withGuide) {
				guide.setListSize(imageUrlList.size());
				guide.setVisibility(View.VISIBLE);
			} else {
				guide.setVisibility(View.GONE);
			}

			/**
			 * set auto scroll
			 */
			if (autoScrollable && adapter.getCount() > 1) {
				startTimer();
			}
		}
	}

	/**
	 * 
	 * @ClassName： ImageViewPagerAdapter
	 * 
	 * @Description： ImageView PagerAdapter
	 * @author wamiwen
	 * @date 2013-10-23 上午10:54:08
	 * 
	 */
	private class ImageViewPagerAdapter extends PagerAdapter {

		@Override
		public int getCount() {
			if (circulated) {
				return Integer.MAX_VALUE;
			} else {
				return imageUrlList.size();
			}
		}

		@Override
		public boolean isViewFromObject(View view, Object obj) {
			return view == obj;
		}

		@Override
		public void destroyItem(View container, int position, Object object) {
			((ViewPager) container).removeView((ImageView) object);
		}

		@Override
		public Object instantiateItem(ViewGroup container, int position) {
			ImageView imageView = new ImageView(context);
			imageView.setScaleType(ScaleType.CENTER_CROP);
			loadImage(imageUrlList.get(position % imageUrlList.size()),
					imageView);
			((ViewPager) container).addView(imageView);
			return imageView;
		}

	}

	@Override
	public void destroy() {
		if (asyncImageLoader != null) {
			asyncImageLoader.destroy();
		}
		stopTimer();
	}

	/**
	 * 
	 * @Title: loadImage
	 * @Description: 异步加载图片
	 * @param @param url
	 * @param @param imageView 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	private void loadImage(final String url, final ImageView imageView) {

		// 异步加载图片
		Bitmap cachedImage = asyncImageLoader.loadDrawable(url, imageView,
				new IImageLoadedCallBack() {
			
					@Override
					public void imageLoaded(final ImageView imageView,
							final Bitmap bitmap, final String imageUrl) {
						if (bitmap != null) {
							imageView.setImageBitmap(bitmap);
						}
					}
					
				});

		if (cachedImage == null) {
			imageView.setImageDrawable(defaultDrawable);
		} else {
			imageView.setImageBitmap(cachedImage);
		}
	}

	@Override
	public boolean onInterceptTouchEvent(MotionEvent ev) {
		if (autoScrollable && adapter != null && adapter.getCount() > 1) {
			switch (ev.getAction()) {
			case MotionEvent.ACTION_DOWN:
				stopTimer();
				break;

			case MotionEvent.ACTION_UP:
				restartTimer();
				break;

			case MotionEvent.ACTION_CANCEL:
				restartTimer();
				break;
			}
		}
		return super.onInterceptTouchEvent(ev);
	}

	/**
	 * 
	 * @Title: setGuideDrawables
	 * 
	 * @Description: 设置表示Guide选中和未选中两种状态的图片
	 * @param @param selectDrawableResId
	 * @param @param unselectDrawableResId 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	public void setGuideDrawables(int selectDrawableResId,
			int unselectDrawableResId) {
		guide.setDrawables(selectDrawableResId, unselectDrawableResId);
	}

	/**
	 * 
	 * @Title: setAutoScrollable
	 * 
	 * @Description: 设置是否自动滚动
	 * @param @param autoScrollable 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	public void setAutoScrollable(boolean autoScrollable) {
		this.autoScrollable = autoScrollable;
		if (adapter != null && adapter.getCount() > 1) {
			if (autoScrollable) {
				restartTimer();
			} else {
				stopTimer();
			}
		}
	}

	/**
	 * 
	 * @Title: setCirculated
	 * 
	 * @Description: 是否循环滚动
	 * @param @param circulated 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	public void setCirculated(boolean circulated) {
		this.circulated = circulated;
	}

	/**
	 * 
	 * @Title: setWithGuide
	 * 
	 * @Description: 是否需要带指示的点点
	 * @param @param withGuide 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	public void setWithGuide(boolean withGuide) {
		this.withGuide = withGuide;
	}

	/**
	 * 
	 * @Title: setDefaultDrawable
	 * 
	 * @Description: 设置默认图片
	 * @param @param defaultDrawable 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	public void setDefaultDrawable(BitmapDrawable defaultDrawable) {
		this.defaultDrawable = defaultDrawable;
	}

	/**
	 * 
	 * @Title: getCurrentNum
	 * 
	 * @Description: 获取当前显示View No.
	 * @param @return 设定文件
	 * @return int 返回类型
	 * @throws
	 */
	public int getCurrentNum() {
		return currentNum % imageUrlList.size();
	}

	/**
	 * 
	 * @Title: setScrollIntervalSeconds
	 * 
	 * @Description: 设置滚动的时间间隔，单位为秒
	 * @param @param scrollIntervalSeconds 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	public void setScrollIntervalSeconds(int scrollIntervalSeconds) {
		this.scrollIntervalSeconds = scrollIntervalSeconds;
		if (autoScrollable && adapter != null && adapter.getCount() > 1) {
			restartTimer();
		}
	}

	private Handler handler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			viewPager.setCurrentItem(currentNum, true);
		}

	};

	/**
	 * 
	 * @ClassName： ViewPagerScrollTask
	 * 
	 * @Description： 实际执行切换图片的线程
	 * @author wamiwen
	 * @date 2013-10-23 下午5:19:30
	 * 
	 */
	private class ViewPagerScrollTask implements Runnable {

		@Override
		public void run() {
			currentNum = currentNum + 1;
			handler.obtainMessage().sendToTarget();
		}

	}

	@Override
	public void startTimer() {
		if (autoScrollable) {
			scheduledExecutorService = Executors
					.newSingleThreadScheduledExecutor();
			scheduledExecutorService.scheduleWithFixedDelay(
					new ViewPagerScrollTask(), scrollIntervalSeconds,
					scrollIntervalSeconds, TimeUnit.SECONDS);
		}
	}

	@Override
	public void restartTimer() {
		stopTimer();
		startTimer();
	}

	@Override
	public void stopTimer() {
		if (scheduledExecutorService != null
				&& !scheduledExecutorService.isShutdown()) {
			scheduledExecutorService.shutdownNow();
		}
	}

}
