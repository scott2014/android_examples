package com.tencent.weigou.common.ui;

/**
 * 页面信息，用于翻页场景中
 * 
 * @author ethonchan
 * 
 */
public class PageInfo {

	private int listViewId;
	/**
	 * 是否有下一页
	 */
	private boolean hasNexPage;

	/**
	 * 当前页面的index
	 */
	private int mPageIndex;

	/**
	 * 默认的pageIndex = 0
	 */
	public PageInfo() {
		hasNexPage = true;
		mPageIndex = 0;
	}

	public int getListViewId() {
		return listViewId;
	}

	public void setListViewId(int listViewId) {
		this.listViewId = listViewId;
	}

	public boolean isHasNexPage() {
		return hasNexPage;
	}

	public void setHasNexPage(boolean hasNexPage) {
		this.hasNexPage = hasNexPage;
	}

	public int getPageIndex() {
		return mPageIndex;
	}

	public void setPageIndex(int pageIndex) {
		this.mPageIndex = pageIndex;
	}

	@Override
	public String toString() {
		return "PageInfo [hasNexPage=" + hasNexPage + ", mPageIndex="
				+ mPageIndex + "]";
	}

}
