package com.tencent.weigou.common.ui;

import android.app.Activity;
import android.content.Context;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.tencent.weigou.R;
import com.tencent.weigou.util.Util;

public class TabTitle extends LinearLayout {
	/* 数据段begin */
	public final static String TAG = "TabTitle";
	private int screenWidth;
	public TextView mallBtn;
	public TextView brandBtn;

	public TabTitle(Context context, AttributeSet attrs) {
		super(context, attrs);
		View view = inflate(context, R.layout.tab_title, this);
		screenWidth = Util.getScreenWidth(((Activity) context)
				.getWindowManager());

		mallBtn = (TextView) view.findViewById(R.id.mall_btn);
		brandBtn = (TextView) view.findViewById(R.id.brand_btn);
		float fontSize = screenWidth / 18;
		mallBtn.setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize);
		brandBtn.setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize);
	}

	@Override
	protected void onLayout(boolean changed, int l, int t, int r, int b) {
		super.onLayout(changed, l, t, r, b);
		if (this.getChildCount() == 2) {
			getChildAt(0).layout(screenWidth / 3, getChildAt(0).getTop(),
					screenWidth / 3 + screenWidth / 9,
					getChildAt(0).getBottom());
			getChildAt(1).layout(screenWidth * 2 / 3 - screenWidth / 9,
					getChildAt(1).getTop(), screenWidth * 2 / 3,
					getChildAt(1).getBottom());
		}
	}
}
