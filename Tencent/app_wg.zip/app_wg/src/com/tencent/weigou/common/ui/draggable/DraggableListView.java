package com.tencent.weigou.common.ui.draggable;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ListAdapter;
import android.widget.ListView;
import com.tencent.weigou.R;
import com.tencent.weigou.common.ui.draggable.OverScrollView.State;

import java.text.SimpleDateFormat;
import java.util.Date;


/**
 * 可拖拽的listView
 * User: ethonchan
 * Date: 13-10-29
 * Time: 上午11:42
 */
public class DraggableListView extends ListView implements ScrollStateListener {
    //  阻力系数，越大滑动时就会感觉阻力越大
    private final static int RATIO = 3;

    private final static int ACTIVE_SIDE_NONE = 0;

    public final static int ACTIVE_SIDE_HEAD = 1;

    public final static int ACTIVE_SIDE_FOOT = 2;

    //  head, foot的提示语
    protected TipsHolder mHeadTips, mFootTips;

    //  头部尾部的view
    protected OverScrollView mHead, mFoot;

    //  按下时的坐标
    private int[] mDownCoord;

    //  当前活动的是哪一边
    private int mActiveSide = ACTIVE_SIDE_NONE;

    //  刷新事件监听器
    private OnRefreshListener mRefreshListener = null;

    public DraggableListView(Context context) {
        super(context);
        init(context, null);
    }

    public DraggableListView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    public DraggableListView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(context, attrs);
    }

    private void init(Context context, AttributeSet attrs) {
        // 去掉分割线
        setDividerHeight(0);

        // 去掉滑动时的黑色背景
        setCacheColorHint(Color.TRANSPARENT);

        // 去掉selector
        setSelector(new ColorDrawable(Color.TRANSPARENT));

        //  是否有head
        boolean hasHead = false;
        if (attrs != null) {
            TypedArray array = context.obtainStyledAttributes(attrs, R.styleable.ScrollRefreshListView);
            hasHead = array.getBoolean(R.styleable.ScrollRefreshListView_hasHeader, false);
            array.recycle();
            array = null;
        }

        if (hasHead) {
            mHead = new OverScrollView(context, true);
            addHeaderView(mHead);
            mHeadTips = new TipsHolder(R.drawable.loading_arrow_down, R.string.pull_down_to_refresh);
            mHead.setScrollRefreshListener(this);
        }

        mFoot = new OverScrollView(context, false);
        addFooterView(mFoot);
        mFootTips = new TipsHolder(R.drawable.loading_arrow_up, R.string.pull_up_to_refresh);
        mFoot.setScrollRefreshListener(this);
    }

    /**
     * 重置头部
     *
     * @param updateTime
     */
    public void resetHead(boolean updateTime) {
        Log.d("TAG", "resetHead, updateTime=" + updateTime);
        if (mHead != null) {
            mHead.reset();
            if (updateTime) {
                Object tag = mHead.getTag();
                if (tag != null && tag instanceof OverScrollView.Holder) {
                    OverScrollView.Holder holder = (OverScrollView.Holder) tag;
                    holder.timeView.setText(curTimeStr());
                    holder.timeView.setVisibility(View.VISIBLE);
                }
            }
        }
    }

    /**
     * 重置脚部
     *
     * @param updateTime
     */
    public void resetFoot(boolean updateTime) {
        Log.d("TAG", "resetFoot, updateTime=" + updateTime);
        if (mFoot != null) {
            mFoot.reset();
            if (updateTime) {
                Object tag = mFoot.getTag();
                if (tag != null && tag instanceof OverScrollView.Holder) {
                    OverScrollView.Holder holder = (OverScrollView.Holder) tag;
                    holder.timeView.setText(curTimeStr());
                    holder.timeView.setVisibility(View.VISIBLE);
                }
            }
        }
    }

    /**
     * 获取当前时间的字符串
     *
     * @return
     */
    private String curTimeStr() {
        Date date = new Date(System.currentTimeMillis());
        SimpleDateFormat formatter = new SimpleDateFormat("MM月dd日 kk:mm");
        return "上次刷新时间: " + formatter.format(date);
    }

    /**
     * 设置刷新事件监听器
     *
     * @param listener
     */
    public void setRefreshListener(OnRefreshListener listener) {
        this.mRefreshListener = listener;
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        switch (ev.getAction()) {
            case MotionEvent.ACTION_DOWN:
                mDownCoord = getEventCoord(ev);
//                return false;
            case MotionEvent.ACTION_MOVE:
                if (mDownCoord == null) {
                    mDownCoord = getEventCoord(ev);
//                    return true;
                }
        }

        return super.onInterceptTouchEvent(ev);
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        double distY = 0;
        if (mDownCoord != null) {
            distY = ev.getRawY() - mDownCoord[1];
        }

        if (mHead != null && distY > 0) {
            if (getFirstVisiblePosition() == 0 && mHead.getHeight() >= 0)
            //  正在拉上边缘
            {
                mActiveSide = ACTIVE_SIDE_HEAD;
                //  展示头部加载view
                int viewHeight = (int) distY / RATIO;
                if (viewHeight < 0) {
                    viewHeight = 0;
                }
                mHead.setVisibleHeight(viewHeight);
                setSelection(0);
            }
        } else if (mFoot != null && distY < 0) {
            if (getLastVisiblePosition() == getLastIndex() && mFoot.getHeight() >= 0)
            //  正在拉下边缘
            {
                mActiveSide = ACTIVE_SIDE_FOOT;
                //  展示尾部加载view
                int viewHeight = -(int) distY / RATIO;
                mFoot.setVisibleHeight(viewHeight);
                int lastOne = 0;
                if (getAdapter() != null) {
                    lastOne = getAdapter().getCount() - 1;
                    lastOne = lastOne < 0 ? 0 : lastOne;
                }
                setSelection(lastOne);
            }
        }

        //  手指弹起来，恢复原状
        if (ev.getAction() == MotionEvent.ACTION_UP || ev.getAction() == MotionEvent.ACTION_CANCEL) {
            //  清除此次动作的各种状态
            mDownCoord = null;
            if (mActiveSide == ACTIVE_SIDE_FOOT && mFoot != null) {
                mFoot.onFingerUp();
            }
            if (mActiveSide == ACTIVE_SIDE_HEAD && mHead != null) {
                mHead.onFingerUp();
            }
            mActiveSide = ACTIVE_SIDE_NONE;
        }

        return super.onTouchEvent(ev);
    }

    @Override
    public void onStateChanged(OverScrollView view, State
            oldState, State newState) {
        if (view == null || newState == null) {
            return;
        }
        oldState = oldState == null ? State.NORMAL : oldState;
        Object tag = view.getTag();
        if (tag == null || !(tag instanceof OverScrollView.Holder)) {
            return;
        }

        OverScrollView.Holder holder = (OverScrollView.Holder) tag;
        TipsHolder tipsHolder = view.isHeader() ? mHeadTips : mFootTips;
        if (newState == State.NORMAL) {
            //  变更文案
            holder.tipsView.setText(tipsHolder.defaultTips);
            //  变更图片
            if (oldState == State.READY_TO_REFRESH) {
                rotateImage(holder.arrowView, true);
            } else if (oldState == State.REFRESHING) {
                holder.progressView.setVisibility(View.INVISIBLE);
                holder.arrowView.setImageResource(tipsHolder.defaultArrow);
                holder.arrowView.setVisibility(View.VISIBLE);
                view.requestLayout();
            }
            //  显示时间
            CharSequence timeStr = holder.timeView.getText();
            if (timeStr != null && timeStr.length() > 0) {
                holder.timeView.setVisibility(View.VISIBLE);
            }
        } else if (newState == State.READY_TO_REFRESH) {
            //  变更文案
            holder.tipsView.setText(tipsHolder.readyToRefreshTips);
            //  箭头倒过来
            rotateImage(holder.arrowView, false);
        } else if (newState == State.REFRESHING) {
            //  变更文案
            holder.tipsView.setText(tipsHolder.refreshingTips);
            //  隐藏时间
            holder.timeView.setVisibility(View.GONE);
            //  隐藏箭头
            holder.arrowView.setImageBitmap(null);
            holder.arrowView.setVisibility(View.INVISIBLE);
            holder.arrowView.invalidate();
            //  显示进度
            holder.progressView.setVisibility(View.VISIBLE);

            if (oldState != State.REFRESHING && mRefreshListener != null) {
                mRefreshListener.onRefreshing(view, null);
            }
        }
    }

    /**
     * 旋转图片
     *
     * @param reversed 是否反转
     */

    private void rotateImage(View view, boolean reversed) {
        int fromDegree = reversed ? 180 : 0;
        int toDegree = reversed ? 360 : 180;
        RotateAnimation anim = new RotateAnimation(fromDegree, toDegree, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        anim.setDuration(200);
        anim.setFillAfter(true);
        view.startAnimation(anim);
    }

    /**
     * 得到list中最后一个的index
     *
     * @return
     */
    private int getLastIndex() {
        int index = 0;
        ListAdapter adapter = getAdapter();
        if (adapter != null) {
            index = adapter.getCount() - 1;
            index = index < 0 ? 0 : index;
        }
        return index;
    }

    /**
     * 取得当前动作的坐标[x, y]
     *
     * @param ev
     * @return
     */
    private int[] getEventCoord(MotionEvent ev) {
        if (ev != null) {
            int x = (int) ev.getRawX();
            int y = (int) ev.getRawY();
            Log.d("TAG", "x=" + x + ", y=" + y);

            return new int[]{x, y};
        }
        return null;
    }

    static class TipsHolder {
        //  放开刷新提示语
        final int readyToRefreshTips = R.string.release_to_refresh;

        //  默认提示语
        final int defaultTips;

        //  默认箭头
        final int defaultArrow;

        //  正在刷新提示语
        final int refreshingTips = R.string.refreshing;

        TipsHolder(int defaultArrow, int defaultTips) {
            this.defaultArrow = defaultArrow;
            this.defaultTips = defaultTips;
        }
    }

	public OverScrollView getFoot() {
		return mFoot;
	}
    
}
