package com.tencent.weigou.common.ui;

import com.tencent.weigou.R;

import android.content.Context;
import android.util.AttributeSet;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;

/**
 * 列表元素指引器。用于告知用户关联列表中的第一个元素被选中
 * 
 * @author ethonchan
 * 
 */
public class ListGuide extends LinearLayout {
	// 默认选中条目的索引号
	private int selectIndex = 0;
	// 关联列表的大小
	private int itemSize = 0;
	// 表示选中状态的图片
	private int select;
	// 表示未选中状态的图片
	private int unselect;
	// 图片之间的margin
	private int leftMargin = 8;
	private int rightMargin = 8;
	private int topMargin = 8;
	private int bottomMargin = 8;

	// 图片大小
	private int width = LayoutParams.WRAP_CONTENT;
	private int height = LayoutParams.WRAP_CONTENT;

	private ImageView[] guides;

	/**
	 * 构造一个列表元素指引器
	 * 
	 * @param context
	 *            上下文
	 */
	public ListGuide(Context context) {
		this(context, null);
	}

	/**
	 * 构造一个列表元素指引器
	 * 
	 * @param context
	 *            上下文
	 * @param attrs
	 *            属性集
	 */
	public ListGuide(Context context, AttributeSet attrs) {
		super(context, attrs);

		setOrientation(LinearLayout.HORIZONTAL);
		setGravity(Gravity.CENTER);

		select = R.drawable.selected;
		unselect = R.drawable.unselected;
	}

	/**
	 * 设置关联列表的大小，如果size为负数，则不予理会
	 * 
	 * @param size
	 *            列表的大小
	 */
	public void setListSize(int size) {
		if (size > 0) {
			itemSize = size;
			guides = new ImageView[size];

			removeAllViews();
			Context context = getContext();
			LinearLayout.LayoutParams layout = new LinearLayout.LayoutParams(
					width, height);
			layout.setMargins(leftMargin, topMargin, rightMargin, bottomMargin);
			for (int i = 0; i < size; i++) {
				ImageView view = new ImageView(context);
				view.setScaleType(ScaleType.FIT_XY);
				if (i == selectIndex) {
					view.setImageResource(select);
				} else {
					view.setImageResource(unselect);
				}
				view.setLayoutParams(layout);
				addView(view, i);
				guides[i] = view;
			}
		}
	}

	/**
	 * 设置被选中条目的index 若index越界，则不予理会
	 * 
	 * @param index
	 *            选中条目的index
	 */
	public void setSelectItem(int index) {
		if (index >= itemSize && selectIndex >= itemSize) {
			return;
		}
		if (index >= 0 && index < itemSize)
			index = index % itemSize;

		if (selectIndex >= 0)
			selectIndex = selectIndex % itemSize;

		if (index != selectIndex) {
			guides[selectIndex].setImageResource(unselect);
			guides[index].setImageResource(select);
		}
		selectIndex = index;
	}

	public void setItemMargin(int left, int top, int right, int bottom) {
		this.leftMargin = left;
		this.topMargin = top;
		this.rightMargin = right;
		this.bottomMargin = bottom;
	}

	public void setItemSize(int width, int height) {
		this.width = width;
		this.height = height;
	}

	/**
	 * 设置表示list条目选中和未选中两种状态的图片
	 * 
	 * @param selectDrawableResId
	 *            选中状态的图片
	 * @param unselectDrawableResId
	 *            未选中状态的图片
	 */
	public void setDrawables(int selectDrawableResId, int unselectDrawableResId) {
		if (selectDrawableResId > 0)
			select = selectDrawableResId;

		if (unselectDrawableResId > 0)
			unselect = unselectDrawableResId;
	}
}
