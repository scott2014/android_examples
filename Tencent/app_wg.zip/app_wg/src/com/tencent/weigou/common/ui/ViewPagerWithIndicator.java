package com.tencent.weigou.common.ui;

import com.tencent.weigou.R;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

/**
 * 
 * @ClassName： ViewPagerWithIndicator
 *
 * @Description： 自定义的带指示条的ViewPager
 * @author wamiwen
 * @date 2013-11-26 下午4:18:00
 *
 */
public class ViewPagerWithIndicator extends RelativeLayout implements
		OnPageChangeListener {

	/**
	 * 上下文
	 */
	private Context context;
	
	/**
	 * 当前Pager的index
	 */
	private int currentNum;
	
	/**
	 * 总Pager数
	 */
	private int viewPagerCount;

	/**
	 * ViewPager
	 */
	private ViewPager viewPager;

//	/**
//	 * ViewPager 指示条
//	 */
//	private ViewPagerIndicator indicator;
	/**
	 * ViewPager页码标识
	 */
	private TextView indicatorTv;
	
	/**
	 * 生成一个带指示条的ViewPager
	 * 
	 * @param context
	 */
	public ViewPagerWithIndicator(Context context) {
		this(context, null);
	}

	/**
	 * 生成一个带指示条的ViewPager
	 * 
	 * @param context
	 * @param attrs
	 */
	public ViewPagerWithIndicator(Context context, AttributeSet attrs) {
		super(context, attrs);
		this.context = context;
		init();
	}

	/**
	 * 
	 * @Title: init
	 *
	 * @Description: 初始化设置
	 * @param   设定文件
	 * @return void  返回类型
	 * @throws
	 */
	private void init() {
		View view = LayoutInflater.from(context).inflate(
				R.layout.viewpager_with_indicator_layout, this);
		viewPager = (ViewPager) view.findViewById(R.id.viewpager);
		indicatorTv = (TextView) view.findViewById(R.id.indicator);
		
		viewPager.setCurrentItem(0);
	}

	/**
	 * 
	 * @Title: setPagerAdapter
	 *
	 * @Description: 设置ViewPager的adapter
	 * @param @param pagerAdapter  设定文件
	 * @return void  返回类型
	 * @throws
	 */
	public void setPagerAdapter(PagerAdapter pagerAdapter) {
		if (pagerAdapter == null) {
			return;
		}
		viewPager.setAdapter(pagerAdapter);
		viewPager.setOnPageChangeListener(this);
		
		viewPagerCount = pagerAdapter.getCount();
		if (pagerAdapter.getCount() < 2) {
			indicatorTv.setVisibility(View.INVISIBLE);
		} else {
			indicatorTv.setText((currentNum + 1) + "/" + viewPagerCount);
		}
	}
	
	/**
	 * 
	 * @Title: setViewPagerOnClickListener
	 * 
	 * @Description: 设置ViewPager OnClick监听器
	 * @param @param l 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	public void setViewPagerOnClickListener(
			GestureDetector.SimpleOnGestureListener listener) {
		final GestureDetector tapGestureDetector = new GestureDetector(context,
				listener);
		viewPager.setOnTouchListener(new OnTouchListener() {
			public boolean onTouch(View v, MotionEvent event) {
				tapGestureDetector.onTouchEvent(event);
				return false;
			}
		});
	}
	
//	/**
//	 * 
//	 * @Title: setIndicatorHeight
//	 *
//	 * @Description: 设置指示条的高度
//	 * @param @param indicatorHeight  设定文件
//	 * @return void  返回类型
//	 * @throws
//	 */
//	public void setIndicatorHeight(int indicatorHeight) {
//		if (indicator != null) {
//			indicator.setIndicatorHeight(indicatorHeight);
//		}
//	}

//	/**
//	 * 
//	 * @Title: setIndicatorDrawables
//	 *
//	 * @Description: 设置指示条的选中和非选中图标
//	 * @param @param select
//	 * @param @param unselect  设定文件
//	 * @return void  返回类型
//	 * @throws
//	 */
//	public void setIndicatorDrawables(int select, int unselect) {
//		if (indicator != null) {
//			indicator.setIndicatorDrawables(select, unselect);
//		}
//	}
	
	/**
	 * 
	 * @Title: getCurrentItem
	 *
	 * @Description: 当前现实的item的index
	 * @param @return  设定文件
	 * @return int  返回类型
	 * @throws
	 */
	public int getCurrentItem() {
		return currentNum;
	}

	@Override
	public void onPageScrollStateChanged(int state) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onPageScrolled(int position, float positionOffset,
			int positionOffsetPixels) {
		
//		if (indicator != null) {
//			indicator.scrollToSelectIndicator(position, positionOffset);
//		}
		if (currentNum != position) {
			currentNum = position;
			indicatorTv.setText((currentNum + 1) + "/" + viewPagerCount);
		}
	}

	@Override
	public void onPageSelected(int position) {
		// TODO Auto-generated method stub

	}

}
