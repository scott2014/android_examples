package com.tencent.weigou.exception.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.tencent.weigou.R;
import com.tencent.weigou.base.activity.TitleBarActivity;
import com.tencent.weigou.util.Constants;
import com.tencent.weigou.util.ConstantsActivity;

/**
 * 网络不可用页面
 *
 * @author ethonchan
 */
public class NetworkUnavailableActivity extends TitleBarActivity implements
        OnClickListener {

    private Button refreshBtn = null;

    private Intent intent = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.network_unavailable_layout);
        setTitle(R.string.app_name);

        refreshBtn = (Button) findViewById(R.id.refreshBtn);
        refreshBtn.setOnClickListener(this);

        intent = getIntent().getParcelableExtra(ConstantsActivity.NET_ERR_INTENT);
    }

    @Override
    public void onClick(View v) {
        if (null != intent) {
            showDialog(Constants.DIALOG_PROGRESS);
            startActivity(intent);
        }
        finish();
    }

}
