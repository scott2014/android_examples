package com.tencent.weigou.discovery.model;

import com.tencent.weigou.base.model.Model;
import com.tencent.weigou.discovery.model.vo.DiscoveryVo;

/**
 * 
 * @ClassName： DiscoveryModel
 *
 * @Description：发现Model
 * @author wamiwen
 * @date 2013-11-26 下午4:38:17
 *
 */
public class DiscoveryModel extends Model {

	public final static int INIT_DATA = 0;
	
	private DiscoveryVo discoveryVo;
	
	@Override
	public void initData(String url) {
		super.initData(url);
		discoveryVo = new DiscoveryVo();
		createNetWorkTask(url, discoveryVo, INIT_DATA);
	}
	
	public DiscoveryVo getDiscoveryVo() {
		return discoveryVo;
	}

}
