package com.tencent.weigou.discovery.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;
import com.tencent.weigou.R;
import com.tencent.weigou.base.activity.BaseActivity;
import com.tencent.weigou.base.activity.ExitAppAdvisor;
import com.tencent.weigou.discovery.model.DiscoveryModel;
import com.tencent.weigou.discovery.view.DiscoveryUI;
import com.tencent.weigou.util.Constants;
import com.tencent.weigou.util.ConstantsUrl;
import com.tencent.weigou.util.PageIds.OprIndex;

/**
 * 
 * @ClassName： DiscoveryActivity
 * 
 * @Description：发现首页
 * @author wamiwen
 * @date 2013-11-26 下午7:07:53
 * 
 */
public class DiscoveryActivity extends BaseActivity implements OnClickListener {

	private static final int tp = 1;

	private static final int pn = 1; // 暂时没做分页， 起始页固定为1

	private static final int ps = 10; // 每页返回多少个元素

	private DiscoveryModel model = new DiscoveryModel();

	private DiscoveryUI ui = new DiscoveryUI();

	private ExitAppAdvisor mExitAppAdvisor;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mExitAppAdvisor = new ExitAppAdvisor();
		initMVC(model, ui, R.layout.discovery_main_layout);
		ui.setTitle(R.string.discovery_title);
		ui.selectBottomBar(2);
//		init();
	}

	private void init() {
		StringBuffer sb = new StringBuffer(app.getEnv().getServerUrl());
		sb.append(ConstantsUrl.URL_DISCOVERY_LIST + "?tp=").append(tp)
				.append("&pn=").append(pn).append("&ps=").append(ps);
		String url = sb.toString();
		url = appendPageInfo(url, OprIndex.PV_OPR);
		model.initData(url);
	}

	@Override
	protected void onResume() {
		super.onResume();
		ui.selectBottomBar(2);
		mExitAppAdvisor.resetTapTimes();

		if (model.getDiscoveryVo() == null || model.getDiscoveryVo().discoveryItemList == null 
				|| model.getDiscoveryVo().discoveryItemList.size() == 0) {
			init();
			// ui.hideNetworkUnavailable();
		}
	}

	@Override
	public void update(int notificationId) {
		super.update(notificationId);
		switch (notificationId) {
		case DiscoveryModel.INIT_DATA:
			ui.updateContent(model.getDiscoveryVo());
			ui.hideNetworkUnavailable();
			break;

		default:
			break;
		}
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.refreshBtn:
		case R.id.refresh_btn:
			ui.hideNetworkUnavailable();
			init();
			break;

		default:
			break;
		}

	}

	@Override
	public void onBackPressed() {
		ExitAppAdvisor.Advice advice = mExitAppAdvisor
				.askAdviceWhenBackPressed();
		if (advice == ExitAppAdvisor.Advice.DO_NOTHING) {
			;
		} else if (advice == ExitAppAdvisor.Advice.EXIT_APP) {
			exitAll();
			finish();
		} else if (advice == ExitAppAdvisor.Advice.ONE_MORE_CLICK) {
			Toast.makeText(this, "再按一次返回键退出", Constants.TOAST_NORMAL_LONG)
					.show();
		} else if (advice == ExitAppAdvisor.Advice.DEFAULT) {
			super.onBackPressed();
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (ui != null) {
			ui.onDestroy();
		}
	}

	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		overridePendingTransition(android.R.anim.fade_in,
				android.R.anim.fade_out);
	}

	@Override
	protected void onNetworkUnavailable(int notificationId) {
		switch (notificationId) {
		case DiscoveryModel.INIT_DATA:
			ui.showNetworkUnavailable();
			break;
		}
	}
}
