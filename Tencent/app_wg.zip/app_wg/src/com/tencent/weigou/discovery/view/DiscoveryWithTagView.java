package com.tencent.weigou.discovery.view;

import java.util.LinkedList;
import java.util.List;

import com.tencent.weigou.R;
import com.tencent.weigou.common.IDestroy;
import com.tencent.weigou.discovery.activity.DiscoveryActivity;
import com.tencent.weigou.discovery.model.vo.DiscoveryVo;
import com.tencent.weigou.discovery.model.vo.DiscoveryVo.DiscoveryItemVo;
import com.tencent.weigou.discovery.model.vo.DiscoveryVo.HotSpotVo;
import com.tencent.weigou.shopping.activity.ShoppingCmdyPagerActivity;
import com.tencent.weigou.shopping.utils.IProgressImgLoaderEvent;
import com.tencent.weigou.shopping.utils.ProgressImgLoader;
import com.tencent.weigou.shopping.view.ProgressImageView;
import com.tencent.weigou.util.ConstantsActivity;
import com.tencent.weigou.util.ImageScaleUtils;
import com.tencent.weigou.util.StringUtils;
import com.tencent.weigou.util.Util;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.ScaleAnimation;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView.ScaleType;
import android.view.View.OnClickListener;

/**
 * 
 * @ClassName： DiscoveryWithTagView
 * 
 * @Description： 自定义带标签的发现页面
 * @author wamiwen
 * @date 2013-11-27 下午6:58:35
 * 
 */
public class DiscoveryWithTagView extends FrameLayout implements
		IProgressImgLoaderEvent, OnClickListener, IDestroy {

	// 热点圆圈半径
	private final int spotRadius = Util.dip2px(getContext(), 7.5f);
//	private final int transRadius = Util.dip2px(getContext(), 12.0f);

	private final int TAG_SPOT_GAP = Util.dip2px(getContext(), 7.5f);
	private final int DESC_OUTTER_MARGIN_RIGHT = Util.dip2px(getContext(),
			10.0f);
	private final int DESC_OUTTER_MARGIN_BOTTOM = Util.dip2px(getContext(),
			90.0f);
	private final int DESC_TAG_MARGIN = Util.dip2px(getContext(), 10.0f);

	/**
	 * 热点列表
	 */
	private List<HotSpotVo> hotSpotList;

	// private Paint paint = new Paint();

	private ProgressImageView imgView;

	private LinearLayout descOutterView;
	private TextView descTitleTv;
	private TextView descSubTitleTv;
	private TextView descContentTv;

	// /**
	// * 图片原始宽度
	// */
	// private int imgWidth;
	//
	// /**
	// * 图片原始高度
	// */
	// private int imgHeight;

	/**
	 * 显示图片View的宽度
	 */
	private int viewWidth;

	/**
	 * 显示图片View的高度
	 */
	private int viewHeight;

	/**
	 * 图片缩放比例
	 */
	private float scaleRatio;

	/**
	 * 坐标转换工具
	 */
	private CoordUtil coordUtil;

	/**
	 * 保存热点View
	 */
	private List<View> hotSpotViews = new LinkedList<View>();
	
	/**
	 * 保存所有标签View
	 */
	private List<View> allTagViews = new LinkedList<View>();
	
	/**
	 * 保存点击跳转View
	 */
	private List<View> clickViews = new LinkedList<View>();

	private String jumpIds = "";

	private String themeTitle = "";

	private int descType;

	private String imgUrl = "";

	private ProgressImgLoader imageLoader;

	private Bitmap imgBitmap = null;

	public DiscoveryWithTagView(Context context) {
		this(context, null, 0);
	}

	public DiscoveryWithTagView(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public DiscoveryWithTagView(Context context, AttributeSet attrs,
			int defStyle) {
		super(context, attrs, defStyle);
		init(context);
	}

	private void init(Context context) {
		LayoutInflater inflater = LayoutInflater.from(context);
		inflater.inflate(R.layout.discovery_with_tag, this);
		imgView = (ProgressImageView) findViewById(R.id.image);
		imgView.setReloadClickListener(this);
		imgView.setLoadingTips(context
				.getString(R.string.discovery_loading_tips));
		descOutterView = (LinearLayout) findViewById(R.id.descOutter);
		descTitleTv = (TextView) descOutterView.findViewById(R.id.descTitleTv);
		descSubTitleTv = (TextView) descOutterView
				.findViewById(R.id.descSubTitleTv);
		descContentTv = (TextView) descOutterView.findViewById(R.id.descContentTv);
	}

	public void setData(final DiscoveryItemVo discoveryItemVo,
			final ProgressImgLoader imageLoader) {
		if (discoveryItemVo == null || imageLoader == null) {
			return;
		}
		this.imageLoader = imageLoader;
		jumpIds = discoveryItemVo.jumpIds;
		themeTitle = discoveryItemVo.themeTitle;
		descType = discoveryItemVo.descType;
		imgUrl = discoveryItemVo.picUrl;
		hotSpotList = discoveryItemVo.hotSpotList;
		// imgWidth = discoveryItemVo.picWidth;
		// imgHeight = discoveryItemVo.picHeight;
		// coordUtil = new CoordUtil(imgWidth, imgHeight);
		descTitleTv.setText(discoveryItemVo.descTitle);
		descSubTitleTv.setText(discoveryItemVo.descSubTitle);
		descContentTv.setText(discoveryItemVo.descContent);

		if (hotSpotList == null || hotSpotList.size() == 0) {
			return;
		}
		final FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(
				LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		for (int i = 0, size = hotSpotList.size(); i < size; i++) {
			final HotSpotVo vo = hotSpotList.get(i);
			if (vo == null) {
				continue;
			}

			final View descTagView = createDescTagView(vo.desc, vo.type,
					getContext());
			final ImageView hotSpotView = createHotSpotView(getContext());
//			final ImageView transView = createTransView(getContext());
			final View clickView = new View(getContext());

			addView(descTagView, 3 * i + 1, layoutParams);
			
			addView(hotSpotView, 3 * i + 2, layoutParams);
			hotSpotViews.add(hotSpotView);
			
//			addView(transView, 4 * i + 3, layoutParams);
//			transView.setVisibility(View.INVISIBLE);
//			hotSpotViews.add(transView);

			addView(clickView, 3 * i + 3, layoutParams);
			clickView.setTag(String.valueOf(i));
			clickView.setOnClickListener(this);
			
			allTagViews.add(hotSpotView);
			allTagViews.add(descTagView);
			clickViews.add(clickView);
		}
		allTagViews.add(descOutterView);
	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
	}

	@Override
	protected void onLayout(boolean changed, int left, int top, int right,
			int bottom) {
		viewWidth = right - left;
		viewHeight = bottom - top;

		layoutView(imgView, 0, 0, viewWidth, viewHeight);
		if (imgBitmap == null) {
			loadProgressImg(imgUrl, imgView, imageLoader);
		}

		if (coordUtil == null) {
			return;
		}

		descOutterView.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED);
		final int descOutterWidth = descOutterView.getMeasuredWidth();
		final int descOutterHeight = descOutterView.getMeasuredHeight();
		int descOutterL = 0, descOutterT = 0, descOutterR = 0, descOutterB = 0;
		if (DiscoveryVo.DESC_OUTTER_POS_BOTTOM_LEFT == descType) {
			descOutterL = DESC_OUTTER_MARGIN_RIGHT;
			descOutterT = viewHeight - DESC_OUTTER_MARGIN_BOTTOM
					- descOutterHeight;
			descOutterR = DESC_OUTTER_MARGIN_RIGHT + descOutterWidth;
			descOutterB = viewHeight - DESC_OUTTER_MARGIN_BOTTOM;
		} else {
			descOutterL = viewWidth - DESC_OUTTER_MARGIN_RIGHT
					- descOutterWidth;
			descOutterT = viewHeight - DESC_OUTTER_MARGIN_BOTTOM
					- descOutterHeight;
			descOutterR = viewWidth - DESC_OUTTER_MARGIN_RIGHT;
			descOutterB = viewHeight - DESC_OUTTER_MARGIN_BOTTOM;
		}
		layoutView(descOutterView, descOutterL, descOutterT, descOutterR,
				descOutterB);

		final int size = hotSpotList == null ? 0 : hotSpotList.size();
		for (int i = 0; i < size; i++) {
			final HotSpotVo vo = hotSpotList.get(i);
			if (vo == null) {
				continue;
			}

			final View childDesc = getChildAt(3 * i + 1);
			final View childSpot = getChildAt(3 * i + 2);
//			final View childTrans = getChildAt(4 * i + 3);
			final View childClick = getChildAt(3 * i + 3);

			final int[] spotScaledXY = coordUtil
					.transferCoord(vo.hotX, vo.hotY);
			final int spotL = spotScaledXY[0] - spotRadius;
			final int spotT = spotScaledXY[1] - spotRadius;
			final int spotR = spotScaledXY[0] + spotRadius;
			final int spotB = spotScaledXY[1] + spotRadius;
			layoutView(childSpot, spotL, spotT, spotR, spotB);
//			layoutView(childTrans, spotScaledXY[0] - transRadius,
//					spotScaledXY[1] - transRadius, spotScaledXY[0]
//							+ transRadius, spotScaledXY[1] + transRadius);

			childDesc.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED);
			int childDescWidth = childDesc.getMeasuredWidth();
			int childDescHeight = childDesc.getMeasuredHeight();
			int descL = 0, descT = 0, descR = 0, descB = 0;
			if (vo.type == DiscoveryVo.DESC_ON_LEFT) {
				// 描述标签在热点左边
				descL = spotL - TAG_SPOT_GAP - childDescWidth;
				descT = spotScaledXY[1] - childDescHeight / 2;
				descR = spotL - TAG_SPOT_GAP;
				descB = spotScaledXY[1] + childDescHeight / 2;
			} else {
				// 描述标签在热点右边
				descL = spotR + TAG_SPOT_GAP;
				descT = spotScaledXY[1] - childDescHeight / 2;
				descR = spotR + TAG_SPOT_GAP + childDescWidth;
				descB = spotScaledXY[1] + childDescHeight / 2;
			}
//			descL = descL < DESC_TAG_MARGIN ? DESC_TAG_MARGIN : descL;
			if (descL < DESC_TAG_MARGIN) {
				descL = DESC_TAG_MARGIN;
				changeDescTagViewBg(childDesc, getContext());
			}
			descR = descR > (viewWidth - DESC_TAG_MARGIN) ? (viewWidth - DESC_TAG_MARGIN)
					: descR;
			layoutView(childDesc, descL, descT, descR, descB);

			final int clickL = descL <= spotL ? descL : spotL;
			final int clickT = descT;
			final int clickR = descR >= spotR ? descR : spotR;
			final int clickB = descB;
			layoutView(childClick, clickL, clickT, clickR, clickB);
		}

	}

	private void layoutView(final View view, final int l, final int t,
			final int r, final int b) {
		if (view == null) {
			return;
		}
		final int width = r - l;
		final int height = b - t;
		final int widthMeasureSpec = MeasureSpec.makeMeasureSpec(width,
				MeasureSpec.EXACTLY);
		final int heightMeasureSpec = MeasureSpec.makeMeasureSpec(height,
				MeasureSpec.EXACTLY);
		view.measure(widthMeasureSpec, heightMeasureSpec);

		view.layout(l, t, r, b);
	}

	@Override
	protected void dispatchDraw(Canvas canvas) {
		super.dispatchDraw(canvas);
		// if (!isShow || coordUtil == null) {
		// return;
		// }
		// paint.setStrokeWidth(2.0f);
		// paint.setAntiAlias(true);
		// paint.setColor(Color.parseColor("#28231D"));
		// final int spotLine = (int) (spotRadius * 0.707);
		// final int size = hotSpotList == null ? 0 : hotSpotList.size();
		// for (int i = 0; i < size; i++) {
		// final HotSpotVo vo = hotSpotList.get(i);
		// if (vo == null) {
		// continue;
		// }
		// final int[] scaleDescXY = coordUtil.transferCoord(vo.descX,
		// vo.descY);
		// final int[] scaleSpotXY = coordUtil.transferCoord(vo.hotX, vo.hotY);
		// int descX = scaleDescXY[0], descY = scaleDescXY[1], spotX =
		// scaleSpotXY[0], spotY = scaleSpotXY[1];
		// if (descY < spotY) {
		// int diff = spotY - descY;
		// if (diff < vo.descHeight) {
		// if (diff < vo.descHeight / 2) {
		// canvas.drawLine(spotX + spotLine, spotY + spotLine,
		// descX, descY + vo.descHeight, paint);
		// } else {
		// canvas.drawLine(spotX + spotLine, spotY - spotLine,
		// descX, descY, paint);
		// }
		// } else {
		// diff = diff - vo.descHeight;
		// final int descLeftX = descX;
		// final int descRightX = descX + vo.descWidth;
		// final int leftMostX = spotX - diff;
		// final int rightMostX = spotX + diff;
		// if (descRightX < leftMostX) {
		// canvas.drawLine(spotX - spotLine, spotY - spotLine,
		// descRightX, descY + vo.descHeight, paint);
		// } else if (descRightX > leftMostX && descLeftX <= leftMostX) {
		// canvas.drawLine(spotX - spotLine, spotY - spotLine,
		// leftMostX, descY + vo.descHeight, paint);
		// } else if (rightMostX < descLeftX) {
		// canvas.drawLine(spotX + spotLine, spotY - spotLine,
		// descLeftX, descY + vo.descHeight, paint);
		// } else {
		// canvas.drawLine(spotX + spotLine, spotY - spotLine,
		// rightMostX, descY + vo.descHeight, paint);
		// }
		// }
		// } else {
		// final int diff = descY - spotY;
		// final int descLeftX = descX;
		// final int descRightX = descX + vo.descWidth;
		// final int leftMostX = spotX - diff;
		// final int rightMostX = spotX + diff;
		// if (descRightX < leftMostX) {
		// canvas.drawLine(spotX - spotLine, spotY + spotLine,
		// descRightX, descY, paint);
		// } else if (descRightX > leftMostX && descLeftX <= leftMostX) {
		// canvas.drawLine(spotX - spotLine, spotY + spotLine,
		// leftMostX, descY, paint);
		// } else if (rightMostX < descLeftX) {
		// canvas.drawLine(spotX + spotLine, spotY + spotLine,
		// descLeftX, descY, paint);
		// } else {
		// canvas.drawLine(spotX + spotLine, spotY + spotLine,
		// rightMostX, descY, paint);
		// }
		// }
		// }
	}

	private void loadProgressImg(final String url,
			final ProgressImageView progressImgView,
			final ProgressImgLoader imageLoader) {
		if (progressImgView == null || imageLoader == null) {
			return;
		}
		final Bitmap bitmap = imageLoader.loadDrawable(url, progressImgView,
				this);
		loadScaledBitmap(bitmap, progressImgView);
	}

	private void loadScaledBitmap(final Bitmap srcBitmap,
			final ProgressImageView progressImgView) {
		if (srcBitmap == null || progressImgView == null) {
			return;
		}
		final int imgWidth = srcBitmap.getWidth();
		final int imgHeight = srcBitmap.getHeight();
		coordUtil = new CoordUtil(imgWidth, imgHeight);
		scaleRatio = ImageScaleUtils.getScaleRatio(imgWidth, imgHeight,
				viewWidth, viewHeight);
		coordUtil.setViewSize(scaleRatio, viewWidth, viewHeight);

		if (srcBitmap != null) {
			imgBitmap = srcBitmap;
			progressImgView.setDrawableDone(true);
			progressImgView.setImageBitmap(srcBitmap);
		}
	}

	@Override
	public void imageLoaded(ImageView imageView, Bitmap bitmap, String imageUrl) {
		if (imageView != null && bitmap != null
				&& imageView instanceof ProgressImageView) {
			final ProgressImageView progressImgView = (ProgressImageView) imageView;
			loadScaledBitmap(bitmap, progressImgView);
			setTagsVisible();
		}
	}

	@Override
	public void imageLoadedStart(ImageView imageView) {
		((ProgressImageView) imageView).setDrawableDone(false);
		 setTagsInvisible();
	}

	@Override
	public void imageLoading(ImageView imageView, float progress) {
		((ProgressImageView) imageView).setProgress(progress);
	}

	@Override
	public void imageLoadedFailed(ImageView imageView) {
		((ProgressImageView) imageView).setDrawableFailed(true);
	}

	// /**
	// *
	// * @Title: createDescView
	// *
	// * @Description: 生成热点描述TextView
	// * @param @param desc
	// * @param @param ctx
	// * @param @return 设定文件
	// * @return TextView 返回类型
	// * @throws
	// */
	// private TextView createDescView(String desc, Context ctx) {
	// TextView textView = new TextView(ctx);
	// textView.setText(desc);
	// textView.setTextColor(Color.WHITE);
	// textView.setBackgroundResource(R.drawable.tag_bg);
	// textView.setTextSize(TypedValue.COMPLEX_UNIT_PX, ctx.getResources()
	// .getDimensionPixelSize(R.dimen.normal_label_text_size));
	// textView.setPadding(Util.dip2px(ctx, 10), Util.dip2px(ctx, 5),
	// Util.dip2px(ctx, 10), Util.dip2px(ctx, 5));
	// textView.setGravity(Gravity.CENTER);
	// textView.setSingleLine(true);
	// textView.setMaxEms(10);
	// textView.setEllipsize(TextUtils.TruncateAt.END);
	//
	// return textView;
	// }

	// private TextView createDescViewV2(String desc, Context ctx) {
	// TextView textView = new TextView(ctx);
	// textView.setText(desc);
	// textView.setTextColor(Color.WHITE);
	// // textView.setBackgroundResource(R.drawable.discovery_tag_bg);
	// textView.setTextSize(TypedValue.COMPLEX_UNIT_PX, ctx.getResources()
	// .getDimensionPixelSize(R.dimen.normal_label_text_size));
	// textView.setPadding(Util.dip2px(ctx, 11.0f), Util.dip2px(ctx, 5),
	// Util.dip2px(ctx, 13.33f), Util.dip2px(ctx, 5));
	// textView.setGravity(Gravity.CENTER);
	// textView.setSingleLine(true);
	// textView.setMaxEms(10);
	// textView.setEllipsize(TextUtils.TruncateAt.END);
	//
	// return textView;
	// }

	/**
	 * 
	 * @Title: createDescTagView
	 * 
	 * @Description: 生成描述tag的View
	 * @param @param desc
	 * @param @param posTyep
	 * @param @param ctx
	 * @param @return 设定文件
	 * @return View 返回类型
	 * @throws
	 */
	private View createDescTagView(String desc, int posType, Context ctx) {
		View descTagView = null;
		if (posType == DiscoveryVo.DESC_ON_LEFT) {
			descTagView = LayoutInflater.from(ctx).inflate(
					R.layout.discovery_desc_tag_left, null);
		} else {
			descTagView = LayoutInflater.from(ctx).inflate(
					R.layout.discovery_desc_tag_right, null);
		}

		TextView descTagTv = (TextView) descTagView
				.findViewById(R.id.desc_tag_tv);
		descTagTv.setText(desc);

		return descTagView;
	}
	
	/**
	 * 
	 * @Title: changeDescTagViewBg
	 *
	 * @Description: 标签超出左边边界时更换标签的背景
	 * @param @param descTagView
	 * @param @param ctx  设定文件
	 * @return void  返回类型
	 * @throws
	 */
	private void changeDescTagViewBg(View descTagView, Context ctx) {
		TextView descTagTv = (TextView) descTagView.findViewById(R.id.desc_tag_tv);
		ImageView descTagArrow = (ImageView) descTagView.findViewById(R.id.desc_tag_arrow);
		descTagArrow.setVisibility(View.GONE);
		descTagTv.setBackgroundResource(R.drawable.discovery_tag_left_bg_v2);
		descTagTv.setPadding(Util.dip2px(getContext(), 10), 0, Util.dip2px(getContext(), 20), 0);
	}

	/**
	 * 
	 * @Title: createHotSpotView
	 * 
	 * @Description: 生成热点圆圈ImageView
	 * @param @param ctx
	 * @param @return 设定文件
	 * @return ImageView 返回类型
	 * @throws
	 */
	private ImageView createHotSpotView(Context ctx) {
		ImageView imageView = new ImageView(ctx);
		imageView.setImageResource(R.drawable.hot_spot);
		imageView.setScaleType(ScaleType.FIT_XY);

		return imageView;
	}

//	private ImageView createTransView(Context ctx) {
//		ImageView imageView = new ImageView(ctx);
//		imageView.setImageResource(R.drawable.circle_border);
//		imageView.setScaleType(ScaleType.CENTER);
//
//		return imageView;
//	}

	/**
	 * 
	 * @Title: hideTagItemAnim
	 * 
	 * @Description: 隐藏View，透明动画
	 * @param @param tagView 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	private void hideTagItemAnim(final View tagView) {
		if (tagView == null) {
			return;
		}
		final AlphaAnimation anim = new AlphaAnimation(1.0f, 0.1f);
		anim.setDuration(400);
		anim.setAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {

			}

			@Override
			public void onAnimationRepeat(Animation animation) {

			}

			@Override
			public void onAnimationEnd(Animation animation) {
				tagView.setVisibility(View.INVISIBLE);
			}
		});
		tagView.startAnimation(anim);
	}

	/**
	 * 
	 * @Title: showTagItemAnim
	 * 
	 * @Description: 显示View，透明动画
	 * @param @param tagView 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	private void showTagItemAnim(final View tagView) {
		if (tagView == null) {
			return;
		}
		final AlphaAnimation anim = new AlphaAnimation(0.1f, 1.0f);
		anim.setDuration(400);
		anim.setAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {

			}

			@Override
			public void onAnimationRepeat(Animation animation) {

			}

			@Override
			public void onAnimationEnd(Animation animation) {
				tagView.setVisibility(View.VISIBLE);
			}
		});
		tagView.startAnimation(anim);
	}

	// /**
	// *
	// * @Title: hideTagsAnim
	// *
	// * @Description: 隐藏所有的标签View，带透明动画
	// * @param 设定文件
	// * @return void 返回类型
	// * @throws
	// */
	// public void hideTagsAnim() {
	// if (tagViews == null || tagViews.size() == 0) {
	// return;
	// }
	// isShow = false;
	// for (int i = 0, size = tagViews.size(); i < size; i++) {
	// final View tagView = tagViews.get(i);
	// hideTagItemAnim(tagView);
	// }
	// // invalidate();
	// }

	// /**
	// *
	// * @Title: showTagsAnim
	// *
	// * @Description: 显示所有的标签View，带透明动画
	// * @param 设定文件
	// * @return void 返回类型
	// * @throws
	// */
	// public void showTagsAnim() {
	// if (tagViews == null || tagViews.size() == 0) {
	// return;
	// }
	// isShow = true;
	// for (int i = 0, size = tagViews.size(); i < size; i++) {
	// final View tagView = tagViews.get(i);
	// showTagItemAnim(tagView);
	// }
	// // invalidate();
	// }

	 /**
	 *
	 * @Title: setTagsVisible
	 *
	 * @Description: 设置所有标签View可见
	 * @param 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	 public void setTagsVisible() {
		 final AlphaAnimation alphaAnimation = new AlphaAnimation(0.0f, 1.0f);
		 alphaAnimation.setDuration(500);
		 for (int i = 0, len = allTagViews.size(); i < len; i++) {
			final View tagView = allTagViews.get(i);
			if (tagView == null) {
				continue;
			}
			tagView.startAnimation(alphaAnimation);
			tagView.setVisibility(View.VISIBLE);
		}
		for (int i = 0, len = clickViews.size(); i < len; i++) {
			final View clickView = clickViews.get(i);
			if (clickView == null) {
				continue;
			}
			clickView.setVisibility(View.VISIBLE);
		}
	 }

	 /**
	 *
	 * @Title: setTagsInvisible
	 *
	 * @Description: 设置所有标签View不可见
	 * @param 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	 public void setTagsInvisible() {
		 for (int i = 0, len = allTagViews.size(); i < len; i++) {
			 final View tagView = allTagViews.get(i);
			 if (tagView == null) {
				continue;
			 }
			 tagView.setVisibility(View.INVISIBLE);
		}
		for (int i = 0, len = clickViews.size(); i < len; i++) {
			final View clickView = clickViews.get(i);
			if (clickView == null) {
				continue;
			}
			clickView.setVisibility(View.INVISIBLE);
		}
	 }

	@Override
	public void onClick(View v) {
		Object obj = null;
		switch (v.getId()) {
		case R.id.image:
			imageLoader.loadDrawable(imgUrl, imgView, 0, 0, false, false, this);
			break;

		default:
			obj = v.getTag();
			if (obj != null && obj instanceof String) {
				final String index = (String) obj;
				if (StringUtils.isNotBlank(index)
						&& StringUtils.isNotBlank(jumpIds)) {
					Intent intent = new Intent(getContext(),
							ShoppingCmdyPagerActivity.class);
					intent.putExtra(ConstantsActivity.INTENT_SOURCE_ACTIVITY,
							DiscoveryActivity.class.getSimpleName());
					intent.putExtra(ConstantsActivity.INTENT_CMDY_INDEX, index);
					intent.putExtra(ConstantsActivity.INTENT_CMDY_IDS, jumpIds);
					intent.putExtra(ConstantsActivity.INTENT_CMDY_LIST_TITLE,
							themeTitle);
					getContext().startActivity(intent);
				}
			}
			break;
		}
	}

	public void playScaleAnimating() {
		final int size = hotSpotViews.size();
		index = index % size;
		if ((index >= 0) && (index < size)) {
			final View hotSpotView = hotSpotViews.get(index);
//			final View transView = hotSpotViews.get(index * 2 + 1);

//			final ScaleAnimation transScaleAnimation = new ScaleAnimation(1.0f,
//					1.6f, 1.0f, 1.6f, Animation.RELATIVE_TO_SELF, 0.5f,
//					Animation.RELATIVE_TO_SELF, 0.5f);
//			transScaleAnimation.setRepeatCount(2);
//			transScaleAnimation.setRepeatMode(Animation.REVERSE);
//			transScaleAnimation.setDuration(800);
//			final AlphaAnimation alphaAnimation = new AlphaAnimation(0.0f, 0.9f);
//			alphaAnimation.setRepeatCount(2);
//			alphaAnimation.setRepeatMode(Animation.REVERSE);
//			alphaAnimation.setDuration(800);
//			final AlphaAnimation alphaAnimation2 = new AlphaAnimation(0.9f, 0.0f);
//			alphaAnimation2.setDuration(500);
//			alphaAnimation2.setStartOffset(2400);
//			final AnimationSet as = new AnimationSet(false);
//			as.addAnimation(transScaleAnimation);
//			as.addAnimation(alphaAnimation);
//			as.addAnimation(alphaAnimation2);

			final ScaleAnimation scaleAnimation = new ScaleAnimation(0.75f,
					1.2f, 0.75f, 1.2f, Animation.RELATIVE_TO_SELF, 0.5f,
					Animation.RELATIVE_TO_SELF, 0.5f);
			scaleAnimation.setDuration(300);
			scaleAnimation.setInterpolator(new DecelerateInterpolator());
			scaleAnimation.setRepeatCount(2);
			scaleAnimation.setRepeatMode(Animation.REVERSE);
//			scaleAnimation.setAnimationListener(new AnimationListener() {
//
//				@Override
//				public void onAnimationStart(Animation animation) {
//
//				}
//
//				@Override
//				public void onAnimationRepeat(Animation animation) {
//
//				}
//
//				@Override
//				public void onAnimationEnd(Animation animation) {
//					transView.startAnimation(as);
//				}
//			});
			hotSpotView.startAnimation(scaleAnimation);

			index++;
		}
	}

	private int index = 0;
	private final Handler handler = new Handler();
	private final Runnable runnable = new Runnable() {

		@Override
		public void run() {
			playScaleAnimating();
			handler.postDelayed(this, 4000);
		}
	};

	public void startAnimating() {
		handler.postDelayed(runnable, 2000);
	}

	@Override
	public void destroy() {
		handler.removeCallbacks(runnable);
	}

}
