package com.tencent.weigou.discovery.model.vo;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.tencent.weigou.base.model.vo.CommonVo;
import com.tencent.weigou.util.StringUtils;

/**
 * 
 * @ClassName： DiscoveryVo
 *
 * @Description： 发现Vo
 * @author wamiwen
 * @date 2013-11-26 下午4:39:49
 *
 */
public class DiscoveryVo extends CommonVo {
	
	public static final int DESC_ON_RIGHT = 0;
	public static final int DESC_ON_LEFT = 1;
	
	public static final int DESC_OUTTER_POS_BOTTOM_RIGHT = 1;
	public static final int DESC_OUTTER_POS_BOTTOM_LEFT = 2;

	public int pageNo;
	
	public int pageSize;
	
	public int pageTotal;
	
//	public List<DiscoveryItemVo> discoveryItemList = new ArrayList<DiscoveryVo.DiscoveryItemVo>();
	public List<DiscoveryItemVo> discoveryItemList;
	
	@Override
	public boolean parse(JSONObject jo) {
		try {
			pageNo = jo.optInt("pageNo", 0);
			pageSize = jo.optInt("pageSize", 0);
			pageTotal = jo.optInt("pageTotal", 0);
			JSONArray elements = jo.optJSONArray("elements");
			final int len = elements.length();
			discoveryItemList = new ArrayList<DiscoveryVo.DiscoveryItemVo>(len);
			for (int i = 0; i < len; i++) {
				JSONObject itemObj = elements.optJSONObject(i);
				if (itemObj == null) {
					continue;
				}
				DiscoveryItemVo itemVo = new DiscoveryItemVo();
				itemVo.id = itemObj.optString("discoverId", "");
				itemVo.picUrl = itemObj.optString("discoverPic", "");
				itemVo.themeTitle = itemObj.optString("discoverTitle", "");
				itemVo.type = itemObj.optInt("discoverType", 0);
				itemVo.picWidth = itemObj.optInt("picWidth", 0);
				itemVo.picHeight = itemObj.optInt("picHeight", 0);
				JSONObject descObj = itemObj.optJSONObject("desc");
				if (descObj != null) {
					itemVo.descTitle = descObj.optString("descTitle", "");
					itemVo.descSubTitle = descObj.optString("descSideLine", "");
					itemVo.descContent = descObj.optString("descContent", "");
					itemVo.descType = descObj.optInt("descType", DESC_OUTTER_POS_BOTTOM_RIGHT);
				}
				JSONArray hotSpots = itemObj.optJSONArray("hotSpotList");
				for (int j = 0, hotLen = hotSpots.length(); j < hotLen; j++) {
					JSONObject hotSpotObj = hotSpots.optJSONObject(j);
					if (hotSpotObj == null) {
						continue;
					}
					HotSpotVo hotSpotVo = new HotSpotVo();
					hotSpotVo.desc = hotSpotObj.optString("desc", "");
					hotSpotVo.descX = hotSpotObj.optInt("descX", 0);
					hotSpotVo.descY = hotSpotObj.optInt("descY", 0);
					hotSpotVo.hotX = hotSpotObj.optInt("hotX", 0);
					hotSpotVo.hotY = hotSpotObj.optInt("hotY", 0);
					JSONObject jumpObj = hotSpotObj.optJSONObject("jumpTo");
					if (jumpObj != null) {
						hotSpotVo.jumpType = jumpObj.optInt("type", 0);
						hotSpotVo.jumpId = jumpObj.optString("info", "");
					}
					hotSpotVo.type = hotSpotObj.optInt("type", 0);
					itemVo.hotSpotList.add(hotSpotVo);
				}
				itemVo.jumpIds = toJumpIds(itemVo.hotSpotList);
				discoveryItemList.add(itemVo);
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public static class DiscoveryItemVo {
		
		public String id = "";
		public String picUrl = "";
		public String themeTitle = "";
		public int type;
		public int picWidth;
		public int picHeight;
		public List<HotSpotVo> hotSpotList = new LinkedList<DiscoveryVo.HotSpotVo>();
		public String jumpIds = "";
		
		public String descTitle = "";
		public String descSubTitle = "";
		public String descContent = "";
		public int descType;
	}
	
	public static class HotSpotVo {
		
		public String desc = "";
	    public int descX;
	    public int descY;
	    public int hotX;
	    public int hotY;
		public int jumpType;
		public String jumpId = "";
		public int type;
//		public int descWidth;
//		public int descHeight;
		
	}
	
	private String toJumpIds(List<HotSpotVo> list) {
		String ids = "";
		if (list == null || list.size() == 0) {
			return ids;
		}
		for (HotSpotVo hotSpotVo : list) {
			if (hotSpotVo == null) {
				continue;
			}
			if (StringUtils.isNotBlank(ids)) {
				ids += "," + hotSpotVo.jumpId;
			} else {
				ids += hotSpotVo.jumpId;
			}
		}
		
		return ids;
	}
	
}
