package com.tencent.weigou.discovery.view;

import java.util.List;

import android.support.v4.view.PagerAdapter;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.tencent.weigou.R;
import com.tencent.weigou.base.view.UI;
import com.tencent.weigou.common.ui.BottomBar;
import com.tencent.weigou.common.ui.TopToolBar;
import com.tencent.weigou.common.ui.ViewPagerWithIndicator;
import com.tencent.weigou.discovery.activity.DiscoveryActivity;
import com.tencent.weigou.discovery.model.vo.DiscoveryVo;
import com.tencent.weigou.discovery.model.vo.DiscoveryVo.DiscoveryItemVo;
import com.tencent.weigou.shopping.utils.ProgressImgLoader;

/**
 * 
 * @ClassName： DiscoveryUI
 * 
 * @Description： 发现 UI
 * @author wamiwen
 * @date 2013-11-26 下午4:37:58
 * 
 */
public class DiscoveryUI extends UI {

	/**
	 * 顶部Bar
	 */
	private TopToolBar topbar;

	/**
	 * 底部Bar
	 */
	private BottomBar bottombar;

	/**
	 * 发现为空或网络异常显示的View
	 */
	private View emptyView;
	
	private RelativeLayout networkRL;

	/**
	 * 带滚动指示条的ViewPager
	 */
	private ViewPagerWithIndicator viewPager;

	/**
	 * 自定义的ViewPager Adapter
	 */
	private CustomPagerAdapter pagerAdapter;

	/**
	 * 图片加载器
	 */
	private ProgressImgLoader imageLoader = new ProgressImgLoader();
	
	/**
	 * 标识标签是显示还是隐藏
	 */
	private boolean isShow = true;

	@Override
	public void initView(View outterView) {
		super.initView(outterView);
		networkRL = (RelativeLayout) findViewById(R.id.network_un);
		topbar = (TopToolBar) outterView.findViewById(R.id.top_bar);
		bottombar = (BottomBar) outterView.findViewById(R.id.bottom_bar);
		viewPager = (ViewPagerWithIndicator) outterView
				.findViewById(R.id.viewpager_with_indicator);
		emptyView = outterView.findViewById(R.id.empty_view);
		EmptyViewHolder emptyViewHolder = new EmptyViewHolder();
		emptyViewHolder.emptyTipsTv = (TextView) emptyView
				.findViewById(R.id.empty_tips);
		emptyViewHolder.emptyTipsDescTv = (TextView) emptyView
				.findViewById(R.id.empty_tips_desc);
		emptyViewHolder.refreshBtn = (Button) emptyView
				.findViewById(R.id.refresh_btn);
		emptyView.setTag(emptyViewHolder);

		setUpListeners();
	}

	class EmptyViewHolder {
		TextView emptyTipsTv;
		TextView emptyTipsDescTv;
		Button refreshBtn;
	}

	/**
	 * 设置标题
	 * 
	 * @param strId
	 *            标题ID
	 */
	public void setTitle(int strId) {
		if (topbar != null) {
			topbar.initTitle(strId);
		}
	}

	/**
	 * 设置底部的选中Button
	 * 
	 * @param index
	 *            Button的序号,从0开始
	 */
	public void selectBottomBar(int index) {
		if (bottombar != null) {
			bottombar.setSelect(index);
		}
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		if (imageLoader != null) {
			imageLoader.destroy();
		}
	}

	private void setUpListeners() {
		viewPager
				.setViewPagerOnClickListener(new GestureDetector.SimpleOnGestureListener() {

					@Override
					public boolean onSingleTapConfirmed(MotionEvent e) {
						showOrHide();
						return true;
					}

				});
	}

	/**
	 * 
	 * @Title: showOrHide
	 * 
	 * @Description: 显示或隐藏标签
	 * @param 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	private void showOrHide() {
		if (isShow) {
			hide();
		} else {
			show();
		}
	}

	private void show() {
		// 从顶部进入的动画
		final Animation inUpAnim = AnimationUtils.loadAnimation(context,
				R.anim.in_from_up);
		inUpAnim.setAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {

			}

			@Override
			public void onAnimationRepeat(Animation animation) {

			}

			@Override
			public void onAnimationEnd(Animation animation) {
				topbar.setVisibility(View.VISIBLE);
				bottombar.setVisibility(View.VISIBLE);
			}
		});
		topbar.startAnimation(inUpAnim);
		// 从底部进入的动画
		final Animation inDownAnim = AnimationUtils.loadAnimation(context,
				R.anim.in_from_down);
		bottombar.startAnimation(inDownAnim);
		// showPagerTagViews();
		isShow = true;
	}

	private void hide() {
		// 从顶部消失的动画
		final Animation outUpAnim = AnimationUtils.loadAnimation(context,
				R.anim.out_to_up);
		outUpAnim.setAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {

			}

			@Override
			public void onAnimationRepeat(Animation animation) {

			}

			@Override
			public void onAnimationEnd(Animation animation) {
				topbar.setVisibility(View.INVISIBLE);
				bottombar.setVisibility(View.INVISIBLE);
			}
		});
		topbar.startAnimation(outUpAnim);
		// 从底部消失的动画
		final Animation outDownAnim = AnimationUtils.loadAnimation(context,
				R.anim.out_to_down);
		bottombar.startAnimation(outDownAnim);
		// hidePagerTagViews();
		isShow = false;
	}

	// /**
	// *
	// * @Title: showPagerTagViews
	// *
	// * @Description: 显示标签
	// * @param 设定文件
	// * @return void 返回类型
	// * @throws
	// */
	// private void showPagerTagViews() {
	// if (pagerAdapter == null || pagerAdapter.getCount() == 0) {
	// return;
	// }
	// final DiscoveryWithTagView[] pagerViews = pagerAdapter.getPagerViews();
	// final int currIndex = viewPager.getCurrentItem();
	// for (int i = 0, len = pagerViews.length; i < len; i++) {
	// final DiscoveryWithTagView pagerView = pagerViews[i];
	// if (pagerView == null) {
	// continue;
	// }
	// if (currIndex == i) {
	// pagerView.showTagsAnim();
	// } else {
	// pagerView.setTagsVisible();
	// }
	// }
	// }

	// /**
	// *
	// * @Title: hidePagerTagViews
	// *
	// * @Description: 隐藏标签
	// * @param 设定文件
	// * @return void 返回类型
	// * @throws
	// */
	// private void hidePagerTagViews() {
	// if (pagerAdapter == null || pagerAdapter.getCount() == 0) {
	// return;
	// }
	// final DiscoveryWithTagView[] pagerViews = pagerAdapter.getPagerViews();
	// final int currIndex = viewPager.getCurrentItem();
	// for (int i = 0, len = pagerViews.length; i < len; i++) {
	// final DiscoveryWithTagView pagerView = pagerViews[i];
	// if (pagerView == null) {
	// continue;
	// }
	// if (currIndex == i) {
	// pagerView.hideTagsAnim();
	// } else {
	// pagerView.setTagsInvisible();
	// }
	// }
	// }

	public void onNetworkUnvailable() {
		viewPager.setVisibility(View.GONE);
		emptyView.setVisibility(View.VISIBLE);
		EmptyViewHolder emptyViewHolder = (EmptyViewHolder) emptyView.getTag();
		emptyViewHolder.emptyTipsTv.setText(R.string.network_unavailable_tips);
		emptyViewHolder.emptyTipsDescTv.setText(R.string.please_check_network);
		emptyViewHolder.refreshBtn
				.setOnClickListener((DiscoveryActivity) context);
	}

	public void updateContent(DiscoveryVo vo) {
		if (vo == null) {
			return;
		}
		super.updateContent(vo);
		if (vo.discoveryItemList == null || vo.discoveryItemList.size() == 0) {
			viewPager.setVisibility(View.GONE);
			emptyView.setVisibility(View.VISIBLE);
			EmptyViewHolder emptyViewHolder = (EmptyViewHolder) emptyView
					.getTag();
			emptyViewHolder.emptyTipsDescTv.setVisibility(View.INVISIBLE);
			emptyViewHolder.refreshBtn.setVisibility(View.INVISIBLE);
		} else {
			viewPager.setVisibility(View.VISIBLE);
			emptyView.setVisibility(View.GONE);
			pagerAdapter = new CustomPagerAdapter(vo.discoveryItemList);
			viewPager.setPagerAdapter(pagerAdapter);
		}
	}

	/**
	 * 
	 * @ClassName： CustomPagerAdapter
	 * 
	 * @Description： 自定义ViewPager Adapter
	 * @author wamiwen
	 * @date 2013-11-26 下午7:11:10
	 * 
	 */
	private class CustomPagerAdapter extends PagerAdapter {

		private List<DiscoveryItemVo> discoveryItemList;

		public CustomPagerAdapter(List<DiscoveryItemVo> discoveryItemList) {
			this.discoveryItemList = discoveryItemList;
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			final DiscoveryWithTagView view = (DiscoveryWithTagView) object;
			view.destroy();
			container.removeView(view);
			object = null;
		}

		@Override
		public Object instantiateItem(ViewGroup container, int position) {
			DiscoveryItemVo temp = discoveryItemList.get(position);
			DiscoveryWithTagView view = new DiscoveryWithTagView(context);
			view.setData(temp, imageLoader);
			container.addView(view);
			view.startAnimating();
			return view;
		}

		@Override
		public int getCount() {
			return discoveryItemList == null ? 0 : discoveryItemList.size();
		}

		@Override
		public boolean isViewFromObject(View view, Object obj) {
			if (view == null || obj == null) {
				return false;
			}
			return view == obj;
		}

	}

	public void hideNetworkUnavailable() {
		networkRL.setVisibility(View.GONE);
	}

	public void showNetworkUnavailable() {
		networkRL.setVisibility(View.VISIBLE);
		networkRL.setOnClickListener(null);
		networkRL.findViewById(R.id.refreshBtn).setOnClickListener(
				(DiscoveryActivity) context);

	}
}
