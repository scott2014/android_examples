package com.tencent.weigou.discovery.view;

/**
 * 发现坐标转换工具
 * User: ethonchan
 * Date: 13-11-28
 * Time: 上午10:15
 */
public class CoordUtil {

    //  源的坐标原点
    private int[] sourceOrigin = new int[]{0,0};

    //  目标的坐标原点
    private int[] viewOrigin = new int[]{0,0};

    //  缩放比例(目标/源)
    private float scaleRatio = 0.0f;

    /**
     * 新建一个坐标转换工具
     *
     * @param sourceWidth
     * @param sourceHeight
     */
    public CoordUtil(int sourceWidth, int sourceHeight) {
        sourceOrigin[0] = sourceWidth / 2;
        sourceOrigin[1] = sourceHeight / 2;
    }

//    /**
//     * 设置目标的大小
//     *
//     * @param targetWidth
//     * @param targetHeight
//     */
//    public void setTargetSize(int targetWidth, int targetHeight) {
//
//        targetOrigin[0] = targetWidth / 2;
//        targetOrigin[1] = targetHeight / 2;
//
//        if (sourceWidth > 0) {
//            scaleRatio[0] = (double) targetWidth / sourceWidth;
//        } else {
//            scaleRatio[0] = 1.0D;
//        }
//
//        if (sourceHeight > 0) {
//            scaleRatio[1] = (double) targetHeight / sourceHeight;
//        } else {
//            scaleRatio[1] = 1.0D;
//        }
//    }
     public void setViewSize(final float scaleRatio, final int viewWidth, final int viewHeight) {
    	 this.scaleRatio = scaleRatio;
    	 
    	 viewOrigin[0] = viewWidth / 2;
    	 viewOrigin[1] = viewHeight / 2;
     }

    /**
     * 转换坐标
     * @param sourceX   以(0, 0)为坐标原点的源X
     * @param sourceY   以(0, 0)为坐标原点的源Y
     * @return  以(0, 0)为坐标原点的目标[x,y]
     */
    public int[] transferCoord(final int sourceX, final int sourceY) {
        int[] transCoord = new int[2];
        // 将sourceXY平移到中心
        transCoord[0] = sourceX - sourceOrigin[0];
//      transCoord[1] = sourceY + sourceOrigin[1];
        transCoord[1] = sourceY - sourceOrigin[1];

        //  缩放坐标
        transCoord[0] = (int)(transCoord[0] * scaleRatio);
        transCoord[1] = (int)(transCoord[1] * scaleRatio);

//      //  将坐标平移回(0,0)
//      transCoord[0] = transCoord[0] + targetOrigin[0];
//      transCoord[1] = transCoord[1] - targetOrigin[1];
        
        // 将左边平移回View的(0,0)
        transCoord[0] = transCoord[0] + viewOrigin[0];
        transCoord[1] = transCoord[1] + viewOrigin[1] ;

        return transCoord;
    }
}
