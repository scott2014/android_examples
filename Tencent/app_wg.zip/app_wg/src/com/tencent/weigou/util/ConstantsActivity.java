package com.tencent.weigou.util;

/**
 * 
 * @author jonathanqi intent中传递数据的常量数据
 */
public class ConstantsActivity {
	public final static String NET_ERR_INTENT = "intent_net_err";
	public static final int MALL_REQ_CODE = 10;
	public static final int REGION_RESP_CODE = 11;

	public static final String REGION_CITY_NAME = "cityName";

	/**
	 * 逛一逛常量
	 */
	public static final String INTENT_MALL_SUB_BACK = "mallSubBack";
	public static final String INTENT_MALL_DETAIL_ID = "mallId";
	public static final String INTENT_MALL_DETAIL_NAME = "mallName";
	public static final String INTENT_MALL_CAT_ID = "catId";
	public static final String INTENT_MALL_CAT_NAME = "catName";
	public static final String INTENT_SHOP_DETAIL_ID = "shopId";
	public static final String INTENT_SHOP_INDEX = "shopIndex";
	public static final String INTENT_SHOP_DETAIL_NAME = "shopName";
	public static final String INTENT_SHOP_CAT_ID = "sCatId";
	public static final String INTENT_SHOP_CAT_NAME = "sCatName";
	public static final String INTENT_SHOP_ITEM_ID = "itemId";
	public static final String INTENT_MALL_DETAIL_SOURCE = "mallSource";
	public static final String MALL_DETAIL_ACTIVITY_NAME = "MallDetailActivity";
	public static final int MALL_DETAIL_REQ_CODE_REGION = 0;
	public static final int MALL_DETAIL_REQ_CODE_NAV = 1;
	public static final int MALL_DETAIL_REQ_SUB = 3;
	public static final int CMDY_REQ_CODE_NAV = 2;
	public static final String SHOPPING_REGION = "shopping_region";
	public static final String INTENT_SHOPPING_SHOP_ID = "intent_shopping_shop_id";
	public static final String INTENT_SHOPPING_CMDY_ID = "intent_shopping_cmdy_id";
	public static final String MALL_PREF_NAME = "com.tencent.weigou.mall";
	public static final String MALL_FIRST = "mallFirst";
	public static final String MALL_PREF_MALL_ID = "prefMallId";
	public static final String MALL_PREF_MALL_TYPE = "prefMallType";
	public static final String MALL_PREF_CAT_ID = "prefCatId";
	public static final String MALL_PREF_SHOP_ID = "prefShopId";
	public static final String MALL_PREF_MALL_NAME = "prefMallName";
	public static final String INTENT_SHOP_ALL_CAT_ID = "shopAllCatIds";
	public static final String INTENT_SHOP_ALL_CAT_NAME = "shopAllCatNames";
    public static final String INTENT_SHOP_TEL = "tel";

	/**
	 * 礼券相关的。
	 */
	public static final String INTENT_TICKET_DEAL_DETAIL = "bid";
	public static final String INTENT_TICKET_CDKEY = "cdkey";
	public static final String INTENT_TICKET_MAPPID = "mappid";
	public static final String INTENT_TICKET_STOREID = "storeid";
	public static final String INTENT_TICKET_TITLE_DETAIL = "title";
	public static final String INTENT_TICKET_DETAIL = "cardId";
	public static final String INTENT_DEAL_ID = "dealId";
	public static final String INTENT_BRAND_ID = "brandId";
	public static final String INTENT_BRAND_NAME = "brandName";
	public static final String INTENT_SHOP_ID = "shopId";
	public static final String INTENT_SHOP_NAME = "shopName";
	public static final String INTENT_SINGLE_CARD = "singleCard";
	public static final String INTENT_MALL_ID = "mallId";
	public static final String INTENT_MALL_NAME = "mallName";
	public static final String INTENT_CMDY_ID = "itemId";
	public static final String INTENT_CMDY_NAV_DATA = "nav_data";
	public static final String INTENT_CMDY_NAV_URL = "nav_url";
	public static final String INTENT_CMDY_PN = "nav_pn";
	public static final String INTENT_CMDY_SUM = "cmdy_sum";
	public static final String INTENT_PAGER_INDEX = "pager_index";
	
	/**
	 * 发现页调商详列表相关
	 */
	public static final String INTENT_SOURCE_ACTIVITY = "source_activity";
	public static final String INTENT_CMDY_IDS = "itemList";
	public static final String INTENT_CMDY_INDEX = "cmdy_index";
	public static final String INTENT_CMDY_LIST_TITLE = "title";

}
