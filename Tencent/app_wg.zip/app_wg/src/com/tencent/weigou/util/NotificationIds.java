package com.tencent.weigou.util;

public class NotificationIds {
	public static final int TOAST_NETWORK_NOT_WORK_ID = -1;
	public static final int SHOW_PROGRESS_DIALOG = -2;
	public static final int DISMISS_PROGRESS_DIALOG = -3;

    //  需要登录
    public static final int NEED_AUTH_ID = -4;

	/**
	 * 订阅列表
	 */
	public static final int FOLLOW_LIST_INIT = 10;
	/**
	 * 收藏夹列表
	 */
	public static final int FAV_LIST_ITEM = 11;

	/**
	 * 礼券列表
	 */
	public static final int TICKET_LIST_ITEM = 12;

	/**
	 * 礼券详情
	 */
	public static final int TICKET_DEAL_DETAIL = 13;

	/**
	 * 微信支付
	 */
	public static final int PAY_BY_WEIXIN = 14;
}
