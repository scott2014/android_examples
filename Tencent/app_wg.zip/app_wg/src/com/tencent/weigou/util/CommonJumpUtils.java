/**
 * @Title: CommomJumpUtil.java
 * @Package com.qq.buy.pp.common.model
 * @author branjing branjing@tencent.com  
 * @date 2012-12-24
 * @version V1.0
 */
package com.tencent.weigou.util;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.tencent.weigou.my.activity.MyActivity;
import com.tencent.weigou.my.activity.MyFollowActivity;
import com.tencent.weigou.my.activity.MyTicketActivity;
import com.tencent.weigou.my.activity.MyTicketDetailActivity;
import com.tencent.weigou.page.activity.BrandPageActivity;
import com.tencent.weigou.page.activity.MallPageActivity;
import com.tencent.weigou.page.activity.ShopPageActivity;
import com.tencent.weigou.pay.activity.PayActivity;
import com.tencent.weigou.setting.activity.AboutActivity;
import com.tencent.weigou.setting.activity.FeedbackActivity;
import com.tencent.weigou.setting.activity.SettingActivity;
import com.tencent.weigou.shopping.activity.MallDetailActivity;
import com.tencent.weigou.shopping.activity.ShopPagerActivity;
import com.tencent.weigou.shopping.activity.ShoppingCmdyPagerActivity;
import com.tencent.weigou.shopping.activity.ShoppingIndexActivity;
import com.tencent.weigou.web.URLWhiteList;
import com.tencent.weigou.web.WebKitActivity;
import com.tencent.weigou.web.WebkitConstants;
import org.apache.http.NameValuePair;

import java.util.HashMap;
import java.util.List;

/**
 * @author wendyhu
 * @ClassName: CommomJumpUtil
 * @date 2013-11-07
 */

public class CommonJumpUtils {

	public final static String GUANG_MALL = "guangMall";

	public final static String GUANG_SHOP = "guangShop";

	public static final String ITEM = "item";

	public static final String MALL_PAGE = "mallPage";

	public static final String BRAND_PAGE = "brandPage";

	public static final String SHOP_PAGE = "shopPage";

	public static final String MY = "my";

	public static final String TICKET_DETAIL = "ticketDetail";

	/**
	 * 支付 weigou://pay?cardId=xxx
	 */
	public static final String PAY = "pay";
	/**
	 * 我的关注列表 weigou://myfollow
	 */
	public static final String MYFOLLOW = "myfollow";

	/**
	 * 我的关注列表 weigou://myfollow
	 */
	public static final String MYTICKET = "myticket";

	/**
	 * 关于 weigou://about
	 */
	public static final String ABOUT = "about";

	/**
	 * 反馈 weigou://feedback
	 */
	public static final String FEEDBACK = "feedback";

	/**
	 * 设置 weigou://setting
	 */
	public static final String SETTING = "setting";

	/**
	 * 设置 weigou://html?title=xx&url=xxx
	 */
	public static final String HTML = "html";

	// 客户端支持的跳转方式
	private static HashMap<String, String> mActivityMap = new HashMap<String, String>();

	static {
		// 网页
		mActivityMap.put(HTML, WebKitActivity.class.getName());
		// 逛商场
		mActivityMap.put(GUANG_MALL, MallDetailActivity.class.getName());
		// 逛门店
		mActivityMap.put(GUANG_SHOP, ShopPagerActivity.class.getName());
		// 我的个人中心相关
		mActivityMap.put(MY, MyActivity.class.getName());
		mActivityMap.put(PAY, PayActivity.class.getName());
		mActivityMap.put(SETTING, SettingActivity.class.getName());
		mActivityMap.put(MYFOLLOW, MyFollowActivity.class.getName());
		mActivityMap.put(MYTICKET, MyTicketActivity.class.getName());
		mActivityMap.put(ABOUT, AboutActivity.class.getName());
		mActivityMap.put(FEEDBACK, FeedbackActivity.class.getName());
		mActivityMap.put(SETTING, SettingActivity.class.getName());
		// 礼券详情
		mActivityMap.put(TICKET_DETAIL, MyTicketDetailActivity.class.getName());
		// PAGE页
		mActivityMap.put(MALL_PAGE, MallPageActivity.class.getName());
		mActivityMap.put(BRAND_PAGE, BrandPageActivity.class.getName());
		mActivityMap.put(SHOP_PAGE, ShopPageActivity.class.getName());

		// 商品列表
		mActivityMap.put(ITEM, ShoppingCmdyPagerActivity.class.getName());
	}

	/**
	 * 跳转到具体的Activity
	 * 
	 * @param context
	 * @param targetName
	 *            跳转目的地
	 * @param paramList
	 *            参数列表
	 */
	public static void goActivity(Context context, String targetName,
			List<NameValuePair> paramList) {
		Bundle data = new Bundle();
		if (paramList != null) {
			for (NameValuePair param : paramList) {
				data.putString(param.getName(), param.getValue());
			}
		}

		goActivity(context, targetName, data);
	}

	/**
	 * 跳转到具体的Activity
	 * 
	 * @param targetName
	 *            要跳转到activity
	 * @param bundle
	 *            参数
	 */
	public static void goActivity(Context packageContext, String targetName,
			Bundle bundle) {
		if (packageContext == null || StringUtils.isBlank(targetName)) {
			return;
		}

		String fullClassName = targetName;
		if (mActivityMap.containsKey(targetName))
		// 客户端约定的统一跳转
		{
			fullClassName = mActivityMap.get(targetName);
		}

		if (!isValidClassName(fullClassName))
		// 非法跳转
		{
			return;
		}

		if (fullClassName.equals(WebKitActivity.class.getName())
				&& bundle != null)
		// 跳转到浏览器，需要检查url
		{
			String url = bundle.getString(WebkitConstants.INTENT_URL);

			if (!URLWhiteList.isFromTrustDomain(url)) {
				return;
			}
		}

		try {
			Intent intent = new Intent();
			intent.setClassName(packageContext, fullClassName);
			if (bundle != null) {
				intent.putExtras(bundle);
			}
            if(ShoppingIndexActivity.class.getName().equals(fullClassName))
            //  跳回首页
            {
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            }
			packageContext.startActivity(intent);
		} catch (Exception e) {
			// TODO 要做升级提醒
			// intent.setClass(packageContext,
			// com.qq.buy.navigation.NewVersionActivity.class);
			// intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			// packageContext.startActivity(intent);
		}
	}

	/**
	 * @param packageContext
	 *            void 返回类型
	 * @throws
	 * @Title: goActivity
	 * @Description: 新的跳转方式
	 */
	public static void go(Context packageContext, String jumpStr) {
		if (packageContext == null || jumpStr == null)
			return;

		// 计算targetName的起止位置
		int targetStart = jumpStr.indexOf(":/");
		if (targetStart > -1) {
			String sep = jumpStr.substring(targetStart, targetStart + 3);
			if ("://".equals(sep)) {
				targetStart += 3;
			} else {
				targetStart += 2;
			}
		} else {
			targetStart = 0;
		}

		int targetEnd = jumpStr.indexOf("?");
		if (targetEnd < 0) {
			targetEnd = jumpStr.length();
		}

		// 跳转目的地
		String targetName = jumpStr.substring(targetStart, targetEnd);

		// 参数
		int paramStart = targetEnd < jumpStr.length() ? targetEnd + 1 : jumpStr
				.length();
		String paramStr = jumpStr.substring(paramStart);
		List<NameValuePair> params = Util.getParam(paramStr, "&");

		goActivity(packageContext, targetName, params);
	}

	/**
	 * 校验跳转类名是否合法
	 * 
	 * @param className
	 * @return
	 */
	private static boolean isValidClassName(String className) {
		if (StringUtils.isBlank(className)) {
			return false;
		} else if (className.startsWith("com.tencent.weigou")) {
			return true;
		} else if (mActivityMap.containsKey(className)) {
			return true;
		} else {
			return false;
		}
	}
}
