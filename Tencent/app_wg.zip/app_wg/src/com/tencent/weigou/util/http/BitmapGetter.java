package com.tencent.weigou.util.http;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import com.tencent.stat.StatAppMonitor;
import com.tencent.weigou.util.Constants;
import com.tencent.weigou.util.StringUtils;
import com.tencent.weigou.util.http.base.HttpRequest;

import java.net.HttpURLConnection;

/**
 * 图片资源获取工具 User: ethonchan Date: 13-10-22 Time: 下午5:58
 */
public class BitmapGetter extends HttpRequest<Bitmap> {

	/**
	 * Http请求基类
	 * 
	 * @param useCache
	 *            true使用缓存，false不使用缓存
	 */
	public BitmapGetter(boolean useCache) {
		super(useCache);
	}

	/**
	 * Get方式获取图片
	 * 
	 * @param urlStr
	 *            图片url
	 * @return 图片对象
	 * @throws Exception
	 */
	public Bitmap doGet(String urlStr) throws Exception {
		// 参数检查
		paramsNotNull(urlStr);

		// 请求图片
		Bitmap result = doRequest("image/getImage.xhtml", urlStr);

		return result;
	}

	@Override
	protected void onReadyToConnect(String urlStr, StatAppMonitor monitor,
			Object... params) {
		// 输出日志
		Log.d(TAG, "start GET bitmap: " + urlStr);

		// 保存请求包大小（只统计了url的，不准确）
		try {
			if (!cancelled) {
				monitor.setReqSize(StringUtils.getByteLength(urlStr,
						Constants.DECODE_CHARSET));
			}
		} catch (Exception e) {
			monitor.setReqSize(0);
		}
	}

	@Override
	protected void onConnected(String urlStr, HttpURLConnection conn) {
		;
	}

	@Override
	protected Bitmap onGetResponseData(byte[] data, StatAppMonitor monitor) {
		Bitmap bitmap = null;
		if (!cancelled) {
			int len = data == null ? 0 : data.length;
			try {
				if (cancelled) {
					// ignore
				} else if (data != null) {
					bitmap = BitmapFactory.decodeByteArray(data, 0, len);
					monitor.setResultType(StatAppMonitor.SUCCESS_RESULT_TYPE);
				} else {
					monitor.setResultType(StatAppMonitor.FAILURE_RESULT_TYPE);
				}
			} catch (OutOfMemoryError e) {
				//
			} catch (Exception e) {
				monitor.setResultType(StatAppMonitor.FAILURE_RESULT_TYPE);
			}
		}

		if (!cancelled) {
			Log.d(TAG, "result: "
					+ (bitmap != null ? bitmap.toString() : "null"));
		} else {
			Log.d(TAG, "BitmapGetter has been cancelled!");
		}
		return bitmap;
	}

}
