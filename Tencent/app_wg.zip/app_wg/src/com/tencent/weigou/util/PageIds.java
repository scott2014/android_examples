package com.tencent.weigou.util;

import java.util.HashMap;
import java.util.Map;

import com.tencent.weigou.EntryActivity;
import com.tencent.weigou.discovery.activity.DiscoveryActivity;
import com.tencent.weigou.feeds.activity.FeedDetailActivity;
import com.tencent.weigou.feeds.activity.FeedListActivity;
import com.tencent.weigou.guide.GuideActivity;
import com.tencent.weigou.my.activity.MyActivity;
import com.tencent.weigou.my.activity.MyFollowActivity;
import com.tencent.weigou.my.activity.MyItemFavActivity;
import com.tencent.weigou.my.activity.MyTicketActivity;
import com.tencent.weigou.my.activity.MyTicketDetailActivity;
import com.tencent.weigou.page.activity.BrandPageActivity;
import com.tencent.weigou.page.activity.MallPageActivity;
import com.tencent.weigou.recom.activity.RecomActivity;
import com.tencent.weigou.shopping.activity.MallDiscountsActivity;
import com.tencent.weigou.shopping.activity.MallNewActivity;
import com.tencent.weigou.shopping.activity.ShopListActivity;
import com.tencent.weigou.shopping.activity.ShopPagerActivity;
import com.tencent.weigou.shopping.activity.ShoppingCmdyPagerActivity;
import com.tencent.weigou.shopping.model.MallDetailModel;
import com.tencent.weigou.wxapi.NeedAuthActivity;
import com.tencent.weigou.wxapi.WXEntryActivity;

/**
 * 页面PageId User: ethonchan Date: 13-10-14 Time: 下午7:06
 */
public class PageIds {
	// 源pageId的Intent变量名
	public final static String INTENT_SOURCE_PAGEID = "sourc_pgid";
	// 前一页的Intent变量名
	public final static String INTENT_PRE_PAGEID = "pre_pgid";

	private static Map<String, Integer> PGIDS = new HashMap<String, Integer>();

	/**
	 * 
	 * @ClassName: OprIndex
	 * @Description: ptag的最后一个字段，用于表示该请求的类型，用于上报信息。
	 *               一共三种类型，0-用于统计pv，一个页面有且只有一个该类型的接口访问， 1-不用于统计pv，也不属于用户行为，
	 *               2-不用于统计pv，但属于用户交互行为
	 *               例子：一个页面有接口a,b,c用于获取页面展示所需的数据，接口d是收藏按钮，接口e是分享按钮
	 *               那么a的OprIndex为0，b和c的OprIndex为1，d和e的OprIndex为2
	 * @author branjing
	 * @date 2013-10-22 下午3:52:13
	 */
	public static enum OprIndex {
		PV_OPR(0), NON_PV_OPR(1), USER_OPR(2);

		private int value;

		private OprIndex(int value) {
			this.value = value;
		}

		public int getValue() {
			return value;
		}
	}

	/**
	 * 得到页面中对应位置上的一个ptag
	 * 
	 * @param sourcePgid
	 *            源pgid
	 * @param prePgid
	 *            前一个pgid
	 * @param pgid
	 *            当前页的pgid
	 * @param oprId
	 *            操作id 如果一个activity里有多个http请求，建议从1开始排序，然后自增。
	 * @return 生成的ptag 格式如下： * ptag = {类型}.[{源头pgid}.{前一个pgid}].{当前pgid}.{操作}
	 */
	public static String getPtag(int sourcePgid, int prePgid, int pgid,
			OprIndex oprId) {
		return String.format("%d.%d.%d.%d.%d", 1, sourcePgid, prePgid, pgid,
				oprId.getValue());
	}

	/**
	 * 根据类名获取对应的页面ID
	 * 
	 * @param className
	 * @return
	 */
	public static Integer getPageId(String className) {
		return PGIDS.get(className);
	}

	/**
	 * 这里定义每个页面的pgid,这里要按顺序写，并且不能重复，已经存在id不能更改。
	 */
	static {
		PGIDS.put(MallDetailModel.class.getSimpleName(), 9);
		PGIDS.put(ShopPagerActivity.class.getSimpleName(), 10);
		PGIDS.put(DiscoveryActivity.class.getSimpleName(), 11);
		PGIDS.put(ShopListActivity.class.getSimpleName(), 12);
		PGIDS.put(BrandPageActivity.class.getSimpleName(), 13);
		PGIDS.put(MallPageActivity.class.getSimpleName(), 14);
		PGIDS.put(ShopPagerActivity.class.getSimpleName(), 15);
		PGIDS.put(RecomActivity.class.getSimpleName(), 16);
		PGIDS.put(FeedListActivity.class.getSimpleName(), 17);
		PGIDS.put(FeedDetailActivity.class.getSimpleName(), 18);
		PGIDS.put(MallDiscountsActivity.class.getSimpleName(), 19);
		PGIDS.put(MallNewActivity.class.getSimpleName(), 20);
		PGIDS.put(GuideActivity.class.getSimpleName(), 21);
		PGIDS.put(EntryActivity.class.getSimpleName(), 22);
		PGIDS.put(NeedAuthActivity.class.getSimpleName(), 23);
		PGIDS.put(WXEntryActivity.class.getSimpleName(), 24);
		PGIDS.put(MyActivity.class.getSimpleName(), 25);
		PGIDS.put(ShoppingCmdyPagerActivity.class.getSimpleName(), 26);
		PGIDS.put(MyItemFavActivity.class.getSimpleName(), 27);
		PGIDS.put(MyTicketActivity.class.getSimpleName(), 28);
		PGIDS.put(MyTicketDetailActivity.class.getSimpleName(), 29);
		PGIDS.put(MyFollowActivity.class.getSimpleName(), 30);

		/********************************************************************************/
		/**************************** 新的PageId请写在我上方 *****************************/
		/**************************** PageId协商之后不得修改 *****************************/
		/*************************** PageId要求递增，请勿跳跃 ****************************/
		/************************* PageId最大不得超过或等于10000 *************************/
		/************************* 如遇页面改版，请使用原来的pgid *************************/
	}

}
