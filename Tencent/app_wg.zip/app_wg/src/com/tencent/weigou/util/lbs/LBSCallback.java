package com.tencent.weigou.util.lbs;

import com.tencent.map.lbsapi.api.SOSOMapLBSApi;
import com.tencent.map.lbsapi.api.SOSOMapLBSApiListener;
import com.tencent.map.lbsapi.api.SOSOMapLBSApiResult;

/**
 * LBS回调
 * User: ethonchan
 * Date: 13-10-28
 * Time: 下午3:11
 */
public class LBSCallback extends SOSOMapLBSApiListener {
    public LBSCallback() {
        super(SOSOMapLBSApi.REQ_TYPE_LOC, SOSOMapLBSApi.REQ_GEO_TYPE_MARS, SOSOMapLBSApi.REQ_LEVEL_ADMIN_AREA, SOSOMapLBSApi.REQ_DELAY_NORMAL);
    }

    @Override
    public final void onLocationUpdate(SOSOMapLBSApiResult lbsResult) {
        super.onLocationUpdate(lbsResult);
        if (lbsResult == null) {
            onUnknownError();
        } else {
            if (lbsResult.Info == SOSOMapLBSApi.RES_LEVEL_NONE) {
                if (lbsResult.ErrorCode == SOSOMapLBSApi.LOC_ERROR_NETWORK) {
                    onNetworkFail();
                } else if (lbsResult.ErrorCode == SOSOMapLBSApi.LOC_ERROR_RADIO) {
                    onIOFail();
                } else {
                    onUnknownError();
                }
            } else {
                Location loc = LBSUtils.toLocation(lbsResult);
                onGetLocation(loc);
            }
        }
    }

    @Override
    public final void onStatusUpdate(int state) {
        super.onStatusUpdate(state);
        if (state == SOSOMapLBSApi.STATE_GPS_DISABLED) {
            onGPSClosed();
        } else if (state == SOSOMapLBSApi.STATE_GPS_ENABLED) {
            onGPSOpened();
        } else if (state == SOSOMapLBSApi.STATE_WIFI_DISABLED) {
            onWIFIClosed();
        } else if (state == SOSOMapLBSApi.STATE_WIFI_ENABLED) {
            onWIFIOpened();
        }
    }

    /**
     * 获取到位置信息后的回调
     *
     * @param loc 获取到的位置信息，注意判断为空
     */
    public void onGetLocation(Location loc){
        LBSUtils.setLocation(loc);
        SOSOMapLBSApi lbs = LBSUtils.getLBSInstance();
        if(lbs != null){
            lbs.removeLocationUpdate();
        }
    }

    /**
     * 网络请求失败回调
     */
    public void onNetworkFail() {
    	//目前已经迁移到非UI线程里操作，因此如果此回调方法要操作UI的话，必须调用runUIThread();
    }

    /**
     * IO失败回调
     */
    public void onIOFail() {
    	//目前已经迁移到非UI线程里操作，因此如果此回调方法要操作UI的话，必须调用runUIThread();
    }

    /**
     * 未知失败
     */
    public void onUnknownError() {
    	//目前已经迁移到非UI线程里操作，因此如果此回调方法要操作UI的话，必须调用runUIThread(); 
    }

    /**
     * GPS打开后的回调
     */
    public void onGPSClosed() {
    }

    /**
     * GPS关闭后的回调
     */
    public void onGPSOpened() {
    }

    /**
     * WIFI关闭后的回调
     */
    public void onWIFIClosed() {
    }

    /**
     * WIFI打开后的回调
     */
    public void onWIFIOpened() {
    }
}