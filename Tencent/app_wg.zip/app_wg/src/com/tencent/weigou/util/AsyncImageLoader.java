package com.tencent.weigou.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.SoftReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.http.HttpStatus;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v4.util.LruCache;
import android.util.Log;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;

import com.tencent.stat.StatAppMonitor;
import com.tencent.weigou.base.App;
import com.tencent.weigou.cache.CacheInfo;
import com.tencent.weigou.cache.CacheUtils;
import com.tencent.weigou.common.IDestroy;
import com.tencent.weigou.util.http.base.HttpRequest;

/**
 * 异步加载图片类
 *
 * 这里用存储了一个url和图片的对应关系，当这个url的图片加载完之后，会回调调用者去重新渲染图片
 * 缓存策略是内存缓存（硬引用LruCache、软引用SoftReference<Bitmap>）+本地SD卡文件缓存
 *
 * @author wendyhu
 *
 */
public class AsyncImageLoader implements IDestroy {
	private static final String IF_MODIFIED_SINCE = "If-Modified-Since";
	private static final String LAST_MODIFIED = "Last-Modified";
	private static final String LOG_TAG = "AsyncImageLoader";

	// 默认缓冲区大小=4k
	public final static int DEFAULT_BUFFER_SIZE = 1024 * 4;

	/**
	 * 是否需要圆角图片
	 */
	private boolean isNeedCorner = false;

	/**
	 * 是否需要压缩图片
	 */
	private boolean isNeedCompress = true;
	/**
	 * 图片需要check lastModifytime时间
	 */
	public static final long mustImageExipreCheckTime = 302400000;

	/**
	 * 硬引用LruCache
	 */
	private LruCache<String, Bitmap> sHardBitmapCache = null;
	/**
	 * 软引用Cache
	 */
	private Map<String, SoftReference<Bitmap>> sSoftBitmapCache = null;
	private ExecutorService executorService = null;

	private static final int MAX_MEMORY_SIZE = (int) (Runtime.getRuntime()
			.maxMemory() / 1024) / 5;
	private static final int MAX_CACHE_SIZE = 4 * 1024 * 1024;
	// 使用最大可用内存值的1/5作为硬缓存的大小
	private static final int HARD_CACHE_SIZE = MAX_MEMORY_SIZE < MAX_CACHE_SIZE ? MAX_MEMORY_SIZE
			: MAX_CACHE_SIZE;
	private static final int SOFT_CACHE_CAPACITY = 50;
	private static final int DEFAULTSIZE = (Runtime.getRuntime()
			.availableProcessors());

	/**
	 * 是否需要本地缓存，默认需要
	 */
	private boolean isNeedFileCache = true;

	public AsyncImageLoader(int threadCount) {
		this(threadCount, true, false, true);
	}

	public AsyncImageLoader() {
		this(DEFAULTSIZE, true, false, true);
	}

	/**
	 *
	 * <p>
	 * Title: p>
	 * <p>
	 * Description: 初使化异步加载图片类
	 * </p>
	 *
	 * @param isNeedFileCache
	 *            是否需要保存到本地
	 */
	public AsyncImageLoader(boolean isNeedFileCache) {
		this(DEFAULTSIZE, isNeedFileCache, false, true);
	}

	/**
	 * @return the isNeedCorner
	 */
	public boolean isNeedCorner() {
		return isNeedCorner;
	}

	/**
	 * @param isNeedCorner
	 *            the isNeedCorner to set
	 */
	public void setNeedCorner(boolean isNeedCorner) {
		this.isNeedCorner = isNeedCorner;
	}

	/**
	 * @return the isNeedCompress
	 */
	public boolean isNeedCompress() {
		return isNeedCompress;
	}

	/**
	 * @param isNeedCompress
	 *            the isNeedCompress to set
	 */
	public void setNeedCompress(boolean isNeedCompress) {
		this.isNeedCompress = isNeedCompress;
	}

	/**
	 *
	 * <p>
	 * Title: p>
	 * <p>
	 * Description: 初使化异步加载图片类
	 * </p>
	 *
	 * @param threadCount
	 *            线程个数
	 * @param isNeedFileCache
	 *            是否需要保存到本地
	 */
	@SuppressWarnings("serial")
	public AsyncImageLoader(int threadCount, boolean isNeedFileCache,
			boolean isNeedCorner, boolean isNeedCompress) {

		sHardBitmapCache = new LruCache<String, Bitmap>(HARD_CACHE_SIZE) {

			@Override
			protected int sizeOf(String key, Bitmap value) {
				// 重写此方法来衡量每张图片的大小，默认返回图片数量。
				return value.getRowBytes() * value.getHeight() / 1024;

			}

			@Override
			protected void entryRemoved(boolean evicted, String key,
					Bitmap oldValue, Bitmap newValue) {
				Log.v(LOG_TAG, "hard cache is full, push to soft cache");
				// 硬引用缓存满，将一个最不经常使用的oldValue推入到软引用缓存区
				sSoftBitmapCache.put(key, new SoftReference<Bitmap>(oldValue));
			}

		};

		sSoftBitmapCache = new LinkedHashMap<String, SoftReference<Bitmap>>(
				SOFT_CACHE_CAPACITY, 0.75f, true) {

			@Override
			protected boolean removeEldestEntry(
					Entry<String, SoftReference<Bitmap>> eldest) {
				if (size() > SOFT_CACHE_CAPACITY) {
					Log.v(LOG_TAG, "soft reference limit, purge one");
					return true;
				}
				return false;
			}

			@Override
			public SoftReference<Bitmap> put(String key,
					SoftReference<Bitmap> value) {
				Log.v(LOG_TAG, "push to soft cache, key:" + key);
				return super.put(key, value);
			}

		};

		executorService = Executors.newFixedThreadPool(threadCount);
		this.isNeedFileCache = isNeedFileCache;
		this.isNeedCorner = isNeedCorner;
		this.isNeedCompress = isNeedCompress;
	}

	/**
	 *
	 * @Title: putBitmapToCache
	 *
	 * @Description: 缓存Bitmap
	 * @param @param key
	 * @param @param bitmap
	 * @param @return 设定文件
	 * @return boolean 返回类型
	 * @throws
	 */
	private boolean putBitmapToCache(String key, Bitmap bitmap) {
		if (null != bitmap) {
			synchronized (sHardBitmapCache) {
				sHardBitmapCache.put(key, bitmap);
			}
			return true;
		}
		return false;
	}

	/**
	 *
	 * @Title: getBitmapFromCache
	 *
	 * @Description: 从缓存中获取Bitmap
	 * @param @param key
	 * @param @return 设定文件
	 * @return Bitmap 返回类型
	 * @throws
	 */
	private Bitmap getBitmapFromCache(final String key) {
		synchronized (sHardBitmapCache) {
			final Bitmap bitmap = sHardBitmapCache.get(key);
			if (null != bitmap) {
				return bitmap;
			}
		}
		// 硬引用缓存区间中读取失败，从软引用缓存区间读取
		synchronized (sSoftBitmapCache) {
			SoftReference<Bitmap> bitmapReference = sSoftBitmapCache.get(key);
			if (null != bitmapReference) {
				final Bitmap bitmap = bitmapReference.get();
				if (null != bitmap) {
					return bitmap;
				} else {
					Log.v(LOG_TAG, "soft reference already recycled");
					sSoftBitmapCache.remove(key);
				}
			}
		}
		return null;
	}

	/**
	 * 对发送的HTTP请求进行预处理
	 *
	 * @param conn
	 * @return
	 */
	protected HttpURLConnection preProcessHttp(HttpURLConnection conn) {
		if (conn != null) {
			try {
				conn.setConnectTimeout(HttpRequest.CONNECT_TIME_OUT);
				conn.setReadTimeout(HttpRequest.READ_TIME_OUT);

				String network = SysUtils.getNetworkType();
				if (SysUtils.NETWORK_CMWAP.equals(network)) {
					String host = conn.getURL().getHost();
					conn.addRequestProperty(HttpRequest.NETWORK_CMWAP_HEADER,
							host);
				}
			} catch (Exception e) {
				// ignore
			}
		}
		return conn;
	}

	/**
	 *
	 * @Title: downloadFromNet
	 *
	 * @Description: 从网络中下载图片
	 * @param @param urlStr
	 * @param @param info
	 * @param @return 设定文件
	 * @return boolean 返回类型
	 * @throws
	 */
	private boolean downloadFromNet(String urlStr, CacheInfo cache) {
		boolean finished = false;
		if (null == cache) {
			return finished;
		}

		InputStream inputStream = null;
		HttpURLConnection conn = null;

		Log.v(LOG_TAG, "start GET url: " + urlStr);
		StatAppMonitor monitor = MTAUtils.getAppMonitorForImage(urlStr);
		final long start = System.nanoTime();

		try {
			// 保存请求包大小（只统计了url的，不准确）
			monitor.setReqSize(StringUtils.getByteLength(urlStr,
					Constants.DECODE_CHARSET));

			URL url = new URL(urlStr);
			// 首先进行预处理
			conn = (HttpURLConnection) url.openConnection();
			conn = preProcessHttp(conn);
			if (conn == null) {
				return false;
			}

			if (cache.getLastModified() > 0) {
				conn.addRequestProperty(IF_MODIFIED_SINCE,
						DateUtils.L2CST(cache.getLastModified()));
			}

			final int statusCode = conn.getResponseCode();
			// 保存接口返回码
			monitor.setReturnCode(statusCode);
			// 返回304,说明不用更新数据
			if (statusCode == HttpStatus.SC_NOT_MODIFIED) {
				finished = true;
			} else {
				if (statusCode != HttpStatus.SC_OK) {
					Log.e(LOG_TAG, "Error statusCode:" + statusCode
							+ ", while retrieving image from " + urlStr);
				} else if ((inputStream = conn.getInputStream()) != null) {
					final long curTime = System.currentTimeMillis();
					final long lastModified = conn.getHeaderFieldDate(
							LAST_MODIFIED, curTime);
					cache.setLastModified(lastModified);

					cache.setValue(toByteArray(inputStream));

					// 记录返回包大小
					final int respSize = cache.getValue() == null ? 0 : cache
							.getValue().length;
					monitor.setRespSize(respSize);

					finished = true;
				}
			}
		} catch (IOException e) {
			Log.e(LOG_TAG, "I/O error while retrieving image from " + urlStr, e);
		} catch (Exception e) {
			Log.e(LOG_TAG, "Error while retrieving image from " + urlStr, e);
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					Log.e(LOG_TAG, "Error while closing inputStream " + urlStr,
							e);
				}
			}

			if (conn != null) {
				conn.disconnect();
			}
		}
		// 上报统计信息
        MTAUtils.report(App.getInstance(), start, monitor);
		return finished;
	}

	private byte[] toByteArray(InputStream ins) throws IOException {
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
		int n = 0;
		while (-1 != (n = ins.read(buffer))) {
			bos.write(buffer, 0, n);
		}
		byte[] result = null;
		result = bos.toByteArray();
		if (bos != null) {
			bos.close();
		}
		return result;
	}

	/**
	 *
	 * @Title: loadDrawable
	 *
	 * @Description: 加载图片，不指定需要加载的图片宽高
	 * @param @param imageUrl
	 * @param @param imageView
	 * @param @param imageCallback
	 * @param @return 设定文件
	 * @return Bitmap 返回类型
	 * @throws
	 */
	public Bitmap loadDrawable(final String imageUrl,
			final ImageView imageView,
			final IImageLoadedCallBack imageLoadedCallBack) {
		int width = 0, height = 0;
		if (isNeedCompress && imageView != null) {
			LayoutParams params = imageView.getLayoutParams();
			if (params != null) {
				width = params.width;
				height = params.height;
			}
		}
		return loadDrawable(imageUrl, imageView, width, height, true, isNeedCorner,
				imageLoadedCallBack);
	}

	public Bitmap loadDrawable(final String imageUrl,
			final ImageView imageView, boolean needCorner,
			final IImageLoadedCallBack imageLoadedCallBack) {
		int width = 0, height = 0;
		if (isNeedCompress && imageView != null) {
			LayoutParams params = imageView.getLayoutParams();
			if (params != null) {
				width = params.width;
				height = params.height;
			}
		}
		return loadDrawable(imageUrl, imageView, width, height, true,
				needCorner, imageLoadedCallBack);
	}

	public Bitmap loadDrawable(final String imageUrl,
			final ImageView imageView, final int reqWidth, final int reqHeight,
			final IImageLoadedCallBack imageLoadedCallBack) {
		return loadDrawable(imageUrl, imageView, reqWidth, reqHeight, true,
				false, imageLoadedCallBack);
	}

	/**
	 * 加载图片, 指定需要加载的图片宽高
	 *
	 * @param imageUrl
	 *            ：图片url
	 * @param imageCallback
	 *            加载完成之后的回调接口
	 * @return
	 */
	@SuppressLint("HandlerLeak")
	public Bitmap loadDrawable(final String imageUrl,
			final ImageView imageView, final int reqWidth, final int reqHeight,
			boolean useMemCache, final boolean needCorner,
			final IImageLoadedCallBack imageCallback) {
		if (StringUtils.isBlank(imageUrl)) {
			return null;
		}
		/**
		 * 0、处理消息
		 */
		final Handler handler = new Handler(Looper.getMainLooper()) {
			public void handleMessage(Message message) {
				if (message.obj == null) {
					imageCallback.imageLoaded(imageView, null, imageUrl.trim());
				} else {
					imageCallback.imageLoaded(imageView, (Bitmap) message.obj,
							imageUrl.trim());
				}
			}
		};

		/**
		 * 1、查询cache里面是否有图片
		 */
		if (useMemCache) {
			final Bitmap bitmap = getBitmapFromCache(imageUrl);
			if (null != bitmap) {
				if (needCorner)
					return Util.getRoundedCornerBitmap(bitmap, 2);
				else
					return bitmap;

			}
		}

		try {
			if (executorService != null && !executorService.isTerminated()
					&& !executorService.isShutdown())
				executorService.submit(new Runnable() {
					@Override
					public void run() {
						try {
							final long startTime = System.currentTimeMillis();
							Bitmap bitmap = null;
							boolean isOk = false;
							CacheInfo cache = null;
							Message message;
							boolean ifFromNet = false;
							if (isNeedFileCache) {
								/**
								 * 2.1、从本地SD卡读取
								 */
								cache = CacheUtils.getFromCache(imageUrl.trim());

								/**
								 * 2.2、从网络中下载图片
								 */
								if (null == cache || !cache.isValid()) {
									if (null == cache) {
										cache = new CacheInfo(0, startTime
												+ mustImageExipreCheckTime,
												imageUrl.trim(), null);
									}
									isOk = downloadFromNet(imageUrl.trim(),
											cache);
									ifFromNet = true;
								} else {
									isOk = true;
								}

							} else {
								cache = new CacheInfo(0, startTime
										+ mustImageExipreCheckTime, imageUrl
										.trim(), null);
								isOk = downloadFromNet(imageUrl.trim(), cache);
								ifFromNet = true;
							}

							if (isOk && cache != null && cache.isValid()) {
								// if (ifFromNet) {
								// bitmap = decodeSampledBitmapFromByteArray(
								// cache.getValue(), reqWidth, reqHeight);
								// } else {
								// // 本地的不需要再采样
								// bitmap = decodeSampledBitmapFromByteArray(
								// cache.getValue(), 0, 0);
								// }
								bitmap = decodeSampledBitmapFromByteArray(
										cache.getValue(), reqWidth, reqHeight);
								// if (needCut) {
								// bitmap = ImageScaleUtils
								// .createScaledBitmap(bitmap,
								// reqWidth, reqHeight);
								// }
							}

							if (bitmap != null) {
								/**
								 * 2.3、保存到缓存
								 */
								putBitmapToCache(imageUrl.trim(), bitmap);
								if (needCorner) {
									message = handler.obtainMessage(0, Util
											.getRoundedCornerBitmap(bitmap, 2));
								} else {
									message = handler.obtainMessage(0, bitmap);
								}
								handler.sendMessage(message);

								/**
								 * 2.4、保存到本地SD卡上
								 */
								if (ifFromNet && isOk && null != bitmap
										&& cache != null && cache.isValid()) {
									saveFile(imageUrl.trim(), bitmap,
											cache.getLastModified(),
											cache.getExpires());
								}
							} else {
								message = handler.obtainMessage(0, null);
								handler.sendMessage(message);
							}

						} catch (Exception e) {
							Log.e(LOG_TAG, e.getMessage(), e);
						}
					}
				});
		} catch (Exception e) {
			Log.e(LOG_TAG, e.getMessage(), e);
		}

		return null;
	}

	/**
	 *
	 * @Title: decodeSampledBitmapFromByteArray
	 *
	 * @Description: 解析得到Bitmap，如果设置了reqWidth， reqHeight,会进行压缩
	 * @param @param data
	 * @param @param reqWidth
	 * @param @param reqHeight
	 * @param @return 设定文件
	 * @return Bitmap 返回类型
	 * @throws
	 */
	private Bitmap decodeSampledBitmapFromByteArray(byte[] data, int reqWidth,
			int reqHeight) {
		if (null == data || data.length <= 0) {
			return null;
		}
		final BitmapFactory.Options options = new BitmapFactory.Options();
		if (reqWidth <= 0 || reqHeight <= 0) {
			// 不需要进行压缩
			options.inPurgeable = true;
			options.inJustDecodeBounds = false;
			return BitmapFactory.decodeByteArray(data, 0, data.length, options);
		} else {
			// 先将inJustDecodeBounds设置为true，获取图片大小，并不解析图片
			options.inJustDecodeBounds = true;
			BitmapFactory.decodeByteArray(data, 0, data.length, options);
			// 计算inSampleSize值
			options.inSampleSize = calculateInSampleSize(options, reqWidth,
					reqHeight);
			// 使用获取到的inSampleSize再次解析图片
			options.inPurgeable = true;
			options.inJustDecodeBounds = false;
			return BitmapFactory.decodeByteArray(data, 0, data.length, options);
		}
	}

	/**
	 *
	 * @Title: calculateInSampleSize
	 *
	 * @Description: 计算inSampleSize
	 * @param @param options
	 * @param @param reqWidth
	 * @param @param reqHeight
	 * @param @return 设定文件
	 * @return int 返回类型
	 * @throws
	 */
	private int calculateInSampleSize(BitmapFactory.Options options,
			int reqWidth, int reqHeight) {
		// 源图片的高度和宽度
		final int height = options.outHeight;
		final int width = options.outWidth;
		int inSampleSize = 1;
		if (height > reqHeight || width > reqWidth) {
//			// 计算出实际宽高和目标宽高的比率
//			final int heightRatio = Math.round((float) height
//					/ (float) reqHeight);
//			final int widthRatio = Math.round((float) width / (float) reqWidth);
//			// 选择宽和高中最小的比率作为inSampleSize的值，这样可以保证最终图片的宽和高， 一定都会大于等于目标的宽和高
//			inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;

			final int halfWidth = width / 2;
			final int halfHeight = height / 2;
			// Calculate the largest inSampleSize value that is a power of 2 and keeps both
			// height and width larger than the requested height and width.
			while ((halfWidth / inSampleSize) > reqWidth && (halfHeight / inSampleSize) > reqHeight) {
				inSampleSize *= 2;
			}
		}
		return inSampleSize;
	}

	/**
	 *
	 * @Title: bitmap2Bytes
	 *
	 * @Description: Bitmap转成bytes
	 * @param @param bitmap
	 * @param @return 设定文件
	 * @return byte[] 返回类型
	 * @throws
	 */
	private byte[] bitmap2Bytes(Bitmap bitmap) {
		if (null == bitmap) {
			return null;
		}
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		bitmap.compress(Bitmap.CompressFormat.PNG, 100, bos);
		return bos.toByteArray();
	}

	/**
	 *
	 * @Title: asynSaveFile
	 *
	 * @Description: 缓存图片到本地SD卡
	 * @param @param key
	 * @param @param content
	 * @param @param lastModifyTime 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	private void saveFile(final String key, final Bitmap bitmap,
			final long lastModifyTime, final long expires) {
		// if (App.getInstance().sWorker != null)
		// App.getInstance().sWorker.post(new Runnable() {
		//
		// @Override
		// public void run() {
		// CacheUtils.saveToCache(key, lastModifyTime,
		// mustImageExipreCheckTime, content);
		// }
		// });
		final byte[] bytes = bitmap2Bytes(bitmap);
		CacheUtils.saveToCache(key, lastModifyTime, expires, bytes);
	}

	/**
	 * 清除内存
	 */
	@Override
	public void destroy() {
		if (executorService != null && !executorService.isTerminated()) {
			executorService.shutdownNow();
			executorService = null;
		}

		if (sHardBitmapCache != null) {
			sHardBitmapCache.evictAll();
		}

		if (sSoftBitmapCache != null) {
			for (SoftReference<Bitmap> reference : sSoftBitmapCache.values()) {
				if (reference != null && reference.get() != null
						&& !reference.get().isRecycled()) {
					reference.get().recycle();
					reference.clear();
				}
			}
		}
	}

	/**
	 *
	 * @Title: asyncLoadImage
	 * @Description: 异步加载图片
	 * @param asyncImageLoader
	 * @param imgView
	 * @param url
	 * @param resid
	 *            设定文件
	 *
	 *            void 返回类型
	 * @throws
	 */
	public static void asyncLoadImage(final AsyncImageLoader asyncImageLoader,
			final ImageView imgView, final String url, int resid) {
		final Bitmap drawable = asyncImageLoader.loadDrawable(url, imgView,
				new IImageLoadedCallBack() {

					@Override
					public void imageLoaded(final ImageView imageView,
							final Bitmap bitmap, final String imageUrl) {
						if (imageView != null && bitmap != null) {
							String tag = (String) imageView.getTag();
							if (tag != null && tag.equals(url)) {
								imageView.setImageBitmap(bitmap);
							}
						}

					}

				});
		if (drawable != null) {
			imgView.setImageBitmap(drawable);
		} else if (resid > 0) {
			imgView.setImageResource(resid);
		}
	}

}
