package com.tencent.weigou.util;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;

/**
 * 
 * @ClassName： ImageScaleUtils
 * 
 * @Description： 图片缩放工具类
 * @author wamiwen
 * @date 2013-11-29 下午4:10:23
 * 
 */
public class ImageScaleUtils {

	/**
	 * 
	 * @Title: createHeightScaledBitmap
	 * 
	 * @Description: 
	 *               以viewHeight为基准缩放bitmap，缩放后bitmap宽大于view宽则截掉两端，取bitmap中间view宽部分
	 *               缩放后bitmap宽小于view宽，两端留白，bitmap居中
	 * @param @param viewWidth
	 * @param @param viewHeight
	 * @param @param srcBitmap
	 * @param @return 设定文件
	 * @return Bitmap 返回类型
	 * @throws
	 */
	public static Bitmap createHeightScaledBitmap(final int viewWidth,
			final int viewHeight, final Bitmap srcBitmap) {
		if (srcBitmap == null) {
			return null;
		}
		Bitmap scaledBitmap;
		final int imgWidth = srcBitmap.getWidth();
		final int imgHeight = srcBitmap.getHeight();

		float viewScaleRatio = (float) viewHeight / (float) viewWidth;
		float bmScaleRatio = (float) imgHeight / (float) imgWidth;

		if (viewScaleRatio <= bmScaleRatio) {// 以宽为主,缩放
			float scaleRatio = (float) viewWidth / imgWidth;
			Matrix matrix = new Matrix();
			matrix.postScale(scaleRatio, scaleRatio);
			scaledBitmap = Bitmap.createBitmap(srcBitmap, 0, 0, imgWidth,
					imgHeight, matrix, true);
			float scaledHeight = imgHeight * scaleRatio;
			int diffHeight = (int) (scaledHeight - viewHeight) / 2;
			scaledBitmap = Bitmap.createBitmap(scaledBitmap, 0, diffHeight,
					viewWidth, viewHeight);
		} else {// 以高为主
			float scaleRatio = (float) viewHeight / imgHeight;
			Matrix matrix = new Matrix();
			matrix.postScale(scaleRatio, scaleRatio);
			scaledBitmap = Bitmap.createBitmap(srcBitmap, 0, 0, imgWidth,
					imgHeight, matrix, true);

			float scaledWidth = imgWidth * scaleRatio;
			int diffWidth = (int) (scaledWidth - viewWidth) / 2;
			scaledBitmap = Bitmap.createBitmap(scaledBitmap, diffWidth, 0,
					viewWidth, viewHeight);
		}
		return scaledBitmap;
	}

	// /**
	// *
	// * @Title: getWhiteBitmap
	// *
	// * @Description: 生成一个宽w，高h，颜色为白色的bitmap
	// * @param @param w
	// * @param @param h
	// * @param @return 设定文件
	// * @return Bitmap 返回类型
	// * @throws
	// */
	// private static Bitmap getWhiteBitmap(final int w, final int h) {
	// Bitmap bitmap = Bitmap.createBitmap(w, h, Config.ARGB_8888);
	// Canvas canvas = new Canvas(bitmap);
	// canvas.drawColor(Color.WHITE);
	// canvas.save(Canvas.ALL_SAVE_FLAG);
	// canvas.restore();
	// return bitmap;
	// }

	/**
	 * 
	 * @Title: getScaleRatio
	 * 
	 * @Description: 返回图片需要缩放的比例，根据图片的高宽比和显示图片的View的高宽比的大小关系，决定以View的高还是宽为基准缩放
	 * @param @param imgWidth 原图的宽
	 * @param @param imgHeight 原图的高
	 * @param @param viewWidth 显示图的View的宽
	 * @param @param viewHeight 显示图的View的高
	 * @param @return 设定文件
	 * @return float 图片需要缩放的比例
	 * @throws
	 */
	public static float getScaleRatio(final int imgWidth, final int imgHeight,
			final int viewWidth, final int viewHeight) {
		// 图片需要缩放的比例
		float scaleRatio = 0.0f;
		// 原图高宽比
		final float imgRatio = (float) imgHeight / imgWidth;
		// 用来显示图的View的高宽比
		final float viewRatio = (float) viewHeight / viewWidth;
		if (imgRatio >= viewRatio) {
			// 图片的高宽比比View的高宽比大，拉伸图片宽到View的宽，即以View的宽为基准缩放
			scaleRatio = (float) viewWidth / imgWidth;
		} else {
			// 图片的高宽比比View的高宽比小，拉伸图片高到View的高，即以View的高为基准缩放
			scaleRatio = (float) viewHeight / imgHeight;
		}

		return scaleRatio;
	}

}
