package com.tencent.weigou.util;

import android.app.Application;
import android.util.Log;
import com.tencent.stat.MtaSDkException;
import com.tencent.stat.StatAppMonitor;
import com.tencent.stat.StatConfig;
import com.tencent.stat.StatService;
import com.tencent.stat.common.StatConstants;
import com.tencent.weigou.base.App;

import java.net.URL;
import java.util.Properties;

/**
 * MTA工具类。如果后续确定用MTA来完成全部的统计工作，这里可以通过封装MTAService来完成对pageId的统计 User: ethonchan
 * Date: 13-10-14 Time: 下午4:05
 */
public class MTAUtils {

    private MTAUtils() {
    }

    private static boolean running = false;

    // Debug版的appkey
    private final static String APPKEY_DEBUG = "AJA1112LSJC1";

    // release版的appkey
    private final static String APPKEY_RELEASE = "AB62XSN3C1X5";

    // 最大有效耗时90s
    public final static int MAX_COST_TIME = 1000 * 90;

    /**
     * 启动MTA
     *
     * @param app     Application
     * @param isDebug true开发版，false正式版
     * @param channel app渠道号
     * @throws MtaSDkException         当MTA无法启动时会抛出此异常
     * @throws AlreadyStartedException 当MTA已启动时会抛出此异常
     */
    public static void startMTA(App app, boolean isDebug, String channel)
            throws MtaSDkException, AlreadyStartedException {
        if (!running) {
            String appKey = isDebug ? APPKEY_DEBUG : APPKEY_RELEASE;
            StatConfig.setAppKey(appKey);
            StatConfig.setDebugEnable(isDebug);
            StatConfig.setEnableSmartReporting(true);
            StatConfig.setEnableStatService(true);
            StatConfig.setMaxDaySessionNumbers(3);
            StatConfig.setSessionTimoutMillis(3 * 60 * 1000);
            StatConfig.setAutoExceptionCaught(true);
            StatService.startStatService(App.getInstance(), appKey,
                    StatConstants.VERSION);
            //  是否停止PV统计
            String pv = StatConfig.getCustomProperty("stopPV");
            if ("true".equals(pv)) {
                app.setMtaReportPV(false);
            }
            running = true;
        }
    }

    /**
     * 上报统计结果。如果本身禁用了统计功能，则不进行上报
     *
     * @param application
     * @param startTime   统计开始时间
     * @param monitor
     */
    public static void report(Application application, long startTime, StatAppMonitor monitor) {
        if (running) {
            // 保存接口耗时
            long costTime = (System.nanoTime() - startTime)
                    / Constants.NANO_SEC_PER_MILLSEC;
            // 对过大的耗时进行削尖
            if (costTime >= MTAUtils.MAX_COST_TIME) {
                costTime = MTAUtils.MAX_COST_TIME;
            }
            monitor.setMillisecondsConsume(costTime);
            // 上报接口统计信息
            StatService.reportAppMonitorStat(application, monitor);
        }
    }

    /**
     * 上报自定义事件。当发生某种关键时间，比如下单，支付等时可以上报到MTA方便运营自行分析。当发生某种关键时间，比如下单，
     * 支付等时可以上报到MTA方便运营自行分析
     *
     * @param eventId 事件ID
     * @param params  事件相关参数
     */
    public static void reportMTAEvent(String eventId, Properties params) {
        if (running) {
            StatService.trackCustomKVEvent(App.getInstance(), eventId, params);
        }
    }

    /**
     * MTA已完成启动异常
     */
    public static class AlreadyStartedException extends Exception {
        public AlreadyStartedException() {
            super("MTA has already started!");
        }
    }

    /**
     * 根据API名称生成一个默认的接口统计对象
     *
     * @param APIName
     * @return
     */
    public static StatAppMonitor getAppMonitor(String APIName) {
        if (StringUtils.isBlank(APIName)) {
            APIName = "unknown";
        }
        StatAppMonitor appMonitor = new StatAppMonitor(APIName);
        appMonitor.setReqSize(0);
        appMonitor.setRespSize(0);
        appMonitor.setReturnCode(-1);
        appMonitor.setResultType(StatAppMonitor.SUCCESS_RESULT_TYPE);
        // 不采样，全量上报
        appMonitor.setSampling(1);
        return appMonitor;
    }

    /**
     * 获取图片读取接口的统计对象
     *
     * @param urlStr 图片访问url
     * @return
     */
    public static StatAppMonitor getAppMonitorForImage(String urlStr) {
        String apiName = "getImage/getImage.xhtml";
        try {
            URL url = new URL(urlStr);
            apiName = apiName + "-" + url.getHost();
        } catch (Exception e) {
            Log.e("MTAUtils", "Error when parsing URL: " + urlStr, e);
        }

        return getAppMonitor(apiName);
    }

    /**
     * 从url中提取出API接口名
     *
     * @param url APP访问的API接口完整url
     * @return API接口名。http://mwg.com/api/a/b.xhtml?xxxxx的接口名就是a/b.xhtml
     */
    public static String getAPIName(String url) {
        String apiName = url;
        int startOffset = url.indexOf("api/");
        if (startOffset > -1)
        // 以API开头的接口
        {
            startOffset += 4;
        } else
        // 不是已API开头的接口
        {
            startOffset = 0;
        }

        int endOffset = url.indexOf("?");
        if (endOffset > -1) {
            apiName = url.substring(startOffset, endOffset);
        } else {
            apiName = url.substring(startOffset, url.length());
        }

        return apiName;
    }

    public static boolean isRunning() {
        return running;
    }
}
