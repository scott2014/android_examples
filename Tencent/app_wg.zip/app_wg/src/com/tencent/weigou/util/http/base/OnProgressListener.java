package com.tencent.weigou.util.http.base;

/**
 * 进度监听器
 * User: ethonchan
 * Date: 13-11-15
 * Time: 下午4:50
 */
public interface OnProgressListener {

    /**
     * 进度更新
     * @param progress  当前进度（完成为100）
     */
    public void onProgressUpdated(float progress);

    /**
     * 取消
     */
    public void onCancel();
}
