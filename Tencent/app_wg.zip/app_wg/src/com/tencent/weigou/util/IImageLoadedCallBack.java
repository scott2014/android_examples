package com.tencent.weigou.util;

import android.graphics.Bitmap;
import android.widget.ImageView;

/**
 * 回调接口 当图片加载完之后，会回调此接口
 * 
 * @author wendyhu
 * 
 */
public interface IImageLoadedCallBack {

	/**
	 * 当图片加载完成之后，会回调此接口
	 * 
	 * @param ImageView
	 *            渲染元素
	 * @param imageDrawable
	 *            渲染内容
	 * @param imageUrl
	 *            图片url
	 */
	public void imageLoaded(final ImageView imageView, final Bitmap bitmap, final String imageUrl);

}
