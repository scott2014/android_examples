package com.tencent.weigou.util.lbs;


import com.tencent.map.lbsapi.api.SOSOMapLBSApi;
import com.tencent.map.lbsapi.api.SOSOMapLBSApiResult;
import com.tencent.weigou.util.StringUtils;

/**
 * LBS工具类
 * User: ethonchan
 * Date: 13-10-25
 * Time: 上午11:27
 */
public class LBSUtils {

    private final static String LBS_APP_NAME = "weigou";

    private final static String LBS_APP_KEY = "6ZIJL-WOU7V-QAQJ4-DRAOL-NBSYJ";

    //  用户当前的位置信息
    private static Location loc;

    /**
     * 获取LBS实例
     *
     * @return LBS实例，或者null（当初始化lbs失败时）
     */
    public static SOSOMapLBSApi getLBSInstance() {
        SOSOMapLBSApi lbsApi = SOSOMapLBSApi.getInstance();
        boolean flag = lbsApi.verifyRegCode(LBS_APP_NAME, LBS_APP_KEY);
        if (flag) {
            return lbsApi;
        } else {
            return null;
        }
    }

    /**
     * 设置当前位置信息
     *
     * @param loc 设置用户当前的位置信息
     */
    public static synchronized void setLocation(Location loc) {
        LBSUtils.loc = loc;
    }

    /**
     * 获取当前位置信息
     *
     * @return 用户当前的位置信息或者NULL
     */
    public static Location getLocation() {
        if(loc == null){
            return Location.getDefault();
        }else{
            return loc;
        }
    }

    public static Location toLocation(SOSOMapLBSApiResult result) {
        Location loc = null;
        if (result != null) {
            loc = new Location();
            loc.latitude = result.Latitude;
            loc.longitude = result.Longitude;
            loc.altitude = result.Altitude;
            loc.accuracy = result.Accuracy;

            if (StringUtils.isNotBlank(result.Province)) {
                Location.AdminInfo info = new Location.AdminInfo();
                info.nation = result.Nation;
                info.province = result.Province;
                info.city = result.City;
                info.district = result.District;
                info.town = result.Town;
                info.village = result.Village;
                info.street = result.Street;
                info.streetNo = result.StreetNo;
                loc.adminInfo = info;
            }
        }

        return loc;
    }

}
