/**  
 * @Title: ConstantsUrl.java 
 * @Package com.tencent.weigou.util 
 * @author wendyhu
 * @date 2013-11-1 下午7:31:34 
 * @version V1.0  
 */
package com.tencent.weigou.util;

/**
 * @ClassName: ConstantsUrl
 * @Description: url相关
 * @author wendyhu
 * @date 2013-11-1 下午7:31:34
 */

public class ConstantsUrl {
	/**
	 * 获取订阅列表
	 * 
	 * 参数: tp：订阅类型,=1为品牌，=2为mall,=3为门店 nd: 是否需要订阅详情，>0则返回订阅的品牌,mall,门店信息
	 * 
	 * ps:pageSize,默认为10
	 * 
	 * pn:pageNo,默认为1,<0则不分页
	 */
	public static final String GET_SUBSCRIBE = "subscribe/list.xhtml";

	/**
	 * 个人中心URL
	 */
	public static final String MY_INFO = "user/myInfo.xhtml";

	/**
	 * 收藏商品列表
	 */
	public static final String MY_FAV_LIST = "favorite/list.xhtml";

	/**
	 * 删除收藏
	 */
	public static final String DEL_FAV_ITEM = "favorite/rmv.xhtml";

	/**
	 * 我的礼券列表
	 */
//	public static final String MY_CARD_LIST = "card/dealList.xhtml";
	public static final String MY_CARD_LIST = "card/myDeal.xhtml";

	/**
	 * 我的礼券详情
	 */
	public static final String MY_CARD_DETAIL = "card/dealDetail.xhtml";

	/**
	 * 礼券详情
	 */
	public static final String CARD_DETAIL = "card/detail.xhtml";

	/**
	 * 礼券支付
	 */
	public static final String CARD_PAY = "card/order.xhtml";
	/**
	 * 支付
	 */
	public static final String DEAL_PAY = "wxpay/genWXPayParam.xhtml";
	/**
	 * 逛一逛常量
	 */
	public static final String URL_MALL_DETAIL_MALL = "mall/guangDetail.xhtml";
	public static final String URL_SHOP_PAGER = "shop/listByCategory.xhtml";
	public static final String URL_SHOP_CARD_DETAIL = "shop/detailV2.xhtml";
	public static final String URL_MALL_BRAND_WALL = "shop/categoryMall.xhtml";
	public static final String URL_QUERY_SUB = "subscribe/check.xhtml";

	public static final String URL_SHOP_DETAIL = "item/list.xhtml";

	public static final String SHOPPING_INDEX = "mall/guangList.xhtml";
	public static final String SHOPPING_INDEX_BRAND = "brand/list.xhtml";
	public static final String SHOPPING_MALL_NAV = "shop/listShopByCategory.xhtml";
	public static final String SHOPPING_CIRCLE_NAV = "shop/categoryBc.xhtml";
	public static final String SHOPPING_CMDY_BY_CAT = "item/listByCategory.xhtml";
	public static final String SHOPPING_CMDY_BY_SHOP = "item/list.xhtml";
	public static final String SHOPPING_CMD_DETAIL = "item/detail.xhtml";
	public static final String SHOPPING_CMD_FAV = "favorite/add.xhtml";
	public static final String SHOPPING_CMDY_LIST_BY_IDS = "/item/listById.xhtml";
	/**
	 * 发现列表
	 */
	public static final String URL_DISCOVERY_LIST = "discover/list.xhtml";
	/**
	 * 品牌Page
	 */
	public static final String URL_BRAND_PAGE = "brand/page.xhtml";
	/**
	 * 品牌下门店列表
	 */
	public static final String URL_LIST_SHOP_BY_BRAND = "shop/listShopByBrand.xhtml";
	/**
	 * 门店Page
	 */
	public static final String URL_SHOP_PAGE = "shop/page.xhtml";
	/**
	 * 商场Page
	 */
	public static final String URL_MALL_PAGE = "mall/page.xhtml";
	/**
	 * 商场下促销门店
	 */
	public static final String URL_SHOP_PROMOTE = "shop/promotion.xhtml";

	/**
	 * 推荐关注
	 */
	public static final String URL_RECOM_SUBSCRIBE = "subscribe/guessYouLike.xhtml";
	/**
	 * 新增关注
	 */
	public static final String URL_ADD_SUBSCRIBE = "subscribe/add.xhtml";
	/**
	 * 取消关注
	 */
	public static final String URL_REMOVE_SUBSCRIBE = "subscribe/rmv.xhtml";
	/**
	 * 批量增加/删除关注
	 */
	public static final String URL_BATCH_SUBSCRIBE = "subscribe/handleList.xhtml";

	// 获取动态
	public static final String GET_FEEDS = "feeds/queryFeedsByUser.xhtml";

	// 本地动态缓存
	public static final String GET_CACHE_FEEDS = "feeds/feeds.cache";

	// 获取未读动态数量
	public static final String GET_UNREADED_FEEDS = "feeds/queryUnreadFeedsCount.xhtml";

	// 按城市获取礼券信息
	public static final String TICKETS_BY_CITY = "card/find.xhtml";

	// 按商场获取礼券信息
	public static final String TICKETS_BY_MALL = "card/list.xhtml";

	public static final String FEEDBACK = "feedback/commit.xhtml";

	// 登录接口
	public static final String LOGIN = "user/login.xhtml";

	// 按分类获取商场内的折扣品牌信息
	public static final String GET_MALL_DISCOUNTS = "shop/promotion.xhtml";

	// 按分类获取商场内的新品信息
	public static final String GET_MALL_NEW = "item/newItem.xhtml";

	/**
	 * 增加我的订单列表
	 */
	public static final String MY_DEAL_LIST_URL = "http://weigou.qq.com/prevwshop/wx/my/index.shtml?from=app&debug";

    //  微信在应用宝的下载页面
    public static final String WX_DOWNLOAD_PAGE = "http://weixin.qq.com/";

    //  检查更新
    public static final String CHECK_UPDATE = "update/check.xhtml";
}
