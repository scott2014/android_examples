package com.tencent.weigou.util;

import java.io.Serializable;

public class UrlParam implements Serializable {
	public static final long serialVersionUID = 1;

	private String title = "";
	private String url = "";

	public UrlParam(String param) {
		// 解析url
		param = StringUtils.trim(param);
		try {
			if (!StringUtils.isBlank(param)) {
				if (param.startsWith("title") || param.startsWith("Title")) {
					int start = param.indexOf("=");
					int end = param.indexOf("&");
					title = new String(param.substring(start + 1, end));

					String urlStr = new String(param.substring(end + 1));
					int urlStart = urlStr.indexOf("=");
					url = new String(urlStr.substring(urlStart + 1));
					/**
					 * Add URL encryption encryption string is added after "url"
					 * and before "="
					 */
					String encryptedUrl = new String(urlStr.substring(0,
							urlStart));
					String decryptedUrl = "";
					try {
						if (encryptedUrl.startsWith("url")) {
							encryptedUrl = encryptedUrl.substring(3);
						}
						if (!StringUtils.isBlank(encryptedUrl)) {
							decryptedUrl = CryptHelper.decrypt(encryptedUrl);
							if (decryptedUrl.startsWith("http://")) {
								url = decryptedUrl;
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}

				} else if (param.startsWith("url") || param.startsWith("Url")
						|| param.startsWith("URL")) {

					int start = param.indexOf("=");
					int end = param.lastIndexOf("&");
					url = new String(param.substring(start + 1, end));

					/**
					 * Add URL encryption encryption string is added after "url"
					 * and before "="
					 */
					String encryptedUrl = new String(param.substring(0, start));
					String decryptedUrl = "";
					try {
						if (encryptedUrl.startsWith("url")) {
							encryptedUrl = encryptedUrl.substring(3);
						}
						if (!StringUtils.isBlank(encryptedUrl)) {
							decryptedUrl = CryptHelper.decrypt(encryptedUrl);
							if (decryptedUrl.startsWith("http://")) {
								url = decryptedUrl;
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}

					String titleStr = new String(param.substring(end));
					int titleStart = titleStr.indexOf("=");
					title = new String(titleStr.substring(titleStart + 1));
				}
			}
		} catch (NullPointerException e) {
			title = "";
			url = "";
		} catch (IndexOutOfBoundsException e) {
			title = "";
			url = "";
		}

	}

	public String getTitle() {
		return title;
	}

	public String getUrl() {
		return url;
	}
}
