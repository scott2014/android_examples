package com.tencent.weigou.util;

/**
 * 环境配置信息类
 * 
 * @author wendyhu
 */
public class Env {
	/**
	 * 服务地址
	 */
	private String serverUrl = null;

	/**
	 * 静态资源地址
	 */
	private String serverStaticUrl = null;

	// env类型
	private int envType = IDC_ENV_TYPE;

	// env类型string
	private String envTypeStr = "IDC环境";

	private static Env idcEnv = null;
	private static Env gammaEnv = null;
	private static Env betaEnv = null;

	/**
	 * env类型
	 */
	public final static int IDC_ENV_TYPE = 0;
	public final static String IDC_ENV_STR = "IDC环境";

	public final static int GAMMA_ENV_TYPE = 1;
	public final static String GAMMA_ENV_STR = "GAMMA环境";

	public final static int BETA_ENV_TYPE = 2;
	public final static String BETA_ENV_STR = "BETA环境";

	static {
		// 初始化IDC环境信息
		idcEnv = new Env();
		idcEnv.serverUrl = "http://app.weigou.qq.com/api/";
		idcEnv.serverStaticUrl = "http://static.paipaiimg.com/mwg/";
		idcEnv.envType = IDC_ENV_TYPE;
		idcEnv.envTypeStr = IDC_ENV_STR;

		// 初始化GAMMA环境信息
		gammaEnv = new Env();
		gammaEnv.serverUrl = "http://api.gamma.xpay.buy.qq.com/api/";
		gammaEnv.serverStaticUrl = "http://static.paipaiimg.com/mwg/pre/";
		gammaEnv.envType = GAMMA_ENV_TYPE;
		gammaEnv.envTypeStr = GAMMA_ENV_STR;

		// 初始化GAMMA环境信息
		betaEnv = new Env();
		betaEnv.serverUrl = "http://api.gamma.xpay.buy.qq.com/api/";
		betaEnv.serverStaticUrl = "http://static.paipaiimg.com/mwg/pre/";
		betaEnv.envType = BETA_ENV_TYPE;
		betaEnv.envTypeStr = BETA_ENV_STR;
	}

	/**
	 * 避免外部实例化
	 */
	private Env() {
	}

	/**
	 * 当前env类型
	 * 
	 * @return
	 */
	public int getEnvType() {
		return envType;
	}

	/**
	 * 当前env类型
	 * 
	 * @return
	 */
	public String getEnvTypeStr() {
		return envTypeStr;
	}

	public String getServerUrl() {
		return serverUrl;
	}

	public String getServerStaticUrl() {
		return serverStaticUrl;
	}

	public static Env getIdc() {
		return idcEnv;
	}

	public static Env getGamma() {
		return gammaEnv;
	}

	public static Env getBeta() {
		return betaEnv;
	}

	public static Env getEnv(int type) {
		Env ret = idcEnv;
		switch (type) {
		case GAMMA_ENV_TYPE:
			ret = gammaEnv;
			break;
		case BETA_ENV_TYPE:
			ret = betaEnv;
			break;
		}
		return ret;
	}
}
