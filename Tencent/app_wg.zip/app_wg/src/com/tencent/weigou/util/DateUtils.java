/**   
 * @Title: DateFormatUtil.java 
 * @Package com.qq.buy.util 
 * @author Wendyhu wendyhu@tencent.com  
 * @date 2012-6-12 下午3:15:47 
 * @version V1.0   
 */
package com.tencent.weigou.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * @ClassName: DateFormatUtil
 * @author wendyhu wendyhu@tencent.com
 * @date 2012-6-12 下午3:15:47
 * 
 */
public class DateUtils {

	public static final String YYYY_MM_DD_HH_MM = "yyyy-MM-dd HH:mm";
	public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";

	/**
	 * 
	 * @Title: CST2L
	 * @Description: cst 时间转成long
	 * @param s
	 *            cst时间
	 * @return long 返回类型
	 * 
	 * @throws
	 */
	public static long CST2L(String s) {
		long t = System.currentTimeMillis();
		DateFormat df = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss 'GMT'",
				Locale.US);
		// 把字符串转换成CST日期类型
		Date date;
		try {
			if (s != null && s.length() > 1) {
				date = df.parse(s);
				t = date.getTime();
			}
		} catch (ParseException e) {
		}

		return t;
	}

	/**
	 * 
	 * @Title: CST2L
	 * @Description: cst 时间转成long
	 * @param s
	 *            cst时间
	 * @return long 返回类型
	 * 
	 * @throws
	 */
	public static String getTime(long date) {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss E");
		return df.format(new Date(date));
	}

	/**
	 * 
	 * @Title: getTime
	 * 
	 * @param @param date
	 * @param @param formatStr
	 * @param @return 设定文件
	 * @return String 返回类型
	 * @throws
	 */
	public static String getTime(long date, String formatStr) {
		DateFormat df = new SimpleDateFormat(formatStr);
		return df.format(new Date(date));
	}

	/**
	 * 
	 * @Title: CST2L
	 * @Description: cst 时间转成long
	 * @param s
	 *            cst时间
	 * @return long 返回类型
	 * 
	 * @throws
	 */
	public static String L2CST(long date) {
		DateFormat df = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss 'GMT'",
				Locale.US);
		return df.format(new Date(date));
	}

	/**
	 * 
	 * @Title: Long2Str
	 * @Description: Long 转化成十六进制str
	 * @param val
	 * @return String 返回类型
	 * 
	 * @throws
	 */
	public static String Long2HexStr(long val) {
		String str = "0";
		try {
			str = String.format("%16s", Long.toHexString(val))
					.replace(' ', '0');
		} catch (Exception e) {
			str = String.format("%16s", Long.toHexString(0)).replace(' ', '0');
		}

		return str;
	}

	/**
	 * 
	 * @Title: hexStr2Long
	 * @Description: 十六进制 转化成long
	 * @param val
	 * @return String 返回类型
	 * 
	 * @throws
	 */
	public static long hexStr2Long(String val) {
		long ret = 0;
		try {
			ret = Long.parseLong(val, 16);
		} catch (Exception e) {
		}

		return ret;
	}

	// /**
	// * 毫秒转成"yyyy-MM-dd HH:mm"格式时间字符串
	// *
	// * @param longStr
	// * @return
	// */
	// public static String long2DateString(String longStr) {
	// String TIME_FORMAT = "yyyy-MM-dd HH:mm";
	// SimpleDateFormat simpleDateFormat = new SimpleDateFormat(TIME_FORMAT,
	// Locale.CHINA);
	// simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+08:00"));
	// Date date = new Date(Long.parseLong(longStr));
	// return simpleDateFormat.format(date);
	// }

}
