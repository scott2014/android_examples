package com.tencent.weigou.util.region;

import java.io.File;
import java.io.InputStream;
import java.lang.Exception;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.lang.StringBuilder;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import android.app.Application;
import com.tencent.weigou.util.Constants;
import com.tencent.weigou.util.region.adapter.RegionManagerAdapter;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.res.AssetManager;
import android.util.Log;

/**
 * 地址信息管理器
 * 
 * @author ethonchan
 */
public class RegionManager extends RegionManagerAdapter {

	// 负责读取地址信息的assetMgr
	protected AssetManager mAssetMgr;

	private static RegionManager mInstance;

	protected RegionManager(Application context) {
		super(context);
		mAssetMgr = context.getAssets();
	}

	/**
	 * 获取到地址管理器的单例。除APP外，其他函数没有必要调用此方法，通过App获取即可
	 * 
	 * @param appContext
	 *            app上下文
	 * @return 地址管理器的单例
	 */
	public static RegionManagerAdapter getInstance(Application appContext) {
		if (mInstance == null) {
			synchronized (appContext) {
				if (mInstance == null) {
					mInstance = new RegionManager(appContext);
				}
			}
		}

		return mInstance;
	}

	@Override
	public List<RegionVo> getProvinceList() {
		if (mProvinces != null) {
			return mProvinces;
		}

		mProvinces = new ArrayList<RegionVo>(31);
		InputStream ins = null;
		try {
			ins = mAssetMgr.open(getProvinceFileName(null),
					AssetManager.ACCESS_BUFFER);
			byte[] bytes = new byte[ins.available()];
			ins.read(bytes);
			JSONObject json = new JSONObject(new String(bytes));
			@SuppressWarnings("unchecked")
			Iterator<String> iter = json.keys();
			while (iter.hasNext()) {
				String regionId = iter.next();
				String province = json.optString(regionId, null);

				if (province != null) {
					mProvinces.add(new RegionVo(province, regionId));
				}
			}

			// 按照省份名称排序
			Collections.sort(mProvinces);
		} catch (JSONException e) {
			mProvinces = null;
			String msg = "Exception when parsing province-json file.";
			Log.e(TAG, msg + e.getMessage(), e);
		} catch (Exception e) {
			mProvinces = null;
			Log.e(TAG, e.getMessage(), e);
		} finally {
			if (ins != null) {
				try {
					ins.close();
				} catch (Exception e) {
					Log.e(TAG, e.getMessage(), e);
					ins = null;
				}
			}
		}
		return mProvinces;
	}

	@Override
	public List<RegionVo> getCityList(String provinceId) {
		if (mLRUCityList != null && mLRUCityList.parentId.equals(provinceId))
		// 上次使用过的列表信息跟这次请求的ID相同
		{
			return mLRUCityList.children;
		}

		InputStream ins = null;
		mLRUCityList = null;
		try {
			String fName = getProvinceFileName(provinceId);
			ins = mAssetMgr.open(fName, AssetManager.ACCESS_BUFFER);
			byte[] bytes = new byte[ins.available()];
			ins.read(bytes);
			JSONObject json = new JSONObject(new String(bytes));
			List<RegionVo> cityList = parseJson(json);

			// 将最近使用城市排序
			Collections.sort(cityList);

			// 保存到最近使用对象中
			mLRUCityList = new LRURegionList();
			mLRUCityList.parentId = provinceId;
			mLRUCityList.children = cityList;
		} catch (JSONException e) {
			mLRUCityList = null;
			String msg = "Exception when parsing City-json file. ProvinceId = "
					+ provinceId;
			Log.e(TAG, msg + e.getMessage(), e);
		} catch (Exception e) {
			mLRUCityList = null;
			Log.e(TAG, e.getMessage(), e);
		} finally {
			if (ins != null) {
				try {
					ins.close();
				} catch (Exception e) {
					Log.e(TAG, e.getMessage(), e);
					ins = null;
				}
			}
		}

		return mLRUCityList == null ? null : mLRUCityList.children;
	}

	@Override
	public List<RegionVo> getDistrictList(String cityId) {
		if (mLRUDistrictList != null
				&& mLRUDistrictList.parentId.equals(cityId))
		// 上次使用过的区信息与本次请求的相同
		{
			return mLRUDistrictList.children;
		}

		if (mLRUCityList == null)
		// 必须先请求城市信息，然后才能请求区信息
		{
			return null;
		}

		InputStream ins = null;
		mLRUDistrictList = null;
		try {
			String provinceId = mLRUCityList.parentId;
			String pFileName = getProvinceFileName(provinceId);

			ins = mAssetMgr.open(pFileName, AssetManager.ACCESS_BUFFER);
			byte[] bytes = new byte[ins.available()];
			ins.read(bytes);
			JSONObject pJson = new JSONObject(new String(bytes));

			java.lang.Object cityObj = pJson.opt(cityId);
			if (cityObj != null && cityObj instanceof JSONArray) {
				JSONObject distObj = ((JSONArray) cityObj).optJSONObject(1);

				List<RegionVo> distList = new ArrayList<RegionVo>(
						distObj.length());
				@SuppressWarnings("unchecked")
				Iterator<String> iter = distObj.keys();
				while (iter.hasNext()) {
					String id = iter.next();
					String name = distObj.optString(id, null);

					if (name != null) {
						distList.add(new RegionVo(name, id));
					}
				}

				// 将最近使用区排序
				Collections.sort(distList);

				// 保存到最近使用对象中
				mLRUDistrictList = new LRURegionList();
				mLRUDistrictList.parentId = cityId;
				mLRUDistrictList.children = distList;
			}
		} catch (JSONException e) {
			mLRUDistrictList = null;
			String msg = "Exception when parsing dist-json file. CityId = "
					+ cityId;
			Log.e(TAG, msg + e.getMessage(), e);
		} catch (Exception e) {
			mLRUDistrictList = null;
			Log.e(TAG, e.getMessage(), e);
		} finally {
			if (ins != null) {
				try {
					ins.close();
				} catch (Exception e) {
					Log.e(TAG, e.getMessage(), e);
					ins = null;
				}
			}
		}

		return mLRUDistrictList == null ? null : mLRUDistrictList.children;
	}

	@Override
	public int getRegionLevel(String regionId) {
		String[] ids = parseRegionId(regionId);
		if (ids == null) {
			return -1;
		} else if (ids[2] != null) {
			return REGION_LEVEL_DISTRICT;
		} else if (ids[1] != null) {
			return REGION_LEVEL_CITY;
		} else {
			return REGION_LEVEL_PROVINCE;
		}
	}

	@Override
	public String[] parseRegionId(String regionId) {
		if (regionId == null || regionId.length() != 6) {
			return null;
		}
		String[] ids = new String[3];

		// 解析省份ID
		String provinceId = regionId.substring(0, 2) + "0000";
		List<RegionVo> provList = getProvinceList();
		for (RegionVo prov : provList) {
			if (prov != null && prov.getId().equals(provinceId)) {
				ids[0] = provinceId;
				break;
			} else {
				continue;
			}
		}
		if (ids[0] == null)
		// 如果省份ID不对，那么说明regionId有误
		{
			return null;
		}

		// 解析城市ID
		String cityId = regionId.substring(0, 4) + "00";
		List<RegionVo> cityList = getCityList(ids[0]);
		for (RegionVo city : cityList) {
			if (city != null) {
				String id = city.getId();
				if (id.equals(cityId)) {
					ids[1] = cityId;
					break;
				} else if (id.equals(regionId))
				// 可能是直辖市
				{
					ids[1] = regionId;
					return ids;
				}
			}
		}

		// 解析区ID
		if (!cityId.equals(regionId)) {
			ids[2] = regionId;
		}

		return ids;
	}

	@Override
	public String getAddressInChinese(String regionId) {
		String[] ids = parseRegionId(regionId);
		if (ids == null) {
			return null;
		}
		StringBuilder sb = new StringBuilder();

		if (ids[0] != null)
		// 得到省份str
		{
			List<RegionVo> provList = getProvinceList();
			for (RegionVo prov : provList) {
				if (prov != null && prov.getId().equals(ids[0])) {
					sb.append(prov.getName());
					sb.append(" ");
					break;
				}
			}
		}

		if (ids[1] != null)
		// 得到城市str
		{
			List<RegionVo> cityList = getCityList(ids[0]);
			for (RegionVo city : cityList) {
				if (city != null && city.getId().equals(ids[1])) {
					sb.append(city.getName());
					sb.append(" ");
					break;
				}
			}
		}

		if (ids[2] != null)
		// 得到区str
		{
			List<RegionVo> distList = getDistrictList(ids[1]);
            if(distList != null){
			    for (RegionVo dist : distList) {
			    	if (dist != null && dist.getId().equals(ids[2])) {
			    		sb.append(dist.getName());
			    		sb.append(" ");
			    		break;
			    	}
			    }
            }
		}

		return sb.toString();
	}

	@Override
	public String getProvinceId(String provinceStr) {
		if (provinceStr == null) {
			return Constants.DEFAULT_REGION_ID;
		}

		List<RegionVo> provList = getProvinceList();
		for (RegionVo prov : provList) {
			if (prov.getName().equals(provinceStr)) {
				return prov.getId();
			}
		}

		return Constants.DEFAULT_REGION_ID;
	}

	@Override
	public String getCityRegionId(String provinceId, String cityName) {
		if (cityName == null) {
			return null;
		}

		List<RegionVo> cityList = getCityList(provinceId);
		if (cityList != null) {
			for (RegionVo city : cityList) {
				if (city.getName().equals(cityName)) {
					return city.getId();
				}
			}
		}

		return null;
	}

	public String getCityId(String cityName) {
		if (cityName == null) {
			return null;
		}
		String provinceId = getProvinceId(cityName);
		return getCityRegionId(provinceId, cityName);
	}

	private String getProvinceFileName(String provinceId) {
		// 存放地址信息的文件夹名
		String dirName = "js" + File.separator + "region";
		if (provinceId == null) {
			return dirName + File.separator + "provinces.js";
		} else {
			return dirName + File.separator + provinceId + ".js";
		}
	}

	/**
	 * 将JSON数据转换成为相应的地址信息列表
	 * 
	 * @param json
	 *            要转换的JSON数据
	 * @return 转换后的地址信息列表
	 */
	private List<RegionVo> parseJson(JSONObject json) {
		List<RegionVo> children = new ArrayList<RegionVo>(json.length());
		@SuppressWarnings("rawtypes")
		Iterator ids = json.keys();
		while (ids.hasNext()) {
			Object id = ids.next();

			Object obj = json.opt(id.toString());
			if (obj == null) {
				continue;
			}
			if (obj instanceof String) {
				children.add(new RegionVo(obj.toString(), id.toString()));
			} else if (obj instanceof JSONArray) {
				JSONArray array = (JSONArray) obj;
				String name = array.optString(0);
				if (name == null)
					continue;
				else
					children.add(new RegionVo(name, id.toString()));
			}
		}

		Collections.sort(children);
		return children;
	}

}
