package com.tencent.weigou.util.http;

import android.util.Log;
import com.tencent.stat.StatAppMonitor;
import com.tencent.weigou.base.json.JsonResult;
import com.tencent.weigou.util.Constants;
import com.tencent.weigou.util.MTAUtils;
import com.tencent.weigou.util.StringUtils;
import com.tencent.weigou.util.http.base.HttpRequest;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * POST方式请求JSON
 * User: ethonchan
 * Date: 13-10-23
 * Time: 下午12:08
 */
public class JSONPoster extends HttpRequest<JsonResult> {

    //  回车换行
    public final static String CRLF = "\r\n";

    //  POST传输时候的分隔符/结束符前缀
    public final static String POST_PREFIX = "--";

    //  POST传输时候用到的分割符
    public final static String POST_BOUNDARY = UUID.randomUUID().toString();

    //  POST传输时候用到的结束符
    public final static String POST_END = POST_PREFIX + POST_BOUNDARY + POST_PREFIX + CRLF;

    public JSONPoster() {
        super(false);
    }

    @Override
    protected void onReadyToConnect(String urlStr, StatAppMonitor monitor, Object... params) {
        //  输出参数日志
        Log.d(TAG, "start POST url: " + urlStr);

        if (params != null && params.length > 0) {
            Object mapObj = params[0];
            if (mapObj instanceof Map) {
                Map map = (Map) mapObj;
                Iterator<Map.Entry> iter = map.entrySet().iterator();
                while (iter.hasNext()) {
                    Map.Entry entry = iter.next();
                    Log.d(TAG, entry.getKey() + "=" + entry.getValue());
                }
            }
        }
    }

    @Override
    protected void onConnected(String urlStr, HttpURLConnection conn) {
        ;
    }

    @Override
    protected void sendHttpParams(OutputStream outs, String urlStr, StatAppMonitor monitor, Object... params) throws IOException {
        String paramStr = "";
        //  拼接POST参数
        if (!cancelled && params != null && params.length > 0) {
            Map<String, String> map = (Map<String, String>) params[0];
            StringBuilder sb = concatParamsForPost(map);
            if (!cancelled && sb != null) {
                paramStr = sb.toString();
            }
        }

        if (!cancelled) {
            byte[] bytes = paramStr.getBytes(Constants.ENCODE_CHARSET);
            outs.write(bytes);
            //  结束符
            byte[] endBytes = POST_END.getBytes(Constants.ENCODE_CHARSET);
            outs.write(endBytes);
            outs.close();

            //  记录请求大小
            monitor.setReqSize(StringUtils.getByteLength(urlStr, Constants.DECODE_CHARSET) + bytes.length + endBytes.length);
        }
    }

    @Override
    protected JsonResult onGetResponseData(byte[] data, StatAppMonitor monitor) {
        JsonResult jsonResult = null;
        if (!cancelled) {
            String strReturn = "";
            if (!cancelled) {
                strReturn = new String(data);
            }

            try {
                if (!cancelled && StringUtils.isBlank(strReturn)) {
                    monitor.setResultType(StatAppMonitor.FAILURE_RESULT_TYPE);
                } else if (!cancelled) {
                    JSONObject json = new JSONObject(strReturn);
                    jsonResult = new JsonResult();
                    jsonResult.setJson(json);

                    if (jsonResult.isSuccess()) {
                        monitor.setResultType(StatAppMonitor.SUCCESS_RESULT_TYPE);
                    } else {
                        //monitor.setResultType(StatAppMonitor.LOGIC_FAILURE_RESULT_TYPE);
                        //  这里本应该是要设置为LOGIC_FAILURE的，但是由于MTA网页版不区分success与logic_failure，故统一使用failure
                        monitor.setResultType(StatAppMonitor.FAILURE_RESULT_TYPE);
                    }
                }
            } catch (JSONException e) {
                jsonResult = null;
                monitor.setResultType(StatAppMonitor.FAILURE_RESULT_TYPE);
            }
        }

        if (!cancelled) {
            Log.d(TAG, "result: " + (jsonResult != null ? jsonResult.toString() : "null"));
        } else {
            Log.d(TAG, "JSONPoster has been cancelled!");
        }
        return jsonResult;
    }

    @Override
    protected HttpURLConnection preProcessHttp(HttpURLConnection conn) {
        conn = super.preProcessHttp(conn);

        conn.setDoInput(true);
        conn.setDoOutput(true);
        conn.setUseCaches(false);
        try {
            conn.setRequestMethod("POST");
        } catch (Exception e) {
            //ignore
        }
        conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + POST_BOUNDARY);

        return conn;
    }

    /**
     * 将参数拼接成为POST方式需要的形式
     *
     * @param params 参数
     * @return 拼接后的字符
     */
    private static StringBuilder concatParamsForPost(Map<String, String> params) {
        StringBuilder sb = new StringBuilder();
        if (params != null) {
            Iterator<Map.Entry<String, String>> iter = params.entrySet().iterator();
            while (iter.hasNext()) {
                Map.Entry<String, String> entry = iter.next();
                sb.append(POST_PREFIX).append(POST_BOUNDARY);
                sb.append(CRLF);
                sb.append("Content-Disposition: form-data; ");
                sb.append("name=\"").append(entry.getKey()).append("\"");
                sb.append(CRLF);
                sb.append(CRLF);
                sb.append(entry.getValue());
                sb.append(CRLF);
            }
        }
        return sb;
    }


    /**
     * Post方式获取JSON
     *
     * @param urlStr 要请求的接口url
     * @param params POST方式传递的参数
     * @return 接口返回的json对象
     * @throws Exception
     */
    public JsonResult doPost(String urlStr, Map<String, String> params) throws Exception {
        //  参数检查
        paramsNotNull(urlStr);

        String apiName = MTAUtils.getAPIName(urlStr);
        JsonResult result = doRequest(apiName, urlStr, params);

        return result;
    }
}
