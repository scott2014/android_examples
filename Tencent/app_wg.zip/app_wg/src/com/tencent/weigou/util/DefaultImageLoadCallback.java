package com.tencent.weigou.util;

import android.graphics.Bitmap;
import android.widget.ImageView;

/**
 * 图片下载回调的默认实现，便于一般场景下的使用
 * User: ethonchan
 * Date: 13-11-6
 * Time: 下午8:11
 */
public class DefaultImageLoadCallback implements IImageLoadedCallBack{
    @Override
    public void imageLoaded(final ImageView imageView, final Bitmap bitmap, final String imageUrl) {
        if(imageView != null){
            Object tag = imageView.getTag();
            if(tag != null && tag.toString().equals(imageUrl)){
                imageView.setImageBitmap(bitmap);
            }
        }
    }
}
