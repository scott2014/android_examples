package com.tencent.weigou.util.db;

import android.annotation.TargetApi;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;

/**
 * DB基类
 * User: ethonchan
 * Date: 13-11-5
 * Time: 下午2:24
 */
public abstract class DatabaseHelper extends SQLiteOpenHelper {
    protected static final int VERSION = 2;

    protected final String mTableName;

    public DatabaseHelper(Context context, String tableName) {
        super(context, tableName, null, VERSION);
        mTableName = tableName;
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        super.onDowngrade(db, oldVersion, newVersion);
        dropTable(db);
        onCreate(db);
    }

    /**
     * 删除当前表
     * @param db
     */
    public void dropTable(SQLiteDatabase db){
        db.execSQL("DROP TABLE IF EXISTS " + mTableName);
    }
}
