/**  
 * @Title: L.java 
 * @Package com.tencent.weigou.util 
 * @Description: TODO(用一句话描述该文件做什么) 
 * @author wendyhu  
 * @date 2013-11-18 下午4:39:15 
 * @version V1.0  
 */
package com.tencent.weigou.util;

import com.tencent.weigou.BuildConfig;

import android.util.Log;

/**
 * @ClassName: L
 * @Description: 日志打印
 * @author wendyhu
 * @date 2013-11-18 下午4:39:15
 */

public class L {

	public static void v(Throwable t) {
		log(Log.VERBOSE, t, null);
	}

	public static void v(Object s1, Object... args) {
		log(Log.VERBOSE, null, s1, args);
	}

	public static void v(Throwable t, Object s1, Object... args) {
		log(Log.VERBOSE, t, s1, args);
	}

	public static void d(Throwable t) {
		log(Log.DEBUG, t, null);
	}

	public static void d(Object s1, Object... args) {
		log(Log.DEBUG, null, s1, args);
	}

	public static void d(Throwable t, Object s1, Object... args) {
		log(Log.DEBUG, t, s1, args);
	}

	public static void i(Throwable t) {
		log(Log.INFO, t, null);
	}

	public static void i(Object s1, Object... args) {
		log(Log.INFO, null, s1, args);
	}

	public static void i(Throwable t, Object s1, Object... args) {
		log(Log.INFO, t, s1, args);
	}

	public static void w(Throwable t) {
		log(Log.WARN, t, null);
	}

	public static void w(Object s1, Object... args) {
		log(Log.WARN, null, s1, args);
	}

	public static void w(Throwable t, Object s1, Object... args) {
		log(Log.WARN, t, s1, args);
	}

	public static void e(Throwable t) {
		log(Log.ERROR, t, null);
	}

	public static void e(Object s1, Object... args) {
		log(Log.ERROR, null, s1, args);
	}

	public static void e(Throwable t, Object s1, Object... args) {
		log(Log.ERROR, t, s1, args);
	}

	private static void log(final int pType, final Throwable t,
			final Object s1, final Object... args) {
		if (pType == Log.ERROR || BuildConfig.DEBUG) {
			final StackTraceElement[] stackTraceElements = Thread
					.currentThread().getStackTrace();
			StackTraceElement stackTraceElement = null;
			if (stackTraceElements != null && stackTraceElements.length > 4)
				stackTraceElement = stackTraceElements[4];
			String fullClassName = "";
			String className = "";
			int lineNumber = 0;
			String method = "";
			if (stackTraceElement != null) {
				fullClassName = stackTraceElement.getClassName();
				className = fullClassName.substring(fullClassName
						.lastIndexOf(".") + 1);
				lineNumber = stackTraceElement.getLineNumber();
				method = stackTraceElement.getMethodName();
			}

			final String tag = className + ":" + lineNumber;
			final StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(method);
			stringBuilder.append("(): ");

			if (s1 != null) {
				final String message = (args == null) ? s1.toString() : String
						.format((String) s1, args);
				stringBuilder.append(message);
			}

			switch (pType) {
			case Log.VERBOSE:
				if (t != null) {
					Log.v(tag, stringBuilder.toString(), t);
				} else {
					Log.v(tag, stringBuilder.toString());
				}
				break;

			case Log.DEBUG:
				if (t != null) {
					Log.d(tag, stringBuilder.toString(), t);
				} else {
					Log.d(tag, stringBuilder.toString());
				}
				break;

			case Log.INFO:
				if (t != null) {
					Log.i(tag, stringBuilder.toString(), t);
				} else {
					Log.i(tag, stringBuilder.toString());
				}
				break;

			case Log.WARN:
				if (t != null) {
					Log.w(tag, stringBuilder.toString(), t);
				} else {
					Log.w(tag, stringBuilder.toString());
				}
				break;

			case Log.ERROR:
				if (t != null) {
					Log.e(tag, stringBuilder.toString(), t);
				} else {
					Log.e(tag, stringBuilder.toString());
				}
				break;
			}
		}
	}
}
