package com.tencent.weigou.util.http;

import android.util.Log;
import com.tencent.stat.StatAppMonitor;
import com.tencent.weigou.base.json.JsonResult;
import com.tencent.weigou.util.Constants;
import com.tencent.weigou.util.MTAUtils;
import com.tencent.weigou.util.StringUtils;
import com.tencent.weigou.util.http.base.HttpRequest;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.HttpURLConnection;

/**
 * JSON获取类 User: ethonchan Date: 13-10-22 Time: 下午4:43
 */
public class JSONGetter extends HttpRequest<JsonResult> {

	/**
	 * JSON请求工具类，请求方式为GET
	 * 
	 * @param useCache
	 *            true使用缓存，false不使用缓存
	 */
	public JSONGetter(boolean useCache) {
		super(useCache);
	}

	/**
	 * Get方式获取JSON数据
	 * 
	 * @param urlStr
	 *            要获取数据的接口url
	 * @return 接口返回的JSON数据
	 * @throws Exception
	 */
	public JsonResult doGet(String urlStr) throws Exception {
		// 检查参数
		paramsNotNull(urlStr);
		JsonResult result = null;

		if (!cancelled) {
			String apiName = MTAUtils.getAPIName(urlStr);
			result = doRequest(apiName, urlStr);
		}

		return result;
	}

	@Override
	protected void onReadyToConnect(String urlStr, StatAppMonitor monitor,
			Object... params) {
		// 输出日志
		Log.d(TAG, "start GET url: " + urlStr);

		// 保存请求包大小
		try {
			if (!cancelled) {
				monitor.setReqSize(StringUtils.getByteLength(urlStr,
						Constants.DECODE_CHARSET));
			}
		} catch (Exception e) {
			monitor.setReqSize(0);
		}
	}

    @Override
    protected void onConnected(String urlStr, HttpURLConnection conn) {
        ;
    }

    @Override
    protected JsonResult onAuthNeeded() {
        JsonResult jsonResult = new JsonResult();
        jsonResult.setAuthNeeded(true);
        return jsonResult;
    }

    @Override
	protected JsonResult onGetResponseData(byte[] data, StatAppMonitor monitor) {
		JsonResult jsonResult = null;
		String strReturn = "";
		if (!cancelled) {
			strReturn = new String(data);
		}

		try {
			if (!cancelled && StringUtils.isBlank(strReturn)) {
				monitor.setResultType(StatAppMonitor.FAILURE_RESULT_TYPE);
			} else if (!cancelled) {
				JSONObject json = new JSONObject(strReturn);
				jsonResult = new JsonResult();
				jsonResult.setJson(json);

				if (jsonResult.isSuccess()) {
					monitor.setResultType(StatAppMonitor.SUCCESS_RESULT_TYPE);
				} else {
					//monitor.setResultType(StatAppMonitor.LOGIC_FAILURE_RESULT_TYPE);
                    //  这里本应该是要设置为LOGIC_FAILURE的，但是由于MTA网页版不区分success与logic_failure，故统一使用failure
                    monitor.setResultType(StatAppMonitor.FAILURE_RESULT_TYPE);
				}
			}
		} catch (JSONException e) {
			jsonResult = null;
			monitor.setResultType(StatAppMonitor.FAILURE_RESULT_TYPE);
		}

		if (!cancelled) {
			Log.d(TAG, "result: " + strReturn);
		} else {
			Log.d(TAG, "JSONGetter has been cancelled!");
		}
		return jsonResult;
	}
}
