package com.tencent.weigou.util;

import android.graphics.Bitmap;
import com.tencent.weigou.cache.CacheInfo;
import com.tencent.weigou.cache.CacheUtils;

import java.io.ByteArrayOutputStream;

/**
 * 图片工具
 * User: ethonchan
 * Date: 13-11-21
 * Time: 上午11:11
 */
public class ImageUtils {
    /**
     * 将给定的bitmap转换成对应的比特数组
     * @param bitmap
     * @return
     */
    public static byte[] toBytes(Bitmap bitmap){
        if(bitmap == null){
            return null;
        }

        ByteArrayOutputStream outs = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, outs);
        byte[] result = outs.toByteArray();
        IOUtils.closeQuietly(outs);
        return result;
    }

    /**
     * 从缓存中取出图片
     * @param url
     * @return
     */
    public static Bitmap getBitmapFromLocal(String url){
        Bitmap bitmap = null;
        CacheInfo cache = CacheUtils.getFromCache(url);
        if(cache != null){
            bitmap = cache.toBitmap();
        }
        return bitmap;
    }
}
