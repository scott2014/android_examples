package com.tencent.weigou.util;

/**
 * MTA自定义事件信息汇总
 * @author ethonchan
 * @created 2014-02-10
 */
public class MTAConstants {

    //  读取用户db的事件ID
    public final static String ID_READ_USER_DB = "read_user_db_fail";

    // MTA统计的缓存命中率事件ID
    public final static String ID_CACHE_MATCH = "cache_stat";

    //  code换token失败
    public final static String ID_GET_TOKEN_FAILED = "get_token_fail";

    //  初始化SDCARD错误
    public final static String ID_INIT_SDCARD_FAILED = "init_sdcard_fail";

    //  APK文件下载失败
    public final static String ID_APK_DOWNLOAD_FAIL = "apk_download_fail";

    public final static String KEY_MSG = "msg";

    public final static String KEY_CODE = "code";

    public final static String KEY_VALUE = "hst";

    public final static String KEY_PARAM_1 = "param1";

    public final static String KEY_PARAM_2 = "param2";

    public final static String KEY_PARAM_3 = "param3";
}
