package com.tencent.weigou.util;

import android.graphics.Bitmap;
import com.tencent.weigou.base.json.JsonResult;
import com.tencent.weigou.util.http.BitmapGetter;
import com.tencent.weigou.util.http.JSONGetter;
import com.tencent.weigou.util.http.JSONPoster;

import java.util.Map;

/**
 * HTTP工具类 User: ethonchan Date: 13-10-15 Time: 上午10:10
 */
public class HttpUtils {
	private HttpUtils() {
	}

	/**
	 * GET方式请求JSON，不使用缓存
	 * 
	 * @param urlStr
	 *            请求的url
	 * @throws Exception
	 */
	public static JsonResult doGet(String urlStr) throws Exception {
		return doGet(urlStr, false);
	}

	/**
	 * GET方式请求JSON
	 * 
	 * @param urlStr
	 *            请求的url
	 * @param useCache
	 *            是否使用本地缓存。true使用，false不使用
	 * @throws Exception
	 */
	public static JsonResult doGet(String urlStr, boolean useCache)
			throws Exception {
		JSONGetter getter = new JSONGetter(useCache);
		JsonResult jsonResult = getter.doGet(urlStr);
		return jsonResult;
	}

	/**
	 * POST方式请求JSON
	 * 
	 * @param urlStr
	 *            请求的url
	 * @param params
	 *            请求的参数
	 * @throws Exception
	 */
	public static JsonResult doPost(String urlStr, Map<String, String> params)
			throws Exception {
		JSONPoster poster = new JSONPoster();
		JsonResult jsonResult = poster.doPost(urlStr, params);
		return jsonResult;
	}

	/**
	 * 获取图片
	 * 
	 * @param urlStr
	 *            要获取的图片url
	 * @return url指向的图片内容，可能为null
	 * @throws Exception
	 */
	public static Bitmap downloadImage(String urlStr) throws Exception {
		return downloadImage(urlStr, false);
	}

	/**
	 * 获取图片
	 * 
	 * @param urlStr
	 *            要获取的图片url
	 * @param useCache
	 *            是否使用本地缓存。true使用，false不使用
	 * @return
	 * @throws Exception
	 */
	public static Bitmap downloadImage(String urlStr, boolean useCache)
			throws Exception {
		BitmapGetter getter = new BitmapGetter(useCache);
		Bitmap bitmap = getter.doGet(urlStr);
		return bitmap;
	}
}
