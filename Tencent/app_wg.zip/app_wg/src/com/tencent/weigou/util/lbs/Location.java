package com.tencent.weigou.util.lbs;

/**
 * 用户位置信息
 * User: ethonchan
 * Date: 13-10-25
 * Time: 下午4:46
 */
public class Location {
    //  纬度
    public double latitude;

    //  经度
    public double longitude;

    //  海拔
    public double altitude;

    //  精度
    public double accuracy;

    //  行政划分
    public AdminInfo adminInfo;

    /**
     * 行政划分
     */
    public static class AdminInfo {

        //  国家
        public String nation;

        //  省
        public String province;

        //  市
        public String city;

        //  区
        public String district;

        //  镇
        public String town;

        //  村
        public String village;

        //  街道
        public String street;

        //  门牌号
        public String streetNo;
    }

    /**
     * APP使用的默认地址
     * @return
     */
    public static Location getDefault(){
        Location loc = new Location();
        loc.longitude = 113.934348;
        loc.latitude = 22.540432;
        loc.altitude = 0D;
        loc.accuracy = 0D;

        AdminInfo admin = new AdminInfo();
        admin.nation = "中国";
        admin.province="广东省";
        admin.city="深圳市";
        admin.district = "南山区";
        admin.street="深南大道";
        admin.streetNo = "Unknown";

        loc.adminInfo = admin;
        return loc;
    }
}
