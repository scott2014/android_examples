package com.tencent.weigou.util;

/**
 * 数字相关的工具类
 * User: ethonchan
 * Date: 13-10-21
 * Time: 下午4:23
 */
public class NumberUtils {

    /**
     * 将byte数组反解为long
     * @param bytes 即将要被反解为long的数组，数组从0-7依次表示从高到低各位的取值。如[00, 00, 00, 00, 00, 00, 7F, FF]表示0x7FFF
     * @return  反解后的数字
     */
    public static long parseByte(byte[] bytes){
        long value = 0L;
        if(bytes != null){
            final int size = bytes.length > 8 ? 8 : bytes.length;
            int pos = 0;
            while(pos < size){
                value <<= 8;
                long temp = bytes[pos] & 0xff;
                value |= temp;
                pos ++ ;
            }
        }
        return value;
    }

    /**
     * 将Long转换为byte[]
     * @param value  long类型数组
     * @return  转换后的byte数组，数组从0-7依次表示从高到低的各位取值。如0x7FFF将会被转换为[00, 00, 00, 00, 00, 00, 7F, FF]
     */
    public static byte[] parseLong(long value){
        byte[] bytes = new byte[8];
        int pos = 0;
        while(pos < 8){
            long temp = value >>> (56 - pos * 8);
            bytes[pos] = (byte)temp;
            pos ++;
        }
        return bytes;
    }
}
