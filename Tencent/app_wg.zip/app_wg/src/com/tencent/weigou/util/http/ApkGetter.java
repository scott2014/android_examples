package com.tencent.weigou.util.http;

import android.util.Log;
import com.tencent.stat.StatAppMonitor;
import com.tencent.weigou.util.*;
import com.tencent.weigou.util.http.base.HttpRequest;

import java.io.File;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.util.Properties;

/**
 * APK下载类
 * User: ethonchan
 * Date: 13-11-15
 * Time: 下午4:43
 */
public class ApkGetter extends HttpRequest<String> {

    //  apk存储路径
    private File mApkFile;

    //  apk的url
    private String url = "";

    /**
     * APK下载类
     *
     * @param apkFile APK本地存储地址
     */
    public ApkGetter(File apkFile) {
        super(false);
        this.mApkFile = apkFile;

        if (apkFile == null) {
            cancelled = true;
        }
    }

    /**
     * 下载APK
     *
     * @param urlStr APK所在的url
     * @throws Exception
     */
    public void doGet(String urlStr) throws Exception{
        // 检查参数
        paramsNotNull(urlStr);

        this.url = urlStr;

        if (!cancelled) {
            String apiName = "apk/update.xhtml";
            doRequest(apiName, urlStr);
        }
    }

    @Override
    protected void onReadyToConnect(String urlStr, StatAppMonitor monitor, Object... params) {
        // 输出日志
        Log.d(TAG, "start GET url: " + urlStr);

        // 保存请求包大小
        try {
            if (!cancelled) {
                monitor.setReqSize(StringUtils.getByteLength(urlStr,
                        Constants.DECODE_CHARSET));
            }
        } catch (Exception e) {
            monitor.setReqSize(0);
        }
    }

    @Override
    protected void onConnected(String urlStr, HttpURLConnection conn) {
        ;
    }

    @Override
    protected String onGetResponseData(byte[] data, StatAppMonitor monitor) {
        //  将APK存储到本地SDCARD
        FileOutputStream outs = null;
        try {
            int len = data == null ? 0 : data.length;
            if (len > 0) {
                outs = new FileOutputStream(mApkFile);
                outs.write(data);
                monitor.setResultType(StatAppMonitor.SUCCESS_RESULT_TYPE);
                outs.close();
                outs = null;
            }else{
                Properties prop = new Properties();
                prop.setProperty(MTAConstants.KEY_MSG, "data len=0");
                prop.setProperty(MTAConstants.KEY_PARAM_1, url);
                MTAUtils.reportMTAEvent(MTAConstants.ID_APK_DOWNLOAD_FAIL, prop);

                monitor.setResultType(StatAppMonitor.FAILURE_RESULT_TYPE);
            }
        } catch (Exception e) {
            String msg = e == null ? "NULL" : e.getMessage();
            Log.e(TAG, msg);
            Properties prop = new Properties();
            prop.setProperty(MTAConstants.KEY_MSG, msg);
            prop.setProperty(MTAConstants.KEY_PARAM_1, url);
            MTAUtils.reportMTAEvent(MTAConstants.ID_APK_DOWNLOAD_FAIL, prop);

            monitor.setResultType(StatAppMonitor.FAILURE_RESULT_TYPE);
        }finally{
            if(outs != null){
                IOUtils.closeQuietly(outs);
            }
        }

        if (mApkFile != null) {
            Log.d(TAG, "APK has been saved into " + mApkFile.toString());
        }
        return null;
    }

    /**
     * APK下载监听器
     */
    public interface APKDownloadListener {

        /**
         * APK下载完成
         *
         * @param apkFile 存储到本地的APK路径
         */
        public void onAPKDownloaded(File apkFile);
    }
}
