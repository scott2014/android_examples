package com.tencent.weigou.util;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Environment;
import android.os.SystemClock;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import com.tencent.weigou.base.App;

import java.io.*;
import java.security.MessageDigest;
import java.util.Properties;
import java.util.zip.Adler32;

/**
 * 系统工具 User: ethonchan Date: 13-10-14 Time: 下午6:44
 */
public class SysUtils {
	public final static String TAG = "SysUtils";

	// 网络类型--cmnet
	public final static String NETWORK_WIFI = "wifi";

	// 网络类型--cmwap
	public static final String NETWORK_CMWAP = "cmwap";

    public static File mDirInSdcard = null;

	// 当前网络类型
	private static String curNetworkType = "";
	private static String phoneInfo = "";
	private static long diffTime;
	static {
		long l = System.currentTimeMillis();
		long l1 = SystemClock.uptimeMillis();
		diffTime = l - l1;
	}

	/**
	 * 获取包名
	 * 
	 * @param ctx
	 *            上下文
	 * 
	 * @return
	 */
	public static String getPackName(Context ctx) {
		String ret = "";
		PackageManager pkgMgr = ctx.getPackageManager();
		String pkgName = ctx.getPackageName();
		try {
			ret = pkgMgr.getPackageInfo(pkgName, 0).versionName;
			if (ret != null) {
				ret = ret.trim().replaceAll(" ", "") + "" + getChannelId(ctx);
                ret = ret.trim();
			}
		} catch (NameNotFoundException e) {
			Log.e(TAG, "getPackName failed");
		}

		return ret;
	}

	/**
	 * 获取渠道Id
	 * 
	 * @param ctx
	 * @return
	 */
	public static String getChannelId(Context ctx) {
		if (ctx == null) {
			return "";
		}
		String ret = "";
		InputStream ins = null;
		byte[] buffer = new byte[32];
		try {
			ins = ctx.getAssets().open("channel.ini");
			ins.read(buffer);
			if (buffer != null)
				ret = new String(buffer, Constants.DECODE_CHARSET);
			if (ret != null) {
				ret = ret.trim();
				int index = ret.indexOf("=");
				if (index > 0) {
					ret = ret.substring(index + 1);
				}
			}
		} catch (Exception e) {
			Log.e(TAG, e.getMessage(), e);
		} finally {
			if (ins != null) {
				try {
					ins.close();
				} catch (IOException e) {
					Log.e(TAG, e.getMessage(), e);
				}
			}

		}
		return ret;
	}

    /**
     * 获取渠道Id
     * @param ctx
     * @param defaultValue   默认返回值
     * @return
     */
    public static String getChannelId(Context ctx, String defaultValue){
        String result = defaultValue;
        try{
            getChannelId(ctx);
        }catch(Exception e){
            Log.e(TAG, "Exception when getChannelId", e);
        }
        return result;
    }

	/**
	 * 当前是否有网络
	 * 
	 * @return true有网络，false无网络
	 */
	public static boolean isNetworkAvaliable() {
		Object service = App.getInstance().getSystemService(
				Context.CONNECTIVITY_SERVICE);
		if (service != null) {
			ConnectivityManager connService = (ConnectivityManager) service;
			NetworkInfo info = connService.getActiveNetworkInfo();
			if (info != null && info.isAvailable()
					&& info.getState() == NetworkInfo.State.CONNECTED) {
				if (ConnectivityManager.TYPE_WIFI == info.getType()) {
					curNetworkType = NETWORK_WIFI;
				} else {
					curNetworkType = info.getExtraInfo();
				}
				return true;
			}
		}

		return false;
	}

	/**
	 * 获取当前的网络类型名称。
	 * 
	 * @return 当前的网络类型名称, 如WIFI, cmnet, cmwap等
	 */
	public static String getNetworkType() {
		if (StringUtils.isEmpty(curNetworkType)) {
			// 如果网络信息为空，则再尝试检查一次
			isNetworkAvaliable();
		}
		return curNetworkType;
	}

	/**
	 * 得到给定字符的MD5值
	 * 
	 * @param content
	 *            要处理的字符串
	 * @param defaultMD5
	 *            默认返回的MD5值
	 * @return 给定字符串加密后的MD5值。如果有异常发生则会返回给定的字符
	 */
	public static String getMD5(String content, String defaultMD5) {
        byte[] bytes = null;
        try {
            bytes = content.getBytes(Constants.DECODE_CHARSET);
        } catch (Exception e) {
            bytes = null;
        }
        return getMD5(bytes, defaultMD5);
	}

    /**
     * 得到给定byte数组的MD5值
     * @param bytes
     * @param defaultMD5
     * @return
     */
    public static String getMD5(byte[] bytes, String defaultMD5){
        StringBuilder md5 = new StringBuilder();
        try{
            MessageDigest digest = MessageDigest.getInstance("MD5");
            digest.update(bytes);
			byte[] result = digest.digest();

			for (byte b : result) {
				int val = ((int) b) & 0xff;
				md5.append(Integer.toHexString(val));
			}
        }catch (Exception e){
            // ignore
			md5.delete(0, md5.length());
			if (defaultMD5 != null) {
				md5.append(defaultMD5);
			}
        }
        return md5.toString();
    }

	/**
	 * 得到给定字符串的ADLER32取值
	 * 
	 * @param url
	 *            要处理的字符串
	 * @param defaultValue
	 *            默认返回的值
	 * @return 给定字符串处理后得到的ALDER32取值。如果有异常发生则会返回给定的默认值
	 */
	public static long getADLER(String url, long defaultValue) {
		long value = defaultValue;
		if (StringUtils.isNotBlank(url)) {
			byte[] bytes = null;
			try {
				bytes = url.getBytes(Constants.DECODE_CHARSET);
				value = getADLER(bytes, defaultValue);
			} catch (UnsupportedEncodingException e) {
				// ignore
				value = defaultValue;
			}
		}
		return value;
	}

	/**
	 * 得到给定byte数组的ADLER32取值
	 * 
	 * @param bytes
	 *            要处理的byte数组
	 * @param defaultValue
	 *            默认返回值
	 * @return 给定byte数组处理后得到的ADLER32取值。如果有异常发生则会返回给定的默认值
	 */
	public static long getADLER(byte[] bytes, long defaultValue) {
		long value = defaultValue;
		try {
			Adler32 adler = new Adler32();
			adler.update(bytes);
			value = adler.getValue();
		} catch (Exception e) {
			// ignore
			value = defaultValue;
		}
		return value;
	}

	/**
	 * 得到APP在sdcard上的根目录
	 * 
	 * @return 
	 *         APP在sdcard上的根目录。如果sdcard不可写，返回NULL；如果目录不存在则创建；如果创建失败或者目录不可写，返回NULL
	 */
	public static File getAppDirectoryOnSdcard() {
        if(mDirInSdcard == null){
    		try {
    			if (isSdcardIsMounted()) {
    				mDirInSdcard = Environment.getExternalStorageDirectory();
    				File directory = null;
    				if (mDirInSdcard != null) {
    					directory = new File(mDirInSdcard.getPath() + File.separator
    							+ "Tencent" + File.separator + "weigou");
    				}
    				if (directory == null) {
    					;
    				} else if (directory.exists() && directory.isDirectory()) {
    					if (directory.canWrite()) {
    						mDirInSdcard = directory;
    					}
    				} else {
    					boolean flag = directory.mkdirs();
    					if (flag) {
    						mDirInSdcard = directory;
    					}
    				}
    			}
    		} catch (Exception e) {
    			// 异常的时候就上报
    			Properties params = new Properties();
    			params.put(MTAConstants.KEY_MSG, e == null ? "Null" : e.getMessage());
    			MTAUtils.reportMTAEvent(MTAConstants.ID_INIT_SDCARD_FAILED, params);
    		}
        }

		return mDirInSdcard;
	}

	/**
	 * 在app的sdcard上生成某个目录
	 * 
	 * @param filePath
	 *            目录名称
	 * @return
	 */
	public static File getDirInSdcard(String filePath) {
		File targetDir = null;
		try {
			File baseDir = getAppDirectoryOnSdcard();
			if (baseDir != null) {
				targetDir = new File(baseDir.getPath() + File.separator
						+ filePath);
				if (targetDir.exists()) {
					if (!targetDir.canWrite()) {
						targetDir = null;
					}
				} else if (!targetDir.mkdirs()) {
					targetDir = null;
				}
			}
		} catch (Exception e) {
			// ignore
		}

		return targetDir;
	}

	/**
	 * 将某个的viewCache分享出去
	 * 
	 * @param view
	 *            要分享的view
	 * @param fileName
	 *            分享图片的临时文件名，至少三个字符
	 * @param desc
	 *            描述性文字
	 * @return 临时图片文件
	 */
	public static File shareViewCache(View view, String fileName, String desc) {
		if (view == null) {
			return null;
		}
		Context ctx = view.getContext();
		view.setDrawingCacheEnabled(true);

		Bitmap bitmap = view.getDrawingCache(true);
		OutputStream out = null;
		File imageFile = null;
		fileName = (fileName == null) ? "" : fileName;
		try {
			imageFile = File.createTempFile(fileName, ".jpg", null);
			Log.d("test", "imgFile = " + imageFile.toString());
			out = new FileOutputStream(imageFile);
			if (bitmap != null && out != null)
				bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
			bitmap = null;
		} catch (Exception e) {
			Log.e(TAG, e.getMessage(), e);
		} finally {
			if (out != null) {
				try {
					out.flush();
					out.close();
					out = null;
				} catch (IOException e) {
					Log.e(TAG, e.getMessage(), e);
				}
			}
		}
		shareImageWithText(ctx, imageFile, desc);

		return imageFile;
	}

	/**
	 * 分享图片+文字
	 * 
	 * @param context
	 *            调用者
	 * @param imgFile
	 *            要分享的图片
	 * @param desc
	 *            与图片一起分享的文字
	 * @return true分享成功，false分享失败
	 */
	public static boolean shareImageWithText(Context context, File imgFile,
			String desc) {
		if (imgFile == null) {
			return shareText(context, desc);
		} else if (context == null || !imgFile.exists() || !imgFile.canRead()) {
			return false;
		} else {
			if (desc == null) {
				desc = "QQ网购";
			}

			Uri uri = Uri.fromFile(imgFile);
			Intent intent = new Intent(Intent.ACTION_SEND);
			// 这样会导致人人的分享直接搞成图片，如果设成text/plain将会导致两个微博的图片分享失败
			intent.setType("image/*");
			intent.putExtra(Intent.EXTRA_TEXT, desc);
			// 添加对短信分享的支持
			intent.putExtra("sms_body", desc);
			intent.putExtra(Intent.EXTRA_STREAM, uri);

			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

			context.startActivity(Intent.createChooser(intent, "分享"));
			return true;
		}
	}

	/**
	 * 分享文字
	 * 
	 * @param text
	 *            要分享的文字
	 * @param context
	 *            调用者
	 * @return true分享成功，false分享失败
	 */
	public static boolean shareText(Context context, String text) {
		if (context == null) {
			return false;
		} else {
			if (text == null) {
				text = "";
			}

			Intent intent = new Intent(Intent.ACTION_SEND);
			intent.setType("text/plain");
			intent.putExtra(Intent.EXTRA_TEXT, text);
			// 添加对短信分享的支持
			intent.putExtra("sms_body", text);

			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

			context.startActivity(Intent.createChooser(intent, "分享"));
			return true;
		}
	}

	/**
	 * sdcard是否已经挂载
	 * 
	 * @return true已经挂载完成，false未挂载
	 */
	public static boolean isSdcardIsMounted() {
		return Environment.getExternalStorageState().equals("mounted");
	}

	/**
	 * 生成mkey
	 * 
	 * @return
	 */
	public synchronized static String generateMkey(Context ctx) {
		String imei = null;
		try {
			imei = ((TelephonyManager) ctx
					.getSystemService(Context.TELEPHONY_SERVICE)).getDeviceId();
			if ("000000000000000".equals(imei))
				imei = null;
		} catch (Exception e) {
			imei = null;
		}
		if (imei == null) {
			String androidId = Secure.getString(ctx.getContentResolver(),
					Secure.ANDROID_ID);
			if (!"9774d56d682e549c".equals(androidId)) {
				imei = "0" + androidId;
			} else {
				String sysInfo = getSysInfo();
				sysInfo = sysInfo == null ? "" : sysInfo;
				sysInfo += System.nanoTime();
				String md5 = getMD5(sysInfo, "");
				imei = "0-F" + md5.substring(0, 14);
			}
		} else {
			imei = "0-" + imei;
		}
		return imei;
	}

	/**
	 * 
	 * @Title: getSysInfo
	 * @Description: 获取系统信息
	 * @return String 返回类型
	 * 
	 * @throws
	 */
	public static String getSysInfo() {
		if (phoneInfo == null || phoneInfo.length() < 1) {
			phoneInfo = "Product: " + android.os.Build.PRODUCT;
			phoneInfo += ", CPU_ABI: " + android.os.Build.CPU_ABI;
			phoneInfo += ", TAGS: " + android.os.Build.TAGS;
			phoneInfo += ", VERSION_CODES.BASE: "
					+ android.os.Build.VERSION_CODES.BASE;
			phoneInfo += ", MODEL: " + android.os.Build.MODEL;
			phoneInfo += ", SDK: " + android.os.Build.VERSION.SDK;
			phoneInfo += ", VERSION.RELEASE: "
					+ android.os.Build.VERSION.RELEASE;
			phoneInfo += ", DEVICE: " + android.os.Build.DEVICE;
			phoneInfo += ", DISPLAY: " + android.os.Build.DISPLAY;
			phoneInfo += ", BRAND: " + android.os.Build.BRAND;
			phoneInfo += ", BOARD: " + android.os.Build.BOARD;
			phoneInfo += ", FINGERPRINT: " + android.os.Build.FINGERPRINT;
			phoneInfo += ", ID: " + android.os.Build.ID;
			phoneInfo += ", MANUFACTURER: " + android.os.Build.MANUFACTURER;
			phoneInfo += ", USER: " + android.os.Build.USER;
			phoneInfo += ", TIME: " + android.os.Build.TIME;
		}
		return phoneInfo;
	}

    /**
     * 获取app当前的版本类型信息
     * @param application
     * @return  App当前的版本信息，默认为DEBUG版
     */
    public static VersionType getVersionType(Application application){
        VersionType type = VersionType.DEBUG;
        if(application != null){
            try{
                PackageManager pkg = application.getPackageManager();
			    PackageInfo info = pkg.getPackageInfo("com.tencent.weigou",
					PackageManager.GET_SIGNATURES);
			    String signature = info.signatures[0].toCharsString();
			    String md5 = SysUtils.getMD5(signature, "");
			    boolean isReleaseKey = "1195d95f684d7f234044c27a774bcc".equals(md5);
                if(!isReleaseKey)
                //DEBUG版
                {
                    type = VersionType.DEBUG;
                }else{
                    ApplicationInfo app = application.getApplicationInfo();
                    if(app != null && (app.flags & ApplicationInfo.FLAG_DEBUGGABLE) > 0)
                    //  GAMMA版
                    {
                        type = VersionType.GAMMA;
                    }else{
                        type = VersionType.RELEASE;
                    }
                }
            }catch(Exception e){
                Log.d(TAG, "Exception when getVersionType", e);
            }
        }

        return type;
    }

    /**
     * 得到APP当前的版本号
     * @param application
     * @return
     */
    public static int getAppVersion(Application application){
        int ver = 0;
        try{
            PackageManager mgr = application.getPackageManager();
            String pkgName = application.getPackageName();
            PackageInfo info = mgr.getPackageInfo(pkgName, 0);
            ver = info.versionCode;
        }catch(Exception e){
            Log.e(TAG, "Exception when getAppVersion", e);
        }
        return ver;
    }
}
