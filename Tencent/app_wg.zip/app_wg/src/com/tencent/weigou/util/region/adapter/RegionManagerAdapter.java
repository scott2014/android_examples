package com.tencent.weigou.util.region.adapter;

import android.app.Application;
import com.tencent.weigou.util.region.RegionVo;

import java.util.List;

/**
 * 地址信息管理类 该类可以提供所有省、市、区三级的信息列表
 * 
 * @author ethonchan
 * 
 */
public abstract class RegionManagerAdapter {

	// 日志
	public final String TAG;

	// 省
	public final static int REGION_LEVEL_PROVINCE = 1;

	// 市
	public final static int REGION_LEVEL_CITY = 2;

	// 区
	public final static int REGION_LEVEL_DISTRICT = 3;

	// 默认省份
	public final static String DEFAULT_PROVINCE = "广东省";

	// 全国的省份信息
	protected List<RegionVo> mProvinces;

	// 最近使用过的省市的城市列表
	protected LRURegionList mLRUCityList;

	// 最近使用过的城市的地区列表
	protected LRURegionList mLRUDistrictList;

	protected RegionManagerAdapter(Application context) {
		TAG = getClass().getSimpleName();
	}

	/**
	 * 得到按拼音首字母大写排序的省份信息
	 * 
	 * @return
	 */
	public abstract List<RegionVo> getProvinceList();

	/**
	 * 得到给定省份的城市列表
	 * 
	 * @param provinceId
	 *            给定的省份ID
	 * @return 如给定的省份ID有误或IOException，则返回null。否则返回城市列表
	 */
	public abstract List<RegionVo> getCityList(String provinceId);

	/**
	 * 得到给定城市的区列表
	 * 
	 * @param cityId
	 *            给定的城市ID
	 * @return 如给定的城市ID有误（不正确或者没有区）或IOException，则返回null。否则返回分区列表
	 */
	public abstract List<RegionVo> getDistrictList(String cityId);

	/**
	 * 得到某个regionId的level
	 * 
	 * @param regionId
	 * @return 省、市、区三个级别，异常时返回-1
	 */
	public abstract int getRegionLevel(String regionId);

	/**
	 * 将给定的regionId解析为省、市、区三个级别对应的regionId
	 * 
	 * @param regionId
	 * @return [省ID，市ID，区ID]。若某个ID无，则用null替代
	 */
	public abstract String[] parseRegionId(String regionId);

	public abstract String getAddressInChinese(String regionId);

	public abstract String getProvinceId(String provinceStr);

	public abstract String getCityRegionId(String provinceId, String cityName);

	public abstract String getCityId(String cityName);

	/**
	 * 最近使用的节点信息，用于缓存最近使用过的地址信息
	 * 
	 * @author ethonchan
	 * 
	 */
	public class LRURegionList {
		// 上一级节点的RegionID
		public String parentId;

		// 本级节点的相关信息
		public List<RegionVo> children;
	}
}
