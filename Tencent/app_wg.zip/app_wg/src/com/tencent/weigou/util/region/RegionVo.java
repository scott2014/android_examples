package com.tencent.weigou.util.region;

import com.tencent.weigou.base.model.vo.CommonVo;

/**
 * 省、市、区地址信息类
 * 
 * @author ethonchan
 * 
 */
public class RegionVo extends CommonVo implements Comparable<RegionVo> {
	private String name;
	private String id;

	/**
	 * 构造一个类来存放地址信息
	 * 
	 * @param addressName
	 * @param addressId
	 */
	public RegionVo(String addressName, String addressId) {
		name = addressName;
		id = addressId;
	}

	/**
	 * 得到地址
	 * 
	 * @return 地址名称
	 */
	public String getName() {
		return name;
	}

	/**
	 * 地址在拍拍上的ID
	 * 
	 * @return 地址ID
	 */
	public String getId() {
		return id;
	}

	@Override
	public String toString() {
		return name;
	}

	@Override
	public int compareTo(RegionVo another) {
        int anHash = another == null ? 0 : another.hashCode();
	    return hashCode() - anHash;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RegionVo other = (RegionVo) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;

		return true;
	}
}