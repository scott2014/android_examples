package com.tencent.weigou.util;

/**
 * 全局常量 User: ethonchan Date: 13-10-14 Time: 下午6:46
 */
public class Constants {

	// 微信AppID
	public static final String WX_APP_ID = "wxf8b4f85f3a794e77";

	public static class ShowMsgActivity {
		public static final String STitle = "showmsg_title";
		public static final String SMessage = "showmsg_message";
		public static final String BAThumbData = "showmsg_thumb_data";
	}

	public static final String NETWORK_HEADER_USER_AGENT = "User-Agent";

	public static final String DEFAULT_USER_AGENT = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.15 Safari/537.1";

	// 一毫秒有多少纳秒
	public final static long NANO_SEC_PER_MILLSEC = 1000 * 1000;

	// HTTP返回内容的解码字符集
	public static final String DECODE_CHARSET = "utf-8";

	// HTTP返回内容的编码字符集
	public static final String ENCODE_CHARSET = "utf-8";

	// toast时间
	public final static int TOAST_NORMAL_LONG = 2000;

	// 默认邮编
	public final static String DEFAULT_REGION_ID = "440000";

	/**
	 * 品牌ID
	 */
	public static final int BRAND_ID = 1;
	/**
	 * MallID
	 */
	public static final int MALL_ID = 2;
	/**
	 * 店铺ID
	 */
	public static final int SHOP_ID = 3;

	public static final int DIALOG_PROGRESS = 0;
	public static final int DIALOG_SERVICE_UNAVALIABLE = 1;
	public static final int DIALOG_CUSTOM = 2;
	public static final int DIALOG_INFO = 3;
	public static final int DIALOG_YESNO = 4;

	public static final String MALL = "mall";
	public static final String BRAND = "brand";

    //  检查更新时android的plat参数取值
    public static final int CHECK_UPDATE_PLAT_ANDROID = 1;

    //  检查更新时GAMMA环境的env参数取值
    public static final int CHECK_UPDATE_ENV_GAMMA = 1;

    //  检查更新时IDC环境的env参数取值
    public static final int CHECK_UPDATE_ENV_IDC = 2;

    //  本地安装包所在文件夹
    public static final String LOCAL_APK_DIR = "update";
    //  本地安装包文件名
    public static final String LOCAL_APK_FILE = "weigou_android_update.apk";
}
