package com.tencent.weigou.util;

/**
 * App版本类型信息。<br/>
 * <ul>
 *     <li>DEBUG: 开发专用版本</li>
 *     <li>GAMMA: 候选发布版本，用于产品体验和测试验证</li>
 *     <li>RELEASE: 正式发布版本</li>
 * </ul>
 * @author: ethonchan
 * @date: 14-1-6 上午11:44
 */
public enum VersionType {
    DEBUG("debug"), GAMMA("gamma"), RELEASE("release");

    private String extra;

    VersionType(String extra){
        this.extra = extra;
    }

    public String getExtra() {
        return extra;
    }

    public static VersionType defaultVersionType(){
        return DEBUG;
    }
}
