package com.tencent.weigou.util;

/**
 * 可取消接口，实现该接口的类都具有通知别人取消状态的能力
 * User: ethonchan
 * Date: 13-10-24
 * Time: 下午12:03
 */
public interface Cancelable {
    /**
     * 是否被取消
     * @return  true已经被取消，false未被取消
     */
    public boolean isCancelled();
}
