package com.tencent.weigou.util;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

/**
 * AES安全编码组件
 * 
 * <pre>
 * 支持 AES
 * AES                  key size must be equal to 56
 * 这个类主要是用于AES加密和解密，基本功能与CryptHelper类一样，主要区别在于，
 * RawKey不是根据DEFAULTSEED来生成的，而是使用默认的固定值，原因在于
 * KeyGenerator根据DEFAULTSEED生成的RawKey在Android的不同版本上是不一样的，
 * CryptHelper类可以使用是因为加密解密都是在Android的固定平台，而新的CryptHelper2
 * 类用于在服务器后台加密，在Android客户端解密，所以需使用固定的RawKey
 * 
 * @author branjin
 * @version 1.0
 * @since 1.0
 */
public class CryptHelper {
	private final static String HEX = "0123456789ABCDEF";
	private final static String RAWKEY = "B29237232540584387F656B1354EABD6";

	/**
	 * 加密
	 * 
	 * @param seed
	 *            种子
	 * @param cleartext
	 *            待加密串
	 * @return
	 * @throws Exception
	 */
	public static String encrypt(String cleartext) throws Exception {
		byte[] rawKey = getRawKey();
		byte[] result = encrypt(rawKey, cleartext.getBytes());
		return toHex(result);
	}

	/**
	 * 解密
	 * 
	 * @param seed
	 *            种子
	 * @param encrypted待解密字符串
	 * @return
	 * @throws Exception
	 */
	public static String decrypt(String encrypted) throws Exception {
		byte[] rawKey = getRawKey();
		byte[] enc = toByte(encrypted);
		byte[] result = decrypt(rawKey, enc);
		return new String(result);
	}

	/**
	 * 生成种子
	 * 
	 * @param seed种子
	 * @return
	 * @throws Exception
	 */
	private static byte[] getRawKey() throws Exception {
		// KeyGenerator kgen = KeyGenerator.getInstance("AES");
		// // SecureRandom sr = SecureRandom.getInstance("SHA1PRNG");
		// SecureRandom sr = SecureRandom.getInstance( "SHA1PRNG", "Crypto" );
		// sr.setSeed(seed);
		// kgen.init(128, sr); // 192 and 256 bits may not be available
		// SecretKey skey = kgen.generateKey();
		// byte[] raw = skey.getEncoded();
		byte[] raw = toByte(RAWKEY);
		return raw;
	}

	/**
	 * 加密
	 * 
	 * @param raw种子
	 * @param clear待加密字符串
	 * @return
	 * @throws Exception
	 */
	private static byte[] encrypt(byte[] raw, byte[] clear) throws Exception {
		SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
		byte[] encrypted = cipher.doFinal(clear);
		return encrypted;
	}

	/**
	 * 解密
	 * 
	 * @param raw种子
	 * @param encrypted待解密字符串
	 * @return
	 * @throws Exception
	 */
	private static byte[] decrypt(byte[] raw, byte[] encrypted)
			throws Exception {
		SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.DECRYPT_MODE, skeySpec);
		byte[] decrypted = cipher.doFinal(encrypted);
		return decrypted;
	}

	/**
	 * 转化成16进制
	 * 
	 * @param txt
	 * @return
	 */
	public static String toHex(String txt) {
		return toHex(txt.getBytes());
	}

	/**
	 * 16进制转化成String
	 * 
	 * @param hex
	 * @return
	 */
	public static String fromHex(String hex) {
		return new String(toByte(hex));
	}

	/**
	 * 转化成二进制
	 * 
	 * @param hexString
	 * @return
	 */
	public static byte[] toByte(String hexString) {
		int len = hexString.length() / 2;
		byte[] result = new byte[len];
		for (int i = 0; i < len; i++)
			result[i] = Integer.valueOf(hexString.substring(2 * i, 2 * i + 2),
					16).byteValue();
		return result;
	}

	/**
	 * 转化成16进制
	 * 
	 * @param buf
	 * @return
	 */
	public static String toHex(byte[] buf) {
		if (buf == null)
			return "";
		StringBuffer result = new StringBuffer(2 * buf.length);
		for (int i = 0; i < buf.length; i++) {
			appendHex(result, buf[i]);
		}
		return result.toString();
	}

	/**
	 * 
	 * @param sb
	 * @param b
	 */
	private static void appendHex(StringBuffer sb, byte b) {
		sb.append(HEX.charAt((b >> 4) & 0x0f)).append(HEX.charAt(b & 0x0f));
	}

}
