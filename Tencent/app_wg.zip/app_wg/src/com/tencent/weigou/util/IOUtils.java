package com.tencent.weigou.util;

import com.tencent.weigou.util.http.base.OnProgressListener;

import java.io.*;

/**
 * User: ethonchan
 * Date: 13-10-15
 * Time: 上午11:31
 */
public class IOUtils {

    //  默认缓冲区大小=4k
    public final static int DEFAULT_BUFFER_SIZE = 1024 * 4;

    private IOUtils() {
    }

    /**
     * 按照指定的编码格式讲述如流转换为字符串，若不指定编码格式，将采用默认编码{@link com.tencent.weigou.util.Constants}
     *
     * @param ins     输入流
     * @param charset 解码编码，默认使用{@link Constants}
     * @return 字符串
     * @throws IOException IO异常
     */
    public static String toString(InputStream ins, String charset) throws IOException {
        return toString(ins, charset, null, 0, null);
    }

    /**
     * 按照指定的编码格式讲述如流转换为字符串，若不指定编码格式，将采用默认编码{@link com.tencent.weigou.util.Constants}
     *
     * @param ins     输入流
     * @param charset 解码编码，默认使用{@link Constants}
     * @param caller  调用前，具有取消功能
     * @return 字符串
     * @throws IOException IO异常
     */
    public static String toString(InputStream ins, String charset, Cancelable caller) throws IOException {
        return toString(ins, charset, caller, 0, null);
    }

    /**
     * 按照指定的编码格式讲述如流转换为字符串，若不指定编码格式，将采用默认编码{@link com.tencent.weigou.util.Constants}
     *
     * @param ins       输入流
     * @param charset   解码编码，默认使用{@link Constants}
     * @param caller    调用前，具有取消功能
     * @param totalSize 要下载的整体大小
     * @param listener  进度监听器
     * @return 字符串
     * @throws IOException IO异常
     */
    public static String toString(InputStream ins, String charset, Cancelable caller, final long totalSize, OnProgressListener listener) throws IOException {
        if (StringUtils.isBlank(charset)) {
            charset = Constants.DECODE_CHARSET;
        }
        StringWriter writer = new StringWriter();
        InputStreamReader reader = new InputStreamReader(ins, charset);
        char[] buffer = new char[DEFAULT_BUFFER_SIZE];
        int n;
        float curProgress = -1;
        boolean cancelled = caller == null ? false : caller.isCancelled();
        while (!cancelled && -1 != (n = reader.read(buffer))) {
            writer.write(buffer, 0, n);
            if (totalSize > 0 && listener != null) {
                float progress = (float) n / totalSize * 100;
                if (progress != curProgress) {
                    listener.onProgressUpdated(progress);
                    curProgress = progress;
                }
            }
            cancelled = caller == null ? false : caller.isCancelled();
        }
        if(cancelled && listener != null)
        //  取消
        {
            listener.onCancel();
        }
        closeQuietly(reader);

        String result = null;
        if (!cancelled) {
            result = writer.toString();
        }
        closeQuietly(writer);

        return result;
    }

    /**
     * 将输入流 <code>InputStream</code> 转换为字节数组 <code>byte[]</code>.
     *
     * @param ins 输入流
     * @return 字节数组
     * @throws java.io.IOException 其它 IO 异常
     */
    public static byte[] toByteArray(InputStream ins) throws IOException {
        return toByteArray(ins, null, 0, null);
    }

    /**
     * 将输入流 <code>InputStream</code> 转换为字节数组 <code>byte[]</code>.
     *
     * @param ins       输入流
     * @param caller    取消监听器
     * @param totalSize 要下载的整体大小
     * @param listener  进度监听器
     * @return 字节数组
     * @throws java.io.IOException 其它 IO 异常
     */
    public static byte[] toByteArray(InputStream ins, Cancelable caller, final long totalSize, OnProgressListener listener) throws IOException {
        ByteArrayOutputStream outs = new ByteArrayOutputStream();
        byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
        int n = 0;
        int readLen = 0;
        float curProgress = -1;
        boolean cancelled = caller == null ? false : caller.isCancelled();
        while (!cancelled && -1 != (n = ins.read(buffer))) {
            outs.write(buffer, 0, n);
            //  更新当前进度
            readLen += n;
            if (totalSize > 0 && listener != null) {
                float progress = (float) readLen / totalSize * 100;
                if (progress != curProgress) {
                    listener.onProgressUpdated(progress);
                    curProgress = progress;
                }
            }
            cancelled = caller == null ? false : caller.isCancelled();
        }
        if(cancelled && listener != null)
        //  取消
        {
            listener.onCancel();
        }
        byte[] result = null;
        if (!cancelled) {
            result = outs.toByteArray();
        }
        closeQuietly(outs);
        return result;
    }


    /**
     * 读取文件
     *
     * @param filePath 文件的全路径
     * @return 文件中的二进制内容
     * @throws IOException
     */
    public static byte[] readFile(String filePath) throws IOException {
        return readFile(filePath, null);
    }

    /**
     * 读取文件
     *
     * @param filePath 文件的全路径
     * @param caller   调用者，可取消本次请求
     * @return 文件中的二进制内容
     * @throws IOException
     */
    public static byte[] readFile(String filePath, Cancelable caller) throws IOException {
        return readFile(filePath, caller, 0, null);
    }

    /**
     * 读取文件
     *
     * @param filePath  文件的全路径
     * @param caller    调用者，可取消本次请求
     * @param totalSize 要下载的整体大小
     * @param listener  进度监听器
     * @return 文件中的二进制内容
     * @throws IOException
     */
    public static byte[] readFile(String filePath, Cancelable caller, final long totalSize, OnProgressListener listener) throws IOException {
        byte[] data = null;
        if (filePath != null) {
            File file = new File(filePath);
            FileInputStream ins = new FileInputStream(file);
            data = toByteArray(ins, caller, totalSize, listener);
            closeQuietly(ins);
        }
        return data;
    }

    /**
     * 关闭一个输入流 <code>Reader</code>.
     * <p>
     * 等同于 {@link java.io.Reader#close()}, 但是将忽悠所有的异常，通常在 finally 语句中使用
     * </p>
     *
     * @param input 输入流
     */
    public static void closeQuietly(Reader input) {
        try {
            if (input != null) {
                input.close();
            }
        } catch (IOException ioe) {
            // ignore
        }
    }

    /**
     * 关闭一个输出流 <code>Writer</code>.
     * <p>
     * 等同于 {@link java.io.Writer#close()}, 但是将忽悠所有的异常，通常在 finally 语句中使用
     * </p>
     *
     * @param output 输出流
     */
    public static void closeQuietly(Writer output) {
        try {
            if (output != null) {
                output.close();
            }
        } catch (IOException ioe) {
            // ignore
        }
    }

    /**
     * 关闭一个输入流 <code>InputStream</code>.
     * <p>
     * 等同于 {@link java.io.InputStream#close()}, 但是将忽悠所有的异常，通常在 finally 语句中使用
     * </p>
     *
     * @param input 输入流
     */
    public static void closeQuietly(InputStream input) {
        try {
            if (input != null) {
                input.close();
            }
        } catch (IOException ioe) {
            // ignore
        }
    }

    /**
     * 关闭一个输出流 <code>OutputStream</code>.
     * <p>
     * 等同于 {@link java.io.OutputStream#close()}, 但是将忽悠所有的异常，通常在 finally 语句中使用
     * </p>
     *
     * @param output 输出流
     */
    public static void closeQuietly(OutputStream output) {
        try {
            if (output != null) {
                output.close();
            }
        } catch (IOException ioe) {
            // ignore
        }
    }
}
