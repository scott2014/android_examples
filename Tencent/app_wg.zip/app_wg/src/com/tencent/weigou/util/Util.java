package com.tencent.weigou.util;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.*;
import android.graphics.Bitmap.Config;
import android.graphics.Paint.Style;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.math.BigInteger;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 常用工具类
 * 
 * @author rickwang
 */
public class Util {
	private static final String REG = "(\\d+).*";

	// 非数字
	private static final String NON_NUM_REG = "(\\D)*";

	private static final String DIGITAL_REG = "(\\d+\\.?\\d*)";

	// 一毫秒有多少纳秒
	public final static long NANO_SEC_PER_MILLSEC = 1000 * 1000;

	/**
	 * 判断是否为手机号码
	 * 
	 * @param num
	 * @return
	 */
	public static boolean isUserMoNumber(String num) {
		boolean re = false;
		if (num.length() == 11) {
			if (num.startsWith("13")) {
				re = true;
			} else if (num.startsWith("15")) {
				re = true;
			} else if (num.startsWith("18")) {
				re = true;
			} else if (num.startsWith("14")) {
				re = true;
			}
		}
		return re;
	}

	/**
	 * 转换dip到px
	 * 
	 * @param context
	 * @param dipValue
	 * @return
	 */
	public static int dip2px(Context context, float dipValue) {
		final float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dipValue * scale + 0.5f);
	}

	public static int px2dip(Context context, float pxValue) {
		final float scale = context.getResources().getDisplayMetrics().density;
		return (int) ((pxValue - 0.5f) / scale);
	}

	/**
	 * 隐藏键盘
	 * 
	 * @param activity
	 */
	public static void hideKeyboard(Activity activity) {
		if (activity == null) {
			return;
		}
		if (activity.getCurrentFocus() == null) {
			return;
		}
		if (activity.getCurrentFocus().getWindowToken() == null) {
			return;
		}
		InputMethodManager imm = ((InputMethodManager) activity
				.getSystemService(Activity.INPUT_METHOD_SERVICE));
		imm.hideSoftInputFromWindow(
				activity.getCurrentFocus().getWindowToken(),
				InputMethodManager.HIDE_NOT_ALWAYS);
	}

	/**
	 * 提取字符串中的数字。因为getNum(String)方法对于0.96这样的数字直接会被提取为0，故新增一个方法
	 * 
	 * @author ethonchan
	 * @param s
	 * @return 字符串中的所有数字组成的值，这里有可能越界哦
	 */
	public static int parseNum(String s) {
		int value = 0;
		if (s != null) {
			s = s.replaceAll(NON_NUM_REG, "");
			try {
				value = Integer.parseInt(s);
			} catch (Exception e) {
				;
			}
		}
		return value;
	}

	/**
	 * 判断字符串是不是数字包括小数
	 * 
	 * @param s
	 * @return
	 */
	public static boolean isDigital(String s) {
		if (s != null) {
			Pattern pattern = Pattern.compile(DIGITAL_REG);
			Matcher matcher = pattern.matcher(s);
			if (matcher.find()) {
				String t = matcher.group(1);
				if (t.equals(s)) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * String to int
	 * 
	 * @param s
	 *            src
	 * @param defaultValue
	 *            : 默认返回值
	 * 
	 * @return
	 */
	public static int getInt(String s, int defaultValue) {
		if (s != null && s.trim().length() > 0) {
			try {
				defaultValue = (int) Double.parseDouble(s);
			} catch (NumberFormatException e) {
			}
		}
		return defaultValue;
	}

	/**
	 * String to long
	 * 
	 * @param s
	 *            src
	 * @param defaultValue
	 *            : 默认返回值
	 * 
	 * @return
	 */
	public static long getLong(String s, long defaultValue) {
		if (s != null && s.trim().length() > 0) {
			try {
				defaultValue = Long.parseLong(s);
			} catch (NumberFormatException e) {
			}
		}
		return defaultValue;
	}

	/**
	 * 转化成当前金额格式
	 * 
	 * @param str
	 *            金额
	 * @return
	 */
	public static String getCurrency(String str) {
		int money = getInt(str, 0);
		return getCurrency(money);
	}

	/**
	 * 转化为当前金额格式
	 * 
	 * @param cent
	 *            金额(分)
	 * @return
	 */
	@SuppressLint("DefaultLocale")
	public static String getCurrency(int cent) {
		return getCurrency(cent, false);
	}

	/**
	 * 将给定的分转换为当前的金额格式 把+或-号放￥前面
	 * 
	 * @param cent
	 *            分
	 * @param withPlus
	 *            当金额为正数时，是否显示"+"
	 * @return
	 */
	@SuppressLint("DefaultLocale")
	public static String getCurrency(int cent, boolean withPlus) {
		int abs = Math.abs(cent);
		boolean neg = cent < 0;
		int yuan = abs / 100;
		int fen = abs % 100;
		if (neg) {
			String negativeFormat = "￥-%1$01d";
			if (fen != 0) {
				if (yuan == 0) {
					return "";
				} else {
					return String.format(negativeFormat, yuan);
				}
			} else {
				return String.format(negativeFormat + ".%2$02d", yuan, fen);
			}
		} else {
			String positiveFormat = withPlus ? "+￥%1$01d" : "￥%1$01d";
			if (fen == 0) {
				if (yuan == 0) {
					return "";
				} else {
					return String.format(positiveFormat, yuan);
				}
			} else {
				return String.format(positiveFormat + ".%2$02d", yuan, fen);
			}
		}
	}

	/**
	 * 转化当前金额格式，以元为单位
	 * 
	 * @param cent
	 * @return
	 */
	public static String getYuan(int cent) {
		int abs = Math.abs(cent);
		boolean neg = cent < 0;
		int yuan = abs / 100;
		if (neg)
			return String.format("￥-%1$01d", yuan);
		else
			return String.format("￥%1$01d", yuan);
	}

	/**
	 * 
	 * @Title: getDistance
	 * 
	 * @Description: 转换距离值，小于1000 展示多少米，大于等于1000，展示多少公里
	 * @param @param distance
	 * @param @return 设定文件
	 * @return String 返回类型
	 * @throws
	 */
	public static String getDistance(int distance) {
		if (distance < 1000) {
			return String.format("%d米", distance);
		} else {
			int kilometer = (int) (distance / 1000);
			if (kilometer < 100) {
				return String.format("%d公里", kilometer);
			} else {
				return ">99公里";
			}
		}
	}

	/**
	 * 转换地址栏中键值对
	 * 
	 * @param jsonStr
	 * @return
	 */
	public static Map<String, String> decodeKeyValue(String jsonStr) {
		jsonStr = URLDecoder.decode(jsonStr);

		Map<String, String> objs = new HashMap<String, String>();

		String[] group = jsonStr.split("&");
		if (group != null)
			for (String s : group) {
				String[] t = s.split("=");
				if (t != null && t.length > 1)
					objs.put(t[0], t[1]);
			}
		return objs;
	}

	/**
	 * 负数转成正数
	 * 
	 * @param v
	 * @return
	 */
	public static String bigLong2String(String v) {
		if (v == null || v.charAt(0) != '-')
			return v;

		BigInteger val = new BigInteger("18446744073709551616", 10);
		BigInteger tmp = new BigInteger(v, 10);

		return tmp.add(val).toString();
	}

	public static String formatHtml(String str) {
		return str.replaceAll("<br/>", "\n").replaceAll("<BR/>", "\n")
				.replaceAll("<BR>", "\n").replaceAll("<br>", "\n");
	}

	public static List<Map<String, Object>> toMapList(Object[][] values,
			String[] keys) {
		if (values == null || keys == null || values[0].length != keys.length) {
			return null;
		}

		int dataSize = values.length;
		int keySize = keys.length;
		List<Map<String, Object>> data = new ArrayList<Map<String, Object>>(
				dataSize);
		for (Object[] obj : values) {
			Map<String, Object> map = new HashMap<String, Object>(keySize);
			for (int index = 0; index < keySize; index++) {
				map.put(keys[index], obj[index]);
			}
			data.add(map);
		}
		return data;
	}

	/**
	 * 屏幕宽度
	 * 
	 * @param manager
	 * @return
	 */
	public static int getScreenWidth(WindowManager manager) {
		DisplayMetrics metric = new DisplayMetrics();
		manager.getDefaultDisplay().getMetrics(metric);
		return metric.widthPixels;
	}

	/**
	 * 屏幕高度
	 * 
	 * @param manager
	 * @return
	 */
	public static int getScreenHeight(WindowManager manager) {
		DisplayMetrics metric = new DisplayMetrics();
		manager.getDefaultDisplay().getMetrics(metric);
		return metric.heightPixels;
	}

	/**
	 * 除去系统栏的屏幕高度
	 * 
	 * @param manager
	 * @return
	 */
	public static int getScreenContentHeight(Context context) {
		int result = 0;
		int resourceId = context.getResources().getIdentifier(
				"status_bar_height", "dimen", "android");
		if (resourceId > 0) {
			result = context.getResources().getDimensionPixelSize(resourceId);
		}
		return getScreenHeight(((Activity) context).getWindowManager())
				- result;
	}

	public static int getScreenX(WindowManager manager) {
		int h = getScreenHeight(manager);
		int w = getScreenWidth(manager);
		return Math.abs(h - w);
	}

	/**
	 * 获取时间的小时和分钟
	 * 
	 * @return
	 */
	public static String[] getTimeArray(long timeLong) {
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss", Locale.CHINA);
		sdf.setTimeZone(TimeZone.getTimeZone("GMT+08:00"));
		String timeStr = sdf.format(timeLong * 1000);
		String[] timeArr = timeStr.split(":");
		if (timeArr.length != 3) {
			return null;
		}
		return timeArr;

	}

	public static Drawable toMohu(Bitmap bmpSource, int Blur) // 源位图，模糊强度
	{
		Bitmap bmpReturn = Bitmap.createBitmap(bmpSource.getWidth(),
				bmpSource.getHeight(), Bitmap.Config.ARGB_8888);
		int pixels[] = new int[bmpSource.getWidth() * bmpSource.getHeight()];
		int pixelsRawSource[] = new int[bmpSource.getWidth()
				* bmpSource.getHeight() * 3];
		int pixelsRawNew[] = new int[bmpSource.getWidth()
				* bmpSource.getHeight() * 3];

		bmpSource.getPixels(pixels, 0, bmpSource.getWidth(), 0, 0,
				bmpSource.getWidth(), bmpSource.getHeight());

		for (int k = 1; k <= Blur; k++) {
			// 从图片中获取每个像素三原色的值
			for (int i = 0; i < pixels.length; i++) {
				pixelsRawSource[i * 3 + 0] = Color.red(pixels[i]);
				pixelsRawSource[i * 3 + 1] = Color.green(pixels[i]);
				pixelsRawSource[i * 3 + 2] = Color.blue(pixels[i]);
			}
			// 取每个点上下左右点的平均值作自己的值
			int CurrentPixel = bmpSource.getWidth() * 3 + 3;
			// 当前处理的像素点，从点(2,2)开始
			for (int i = 0; i < bmpSource.getHeight() - 3; i++) // 高度循环
			{
				for (int j = 0; j < bmpSource.getWidth() * 3; j++) // 宽度循环
				{
					CurrentPixel += 1; // 取上下左右，取平均值
					float sumColor = 0; // 颜色和
					sumColor = pixelsRawSource[CurrentPixel
							- bmpSource.getWidth() * 3]; // 上一点
					sumColor = sumColor + pixelsRawSource[CurrentPixel - 3]; // 左一点
					sumColor = sumColor + pixelsRawSource[CurrentPixel + 3]; // 右一点
					sumColor = sumColor
							+ pixelsRawSource[CurrentPixel
									+ bmpSource.getWidth() * 3]; // 下一点
                    sumColor /= 4;
					pixelsRawNew[CurrentPixel] = Math.round(sumColor); // 设置像素点
				}
			}

			for (int i = 0; i < pixels.length; i++) {
				pixels[i] = Color.rgb(pixelsRawNew[i * 3 + 0],
						pixelsRawNew[i * 3 + 1], pixelsRawNew[i * 3 + 2]);
			}
		}

		bmpReturn.setPixels(pixels, 0, bmpSource.getWidth(), 0, 0,
				bmpSource.getWidth(), bmpSource.getHeight()); // 必须新建位图然后填充，不能直接填充源图像，否则内存报错
		return new BitmapDrawable(bmpReturn);
	}

	/**
	 * 
	 * @Title: zoomDrawable
	 * @Description: 缩放
	 * @param bitmap
	 * @param w
	 * @param h
	 * @return 设定文件
	 * 
	 *         Drawable 返回类型
	 * @throws
	 */
	public static Drawable zoomBitmap(Bitmap bitmap, int w, int h) {
		int width = bitmap.getWidth();
		int height = bitmap.getHeight();
		// 创建操作图片用的Matrix对象
		Matrix matrix = new Matrix();
		// 计算缩放比例
		float sx = ((float) w / width);
		float sy = ((float) h / height);
		// 设置缩放比例
		matrix.postScale(sx, sy);
		// 建立新的bitmap，其内容是对原bitmap的缩放后的图
		Bitmap newbmp = Bitmap.createBitmap(bitmap, 0, 0, width, height,
				matrix, true);
		return new BitmapDrawable(newbmp);
	}

	/**
	 * 将图片截取为圆角图片
	 * 
	 * @param bitmap
	 *            原图片
	 * @param ratio
	 *            截取比例，如果是8，则圆角半径是宽高的1/8，如果是2，则是圆形图片
	 * @return 圆角矩形图片
	 */
	public static Bitmap getRoundedCornerBitmap(Bitmap bitmap, float ratio) {

		Bitmap output = Bitmap.createBitmap(bitmap.getWidth(),
				bitmap.getHeight(), Config.ARGB_8888);
		Canvas canvas = new Canvas(output);

		final Paint paint = new Paint();
		final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
		final RectF rectF = new RectF(rect);

		paint.setAntiAlias(true);
		canvas.drawARGB(0, 0, 0, 0);
		canvas.drawRoundRect(rectF, bitmap.getWidth() / ratio,
				bitmap.getHeight() / ratio, paint);
		paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
		canvas.drawBitmap(bitmap, rect, rect, paint);
		paint.setColor(Color.parseColor("#eaeaea")); // 设置画笔颜色
		paint.setStrokeWidth((float) 1.0); // 线宽
		paint.setStyle(Style.STROKE); // 空心效果
		canvas.drawCircle(bitmap.getWidth() / 2, bitmap.getHeight() / 2,
				bitmap.getWidth() / 2 - 2, paint);
		return output;
	}

	/**
	 * 将图片切为圆角
	 */
	public static Bitmap toRoundCorner(Drawable drawable, int pixels) {
		BitmapDrawable bd = (BitmapDrawable) drawable;
		Bitmap bitmap = bd.getBitmap();
		Bitmap output = Bitmap.createBitmap(bitmap.getWidth(),
				bitmap.getHeight(), Config.ARGB_8888);
		Canvas canvas = new Canvas(output);
		final int color = 0xff424242;
		final Paint paint = new Paint();
		final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
		final RectF rectF = new RectF(rect);
		final float roundPx = pixels;
		paint.setAntiAlias(true);
		canvas.drawARGB(0, 0, 0, 0);
		paint.setColor(color);
		canvas.drawRoundRect(rectF, roundPx, roundPx, paint);
		paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
		/**
		 * 这里如果bitmap recycle了，就不绘制，只留背景
		 */
		if (!bitmap.isRecycled()) {
			canvas.drawBitmap(bitmap, rect, rect, paint);
		}
		return output;
	}


	/**
	 * 根据时间(ms)得到对应的月日信息
	 * 
	 * @param time
	 * @return
	 */
	public static String getDateStr(long time) {
		Date date = new Date(time);
		SimpleDateFormat formatter = new SimpleDateFormat("MM年dd日",
				Locale.CHINA);
		formatter.setTimeZone(TimeZone.getTimeZone("GMT+08:00"));
		return formatter.format(date);
	}

	public static String getDateShortStr(long shortTime) {

		Date date = new Date(shortTime * 1000);
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy.MM.dd",
				Locale.CHINA);
		formatter.setTimeZone(TimeZone.getTimeZone("GMT+08:00"));
		return formatter.format(date);
	}

	public static String getTimeStr(long shortTime) {
		Date date = new Date(shortTime * 1000);
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
				"yyyy-MM-dd HH:mm", Locale.CHINA);
		simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+08:00"));
		return simpleDateFormat.format(date);
	}

	public static String getTimeSecStr(long shortTime) {
		Date date = new Date(shortTime * 1000);
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
				"yyyy-MM-dd HH:mm:ss", Locale.CHINA);
		simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+08:00"));
		return simpleDateFormat.format(date);
	}

	public static String getShowDate(long shortTime) {
		shortTime = shortTime * 1000;
		String ret = "";
		Date date = new Date(shortTime);
		try {
			Calendar now = Calendar.getInstance();
			int hour = now.get(Calendar.HOUR_OF_DAY);
			int minute = now.get(Calendar.MINUTE);
			int second = now.get(Calendar.SECOND);
			long ms = 1000 * (hour * 3600 + minute * 60 + second);
			long ms_now = now.getTimeInMillis();
			SimpleDateFormat simpleTimeFormat = new SimpleDateFormat("HH:mm",
					Locale.CHINA);
			simpleTimeFormat.setTimeZone(TimeZone.getTimeZone("GMT+08:00"));
			if (ms_now - shortTime < ms) {
				ret = "今天" + simpleTimeFormat.format(date);
			} else if (ms_now - shortTime < (ms + 24 * 3600 * 1000)) {
				ret = "昨天" + simpleTimeFormat.format(date);
			} else if (ms_now - shortTime < (ms + 24 * 3600 * 1000 * 2)) {
				ret = "前天" + simpleTimeFormat.format(date);
			} else {

				SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
						"MM月dd日HH:mm", Locale.CHINA);
				simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+08:00"));
				ret = simpleDateFormat.format(date);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ret;
	}

	public static String cutString(String str, int n) {
		if (StringUtils.isBlank(str)) {
			return "...";
		}
		if (n < 3) {
			return "...";
		}
		str = str.trim();

		if (str.length() > n) {
			str.substring(0, n - 3);
			str += "...";
		}
		return str;
	}

	/**
	 * 
	 * @Title: showToastInCenter
	 * 
	 * @Description: 在页面中间显示toast
	 * @param @param context
	 * @param @param text 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	public static void showToastInCenter(Context context, String text) {
		if (context == null) {
			return;
		}
		Toast toast = Toast
				.makeText(context, text, Constants.TOAST_NORMAL_LONG);
		toast.setGravity(Gravity.CENTER | Gravity.CENTER, 0, 0);
		toast.show();
	}

	/**
	 * 解码字符串
	 * 
	 * @param str
	 * @return
	 */
	public static String decodeStr(String str) {
		String result = "";
		if (StringUtils.isNotBlank(str)) {
			try {
				result = URLDecoder.decode(str, Constants.DECODE_CHARSET);
			} catch (Exception e) {
				;
			}
		}

		return result;
	}

	/**
	 * 
	 * @Title: getParam
	 * @Description: 分隔参数
	 * @param value
	 * 
	 * @throws
	 */
	public static List<NameValuePair> getParam(String value, String separated) {
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		if (separated == null || separated.length() < 1)
			return params;
		if (value != null) {
			String[] clickParams = value.split(separated);
			if (clickParams != null)
				for (String param : clickParams) {
					int sepIndex = param.indexOf("=");
					int paramLen = param.length();
					if (sepIndex > -1 && sepIndex < paramLen) {
						String pName = param.substring(0, sepIndex);
						String pValue = param.substring(sepIndex + 1, paramLen);

						pName = decodeStr(pName);
						pValue = decodeStr(pValue);
						params.add(new BasicNameValuePair(pName, pValue));
					}
				}
		}
		return params;
	}

	/**
	 * 
	 * @Title: getParam
	 * @Description: 分隔参数
	 * @param value
	 * 
	 * @throws
	 */
	public static List<NameValuePair> getParam(String value) {
		return getParam(value, "&");
	}

	/**
	 * 将米转为千米，不能整除的部分将被四舍五入。低于1km的输入将产生空白字符输出
	 * 
	 * @param distanceInM
	 * @return 1 > "", -1 > "", 1000 > "1km", 1499 > "1km", 1500 > "2km"
	 */
	public static String getKMstr(int distanceInM) {
		String str = "";
		if (distanceInM > 0) {
			double dist = distanceInM / 1000D;
			dist = Math.round(dist);
			int distInt = (int) dist;
			if (distInt > 0) {
				str = distInt + "km";
			}
		}
		return str;
	}
}