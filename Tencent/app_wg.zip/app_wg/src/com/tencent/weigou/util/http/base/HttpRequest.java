package com.tencent.weigou.util.http.base;

import android.util.Log;
import com.tencent.stat.StatAppMonitor;
import com.tencent.weigou.base.App;
import com.tencent.weigou.cache.CacheInfo;
import com.tencent.weigou.cache.CacheUtils;
import com.tencent.weigou.util.MTAUtils;
import com.tencent.weigou.util.*;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.zip.GZIPInputStream;

/**
 * Http请求基类
 * User: ethonchan
 * Date: 13-10-22
 * Time: 下午4:19
 */
public abstract class HttpRequest<ResultType> implements Cancelable {
    protected static String TAG = "HttpRequest";

    //  HTTP连接超时毫秒数
    public final static int CONNECT_TIME_OUT = 15000;

    //  HTTP读取超时毫秒数
    public final static int READ_TIME_OUT = 15000;

    //  网络类型---cmwap时需要添加的头部字段
    public static final String NETWORK_CMWAP_HEADER = "X-Online-Host";

    //  中国移动CMWAP代理地址
    public static final String NETWORK_CMWAP_PROXY_HOST = "10.0.0.172";

    public static final String DEFAULT_REFERER = "http:/m.buy.qq.com";

    public static final String IF_MODIFIED_SINCE = "If-Modified-Since";

    public static final String LAST_MODIFIED = "Last-Modified";

    //  是否取消
    protected volatile boolean cancelled = false;

    //  是否使用缓存
    protected boolean useCache = false;

    //  进度监听器
    protected OnProgressListener mListener = null;

    /**
     * Http请求基类
     *
     * @param useCache true使用缓存，false不使用缓存
     */
    public HttpRequest(boolean useCache) {
        this.useCache = useCache;
    }

    /**
     * 设置进度监听器
     *
     * @param listener
     */
    public void setProgressListener(OnProgressListener listener) {
        mListener = listener;
    }

    /**
     * 发起Get请求
     *
     * @param apiName 接口名称
     * @param urlStr  要请求的url
     * @return 请求得到的资源
     * @throws IOException
     */
    protected final ResultType doRequest(String apiName, String urlStr, Object... params) throws Exception {
        //   参数检查
        paramsNotNull(apiName, urlStr);

        //  初始化统计信息
        final long start = System.nanoTime();
        StatAppMonitor monitor = MTAUtils.getAppMonitor(apiName);

        CacheInfo cache = null;
        if (useCache && !cancelled)
        //  检查缓存
        {
            cache = CacheUtils.getFromCache(urlStr);
            if (cache != null && cache.isValid() && !cache.isExpires())
            //  直接返回处理，不用发起网络请求
            {
                onReadyToConnect(urlStr, monitor, params);
                return onGetResponseData(cache.getValue(), monitor);
            }
        }

        ResultType result = null;
        HttpURLConnection conn = null;
        try {
            //  发起网络请求
            long lastModified = 0L;
            if (cache != null) {
                lastModified = cache.getLastModified();
            }
            conn = connectServer(urlStr, lastModified, monitor, params);

            result = handleResponse(urlStr, conn, cache, monitor);
        } catch (IOException e) {
            Log.e(TAG, e == null ? "" : e.getMessage(), e);
            if (monitor != null) {
                monitor.setResultType(StatAppMonitor.FAILURE_RESULT_TYPE);
            }
            throw e;
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }

        if (!cancelled) {
            //  上报统计结果
            MTAUtils.report(App.getInstance(), start, monitor);
        }

        return result;
    }

    /**
     * 处理Http响应。这里会根据服务端是否更新来选择是否使用缓存
     *
     * @param urlStr  Http请求url
     * @param conn    建立好的http连接
     * @param cache   url对应的本地缓存
     * @param monitor MTA统计对象
     * @return
     * @throws IOException
     */
    private ResultType handleResponse(String urlStr, HttpURLConnection conn, CacheInfo cache, StatAppMonitor monitor) throws Exception {
        ResultType result = null;
        if (!cancelled && conn != null) {
            //  读取响应状态码
            int responseCode = conn.getResponseCode();
            monitor.setReturnCode(responseCode);

            if (responseCode == 402)
            //  402需要登录
            {
                result = onAuthNeeded();
            } else if (useCache && cache != null && responseCode == 304)
            //   304使用本地缓存
            {
                result = onResourceNotModified(cache, monitor);
            } else {
                result = readHttpConn(urlStr, conn, monitor);
            }
        }
        return result;
    }

    /**
     * 请求需要登录验证
     *
     * @return
     */
    protected ResultType onAuthNeeded() {
        ResultType result = null;
        return result;
    }

    /**
     * 请求返回304
     *
     * @param cache
     * @param monitor
     * @throws Exception
     */
    protected ResultType onResourceNotModified(CacheInfo cache, StatAppMonitor monitor) throws Exception {
        ResultType result = null;
        // 记录返回包大小
        byte[] response = cache.getValue();
        int respLen = response == null ? 0 : response.length;
        monitor.setRespSize(respLen);
        result = onGetResponseData(response, monitor);
        return result;
    }

    /**
     * 读取HttpConn
     *
     * @param urlStr
     * @param conn
     * @param monitor
     * @return
     * @throws Exception
     */
    protected ResultType readHttpConn(String urlStr, HttpURLConnection conn, StatAppMonitor monitor) throws Exception {
        ResultType result = null;
        if (conn != null) {
            byte[] response = null;
            int totalSize = conn.getContentLength();
            if (!cancelled) {
                InputStream ins = getInputStream(conn);
                response = IOUtils.toByteArray(ins, this, totalSize, mListener);
                IOUtils.closeQuietly(ins);

                // 记录返回包大小
                int respLen = response == null ? 0 : response.length;
                monitor.setRespSize(respLen);
            }

            //  加入缓存
            if (useCache && response != null) {
                long curTime = System.currentTimeMillis();
                long lastModified = conn.getHeaderFieldDate("Last-Modified", curTime);
                long expires = conn.getHeaderFieldDate("Expires", curTime);
                CacheUtils.saveToCache(urlStr, lastModified, expires, response);
            }

            if (!cancelled && response != null) {
                result = onGetResponseData(response, monitor);
            }
        }
        return result;
    }

    /**
     * Http连接打开前的回调
     *
     * @param urlStr  要请求的url
     * @param monitor MTA统计对象
     * @param params  HTTP请求参数
     */
    protected abstract void onReadyToConnect(String urlStr, StatAppMonitor monitor, Object... params);

    /**
     * Http连接建立后的回调
     *
     * @param urlStr
     * @param conn
     */
    protected abstract void onConnected(String urlStr, HttpURLConnection conn);

    /**
     * 处理http响应
     *
     * @param data    http响应字节
     * @param monitor MTA统计对象
     * @return
     */
    protected abstract ResultType onGetResponseData(byte[] data, StatAppMonitor monitor);

    /**
     * 建立Http连接
     *
     * @param urlStr     http请求的url
     * @param monitor    统计对象
     * @param params     http参数
     * @param lastMofied 上次更新时间
     * @return 建立好的http连接
     * @throws IOException
     */
    private HttpURLConnection connectServer(String urlStr, long lastMofied, StatAppMonitor monitor, Object... params) throws Exception {
        URL url = null;
        HttpURLConnection conn = null;
        OutputStream outs = null;

        if (!cancelled) {
            url = new URL(urlStr);
        }

        if (!cancelled) {
            conn = (HttpURLConnection) url.openConnection();
        }
        if (!cancelled) {
            conn = preProcessHttp(conn);
            if (lastMofied > 0) {
                conn.setRequestProperty(IF_MODIFIED_SINCE, DateUtils.L2CST(lastMofied));
            }
        }

        if (!cancelled) {
            onReadyToConnect(urlStr, monitor, params);
        }

        if (!cancelled) {
            try {

                conn.connect();

                //  连接建立
                onConnected(urlStr, conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (!cancelled) {
            outs = getOutputStream(conn);
        }

        if (!cancelled)
        //   输入参数
        {
            sendHttpParams(outs, urlStr, monitor, params);
            if (outs != null) {
                IOUtils.closeQuietly(outs);
            }
        }

        return conn;
    }

    /**
     * 发送Http参数
     *
     * @param outs    Http输出流
     * @param urlStr  请求的url
     * @param monitor 统计对象
     * @param params  请求的参数
     * @throws IOException
     */
    protected void sendHttpParams(OutputStream outs, String urlStr, StatAppMonitor monitor, Object... params) throws Exception {
        long len = 0;
        if (StringUtils.isNotBlank(urlStr)) {
            try {
                len = StringUtils.getByteLength(urlStr, Constants.ENCODE_CHARSET);
            } catch (Exception e) {
                len = 0;
            }
        }
        monitor.setReqSize(len);
    }

    /**
     * 从connection中获得输入流
     *
     * @param conn 当前HTTP连接
     * @return 当前HTTP连接中的输入流
     * @throws IOException
     */
    protected InputStream getInputStream(HttpURLConnection conn) throws Exception {
        InputStream ins = null;
        if (conn != null) {
            ins = conn.getInputStream();
            String encoding = conn.getContentEncoding();
            if ("gzip".equals(encoding)) {
                ins = new GZIPInputStream(ins);
            }
        }
        return ins;
    }

    /**
     * 从连接中获取输出流
     *
     * @param conn Http连接
     * @return http输出流。当无法获取输出流时将会返回null
     */
    private OutputStream getOutputStream(HttpURLConnection conn) {
        OutputStream outs = null;
        try {
            outs = conn.getOutputStream();
        } catch (Exception e) {
            //  ignore
        }
        return outs;
    }


    /**
     * 参数不能为空
     *
     * @param obj 不能为空的几个参数
     */
    protected void paramsNotNull(Object... obj) throws NullPointerException {
        if (obj != null) {
            boolean hasNull = false;
            StringBuilder paramStr = new StringBuilder("[");
            for (int i = 0, len = obj.length; i < len; i++) {
                if (obj[i] == null) {
                    hasNull = true;
                    paramStr.append("NULL, ");
                } else {
                    paramStr.append(obj[i].toString()).append(", ");
                }
            }

            if (hasNull) {
                throw new NullPointerException("One or More Param is Null. " + paramStr.toString());
            }
        }
    }

    /**
     * 对发送的HTTP请求进行预处理
     *
     * @param conn
     * @return
     */
    protected HttpURLConnection preProcessHttp(HttpURLConnection conn) {
        if (conn != null) {
            try {
                conn.setConnectTimeout(CONNECT_TIME_OUT);
                conn.setReadTimeout(READ_TIME_OUT);

                String network = SysUtils.getNetworkType();
                if (SysUtils.NETWORK_CMWAP.equals(network)) {
                    String host = conn.getURL().getHost();
                    conn.addRequestProperty(NETWORK_CMWAP_HEADER, host);
                }
            } catch (Exception e) {
                //  ignore
            }
        }
        return conn;
    }

    /**
     * 取消Http请求
     */
    public void cancel() {
        cancelled = true;
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }
}
