package com.tencent.weigou.setting.update;

import android.content.DialogInterface;
import android.os.AsyncTask;
import android.util.Log;
import com.tencent.weigou.base.activity.BaseActivity;
import com.tencent.weigou.base.json.JsonResult;
import com.tencent.weigou.setting.activity.CheckUpdateVo;
import com.tencent.weigou.util.Constants;
import com.tencent.weigou.util.SysUtils;
import com.tencent.weigou.util.http.JSONGetter;

/**
 * 检查更新线程
 * @author ethonchan
 * @created 2014-02-17
 */
public class CheckUpdateTask extends AsyncTask<String, Void, CheckUpdateVo> implements DialogInterface.OnCancelListener {

    protected BaseActivity owner;

    protected JSONGetter getter = new JSONGetter(false);

    private String title = "检查更新";

    private boolean alwaysNeedDialog = false;

    public CheckUpdateTask(BaseActivity owner, boolean alwaysNeedDialog) {
        this.owner = owner;
        this.alwaysNeedDialog = alwaysNeedDialog;
    }

    @Override
    protected void onPreExecute() {
        // 检查网络状况
        if (!SysUtils.isNetworkAvaliable()) {
            cancel(true);
        } else {
            if(alwaysNeedDialog){
                owner.showProgressDialog(this, true);
            }
            super.onPreExecute();
        }
    }

    @Override
    protected CheckUpdateVo doInBackground(String... params) {
        CheckUpdateVo result = new CheckUpdateVo();
        if (params != null) {
            String url = params[0];
            try {
                JsonResult json = getter.doGet(url);
                if (json == null) {
                    ;
                } else if (json.isAuthNeeded()) {
                    owner.toLogin();
                } else if (json.isSuccess()) {
                    result.parse(json.getData());
                } else {
                    result.setErrorCode(json.getErrCode());
                    result.setErrorMsg(json.getErrMsg());
                }
            } catch (Exception e) {
                Log.e("TAG", "CheckUpdate failed!", e);
            }
        }
        return result;
    }

    @Override
    protected void onPostExecute(CheckUpdateVo checkUpdateVo) {
        super.onPostExecute(checkUpdateVo);
        if(alwaysNeedDialog){
            owner.dismissDialogSafely(Constants.DIALOG_PROGRESS);
        }

        //  没有获取到数据则展示默认数据
        if (checkUpdateVo == null) {
            checkUpdateVo = new CheckUpdateVo();
        }

        CheckUpdateVo.Version newVersion = checkUpdateVo.getVersion();
        if (newVersion == null)
        //  检查更新失败
        {
            if(alwaysNeedDialog){
                owner.showAlertDialog(title, checkUpdateVo.getErrorMsg(), "确定", true, null, null);
            }
        } else if (newVersion.flag == CheckUpdateVo.Version.FLAG_ALREADY_LATEST)
        //  无需更新
        {
            if(alwaysNeedDialog){
                owner.showAlertDialog(title, "当前已是最新版本", "确定", true, null, null);
            }
        } else if (newVersion.flag == CheckUpdateVo.Version.FLAG_NEED_UPDATE)
        //  需要更新
        {
            UpdateDialogListener listener = new UpdateDialogListener(owner, true);
            owner.showYesNoDialog(title, newVersion.slogan, "更新", "下次再说", true, listener, listener);
        } else if (newVersion.flag == CheckUpdateVo.Version.FLAG_NEED_FORCE_UPDATE)
        //  需要强制更新
        {
            UpdateDialogListener listener = new UpdateDialogListener(owner, false);
            owner.showAlertDialog(title, newVersion.slogan, "更新", false, listener, listener);
        }
    }

    @Override
    protected void onCancelled() {
        super.onCancelled();

        owner.dismissDialogSafely(Constants.DIALOG_PROGRESS);
        if (getter != null) {
            getter.cancel();
        }
    }

    @Override
    public void onCancel(DialogInterface dialog) {
        cancel(true);
    }
}