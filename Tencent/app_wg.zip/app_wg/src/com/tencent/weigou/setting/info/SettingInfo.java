package com.tencent.weigou.setting.info;

import com.tencent.weigou.util.Env;

/**
 * 设置信息
 * 
 * @author wendyhu
 * 
 */
public class SettingInfo {
	/**
	 * 存放setting信息的sp名字
	 */
	public static final String NAME_OF_SETTING = "com.tencent.weigou.settings";

	/**
	 * 配置文件和配置项名称静态类
	 * 
	 * @author ethonchan
	 * 
	 */
	public static class SettingKeys {
		public static final String ITEM_ENV = "mEnv";
		public static final String FUN_PROPERTY = "funProperty";
	}

	// 系统运行环境，是gamma还是idc
	public int env = Env.IDC_ENV_TYPE;
}
