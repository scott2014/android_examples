package com.tencent.weigou.setting.activity.persistence;

import com.tencent.weigou.setting.info.SettingInfo;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

/**
 * APP设置信息的读取操作类
 * 
 * @author wendyhu
 * 
 */
public class SettingStorage {
	/**
	 * 把Setting信息写入到SharedPreference
	 * 
	 * @param si
	 *            设置信息
	 */
	public synchronized static boolean write(Context ctx, SettingInfo si) {
		if (ctx == null || si == null)
			return false;

		Editor editor = ctx.getSharedPreferences(SettingInfo.NAME_OF_SETTING,
				Context.MODE_PRIVATE).edit();

		editor.putInt(SettingInfo.SettingKeys.ITEM_ENV, si.env);
		return editor.commit();
	}

	/**
	 * 从SharedPreference中读取Setting信息
	 * 
	 * @return Setting信息
	 */
	public static SettingInfo read(Context ctx) {
		if (ctx == null)
			return null;

		try {
			SettingInfo si = new SettingInfo();

			SharedPreferences sps = ctx.getSharedPreferences(
					SettingInfo.NAME_OF_SETTING, 0);
			si.env = sps.getInt(SettingInfo.SettingKeys.ITEM_ENV, 0);
			return si;
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * 清除程序的设置信息
	 * 
	 * @param ctx
	 */
	public synchronized static boolean clear(Context ctx) {
		if (ctx == null)
			return false;

		android.content.SharedPreferences.Editor editor = ctx
				.getSharedPreferences(SettingInfo.NAME_OF_SETTING, 0).edit();
		editor.clear();
		return editor.commit();
	}
}
