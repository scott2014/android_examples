package com.tencent.weigou.setting.update;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import com.tencent.weigou.R;
import com.tencent.weigou.setting.activity.CheckUpdateVo;
import com.tencent.weigou.setting.activity.SettingActivity;
import com.tencent.weigou.shopping.activity.ShoppingIndexActivity;
import com.tencent.weigou.util.Constants;
import com.tencent.weigou.util.SysUtils;
import com.tencent.weigou.util.http.ApkGetter;
import com.tencent.weigou.util.http.base.OnProgressListener;

import java.io.File;

/**
 * 更新包下载线程
 *
 * @author ethonchan
 * @created 2014-01-26
 */
public class UpdateThread implements Runnable, OnProgressListener {

    public final static String TAG = "UpdateThread";

    protected Context mContext;

    protected CheckUpdateVo.Version mApkVersion;

    //  下载工具
    protected ApkGetter mApkGetter = null;

    protected NotificationManager mNotificationManager;

    protected Bitmap mLargeIcon;

    private String mTitle, mDownloading, mDownloadFinished, mDownloadFailed;

    private int curProgress = -1;

    public UpdateThread(Context context, CheckUpdateVo.Version apkVersion) {
        mContext = context;
        mApkVersion = apkVersion;

        if (mNotificationManager == null) {
            mNotificationManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
        }
        mLargeIcon = BitmapFactory.decodeResource(context.getResources(), R.drawable.notification_icon_large);
        mTitle = (String) context.getText(R.string.app_name);
        mDownloading = (String) context.getText(R.string.downloading);
        mDownloadFinished = (String) context.getText(R.string.download_finished);
        mDownloadFailed = (String) context.getText(R.string.download_failed);
    }

    @Override
    public void run() {
        try {
            File apkFile = getApkFile();
            if (apkFile == null) {
                //TODO need report?
                Log.e(TAG, "Fail to get local apk filename, apkFile=null");
            } else {
                boolean downloaded = apkFile.exists() && checkLocalFile(apkFile);
                if (!downloaded) {
                    apkFile.delete();
                    mApkGetter = new ApkGetter(apkFile);
                    mApkGetter.setProgressListener(this);
                    mApkGetter.doGet(mApkVersion.url);
                } else {
                    //  直接下载完成
                    onProgressUpdated(100);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Exception when download APK.", e);
        }
    }

    /**
     * 检查本地apk文件是否可用
     *
     * @param apkFile   本地apk文件
     * @return true可用，false不可用
     */
    protected boolean checkLocalFile(File apkFile) {
        if (apkFile == null || !apkFile.exists()) {
            return false;
        } else
        //  校验版本号
        {
            try {
                PackageManager mgr = mContext.getPackageManager();
                if (mgr != null) {
                    PackageInfo info = mgr.getPackageArchiveInfo(apkFile.getPath(), PackageManager.GET_ACTIVITIES);
                    if (info != null && info.applicationInfo != null) {
                        ApplicationInfo appInfo = info.applicationInfo;
                        if ((appInfo.flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0)
                        //  如果是debug版本的，则不使用本地的apk
                        {
                            return false;
                        } else {
                            return info.versionCode >= mApkVersion.version;
                        }
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "Exception when checkLocalFile. ", e);
            }
            return false;
        }
    }

    @Override
    public void onProgressUpdated(float progress) {
        int newProgress = (int) progress;
        if (newProgress != curProgress) {
            curProgress = newProgress;
            updateNotification(newProgress);
        }
    }

    @Override
    public void onCancel() {
        curProgress = -1;
        updateNotification(-1);
    }

    /**
     * 更新通知栏进度
     *
     * @param progress <0表示失败，100表示下载完成
     */
    protected void updateNotification(int progress) {
        Intent intent = new Intent();
        NotificationCompat.Builder builder = new NotificationCompat.Builder(mContext);
        builder.setContentTitle(mTitle);
        if (progress < 0)
        //  下载失败
        {
            builder.setSmallIcon(android.R.drawable.stat_sys_warning);
            builder.setTicker(mDownloadFailed);
            builder.setContentText(mDownloadFailed);
            builder.setContentInfo("");
            builder.setProgress(100, 0, false);
            intent.setClass(mContext, SettingActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            builder.setOngoing(false);
            builder.setAutoCancel(true);
        } else if (progress >= 100)
        //  下载完成
        {
            builder.setSmallIcon(android.R.drawable.stat_sys_download_done);
            builder.setTicker(mDownloadFinished);
            builder.setContentText(mDownloadFinished);
            builder.setContentInfo("100%");
            builder.setProgress(100, 100, false);
            builder.setOngoing(false);
            builder.setAutoCancel(true);
            // install apk
            intent.setAction(Intent.ACTION_VIEW);
            File apkFile = getApkFile();
            Uri uri = Uri.fromFile(apkFile);
            intent.setDataAndType(uri, "application/vnd.android.package-archive");
        } else
        //  正在下载
        {
            builder.setSmallIcon(android.R.drawable.stat_sys_download);
            builder.setTicker(mDownloading);
            builder.setContentText(mDownloading);
            builder.setContentInfo(progress + "%");
            builder.setProgress(100, progress, false);
            intent.setClass(mContext, ShoppingIndexActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            builder.setOngoing(true);
        }
        builder.setLargeIcon(mLargeIcon);

        PendingIntent pIntent = PendingIntent.getActivity(mContext, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        builder.setContentIntent(pIntent);
        Notification ntf = builder.build();
        mNotificationManager.notify(12345, ntf);
    }

    /**
     * 得到安装包的文件目录
     *
     * @return 本地的安装包文件
     */
    public File getApkFile() {
        File dir = SysUtils.getDirInSdcard(Constants.LOCAL_APK_DIR);
        File apkFile = null;
        if (dir != null) {
            apkFile = new File(dir.getAbsolutePath() + File.separator + Constants.LOCAL_APK_FILE);
        }
        return apkFile;
    }
}
