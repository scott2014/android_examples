/**
 * @Title: SettingActivity.java
 * @Package com.tencent.weigou.setting.activity
 * @author wendyhu
 * @date 2013-10-28 下午3:14:45 
 * @version V1.0
 */
package com.tencent.weigou.setting.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import com.tencent.weigou.R;
import com.tencent.weigou.base.App;
import com.tencent.weigou.base.activity.TitleBarActivity;
import com.tencent.weigou.guide.GuideActivity;
import com.tencent.weigou.setting.activity.persistence.SettingStorage;
import com.tencent.weigou.setting.info.SettingInfo;
import com.tencent.weigou.setting.update.CheckUpdateTask;
import com.tencent.weigou.user.UserVo;
import com.tencent.weigou.util.*;
import com.tencent.weigou.web.WebKitActivity;
import com.tencent.weigou.web.WebkitConstants;

/**
 * @ClassName: SettingActivity
 * @author wendyhu
 * @date 2013-10-28 下午3:14:45
 */

public class SettingActivity extends TitleBarActivity implements
		OnClickListener {

	private TextView envTypeTv;
	private TextView loginTv;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.setting_layout);
		setTitle(this.getString(R.string.setting_title));
		initBackBtn();
		setupViews();
		setupListener();
	}

	private void setupViews() {
		initItem(R.id.setting_clear_data_view,
				getString(R.string.clear_cache_title),
				getString(R.string.clear_cache_des),
				R.drawable.list_item_selector);

		// 1、功能页面，包含三个项目（引导页面、帮助页面、和反馈页面）
		initItem(R.id.setting_guide_new_user_view,
				getString(R.string.use_guide),
				R.drawable.list_item_selector);
		initItem(R.id.setting_help_view, getString(R.string.help),
				R.drawable.list_item_selector);
		initItem(R.id.setting_feedback_view,
				getString(R.string.feedback_title),
				R.drawable.list_item_selector);

		// 2、应用页面，包含三个项目（关于、检查更新、应用推荐）
		initItem(R.id.setting_about_view, getString(R.string.abount_title),
				R.drawable.list_item_selector);
		initItem(R.id.setting_check_update_view,
				getString(R.string.check_update), SysUtils.getPackName(this),
				R.drawable.list_item_selector);
		initItem(R.id.setting_recommend_view,
				getString(R.string.recommend_app),
				R.drawable.list_item_selector);
		loginTv = (TextView) findViewById(R.id.login_Tv);
		// 3、环境
        VersionType versionType = app.getVersionType();
		if (versionType != null && versionType != VersionType.RELEASE) {
			View v = initItem(R.id.setting_env_view,
					getString(R.string.env_title),
					R.drawable.list_item_selector);
			v.setVisibility(View.VISIBLE);
			// LinearLayout.LayoutParams param = (LinearLayout.LayoutParams) v
			// .getLayoutParams();
			// param.setMargins(0,
			// getResources().getDimensionPixelSize(R.dimen.big_mp), 0, 0);
			// v.setLayoutParams(param);
			envTypeTv = (TextView) v.findViewById(R.id.desc_tv);
			envTypeTv.setText(app.getEnv().getEnvTypeStr());
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
	}

	private void setupListener() {
		loginTv.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
                showYesNoDialog("确认退出", "是否确认退出登录?", "退出", "取消", true, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if(which == DialogInterface.BUTTON_POSITIVE){
                            app.updateUser(new UserVo());
                            finish();
                        }
                    }
                }, null);
			}

		});
	}

	private void showClearBufDialog() {
        String title = getString(R.string.clear_cache_title) + "?";
        String msg = getString(R.string.clear_cache_msg);
        String okBtn = getString(R.string.clear_cache);
        String cancelBtn = getString(R.string.cancel);

        ClearBufferDialogListener listener = new ClearBufferDialogListener(this);
        showYesNoDialog(title, msg, okBtn, cancelBtn, true, listener, listener);
	}

	/*
	 * (非 Javadoc) <p>Title: onClick</p> <p>Description: </p>
	 *
	 * @param v
	 *
	 * @see android.view.View.OnClickListener#onClick(android.view.View)
	 */
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.setting_clear_data_view:
			showClearBufDialog();
			break;
		case R.id.setting_guide_new_user_view:
			toUserGuide();
			break;
		case R.id.setting_help_view:
			toHtml("http://m2.buy.qq.com/t/template.xhtml?tid=weigou_app_help",
					getString(R.string.help));
			break;
		case R.id.setting_feedback_view:
			go(FeedbackActivity.class);
			break;
		case R.id.setting_about_view:
			go(AboutActivity.class);
			break;
		case R.id.setting_check_update_view:
            checkUpdate();
			break;
		case R.id.setting_recommend_view:
			toHtml("http://m2.buy.qq.com/t/template.xhtml?tid=recommend_app",
					getString(R.string.recommend_app));
			break;
		case R.id.setting_env_view:
			showEnvDialog();
			break;
		}
	}

    /**
     * 检查更新
     */
    private void checkUpdate(){
        int ver = SysUtils.getAppVersion(getApplication());
        int env = Constants.CHECK_UPDATE_ENV_GAMMA;
        if(Env.getIdc().equals(app.getEnv())){
            env = Constants.CHECK_UPDATE_ENV_IDC;
        }
        String channel = SysUtils.getChannelId(this, "");
        int ch = Util.parseNum(channel);
        String mk = getMk();

        String url = app.getEnv().getServerUrl() + ConstantsUrl.CHECK_UPDATE;
        url += "?plat=1";
        url += "&mk="+mk;
        url += "&ver="+ver;
        url += "&env="+env;
        url += "&ch="+ch;
        url = appendPageInfo(url, PageIds.OprIndex.NON_PV_OPR);
        CheckUpdateTask task = new CheckUpdateTask(this, true);
        task.execute(url);
    }

	private void toUserGuide() {
		Intent intent = new Intent(this, GuideActivity.class);
		intent.putExtra(GuideActivity.BUTTON_TEXT,
				getString(R.string.back_setting));
		startActivity(intent);
	}

	/**
	 * 跳转到应用推荐
	 */
	private void toHtml(String url, String title) {
		Intent intent = new Intent(this, WebKitActivity.class);
		intent.putExtra(WebkitConstants.INTENT_TITLE, title);
		intent.putExtra(WebkitConstants.INTENT_URL, url);
		intent.putExtra(WebkitConstants.INTENT_SHOW_ACTION_BAR, "true");
		intent.putExtra(WebkitConstants.INTENT_APPEND_APP_PARAMS, "false");
		startActivity(intent);
	}

	private void go(Class<?> cls) {
		if (cls != null) {
			Intent intent = new Intent(this, cls);
			startActivity(intent);
		}
	}

	/**
	 * 初始化栏目
	 *
	 * @param viewId
	 *            栏目ID
	 * @param label
	 *            栏目名称
	 * @param bgId
	 *            栏目背景图片
	 * @return 初始化之后的栏目
	 */
	private View initItem(int viewId, String label, String desc, int bgId) {
		View view = findViewById(viewId);
		if (view != null) {
			TextView labelView = (TextView) view.findViewById(R.id.label_tv);
			if (labelView != null) {
				labelView.setText(label);
			}

			if (desc != null) {
				TextView descView = (TextView) view.findViewById(R.id.desc_tv);
				if (descView != null) {
					descView.setText(desc);
				}
			}
			view.setBackgroundResource(bgId);
			view.setPadding(25, 20, 25, 20);
			view.setOnClickListener(this);
		}
		return view;
	}

	/**
	 * 初始化栏目
	 *
	 * @param viewId
	 *            栏目ID
	 * @param label
	 *            栏目名称
	 * @param bgId
	 *            栏目背景图片
	 * @return 初始化之后的栏目
	 */
	private View initItem(int viewId, String label, int bgId) {
		return initItem(viewId, label, null, bgId);
	}

	private void updateEnv(final int which) {
		App.sWorker.post(new Runnable() {
			@Override
			public void run() {
				if (which > -1 && which < 3) {
					SettingInfo si = SettingStorage.read(SettingActivity.this);
					if (si == null) {
						si = new SettingInfo();
					}
					si.env = which;
					SettingStorage.write(SettingActivity.this, si);
					app.updateEnv(which);

					SettingActivity.this.runOnUiThread(new Runnable() {
						@Override
						public void run() {
							envTypeTv.setText(app.getEnv().getEnvTypeStr());
						};

					});
				}
			}

		});
	}

	/**
	 * 显示选择系统环境对话框
	 */
	private void showEnvDialog() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		String[] items = new String[] { Env.IDC_ENV_STR, Env.GAMMA_ENV_STR,
				Env.BETA_ENV_STR };

		int selected = app.getEnv().getEnvType();
		builder.setSingleChoiceItems(items, selected,
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						updateEnv(which);
						dialog.dismiss();
					}

				});
		AlertDialog dialog = builder.create();
		dialog.show();
	}
}
