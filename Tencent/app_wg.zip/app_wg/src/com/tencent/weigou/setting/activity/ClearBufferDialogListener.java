package com.tencent.weigou.setting.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.widget.Toast;
import com.tencent.weigou.R;
import com.tencent.weigou.base.App;
import com.tencent.weigou.cache.CacheUtils;
import com.tencent.weigou.util.Constants;

/**
 * 清除缓存事件监听器
 * @author ethonchan
 * @created 2014-01-26
 */
public class ClearBufferDialogListener implements DialogInterface.OnCancelListener, DialogInterface.OnClickListener {
    private Context mContext = null;

    public ClearBufferDialogListener(Context ctx) {
        mContext = ctx;
    }

    @Override
    public void onCancel(DialogInterface dialog) {
        dialog.dismiss();
        // 用户取消清除缓存说明用户抱怨缓存过大，但是又担心删除缓存导致流量问题，所以启动自动清理机制
        clearCache(false);
    }

    @Override
    public void onClick(DialogInterface dialog, int which) {
        dialog.dismiss();
        if (which == DialogInterface.BUTTON_POSITIVE) {
            clearCache(true);
            CharSequence tips = mContext.getText(R.string.clear_tips);
            Toast.makeText(mContext, tips, Constants.TOAST_NORMAL_LONG).show();
        } else if (which == DialogInterface.BUTTON_NEGATIVE) {
            // 用户取消清除缓存说明用户抱怨缓存过大，但是又担心删除缓存导致流量问题，所以启动自动清理机制
            clearCache(false);
        }
    }

    private void clearCache(final boolean clearAll) {
        App.sWorker.post(new Runnable() {
            @Override
            public void run() {
                CacheUtils.clearCache(clearAll);
            }
        });
    }
}
