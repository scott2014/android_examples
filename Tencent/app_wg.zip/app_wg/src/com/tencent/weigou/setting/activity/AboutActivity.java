package com.tencent.weigou.setting.activity;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Date;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

import com.tencent.weigou.R;
import com.tencent.weigou.base.activity.TitleBarActivity;
import com.tencent.weigou.util.CommonJumpUtils;
import com.tencent.weigou.util.SysUtils;
import com.tencent.weigou.util.VersionType;
import com.tencent.weigou.web.WebkitConstants;

/**
 * QQ网购"关于"页
 * 
 * @author wendyhu
 * 
 */
public class AboutActivity extends TitleBarActivity implements OnClickListener {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.about_layout);
		setTitle("关于");
		initBackBtn();
		setupViews();
		setupListener();
	}

	private void setupViews() {
		// 更新关于页面的版本信息
		TextView versionView = (TextView) findViewById(R.id.app_version_tv);
		String des = getVersionInfo();
		versionView.setText(des);

		// 获取版权信息
		TextView appCopyRight = (TextView) findViewById(R.id.appCopyRight_tv);
		String copyRightFormat = getText(R.string.app_copyright).toString();
		int year = new Date().getYear() + 1900;
		if (year < 2013)
			year = 2013;
		String copyRight = String.format(copyRightFormat, year);
		appCopyRight.setText(copyRight);
	}

	private void setupListener() {
		View contracts = findViewById(R.id.contracts_tv);
		contracts.setOnClickListener(this);
	}

	/**
	 * 获得软件的版本说明
	 * 
	 * @return
	 */
	private String getVersionInfo() {
		String ver = "1.0.0";
		String verNameExtra = "";

		ver = SysUtils.getPackName(this);
        ver = ver == null ? "" : ver;

        VersionType versionType = app.getVersionType();
        if(versionType == null){
            versionType = VersionType.defaultVersionType();
        }
		verNameExtra = "\n" + versionType.getExtra();
		String des = getString(R.string.app_name) + " Android  "
				+ ver.replaceAll(" ", "\n") + verNameExtra;
		des += "\n" + getString(R.string.contracts_no);
		return des;
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.contracts_tv:
			// Intent intent = new Intent(this, WebKitActivity.class);
			// intent.putExtra(WebkitConstants.INTENT_TITLE, "软件许可服务协议");
			// intent.putExtra(WebkitConstants.INTENT_URL,
			// "http://m.buy.qq.com/t/template.xhtml?tid=contracts");
			// intent.putExtra(WebkitConstants.INTENT_APPEND_APP_PARAMS,
			// "false");
			// startActivity(intent);

			StringBuffer buf = new StringBuffer(CommonJumpUtils.HTML);
			try {
				String urlParam = URLEncoder
						.encode("http://m2.buy.qq.com/t/template.xhtml?tid=weigou_contracts",
								"utf-8");
				buf.append("?").append(WebkitConstants.INTENT_TITLE)
						.append("=" + getString(R.string.permission))
						.append("&").append(WebkitConstants.INTENT_URL)
						.append("=").append(urlParam);
				CommonJumpUtils.go(v.getContext(), buf.toString());
			} catch (UnsupportedEncodingException e) {
			}

			break;
		}
	}
}
