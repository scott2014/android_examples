package com.tencent.weigou.setting.update;

import android.content.Context;
import android.content.DialogInterface;
import com.tencent.weigou.base.App;
import com.tencent.weigou.setting.activity.CheckUpdateVo;

/**
 * 检查更新对话框监听器
 * @author ethonchan
 * @created 2014-01-26
 */
public class UpdateDialogListener implements DialogInterface.OnClickListener, DialogInterface.OnCancelListener{

    private Context mContext;

    //  是否可取消
    private boolean cancellable = true;

    public UpdateDialogListener(Context context, boolean cancellable){
        this.cancellable = cancellable;
        this.mContext = context;
    }

    @Override
    public void onCancel(DialogInterface dialog) {
        if(cancellable){
            dialog.dismiss();
        }
    }

    @Override
    public void onClick(DialogInterface dialog, int which) {
        if(DialogInterface.BUTTON_POSITIVE == which){
            //TODO  开始下载安装包
            App.sWorker.post(new UpdateThread(mContext, new CheckUpdateVo().getVersion()));
        }else if(cancellable){
            dialog.dismiss();
        }
    }
}
