package com.tencent.weigou.setting.activity;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.pm.ApplicationInfo;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.InputFilter;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.tencent.weigou.R;
import com.tencent.weigou.base.App;
import com.tencent.weigou.base.activity.TitleBarActivity;
import com.tencent.weigou.base.json.JsonResult;
import com.tencent.weigou.util.Constants;
import com.tencent.weigou.util.ConstantsUrl;
import com.tencent.weigou.util.StringUtils;
import com.tencent.weigou.util.SysUtils;
import com.tencent.weigou.util.PageIds.OprIndex;
import com.tencent.weigou.util.http.JSONGetter;

/**
 * 反馈意见页面 这里允许用户提交反馈意见。如果用户已经登录，那么将用户的QQ号一并发送，如果没有登录，那么就不发送用户的QQ号。
 * 
 * @author wendyhu
 * 
 */
public class FeedbackActivity extends TitleBarActivity {
	// 反馈意见输入框
	private EditText feedback;
	// 反馈意见提交按钮
	private TextView feedbackButton;

	private String dialogTitle = "", overLoadErrMsg = "", errMsg = "";
	private String url = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.feedback_layout);
		setTitle(this.getResources().getText(R.string.feedback_title));
		initBackBtn();
		setupViews();
		setupListener();

	}

	private void setupViews() {
		dialogTitle = this.getResources().getString(R.string.notice);
		overLoadErrMsg = this.getResources().getString(
				R.string.feedback_max_notice);
		errMsg = this.getResources().getString(R.string.feedback_err_notice);
		url = this.appendPageInfo("http://m.buy.qq.com/api/"
				+ ConstantsUrl.FEEDBACK, OprIndex.PV_OPR);
		// 反馈输入框
		feedback = (EditText) findViewById(R.id.feedback_content);
		// 反馈按钮
		feedbackButton = (TextView) topbar.initRightBtnA(0, this.getResources()
				.getText(R.string.submit).toString(), null);
	}

	private void setupListener() {
		// 反馈意见的最大长度
		feedback.setFilters(new InputFilter[] { new InputFilter.LengthFilter(
				500) });

		// 提交反馈
		feedbackButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {
				// 避免同时点击多次
				feedbackButton.setClickable(false);
				String contentText = feedback.getText().toString();
				if (StringUtils.isNotBlank(contentText)) {
					try {
						final String content = URLEncoder.encode(
								(getVersionInfo() + contentText),
								Constants.ENCODE_CHARSET);

						if (StringUtils.isNotBlank(content))
							App.sWorker.post(new Runnable() {

								@Override
								public void run() {
									try {
										JSONGetter getter = new JSONGetter(
												false);
										JsonResult jr = getter.doGet(url
												+ "&c=" + content);
										if (jr != null) {
											update(jr.isSuccess(),
													jr.getErrMsg());
										} else {
											update(false, errMsg);
										}
									} catch (Exception e) {
										Log.e(TAG, "get my info err", e);
										update(false, errMsg);
									}

								}
							});
					} catch (UnsupportedEncodingException e) {
					}

				} else {
					Toast.makeText(FeedbackActivity.this, overLoadErrMsg,
							Constants.TOAST_NORMAL_LONG).show();
				}

				feedbackButton.setClickable(true);
			}
		});
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
	}

	/**
	 * 提交过程结束，不论是否成功，提示用户
	 */
	private void update(final boolean success, final String result) {
		this.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				Resources res = getResources();
				String msg = result;
				String okText = res.getString(R.string.ok);
				DialogInterface.OnClickListener clk = null;
				OnCancelListener canl = null;
				if (success) {
					clk = new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							FeedbackActivity.this.finish();
						}
					};

					canl = new OnCancelListener() {
						@Override
						public void onCancel(DialogInterface dialog) {
							FeedbackActivity.this.finish();
						}
					};
				}
				showAlertDialog(dialogTitle, msg, okText, true, clk, canl);
			}
		});
	}

	/**
	 * 
	 * @Title: getVersionInfo
	 * 
	 * @Description: 获取android版本信息
	 * 
	 * @return String 返回类型 格式为[and-版本-debug|Release]
	 * 
	 */
	private String getVersionInfo() {

		// 1、设置返回的数据格式和初始化数据
		String strFormat = "[and-%s-%s]";
		String ver = "unknown";
		String verNameExtra = "unknown";

		// 2、设置返回数据
		// 2.1 获取版本名
		ver = SysUtils.getPackName(FeedbackActivity.this);

		// 2.2 获取debug信息
		ApplicationInfo ai = getApplicationInfo();
		if (ai != null) {
			if ((ai.flags & ApplicationInfo.FLAG_DEBUGGABLE) > 0) {
				verNameExtra = "D";
			} else {
				verNameExtra = "R";
			}
		}

		// 3、回写数据
		return String.format(strFormat, ver, verNameExtra);
	}
}