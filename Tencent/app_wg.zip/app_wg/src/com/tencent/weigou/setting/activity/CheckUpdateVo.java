package com.tencent.weigou.setting.activity;

import com.tencent.weigou.base.model.vo.CommonVo;
import org.json.JSONObject;

/**
 * 检查更新VO
 * @author ethonchan
 * @created 2014-01-24
 */
public class CheckUpdateVo extends CommonVo {
    private Version version;

    public CheckUpdateVo(){
        errorCode = -1;
        errorMsg = "未知错误(-1)";
    }

    @Override
    public boolean parse(JSONObject data) {
        boolean success = super.parse(data);
        if (data != null) {
            version = new Version();
            version.flag = data.optInt("flag", 0);
            version.md5 = data.optString("md5");
            version.name = data.optString("name", "微购物");
            version.slogan = data.optString("slogan", "欢迎使用微购物APP");
            version.url = data.optString("url", "");
            version.version = data.optInt("version", 0);
        }
        return success;
    }

    public Version getVersion() {
        return version;
    }

    public static class Version {
        //  是否需要升级
        public int flag;

        //  安装文件的md5值
        public String md5;

        //  版本名称
        public String name;

        //  版本提示语
        public String slogan;

        //  版本下载url
        public String url;

        //  版本取值
        public int version;

        //  已经是最新了
        public final static int FLAG_ALREADY_LATEST = 0;

        //  不需要更新
        public final static int FLAG_NEED_UPDATE = 1;

        //  需要强制更新
        public final static int FLAG_NEED_FORCE_UPDATE = 2;
    }
}
