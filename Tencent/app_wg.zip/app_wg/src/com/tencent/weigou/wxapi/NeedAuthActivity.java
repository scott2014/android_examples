package com.tencent.weigou.wxapi;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import com.tencent.weigou.R;
import com.tencent.weigou.base.activity.BaseActivity;
import com.tencent.weigou.base.activity.ExitAppAdvisor;
import com.tencent.weigou.base.json.JsonResult;
import com.tencent.weigou.shopping.activity.ShoppingIndexActivity;
import com.tencent.weigou.user.UserVo;
import com.tencent.weigou.util.*;

import java.util.Properties;

/**
 * 去登录Activity
 * User: ethonchan
 * Date: 13-12-2
 * Time: 下午2:28
 */
public class NeedAuthActivity extends BaseActivity implements View.OnClickListener {
    //  跳转到登录的来源页面（如果为空，则认为是首页）
    public final static String SOURCE_ACTIVITY = "source_activity";

    //  微信授权码
    public final static String WX_OAUTH_CODE = "wx_code";

    //  用户信息
    public static final String INTENT_USER = "intent_user";

    //  获取token的异步线程
    private GetTokenByCodeTask mGetTokenTask = null;

    //  来源页面名
    private String mSourceClassName = null;

    private String mAlertTitle = "微信授权";

    //  退出APP的咨询者
    private ExitAppAdvisor mAdvisor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_layout);
        mAdvisor = new ExitAppAdvisor();

        View loginWX = findViewById(R.id.login_wx);
        loginWX.setOnClickListener(this);
//        View loginQQ = findViewById(R.id.login_qq);
//        loginQQ.setOnClickListener(this);

        Intent intent = getIntent();
        handleIntent(intent);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    @Override
    protected void onLogin(boolean success, UserVo newUserVo) {
        ;
    }

    protected void handleIntent(Intent intent) {
        if (intent == null) {
            return;
        }

        //  获取来源Intent
        mSourceClassName = intent.getStringExtra(SOURCE_ACTIVITY);
        if (isFromWX())
        //  来源于微信回调页面
        {
            //  登录态
            String code = intent.getStringExtra(WX_OAUTH_CODE);

            if (StringUtils.isBlank(code))
            //   用户取消
            {
                Log.d("TAG", " user cancelled!!!");
                showAlertDialog("微信授权", "哇哦, 未能获得您的微信授权!", "确定", true, null, null);
            } else
            //  授权登录
            {
                Log.d("TAG", " oauth passed!!! get code");
                //  调用接口换WId和xToken
                if (mGetTokenTask != null && mGetTokenTask.getStatus() != AsyncTask.Status.FINISHED) {
                    mGetTokenTask.cancel(true);
                }
                mGetTokenTask = new GetTokenByCodeTask();
                mGetTokenTask.execute(code);
            }
        } else
        //  来源于其他页面，跳去微信登录
        {
            Log.d("TAG", " oauth needed!!!");
        }
    }

    private boolean isFromWX() {
        boolean fromWX = WXEntryActivity.class.getName().equals(mSourceClassName);
        return fromWX;
    }

    @Override
    public String appendPageInfo(String urlWithoutPageInfo, PageIds.OprIndex ptagIndex) {
        StringBuilder url = new StringBuilder();
        url.append(urlWithoutPageInfo);
        if (!urlWithoutPageInfo.contains("?")) {
            url.append("?");
            url.append("wid=").append(getWid());
        } else {
            url.append("&wid=").append(getWid());
        }
        url.append("&pgid=").append(pageId);
        String ptag = PageIds.getPtag(sourcePageId, prePageId, pageId,
                ptagIndex);
        url.append("&ptag=").append(ptag);
        return url.toString();
    }

    @Override
    public void onBackPressed() {
        ExitAppAdvisor.Advice advice = mAdvisor.askAdviceWhenBackPressed();
        if (advice == ExitAppAdvisor.Advice.DO_NOTHING) {
            ;
        } else if (advice == ExitAppAdvisor.Advice.EXIT_APP) {
            exitAll();
            finish();
        } else if (advice == ExitAppAdvisor.Advice.ONE_MORE_CLICK) {
            Toast.makeText(this, "再按一次返回键退出",
                    Constants.TOAST_NORMAL_LONG).show();
        } else if (advice == ExitAppAdvisor.Advice.DEFAULT) {
            super.onBackPressed();
        }
    }

    /**
     * 返回到首页
     * @param userVo
     */
    protected void backToHome(UserVo userVo){
        Intent intent = new Intent(this, ShoppingIndexActivity.class);
        if(userVo != null){
            intent.putExtra(INTENT_USER, userVo);
        }
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    @Override
    public void onClick(View v) {
        Log.d("TAG", "clickBtn, toWX = " + (v.getId() == R.id.login_wx) + ", req.state=" + mSourceClassName);
        if (v.getId() == R.id.login_wx)
        //  微信登录
        {
            if (isReleaseKey()) {
                if (!WXUtils.isWXInstalled(this)) {
                    onWechatNotInstalled();
                } else if (!WXUtils.supportSDK(this)) {
                    onWechatNeedUpdate();
                } else {
                    boolean sendSuccess = WXUtils.sendAuthRequest(this, "");
                    if (sendSuccess) {
                        finish();
                    }
                }
            } else {
                UserVo user = UserVo.getMock();
                app.updateUser(user);
                Bundle data = new Bundle();
                data.putSerializable(INTENT_USER, user);
                //  跳转到目标页面
                CommonJumpUtils.goActivity(NeedAuthActivity.this, mSourceClassName, data);
                finish();
            }
        } else if (v.getId() == R.id.login_qq)
        //  QQ登录
        {
            Toast.makeText(this, "该功能正在开发中，请耐心等候...", Constants.TOAST_NORMAL_LONG).show();
        }
    }

    /**
     * TODO delete on release
     * 判断是否为release签名
     *
     * @return
     */
    private boolean isReleaseKey() {
        boolean isReleaseKey = false;
        try {
            PackageManager pkg = getBaseContext().getPackageManager();
            PackageInfo info = pkg.getPackageInfo("com.tencent.weigou", PackageManager.GET_SIGNATURES);
            String signature = info.signatures[0].toCharsString();
            String md5 = SysUtils.getMD5(signature, "");
            isReleaseKey = "1195d95f684d7f234044c27a774bcc".equals(md5);
        } catch (Exception e) {
            Log.d("TAG", "exception in isReleaseKey(), " + e.getMessage());
        }
        return isReleaseKey;
    }

    /**
     * 根据SDK分配的code获取对应的wid+xToken
     */
    class GetTokenByCodeTask extends AsyncTask<String, Void, UserVo> {

        @Override
        protected void onPreExecute() {
            // 检查网络状况
            if (!SysUtils.isNetworkAvaliable()) {
                cancel(true);
                showAlertDialog(mAlertTitle, "当前网络不可用", "确定", true, null, null);
            } else {
                super.onPreExecute();
                showProgressDialog(null, false);
            }
        }

        @Override
        protected UserVo doInBackground(String... params) {
            UserVo userVo = null;
            if (params != null && params.length > 0) {
                String code = params[0];
                String url = app.getEnv().getServerUrl() + ConstantsUrl.LOGIN;
                url += "?code=" + code;
                url += "&appid=" + WXUtils.WX_APP_ID;
                url = appendPageInfo(url, PageIds.OprIndex.PV_OPR);
                try {
                    JsonResult json = HttpUtils.doGet(url, false);
                    userVo = UserVo.parseJson(json);
                    Properties prop = new Properties();
                    if(json  == null){
                        prop.put(MTAConstants.KEY_CODE, -1);
                        MTAUtils.reportMTAEvent(MTAConstants.ID_GET_TOKEN_FAILED, prop);
                    } else if(!json.isSuccess()){
                        prop.put(MTAConstants.KEY_CODE, json.getErrCode());
                        MTAUtils.reportMTAEvent(MTAConstants.ID_GET_TOKEN_FAILED, prop);
                    }
                } catch (Exception e) {
                    String msg = e.getMessage();
                    msg = msg == null ? "NULL" : msg;
                    Log.e(TAG, "Fail to getTokenByCode. " + msg);
                }
            }
            return userVo;
        }

        @Override
        protected void onPostExecute(UserVo userVo) {
            super.onPostExecute(userVo);
            dismissDialogSafely(Constants.DIALOG_PROGRESS);

            if (userVo != null && !userVo.isTokenEmpty())
            //  登录成功
            {
                Log.d("TAG", "success-------onPostExecute@" + TAG);
                app.updateUser(userVo);

                //  跳回首页
                backToHome(userVo);
                finish();
            } else {
                Log.d("TAG", "fail-------onPostExecute@" + TAG);

                app.updateUser(new UserVo());
                showAlertDialog("微信授权", "哇哦, 登录失败啦, 请重试!", "确定", true, null, null);
            }
        }

        @Override
        protected void onCancelled() {
            super.onCancelled();
            dismissDialogSafely(Constants.DIALOG_PROGRESS);
        }
    }
}
