package com.tencent.weigou.wxapi;

import com.tencent.mm.sdk.constants.ConstantsAPI;
import com.tencent.mm.sdk.modelbase.BaseReq;
import com.tencent.mm.sdk.modelbase.BaseResp;
import com.tencent.mm.sdk.modelpay.PayResp;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.IWXAPIEventHandler;
import com.tencent.mm.sdk.openapi.WXAPIFactory;
import com.tencent.weigou.R;
import com.tencent.weigou.base.activity.TitleBarActivity;
import com.tencent.weigou.my.activity.MyActivity;
import com.tencent.weigou.my.activity.MyTicketActivity;
import com.tencent.weigou.util.ConstantsUrl;
import com.tencent.weigou.util.StringUtils;
import com.tencent.weigou.util.Util;
import com.tencent.weigou.web.WebKitActivity;
import com.tencent.weigou.web.WebkitConstants;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class WXPayEntryActivity extends TitleBarActivity implements
		IWXAPIEventHandler {

	private static final String TAG = "MicroMsg.SDKSample.WXPayEntryActivity";

	private IWXAPI api;

	private TextView mPayResTextView;
	private TextView mPayResdealView;
	private TextView mPayResReturnView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.pay_result);
		setTitle("支付结果");
		mPayResTextView = (TextView) findViewById(R.id.pay_res_text);
		mPayResdealView = (TextView) findViewById(R.id.pay_res_deal);
		mPayResReturnView = (TextView) findViewById(R.id.pay_res_return);

		api = WXAPIFactory.createWXAPI(this, WXUtils.WX_APP_ID);
		api.handleIntent(getIntent(), this);
	}

	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		setIntent(intent);
		api.handleIntent(intent, this);
	}

	@Override
	public void onReq(BaseReq req) {
	}

	@Override
	public void onResp(BaseResp resp) {
		Log.d(TAG, "onPayFinish, errCode = " + resp.errCode);
		if (resp.errCode == -2) {
			finish();
			return;
		}
		mPayResReturnView.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});

		if (resp.getType() == ConstantsAPI.COMMAND_PAY_BY_WX) {
			PayResp pay = (PayResp) resp;
			Log.d(TAG,
					String.format("微信支付结果：%s", "err:" + pay.errCode
							+ " errMsg:" + pay.errStr + " extDa:" + pay.extData
							+ " openId:" + pay.openId + " payId:"
							+ pay.prepayId + " retkey:" + pay.returnKey
							+ " tans:" + pay.transaction));
			String ext = pay.extData;
			if (!StringUtils.isBlank(ext)) {
				String[] deals = ext.split(";");
				String dealId = "";
				String cdealId = "";
				if (deals.length == 2) {
					dealId = deals[0];
					cdealId = deals[1];
				} else if (deals.length == 1) {
					if (ext.endsWith(";")) {
						dealId = deals[0];
					} else if (ext.startsWith(";")) {
						cdealId = deals[0];
					}
				}

				Log.d(TAG, "dealId=" + dealId + "cdealId=" + cdealId);
				if (!StringUtils.isBlank(dealId)
						&& !"null".equals(dealId)) {
					if (pay.errCode != 0) {
						mPayResTextView.setText("抱歉，订单支付失败!");
					} else {
						mPayResTextView.setText("支付成功!");
						mPayResTextView
								.setCompoundDrawablesWithIntrinsicBounds(
										R.drawable.ic_pay_success, 0, 0, 0);
						mPayResTextView.setCompoundDrawablePadding(Util.dip2px(
								this, 7));
					}
					mPayResdealView.setText("查看订单");
					mPayResdealView
							.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View v) {
									toDealList();
									finish();
								}
							});
				} else if (!StringUtils.isBlank(cdealId)) {
					if (pay.errCode != 0) {
						mPayResTextView.setText("抱歉，礼券支付失败!");
						mPayResdealView.setVisibility(View.GONE);
					} else {
						mPayResTextView.setText("支付成功!");
						mPayResTextView
								.setCompoundDrawablesWithIntrinsicBounds(
										R.drawable.ic_pay_success, 0, 0, 0);
						mPayResTextView.setCompoundDrawablePadding(Util.dip2px(
								this, 7));
						mPayResdealView.setText("查看礼券");
						mPayResdealView
								.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View v) {
										// 跳转我的礼券
										go(MyTicketActivity.class);
										finish();
									}
								});
					}

				} else {
					mPayResTextView.setText("抱歉，支付失败!");
					mPayResdealView.setText("个人中心");
					mPayResdealView
							.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View v) {
									// 异常情况跳转个人中心
									Intent intent = new Intent(
											WXPayEntryActivity.this,
											MyActivity.class);
									startActivity(intent);
									finish();
								}
							});
				}
			}
		} else {
			mPayResTextView.setText("抱歉，支付失败!");
			mPayResdealView.setText("个人中心");
			mPayResdealView.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					// 异常情况跳转个人中心
					Intent intent = new Intent(WXPayEntryActivity.this,
							MyActivity.class);
					startActivity(intent);
					finish();
				}
			});
		}
	}

	private void go(Class<?> cls) {
		if (cls != null) {
			Intent intent = new Intent(this, cls);
			startActivity(intent);
		}
	}

	private void toDealList() {
        String url = ConstantsUrl.MY_DEAL_LIST_URL;
        //  附带上登录态
        url += "&crmuin=" + getWid();
        url += "&wk2=" + getXtk();
		Intent intent = new Intent(this, WebKitActivity.class);
		Bundle bundle = new Bundle();
		bundle.putString(WebkitConstants.INTENT_TITLE,
				getString(R.string.my_deals));
		bundle.putString(WebkitConstants.INTENT_URL, url);
		bundle.putString(WebkitConstants.INTENT_SHOW_ACTION_BAR, "true");
		intent.putExtras(bundle);
		startActivity(intent);
	}
}