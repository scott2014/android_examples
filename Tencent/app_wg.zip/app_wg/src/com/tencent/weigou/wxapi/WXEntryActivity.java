package com.tencent.weigou.wxapi;

import android.content.Intent;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import com.tencent.mm.sdk.modelbase.BaseReq;
import com.tencent.mm.sdk.modelbase.BaseResp;
import com.tencent.mm.sdk.modelmsg.SendAuth;
import com.tencent.mm.sdk.openapi.IWXAPIEventHandler;
import com.tencent.weigou.base.activity.BaseActivity;
import com.tencent.weigou.util.StringUtils;

/**
 * 微信入口Activity，接收微信回跳
 * User: ethonchan
 * Date: 13-11-29
 * Time: 下午4:32
 */
public class WXEntryActivity extends BaseActivity implements IWXAPIEventHandler {

    //  跳去微信登录时附带的字符串
    public final static String INTENT_STATE = "state";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 隐藏任务栏
        Window myWindow = this.getWindow();
        WindowManager.LayoutParams wl = myWindow.getAttributes();
        wl.flags = WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
        //  背景完全透明
        wl.alpha = 0.0f;
        myWindow.setAttributes(wl);

        Intent intent = getIntent();
        handleIntent(intent);
    }

    protected void handleIntent(Intent intent) {
        if (intent != null) {
            WXUtils.handleWXIntent(this, this, intent);
        } else {
            Intent backIntent = new Intent(this, NeedAuthActivity.class);
            backIntent.putExtra(NeedAuthActivity.SOURCE_ACTIVITY, WXEntryActivity.class.getName());
            startActivity(backIntent);
            finish();
        }
    }

    @Override
    public void toLogin() {
        ;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    @Override
    public void onReq(BaseReq baseReq) {
        ;
    }

    @Override
    public void onResp(BaseResp baseResp) {
        Intent intent = new Intent(this, NeedAuthActivity.class);
        intent.putExtra(NeedAuthActivity.SOURCE_ACTIVITY, WXEntryActivity.class.getName());
        if (baseResp != null && baseResp instanceof SendAuth.Resp) {
            SendAuth.Resp resp = (SendAuth.Resp) baseResp;
            if (StringUtils.isNotBlank(resp.code))
            //  确认登录
            {
                intent.putExtra(NeedAuthActivity.WX_OAUTH_CODE, resp.code);
            }

            if (StringUtils.isNotBlank(resp.state))
            //  目标页面名
            {
                intent.putExtra(INTENT_STATE, resp.state);
            }

            startActivity(intent);
        }

        finish();
    }
}
