package com.tencent.weigou.wxapi;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * 微信注册广播接收器
 * User: ethonchan
 * Date: 13-11-12
 * Time: 上午11:21
 */
public class WXRegisterBroadcastReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
//        WXUtils.registerApp(context);
    }
}
