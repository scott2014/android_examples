package com.tencent.weigou.page.model.vo;

import com.tencent.weigou.base.model.vo.CommonVo;

public class CommonPageVo extends CommonVo {

	public String id = "";
	
	public String name = "";
	
	public String logoUrl = "";
	
	public String landscapePicUrl = "";
	
	public boolean isSubscribed = false;
	
	public int type;
	
	public String tel = "";
	
	public String longitude = "";
	
	public String latitude = "";
}