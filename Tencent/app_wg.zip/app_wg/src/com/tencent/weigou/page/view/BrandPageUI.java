package com.tencent.weigou.page.view;

import java.util.List;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.RelativeLayout.LayoutParams;

import com.tencent.weigou.R;
import com.tencent.weigou.base.App;
import com.tencent.weigou.base.TypeVo;
import com.tencent.weigou.common.ui.ScaleImageView;
import com.tencent.weigou.page.activity.BrandPageActivity;
import com.tencent.weigou.page.model.vo.BrandPageVo;
import com.tencent.weigou.page.model.vo.CommonPageVo;
import com.tencent.weigou.page.model.vo.BrandPageVo.ShopItemVo;
import com.tencent.weigou.util.StringUtils;
import com.tencent.weigou.util.Util;

/**
 * 
 * @ClassName： BrandPageUI
 * 
 * @Description： 品牌Page UI
 * @author wamiwen
 * @date 2013-11-1 下午5:57:13
 * 
 */
public class BrandPageUI extends CommonPageUI {

	/**
	 * 品牌介绍
	 */
	private TextView brandDescTv;

	/**
	 * 品牌下门店列表
	 */
	private ListView shopListView;

	private ShopListAdapter listAdapter;

	@Override
	public void initView(View outterView) {
		super.initViewV2(outterView);

		shopListView = (ListView) outterView.findViewById(R.id.listview);
		View headerView = LayoutInflater.from(context).inflate(
				R.layout.brand_page_header, null);
		titleImage = (ScaleImageView) headerView.findViewById(R.id.landscape);
		titleImage.setScale(2.286f);
		logoImage = (ImageView) headerView.findViewById(R.id.logo);
		titleTv = (TextView) headerView.findViewById(R.id.title);
		locationTv = (TextView) headerView.findViewById(R.id.location);
		locationTv.setVisibility(View.INVISIBLE);
		brandDescTv = (TextView) headerView.findViewById(R.id.brand_desc);

		AbsListView.LayoutParams params = new AbsListView.LayoutParams(
				LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
		headerView.setLayoutParams(params);
		shopListView.addHeaderView(headerView);
		
		shopListView.setOnItemClickListener((BrandPageActivity)context);
	}

	@Override
	public void updateContent(CommonPageVo vo) {
		if (vo == null) {
			return;
		}
		super.updateContent(vo);
		BrandPageVo brandPageVo = (BrandPageVo) vo;
		
		String brandDesc = StringUtils.stripEnd(brandPageVo.brandDesc.trim(), "\n");
		brandDescTv.setText(brandDesc);

		listAdapter = new ShopListAdapter(brandPageVo.shopItemList);
		shopListView.setAdapter(listAdapter);
	}
	
	@Override
	protected void recordSubState(String id, boolean sub) {
		super.recordSubState(id, sub);
		TypeVo typeVo = new TypeVo(id, sub);
		App app = App.getInstance();
		app.putBrandSubInfo(typeVo);
	}

	/**
	 * 
	 * @ClassName： ShopListAdapter
	 * 
	 * @Description： 门店列表List 适配器
	 * @author wamiwen
	 * @date 2013-12-26 上午11:04:15
	 * 
	 */
	private class ShopListAdapter extends BaseAdapter {

		private List<Object> shopItemList;

		public ShopListAdapter(List<Object> shopItemList) {
			this.shopItemList = shopItemList;
		}

		@Override
		public int getCount() {
			return shopItemList == null ? 0 : shopItemList.size();
		}

		@Override
		public Object getItem(int position) {
			if (shopItemList != null && shopItemList.size() > position) {
				return shopItemList.get(position);
			}
			return null;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public boolean isEnabled(int position) {
			Object obj = getItem(position);
			if (obj != null && obj instanceof String) {
				return false;
			} else {
				return super.isEnabled(position);
			}
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder = null;
			if (convertView == null) {
				holder = new ViewHolder();
				convertView = LayoutInflater.from(parent.getContext()).inflate(
						R.layout.shop_list_item, null);
				holder.nameTv = (TextView) convertView
						.findViewById(R.id.shop_name);
				holder.promotionTv = (TextView) convertView
						.findViewById(R.id.shop_promotion);
				holder.distanceTv = (TextView) convertView
						.findViewById(R.id.shop_distance);
				holder.typeDescTv = (TextView) convertView
						.findViewById(R.id.shop_list_desc);
				holder.itemOutterView = (RelativeLayout) convertView
						.findViewById(R.id.shop_item_outter);

				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}
			Object obj = getItem(position);
			if (obj != null && obj instanceof String) {
				String typeDesc = (String) obj;
				holder.typeDescTv.setVisibility(View.VISIBLE);
				holder.typeDescTv.setText(typeDesc);
				holder.itemOutterView.setVisibility(View.GONE);
			} else if (obj != null && obj instanceof ShopItemVo) {
				holder.typeDescTv.setVisibility(View.GONE);
				holder.itemOutterView.setVisibility(View.VISIBLE);
				ShopItemVo shopItemVo = (ShopItemVo) obj;
				holder.nameTv.setText(shopItemVo.name);
				holder.promotionTv.setText(shopItemVo.promotion);
				if (shopItemVo.distance < 0) {
					holder.distanceTv.setVisibility(View.INVISIBLE);
				} else {
					holder.distanceTv.setText(Util
							.getDistance(shopItemVo.distance));
				}

				convertView.setTag(R.id.tag_shop_id, shopItemVo.id);
				convertView.setTag(R.id.tag_shop_name, shopItemVo.name);
			}

			return convertView;
		}

	}

	static class ViewHolder {
		TextView nameTv;
		TextView promotionTv;
		TextView distanceTv;
		TextView typeDescTv;
		RelativeLayout itemOutterView;
	}

}
