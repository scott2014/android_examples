package com.tencent.weigou.page.model.vo;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.tencent.weigou.util.Constants;

/**
 * 
 * @ClassName： ShopPageVo
 *
 * @Description： 门店Page
 * @author wamiwen
 * @date 2013-11-5 下午10:18:22
 *
 */
public class ShopPageVo extends CommonPageVo {
	
	public String address = "";
	
	public int floor;
	
	public String brandId = "";
	
	public int picCount;
	
	public List<String> picUrls = new ArrayList<String>();
	
	public ShopPageVo() {
		type = Constants.SHOP_ID;
	}
	
	@Override
	public boolean parse(JSONObject jo) {
		try {
			id = jo.optString("id", "");
			name = jo.optString("name", "");
			address = jo.optString("address", "");
			floor = jo.optInt("floor", 0);
			longitude = jo.optString("longitude", "");
			latitude = jo.optString("latitude", "");
			tel = jo.optString("tel", "");
			logoUrl = jo.optString("brandLogo", "");
			brandId = jo.optString("brandId", "");
			isSubscribed = jo.optInt("subscribe", 0) == 1 ? true : false;
			landscapePicUrl = jo.optString("landscapePic", "");
			picCount = jo.optInt("picCount", 0);
			JSONArray picsArray = jo.optJSONArray("pics");
			for (int i = 0, size = picsArray.length(); i < size; i++) {
				if (picUrls.size() == 2) {
					break;
				}
				picUrls.add(picsArray.optJSONObject(i).optString("url", ""));
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}

}
