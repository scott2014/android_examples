package com.tencent.weigou.page.model.vo;

import java.util.LinkedList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.tencent.weigou.util.Constants;

/**
 * 
 * @ClassName： BrandPageVo
 *
 * @Description： 品牌PageVo
 * @author wamiwen
 * @date 2013-11-1 下午5:59:19
 *
 */
public class BrandPageVo extends CommonPageVo {
	
	public String brandDesc = "";
	
	public static final String ALL_DESC = "全部门店";
	public static final String SUBSCRIBED_DESC = "我关注的门店";
	
	public List<Object> shopItemList = new LinkedList<Object>();
	
	public BrandPageVo() {
		type = Constants.BRAND_ID;
	}
	
	@Override
	public boolean parse(JSONObject jo) {
		try {
			JSONObject brandObj = jo.optJSONObject("brand");
			if (brandObj != null) {
				id = brandObj.optString("id", "");
				name = brandObj.optString("name", "");
				logoUrl = brandObj.optString("logo", "");
				brandDesc = brandObj.optString("desc", "");
				isSubscribed = brandObj.optInt("userSubscribe", 0) == 1 ? true : false;
				JSONArray brandPics = brandObj.optJSONArray("brandPics");
				if (brandPics != null && brandPics.length() > 0) {
					for (int i = 0, len = brandPics.length(); i < len; i++) {
						JSONObject picObj = brandPics.optJSONObject(i);
						if (picObj != null && (picObj.optInt("type", 0) == 1)) {
							landscapePicUrl = picObj.optString("url", "");
						}
					}
				}
			}
			JSONArray subscribedList = jo.optJSONArray("subscribedList");
			if (subscribedList != null && subscribedList.length() > 0) {
				shopItemList.add(SUBSCRIBED_DESC);
				for (int i = 0, len = subscribedList.length(); i < len; i++) {
					JSONObject shopItemObj = subscribedList.optJSONObject(i);
					ShopItemVo shopItemVo = ShopItemVo.parseJSONObj(shopItemObj);
					if (shopItemVo == null) {
						continue;
					}
					shopItemList.add(shopItemVo);
				}
			}
			JSONArray allList = jo.optJSONArray("shopList");
			if (allList != null && allList.length() > 0) {
				shopItemList.add(ALL_DESC);
				for (int i = 0, len = allList.length(); i < len; i++) {
					JSONObject shopItemObj = allList.optJSONObject(i);
					ShopItemVo shopItemVo = ShopItemVo.parseJSONObj(shopItemObj);
					if (shopItemVo == null) {
						continue;
					}
					shopItemList.add(shopItemVo);
				}
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public static class ShopItemVo {
		public String id = "";
		public String name = "";
		public int distance;
		public String address = "";
		public String promotion = "";
		
		public ShopItemVo(String id, String name, int distance, String address, String promotion) {
			this.id = id;
			this.name = name;
			this.distance = distance;
			this.address = address;
			this.promotion = promotion;
		}
		
		public static ShopItemVo parseJSONObj(JSONObject jsonObj) {
			if (jsonObj == null) {
				return null;
			}
			String id = jsonObj.optString("id", "");
			String name = jsonObj.optString("name", "");
			int distance = jsonObj.optInt("distance", 0);
			String address = jsonObj.optString("address", "");
			String promotionDesc = jsonObj.optString("promotionDesc", "");
			
			return new ShopItemVo(id, name, distance, address, promotionDesc);
		}
	}

}
