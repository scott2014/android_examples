package com.tencent.weigou.page.view;

import android.view.View;
import android.view.ViewStub;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.tencent.weigou.R;
import com.tencent.weigou.base.App;
import com.tencent.weigou.base.TypeVo;
import com.tencent.weigou.common.ui.ScaleImageView;
import com.tencent.weigou.page.activity.MallPageActivity;
import com.tencent.weigou.page.model.vo.CommonPageVo;
import com.tencent.weigou.page.model.vo.MallPageVo;
import com.tencent.weigou.page.model.vo.MallPageVo.TicketItemVo;
import com.tencent.weigou.util.Util;

/**
 * 
 * @ClassName： MallPageUI
 * 
 * @Description： 商城MALL Page页
 * @author wamiwen
 * @date 2013-10-31 下午3:39:33
 * 
 */
public class MallPageUI extends CommonPageUI {

	/**
	 * 热销礼券View
	 */
	private View hotTicketsView;

	/**
	 * 热销礼券title
	 */
	private RelativeLayout hotTicketsTitleView;

	@Override
	public void initView(View outterView) {
		super.initView(outterView);

		// 热销礼券
		hotTicketsView = outterView.findViewById(R.id.page_hot_tickets);
		// 热销礼券title
		hotTicketsTitleView = (RelativeLayout) outterView.findViewById(R.id.page_hot_tickets_title);
				
		phoneView = (RelativeLayout) outterView.findViewById(R.id.phone_outter);
		phoneTv = (TextView) outterView.findViewById(R.id.phone);
		addressView = (RelativeLayout) outterView
				.findViewById(R.id.address_outter);
		addressTv = (TextView) outterView.findViewById(R.id.address);

		phoneView.setOnClickListener((MallPageActivity) context);
		addressView.setOnClickListener((MallPageActivity) context);
		hotTicketsTitleView.setOnClickListener((MallPageActivity) context);
	}

	@Override
	public void updateContent(CommonPageVo vo) {
		super.updateContent(vo);
		if (vo == null) {
			return;
		}
		MallPageVo mallPageVo = (MallPageVo) vo;
		
		// 距离
		locationTv.setText(Util.getDistance(mallPageVo.distance));
		// 电话
		phoneTv.setText(mallPageVo.tel);
		// 地址
		addressTv.setText(mallPageVo.address);
		
		// 热销礼券
		if (mallPageVo.ticketItemList.size() > 2) {
			initTicketItemView(R.id.viewstub_ticket_left, mallPageVo.ticketItemList.get(0));
			initTicketItemView(R.id.viewstub_ticket_middle, mallPageVo.ticketItemList.get(1));
			initTicketItemView(R.id.viewstub_ticket_right, mallPageVo.ticketItemList.get(2));
		} else if (mallPageVo.ticketItemList.size() > 1) {
			initTicketItemView(R.id.viewstub_ticket_left, mallPageVo.ticketItemList.get(0));
			initTicketItemView(R.id.viewstub_ticket_middle, mallPageVo.ticketItemList.get(1));
		} else if (mallPageVo.ticketItemList.size() > 0) {
			initTicketItemView(R.id.viewstub_ticket_left, mallPageVo.ticketItemList.get(0));
		} else {
			hotTicketsView.setVisibility(View.GONE);
		}
	}
	
	@Override
	protected void recordSubState(String id, boolean sub) {
		super.recordSubState(id, sub);
		TypeVo typeVo = new TypeVo(id, sub);
		App app = App.getInstance();
		app.putMallSubInfo(typeVo);
	}

	/**
	 * 
	 * @Title: initTicketItemView
	 * 
	 * @Description: 初始化热销礼券的每一个item
	 * @param @param viewId
	 * @param @param ticketItemVo 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	private void initTicketItemView(final int viewId,
			final TicketItemVo ticketItemVo) {
		stub = (ViewStub) outterView.findViewById(viewId);
		View itemView = stub.inflate();
		if (itemView != null) {
			ScaleImageView ticketImage = (ScaleImageView) itemView
					.findViewById(R.id.ticket_image);
			TextView ticketNameTv = (TextView) itemView
					.findViewById(R.id.ticket_name);

			ticketImage.setScale(1.727f);
			asyncLoadImage(ticketImage, ticketItemVo.imgUrl);
			ticketNameTv.setText(ticketItemVo.name);

			itemView.setTag(R.id.tag_ticket_id, ticketItemVo.cardId);
			itemView.setTag(R.id.tag_ticket_name, ticketItemVo.name);
			itemView.setOnClickListener((MallPageActivity) context);
		}
	}

}
