package com.tencent.weigou.page.view;

import android.graphics.Bitmap;
import android.view.View;
import android.view.ViewStub;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.tencent.weigou.R;
import com.tencent.weigou.base.activity.BaseActivity;
import com.tencent.weigou.base.view.UI;
import com.tencent.weigou.common.ui.ScaleImageView;
import com.tencent.weigou.page.activity.CommonPageActivity;
import com.tencent.weigou.page.model.vo.CommonPageVo;
import com.tencent.weigou.util.AsyncImageLoader;
import com.tencent.weigou.util.IImageLoadedCallBack;

/**
 * 
 * @ClassName： CommonPageUI
 *
 * @Description：Page页公共UI
 * @author wamiwen
 * @date 2013-11-12 下午4:06:37
 *
 */
public class CommonPageUI extends UI {

	/**
	 * 标题栏
	 */
	protected ImageView backImgView;
	protected TextView subTxtView;
	protected TextView titleTxtView;
	
	/**
	 * title
	 */
	protected ScaleImageView titleImage;
	protected ImageView logoImage;
	protected TextView titleTv;
	protected TextView locationTv;
	
	/**
	 * 电话
	 */
	protected RelativeLayout phoneView;
	protected TextView phoneTv;
	
	/**
	 * 地址
	 */
	protected RelativeLayout addressView;
	protected TextView addressTv;
	
	protected ViewStub stub;
	
	/**
	 * 图片异步加载工具
	 */
	protected AsyncImageLoader asyncImageLoader = new AsyncImageLoader(true);
	
	@Override
	public void initView(View outterView) {
		super.initView(outterView);
		backImgView = (ImageView) outterView.findViewById(R.id.top_bar_back_tv);
		subTxtView = (TextView) outterView.findViewById(R.id.top_bar_right_1_tv);
		titleTxtView = (TextView) outterView.findViewById(R.id.top_bar_title);
		// landsape, logo
		titleImage = (ScaleImageView) outterView.findViewById(R.id.landscape);
//		titleImage.setScale(1.73f);
		titleImage.setScale(2.286f);
		logoImage = (ImageView) outterView.findViewById(R.id.logo);
		titleTv = (TextView) outterView.findViewById(R.id.title);
		locationTv = (TextView) outterView.findViewById(R.id.location);
		
		backImgView.setOnClickListener((CommonPageActivity)context);
		subTxtView.setOnClickListener((CommonPageActivity)context);
	}
	
	protected void initViewV2(View outtView) {
		super.initView(outtView);
		backImgView = (ImageView) outterView.findViewById(R.id.top_bar_back_tv);
		subTxtView = (TextView) outterView.findViewById(R.id.top_bar_right_1_tv);
		titleTxtView = (TextView) outterView.findViewById(R.id.top_bar_title);
		
		backImgView.setOnClickListener((CommonPageActivity)context);
		subTxtView.setOnClickListener((CommonPageActivity)context);
	}

	public void updateContent(CommonPageVo vo) {
        if(vo != null){
        	setTitle(vo.name);
		    asyncLoadImage(titleImage, vo.landscapePicUrl);
		    asyncLoadImage(logoImage, vo.logoUrl);
		    titleTv.setText(vo.name);
		    
		    if (subTxtView != null) {
		    	subTxtView.setTag(vo);
				if (vo.isSubscribed) {
					subTxtView.setCompoundDrawablesWithIntrinsicBounds(R.drawable.mall_detail_sub, 0, 0, 0);
				} else {
					subTxtView.setCompoundDrawablesWithIntrinsicBounds(R.drawable.brand_not_sub, 0, 0, 0);
				}
			}
        }
	}
	
	/**
	 * 
	 * @Title: setTitle
	 *
	 * @Description: 设置标题栏title
	 * @param @param title  设定文件
	 * @return void  返回类型
	 * @throws
	 */
	public void setTitle(String title) {
		if (titleTxtView != null) {
			titleTxtView.setText(title);
		}
	}
	
	/**
	 * 
	 * @Title: onSubStart
	 *
	 * @Description: 新增/取消关注开始时
	 * @param   设定文件
	 * @return void  返回类型
	 * @throws
	 */
	public void onSubStart() {
		if (subTxtView != null) {
			Object subTag = subTxtView.getTag();
			if (subTag != null && subTag instanceof CommonPageVo) {
				CommonPageVo vo = (CommonPageVo) subTag;
				boolean tmpIsSub = !vo.isSubscribed;
				if (tmpIsSub) {
					subTxtView.setCompoundDrawablesWithIntrinsicBounds(R.drawable.mall_detail_sub, 0, 0, 0);
				} else {
					subTxtView.setCompoundDrawablesWithIntrinsicBounds(R.drawable.brand_not_sub, 0, 0, 0);
				}
			}
		}
	}
	
	/**
	 * 
	 * @Title: onSubSuccess
	 *
	 * @Description: 新增/取消关注成功
	 * @param   设定文件
	 * @return void  返回类型
	 * @throws
	 */
	public void onSubSuccess() {
		if (subTxtView != null) {
			Object subTag = subTxtView.getTag();
			if (subTag != null && subTag instanceof CommonPageVo) {
				CommonPageVo vo = (CommonPageVo) subTag;
				vo.isSubscribed = !vo.isSubscribed;
				subTxtView.setTag(vo);
				recordSubState(vo.id, vo.isSubscribed);
			}
		}
	}
	
	/**
	 * 
	 * @Title: onSubFailure
	 *
	 * @Description: 新增/取消关注失败
	 * @param   设定文件
	 * @return void  返回类型
	 * @throws
	 */
	public void onSubFailure() {
		if (subTxtView != null) {
			Object subTag = subTxtView.getTag();
			if (subTag != null && subTag instanceof CommonPageVo) {
				CommonPageVo vo = (CommonPageVo) subTag;
				if (vo.isSubscribed) {
					subTxtView.setCompoundDrawablesWithIntrinsicBounds(R.drawable.mall_detail_sub, 0, 0, 0);
					((BaseActivity)context).showToast(context.getString(R.string.remove_sub_failure), R.drawable.mall_detail_sub_fail);
				} else {
					subTxtView.setCompoundDrawablesWithIntrinsicBounds(R.drawable.brand_not_sub, 0, 0, 0);
					((BaseActivity)context).showToast(context.getString(R.string.add_sub_failure), R.drawable.mall_detail_sub_fail);
				}
			}
		}
	}
	
	protected void recordSubState(String id, boolean sub) {
		
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		if (asyncImageLoader != null) {
			asyncImageLoader.destroy();
		}
	}
	
	/**
	 * 异步加载图片
	 * 
	 * @param imgView
	 * @param url
	 */
	protected void asyncLoadImage(final ImageView imgView, final String url) {
		final Bitmap drawable = asyncImageLoader.loadDrawable(url, imgView,
				new IImageLoadedCallBack() {

					@Override
					public void imageLoaded(final ImageView imageView, final Bitmap bitmap,
							final String imageUrl) {
						if (imageView != null && bitmap != null) {
							imageView.setImageBitmap(bitmap);
						}
					}

				});
		if (drawable != null) {
			imgView.setImageBitmap(drawable);
		} else {
			//imgView.setImageResource(R.drawable.loading_big);
		}
	}
	
}
