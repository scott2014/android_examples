package com.tencent.weigou.page.model.vo;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.tencent.weigou.util.Constants;

/**
 * 
 * @ClassName： MallPageVo
 *
 * @Description： MallPageVo
 * @author wamiwen
 * @date 2013-10-31 下午3:42:43
 *
 */
public class MallPageVo extends CommonPageVo {
	
	public String mappid = "";
	
	public String refMallId = "";
	
	public String address = "";
	
	public int distance;
	
	public List<TicketItemVo> ticketItemList = new ArrayList<TicketItemVo>();
	
	public MallPageVo() {
		type = Constants.MALL_ID;
	}
	
	@Override
	public boolean parse(JSONObject jo) {
		try {
			id = jo.optString("mallId", "");
			name = jo.optString("mallName", "");
			landscapePicUrl = jo.optString("landscapePic", "");
			logoUrl = jo.optString("logo", "");
			tel = jo.optString("tel", "");
			longitude = jo.optString("longitude", "");
			latitude = jo.optString("latitude", "");
			mappid = jo.optString("appId", "");
			refMallId = jo.optString("relMallId", "");
			distance = jo.optInt("distance", 0);
			address = jo.optString("address", "");
			isSubscribed = jo.optInt("userSubscribled", 0) == 1 ? true : false;
			
			// 热销礼券
			JSONObject shopCardlist = jo.optJSONObject("shopCardlist");
			if (shopCardlist != null) {
				JSONArray listArray = shopCardlist.optJSONArray("list");
				if (listArray != null && listArray.length() > 0) {
					for (int i = 0, len = listArray.length(); i < len; i++) {
						JSONObject cardObj = listArray.optJSONObject(i);
						TicketItemVo ticketItemVo = TicketItemVo.parseJSONObject(cardObj);
						if (ticketItemVo != null) {
							ticketItemList.add(ticketItemVo);
						}
					}
				}
			}
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public static class TicketItemVo {
		
		public String cardId = "";
		
		public String imgUrl = "";
		
		public String mallId = "";
		
		public String name = "";
		
		private TicketItemVo(String cardId, String imgUrl, String mallId, String name) {
			this.cardId = cardId;
			this.imgUrl = imgUrl;
			this.mallId = mallId;
			this.name = name;
		}
		
		public static TicketItemVo parseJSONObject(JSONObject jsonObj) {
			if (jsonObj == null) {
				return null;
			}
			String cardId = jsonObj.optString("cardId", "");
			String name = jsonObj.optString("name", "");
			String mallId = jsonObj.optString("mallId", "");
			String imgUrl = jsonObj.optString("imgUrl", "");
			
			return new TicketItemVo(cardId, imgUrl, mallId, name);
		}
	}
	
}
