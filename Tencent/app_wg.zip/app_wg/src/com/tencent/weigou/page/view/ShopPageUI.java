package com.tencent.weigou.page.view;

import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.tencent.weigou.R;
import com.tencent.weigou.page.activity.ShopPageActivity;
import com.tencent.weigou.page.model.vo.CommonPageVo;
import com.tencent.weigou.page.model.vo.ShopPageVo;

/**
 * 
 * @ClassName： ShopPageUI
 * 
 * @author wamiwen
 * @date 2013-10-30 下午9:02:07
 * 
 */
public class ShopPageUI extends CommonPageUI {

	@Override
	public void initView(View outterView) {
		super.initView(outterView);

		locationTv.setVisibility(View.INVISIBLE);
		titleImage.setImageResource(R.drawable.tmp_shop_img);

		phoneView = (RelativeLayout) outterView.findViewById(R.id.phone_outter);
		phoneTv = (TextView) outterView.findViewById(R.id.phone);
		addressView = (RelativeLayout) outterView
				.findViewById(R.id.address_outter);
		addressTv = (TextView) outterView.findViewById(R.id.address);

		phoneView.setOnClickListener((ShopPageActivity) context);
		addressView.setOnClickListener((ShopPageActivity) context);
	}
	
	@Override
	public void updateContent(CommonPageVo vo) {
		super.updateContent(vo);
		if (vo != null) {
		    ShopPageVo shopPageVo = (ShopPageVo) vo;
		
		    phoneTv.setText(shopPageVo.tel);
		    addressTv.setText(shopPageVo.address);
        }
	}

}
