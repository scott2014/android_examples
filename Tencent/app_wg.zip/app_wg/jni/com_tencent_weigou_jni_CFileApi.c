#include "com_tencent_weigou_jni_CFileApi.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/*
 * Class:     com_qq_buy_jni_CFileApi
 * Method:    ltos long转成radix进制的字符串
 *
 *
 * @param i 魔术字
 * @param radix 进制
 * @param retBuf 返回的字符串
 */
int Java_com_qq_buy_jni_CFileApi_ltos(jlong i, int radix,char* retBuf)
{
	if (radix < 2 || radix > 36)
	    radix = 10;

    char digits[] = {
	'0' , '1' , '2' , '3' , '4' , '5' ,
	'6' , '7' , '8' , '9' , 'a' , 'b' ,
	'c' , 'd' , 'e' , 'f' , 'g' , 'h' ,
	'i' , 'j' , 'k' , 'l' , 'm' , 'n' ,
	'o' , 'p' , 'q' , 'r' , 's' , 't' ,
	'u' , 'v' , 'w' , 'x' , 'y' , 'z'
    };

	char buf[65] = {0};
	jlong negative = i ;
	int charPos = 64;

	if (negative>=0) {
	    i = -i;
	}

	while (i <= -radix) {
	    buf[charPos--] = digits[(int)(-(i % radix))];
	    i = i / radix;
	}
	buf[charPos] = digits[(int)(-i)];

	if (negative<0) {
	    buf[--charPos] = '-';
	}
	int pos = charPos, size = 65 - charPos,j=0;
	for(;j<size;pos++)
		retBuf[j++]=buf[pos];

	return 0;
}

/*
 * Class:     com_qq_buy_jni_CFileApi
 * Method:    getToken 获取一个token
 *
 *         通过对请求参加进行hash
 *
 * @param magicNum 魔术字
 * @param source 源串
 * Signature: (Ljava/lang/Integer;)J
 */
JNIEXPORT jint JNICALL Java_com_qq_buy_jni_CFileApi_sign_hash
  (JNIEnv * env, jint magic, jstring source)
{
    //在java中由于是unicode编码，无论是英文字母还是汉字每个字符都是占用2个字节。但是在jni中的字符时utf-8编码，每
	//个字符不是等长的。所以在java和jni调用的时候要注意这个问题。

 	//1、转成char字符，这里通过反射用java的方式来获取值
	//这里太复杂了，效率会有点低，不建议用反射了。
	/**
	jclass     jstrObj   = (*env)->FindClass(env, "java/lang/String");
    jstring    encode    = (*env)->NewStringUTF(env, "utf-8");
    jmethodID  methodId  = (*env)->GetMethodID(env, jstrObj, "getBytes", "(Ljava/lang/String;)[B");
    jbyteArray byteArray = (jbyteArray)(*env)->CallObjectMethod(env, source, methodId, encode);
    jsize      strLen    = (*env)->GetArrayLength(env, byteArray);
	jbyte* pByte = (*env)->GetByteArrayElements(env, byteArray, JNI_FALSE);
	*/
	int hash = magic + 5381;
	if( source == NULL)
		return hash & 0x7fffffff;

	const char* pByte = (*env)->GetStringUTFChars(env, source, NULL);
	if ( pByte == NULL )
		return hash & 0x7fffffff;

	//2、初始化hash值，和参数
	int i = 0, item = 0, strLen = strlen(pByte);
    for( ; i < strLen; ++i){
	   item = (pByte[i] < 0 ? (256 + pByte[i]):(pByte[i]));
       hash += (hash << 5) + item;
    }

	//3、释放内存
	if( source != NULL)
		(*env)->ReleaseStringUTFChars(env, source, pByte);

    return hash & 0x7fffffff;
}

/*
 * Class:     com_tencent_weigou_jni_CFileApi
 * Method:    getLastAccessTime
 * Signature: (Ljava/lang/String;)J
 */
JNIEXPORT jlong JNICALL Java_com_tencent_weigou_jni_CFileApi_getLastAccessTime
  (JNIEnv * env, jobject o, jstring filePath){
        jlong time = 0 ;
	    if( filePath == NULL)
		    return time;

	    //1、转成char字符
	    const char* filename = (*env)->GetStringUTFChars(env, filePath, NULL);

	    if( filename == NULL)
		    return time;

        struct stat buf;

	    //2、获取文件信息
        if (!stat(filename, &buf)) {
            time = (jlong)buf.st_atime;
        }

	    //3、释放内存
	    if( filePath != NULL && filename != NULL)
		    (*env)->ReleaseStringUTFChars(env, filePath, filename);

	    return time;
  }

/*
 * Class:     com_tencent_weigou_jni_CFileApi
 * Method:    sign  生成加密串
 * description: 对于给定的一个魔术值token(一个24进制的long转成String)和一个字符串url(请求Url,这里建议加上一个时间戳)，进行hash得到另一个值
 *                    result = Function((hashCode = hash(magic,srcStr)) + token);
 *               result格式为："u_"+ 20进制的(hashCode) + "_" + 28进制的(token) + "@qq.com"
 *
 * @param magicStr 魔术字,这个是一个24进制的字符串
 * @param source 源串，url请求串
 * @return 返回 加密串的20进制加上token的28进制的组合串
 *
 * Signature: (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_com_tencent_weigou_jni_CFileApi_sign
  (JNIEnv * env, jobject o, jstring magicStr, jstring source){
        //1、转换魔术字，
	    const char* token = NULL;

	    if( magicStr != NULL )
		    token = (*env)->GetStringUTFChars(env, magicStr, NULL);

	    jlong magic = 0;

	    //2、解析魔术字，这个魔术字是一个24进制的
	    if(token != NULL)
	    {
		    magic = strtoull(token,NULL,24);
	    }

	    //3、调用接口生成加密串
	    jint result = Java_com_qq_buy_jni_CFileApi_sign_hash(env, (int)(magic%2147483647),source);

	    char tokenBuf[16] = {0}, keyBuf[16]= {0}, retBuf[50] = {0};

	    //4、把加密得到的串转成20进制
	    Java_com_qq_buy_jni_CFileApi_ltos(result,20,keyBuf);

	    //5、把token转成28进制
	    Java_com_qq_buy_jni_CFileApi_ltos(magic,28,tokenBuf);

	    //6、组合返回结果
	    snprintf(retBuf,sizeof(retBuf),"u_%s_%s@qq.com",keyBuf,tokenBuf);

	    jstring ret = (*env)->NewStringUTF(env, retBuf);

	    //7、回收内存
	    if( magicStr != NULL && token != NULL)
		    (*env)->ReleaseStringUTFChars(env, magicStr, token);

	    return ret;
  }
